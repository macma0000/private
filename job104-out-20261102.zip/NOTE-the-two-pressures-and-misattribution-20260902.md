# NOTE — the two pressures, and misattribution

**Produced 2026-09-02 in `Job44 coherence 09022026` while ruling fault 13. It is not fault
material and does not belong in the claim inventory, which records faults and their rulings.
This is a positive account and it is NEW — book 2 contains none of it.**

**Status: `[A]` called it valuable new material and did not rule it into the book.** Nothing here
is applied. A chapter that takes it up is a later decision.

---

## WHAT FORCED IT

`[A]`'s ruling on fault 13 — that what is blocked or ignored still goes into the deposits and
accumulates there unseen, and that the accumulation is what eventually forces sight — gives the
model a **pressure building from inside**. Ch 17's *Why this does not take everyone to the floor*
already has a pressure **growing with distance fallen, from outside, in consequences**. Nothing
in book 2 says how the two stand to each other. This note is the attempt.

---

## 1. WHAT THE TWO PRESSURES SHARE

**Both work by putting pain into the same comparison, and blindness cannot remove either.**

Ch 17's account of why consequences still reach a blind person: **blindness does not corrupt the comparison of immediate pains — one of its terms is simply
not there to be weighed**, and consequences
survive that because their trigger is not self-recognition. The pain arrives from the world and
blindness has no purchase on it.

Buried material produces pain blindness also cannot remove, for the same reason — the Z+ sketch:
*buried anxiety continues to cause stress even though it is not consciously seen.*

## 2. WHAT DIVIDES THEM — and this was `[C]`'s, and it is the load-bearing link

**Consequence-pain has an identifiable source in the world, so it can redirect behavior — there
is somewhere to send the response. Deposit-stress is unattended by definition, so it has no
attributable source, and pain with nowhere to send you is what forces a look inward.**

That gives each pressure its own product, and they are the two things Ch 17 says are needed —
*what fails at the bottom is aim, not energy*:

- **Consequences supply energy and redirect it.**
- **The deposits supply the occasions when aim is possible.**

Neither substitutes for the other, which is why the account needs both.

**It also explains the intervener without adding anything.** Ch 17 has another person supplying
sight rather than force, becoming necessary *exactly as the first thing weakens*. On this reading
**the intervener does from outside what the deposits do from inside**, and is needed when the
inside route has been outpaced — because blocking strengthens each time it runs while the material
it holds down also grows, and far down the reinforcement has had more use.

*Three of the four moves are the book's: energy against aim, blindness removing a term, the
intervener supplying sight. The locatable-source distinction is `[C]`'s.*

## 3. THE OBJECTION, WHICH IS THE ORDINARY CASE

**If deposit-stress does get attributed — if a person reliably blames it on something — then it
redirects behavior like any other consequence and produces no inward turn at all.** This is not
obviously false and may be the ordinary case. If it is, **the inside pressure produces sight only
when the attribution fails.**

## 4. `[A]`: THE EXCEPTIONS ARE NOT RANDOM AND HAVE SPECIFIC CAUSES

Misattribution needs a **candidate** — something plausible enough to carry the stress. Candidates
do not appear at a constant rate. So the exceptions cluster where candidates run out:

- circumstances are good and the stress persists anyway, so there is nothing to pin it to;
- the same complaint has followed a person through several changes of circumstance, each new
  candidate undermined by the last;
- **the accumulated load has grown past what any candidate can plausibly account for** — not a
  separate cause but the same accumulation making misattribution progressively harder to sustain.

**Two consequences.** The rare clear moment is no longer rare for unstated reasons: it is rare
because candidates are usually available, and it arrives when they fail — **a condition in place
of a bare frequency claim, which is what the chapter was missing.** And this is two mechanisms
working against each other, the load rising while the supply of candidates stays roughly flat.
*`[C]`'s caution, unresolved: that is the same shape as the blocking mechanism `[A]` ruled, where
the arrangement entrenches while the material it holds down grows. Two pressures with the same
shape is either a real symmetry or a sign the second was built in the image of the first.*

## 5. `[A]`: SELF-BLAME BLINDS AS WELL AS OUTWARD ATTRIBUTION — and this killed a fourth cause

**`[C]` proposed a fourth cause and it is WRONG. Recorded so it is not re-proposed.** `[C]` had
attribution outward as a physical-realm move, so a person detached in the physical realm would
have fewer candidates and misattribution would fall unevenly across the grid. **`[A]`: psychic-realm
self-blame is just as blinding.** The psychic realm supplies its own candidates — my fault, myself,
my character — so someone short of physical candidates has an inexhaustible stock of psychic ones.
**The grid prediction dies, and running out of candidates is harder than `[C]` made it.**

**Why self-blame blinds, and the book can already say it.** The mechanism is not attribution
outward. It is **attribution to something — anything that terminates the question.** Naming a
cause closes the inquiry, and a psychic cause closes it as firmly as a physical one. Ch 16 has
this in its descent: the fears turn inward until they are all about the person's own failing, and
**Ch 16 does not treat that turn as an improvement in sight.** So self-blame is on the descending
side of the axis — *the book saying that looking at yourself is not the same as seeing yourself.*

**`[A]` connected this to the Buddhist position that the concept of a self is wrong and
misleading, and the book reaches the same point independently** — which is worth keeping separate
from whether the traditions are invoked at all, since that is Part 4's first question. Ch 13 has
the self as **a position produced by the folding, built for a contest, not an object and not
findable by looking inward.** So a self-blame attribution **assigns the stress to something that
is not there to hold it**, which is why it terminates the question without resolving anything and
can be repeated without limit.

*That is a stronger account of why self-blame blinds than `[C]`'s locatable-source distinction in
§2: it is not that the source is hard to find, it is that the thing named as source is not a
thing.* **§2 is therefore weakened and not withdrawn — how much of it survives §5 is not settled.**

## 6. WHAT THE EXCEPTIONS ACTUALLY ARE, AFTER §5

**Not moments when candidates run out, but moments when the attributing itself is seen.** Ch 17
already names that as the one object worth recognizing: *not the individual fear but the
arrangement that disposes of fears without consulting anyone* — the single thing running under all
of them, whose recognition generalizes.

---

## WHERE THIS WOULD GO, IF IT GOES ANYWHERE

Not sited. Ch 17's *Why this does not take everyone to the floor* is where the outside pressure
lives and where fault 13's ruled repair lands, so it is the obvious candidate for §1–§2. §5 and §6
are closer to Ch 17's *What is actually being undone* and to Ch 16's account of the fears turning
inward. **`[A]` has ruled none of this.**

## THE CAUTION `[C]` ENTERED WHEN IT STOPPED

Four turns of new material with no session between it and the manuscript, and **two of `[C]`'s
links broke on first contact with something `[A]` knew** — the fourth cause in §5, and the
locatable-source distinction weakened by it. *`[C]` stopped rather than building further. A
session taking this up should treat §2 and §4 as needing a check they have not had.*
