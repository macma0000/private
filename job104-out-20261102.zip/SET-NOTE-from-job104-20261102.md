# SET NOTE — from `Job104 drafting 20261102`

This note goes to the session that receives `job104-out-20261102.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job105-20261102`.

## Arrival

The session was given as `Job104 drafting`. `setcheck.py verify`: 58 ok, 0 mismatched, 0 bad count, 0 missing, 258 not
in the manifest, all in `spent/` and `superseded/`. Screen: the record is the one carry-do-not-read hit; all 51 drop
hits are names in `superseded/`. Sweep: the record's last marker matched `Job103`'s note, hundred-and-fifth append,
109,014 w. The record was not opened.

## The job

`FINDINGS-job103-20261101.md` Part Four, items 1 and 2. Every wording already had `[A]`'s *yes*, relayed through
`Job103`; nothing was shown to him in this session. **Every site is in `CHANGES-job104-20261102.md`.**

## What was done

`BOOK2-20261101.md` (45,342 w) became **`BOOK2-20261102.md`** (45,334 w):

- **The two realm sentences drop *pushes back*.** In *Why this does not take everyone to the bottom*, the explaining
  paragraph's physical- and psychic-realm sentences no longer name the pushback mechanism, since the section's own
  *Consequences do.* already carries it in both realms. *the world pushes back:* and *nothing outside pushes back:*
  are gone; nothing else in the two sentences changed.

**Register letter `t`** (`WORD-RULINGS-book2-20261102.md`): amends the `Job102` block's description to match, with
`[A]`'s words (relayed); one pattern added, `outside-pushback`. **Style guide:** unchanged.

## The record

One append, the **hundred-and-sixth**, blind: no new words of `[A]`'s were given in this session, so the append is
`[C]`'s report only, citing his relayed words. **Parent 109,014 w, head 109,240 w.** The parent's 650,631 bytes were
checked unchanged at the join by md5 before appending.

## Moved

- To `superseded/`: `SUPERSEDED__live__BOOK2-20261101.md`; `SUPERSEDED__live__WORD-RULINGS-book2-20261101b.md`
  (letter `s`); `MANIFEST-job104-20261101.md`.
- To `spent/`: `SET-NOTE-from-job103-20261101.md`.
- **New and live:** `BOOK2-20261102.md`; `WORD-RULINGS-book2-20261102.md`; `CHANGES-job104-20261102.md`.
- **Kept live:** `FINDINGS-job103-20261101.md`, until a coherence run checks the master against it;
  `FINDINGS-job101-20261101.md` (items 4 and 5 owed); `CLOSURES-SITED-job99-20261030.md` (Parts E, F, G owed);
  `FINDINGS-job99-20261029.md`.

## What is owed

- **A coherence run on `BOOK2-20261102.md`**: check the master against `FINDINGS-job103-20261101.md` Part Four items 1
  and 2, then move that findings file and `CHANGES-job104-20261102.md` to `spent/`.
- **The letters pass** (closures Part G, pilot first) must change *The letters are never used for a phase. So a letter
  always means a person.* in *The phases and their names* (`FINDINGS-job101-20261101.md` item 4).
- **Held for `[A]`'s scope and his paper read:** a person placed *at* or *near* an end of the detached phase
  (`FINDINGS-job101-20261101.md` item 5); the density items carried from `job100`'s note.
- **Still from earlier notes:** closures Parts E and F; the record's index of subjects (doctrine); `wordcheck.py` has
  no Part-3 scope, and `refcount.py` writes to a fixed `Job59` path (tools); the handoff is now six sessions behind.
- **Still waiting:** the writer 2 pass, on Toby Marshall; the Introduction on recognition, on `[A]`.

For any session that shows `[A]` a change: bold does not show on his screen. Mark new words with square brackets and
list the words going out underneath.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261102.md`.** The kind is `[A]`'s to say.
