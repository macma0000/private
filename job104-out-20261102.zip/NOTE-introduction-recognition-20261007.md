# NOTE — what the Introduction should say about recognition

Cut 2026-10-07 by `Job70 doctrine 09152026`, at `[A]`'s request, **to be done later.** Not sited,
not drafted, and no session is to act on it until `[A]` says so.

**`Job70` has no manuscript.** The Introduction is not quoted here.

---

## `[A]`'s words, 2026-10-07

> most of what we are writing everyone knows in a pre-conscious way. the value here is that it made
> explicit.

**For the Introduction.**

## Why it belongs there

**It tells a reader what kind of book this is before they meet anything strange.** A reader has no
way to check the two realms, the phases or the fates against evidence. **What a reader can do is
recognize the thing described.** Saying so at the start tells them what to do with every chapter,
and it is honest about what the model offers.

It also agrees with what the book now says elsewhere: a person in the unease loop experiences
effort rather than being stuck, and a person who turns away from a fear cannot find the moment they
chose to. **Both are things a reader knows and has never had put into words.**

## Three cautions for whoever writes it

**Do not promise that everything will be recognized.** Parts of the book are derivation that nobody
could recognize — the nine pairs, the hexad, the triangle. **A reader who expects to recognize those
and cannot will take the failure as a fault in themselves or in the book.**

**`pre-conscious` is machinery and does not go on the page.** The plain form: people already know
most of this without having put it into words, and what the book does is say it.

**This is a claim about the book**, which the style guide bars in running prose. **The Introduction
is where such a claim is allowed**, since the book has not started. Say so in the instruction, or a
drafting session will flag it against the rule.
