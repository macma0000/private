# BOOK 2 ARCHITECTURE — 2026-08-15b

**Supersedes `BOOK2-ARCHITECTURE-20260815.md`**, which placed the growth material as Part Two.
`[A]` corrected this: **book 2 follows book 1's order.** Part 2 is the finer structure; the Levels
and the growth go in Part 3.

Why the first version was wrong, on the record: it was written before book 1 was read, so book 2's
order was never checked against it. The targeted read is what should have caught it and came after.

**This file places Part 2 and fixes Part 3's boundary and contents. It does not architect Part 3** —
`[A]` has that as the next job. The per-chapter growth specs from the superseded file are carried
forward in §5, intact, to be re-placed there.

Provenance `[A]`/`[C]`/`[J]`. Sources: the six job-1 files, book 1 `rev2-0814b.md`, the eight
figures, and `BOOK1-INDEX-20260815.md`.

---

## 1. RULED THIS SESSION

**R8. The spiral debt is void.** `[A]`, 2026-08-15. Riso and Hudson publish no winding figure.
Theirs is a chart: nine rows under a four-column legend — behaviors, attitudes, desires, fears —
with fear the only cross-row arrow, pointing down to desire on the next level; one upward arrow in
the whole figure, desire at Level 2 to desire at Level 1, marked escape. `[A]`: the fear and desire
columns alone would wind, so the shape is latent, but the figure shows no way up except from
Level 2, **so it was not meant to be that specific.** "Spiral" in their prose is a metaphor for
repeated traversal, not a picture. R6's unnaming stands on its own internal reasons. **Append to
`RULINGS-20260814.md`.** Corrections owed: the old handoff §6 item 2 and `VERIFY-20260815.md` both
say they publish a spiral figure; both are wrong.

Kept from the figure `[C]`, held loosely: **their figure draws the movement once, at the top, as
escape; the book says that movement is what every rung's climb is** (R5.3). Better than "they
describe, the book supplies mechanism," and wanted by the Ch 15 repair. And it diagnoses the bad
sentence — the error was reading a figure's omission as a doctrinal reservation.

**Levels.** `[A]`: as presented by R&H. Their nine rows are the ladder; the book supplies the
mechanism and adds Level 0. This is what R2 presupposed — "Level 1 is Z−" only parses on their
numbering.

**Order.** `[A]`: book 2 follows book 1's order. Part 1 stands as written; the cycles chapter and
the grid chapter go into **Part 2**, not back into Part 1.

**Scale.** `[A]`: the small arcs are momentary process; the relation between the orientations and
the figure is habitual fixation. Only indirectly related — see §6, it is the standing hazard.

---

## 2. THE SHAPE, AND THE TABLE OF CONTENTS

| | | Corresponds to |
|---|---|---|
| **Part 1 — The Model** | Ch 1–5, **written** | Book 1's Part I |
| **Part 2 — The Finer Structure** | Ch 6–12, **placed** (§3) | Book 1's Ch 5 and 7, then Part II, plus Ch 14 |
| **Part 3 — The Depth of Fixation** | Ch 13–16, **provisional** (§4) | Book 1's Part III, minus the parallels |
| **Part 4 — Parallels** | Ch 17+, **sketch only** | Book 1's Ch 13, and Ch 18's contemplative half |

Book 2's Part 1 is book 1's Part I minus two chapters: the cycles (book 1 Ch 5) and the grid
(book 1 Ch 7). `[A]` places both at the head of Part 2 rather than filling the gap in Part 1, which
leaves a written and agreed part untouched.

### The proposed contents

Foreword · Introduction

**Part 1 — The Model** — *written, 10,491 words*

1. A New Theory of the Enneagram
2. The Nine Enneagram Types — Profiles and Self-Perception
3. The Two Realms
4. The Three Orientations — **two additions** (`[A]`, 2026-08-15, from writer 2's reply). A clause
   at first use of *competence*: **the desire for competence is native, the details are learned** —
   which leaves book 2's "arrived at deliberately" standing for B. And **looking versus seeing,
   stated in detail**: you look, and seeing is what arrives when looking succeeds. The second is
   load-bearing — it is what makes *blindness is not chosen* coherent, and it is the hinge for
   suppression versus dissolution in Part 4. R7 is cut, so nothing states it later unless Ch 4 does.
5. Where the Types Come From — **gaining "What Each Pair Asks"** (`[A]`, 2026-08-15), after Type 9
   and before "In Short." Delivered as `BOOK2-Ch5-insert-what-each-pair-asks-20260815.md`.

**Part 1 now carries three changes, not one.** It was untouched at the start of 08-15 and `[A]` has
twice declined to open it. Two of the three came from writer 2, who co-owns these chapters and has
seen none of them. **The accumulation is worth looking at as a whole before any of it is applied.**

**Part 2 — The Finer Structure** — *placed; most of it exists in book 1*

6. The Grid — book 1 Ch 7
7. The Cycle — book 1 Ch 5, split (see §3.1)
8. Relational Positions — book 1 Ch 8
9. Relational Dynamics — book 1 Ch 9
10. The Figure's Own Lines — book 1 Ch 10
11. Leans, and the Classical Wings — book 1 Ch 11
12. Learning to See — book 1 Ch 14. `[A]`, 2026-08-15: **definitely Part 2 material** — reading
    orientations and leans in a living person, not spiritual material. It follows Ch 11 because it
    is leans put to use. *Cost to notice: book 1's Ch 14 cites Appendix G twice, for preverbal
    learning and for the thinking/intuition split, and that material is Part 3's. Book 2 forbids
    forward references, so Ch 12 must make the preverbal point briefly in its own right — it is a
    developmental observation and does not need the core dynamics to stand.*

**Part 3 — The Depth of Fixation** — *the core dynamics straight, without Buddhism. Provisional —
see `BOOK2-PART3-PROVISIONAL-20260815.md`.*

13. Underneath the Cycle: The Three Transitions — R3
14. Where Fixations Come From — book 1 Ch 17, + Appendix G.2's floor
15. The Depth of Fixation: the Levels and the Core Dynamics — book 1 Ch 15, **+ Appendix G.1**, + R6
16. Falling and Rising, and the Problem of Leverage — book 1 Ch 16 + Ch 5, merged (`[A]`), closing
    on the counterfeit summit and then the leverage problem, stated and left for Part 4

*R7's two chapters are cut (`[A]`, 2026-08-15). The type-differentiated remedies go back to Ch 5 as
"What Each Pair Asks"; the counterfeit summit closes rising; active starvation goes into rising;
the propagation stays in the notes. R7 remains ruled doctrine — what is cut is its presence in
book 2.*

**Part 4 — Parallels** — *sketch only, Ch 17 onward.* The poisons and the Trimurti · one cycle at
every scale · no-self · choicelessness · the three releases and the answer to leverage · the Stoics.

**Appendices** — proposed set at §3A of the provisional file.

A. Reference Card · B. Comparison with the Classical Enneagram (book 1 Ch 12 + App D) ·
C. The Triad and Hexad Walks · D. The Complete Relational Map · E. What This Book Borrows ·
F. Karen Horney · G. The Level Chains of the Six Half-Types (book 1 App G.3) · H. Working with AI ·
I. A Hard Case: Mathematics

### What the contents do not yet settle

- **Sizing, after the merge and the R7 cut.** Part 1 five, Part 2 seven, Part 3 four, Part 4 five
  as sketched — twenty-one chapters plus nine appendices, against book 1's eighteen and nine. Part 4
  is the one still to be sized, since it is the only part never architected.
- **Book 1's Ch 13 — the spiritual and philosophical parallels — is Part 4's, which is a sketch.**
  Book 2 currently contains no contemplative material at all, and how much comes across is Part 4's
  first question. *Ch 14, Learning to See, is placed: Part 2's Ch 12.*
- **R6** sits at the close of Ch 15 in the provisional file. Confirm, and decide how much of it
  book 2 carries.
- Further appendices unplaced. Book 1's Appendix C (the step-by-step walk) is the natural companion
  to Ch 10; Appendix G is unread — job 5.

---

## 3. PART 2 — THE FINER STRUCTURE

`[A]` was unsure whether Part 2's internal order should change from book 1's. **`[C]`: it should
not, once one chapter is split.** Reasoning first, because it is the whole answer.

### 3.1 Book 1's Ch 5 splits, and that is what settles the order

Book 1 introduced depth early, so its cycles chapter carries three sections that are depth material:
**"Direction and Depth"** (L596), **"How a Person Sinks"** (L610), and **"What Makes a Step a
Release"** (L632) — the last being the three remedies, karma and emptiness and care. With depth
deferred to Part 3, all three go to Part 3, and book 2's cycle chapter is the cycle and nothing
else.

Two gains fall out. **The duplication dies:** book 1 tells how a person sinks twice, at Ch 5 and
again at Ch 16 "What Moves a Person"; book 2 tells it once, in Part 3. And **the three remedies
land where the methods are**, instead of arriving three parts before anything needs them.

With that removed, every remaining dependency is satisfied by book 1's own order, so there is no
reason to depart from it.

### 3.2 The chapters

**Ch 6 — The grid.** Book 1's Ch 7. The 3×3, H across and S down, the nine placed, the aligned
diagonal. Cheap, and it is the tool the rest of Part 2 uses. **Figure: `two-realm-grid`.**
*Placed first rather than second because it is a picture of the argument Ch 5 has just finished in
prose, and because positions, arrows and leans are all grid moves. The alternative — cycle first,
as more fundamental — is defensible; this is the one ordering call in Part 2 that is a judgment
rather than a dependency.*

**Ch 7 — The cycle.** Book 1's Ch 5, stripped to the cycle: A→B→Z→A; integration forward,
disintegration reverse; what kind of thing the cycle is — the three scales, and that a fixation is
where arcs come to rest rather than a place a person stands; the cycle at its smallest scale.
**And the two entries into Z**, which book 1 states here (L582): integration enters detachment
seeing, disintegration enters it blind — *"Detachment, alone among the orientations, contains these
opposites."* **Figure: `orientation-cycles`.** Standing rule: "cycle" only for the closed loop, a
single traversal is a **process arc**.

**Ch 8 — Relational positions.** Book 1's Ch 8. The six positions read off the grid — Double Ahead,
Ahead, Equal, Behind, Double Behind, Identical.

**Ch 9 — Relational dynamics.** Book 1's Ch 9. What the positions are like from inside; aligned
versus non-aligned. *II-B wants a successor to this chapter for the A/B intrapsychic-versus-
interpersonal material, written so neither depends on the other.*

**Ch 10 — The figure's own lines.** Book 1's Ch 10, and the payoff chapter. Integration runs the
cycle forward and disintegration backward; a step advances the realm whose advance leaves the
type's class intact; hence six steps for the mixed types alternating realms, three for the aligned
types moving both. The classical hexad and triad fall out exactly. Book 1's own Overview calls this
*"the model's strongest single piece of evidence."* **Figures: `enneagram-hexagon`,
`triad-hexad-cycles`, `hexad-cycle`; `wraparound-grid` if the diagonal reading is wanted.**
Open, §7: whether book 2 also carries the twelve relations the classical figure omits, and the two
extra triangles.

**Ch 11 — Leans, and the classical wings.** Book 1's Ch 11. **This is the bridge to Part 3 and the
most load-bearing chapter in Part 2.** **Also gains the disregard/denial contrast** (`[A]`,
2026-08-15): you can decline to attend to what you have already seen; the looking that would have
shown you something can stop without your deciding; and where it has stopped there is nothing left
to decline. Only the first is chosen. It lands here rather than in Ch 4 because this is where book
1 already has the machinery — *at Z− the lean toward B funds attention, at Z+ the lean toward A
funds an aversion to looking.* The lean notation; and **detachment's lean is special** —
Z− toward B is dispassionate vision, Z+ toward A is blindness, one quantity across a range rather
than two conditions with a boundary. Z0 as unselective receptivity and as a limit. Part 3 cannot
start without this: the health axis is the Z arc turned on a third object, and "Level 1 is Z−" is
unreadable otherwise.
*Scope open (§7): book 1's eight-wings-per-type claim and the fractional-lean notation are a large
apparatus and the book's explicit disagreement with the classical system.*
*Not carried: the `opposite-relationship` figure — settled doctrine says opposite is not a
relational class, and the figure draws it as one.*

**Comparison with the classical system** — book 1's Ch 12, with its scorecard. **Ruled `[A]`
2026-08-15: an appendix, not a chapter.** It is reference rather than argument, book 2 has not set
itself up as an audit the way book 1 does, and Ch 10 already makes the correspondence claim where
it is strongest — a scorecard chapter after it would restate a case the reader has just been given.

### 3.3 What Part 2 must not spend

R3's transitions as fundamental, and the orientations as derivative — names of the three ways a
process can stall. Ch 7 gives the cycle as an ordering and Ch 10 uses it; neither says what the
ordering is made of. **Where the transitions layer sits is open (§7) — `[A]` did not rule on it.**

---

## 4. PART 3 — BOUNDARY AND CONTENTS ONLY

**Not architected here.** What belongs to it, so Part 2 does not spend it and the next session
knows its inventory:

- The health axis and the Levels (book 1 Ch 15).
- Falling (book 1 Ch 16 "What Moves a Person," plus Ch 5's "How a Person Sinks" folded in, told
  once).
- Rising, the summit and the exit (book 1 Ch 16, Ch 18).
- What a rise requires — the two-realm requirement (R7.1). **The most novel chapter in the part:
  book 1 has the two-realm requirement only as a summit phenomenon; propagating it down the ladder
  via R5.3 is in book 1 nowhere.**
- The methods (book 1 Ch 18's leverage and choicelessness, Ch 17's habit, **and Ch 5's "What Makes
  a Step a Release"** — the three remedies, which arrive here rather than in Part 2).
- What each pair brings (R7.4 and the three structural positions).
- The spiritual parallels and learning to see (book 1 Ch 13, 14).
- Origins and endings (book 1 Ch 17, 18).

**And R6, which is now available.** The superseded file deferred the winding structure because
book 2 had no cycle for the angular coordinate to attach to. Part 2 supplies it. **Part 3 can carry
R6 whole** — level change only at the seam crossing, the seam passable only at the currency's
extremes, the descent's blacked-out crossing, and why insight arrives climbing and never
mid-collapse. That is a direct gain from `[A]`'s reordering.

---

## 5. CARRIED FORWARD — the growth chapter specs

From the superseded file, to be re-placed when Part 3 is architected. Anchors and exclusions hold;
positions and numbers do not.

- **The axis.** R2 — one quantity, two objects; independent as coordinates. R&H's Levels as
  landmarks, **tight at the ends and loose in the middle** (R2). Anchor: Ch 4's two faces of
  detachment, now reinforced by Part 2's Ch 11. Hazard: "Level 1 is Z−" is an identity in the
  currency only — the healthy person is not thereby detached.
- **Falling.** R2's filing; the trap (E2–E4) transferred whole; "the levels do not wrap," derived;
  the graded cut, thinnest at the top, and thin-at-top is safe.
- **Rising.** R5.3 — the exit is the climb performed on the last layer; withdrawal, seeing, and the
  gain arriving only on re-engagement; every rung's climb shows the summit's shape in miniature.
  Level 0 as a passage, touched and renewed. Plus R8's finding. **Open: whether Level 0 goes into
  book 2 at all, and whether R5.4 stays out on register grounds.**
- **What a rise requires.** R7.1, and the half-attainment derived rather than described. Anchor:
  Ch 3's two realms and Ch 5's per-type unwatched realms.
- **The methods.** R7's frame — type-neutral methods, type sets the length of the walk. The
  attention bind (R7.3); suppression and dissolution (R7.6). **The second-method question is
  answered by book 1's own practice** — Ch 5 and Ch 18 both name emptiness, state the vow, stop
  short and install care first. Book 2 follows that model.
- **What each pair brings.** Starve versus substitute (R7.4), and the three structural positions —
  no Z realm, one, two. **Not the nine roads, and not the walk-length ordering** — §6.
  **Scheme collision:** book 1 sorts by *which* realm is detached (four families); this sorts by
  *how many*. Both correct for their own job; the families cannot carry this material, since they
  put the 3 and the 9 together.

---

## 6. DECISIONS THAT SURVIVE THE REORDERING

**(a) R7.5's nine roads stay out of book 2.** Third pass through the nine after Ch 2 and Ch 5; the
walk-length ordering reads as ranking without Ch 16's register to protect it; entirely `[C]` and
hours old when ruled; forward tests unrun. Replaced by the three structural positions. R7.5 remains
ruled and available; its home is book 1's successor material.

**(b) The two scales stay visible — standing hazard.** `[A]`: **the small arcs are momentary
process; the orientation-to-figure relation is habitual fixation.** The Levels, the fixations and
Ch 10's arrow-steps are habitual; R5.3's withdrawal-seeing-re-engagement is momentary. `[C]`
blurred them this session — counting six arrow-steps as sub-revolutions of a process arc, and
reporting a collision with the small-arcs note that does not exist. **The error looks like
completeness, which is why it got as far as it did.** Check every Part 2 and Part 3 chapter
against it.

**(c) The small-arcs note is not built on and not foreclosed.** Nothing states what a step is made
of, at what scale fear clears, or which edge carries the depth change. The Levels stay loose in the
middle; the rising chapter is shaped to the note's own §5 template. **Drafting does not need the
note.**

**(d) Ch 2 stays.** Recognition, not duplication — Ch 5's derivations assume a reader who has a
type in hand. First to cut if book 2 runs long.

**(e) A figure can name what the prose leaves unnamed.** R6 retired "helix" and withdrew "spiral
staircase." **No figure of the winding structure, in Part 3 or anywhere** — a drawing has to commit
to a pitch, which is the feature R6 found non-uniform.

---

## 7. OPEN, FOR `[A]`

1. **Where the transitions layer sits.** Not ruled. End of Part 2, opening Part 3, or late in
   Part 3 with origins and endings.
2. **Ch 10's scope** — the two classical cycles alone, or also the twelve single-ahead relations
   the classical figure omits, and the other two triangles. All three are in book 1's Ch 10; the
   last two add structure the classical system does not have.
3. **Ch 11's scope** — how much of the eight-wings claim and the fractional-lean notation book 2
   carries. It is book 1's explicit disagreement with the classical system.
4. ~~The comparison chapter.~~ **Ruled 2026-08-15: Appendix A, not a chapter.**
5. **Level 0 in book 2**, and **R5.4 out on register grounds**. Both Part 3, both one line.
6. **Z+ named "blindness."** Book 1's Ch 11 names it; Part III item 4 has the naming open. One of
   the two is stale.
7. **Book 2's chapter numbering** assumes Ch 1–5 keep their numbers. If Ch 2 goes, everything
   shifts.
