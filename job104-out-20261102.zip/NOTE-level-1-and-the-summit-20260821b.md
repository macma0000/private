# NOTE — what Level 1 actually holds, and the figure it was read off

Cut 2026-08-21 by `Job12 doctrine 2f session 8-21`, at `[A]`'s instruction, because the material
below reached the record only as verbatim entries in `AUTHOR-RECORD.md` and **nothing pointed at
them**. A note nobody is told to read is the failure mode this project already has twice.

**REVISED 2026-08-23 by `Job14 doctrine 2g session 8-23`. Replaces
`NOTE-level-1-and-the-summit-20260821.md`; quarantine that file.** The revision is surgical — every
word of the original is below, with the 08-23 rulings marked where they bear. **Read §0 first.**

**Nothing in the original was ruled.** `[A]` marks the author's words, `[bk1]` book 1 quoted and
measured by `grep`, `[C]` mine. **`[C]`'s share is small and is marked at every point**, because this is a
description of a book neither `[C]` nor the record has seen.

**Scope.** One subject: what Level 1 contains, and what `[A]`'s reading of Riso and Hudson's chart
says about it. It does not touch the health axis generally, it does not reopen the winding
structure, and it takes no part of the reserved depth-and-threshold question.

---

## 0. WHAT WAS RULED ON 2026-08-23 — added at revision

**`[A]`, and it settles the file's central claim and one beyond it:**

> the exit is the upper half of Level 1 - make it match riso.

> riso's self-actualization is our liberation.

**Three consequences, and the third is the large one.**

1. **§1's third claim — the internal half-step — is RULED.** Level 1 has two heights and a person can
   be at either. It is no longer an interpretation awaiting the book.
2. **§5's parked fork is untouched.** Where the branch sits — at the fear, as book 1 has it, or at
   the basic desire, as the chart has it — is a *different* question and is still parked on the same
   terms. **Do not read the 08-23 ruling as settling it.**
3. **LEVEL 0 IS ABOLISHED.** Book 1's argument for a rung above Level 1 is that Level 1 *still retains
   a desire, and a desire, however refined, is still a rung* — but self-actualization is not a desire.
   It stands where the desires stand on every other row and is not one. **The premise fails and the
   rung goes.** What Level 0 named is the upper half of Level 1. Full account, with the repair sites
   and what it costs the impermanence result, in the live handoff at §5 and §6.

**Two of §7's three questions are discharged by this.** Question 1 (is *higher* physical on the chart
or inferred from the arrow) no longer gates anything — the half-step is ruled either way. Question 3
(does anything in R&H give Level 1 two positions) is answered in the affirmative by the ruling.
**Question 2 — whether the turning point at the basic desire is R&H's framing or the chart's artifact
— is still open and still wants the book.**

**What did NOT change.** §3's verbatim chart description and its discount stand exactly as written;
§4's list of what is undisturbed stands; §6's recorded softening stands, unproposed. **Nobody but
`[A]` has seen the figure, and that is as true after the ruling as before it.**

---

## 1. THE REDEFINITION — `[A]`, and it is the reason this file exists

**Level 1 is not one place. It holds two things, and one sits above the other.**

> level 1 has the basic fear and self-actualization in place of a desire

> then there is a single arrow going from the basic desire (level 2) to self-actualization at level 1
> - which can be inferred as higher that the basic fear at level 1

> so he starts at the fear at level 1 and comes back to self-actualization at level 1 - which is like
> a half step higher

**Three claims in that, and they should be kept apart:**

1. **Level 1 carries the basic fear.** Not a fear derived from a desire above it — the seed of the
   whole downward sequence.
2. **Level 1 carries self-actualization *in place of* a desire**, where every level below carries a
   desire proper.
3. **Self-actualization sits higher than the basic fear, on the same row** — so **Level 1 has
   internal structure and a person can be at two different heights within it.** `[A]`'s phrase is
   *like a half step higher*.

**The third is the new one.** The record has treated Level 1 as a single position throughout.

### 1.1 And Level 1 is therefore not freedom — `[A]`

> riso's top level is not freedom. he explicitly has an arrow up out of level 1 where the basic fear
> is dissolved.

**The basic fear is still present at Level 1.** It is dissolved by the upward step, not by arriving.

---

## 2. WHAT BOOK 1 ALREADY HAS, MEASURED — and it agrees, which is the useful finding

`[bk1]`, Appendix G, and it is explicit:

> F(1), the basic fear, is a fork: answered by D(1) it is *released* — the desire is not to secure the
> basic fear's object but to let the fear itself go — and answered instead by the securing-desire D(2)
> it drives the descent. Released, F(1) seeds no descent; with the basic fear gone there is nothing to
> generate a next level, and the movement is *out* the top, onto Level 0

`[bk1]`, Ch 16:

> So Level 1 is the highest position *on* the ladder — the summit, not the exit from the building.
> And the core dynamics record the residue that distinguishes them: Level 1 still retains a desire (to
> be free of illusory beliefs), and a desire, however refined, is still a rung.

**So claims 1 and 2 of §1 are book 1's own and need no ruling.** *(`[C]`: the session that opened
this had gone to Ch 15's one-line level summary instead of to the structure, and read Level 1 as the
place where the fear is already gone. `[A]` corrected it. **Go to Appendix G and Ch 16 for Level 1,
never to the summary line.**)*

**Claim 3 — the internal half-step — is NOT in book 1.** `grep` finds nothing giving any level an
internal position. **That is the part that is new** — *and it was ruled on 2026-08-23; see §0. The
sentence read "and it is unruled."*

*Measured at revision, and it makes the ruling cheap: **book 1 has the half-step's content already**,
without the label. Ch 18 has Level 1 as Z−, calm clarity with the last trace of a seeing lean, and
Level 0 as what lies past it when even that trace is gone. **Strike the rung label and that sentence
is the internal half-step** — the lower height Z−, the upper what remains when the last lean goes.*

### 2.1 Where it may bear, `[C]`, offered and not built on

- **On the ruling that a level is many turns and the levels are recognition markers, not units.** A
  level with two nameable heights inside it is a concrete instance of a level not being a unit —
  consistent, and it costs that ruling nothing.
- **On the resemblance that reads Level 1 against the seeing end of detachment.** That resemblance is
  pitched at a single position. If Level 1 has two heights, **which one is the resemblance about?**
  Recorded as a question; the resemblance is a correspondence claim with no mechanism, so the answer
  may be *neither, it was never that precise*. *Answered at revision: **the lower height**. Ch 18
  gives Level 1 as Z− and the upper height as past the last trace of the lean. **And a warning found
  on 08-23:** the correspondence hedges this (`not that each Level is a particular orientation`) and
  **three later passages state it flat**, two of them using it to argue about the top of the ladder.
  The hedge is being spent as a fact.*
- **It must not become a mechanism joining the two coordinates.** That is the reserved question.

---

## 3. THE CHART — `[A]`'s full description, verbatim

**Provenance and its discount.** This is `[A]` reading the book in front of him and typing what he
sees. **He read the same figure twice within an hour on 2026-08-21 and got different answers**, and
retracted the first himself — see §4. This is the second reading and it is the one he stood behind.
**Nobody but `[A]` has seen the figure.**

> i was wrong. the way down is spelled out clearly. levels below 1 have fears and desires. level 1 has
> the basic fear and self-actualization in place of a desire. the downward fall entails the basic fear
> at level 1 creating a desire one level down. the desire at level 2 is called the basic desire which
> leads to a secondary fear at level 2. that iterates to the last secondary fear at level 9 where
> there in level lower and no arrow going farther down. then there is a single arrow going from the
> basic desire (level 2) to self-actualization at level 1 - which can be inferred as higher that the
> basic fear at level 1. the text says "it then follows that the way to lighten ones burden of one's
> more painful, defended states is to follow the spiral up against the arrows." ... "our discussion
> then, has led us back to the "turning point" at the basic desire at level 2." ...( there are two
> arrow there - one to the secondary fears and one going up to level 1 self actualization.) -- so he
> starts at the fear at level 1 and comes back to self-actualization at level 1 - which is like a half
> step higher. also good to know is that the desire doesn't lead directly to the fear as i said, it
> goes desire->attitude->behavior->fear.

### 3.1 Two further things in it that no file had

- **The within-row order is desire → attitude → behavior → fear.** The fear is produced at the end of
  the row's chain, not directly by the desire. `[A]` corrected his own summary on this point.
- **The basic desire is a turning point with two arrows out** — one down to the secondary fears, one
  up to self-actualization — **and R&H's own text calls it that**: *"our discussion then, has led us
  back to the 'turning point' at the basic desire at level 2."*

---

## 4. WHAT THIS DOES NOT DISTURB

- **The ruling that voided the spiral debt STANDS.** `[A]` floated nine upward arrows and retracted
  it — *"i was wrong."* One upward arrow, basic desire at Level 2 to self-actualization at Level 1,
  none below. **The four working files quoting that description need no repair**, and they were
  checked: `RULINGS-20260816b.md` (two sites), `BOOK2-ARCHITECTURE-20260815b.md`,
  `VERIFY-20260815.md`, `BOOK1-INDEX-20260815.md`. **No book 1 or book 2 text quotes it.**
- **The refusal to name the winding structure is untouched.** That ruling states in its own words that
  the retractions were made on internal grounds, not to get clear of R&H.
- **Levels as presented by R&H** — untouched.

---

## 5. PARKED, AND DELIBERATELY NOT SETTLED — the fork is in two places

**Book 1 puts the fork at the fear** — F(1) answered by D(1) or by D(2), and *"the two desires at the
top of the structure point opposite ways: D(1) out of it, D(2) down into it."*

**The chart puts the turning point at the basic desire**, which on `[A]`'s description points both
ways: everyone passes from the basic fear into the basic desire and the branch is taken there.

Asked whether the divergence was meant, **`[A]`: *"i was careless. riso's chart confused me. what i
entered is what is in the book."***

**Not pressed further, and the reasons are on the record.** It is the item answered and withdrawn more
often than anything else in this project; `[A]` read the chart twice in an hour with different results,
which says the chart is hard; and **measured — nothing in either book's text depends on it.** It wants
the book open and an unhurried hour. **Do not settle it at the end of a session.**

*`[C]`, recorded and not developed: the difference is not decorative if it holds. On book 1's version
the escape is a different answer to the fear, taken before the basic desire is reached. On the chart's
it is a different exit from the basic desire, taken after everyone has arrived there.*

---

## 6. ONE CLAUSE OF THE VOIDING RULING MAY WANT SOFTENING

That ruling says *"'Spiral' in their prose is a metaphor for repeated traversal, not a picture."*
`[A]` has now supplied the sentence — *follow the spiral up against the arrows* — where *the arrows*
are the drawn ones. **That is closer to the ruling's own *the shape is latent in the chart* than to a
loose metaphor.** One clause; nothing else in the ruling is touched. **Recorded, not proposed.**

---

## 7. WHAT TO DO WITH THIS

**Nothing, until `[A]` has the book open.** Three questions, all cheap with it in hand and
unanswerable without it:

1. Does the chart place self-actualization physically above the basic fear on the Level 1 row, or is
   *higher* an inference from the arrow's direction?
2. Is the turning point at the basic desire R&H's own framing, or the chart's artifact?
3. Does anything in their text give Level 1 two positions, or is the half-step `[A]`'s reading of the
   geometry?

**Question 1 decides whether §1's third claim is a description or an interpretation**, and everything
in §2.1 waits on it.

*Superseded 2026-08-23 — see §0. The half-step is ruled, so §2.1 no longer waits on question 1, and
questions 1 and 3 are discharged. **Question 2 stands, and the instruction that opens this section
stands with it: do not settle it at the end of a session.** The sentence above is left in place
because §7's ordering is what a successor will read first.*
