# FINDINGS — `Job99 doctrine 20261029`: how the book's parts connect, openings, and a glossary

Cut 2026-10-29 by `Job99 doctrine 20261029` from `BOOK2-20261029b.md` (md5 `f49c8c53`, 44,666 w, 1,867 lines).
`[A]` set the job in his first message: *examine the connections between the topics both at the paragraph to paragraph
level, between sections, chapters and overall. also consider that i want to add introductory paragraphs to the chapters
and sections that preview what the reader will see. and think about whether and how we can have a kind of glossary for
the vocabulary we have chosen for each chapter.*

**Status of everything below: `[C]` findings, not rulings.** Each item is put to `[A]` one at a time. His answers are
recorded in the section at the end, *Rulings in this session*, with his words. Nothing here is to be drafted until a
closures file carries his ruling on it.

---

## How the examination was made

- The master was read through, Foreword to the last line of Chapter 17, in one session.
- The style guide (letter `l`) and the word register (letter `p`) were read for what bears on openings and vocabulary.
- Two scripts, kept in the session's working folder and not in the set: one finds sentences that recur nearly word for
  word in two different sections; one finds the first line on which each of about seventy terms appears.
- The record was searched, not read through, for anything `[A]` has said about previews, introductions, glossaries,
  repetition and reader confusion. Nothing on previews or a glossary was found. **What was found bears on every finding
  about repetition**, `[A]` 2026-09-02:

  *i was suggesting that you might need to add repetition rather than delete it — in relation to the parts that are to be
  moved. as far as removing repetition, the same thinking applies: maybe it is necessary, but it should be done with the
  awareness of the other place it occurs.*

  So the repetition findings below are not a call to delete. They mark places where the same account is given twice or
  more **without either place knowing of the other**, so that no single place holds the account and the reader cannot
  tell which one to rely on. The 09-02 record also says what decides whether a move works: *what the next paragraph needs*,
  not whether a thing is said elsewhere.

---

## A. Overall

**A1. The main line holds through Parts 1 and 2.** The Introduction ends on its question, *why nine*, and Chapter 1 opens
on it. Part 1 answers it: two realms, three orientations, nine pairs. Part 2 follows from Part 1 step by step: the grid
sets the pairs out, the cycle orders the orientations, the positions come from the order, the figure's lines come from the
positions, the leans come from the cycle.

**A2. Superseded as the frame by `[A]`'s own account of 10-30, which is recorded under *Rulings in this session* and
set out at A2a.** What follows here is `[C]`'s first reading, kept because it describes the measure the second of his two
connections runs on. **`[C]`'s first reading: Part 3 is joined to the first two parts by one idea, how much a person
notices, and nothing at the start of Part 3 says so.** Part 1's orientations chapter ends on it:

> What separates the three orientations is what a person holding each one notices.

The health-axis chapter makes it the measure of health:

> What corresponds appears to be how much of what is there a person actually notices.

The falling-and-rising chapter opens on it:

> One thing moves on this axis, and it is not how much a person suffers or how hard they are trying. It is how much of their own condition they notice.

The opening of Part 3 names three other things, and its chapters do not take them in that order:

> What the chapters here take up is the limitation a person holds themselves inside: where the habit comes from, how deep it goes, and what holding it does to a person.

Where the habit comes from is near the end of Chapter 15 (*Two channels*, *The hinge*, *Habit carries it*). Chapter 13,
the first chapter of Part 3, is about where the inner world came from.

**A2a. Part 3's chapters under `[A]`'s two connections** (his words at *Rulings in this session*, 10-30). `[C]`'s mapping,
not yet put to him:

- **The first connection** — the characteristics of the fixations, and so of the types, against the phases and the way
  each fixation runs a thought — is **Chapter 14** and most of **Chapter 15** (*The range of detachment*, *Which fixation
  handles a fear*, *The four sketches*, and where a fixation comes from and why it holds).
- **The second connection** — what is behind the Levels — is **Chapters 16 and 17**.
- **Where the two meet:** Chapter 15's account of what becomes of a fear in the detached phase — the four fates, blocking
  and burial, unease. It belongs to the first by subject and is what the second runs on. Chapter 14 already says the
  meeting point in one sentence: *So how deep a person has fallen can change only in the detached phase.*
- **Chapter 13 falls under neither as it stands.** Its later sections supply three things the rest of Part 3 uses: why a
  fixation cannot be found by looking inward (*A slant on everything rendered*, used by Chapter 15's *The hinge*, *The
  first was that a fixation is a slant…*); why detachment is the one orientation with two faces (*Why detachment is the odd
  one*, used by Chapter 15's range of detachment); and why any way out runs through detachment (used by *Rising*). Its
  first four sections — brains, other minds, the self, self-reference — lead up to those, and deepen the realms chapter's
  account of the psychic realm. **Put to `[A]`: what Chapter 13 is for.**

**A2b. The Levels matrix.** `[A]` 10-30: *the connection would be better if riso's levels for each enneatype matrix were
included.* His standing plan, record 2026-08-26 (`job21-doctrine-20260826`): *ideally we will ask the enneagram institute
for permission too reproduce their table of the four attributes for 9 types and 9 levels*, and the letter goes when the
book is complete, before the style is polished, with permission not planned around. Nothing in this session changes that.
**`[C]` adds one small thing that needs no permission:** book 2 never names the book where the per-type descriptions are.
The health-axis chapter says *Those descriptions are the substance of their work and are not reproduced here.* and gives
no title. Book 1's Appendix E gives one: *For the full treatment see _Personality Types: Using the Enneagram for
Self-Discovery_ by Don Richard Riso and Russ Hudson.* Naming it lets a reader make the connection to the matrix until the
matrix can be included.

**A3. Only Part 3 has an opening.** Parts 1 and 2 begin straight on their first chapter. Chapters 13, 15 and 17 also have
no opening: each goes straight into its first section.

**A4. Part 3 is where the connections fail, and they fail in one way.** Part 3 was drafted a chapter at a time across many
sessions (the record says so, 09-02: *No session has ever had the job of reading the assembled part through*). The result
is that an account is told in several places, each partial, each written without the others in view. The account of how a
fear comes to be buried is the largest case (C2 below).

**A5. Chapter 15 is 8,734 words, nearly a fifth of the book, and carries four subjects:** the range of detachment; what
becomes of a fear (the fates, blocking, burial); unease; and where a fixation comes from and why it holds.

---

## B. Between chapters

- **B1. From the type portraits to the realms chapter.** Chapter 1 promised two places and three things. Chapter 2 then
  gives about 3,100 words of portraits *before any theory*. The realms chapter opens *Everything a person deals with falls
  on one of two sides.* and does not tie back to the two places a type's orientations sit.
- **B2. From the orientations chapter to the types chapter.** The types chapter opens *A person has one of these three…*,
  pointing back across the chapter break.
- **B3. The cycle chapter's last two sections are used by nothing in Part 2.** *What kind of thing this is* and *The
  smallest scale* set out processes, scales, phases and the three passages. The next use is Chapter 14, which opens by
  stating the passages again, nearly word for word:

  > A passage is the move from one phase to the next.

  appears in both. Under the 09-02 rule (minimal first, full later), the cycle chapter's statement would be the minimal
  one; at present it is as full as Chapter 14's.
- **B4. From the Part 3 opening to Chapter 13.** See A2. Chapter 13's link to fixation arrives only in its fifth section,
  *A slant on everything rendered*.
- **B5. From Chapter 13 to Chapter 14.** Chapter 13 ends on the self as a position in a contest. Chapter 14 opens *Until
  now the cycle has been used to put the three orientations in order*, picking up the cycle chapter, not Chapter 13.
- **B6. The health axis is named before the chapter that calls it new.** Chapter 15's unease-loop section says *The health
  axis reflects how much a person notices*, placed there by `[A]` on 10-17 (register §5a). Chapter 16 then opens:

  > The second is new — an axis of health, running from clearest functioning down to breakdown.

  Chapter 14 also says *how deep a person has fallen* before any fall has been described.
- **B7. The break between Chapters 16 and 17 falls inside the account of falling and rising.** Chapter 16's last three
  sections (*Where a level change can happen*, *Spoiled arrivals*, *What a level is made of*) already say what a fall is
  and what a climb is (*That is the fall.* … *That is the climb.*). Chapter 17 opens on the fall again, and its sentence
  *Each fear turned away from until it is no longer noticed takes a little of the noticing with it* restates Chapter 16's.
  Chapter 17 also opens *One thing moves on this axis*, pointing back across the chapter break.

---

## C. Within chapters, between sections

- **C1. The orientations chapter has no section headings** across 2,020 words and about fourteen subjects. The
  competences are given, then noticing, then detachment and denial, then the competences again, then what each
  orientation does when something goes wrong, what each cannot easily bear, being caught, stress, and noticing again in the
  last paragraph. The detachment paragraphs carry Part 3's account of panic and denial in compressed form.
- **C2. Chapter 15 tells how a fear comes to be buried in seven places,** and the formal statement, in *The four fates*,
  is the third of them: *The range of detachment* (the job example, the blindness loop, the fresh anxiety, the burial
  crossing the detached phase); *Disregarding, and not seeing at all* (*Take one fear at a time*); *The four fates* (the
  *Blocked* entry); *Burial is not a decision*; *The unease loop* (twice); *The four sketches* (the enthusiasm-side
  sketch); and the last paragraph of the chapter, *A burial is not one event*. Two sentences recur word for word
  between those sections: *At first the turning away feels like a choice.*, three times, and *The fresh anxiety is the
  fear of looking at the buried fear.*, twice.
- **C3. The leans chapter's last section repeats the opening of a Chapter 15 section.** The leans chapter's last section, *What
  the leans do with what a person notices*, is one paragraph, and its three middle sentences open Chapter 15's
  *Disregarding, and not seeing at all* word for word. The paragraph never says what its heading promises, what the leans
  do. **Corrected 10-30 after checking the history: the section is not to be cut.** It is `[A]`'s own siting (08-15, per
  the 09-02 architecture) and the short statement deliberately left behind on 09-02 when the full one moved, under his
  rule that a move may leave a minimal statement where it was. The 09-02 architecture specified it as *the three named,
  and the leans as what makes the difference*. The claim inventory records that its leans paragraph was cut on 09-12 for
  repeating Chapter 15 word for word, which is how it lost what its heading names. **The repair is to its content, with
  awareness of the other place:** the short statement says the three and what the leans do, in fewer words than the full
  one, rather than repeating the full one's first paragraph.
- **C4. Chapter 14's *The phases and their names*** defines the phases as a beginning, a middle and an end **after** the
  chapter's opening has already split each phase into two halves.
- **C5. Chapter 15's *The range of detachment*** repeats, word for word, the types chapter's sentences on motivation
  crossing to a detached realm and Chapter 14's sentences on a pain or a pleasure starting a process.
- **C6. Chapter 15's *The unease loop* is 1,879 words** and carries, besides the loop itself: the capacity to face buried
  fears, with the migraine story; the two pains and the way out; turning a matter over; the health axis; being less able
  to handle life than others are; two kinds of help; unease when idle, and distraction; three sources of lasting unease;
  and habitual fear. Several of these are the falling-and-rising chapter's subjects.
- **C7. Chapter 15's *What previous thoughts have laid down*** restates Chapter 14's *What a thought leaves*, and *laid
  down* is used throughout Chapters 14 and 15 before *mental deposits* is named in that last section.
- **C8. *Spoiled arrivals* in Chapter 16** is one paragraph with no link to the sections either side, or to the cycle
  chapter's *Backward*, where the spoiled arrivals are described (*worry without the accompanying sense that understanding
  will help*; *a brittle energy rather than any real optimism*).
- **C9. One thing is described three times with no link between the places: a person under stress looking like the
  orientation behind their own.** The cycle chapter's *Backward* (disintegration); Chapter 16's *Spoiled arrivals*;
  Chapter 17's *What falling takes from capacity*:

  > Under stress, a person looks more like the orientation behind their own.

  None of the three names the others' word for it.
- **C10. Chapter 17's falling material is interrupted and then resumed.** The order is: *What actually descends*, *Leaving
  fears unweighed*, *The second way down*, *What falling takes from capacity*, *Why this does not take everyone to the
  bottom* (which also says where a climb through buried material stops and why such a climb is possible), *What reaches
  someone who cannot see their own condition* (the intervener), then **back to falling** in *Two things that cannot
  happen* and *The last stretch*, then *Rising*. **History, checked 10-30:** the 09-02 architecture (a `[C]` call, not a
  ruling) placed the two things that cannot happen after both brakes, because the derivation that the levels do not wrap
  was to close the falling half. That derivation now stands in the health-axis chapter, so the reason no longer holds.
  *Where a climb through buried material stops*, inside *Why this does not take everyone to the bottom*, is **not**
  misplaced: it is the other half of why people gather in the middle.
- **C11. Chapter 17's *The second way down* defines discomfort blocking again,** in sentences taken from Chapter 15's *The
  four fates*, with *This is discomfort blocking.* as though it were new.
- **C12. The figure chapter's *As the grip loosens*** gives the six mixed types and not the Three, the Six or the Nine,
  and says nothing about why.
- **C13. The relationships chapter uses the mirror pair before defining it.** The sketch of Elena and Marcus says *They
  share the mirror pair's blind spot too*; the section that defines a mirror pair comes after the sketches.

---

## D. Paragraph to paragraph

- **D1. The Eight's section does not end on its closing line.** Every type section ends *Whatever a … condition, the pair
  still gives them what it gives: …*. In the Eight's, one more paragraph follows it, *The gap between impact and intent has
  the same source.*
- **D2. *Examining* is used in the One's section before the book has introduced it:**

  > A One is cautious in the psychic realm, and the examining is done where a person is cautious.

  The examining is introduced in Chapter 14's shoelace example.
- **D3. Chapter 13 gives the self-as-a-piece-in-a-game twice, under two names.** *The imaginary self* ends:

  > The game is also why the self seems so real: the opponent plays a piece too, and for most of a life the game never stops.

  and the chapter's last paragraph:

  > It seems solid because it was made for a contest in which the other side is holding a position too, and because for most of a life the contest never stops.

- **D4. Chapter 13's *What self-reference does* opens on a *This* that points two sections back,** and its preview names
  none of what follows:

  > This is also the property that divides the two realms most sharply, and it is what the earlier account of them was describing.

  > Several things stated separately in earlier chapters follow from this one property.

- **D5. In the Part 3 opening, the arhat paragraph** sits between the paragraph on the judgment the word *fixation*
  carries and the paragraph that says what Part 3 takes up, and joins neither.
- **D6. In the relationships chapter:**

  > This describes a small number of people, and in any real relationship it is one factor among many.

  A reader cannot tell what *This* is, or whether the observation is meant to be rare or to have been seen in few people.
- **D7. Paragraphs that open by pointing back at the one before.** Ten of Chapter 13's 27 paragraphs open on a word that
  points back (*That*, *This*, *It*, *Which*, *The same*); fourteen of Chapter 17's 98 do. Elsewhere it is rare.
- **D8. Already on the later style job's list** (handoff §4), and confirmed: the orphan *It also says what undoing one
  would involve*; the forward reference *is taken up in Part 3*; the heading *The second way down, which is not
  blindness*.

---

## E. Openings that preview what the reader will see

**E1. The obstacle, in one piece.** The style guide's section 1 is *Write about the world, not about the book*: *A sentence
that describes the book's own arrangement, or tells the reader what to do with a passage, has stopped doing that*, with
*No forward chapter references in running prose*. A preview that says what a chapter will show is a sentence about the
book's arrangement. Section 7's test (*delete the sentence and see whether the chapter loses anything*) also fails every
preview, since everything a preview says is said again later. The licence that does cover a preview is `[A]`'s own: a thing
may be said **minimally first and fully later**. The Introduction note of 10-07 already allows claims about the book in the
Introduction, *since the book has not started*.

**E2. The book already has both forms.** About the book:

> This chapter gives each type's story in its own voice, followed by what that type usually cannot see about itself.

and the Part 3 opening quoted at A2. About the world:

> A position is a fact about two types. What it is like from inside is a different matter — who looks up to whom, where the irritation comes from, and what each person has that the other needs.

and the figure chapter's *Both shapes fall out of the grid.*

**E3. `[C]` recommends the second form for chapter and section openings:** a short opening that states, about people and
in the order the sections take them, the few things the chapter establishes, without saying *this chapter*. It keeps
section 1 whole, it is covered by *minimally first and fully later*, and it gives a reader the claims to hold rather than a
list of contents. A reader who can hold little is better served by the claims than by the map. The Part openings and the
Introduction are the places where the first form (about the book) is most defensible, as the 10-07 note already says of
the Introduction. **This is `[A]`'s decision, since either form changes how a standing rule is read.**

**E4. Where openings are missing or would do the most:** Parts 1 and 2 (none); Chapters 13, 15 and 17 (none); Chapter 4
(no sections, fourteen subjects); Chapter 16 (its opening says the axis is new); Part 3 (its three subjects do not match its
chapters, A2).

---

## F. A glossary

**F1. The register is not a glossary.** It says which word names which thing and why, with dates and `[A]`'s words, for
sessions. A reader's glossary says what each word means in the book.

**F2. Several of the register's rulings are already a glossary in pieces,** written as rules for restating a term in the
running text: *caught* is restated at its first use after a long gap; *of the detached phase* is attached at the first
mention in each section; the fear of looking and *without being aware of the reaction* are restated where the last mention
is far back; *a detached realm* takes the long form at distant sites. A glossary would let the reader look a term up, and
would take some of that load off the prose.

**F3. `[C]` recommends building one glossary first, as a working file, from the book's own defining sentences,** each entry
being the term, the sentence that defines it copied exactly from the book, and the chapter (by title) where it stands. Copied
sentences can be checked against each new master by `quotecheck.py`, so the glossary cannot drift from the book. **Where it
then shows in the book is a second decision:** a glossary at the back; or, for each chapter, a short list after its
opening of the words the chapter relies on that were defined in an earlier chapter — the words a reader is most likely to
have lost; or both. New words are defined in each chapter's own text, as the style guide's section 10 requires.

**F4. Building it will surface vocabulary faults, and already has.** Words the register has not ruled on, each a second name
for something that has one:

- *settled* (ruled: worked through or given up on) and *disposed of* name the same two fates, two paragraphs apart in *The
  four fates*; *processed* (Chapter 14), *handled* (Chapter 17) and *dealt with* (Chapters 15 and 17) are near them, and
  *handled* in *how often a fear gets handled instead of being blocked* could include ignoring.
- *mixed* (the grid chapter) and *non-aligned* (the relationships chapter).
- *game* and *contest* (Chapter 13, D3).
- *the pain of staying* (nineteen uses) and *the pain of life not working* (three uses, all in *Rising*); and on the other
  side *the pain of facing*, *the pain of doing what the way out requires*, *facing what they avoid*, *the fear of facing
  what has been buried*.
- *fixation* is defined three times: in Chapter 1 (*settles and hardens into habit*, without the word), at the Part 3
  opening, and again in Chapter 14's *Where a fixation acts*.
- Terms used before their definition: *the health axis* (B6), *fallen* (Chapter 14), *examining* (D2), *mirror pair*
  (C13), *unattended* (used in *The range of detachment*, defined in *The four fates*), *the blindness loop* (named in *The
  range of detachment* a paragraph after it is described without the name), *laid down* before *mental deposits* (C7).

---

## G. Noticed in passing

- **The register still carries the retired author's-voice list.** Section 7's entry *The author's voice — RULED 09-15* lists
  *My proposal is that*, *I propose that*, *What I call*, *I suspect*, *I assume that*, *What I have seen is* as forms to
  keep. The style guide's letter `l` carries `[A]`'s 10-28 ruling against the author referring to himself, and the handoff
  §3 retires the list. The register's next letter owes the correction.
- `refcount.py` on this master, per `FINDINGS-job97-20261029.md`: 566 sentences carry two or more referring words. Known;
  the later style job's.

---

## Rulings in this session

*(Filled in as `[A]` answers. Each with his words, verbatim.)*

*[A]'s words below are set as indented verbatim blocks, not blockquotes, so that the set-wide quote sweep, which excludes
the record, does not read them as quotations of the book. They are verbatim, and they are in the record's hundred-and-first
append.*

**2026-10-30 08:05, how Part 3 relates to Parts 1 and 2.** Asked whether how much a person notices is the idea that holds
Part 3 to the first two parts:

    part 3 developed without planning. how it is related to the first two parts:

    * it examines the relationship between the characteristics of the fixations (and therefore the enneatypes) and the orientation phases and styles of thought
    * it explores what is behind riso's levels of development. the connection would be better if riso's levels for each enneatype matrix were included.

`[C]`'s reading of what it settles: the Part 3 opening names these two subjects, not `[C]`'s single idea of noticing.
*Styles of thought* is his phrase in conversation; the book's own wording for it is in *Where a fixation acts* (which phase
a fixation gives most attention to) and *The four sketches*. A drafting session puts it in the book's words.

**2026-10-30 14:43 and 14:44, asked for the order.** `[C]` had recommended keeping *Where the Inner World Came From* first in
Part 3 and asked whether he agreed. He did not answer that, and asked instead:

    show the proposed order of chapters and section titles.

    also mark those where the order is changed from the current book.

`[C]`'s answer is `PROPOSED-ORDER-job99-20261030.md`. Before writing it, `[C]` checked each move against the record and the
09-02 architecture, and dropped two moves it had first planned: cutting the leans chapter's last section (it is `[A]`'s
siting, see C3) and putting *One thought, step by step* before *Where a fear meets its fate* (the present order defines the
four fates before the example names them). One change goes against a placement of `[A]`'s, and is put to him alone: the four
fates and everything about blocking and unease leave *The Fixations Themselves* for a chapter of their own, placed before it.

**2026-10-30 15:03, the new chapter — RULED.** Asked: *In September you approved keeping the four fates in The Fixations
Themselves. This order moves them into a chapter of their own, along with everything about blocking, burial and unease, just
before The Fixations Themselves. … Do you agree to the new chapter?*

    yes

**What the yes covers:** the chapter *What Becomes of a Fear*, placed between *Underneath the Cycle* and *The Fixations
Themselves*, holding *Disregarding, and not seeing at all*, *The four fates*, *How a fear comes to be buried*, *Burial is not
a decision*, *The blindness loop*, *The unease loop* and *Lasting unease*, in that order. It supersedes his 09-02 placement of
the four fates at the beginning of *The Fixations Themselves* and his approval during `job74-drafting-20260919` that the
chapter keeps the four fates; the mental deposits stay in *The Fixations Themselves*, as that approval had it.
**What it does not cover:** the other changes in `PROPOSED-ORDER-job99-20261030.md`. Those are `[C]`'s, shown to him in full
on 10-30, in the answer to his 14:44 message, with the marks; he was asked about the new chapter only. A drafting session shows him each one in place
before applying it. *Where the Inner World Came From* stays first in Part 3; `[C]` recommended it, it is no change, and he
did not answer that question.

**2026-10-30 15:04, the form of the openings — RULED.** Shown the type chapter's overview (*This chapter gives each type's
story in its own voice, followed by what that type usually cannot see about itself.*) as the kind that talks about the book,
and Relational Dynamics' opening (*A position is a fact about two types. What it is like from inside is a different matter —
who looks up to whom, where the irritation comes from, and what each person has that the other needs.*) as the kind that
names what is coming as things about people. Asked whether every chapter and section opening should be written the second
way, naming the subjects in the order the chapter takes them, with the Introduction still free to speak about the book as
his 10-07 note allows:

    yes

**What it settles:** the style guide's section 1 stands unchanged and governs the openings; an opening previews by naming the
subjects, about people and in the chapter's order, and never says *this chapter* or refers to the book's arrangement. The
Introduction is the one place a sentence about the book is allowed, as `NOTE-introduction-recognition-20261007.md` already
says. The style guide's next letter should carry this as a caught instance under section 1, with his word.

**2026-10-30 15:09, where the glossary appears — RULED; and his proposal for the chapter glossaries.** Asked whether the
glossary should appear in two places — the whole glossary at the back, and after each chapter's opening a short list of the
words from earlier chapters that the chapter relies on most, each with its definition:

    yes to placement. i propose that the glossaries in each chapter could be written in complete sentences which connect together in a readable way. is that feasable?

**What is ruled:** both places. **What he proposes:** the glossary in each chapter is written as complete sentences that
connect into readable prose, not as a list. `[C]` answered that it is feasible and showed a sample built for *What Becomes of
a Fear*, every sentence the book's own defining sentence or shortened from it, run through `refcount.py` (0 sentences with
two or more referring words) and checked against the master. `[C]` decided, and reported, that the glossary at the back
stays a list, since it is for looking a word up. His answer on the sample is pending.

**2026-10-30 15:14, the chapter glossaries as connected sentences — RULED; and two requirements of his.** Shown the sample
for *What Becomes of a Fear* and asked whether it was the kind of thing he meant:

    yes. is it free of dependencies on things defined later? these definition sections of each chapter need a title saying what they are.

**Ruled:** each chapter's glossary is written as complete sentences that connect into readable prose. **His two
requirements:** (1) it may depend on nothing defined later; (2) each such section has a title saying what it is.

**`[C]`'s check of the sample against the new order:** nine of its eleven sentences rest on earlier chapters. Two did not:
*A person leaning toward caution gives the caution end more attention.* and *A person leaning toward enthusiasm gives most
of their attention to the enthusiasm end and little to the caution end.* Their only sources are master lines 1271 (in the
burial paragraphs moving into *What Becomes of a Fear* itself) and 1453 (*Which fixation handles a fear*, which comes after
it). They were replaced by sentences from earlier chapters: *A detached person leaning toward caution is at home in the
caution end.* and *A detached person leaning toward enthusiasm is at home in the enthusiasm end.* (from the section on the
two ends in *Underneath the Cycle*, master line 1115, with *written Z−* and *written Z+* dropped), and *The more attention a
person gives the caution end, the more likely a fear is to be noticed and met there.* (the orientations chapter, line 391).
The revised sample passes `refcount.py`: 12 sentences, 0 with two or more referring words. **Method for every chapter:** the
glossary working file records the section each defining sentence stands in, so a chapter's section may use an entry only
when that section comes earlier in the new order; the check is a lookup.

**2026-10-30 15:18, what the chapter glossaries hold — his correction.** `[C]` had read *glossaries in each chapter* as a
reminder of words from earlier chapters, and recommended the title *Words from earlier chapters*. `[A]`:

    i was proposing definitions for words introduced and defined and used in the rest of the same chapter.

**So each chapter's definition section, after its opening, defines the words that chapter itself introduces and goes on to
use**, in connected sentences. `[C]`'s recap of earlier words is withdrawn; the glossary at the back is where a reader looks
up a word from an earlier chapter. **Dependency rule, restated for his design:** each sentence of a chapter's section may use
only words defined in earlier chapters or earlier in the same section. Each word is then defined twice, briefly in the
section and in full where the chapter explains it, which his 09-02 rule allows (a short statement first, the full one later,
with awareness of the other place); copying the section's sentences from the chapter's own defining sentences keeps the two
in agreement. Title: `[C]` recommends *New words in this chapter*; put to him.

**2026-10-30 15:28, the title — RULED; and his idea for the order of definitions.** Asked whether the title is *New words in
this chapter*:

    yes to title. one thought on the arrangement of definitions: if they can be arranged as a tree starting with words dependent only on earlier chapters or independent, the next level dependent on the first, then define all first level words before all second level words etc. with the exception that less words can be moved down. i don't think that's a clean specification - maybe you can do something with it. the idea is that the reader will remember the earlier words more easily and will not need to remember the later words to understand other words.

**Ruled:** the title *New words in this chapter*. **His idea**, asked to be made clean: order the definitions so the words
others depend on come first, where they are remembered best, and the words nothing depends on come later, where forgetting
one costs nothing. `[C]`'s clean form, put to him: (1) a definition uses only words from earlier chapters and words already
defined in the section; (2) the more of the section's definitions use a word, directly or through another word, the earlier
it comes, and a word no other definition uses comes last; ties keep the chapter's order of use. Rule 2 cannot break rule 1:
if B's definition uses A, then A is used by B and by everything that uses B, so A always counts more and comes first. His
"less words can be moved down" is read as: a word fewer definitions use may come later than its level allows. For readable
prose, the same two rules are applied to short paragraphs: each paragraph is one small tree on one subject, opening with the
word the rest of it uses, and a paragraph whose words later paragraphs use comes first.

**2026-10-30 15:33, the ordering rules — ACCEPTED; and whether they apply to sections.** Shown the two rules (*nothing before
its definition*; *most-used first*, with ties kept in the chapter's order of use) and their application to short paragraphs,
each a small tree on one subject:

    sounds good. it seems to me that the same idea would apply to the sections of the main content of the chapter. does it? should it?

**Accepted:** the two rules, and the paragraph form, for the *New words in this chapter* sections. **`[C]`'s answer on
sections, put to him:** *nothing before its definition* should hold for sections without exception, with *definition* read as
*explanation*: a section never relies on an idea a later section explains. The proposed order was built mostly on it, so it
largely holds; a few single words are still used early (*fallen* in *Where a fear meets its fate*; *the health axis* in the
unease loop, placed by `[A]` on 10-17; *examining* in the One's section), and the definition sections or small rewordings take
care of most. *Most-used first* should apply to sections only as a tie-breaker: sections carry explanation, which is easier to
follow in the order things happen (a thought from arising to ending, a fall before a climb) or the order readers expect (the
types One to Nine), and the words, where the memory argument bites, are already put first by the definition section. Where it
can apply it mostly already does: the phases first in *Underneath the Cycle*, the four fates straight after their short
version in *What Becomes of a Fear*, the nine rungs first in *The Health Axis*, the fall fear by fear first in *Falling and
Rising*. For words the check is a lookup; for ideas it needs a reading, chapter by chapter.

**2026-10-30 15:36, the rules for sections — RULED; and his question about the reverse.** Asked whether *nothing before its
explanation* applies to sections always, and *most-used first* only where two sections do not depend on each other and their
order follows no sequence:

    yes. what about the reverse - the definitions in the same order as the main content?

**Ruled for sections:** nothing before its explanation, always; most-used first only to settle ties. **His question:**
whether the *New words in this chapter* section should follow the chapter's own order instead of the tree order.

**`[C]`'s answer, put to him: yes, and better than the tree order,** on the condition that the chapter itself obeys *nothing
before its explanation*. Then the chapter's order of explanation is already dependency-safe, so the definitions can follow it
and still pass his test; the reader meets the words in the same order twice, so the section previews the chapter and a word
is easy to find again; and one rule then governs both the sections and the definitions. **What it gives up:** words nothing
else uses no longer drop to the end. In *What Becomes of a Fear*, *regret* and *settled* would come before *bodily tension*,
which the unease material relies on. **The condition matters:** the cycle chapter says *A passage is the move from one phase
to the next.* before it says what a phase is (*The three phases are the same three places on the cycle as the three
orientations.*). Copying the chapter's order would copy that fault, so the chapter is fixed first and the definitions follow.

**2026-10-30 15:37, definitions in the chapter's order — RULED.** Asked whether the *New words in this chapter* section
follows the chapter's own order, on the condition that the chapter first obeys *nothing before its explanation*:

    yes.

**What it settles, with the rulings of 15:28 to 15:36:** each chapter's *New words in this chapter* section defines, in
connected sentences, the words the chapter introduces and goes on to use; in the order the chapter explains them; each
sentence taken from the chapter's own defining sentence or shortened from it; using only words from earlier chapters or
defined earlier in the section; in short paragraphs by subject. *Most-used first* survives only to settle ties, for
definitions and sections alike. **The chapter is fixed first**, wherever it uses a word or idea before explaining it; the
cycle chapter's *A passage is the move from one phase to the next.*, before it says what a phase is, is the instance shown.
This supersedes the tree order `[A]` proposed at 15:28 and accepted at 15:33.

### Words with two names (from finding F4), put one at a time

**1. *settled* and *disposed of*.** `disposed of` was the book's word in the 08-31 sorting of the four fates (*whether it is
disposed of*); `settled` was ruled on 10-05 for a fear that is worked through or given up on. Both now name the same two
fates. Measured on the master: *disposed of* 18 times, 17 meaning worked through or given up on, and one (*a moment of
clarity that gets disposed of*, in the falling-and-rising chapter) meaning turned away from; *processed* once and *dealt with*
twice in the same sense as *settled* (the coffee example's processing and ignoring, the enthusiastic sketch, the rate of
falling). *dealt with or released* in the Seven's portrait and *What arrives unprocessed* in the rate of falling are other
senses and stay. `[C]` recommends *settled* at all twenty sites in that sense; the moment of clarity gets wording of its own.
**Put to `[A]`.**

**2026-10-30 16:42, *settled* — RULED.** Asked whether *settled* replaces *disposed of*, *processed* and *dealt with* at the
twenty sites where they mean a fear worked through or given up on, with the moment of clarity given wording of its own:

    yes

**Applied by a drafting session at:** master lines 387, 1271, 1319 (three uses), 1343 (six uses), 1345, 1387, 1453 (two), 1459
(*disposed of*), 1711 (*disposing of*); 1225 (*processed*); 1459 and 1657 (*dealt with*). **Not changed:** 609 (the Seven's
*dealt with or released*) and 1659 (*What arrives unprocessed*), which are other senses; 1747 (*a moment of clarity that gets
disposed of*), which means turned away from and gets wording of its own. The register's next letter carries the entry with
his word; `wordcheck.py` gains a pattern for *disposed of* that fires on this master and on none of the next.

### A site missed by the 09-06 ruling on the aligned types — no new ruling needed

Found while measuring *non-aligned*. *Aligned and non-aligned*, in Relational Dynamics, still gives the reason `[A]` ruled
wrong on 09-06 (record, `Job49`'s second append, *RULED 2026-09-06 by `[A]` — the aligned types, and why the drafted reason
is wrong*): *Two aligned types together have unified approaches to both realms, and neither has reason to notice that the
realms are separate.* and *They may or may not take both realms to be real, and may or may not be comfortable with the reality
the other sees, but they have direct evidence that the realms are distinct, which puts them closer to recognizing it than an
aligned type comes naturally.* `[A]`'s words that day: *i see that they seem to miss something the mixed types intuitively
know but i can't see that it is understanding the difference between the realm.* What survives, ruled (*i think that's
true*): a mixed type has watched themselves notice in two different ways and an aligned type never has, so an aligned type's
orientation is harder to see as an orientation. **The 09-06 repair reached four sites** — the grid chapter and the Three's,
Six's and Nine's sketches — **and missed this section**, a site where the doctrine is used rather than discussed. Sited for
the drafting session under that ruling.

**2. *mixed* and *non-aligned*.** The grid chapter defines *mixed* (*These are the mixed types.*); the book uses it 14 times,
and `[A]` uses it himself (09-06). *Aligned and non-aligned* uses *non-aligned* three times, its heading included. `[C]`
recommends *mixed* everywhere, the heading becoming *Aligned and mixed*. **Put to `[A]`.**

**2026-10-30 16:44, *mixed* — RULED.** Asked whether *mixed* replaces *non-aligned* everywhere, the heading becoming *Aligned
and mixed*:

    yes

**Applied by a drafting session at:** master lines 858 (heading), 862 and 864. The register's next letter carries the entry.
The rewrite of that section's two paragraphs under the 09-06 ruling (above) is the same session's work and can be done in
one pass.

**3. *game* and *contest*, and the self's realness said twice.** The inner-world chapter says twice why the self seems so
real. *The imaginary self* ends: *The game is also why the self seems so real: the opponent plays a piece too, and for most
of a life the game never stops.* The chapter's last paragraph ends: *It seems solid because it was made for a contest in which
the other side is holding a position too, and because for most of a life the contest never stops.* History: the *contest*
paragraph is in `BOOK2-20260914.md`; the *game* paragraph was added on 09-15 by `job71-drafting-20260915` at `[A]`'s request
(*i think i also say that the idea of self is used like is used like a competitor in a game of strategy. maybe that's
elsewhere.*), with his addition *"Taking the self to be fixed as a piece in the competition game"?* `[C]` then reported the
idea as being in book 1 only, and missed that book 2's last paragraph already carried it. `[C]` recommends keeping the *game*
paragraph and cutting the *contest* paragraph, so the chapter ends on *The self is a by-product of something working exactly
as it should.* Nothing after it leans on the paragraph: the next thing is the chapter break. **Put to `[A]`.**

**2026-10-30 16:46, *game* — RULED.** Asked whether the *game* paragraph stays and the *contest* paragraph, the chapter's
last, is cut:

    yes

**Applied by a drafting session:** cut master line 1103 whole (*That is also why it feels as real as it does. … for most of a
life the contest never stops.*). *Where the Inner World Came From* then ends on *The self is a by-product of something working
exactly as it should.* `contest` leaves the book with it.

**4. *the pain of staying* and *the pain of life not working*.** *The pain of staying* is used 19 times. *Rising* uses *the
pain of life not working* three times (master lines 1813, twice, and 1815). `[A]`'s own phrase (record line 6298: *the way up
happens when the pain of life not working exceeds the pain of facing blindness*; again in his 10-16 relay). Same thing:
*All of the pain of life not working counts, whether or not the person connects the failures to fears left unfaced.* (1813)
against *All of the felt pain counts toward the pain of staying, whether or not the person connects the pain to their own
condition.* (1757). `[C]` recommends *the pain of staying* at the three sites. **Put to `[A]`.** *The facing side of the
comparison is held back as a separate question:* line 1813's *the fear of facing what has been buried* against line 1743's
*the pain of facing* may carry `[A]`'s 10-16 point that, with buried material, *the only thing available to consciousness is
fear of pain*, so it is not a plain second name.

**2026-10-30 17:08, *the pain of life not working* — `[A]` declines the merge.** Asked whether *the pain of staying* replaces
*the pain of life not working* at its three sites in *Rising*:

    "the pain of life not working" is more specific than "the pain of life". life is used in a different sense. the first refers to the practical details of life. the second refers to pain in general.

**`[C]`'s recommendation is withdrawn. Both phrases stay, as two things:** *the pain of life not working* is the pain from the
practical details of life not working; *the pain of staying* counts all the felt pain (master line 1757, *All of the felt pain
counts toward the pain of staying*, under his 10-17 ruling). For the glossary, the first is defined in his words above.

**4a. The one sentence where the two meet — put to `[A]`.** Master line 1813: *What motivates a person to take up a skill for
handling fear is the same comparison that decides a fear's fate in the detached phase: the pain of life not working against
the fear of facing what has been buried.* Everywhere else the first side of that comparison is *the pain of staying*, and all
the felt pain counts (the unease loop, line 1405; the routing in *Why this does not take everyone to the bottom*, lines
1725 to 1743). Here, calling it *the same comparison* while naming only the practical part narrows it. `[C]` asks whether this
one sentence should say *the pain of staying*, leaving *the pain of life not working* at 1813's next sentence and at 1815,
where the practical failures are meant. `[A]`'s 10-16 relay used *the comparison of the pain of life not working*, so the
answer may go either way.

**2026-10-30 17:17, the sentence where the two pains meet — `[A]` keeps it, and says what it lacks.** Asked whether master
line 1813 should say *the pain of staying*:

    "the pain of life not working" here is again a specific kind of suffering. i see that it is mentioned here without being previously brought up. but is what the sentence intended. blindnesses cause a person to be unable to function in life. the person can see that others are able to function and might understand that there is something causing him to be unable to function and that the thing is his fears. then comes the comparison between his inability to function in life with the pain of facing fears.

**Settled:** line 1813 stays as written; *the pain of life not working* is what it intends. **The fault he names:** the phrase
is used there without being brought up before. **`[C]`'s reading, put to him:** what he describes has the book's ruled name,
*less able to handle life than others are* (register, `Job90` block; *Never write unable to handle life*), first described in
the unease material (master line 1421, *Blocked aversions can leave a person less able to handle life than others are. The
person perceives being less able as a threat.*), and again as the third source of stress (line 1701). So the phrase can be
brought up where being less able is first described: *the pain of life not working* is the suffering of being less able to
handle life than others are. Rising's sentence then uses a phrase the reader has met. *His word* blindnesses *is kept in his
words above; the book's ruled cause of being less able stays blocked aversions of either kind (10-28), and the quoted sentence
puts that cause in front of him.*

**2026-10-30 17:20, *the pain of life not working* — RULED, with more explanation owed.** Asked whether the phrase is brought
up where being less able to handle life than others are is first described, as the suffering of being less able:

    yes. your failure to understand means the reader might also fail to understand to more explanation should be added.

**Owed to a drafting session, from his words of 17:08, 17:17 and 17:20:**

- **Where being less able to handle life than others are is first described** (the unease material, master lines 1421 to
  1431; in the new order, *Lasting unease* in *What Becomes of a Fear*): bring up *the pain of life not working* as the
  suffering of being less able to handle life than others are — the practical details of life not working.
- **Say how it differs from the pain of staying**, since `[C]` read the two as one: the pain of staying counts all the felt
  pain; the pain of life not working is the specific suffering of not being able to function in practical life.
- **At Rising's sentence** (master line 1813), explain the sequence in his words of 17:17: blocked aversions leave a person
  unable to function as well as others in life; the person can see that others are able to function; the person might
  understand that something is causing it, and that the thing is his fears; then comes the comparison between the pain of
  life not working and the pain of facing his fears. *Might* stays: the 10-17 ruling has all the felt pain count whether or
  not the person makes the connection.
- **Its definition goes in the *New words in this chapter* section** of the chapter where it is brought up.

**5. The facing side of the same comparison — put to `[A]`.** Line 1813 says *the fear of facing what has been buried*; line
1743 says *The pain of facing does not fall along with the pain of staying.*; the register's 10-16 entry is *the pain of
facing*; and `[A]` said at 17:17 *the pain of facing fears*. `[C]` recommends *the pain of facing* at 1813. His 10-16 point,
that with buried material only the fear of the pain is available, stays in the next sentence: *a person reacts to a buried
pain as if facing it would be unbearable, without being aware of the reaction.*

**2026-10-30 17:26, the facing side — his yes, his question, and `[C]`'s correction.** Asked whether line 1813 should say *the
pain of facing*:

    yes. does it need to be explained that the pain is a shorthand for the fear in the sense that failure causes the pain that eventually forces facing the fear - to the person it seems like facing the fear is causing the pain even though the really the cause and effect are the reverse.

**`[C]`'s correction, made to him at once:** `[C]` had told him *The rest of the book says "the pain of facing"*. Measured, the
book says it once, at line 1743 (*The pain of facing does not fall along with the pain of staying.*). Elsewhere the facing side
is *the person reacts as if facing … would be unbearable* (lines 1627, 1727, 1743, 1813), *the pain the person might face*
(1727) and *facing what they avoid* (1725); *the pain of doing what the way out requires* (1405) is the unease loop's general
way out. The register already moved its wording from *the pain of facing* to *reacts as if facing would be unbearable* on
10-26. So the consistency reason `[C]` gave was weaker than stated.

**`[C]`'s answer to his question, put to him:** if the book calls the facing side a pain, yes, it needs explaining — a reader
takes *the pain of facing* as a real pain that facing causes, as `[C]` did, and the toothache example (*the pain of pulling*)
invites that reading. **Simpler: call it what it is, *the fear of facing*** — his own 10-16 words were *the fear of pain of
facing buried material*. That reverses the recommendation he said yes to at 17:26: line 1813 keeps *the fear of facing what
has been buried*, and line 1743 becomes *The fear of facing does not fall along with the pain of staying.* **His
cause-and-effect point is new to the book** and goes in once, where the comparison is set out (*Why this does not take everyone
to the bottom*, the paragraphs on the two pains): the pain comes from life not working and in the end forces the facing, but
to the person it seems that facing is what hurts. `[C]` checked it against the fear of looking: the fear of looking is a fear
that arrives when buried material comes near, and his point is about the pain of failure, so the two do not collide.

**2026-10-30 18:11, what the fear of facing is a fear of — his refinement, and the fear–pain loop.** Answering whether *the
fear of facing* goes in at the two sites and his cause-and-effect point goes in where the comparison is set out:

    “the fear of pain of facing buried material” should be “the fear of pain associated with facing buried material” or “the fear of pain associated with the fear that arises when facing buried material”. maybe rewording in all the occurrences would be helpful. it seems there is a close association between fear and pain. a person normally fears pain. pain causes fear. but fear is normally painful. fear causes pain. another loop. people can train themselves not to be afraid of pain and not to react to fear.

**Not yet a ruling on the name;** he refines what is feared rather than answering yes or no. **`[C]`'s write-up, put to him as
claims, not wording:**

- What a person fears in facing buried material is pain: the pain of the fear that arises when buried material comes near.
  `[C]` identifies that fear with the book's *fear of looking* (register, `Job88` block) and asks him to confirm the identity.
- Every place the book speaks of the facing side is reworded to say what is feared: four paragraphs, master lines 1627, 1727,
  1743 and 1813 (*as if facing … would be unbearable*, *the pain the person might face*, *The pain of facing does not fall*,
  *the fear of facing what has been buried*).
- His 17:26 point goes in once where the comparison is set out: the pain of life not working is what in the end forces the
  facing, though to the person it seems that facing is what hurts. *He has not said yes to it in so many words; the write-up
  shows it to him again.*
- **The loop is already in the book as the fear of the fear:** *Fear of fear produces more fear.* (the realms chapter, line
  343) and *Being afraid is itself uncomfortable, so the person now fears the fear as well.* (the job example, line 1255), and
  the *layers of fear of the fear* of the burial account. What is new is that pain is the link: fear is painful, and pain is
  feared. `[C]` recommends adding that where the fear of the fear is first explained, rather than naming a new loop — the
  register allows *loop* only for the blindness loop, a feedback loop and the unease loop.
- **Training out of it is already in the book:** the migraine story (*She learned to stop resisting the pain*, line 1395,
  moving to *Rising*) and trained abiding (*Trained abiding acts directly on the feeling of fear.*, line 1809).

**2026-10-30 18:18, fear and pain — RULED; and the fear that arises when facing.** Answering the write-up of 18:11 and the
question whether the fear that arises when facing buried material is the book's *fear of looking*:

    i think it worth describing the relationship between fear and pain. a loop isn't necessary - as you say, a loop is just another name for fear producing fear. but it's good to know that fear is usually associated with pain.

    "the fear of looking" might refer to a single instance. “the fear that arises when facing buried material” refers to a principle. otherwise the same.

**Ruled:** the book describes the relationship between fear and pain — fear is usually associated with pain: a person fears
pain, and fear is painful. No new loop is named; the relationship is said where the fear of the fear is first explained (the
realms chapter's *Fear of fear produces more fear.*, or the job example's *Being afraid is itself uncomfortable, so the
person now fears the fear as well.*; the drafting session chooses the first and shows him). **Ruled:** the fear that arises when
facing buried material and *the fear of looking* are the same thing; *the fear of looking* names an instance, *the fear that
arises when facing buried material* the principle. So the four paragraphs on the facing side (master lines 1627, 1727, 1743,
1813), which state the principle, are reworded to say that what is feared is the pain associated with the fear that arises
when facing buried material, per his 18:11 words; the sites that speak of one buried fear keep *the fear of looking*. This
supersedes `[C]`'s *the fear of facing* recommendation of 17:26.

**Still to confirm in one line:** his 17:26 cause-and-effect point, going in once where the comparison is set out. Shown
twice, not objected to, not said yes to.

**2026-10-30 18:22, the cause-and-effect point — RULED; the session stays open; and the openings' order.** Asked whether his
17:26 point goes in once where the comparison is set out:

    yes. not ready to close. i proposed summary paragraphs for each section saying what is to be covered and when possible why it's important. would that come before the glossary paragraph?

**Ruled:** his 17:26 point goes in once, where the comparison of the two pains is first set out (*Why this does not take
everyone to the bottom*): the pain of life not working is what in the end forces the facing, though to the person it seems
that facing is what hurts. **His addition to the openings:** each opening says what is to be covered and, when possible, why it
is important; every section gets one, as well as every chapter. **His question:** whether the chapter's opening comes before
the *New words in this chapter* section.

**`[C]`'s answer, put to him:** yes, the opening first, as his 15:09 placement already has it (after the opening). Conditions:
the opening names its subjects in plain words and words from earlier chapters, since the chapter's new words are defined only
after it; and why a subject matters is said about people, as the 15:04 ruling requires (the instance given: the detached
phase is the only place a person's depth can change, master line 1135). `[C]` recommends that a section of one or two
paragraphs gets no opening, since a summary would be as long as the section, and that its first sentence says what it covers
instead.

**2026-10-30 18:27, the openings — RULED; section summaries may be his; Riso's level names.** Asked whether the chapter's
opening comes before *New words in this chapter*, in plain words, with why it matters said about people, and with no opening
for a section of one or two paragraphs:

    yes. i might attempt section summaries later. still more to do. are riso's levels named? if not, we can paraphrase riso's general names that apply to all types.

**Ruled:** all of `[C]`'s 18:22 answer. **For the drafting session:** `[A]` may write the section summaries himself; ask him
before drafting any. Chapter openings and the *New words in this chapter* sections are drafting work as ruled. **His question,
answered from the master:** the levels are named. *The nine rungs* in the health-axis chapter gives Riso and Hudson's nine
general names (Liberation, Psychological capacity, Social value, Imbalance, Interpersonal control, Overcompensation,
Violation, Delusion and compulsion, Pathological destructiveness), each with a line in the book's own words on what holds at
it, and the chapter says *What is used is the shape of the scale and the names of its rungs.* So the paraphrase he proposes is
already there. What is absent is the per-type matrix, which waits on the Enneagram Institute (his 08-26 plan).

**2026-10-30 18:36, letters for both fixations and phases — his proposal.**

    a previous decision on how to differentiate orientations that name fixations and orientations that name phases. i still want to use the labels A, B and Z for both. that would require a way to differentiate fixation at A from the A phase. I propose leaving ABZ unlabeled in parts 1 and 2. in part 3 we would explain that the earlier orientations are really fixations and call them fxA, fxB and fxZ and call the phases phA, phB and phZ. and we would use fxZ-, fxZ+ and phZ-, phZ+. saying the cautious end of the detached phase is clumsy and these phrases occur many times. do you think that will work?

**History, from the record:** 09-01 ruling, letters never of a phase; 09-02 (`Job44`), *i never liked that ruling* and *i dislike
the loss of connection between the three states of fixations and the three places on the orientation arc*, with his proposal
then to qualify the letters as *fixation A* and *phase A*; 09-13 (`Job68`), his own statement of the convention, *The letters
A, B, Z are reserved for the person … A letter always means a person … The trap is the shared adjectives, not the letters.*

**Measured on the master:** *the detached phase* 68 times, *the cautious phase* 16, *the enthusiastic phase* 12; *the caution
end* 32 and *the enthusiasm end* 32, of which the long form *… of the detached phase* is 7 each; *Z−* 5 and *Z+* 3 (Ch 14 and
the sketches); no pair notation in Part 3.

**`[C]`'s answer, put to him:** it would work in that nothing would be ambiguous, and the letters would show the link he has
wanted since 09-02 between a person's lean and the end of the detached phase that person is at home in. `[C]` recommends
against it: *fx* and *ph* cannot be said aloud and every letter must be translated back into a word before the sentence
means anything, against his rule that the plainer form beats the shorter; it would reach about 150 phrases, not a few (the ends 64, the phases 82 outside the long forms, the fixation letters 8); and
the long phrase he finds clumsy occurs 14 times, the book already saying *the caution end* elsewhere. The link can be shown
once where the ends are defined, as *Underneath the Cycle* does (*A detached person leaning toward caution, written Z−, is at
home in the caution end.*). **Recommendation:** keep words for the phases; with each chapter now defining its new words at its
start, use the long form only at its first mention in each chapter (relaxing the 09-13 *first mention in each section* rule of
the register, §4). If he still wants letters, spell the qualifier as a word (*phase Z−*, *fixation Z+*), as he proposed on
09-02, rather than *phZ−*.

**2026-10-30 18:49, letters beside the words — his counter-proposal.**

    you're right. but i find "What separates people is how much attention a person gives the caution end. A person leaning toward caution gives the caution end more attention." hard to parse simply because of it's length. i'd would do better with "What separates people is how much attention a person gives the caution end (phase Z-). A person leaning toward caution (fixation Z-) gives the caution end of the detached phase more attention." just because i find Z- easier to parse. i also redundantly specified "of the detached phase" because i would otherwise need to stop and think it through each time. how about that?

**`[C]`'s answer, put to him as one rule:** every letter in Part 3 carries its word, *fixation* or *phase* (his 09-02 proposal,
*i think it safest to qualify the letters every time*); Parts 1 and 2 keep bare letters (his 18:36 words). Each time an end or a
lean of detachment is named in Part 3, the words come first and the letter follows in brackets: *the caution end (phase Z−)*,
*a person leaning toward caution (fixation Z−)*. The letter says which phase, so it does the work of *of the detached phase*,
and the long form is not needed where the letter is. His sentences under the rule: *What separates people is how much
attention a person gives the caution end (phase Z−). A person leaning toward caution (fixation Z−) gives the caution end (phase
Z−) more attention.* **A gain `[C]` notes:** *leaning toward caution* alone does not say which orientation leans (a detached
person leaning back, or an enthusiastic person leaning forward); *fixation Z−* does. **What it supersedes:** the 09-13
convention that a letter is never used of a phase, and with it *Underneath the Cycle*'s sentence at master line 1127 (*The
letters A, B and Z name only where a person stands … The letters are never used for a phase. So a letter always means a
person.*). Sites also reached: the sketches' *(A)*, *(B)*, *(Z−)*, *(Z+)* and Chapter 14's *written Z−* and *written Z+*.

**2026-10-30 18:54, letters for A and B too.** Answering the rule put to him at 18:49 (letters in brackets beside the words for
the ends and leans of detachment):

    i'd like to do the same for fixations and phases A and B.

**`[C]`'s rule, extended and put to him:** in Part 3, every time a phase or a fixation is named, the words come first and the
letter follows in brackets, with its word — *the enthusiastic phase (phase A)*, *the cautious phase (phase B)*, *the detached
phase (phase Z)* and its ends *(phase Z−)*, *(phase Z+)*; *an enthusiastic person (fixation A)*, *a cautious person (fixation
B)*, *a detached person (fixation Z)* and the leans *(fixation Z−)*, *(fixation Z+)*. `[C]` includes plain Z with A and B,
since the ends are already covered; he can say otherwise. Parts 1 and 2 keep bare letters. **Measured on Part 3 (22,264 w):**
about 220 sites — phases 81 outside the long end-forms, ends 54, leans 18, persons named by orientation 63, the sketches'
letters 5. **`[C]` recommends a pilot:** the drafting session applies the rule to one section first, shows it to him in place,
and does the rest only once he has seen how it reads. Example given: *Underneath the Cycle*'s *A detached person leaning
toward caution, written Z−, is at home in the caution end.* becomes *A detached person leaning toward caution (fixation Z−) is
at home in the caution end (phase Z−).*

**2026-10-30 19:05, letters in brackets for every phase and fixation in Part 3 — RULED.** Asked whether the rule of 18:54 holds,
with the pilot:

    yes.

**Ruled, superseding the 09-13 convention that a letter is never used of a phase:** in Part 3, every time a phase or a
fixation is named, the words come first and the letter follows in brackets with its word — *phase A*, *phase B*, *phase Z*,
*phase Z−*, *phase Z+*; *fixation A*, *fixation B*, *fixation Z*, *fixation Z−*, *fixation Z+*. Every letter in Part 3
carries its word. Parts 1 and 2 keep bare letters. Where the letter names the phase, *of the detached phase* is not needed.
**The drafting session applies it to one section first, shows him, and does the rest only after he has seen it.** Owed with
it: *Underneath the Cycle*'s sentence at master line 1127 is rewritten to the new rule; the style guide's section 8 bullet
(*A, B and Z name where a person stands … never used of a phase. A letter always means a person.*) and the register's §2 entry
(*A, B, Z … never a phase*) are amended in their next letters, with his words.
