#!/usr/bin/env python3
"""wordcheck.py - flag book 2 sentences that use words the word-rulings register governs.

Usage:  python3 wordcheck.py BOOK2-<date>.md [WORD-RULINGS-book2-<date>.md]

The patterns live in the register's ```patterns block, not here, so a new ruling
needs only a new line in the register. With no register named, the newest
WORD-RULINGS-book2-*.md beside this script is used.

The script flags; it does not decide. Read every hit. An ordinary-English use is
left as it is. Scopes: all | before-part3 | not-ch2.
"""
import glob, os, re, sys

def load_patterns(path):
    text = open(path, encoding="utf-8").read()
    m = re.search(r"```patterns\n(.*?)```", text, re.S)
    if not m:
        sys.exit(f"no ```patterns block in {path}")
    pats = []
    for line in m.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split(" | ")]
        if len(parts) != 4:
            sys.exit(f"bad pattern line: {line}")
        name, rx, scope, note = parts
        pats.append((name, re.compile(rx, re.I), scope, note))
    return pats

def sentences(par):
    return re.split(r"(?<=[.!?])\s+", par)

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    book = sys.argv[1]
    if len(sys.argv) > 2:
        reg = sys.argv[2]
    else:
        here = os.path.dirname(os.path.abspath(__file__))
        regs = sorted(glob.glob(os.path.join(here, "WORD-RULINGS-book2-*.md")))
        if not regs:
            sys.exit("no WORD-RULINGS-book2-*.md found; name one")
        reg = regs[-1]
    pats = load_patterns(reg)
    lines = open(book, encoding="utf-8").read().splitlines()

    part, chapter, in_toc = 0, "", False
    hits = {p[0]: [] for p in pats}
    for n, line in enumerate(lines, 1):
        if line.startswith("## "):
            in_toc = line.strip() == "## Table of Contents"
        if in_toc:
            continue
        if line.startswith("# Part "):
            part = int(re.match(r"# Part (\d+)", line).group(1))
            chapter = f"Part {part} opening"
        if line.startswith("## Chapter"):
            chapter = re.match(r"## (Chapter \d+)", line).group(1)
        for name, rx, scope, note in pats:
            if scope == "before-part3" and part >= 3:
                continue
            if scope == "not-ch2" and chapter == "Chapter 2":
                continue
            for s in sentences(line):
                for mm in rx.finditer(s):
                    hits[name].append((n, chapter, mm.group(0), s.strip()))
    print(f"register: {os.path.basename(reg)}\nbook:     {os.path.basename(book)}\n")
    total = 0
    for name, rx, scope, note in pats:
        h = hits[name]
        total += len(h)
        print(f"{name:14} {len(h):4}   {note}")
    print(f"\n{total} hit(s). Details:\n")
    for name, rx, scope, note in pats:
        for n, ch, word, s in hits[name]:
            short = s if len(s) <= 160 else s[:157] + "..."
            print(f"[{name}] L{n} {ch}: '{word}' — {short}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
