# PROCEDURAL CHANGES, 2026-08-25 — and how to undo each one

Cut by `Job17 apply book 1 repairs 8-25`. **This file exists so that every change made on 2026-08-25
can be reversed by someone who was not there.** Each entry gives what changed, why, where the
evidence is, and what to do if it turns out to be wrong.

**Read this before `SET-NOTE-from-job17-20260825.md`.** That file describes the set; this one
describes what was altered underneath it.

---

## 1. THE AUTHOR RECORD — three files existed at once, and two are wrong

**State before.** `AUTHOR-RECORD.md` in `[A]`'s directory was **4,641 words**, ending at 08-21, with
no `RECORD MARKER`. This was `Job15 tools session 8-24`'s *input*. Job 15 appended to it and its
*output* — 6,273 words, three markers — never reached `[A]`'s directory. Nobody noticed for a day.

**What went wrong on top of that.** `Job16 book 1 defects 8-24` was handed the 4,641-word file and
appended its 08-25 entry to it, producing a **5,921-word hybrid**: new material on an ancestor
missing 1,632 words, carrying no marker to say so.

**What job 17 did.**

1. Refused to append to either wrong copy. Detected by the count disagreeing with the live handoff's
   §1.1 figure, which is exactly what the marker rule was built to catch.
2. Located job 15's output — confirmed by its final marker reading *6,273 words*, matching §1.1
   exactly, and by the 4,641-word file being a **byte-identical prefix** of it at 26,333 bytes.
3. Replayed job 16's 08-25 entry onto it **byte-exact**, under a note saying it is replayed.
4. Appended job 17's own entry.
5. Made the rules edit in §2 below.

**State now: 8,589 words, five markers.** The last reads
*2026-08-25 · `Job17 apply book 1 repairs 8-25` (rules edit) · 8,589 words*.

**HOW TO CHECK IT IS THE RIGHT FILE.** `LC_ALL=C wc -w AUTHOR-RECORD.md` must give **8,589**, and the
last marker must say the same. Any other number means a wrong copy.

**DESTROY THESE IF FOUND:** the 4,641-word copy and the 5,921-word copy. Both look like records.
Neither is. As of the cut of this set, **`[A]`'s directory still held the 4,641-word copy** — it was
uploaded again during this session — so replacing it is an outstanding action, not a completed one.

**HOW TO UNDO.** Nothing was deleted. The 8,589-word file contains job 15's output unchanged from its
line 6 onward, so any earlier state can be recovered by truncation: job 15's output is the first
36,087 bytes plus the original line 3 (see §2).

---

## 2. THE RECORD'S TRAVEL RULE — replaced, and this is the change most worth watching

**Before**, at line 3 of `AUTHOR-RECORD.md`:

> **This file does not go into a drafting
> set.** It holds unruled theory, and a drafting session that
> reads it is disqualified from drafting. The sentence above is what the pre-assembly screen looks
> for.

**After**, ruled by `[A]` on 2026-08-25: the file **travels in every set and is not read by a text
session**. A doctrine session reads it and rules from it; a text session does not and declares which
it is before starting. The full replacement is at the top of the record.

**Why.** The old sentence did two jobs in one breath — it barred the file from *travelling* and
barred a drafting session from *reading* it. Only the second was ever wanted, and the first is what
let the record go stale: excluded from job 3 sets, it stopped moving and fell four days behind, and a
stale copy of an append-only file is short rather than wrong, so nothing internal shows it.

**What this breaks, stated plainly.** The record's body is append-only, but the **rules section is
revisable by `[A]`'s ruling**, as it also was on 2026-08-24 when job 15 added the marker rule and the
personal marks. So **job 15's output is NOT a byte-prefix of the current file** — the difference is
line 3 and nothing else. Job 17's two appends were pure prefix extensions; this edit was not, and it
carries its own marker saying so.

**HOW TO UNDO.** Restore the old paragraph at the top of the record, revert `setcheck.py` per §3, and
add a marker recording the reversal. Do not silently revert: the record must show that it moved and
moved back.

**RISK IF IT STAYS.** Every archived copy of the record in every old set folder still carries the OLD
line and will keep firing *drop* under the new screen. Old and new copies now behave differently
under the same tool. That is not a bug to fix by editing archives — it is a reason to trust the
marker count over the screen when the two disagree.

---

## 3. `setcheck.py` — a third screen verdict

**Before.** The screen had one verdict: *drop these from the set*, fired by the restriction string
`does not go into a drafting
set` or by a restricted name prefix.

**After.** A second string — the record's new opening sentence, quoted here with a line
break inside it so this file does not itself fire — sets a
separate verdict: **CARRY, DO NOT READ**, printed above the drop list and excluded from it. The drop
path is unchanged for everything else.

**Why.** Without this the record's new line leaves the screen silent about the file, which is worse
than a wrong warning. The tool now agrees with the record instead of contradicting it.

**This applies to any file that quotes the string.** An earlier draft of this note fired *carry, do
not read* because it reproduced the sentence exactly. It does not now, and that is why the sentence
is described rather than quoted above. **Anything discussing the screen must break the string or it
will be mistaken for a restricted file** — the same trap the handoff already falls into for the old
string.

**Known wart, not fixed.** `setcheck.py` fires *carry, do not read* **on itself**, because it
contains the string it greps for. It fired *drop* on itself before, so this is no worse, but the
checker still cannot recognise its own reflection. **A tools session should exempt the checker by
name.** Until then, expect the screen to name `setcheck.py` and ignore it.

**Filename unchanged**, per job 15's ruling that tools carry bare names across builds. So a set
verified against the older `setcheck.py` will show a manifest mismatch on that file alone. That is
the tool changing, not corruption.

**HOW TO UNDO.** Remove the `CARRY_NOREAD_STRING` constant, the `carry` list and its print block, and
restore the single-verdict `cmd_screen`. The change is confined to those places.

---

## 4. BOOK 1 AND BOOK 2 — eighteen repairs applied

**Book 1: `rev2-0814b.md` → `rev2-0814c.md`**, 56,260 → 56,237 words.
**Book 2: `BOOK2-20260818c.md` → `BOOK2-20260825.md`**, 17,431 → 17,455 words.
**`TODO.md`** L159 updated for two renamed Ch 15 sections.

Every substitution verified to match its `CURRENT` string **exactly once** before being made; nothing
was written until all matched. The full list is `REPAIRS-job16-book1-defects-20260825.md`.

**Deviations from the repair list**, all disclosed and recorded in
`DEFECTS-carried-forward-20260825.md` §5: one authored sentence in book 2 Ch 7, the word `smaller`
kept where the repair file's `CURRENT` quote had dropped it, and site 2's retained lead-in.

**HOW TO UNDO.** The predecessors are unmodified and were never overwritten — the old names still
name the old bytes. Revert by using them.

---

## 5. WHAT WAS NOT DONE, AND WHY

- **No new handoff.** `HANDOFF-20260824f.md` travels unchanged and is stale in two places: it names
  `rev2-0814b.md` in four §1.1 rows plus the rule putting book 1 in every drafting set, and it states
  the record at 6,273 words dated 08-24. **The second makes the correct record look stale.**
- **The five open defects were not repaired.** Each needs a ruling with the record open. See the
  defects file.
- **The doctrine settled in conversation on 08-25** — the store is the deposits; outcomes feed it;
  the fixation is both effect and, through what it has deposited, cause; `deposits` unmodified, with
  the Buddhist term once in Ch 13 — **is recorded in the author record and written into neither
  book.**

---

## 6. WHAT JOB 17 READ, since it bears on what its output is worth

Job 17 was assembled as an applying session. It then read: the author record (the stale copy first,
then job 15's output), `DEFECTS-carried-forward-20260825.md`, and — because they arrived as inline
uploads rather than as files on disk — `DOCTRINE-BRIEF-arcs-and-position-20260816.md`,
`NOTE-level-1-and-the-summit-20260821b.md`, `NOTE-small-arcs-and-the-step-20260815.md`,
`NOTE-overlap-and-truthfulness-20260815b.md`, and `TODO-additions-20260814.md`. **Five doctrine
files, not three** — the delivery mechanism, not a choice, and it is the reason a "carry but do not
read" instruction is weak in practice: a file handed over inline is read on arrival.

**It is therefore disqualified from drafting**, and drafted nothing. Applying a prepared list is not
drafting; the one place it wrote prose is recorded in the defects file §5. The remaining eight doctrine
files added to this set were copied and manifested **without being read**.
