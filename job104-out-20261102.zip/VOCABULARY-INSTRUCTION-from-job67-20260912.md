# VOCABULARY INSTRUCTION — `orientation` and `fixation`

**Cut by `Job67 doctrine 09122026`, 2026-09-12, after the closing zip had already been built.**
This file is **not** in `job67-out-20260912.zip` and is not in `MANIFEST-job68-20260912.md`. It
arrives beside the set. A session receiving it adds it to the directory and regenerates the
manifest with `setcheck.py manifest` rather than treating it as an unlisted extra.

**`[A]` has said the next drafting job has already started.** §6 below says what a session already
in flight should and should not do with this file.

**Ruled by `[A]` 2026-09-12. Not applied. No master has been touched.** Measurements are against
`BOOK2-20260912.md` (35,695 w, md5 `1065e37e`).

---

## 1. What `[A]` ruled, and why

**`fixation` carries a negative connotation and `orientation` does not.** `[A]` is keeping
Naranjo's claim that the enneatypes are fixations. What he does not want is the connotation
landing on a reader in Part 1, before the book has argued that being stuck is the problem.

**So the word `fixation` does not appear anywhere before Part 3.**

This **reverses the ruling of 2026-08-31**, which said to name `fixation` in Ch 1 and hold the
explanation until Ch 4. That ruling was argued on reading order — a reader meeting nine type
profiles before the orientations chapter. The new ruling is argued on connotation, and `[A]`
ruled the connotation reason the better one.

---

## 2. The scheme, stated once

**Three kinds of thing, three names, no overlap.**

- **An orientation** is one of the three: enthusiasm, caution, detachment. A class. **The word is
  unchanged in all three parts.** Nothing in this instruction touches it.
- **A fixation** is an orientation a person has hardened into, held in one realm. **The word is
  used from the start of Part 3 onward and nowhere earlier.**
- **A phase** is where one endeavor has got to. Unchanged, and governed by Ch 14.

**A fixation is an instance of an orientation.** The two words are not two names for one thing,
which is why `[A]`'s standing rule against a second name is not breached by the pair.

**In Parts 1 and 2 the hardened one has no name.** It is referred to by description, and Parts 1
and 2 already do this in about twenty places — *whatever orientation a person holds*, *the types
holding the same orientation in both realms*, *a person's orientation in a realm does not
ordinarily change*, *nobody holds an orientation purely*. Each of those names the class and says
the person holds one. **These sentences are already right and must not be changed.**

---

## 3. What to do at the 61 sites

`fixation` appears **61 times in Parts 1 and 2**: Ch 1 three, Ch 4 three, Ch 5 twenty-seven,
Ch 7 four, Ch 8 one, Ch 9 two, Ch 10 eighteen, Ch 11 four. Ch 2, Ch 3 and Ch 6 have none.

**Two constructions cover almost all of them. Both are already in use in the book.**

**(a) Put it on the realm.** The book already says a realm is called detached when the person is
detached in it. So:

- *less caught in the physical fixation* → **less caught in the physical realm**. This one formula
  covers roughly sixteen of Ch 5's twenty-seven and most of Ch 10's eighteen. **Decide it once and
  apply it everywhere; do not vary the wording between type sketches.**
- *both fixations pull, but not in the same direction* → **both realms pull, but not in the same
  direction**
- *neither of a Nine's fixations bends a Nine's view* → **neither of a Nine's realms bends their
  view**
- *holding one fixation in both realms* → **the same in both realms**, or **holding the same
  orientation in both realms**

**(b) Name the class and say the person holds one.** *The orientation a person holds in that
realm.* Use this where the sentence is about the thing held rather than about the realm.

**Do not coin a third word.** This is the fifth time the book has come out with no noun for
something — the helix, the Z object, the gradient, and what previous thoughts have laid down were
the first four, and the ruling in every case was to keep the doctrine in prose rather than invent
a name. Precedent: R6 retired `helix`.

---

## 4. The five sites that will not dissolve

**4.1 Ch 1, L~70.** *In each realm one of the three settles and hardens into habit, and a hardened
orientation is what this book calls a fixation.* This is the definition. **It moves to Part 3
whole.** What replaces it in Ch 1 says that in each realm one of the three settles and hardens
into habit, and stops there. **Ch 1 may still say that the hardening happens.** What it may not do
is name the result.

**4.2 Ch 5, L~413.** *This book calls a realm detached when the person's fixation in the realm is
detached.* This sentence licenses construction (a), so it has to survive without the word: the
realm is called detached when the person is detached in it.

**4.3 Ch 5, L~413.** *A pair is written as the physical fixation and then the psychic: Type 5 is
HB;SZ.* This is the sentence telling a reader what `HA;SB` means and it cannot be vague. Write the
pair as the physical realm and then the psychic, with the gloss the sentence already carries —
*cautious in the physical realm and detached in the psychic*.

**4.4 Ch 5, end.** *Each type's recognizable qualities are its two fixations at work.* Recast onto
the realms or onto the person.

**4.5 Ch 11, the lean material.** *The eight combinations are read the same way whichever
orientation a fixation sits at.* A lean is defined as a position between two orientations, so the
sentence must say what sits there. **Make the person sit there, not a thing** — a person rests at
a position between two orientations. This also discharges `[A]`'s standing rule against giving a
human property to something that is not a person.

---

## 5. Where the word is introduced

**At the opening of Part 3, before Ch 13, and this is settled rather than open.** `[A]` was asked
whether Ch 15 would do and the question is answered by the manuscript: **the part title is *Part 3
— The Depth of Fixation*.** The word is in the title, so nothing earlier in Part 3 can be the
introduction, and Ch 13's two uses stand as they are once the introduction is above them.

**What the introduction has to do, in this order:**

1. Give the definition moved out of Ch 1 — a fixation is an orientation a person has hardened into
   and holds in one realm.
2. Say that this is what Parts 1 and 2 have been describing throughout, so a reader turning back
   is not left to work it out.
3. State Naranjo's claim that the enneatypes are fixations, and say the book keeps it. **The book
   does not currently state this anywhere.**
4. Name the connotation rather than let it operate unremarked. The word carries a judgement, the
   judgement is meant, and Part 3 is where the book has earned it.

**Keep the register split the book already observes.** The claim is Naranjo's. What the book builds
on it is the book's.

---

## 6. If the drafting session is already in flight

**Do not start this instruction mid-job.** The vocabulary pass touches Parts 1 and 2 at 61 sites.
The twelve rows of `CLOSURES-SITED-job67-20260912.md` are in Part 3, nine of them in two sections
of Ch 15. **The two jobs barely overlap, so there is no reason to interleave them and one good
reason not to** — a session doing both has no clean way to report what it changed and why.

**Finish the closures and the repairs. Leave the vocabulary pass whole for the job after.**

**One site is shared and it belongs to the closures job, not this one.** Ch 15 is Part 3, so every
row that adds or rewrites Ch 15 prose uses `fixation` normally. Nothing in this file constrains
the closures work.

**The ordering constraint already recorded still holds and is unrelated to this file:**
`REPAIRS-job66-20260912.md` repair 2 site 3 must not be applied before rows 4 and 5 of the
closures, or withdrawn reasoning will be left standing inside a freshly rewritten sentence.

---

## 7. The check at the end

**Mechanical, and it is the reason to do the pass as one job.**

```
sed -n '63,994p' BOOK2-<date>.md | grep -c -i 'fixation'
```

**The count must be 0.** Adjust the line range to the new Part 1 and Part 2 bounds after the
rewrite; the current bounds are lines 63 to 994.

**A second count, which must not change.** `orientation` currently appears 58 times in Parts 1 and
2 and 106 times in the book. The pass should leave the class word roughly where it is. **A large
rise means the instance sites were renamed rather than recast**, which is the outcome this
instruction exists to prevent — it would put one thing under two names with a part boundary
between them.

**Read the two heaviest chapters whole afterwards.** Ch 5 and Ch 10 hold forty-five of the 61
sites, and Ch 10's is one formula repeated sixteen times, so a wording chosen badly is repeated
sixteen times before anyone sees it.

---

## 8. What this instruction does not settle

**`[C]` finding, reported to `[A]` 2026-09-12 and not ruled.** An orientation, a fixation and a
phase are three kinds of thing said with the same three adjectives, and the only safeguard is the
rule in Ch 14 reserving the letters for a person. The letters appear 28 times in the whole book,
every one inside the pair notation, and the rule is stated in Part 3 after a reader has met the
pairs about thirty times. **The safeguard is not load-bearing, and this session found a false
claim it had failed to catch** — a sentence comparing a person with a phase, written in adjectives,
which passed a coherence run and stood through six sessions before `[A]` doubted it.

`[A]` 2026-09-12: *a rule is easy. let's keep looking at what is needed first.* **So no rule is
proposed here.** The finding is recorded for a later doctrine sitting.
