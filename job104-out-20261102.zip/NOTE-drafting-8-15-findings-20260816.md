# NOTE — findings from the drafting session `drafting-8-15`, 2026-08-16

**This does not replace `HANDOFF-20260815b.md`, which is the live handoff.** It records what a
session produced before discovering it was executing a superseded architecture, and it exists
because two of the items are `[A]` rulings that are written down nowhere else.

Provenance `[A]`/`[C]`. Everything below has been checked against `rev2-0814b.md` directly, by
`grep`, and quotes rather than paraphrases.

---

## 0. THE ARCHITECTURE ERROR — for the record, because it will recur

**There are three architecture files, and two of them claim to supersede the same one.**

- `BOOK2-ARCHITECTURE-20260815.md` — growth as Part Two. Correctly deleted.
- `BOOK2-ARCHITECTURE-20260815b.md` — *"`[A]` corrected this: book 2 follows book 1's order."* **Live.**
- `BOOK2-ARCHITECTURE-20260816.md` — growth as Part Two again, Ch 6–13. **Void.**

Both the 08-15b file and the 08-16 file open *"Supersedes `BOOK2-ARCHITECTURE-20260815.md`."* The
08-16 session superseded a file that had already been replaced, and never saw 08-15b. Its §2 argues
the structure from *"the 08-11 design intent carried to book 2 by R3"* — from first principles,
because it did not know `[A]` had ruled otherwise on 08-15.

**What the 08-16 file therefore does not know:** that R7 is cut from book 2 (it builds three
chapters on R7); that Ch 2 stays, ruled; that book 1 had been read and indexed; that book 2 has four
parts; that the comparison chapter became an appendix; that Learning to See was placed.

**`HANDOFF-20260816.md` carries the error forward** and is void with it.

**And the safeguard that would have caught it was removed by the file that needed catching.**
`HANDOFF-20260815b.md` §1.0 — *"FIRST — check what you were given"* — makes a session compare its
inputs against the job's file set and say what is missing before starting. The 08-16 handoff dropped
§1.0. A session given that handoff cannot run the check that would have exposed it.

**Recommendation `[C]`: §1.0 should never be dropped from a handoff, and the file-set tables are
the reason it works.** Restore it in every successor.

---

## 1. RULED BY `[A]`, 2026-08-16 — in no other file

**Z0 is only ever an ideal**, wherever the book mentions it. Offered against `[A]`'s general
position that in the strictest sense everything in the book is an ideal, and that this is not
practical to write out each time — but that Z0 specifically is only ever meant that way.

**The −/0/+ suffixes are used in two ways, and they are different subjects.**

1. **The continuous positioning of fixations on the orientation cycle** — the leans. `[A]` flags
   that **this may be wrong**: it may be that **B+ can never touch Z−**, i.e. the circle may not be
   continuous. *New, unruled, and recorded here because it exists nowhere else.*
2. **The Z− to Z+ stretch** — how much of a realm registers. *"An entirely different subject."*

**This bears directly on Part 2's Ch 11**, which `BOOK2-ARCHITECTURE-20260815b.md` §3.2 calls *"the
bridge to Part 3 and the most load-bearing chapter in Part 2."* That chapter is titled for the first
use — *Leans, and the Classical Wings* — and specced to carry both. Book 1 bundles them too, which
is why its Ch 11 has to open with a disclaimer (L1129): *"So Z− and Z+ are not merely detachment
leaning one way or the other, the way B− and B+ are different flavors of caution."* **Whether book 2
keeps the bundle is a scope question for Ch 11, alongside the eight-wings question already open at
§7 item 3.**

---

## 2. BOOK 1 VOCABULARY — measured, and it bears on Ch 11

**"Arc" carries two senses in book 1, undistinguished.**

- *One traversal* — `[A]`'s own sense. *"The process arc named at the start of the chapter"*; *"the
  arc has the orientation cycle's shape but not yet its closure"*; Ch 15's *"Fixation as a Stopped
  Arc"*; *"arcs frozen inside arcs."*
- *The Z segment* — *"the middle of the Z arc"*; *"what varies across the Z arc is how much still
  registers"*; *"Vision and blindness are the near and far ends of detachment's single arc"*;
  *"Z0 sits at the apex of detachment's arc"*; *"Level 1 is not the top of the Z arc but just short
  of it"*; *"the arc through Z."*

**"Range" carries three.** The whole Z stretch (L1129, *"It is one quantity across a range, not two
conditions with a boundary between them"*); the band around a mark (L1164 and L1716, *"the notation
names the middle of a range, and the range is not error"*); and the Levels ladder (L1530, *"a
bounded range"*).

**Consequence for Ch 11 `[C]`:** the chapter needs to refer to the Z− to Z+ object roughly a dozen
times, and neither noun is clean. One option worth considering is no place-word at all — L1129's
load-bearing noun is *quantity*, and R2 says the same in its own voice (*"One quantity — how much
registers"*). A quantity cannot be misread as a fourth orientation the way a place can. **Offered,
not recommended; `[A]` to rule when Ch 11 is drafted.**

---

## 3. A CONFLATION IN BOOK 1, AND THE ARCHITECTURE INHERITS IT

`BOOK2-ARCHITECTURE-20260815b.md` §3.2 specs Ch 11 to carry *"Z0 as unselective receptivity and as
a limit."* **Book 1 attaches "limit" to a different object.** Ch 18 L1796 pulls three things apart:

> But one word has been doing two jobs, and they must be pulled apart. **Z0 the orientation** is a
> stance on the circle — the balanced point, no lean, and like every position a region a person only
> ranges around… **A moment of it passes by in ordinary blur; nothing about it is an attainment.**

"Limit" appears two paragraphs later, at L1798, and attaches to **complete choicelessness** — *"the
limit the trained state approaches, and nowhere else."*

`[A]` has ruled (§1 above) that Z0 is only ever an ideal, so the substance stands. **But Ch 11 must
not let Z0 read as an attainment**, which is the distinction Ch 18 exists to draw and which the
one-line spec collapses.

---

## 4. PART ONE REPAIRS — verified, and independent of any architecture

**The R10 sweep in book 2, seven sites**, each confirmed as a unique exact string:

| Chapter | String |
|---|---|
| Ch 1 | *a person holds one orientation in each realm* |
| Ch 5 | *a pair is written as the physical orientation and then the psychic* |
| Ch 5, the One | *both orientations pull, but not in the same direction* |
| Ch 5, the Three | *holding one orientation in both realms has a particular consequence* |
| Ch 5, the Six | *as with the Three, one orientation in both realms* |
| Ch 5, the Nine | *one orientation in both realms means, again* |
| Ch 5, close | *its two orientations at work* |

**Four sites stay as orientations:** the TOC, Ch 4's title, Ch 4's *"there are three orientations"*,
and the Eight's *"an orientation their loud realm has no way of reading."* **Two in Ch 2's profiles
are ordinary English.** This matches R10's measured scope exactly.

**An eighth site R10 did not list** `[C]`: the Four's *"consequences in that realm are exactly what a
stepped-back orientation does not track."* It reads as the Four's own physical fixation. `[A]` to
rule.

**Two Ch 5 sentences that break once R11's decoupling is stated** (now Ch 11, not Ch 6):

- The Three: *"There is also no detachment in either realm, which means no step back and no vantage
  point on either one."* Inserting "fixation" after "detachment" makes the first clause true and
  untouched by R11. The second clause waits on §5 below.
- The Nine: *"The Nine has seeing twice over… Nothing in either realm is pulling at them, and so
  they observe both plainly."* Unqualified — under R11 seeing is a position, not a property of the
  fixation. No repair proposed.

**Flagged, not proposed:** Ch 1's *"all following from which pair a person holds"* is stronger than
R11 supports. `[C]` recommends leaving it and letting the later chapter do the qualifying.

**Coupling to watch:** whichever chapter states R11's decoupling will want to recall Part One's
claim. If the sweep has landed, Part One says *fixation* there, and the recall must match.

---

## 5. OPEN, AND IT IS THE ONE THAT MATTERS

**Position or exercise.** `[C]` raised it; `[A]` pushed on it and was right to.

Does a realm's place on the Z stretch mean the person is **exercising** detachment there, or is it a
fact about the realm that a Z fixation is only one route to?

Ch 4 makes seeing Z's competence, so the first reading has a Three seeing — and book 2's Ch 5 says
the Three has no vantage point anywhere. The second reading keeps the Three's account intact and
still gives R7.1 the arc in every realm that R11 was ruled to supply.

**Where it binds:** Ch 11, and again wherever the half-attainment is derived for types with no Z
fixation. R11 as written does not say which.

---

## 6. WHAT THIS SESSION PRODUCED AND DELETED

A Ch 6, *"Detachment Has a Range"*, drafted to the void 08-16 architecture; a handoff written
against it; and a note claiming book 1's Ch 8 and Ch 9 were missing from book 2 — which
`BOOK2-ARCHITECTURE-20260815b.md` places at Ch 8 and Ch 9. **All deleted, nothing downloaded.**

The one substantive thing in that draft worth carrying to Ch 11: **R11's decoupling can be argued
from book 2's own Ch 5 rather than asserted** — the One who cannot see their own anger, the Eight
who cannot see the force they brought, the Three's unwatched blind spot. Three realms gone dark in
types where detachment is not the fixation. **This rests on §5 and should not be written before it
is ruled.**

---

## 7. A STANDING VOICE RULE, `[A]` 2026-08-16 — proposed for §4 of the handoff

`[A]`, on reading a drafted chapter: **Claude uses awkward metaphors to keep the wording terse.**
An earlier session traced the habit to a particular book on writing style, aimed at technical
writing, where it does not belong in this book. **It most often appears as verbs proper to a
conscious being attached to inanimate or abstract subjects and objects.**

**The rule.** Grids, folds, chapters, figures, loops, steps and structures do not *invite*, *ask*,
*want*, *arrive at*, *hold*, *leave alone*, *string together*, or get *moved on*. And where a
compressed metaphor stands in for a plain statement, use the plain statement even when it is
longer. **Terseness is not worth a metaphor.**

**The diagnostic that makes it findable, `[C]`.** In this session's two chapters the fault appeared
nineteen times, and **the majority were places where a plainer sentence book 1 already had was
replaced with a tighter one.** Book 1: *"caution requires deferring pleasure"* → `[C]`: *"caution
asks them to defer pleasure."* Book 1: *"stress disturbs a person's ability to focus"* → `[C]`:
*"…to hold their footing."* Book 1: *"the place their process arcs habitually rest"* → `[C]`:
*"the place their process arcs stop."* Book 1's Ch 7: *"The rest of the book uses it constantly"* →
`[C]`: *"It is a working surface. Almost everything from here on is a move on it."*

So the check has a cheap form when carrying: **where the draft is tighter than the source, look at
what was traded for the tightness.** Reverting to book 1's wording fixed most instances and
restored fidelity at the same time.

**Not to be swept out of book 1.** `[A]`'s own prose has abstract subjects taking live verbs —
*"Enthusiasm meets limits and becomes caution; caution ripens into understanding and lets go into
detachment."* Those are his and they carry. The rule governs what `[C]` adds.

**Extension, `[A]` same day — do not stage the reader's response.** *"That is worth a moment"*
mixes the reader's emotions into factual exposition, and `[A]` files it with the metaphor fault
above. Out: *worth a moment*, *notice*, *worth asking*, *worth saying*, *one thing has to be said*,
*strikingly*, *remarkably*. State the fact and let the reader supply the response. Both faults are
the same substitution — an authorial gesture standing in for a plain statement — and both read as
tighter writing while being weaker writing.

**A third family, `[A]` same day — the disguised restatement.** `[A]` on the grid chapter: *"there
were more disguised attempts to associate the 3x3 with the 9."* A claim the chapter needs **once**
gets re-asserted in several softened forms, each dressed as a different point, so the repetition is
invisible to the writer. In Ch 6 the nine-cells-are-the-nine-types claim was made four times — in
the opening sentence, in *"every pairing is a type"*, in *"All nine are there, each in one cell"*,
and in a paragraph of its own. `[A]`'s rule: **if the association is needed, say it in one place by
itself.**

**Diagnostic:** delete the sentence and see whether the chapter loses anything. A restatement costs
nothing to remove — which is also why it survives review. It never looks wrong, only unnecessary,
and unnecessary is easy to defend one sentence at a time.

**All three families are the same failure at different scales** — a gesture where a statement
belongs. Metaphor for compression, staged reader response, and the claim said four ways instead of
once. In this session `[A]` caught all three and `[C]` caught none unprompted.

**Where the style comes from, and why it is hard to see — `[A]`, 2026-08-16, recorded as given.**

> It strikes me as a kind of poetry, and I think the originator of the style (not Claude) was
> attempting to flatter the reader that he is sophisticated enough to be able to follow it. Which
> confuses those who don't follow it and insults some of those who do.

**Where it actually comes from — recovered by `[A]` from an earlier session, 2026-08-16.** Not a
style manual. A register:

> not primarily academic papers but the register of expository science-and-ideas writing — the
> Gould/Hofstadter/pop-philosophy lineage, where "the mechanism does X," "the theory predicts,"
> "this chapter argues" are house style. It's a voice that keeps the abstraction as grammatical hero
> because that lets you be concise and sound rigorous without committing to a plain subject — which
> is exactly why it surfaces under pressure to say something briefly and authoritatively.

**The rule, and it supersedes the looser one above:**

> **When the subject of a sentence is an idea rather than a person or a thing and the verb gives it
> agency, the prose has stopped describing the world.**

*`[C]`'s guess before this was recovered was a prescriptive manual — Williams's `Style`, Lanham's
`Revising Prose`. **Wrong in kind, not merely in detail**, and worth keeping on the record: a rule
taught can be dropped, a register absorbed by reading cannot, which is why naming the fault does not
stop it recurring. It was also the fifth confident-sounding attribution `[C]` produced this session
that did not survive checking.*

**Two things the sharper rule fixes.** It permits *things* as subjects — "the grid has nine cells"
is describing the world — and forbids only *ideas* given agency, which is a cleaner line than
"inanimate or abstract." And its final clause is not a stylistic complaint but **R9 applied at
sentence level**: what can be written points at patterns in reality, and a sentence whose subject is
an idea acting is not pointing at reality at all. The voice rule is therefore downstream of ruled
doctrine rather than a matter of taste, and can be argued from R9 when a drafter resists it.

**What this explains, `[C]`, and it is the most useful thing in this section.** All three families
ask the reader to do a small piece of extra work — unpack the metaphor, take the cue, notice that
this is the same claim again — and each converts a statement into a performance the reader is
invited to appreciate. That is why the fault resists self-detection: **compression reads to the
writer as respect for the reader's intelligence**, so every instance feels like good writing at the
moment it is written, and can be defended one sentence at a time. `[A]`'s second clause is the part
that settles it: a reader who does unpack *"almost everything from here on is a move on it"* arrives
at nothing they did not already have, having been made to work for a payoff that was never there.

**And it predicts where the fault will recur: wherever the writing is going well**, because that is
when compression feels earned.

**It also bears on this book in particular.** The Foreword's reader is someone who came to the
Enneagram *"despairing, blundering through life, looking for help."* A device that flatters the
quick and loses everyone else is the wrong device for that reader, whatever its merits elsewhere.

---

## 8. A BOOK 1 REPAIR, `[A]` 2026-08-16 — job 3

**Book 1 Ch 5, L586, "What Kind of Thing the Cycle Is."** The passage asks *who* completes a whole
loop, and its own answers are not all people — at the thought scale it is the thought that runs the
arc, not the person. Ch 5's own definition has it right two paragraphs earlier: *"Every individual
process… runs its own smaller process arc… through the orientations."* `[A]` ruled the repair.

**Two search strings, punctuation-free, one occurrence each — measured by `grep`:**

| Find | Replace with |
|---|---|
| `so it is worth saying again who actually does that` | `so it is worth saying again what actually completes one` |
| `At the scale of **character**, usually nobody does` | `At the scale of **character**, usually nothing does` |

**Deliberately not touched:** *"it is worth saying again"*, which is the reader-staging fault of §7.
Book 1 has its own register and correcting the referent is not a licence to restyle 56,000 words.
**And this is the first repair made in the repository rather than at the moment of carrying** — the
handoff records that choice as open (*"'book 1 is never revised' makes the second the default"*), so
the precedent is worth noticing.

**A deliberate divergence from book 1, `[A]` 2026-08-16 — do not "restore" it.** Book 1 Ch 5 L594
illustrates the three passages with *"a candle burns through all three with no one home."* `[A]`:
a candle does not light itself, so the example fails at the arising passage, which is the one it is
there to illustrate. Book 2's Ch 7 reads **"A wave rises, crests and falls on its own"** — self-
arising, and plainer than the idiom it replaces. A carrier comparing the two chapters will see a
difference and should leave it.
