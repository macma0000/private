# JOB16 `book 1 defects` — REPAIRS, READY TO APPLY

**Session:** Job16 book 1 defects 8-24. Set: `MANIFEST-20260824m.md`, 19 ok / 0 missing / 0 extra.
**Source list:** `NOTE-fixations-arcs-and-the-two-scales-20260821.md` §8, nine rows.
**Status of this file:** every site below is DRAFTED, not applied. Nothing has been written to
`rev2-0814b.md` or `BOOK2-20260818c.md`. A session applying these should verify each `CURRENT`
string still matches before substituting.

**Author record was NOT in this set and was NOT read**, per job 3's exclusion. One passage was
pasted into chat by `[A]`; it informed discussion but no repair rests on it.

---

## PART 1 — RULINGS MADE THIS SESSION

These reach past the nine sites. Several repairs below depend on them.

| # | Ruling | Where it came from |
|---|---|---|
| R-A | **No umbrella term.** `process arc` is RETIRED. The general shape keeps a plain word (`arc`, unbolded); **thought arc** and **endeavor arc** are the two named terms. Never present them as a genus with two species. | `[A]`, on whether a general term is needed |
| R-B | **`range` for the circle.** A stretch of the circle is a *range* (the Z range, the detachment range), never an *arc*. | `[A]` proposed `section`, then `range` |
| R-C | **Fixation position is fuzzy everywhere** — "it's just less obvious" away from Z. NOT ruled as doctrine; see the open-derivations note, Entry B. Ch 11 repair is written to be consistent with it without asserting it. | `[A]` |
| R-D | **Many nestings per level** — one-per-level would have everyone at the bottom in hours or days. Conditional on the blindness mechanism being valid. Generalizes: *whatever the descent quantum is, many make a level.* | `[A]` |
| R-E | **Ch 5 poses, Ch 15 answers** — the deepest question (*what a type ultimately is*) is not answered in Ch 5. Strengthened by R-F. | `[A]` agreed |
| R-F | **The fixation reaches the thought scale only through content selection** — it decides what thoughts are *about*; it does not touch the thought's shape, which is the same in everyone. Hence the sixty-second claim survives whole: what is checkable is the shape. | `[A]`: *"thought loops depend on fixations only as far as what the thought is about - but it doesn't pause"* |
| R-G | **Section retitles**: `Fixation as a Stopped Arc` → **`Where a Person Stops`**; `Beneath the Levels: The Process` → **`Beneath the Levels: The Rule That Drives the Descent`**. | `[A]` |

**Prior rulings these repairs also rest on** (from the 08-21 note, already made): all arcs complete;
a fixation is where a person habitually stops, in an endeavor or not; what sticks is the endeavor,
not the thought; registration continues at the blind end, conscious availability is what fails
(§4.3); abandonment does not feed the blindness loop, jumped-over fear does (§4.2).

---

## PART 2 — THE REPAIRS

### 2.1 bk1 Ch 15 — section title *(row 1; R-G)*

`CURRENT:` `### Fixation as a Stopped Arc`
`REPLACE:` `### Where a Person Stops`

Only ONE citation of the old title survives in the manuscript — App G's temporal layering bullet
(§2.10). The other was in the future-topics item being cut (§2.9). `TODO.md` L159 also lists it;
bookkeeping, see Part 4.

---

### 2.2 bk1 Ch 15 — the opening paragraph *(rows 1 and 4 — the same sentence)*

Rows 1 and 4 land in one sentence and are repaired together. **The site is larger than either row
says:** the note's own §1 convicts the section on *the same smallest arc is walked through in each*
(§2.3), which no row lists.

`CURRENT:`
> A type, at the smallest scale, is not a place a person stands but a place their process arcs come
> to rest: one person's thoughts rest in the impulse, wanting without proceeding to weigh (an A
> fixation); another's rest in examination, weighing without arriving (a B fixation — the cautious
> types' unclosable worry, defined rather than described); another's rest in resolution, already
> done with the matter (a Z fixation). One habitual stopping point per realm — and once stopped,
> the next thoughts arise inside that unfinished context, and each of *those* arcs either completes
> or stops again in the middle.

`REPLACE:`
> A type is not a place a person stands but the place they habitually stop. What stops is not the
> thought — thoughts run their course, and one that ends badly has still ended. What stops is the
> endeavor: the pursuit taken up, the problem worked at, the matter to be settled. One person's
> endeavors stop in the impulse, wanting without proceeding to weigh (an A fixation); another's stop
> in examination, where the weighing will not close (a B fixation — the cautious types' unclosable
> worry, defined rather than described); another's stop in resolution, already done with the matter
> (a Z fixation). One habitual stopping point per realm.

**Note the tail clause is DELETED here**, not left standing — the nesting claim dies in §2.4, and
this paragraph should not carry it in the interim.

**On row 4** (*weighing without arriving*): the sketch three paragraphs down has the cautious
person arriving — *forced by time or exhaustion, they choose (Z), with a resolution they seldom
trust*. The failure was never arrival; it is the stacking. Hence *where the weighing will not close*.

---

### 2.3 bk1 Ch 15 — the sketch lead-in *(unlisted; note §1's own evidence)*

`CURRENT:` `The difference between the fixations shows plainly if the same smallest arc is walked through in each.`
`REPLACE:` `The difference between the fixations shows plainly if the same endeavor is walked through in each.`

---

### 2.4 bk1 Ch 15 — the Z+ sketch *(row 2)*

`CURRENT`, final three sentences:
> To him, each drop is a clean ending and each new pursuit a fresh start. The structure underneath
> says otherwise: a pursuit ended by dropping rather than deciding does not close; it persists
> unresolved, and the new pursuit arises inside it — which is why the alternatives stay related. He
> nests without knowing it; the cautious person nests in plain sight.

`REPLACE:`
> To him, each drop is a clean ending and each new pursuit a fresh start, and in that he is not
> wrong: the pursuit is over, and dropping is how his endings are made. What the drop does not do is
> answer anything, so the boredom it returns him to is the boredom he began with. The alternatives
> stay related for the reason given below — the fixation selects the population of arisings before
> any pursuit begins, and at Z+ that population is restlessness. He never sees the layering; the
> cautious person watches it happen and cannot stop it.

**The replacement cause is the book's own**, two paragraphs down: *the fixation selects the
population of arisings before any single arc begins*. Nothing invented.

**The last sentence is doubly motivated:** it was a nesting sentence (dies with §2.5), and under
`[A]`'s conscious-arcs position (open note, Entry A §1) *nesting without knowing it* is not merely
unobserved but impossible.

**THE TRIGGER WAS SUBSEQUENTLY RULED — `[A]`: "sketch is wrong."** The earlier sentences of the
paragraph change too, and they are NOT yet settled prose. See §2.4b.
2. **Not a repair, flagged only:** the sketch can no longer be read as showing how a Z+ person got
   that way (§4.2: abandoned desires carry nothing). The old nesting line invited that reading; the
   replacement does not assert it but does not rule it out. Saying so would be a NEW sentence, past
   what §8 authorizes.

---

### 2.4b bk1 Ch 15 — the Z+ sketch, opening sentences *(RULED, prose not final)*

**`[A]` ruled the sketch wrong: Z+ SKIPS the examination, it does not defer it.** The seam
definition three paragraphs above (*resolution grabbed to skip examination*) is right. The old text
— *the examination not skipped but deferred, waiting until the action runs into trouble*, and
*when trouble comes (B, late and from outside), he drops the pursuit* — is an accomplishment frame
presuming an obstacle, which is A's shape, not Z+'s.

**`[A]` then corrected `[C]`'s first redraw**, which had Z+ skipping B entirely. That is not
available: Ch 5 says every process makes all three passages. **B happens; what happens in it is
abandonment rather than resolution — a quick, unpleasant decision to avoid the further
unpleasantness.** A and Z+ differ in when and how often, not in kind.

`CURRENT`, first three sentences:
> A person detached on the blind side (Z+) starts from the vacuum the stance itself creates:
> boredom. An impulse toward something enjoyable arises (A) and moves straight to action — the
> examination not skipped but deferred, waiting until the action runs into trouble. When trouble
> comes (B, late and from outside), he drops the pursuit — "never mind" — and before long a new
> impulse arises, usually for a related alternative: the same fun by another route.

`DRAFT` (prose not final — see caution below):
> A person detached on the blind side (Z+) starts from the vacuum the stance itself creates:
> boredom. An impulse toward something enjoyable arises (A) and goes straight to action. He stays
> while it is comfortable. When the comfort thins, the weighing does happen (B) — but it is brief
> and it is unpleasant, and what it decides is to abandon rather than to resolve: a small discomfort
> now against the larger one that staying would cost. He is elsewhere before he has finished
> thinking about it. And before long a new impulse arises, usually for a related alternative: the
> same fun by another route.

**Why this is not final.** The exchange continued past the sketch into what the abandonment
*leaves* — a vague unresolved fear, partly about the abandoning itself, which is what makes more
blindness. That is Entry C of the open-derivations note and it is **not ruled**. If it is ruled, this
paragraph likely takes a closing sentence and the A sketch takes a counterpart. **An applying session
should treat §2.4b as ruled in substance and provisional in wording, and should not add the closing
sentence.**

**One consequence `[A]` has not addressed:** A and Z+ are now one mechanism at two settings, while
the four sketches exist to show four fixations as distinguishable. Whether the section can carry
that, or needs a line saying so outright, is a judgment about the section.

---

### 2.5 bk1 Ch 15 — the nesting paragraph *(row 3)*

`CURRENT:`
> A stopped arc does not disappear. It persists as unresolved context, and arcs arising within it
> can stop partway too — so the stopping goes farther, into new layers: arcs frozen inside arcs.
> This is the layering Riso and Hudson traced to its most primitive floor in the Levels and the Core
> Dynamics — the connection that ties the orientation fixations directly to the health axis. The next
> section states the rule that drives the descent; Appendix G runs it level by level.

`REPLACE:`
> What builds is not the arc but the fear. A fear avoided rather than faced becomes the desire of the
> level below, which breeds a fear of its own, avoided in turn; each evasion lays a layer over the
> ones already there, and the layers accumulate. This is the layering Riso and Hudson traced to its
> most primitive floor in the Levels and the Core Dynamics — the connection that ties the orientation
> fixations directly to the health axis. The next section states the rule that drives the descent;
> Appendix G runs it level by level.

**IMPORTANT — the depth cost is smaller than the row implies.** `[C]` first reported that cutting
this leaves the chapter's correspondence without a mechanism. **That was wrong.** Riso's layering is
stated twice elsewhere with no reference to arcs (Ch 5's *builds in layers, each one a further
remove from freedom*; Ch 13's *papering it over… creates a new layer covering the earlier fears*),
and App G's chains are that layering written out. What L1476 did was **assert the arc nesting and
the Riso layering are one layering.** That identification is what fails; the layering has its own
legs. The cascade in the replacement's second sentence is Ch 14's closing promise almost verbatim —
Ch 15 was supposed to be delivering on it here and was delivering arc nesting instead.

---

### 2.6 bk1 Ch 15 — the temporal paragraph *(row 3, second half)*

`CURRENT:`
> The nesting has a temporal consequence, and it follows from the structure rather than from
> observation. An arc can only arise *within* a context that already exists, and that context
> persists while the inner arc runs — so each layer is older and longer-lived than the layers below
> it. Thoughts churn by the minute; the fixation that frames them moves at the pace of a life. This
> is why durable movement along the health axis is slow while the day-to-day fluctuates by a step,
> and why the deepest structures are hardest to see: nothing that completes inside a layer ever gives
> the vantage of its beginning or its end.

`REPLACE:`
> The layering has a temporal consequence, and it follows from the structure rather than from
> observation. Each layer is laid down over the ones already there and persists while everything
> inside it turns — so an enclosing layer is older and longer-lived than the layers it encloses.
> Thoughts churn by the minute; the fixation that frames them moves at the pace of a life. This is
> why durable movement along the health axis is slow while the day-to-day fluctuates by a step, and
> why the deepest structures are hardest to see: nothing that completes inside a layer ever gives the
> vantage of its beginning or its end.

All three conclusions survive. Direction unchanged (enclosing is older), which is what makes the
deepest layers of the personality the upper levels of health, as Ch 15 says later.

**Deliberately NOT used here:** *desires cycle because they can be answered, fears freeze because
they cannot.* That is Ch 17, and Ch 17 introduces it as the answer to a question **Ch 15 raised and
deferred.** Using it here spoils its own setup.

---

### 2.7 bk1 Ch 15 — next section title *(unlisted; R-G)*

`CURRENT:` `### Beneath the Levels: The Process`
`REPLACE:` `### Beneath the Levels: The Rule That Drives the Descent`

The new title matches the forward reference pointing at it (§2.5's last sentence). Citation sweep:
the old title appears NOWHERE else in either book. `TODO.md` L159 lists it; see Part 4.

`[A]` proposed *How a Person Accumulates Disabilities* for this section; rejected because roughly
half the section is the nine-level roster (description, not accumulation), *disabilities* appears
nowhere in it, and the chapter already has *What Moves a Person* and *What the Climb Requires* — a
third person-shaped title would blur the run.

---

### 2.8 bk1 Ch 5 — the deepest-question sentence and its successor *(row 5; R-E, R-F)*

`CURRENT:`
> This smallest scale is also where the deepest question, *what a type ultimately is*, gets its
> answer: not a place a person stands but the place their process arcs habitually rest. Chapter 13
> reads the thought-scale loop against what the contemplative traditions found there; Chapter 15
> follows the resting down into the nested layers that become the Levels of Development.

`REPLACE:`
> Chapter 13 reads this thought-scale loop against what the contemplative traditions found there;
> Chapter 15 turns to what a fixation is, at a larger scale than this one.

**Why the question is not merely deferred but removed.** `[C]` first argued from weight (a
definitional answer landing ten chapters early). The better argument is R-F: the paragraph's subject
is the loop's SHAPE, which is fixation-independent, and the old sentence **transferred the
sixty-second claim's checkability across a scale boundary** to a claim about types that does not
share it. The demonstrative *This smallest scale* referred to the thought scale — correctly. The
transfer was the defect.

**The successor sentence is unlisted and had to go with it:** *follows the resting down into the
nested layers* contains two dead things — *the resting* (arcs coming to rest) and *the nested
layers* (the reading killed in §2.9).

---

### 2.9 bk1 "Additional Topics for Future Exploration" — CUT ENTIRELY *(row 9, first half)*

**ADDRESS CORRECTION: row 9 says "bk1 App G, the open-questions appendix." Wrong.** The *fixation
is an arc arrested before its ending* text is NOT in App G and not in any appendix — it is in
"Additional Topics for Future Exploration" (a top-level section before Appendix A), under
"Practical Tools and Resources," item 1, "The Nesting Reading of the Core Dynamics." Only §2.10 is
actually in App G. A session working the row alone would find one of two and report the item closed.

`ACTION:` **Delete the whole numbered item.** Not a wording repair — every sentence of it is the
identification that was struck. Cutting the named clause leaves nothing, not a damaged item.

**It dies three times over, and only the second is conditional:**
1. Nothing freezes (all arcs complete) — so there are no frozen arcs to count.
2. **R-D**: many nestings per level, so the counts do not line up. *(Conditional on blindness.)*
3. The correspondence has **four approximate sample points**, not nine rungs (Ch 13: healthiest like
   Z−, down through B, A, to Z+; Ch 15: *without the claim that any single rung is a particular
   orientation*). An identity claim needs rung-level structure the correspondence does not have.

`[C]` drafted a narrowed replacement question and **withdrew it** after R-D: the question is settled,
not still open, and an open-questions list should not carry a closed one. What replaces it is a
statement, and a statement belongs in Ch 15 or App G — placement is doctrine, not repair.

---

### 2.10 bk1 App G.1 — the temporal nesting rule *(row 9, second half)*

`CURRENT:`
> - **Temporal nesting.** D(n+1) arises within the persisting, unresolved context of level n, so
> each level's structure is older and longer-lived than the structures of the levels below it — by
> the nature of the nesting, each arc lasts longer than the newer ones beneath it (Chapter 15,
> "Fixation as a Stopped Arc"). The churn is fastest at the newest, innermost layers: this is what
> lies behind the ±1 short-term fluctuation of Chapter 15 (the innermost layer moves at the pace of
> circumstance) and behind the slowness of durable ascent or descent (the enclosing layers move at
> the pace of a life). It also sharpens the self-obscuration point: an enclosing layer is never seen
> whole from inside, because nothing that completes within it spans its duration.

`REPLACE:`
> - **Temporal layering.** The evasions that carry a person from one level to the next are laid down
> over what is already there, and what is already there persists beneath them — Conservation above
> says as much: the earlier desire is not replaced but covered. A level is not one layer; it may take
> several. What holds is the order — everything at level n is older than anything at level n+1 — so
> each level's structure is older and longer-lived than the structures of the levels below it. The
> churn is fastest at the newest, innermost layers: this is what lies behind the ±1 short-term
> fluctuation of Chapter 15 (the innermost layer moves at the pace of circumstance) and behind the
> slowness of durable ascent or descent (the enclosing layers move at the pace of a life). It also
> sharpens the self-obscuration point: an enclosing layer is never seen whole from inside, because
> nothing that completes within it spans its duration.

Derivation now runs off **Conservation**, two bullets above in the same list, which needs no arcs.
Name changed from *nesting* to *layering* to match Ch 15. The Ch 15 citation is dropped as
redundant; if retained it must read `(Chapter 15, "Where a Person Stops")`.

**`[C]`'s first draft said *D(n+1) is laid down over level n* — one layer per level, which R-D
denies. Corrected above.** The one-to-one was smuggled in the original too.

**Confirmed by `[A]`:** the level ordering stands on **the chain's own causal derivation** (F(n) →
D(n+1), rung to rung, no orientation named), NOT on the orientation correspondence. So the
four-sample-point limit does not reach this bullet and the ordering claim is sound.

**The line this draws:** the chain gives structure rung by rung; the correspondence gives resemblance
at four points. Anything claiming rung-level precision must be sourced to the chain. **The dead item
in §2.9 wanted rung-level precision from the correspondence.**

---

### 2.11 bk1 Ch 11 AND bk2 Ch 11 — the registering clause *(row 7)*

**Row 7 ends "and see the cost note there" — the SUBSTANCE was ruled (§4.3), the WORDING was not.
`[C]` twice told `[A]` this item needed no ruling. That was wrong.**

**The cost is smaller than §4.3 feared.** `register` appears in exactly three places across both
books — the two listed clauses and one sentence after book 2's. Everywhere else, including the whole
health axis, the book calls this quantity **seeing** (the seeing face, clear seeing at Z−, clarity to
blindness, the terminal levels destroying the seeing itself).

**The book already has the correct account, in Ch 8:** seeing is not volitional and fails by *a deep
reflexive turning away* whose extent depends on what the seeing would cost and which way detachment
leans. That is conscious availability failing, not registration. **Ch 11 is the outlier.**

`bk1 CURRENT:`
> What varies across the Z arc is how much still registers. Near Z− the remnant of caution is real
> and the realm is seen; further along, as the trace of enthusiasm grows, less arrives; at Z+ the
> registering has stopped. It is one quantity across a range, not two conditions with a boundary
> between them — a doubly-detached Type 9 leaning Z− …

`bk1 REPLACE:`
> What varies across the Z range is how much is seen. Near Z− the remnant of caution is real and the
> realm is seen; further along, as the trace of enthusiasm grows, the turning away goes further, and
> less of what registers is allowed to surface. It is one quantity varying continuously, not two
> conditions with a boundary between them — a doubly-detached Type 9 leaning Z− …

`bk2` takes the same substitution (*at the far end* likewise removed), and its following sentence
with it:
> How much is seen is a fact about a realm. A fixation in detachment is one route to a realm being
> little seen.

**THE ENDPOINT CLAUSE IS GONE ENTIRELY — this matters.** `[C]`'s first two drafts wrote *at Z+ it is
complete* and then *toward Z+ little of what registers is allowed to surface*. **Both were wrong for
`[A]`'s reason:** the width is a property of the FIXATION, not of the arc. A range may have a
definite endpoint; what it cannot have is a person standing exactly on it. The sentence now describes
a gradient and stops. **The next sentence already characterizes the far end correctly — by LEAN
(*the same 9 leaning Z+*), not by position.** `[C]`'s clause was competing with it.

`Z arc` → `Z range` and `across a range` → `varying continuously` are both R-B: `range` is now the
circle's word, so the seeing quantity gives it up. **This is the one edit R-B costs, and it costs
nothing** — *across a range* was doing no work.

---

### 2.12 bk1 Ch 5 — *the cycle's largest arc is a life* *(row 6; DELETE)*

`CURRENT:` `The cycle's largest arc is a life; its smallest is a single thought. Every thought comes to rest in turn at an **impulse**, …`
`REPLACE:` `Every thought comes to rest in turn at an **impulse**, …`

**`[A]`: "just delete it."** The clause bracketed the range before narrowing, but the bracket is
available a few lines up, where Ch 5 gives the scales as a thought, an afternoon, and a lifetime
without calling any of them arcs.

**Consequence, and it is the good kind:** this was the only place in either book treating a life as a
traversal. Ch 18 reads rebirth-over-lifetimes as a figure for the thought-scale fact rather than a
claim about lives, and that now stands unopposed instead of contradicting a sentence thirteen
chapters earlier. Ch 18's surviving life-scale line (§2.16) is safe — it says *what the physical
realm shows*.

---

### 2.13 bk1 Ch 5 — the sixty-second claim, scope named *(row 8; R-F)*

`CURRENT:`
> When one thought ends the next arises conditioned by it, so the arc closes into a loop; at this
> scale the cycle is not a metaphor but a fact, completing many times an hour, in everyone — the one
> claim in this book you can check in the next sixty seconds.

`REPLACE:`
> When one thought ends the next arises conditioned by it, so the thought arc closes into a loop; at
> this scale the cycle is not a metaphor but a fact, completing many times an hour, in everyone — the
> one claim in this book you can check in the next sixty seconds. What is checkable is the shape: a
> thought arising, working over, ending, and the next one following from it. That much is the same
> whatever a person's fixation, which reaches this scale only in what the thoughts are about.

Row 8 said *kept, scope to be named*. R-F names it. The final clause does two jobs: states the scope,
and blocks the transfer §2.8 removed, at the paragraph where a reader would otherwise make it
themselves.

---

### 2.14 bk1 Ch 5 — the process-arc definition *(census; R-A)*

`CURRENT:`
> Every individual process — a thought, a project, an interaction, a relationship — runs its own
> smaller **process arc** of arising, development, and ending, through the orientations.

`REPLACE:`
> Every individual process — a thought, a project, an interaction, a relationship — runs its own arc
> of arising, development, and ending, through the orientations. Two of these matter most in what
> follows and are named throughout: the **thought arc**, and the **endeavor arc** of a bounded
> pursuit.

**DIVERGENCE FOUND 2026-08-27 by `Job24`, via a full `quotecheck sweep` of the set — NOT REPAIRED,
`[A]` HAS NOT SEEN IT.** The `REPLACE:` string above reads *runs its own arc*. **Book 1 L550 reads
*runs its own smaller arc*.** Everything else in this entry landed exactly. **The word `smaller`
survived a repair that removes it, so this file and the manuscript disagree by one word.**
`Job24`'s recommendation is to change **this file, not the manuscript** — *smaller* is doing work,
the arcs being smaller than the orientation cycle the same paragraph has just described, and dropping
it costs the reader that relation. Whoever applied the repair may well have seen the same thing.

**`[A]` proposed substituting "thought arc and/or endeavor arc" for "process arc". Rejected**, and
the reason is the sentence: the four-item list says the categories are not exhaustive, and the
disjunction would claim an interaction and a relationship are one or the other. It also builds the
genus-and-species taxonomy R-A forbids, in the worst place — the definition. And *and/or* is a legal
construction the book uses nowhere.

**Bold moves** from the retired term to the two surviving ones.

---

### 2.15 bk1 Ch 5 — remaining process-arc uses *(census; R-A)*

`CURRENT:` `This is the process arc named at the start of the chapter, at its smallest. The arc has the orientation cycle's shape but not yet its closure.`
`REPLACE:` `This is the thought arc, the smallest of them. The thought arc has the orientation cycle's shape but not yet its closure.`

---

### 2.16 bk1 Ch 13 — the Trimurti line *(census; R-A)*

`CURRENT:` `…the cosmic namesake of the smallest structure in this book: Chapter 5's process arc — arising, development, ending — which every thought traverses.`
`REPLACE:` `…the cosmic namesake of the smallest structure in this book: the arc every thought traverses — arising, development, ending.`

---

### 2.17 bk1 Ch 18 — *the cycle does not close its last arc* *(census)*

`CURRENT:` `One shape, three sizes: the cycle does not close its last arc; it ends, and starts.`
`REPLACE:` `One shape, three sizes: the cycle does not close; it ends, and starts.`

**This site is NOT covered by R-A or R-B.** The word here is a FOURTH sense — a *leg of the cycle*,
the third arrow, Z to A. `range` will not take it (*does not close its last range* is not English):
a range is a stretch you can be positioned in; this is a directed segment of a loop.

**The word was also carrying a deliberate double meaning** — geometrically, closing an arc completes
the circle; and *closure* is Ch 5's word for a process arc reaching its ending. **Dropping the word
costs the pun.** Judged a fair price: the pun was only available because `arc` was ambiguous.

Nothing else is lost — the paragraph has already established that the first two arrows are
transitions and the third is not, so *where* it fails to close is fixed by context.

---

### 2.18 bk2 Ch 7 — the census sites and the carried fixation sentence

Book 2's five `arc` sites are all in Ch 7 (writer 2 is in Ch 1–4; **no collision, but verify before
applying**).

- `runs its own **process arc** through the orientations. Whether a whole arc ever completes depends
  on the scale.` → take §2.14's treatment, adapted to book 2's wording.
- `At the scale of a **single thought**, an arc completes in fractions of a second…` → `a thought
  arc completes…`
- `**bounded undertaking** … the whole arc is sometimes genuinely lived` → `the whole endeavor arc…`
- `so the arc closes into a loop` → `so the thought arc closes into a loop`
- `That is what a fixation is — not a place a person stands, but the place their process arcs rest.`
  → **NOT a census site.** This is the ruled-and-unapplied Ch 7 fixation sentence carried from the
  handoff. It takes §2.2's frame: *not a place a person stands but the place they habitually stop.*
  Under R10a this is book 2's ONLY account of fixation, so the replacement must stand alone.

---

## PART 3 — THE PATTERN THE LIST DID NOT CATCH

**Five times, a listed row named a clause whose neighbour was defective and unlisted:**

| Listed | Unlisted neighbour that had to go with it |
|---|---|
| Ch 15 title + opening clause | *the same smallest arc is walked through in each* (§2.3) |
| Ch 15 Z+ drop clause | *He nests without knowing it…* (§2.4) |
| Ch 15 nesting paragraph | — (temporal paragraph WAS listed) |
| Ch 5 deepest-question sentence | *follows the resting down into the nested layers* (§2.8) |
| App G row | its address was wrong, and the two sites are in different sections (§2.9) |

**Rows 1 and 4 also turned out to be the same sentence.**

**Recommendation for any future repair list: state that rows name sites, not extents**, and that a
repair session is expected to follow the defect to the edge of what it infects.

---

## PART 4 — BOOKKEEPING FOR THE NEXT SET CUT

1. **§1.0's screen count is set-dependent and reads as absolute.** It says the pre-assembly screen
   prints THREE benign hits and "a fourth hit is a real one" — true for a doctrine set, where the
   author record is the third. **Job 3 excludes the record by design, so two is correct there and a
   THIRD would be the real one.** A session trusting the text would hunt a correctly-absent file.
2. **`TODO.md` L159** lists Ch 15's sections by name and carries BOTH old titles — *Fixation as a
   Stopped Arc* and *Beneath the Levels*. Stale after R-G.
3. **App G citation** to the retitled section (§2.10).
4. **`process arc` is a RETIRED TERM** (R-A). Worth an explicit *retired* entry alongside the
   two-jobs word list, or a later session will reintroduce it innocently. Check **Appendix A**
   (reference card) — not opened this session — for a glossary entry.
5. **`nest` was doing THREE jobs**, only one of which died: scale nesting (Ch 5, Ch 17's recursion —
   fast inside slow) and healthy nesting (Z−'s action begun inside a COMPLETED decision) are both
   untouched. Only nesting-in-an-unfinished-context is gone. Belongs on the two-jobs list.

---

## PART 5 — OPEN, NOT APPLIED

- **Two open derivations** — resolution rate as the descent quantity, and fuzzy fixation position
  (R-C) — in `NOTE-resolution-rate-and-the-descent-20260825.md`. Includes the four
  exact-position sentences found incidentally, and `[A]`'s unanswered question of whether precision
  about fuzziness is needed that early in the book. **`[C]`'s view, recorded there: exact in the
  body, precise in Appendix F, which is where fuzziness changes a prediction rather than a nuance.**
- **The Z+ sketch trigger** (§2.4) — deferred by `[A]`.
- **Bold audit, coinages only, both books** — deliberately NOT run this session: it is a voice
  decision across two books of which `[C]` read perhaps a third, it collides with writer 2 across
  Ch 1–4, and this session already generated more than it closed. The case for it is that
  bolded-term prose reads as cheaper now than it did thirty years ago, not that it is wrong.
- **Dash density** — `[C]`'s drafts in this file lean on em dashes more than `[A]`'s voice requires.
  Worth a pass; not opened.

---

# PART 6 — RECONCILIATION, `job27-defects-20260829`

**Appended, not rewritten.** Nothing above this line is edited. That is deliberate: the
`CURRENT:` strings above are the only surviving record of what each sentence said before its
repair, and rewriting them to match today's text would make this file agree with the books by
construction — which destroys the comparison the file exists for. Both the old string and the
new one are given below, so a grep for either lands here.

**Parent:** `REPAIRS-job16-book1-defects-20260825.md`, 5,556 w, md5 `7d46c89a`.

## 6.0 A standing point that changes how this file is read

**`[A]` 2026-08-29, asked what book 1 is for:** it is the source book 2 is drafted from.

**Consequence:** book 2 developing past book 1 is NOT by itself a defect, and there is nothing
to back-port. A book 1 sentence needs repair only when it is false or asserts something unruled,
because a drafting session greps book 1 and carries forward what it finds. Wording that is merely
older than book 2's stays. Several of the divergences below are recorded as divergences and
deliberately left standing on that basis.

## 6.1 The `smaller` disagreement — CLOSED, in favour of the manuscript

§2.14's `REPLACE:` string reads *runs its own arc*; book 1 L550 reads *runs its own smaller arc*.
Found 08-27 by `Job24`, unresolved since. **The manuscript is right and this file is wrong.**
*smaller* is doing work — the arcs are smaller than the orientation cycle the same paragraph has
just described — and the repair that dropped it did so incidentally, not by ruling. §2.14 is left
as written, carrying its own divergence note; this entry is the closure. **No manuscript change.**

## 6.2 Book 2 Ch 11 — what was applied 2026-08-29, and by whom

**Two sessions touched this passage on 08-29 and this file recorded neither.** `Job25` applied
three substitutions in the morning; the rest of its drafting was composed in conversation and
**never written to the manuscript**, which `job27` found by comparing the master against
`Job25`'s own set note. `[A]` supplied the lost material as
`APPLY-job25-drafting-20260829.md` and `job27` applied it. Blocks marked OPEN in that file were
not applied as agreed; the two open sentences were settled by `[A]` in session and are noted below.

| Site | Was | Is |
|---|---|---|
| the more-stable paragraph, opening | `Detachment leaning toward enthusiasm is more stable than it sounds, because it holds itself in place.` | `That giving way sounds slack, and it is not — it holds a person in place.` |
| same paragraph, second sentence | `The wariness left over from caution meets the wanting that draws toward comfort` | `A fear arriving from the cautious orientation meets the desire for comfort` |
| same paragraph, fourth sentence | `the blind end` | `that blind state` |
| same paragraph, close | `the caution being carried past detachment rather than let go of — on detachment reached by surrendering to fear` | `the fear being carried past detachment rather than handled — on detachment reached by reactively avoiding fear` |
| the paragraph above it | `protects that giving-way` | `protects that giving way` |
| the two-positions paragraph | `the remnant of caution is real and the realm is seen` | `the remnant of caution is real and fears are seen` |
| same paragraph | `sees a realm with tranquil clarity` | `sees into a realm with concerned clarity` |
| same paragraph | `forgetfully blind` | `unconsciously but militantly blind` |
| same paragraph | `, and every degree between them is occupied` | *cut* |
| the how-much-is-known paragraph, opening | `How much is seen is a fact about a realm.` | `How much of a realm a person knows is a fact about that realm for them, and it depends on where on the cycle of orientations their fixation is.` |
| same paragraph | `A fixation in detachment is one route to a realm being little seen, and it is the route described here, but nothing in it says a person is doing detachment in that realm.` | `For a fixation in detachment a cautious lean is starkly different from an enthusiastic lean. A realm can go little known for other reasons; this is the route that runs through detachment.` |
| same paragraph, close | `Vision and blindness are the two ends of one orientation, reached by opposite routes.` | `Detachment takes a realm in whole, and takes it in directly — not assembled out of pieces, but seen as it is. Detachment sees the same either way. What differs is how much of what it sees a person is allowed to know.` |
| end of *Disregarding, and not seeing at all* | — | the three fates of a fear, four paragraphs, closing `Only a blocked fear is a failure of seeing.` |

**Rulings behind the wording, all `[A]`, 2026-08-29.** It is *fear*, not *wariness*, that is carried
past detachment — wariness has no content, so there is nothing to bury. A position on the circle
cannot be *stable* or *unstable*; what is held is the person, which is why the opening sentence
moved its predicate. `know`, not `see`, names the quantity that varies with fixation, `see` being
reserved by the whole-realm ruling for the invariant. *reached by opposite routes* is the retired
backward mechanism.

**`[A]` rejected `that easy wanting` as the referent** for what the not-seeing protects: the wanting
is enthusiasm's and exists regardless, while what insight would interrupt is the going-along.
`yielding` and `surrender` were both rejected as already spent — `yield` stands eight times in book 1
and twice in book 2 in the *produces* sense; `surrendered to` is the three-fates term for giving up
on a fear.

**Left out deliberately:** the knowing profiles of the three orientations — A knows the superficial
and easily understood, B knows more about the complicated aspects of certain parts and misses others
more completely, Z sees the whole picture but attends only to parts. `[A]` gave these in session.
They are unruled and unsited and belong where the orientations are introduced; writing them into
Ch 11 would site them by default.

## 6.3 Book 1 — applied 2026-08-29 by `job27`

| Site | Was | Is |
|---|---|---|
| Ch 11, the Z− / Z+ sentence | `forgetfully blind` | `unconsciously but militantly blind` |
| same sentence | `, with every degree between them occupied` | *cut* |
| the future-questions list, Jungian integration | `Can the modelsSENTINEL be synthesized?` | `Can the models be synthesized?` |

`forgetfully blind` fuses forgetting and blindness, ruled apart 08-27, and a drafting session
grepping book 1 would carry the fusion forward. The occupancy clause was the third statement of
not-binary in one sentence — the same sentence already says *one quantity varying continuously, not
two conditions with a boundary between them* — and it additionally commits to the whole angular span
being occupiable, which is open, `[A]` having flagged that caution's forward lean may never reach
detachment's backward one. `SENTINEL` occurred nowhere else in the set, so it was a corruption, not
a marker.

**Divergence recorded and deliberately NOT repaired:** book 1 keeps `tranquil clarity` where book 2
now has `concerned clarity`. Under §6.0, *tranquil* is not false, so it stays.

## 6.4 Live files after this session

`rev2-0814e.md` supersedes `rev2-0814c.md` and the intermediate `d`.
`BOOK2-20260829f.md` supersedes `BOOK2-20260829.md` and the intermediates `b` through `e`.
`setcheck.py` keeps its name across its 08-29 revision; the manifest md5 is what identifies it.

---

# PART 7 — LATER IN THE SAME SESSION, `job27-defects-20260829`

## 7.1 Applied after Part 6 was written

| Book | Was | Is | Why |
|---|---|---|---|
| bk2, opening of *Disregarding, and not seeing at all* | `Only the first is chosen.` | `Only declining to attend is chosen.` | `[A]`'s standing rule: never name a case by its position in a list. Book 1 has no twin. |
| both, the pure-detachment paragraph | `residue` in the lean sense, 3 sites per book | `trace of` | `residue` was doing three jobs. `[A]`: the `trace of` form is the acceptable one. |
| bk2, the leans paragraph | `The leans are what fund the difference. Leaning back toward caution, the lean funds attention… the lean funds an aversion to looking` | `The leans are what make the difference. Leaning back toward caution, residual vigilance keeps a person watching… the lean turns a person away from looking` | see 7.2 |
| bk1, the Z0 apex paragraph | `at Z− the lean toward B funds attention — residual vigilance keeps one watching; at Z+, the lean toward A funds an aversion to looking` | `at Z−, residual vigilance keeps one watching; at Z+, the lean toward A turns one away from looking` | the metaphor was followed by its own explanation; the explanation is enough |
| bk1, mobility asymmetry | `descent is funded by unwatched reaction` | `descent runs on unwatched reaction` | |
| bk1, appendix, reception at realm-Z0 | `attention is funded horizontally` | `what is attended to is settled horizontally` | |
| bk1, the 9's growth | `withdrawal buys peace in neither` | `withdrawal brings peace in neither` | |
| bk1, the observer's compound feeling | `the residual tax of watching that Z− still pays` | `the residual watching that Z− is still doing` | |

`fund`, `funds` and `funded` now occur **zero times in either book**.

## 7.2 `[A]`'s ruling on metaphor, 2026-08-29 — THE CENSUS BELOW IS WORK, NOT A NOTE

**`[A]`, on `fund`:** it is *claude's default use of an inappropriate metaphor to save a few
words*, and he has corrected it repeatedly across sessions. Book 1 showed why it fails: the
sentence read *the lean toward B funds attention — residual vigilance keeps one watching*. The
mechanism is stated immediately after the metaphor, so the metaphor compresses nothing and only
delays the explanation. Book 2 had dropped the explanation and kept the metaphor.

**`[A]` then widened it, asked directly:** *even the economic language cases useful in arguments
are too remote of metaphors for this context.* `[C]` had proposed sparing the sites where the
exchange is the argument — the psychic realm's goods growing by being spent, producing cheap and
testing expensive, a calibration claim being spent. **That proposal is overruled. They are in
scope.**

**`[A]`'s instruction for the next session, verbatim in substance:** work on these metaphors
**including the ones that will be difficult to replace.** The difficult ones are the point. A
site is not closed by being judged hard, by being judged dead-metaphor, or by being judged
load-bearing. Each one gets a mechanism named or a ruling from `[A]` that it stays.

### The census, counted 2026-08-29 against `BOOK2-20260829i.md` and `rev2-0814g.md`

**94 sites: 36 in book 2, 58 in book 1.**

| word | bk2 | bk1 | | word | bk2 | bk1 |
|---|---|---|---|---|---|---|
| cost | 9 | 12 | | paid | 2 | 2 |
| spent | 5 | 7 | | pays | 1 | 2 |
| earned | 4 | 4 | | costs | 3 | 2 |
| price | 2 | 5 | | spending | 2 | 1 |
| goods | 2 | 1 | | investment | 1 | 1 |
| leverage | 1 | 3 | | budget | 1 | 1 |
| earns | — | 3 | | costly | 1 | 1 |
| spend | — | 3 | | bargain | 1 | — |
| earn | — | 2 | | rationed | 1 | — |
| expensive | — | 2 | | spends, buys, afford, cheap, pay, purchase | — | 1 each |

**Known traps in that count, none of them permission to skip a site.**

1. **`leverage` in book 1's *The Problem of Leverage* is mechanical, not economic** — a lever and
   a footing, and the chapter's argument is that no one gets a footing on themselves. Removing it
   would remove the argument. **Put it to `[A]` as a named exception; do not decide it in session.**
2. **`spends one or two degrees of freedom`** in the statistics appendix is standard usage in that
   field, in a place a technical reader expects it. Same handling: put it, don't decide it.
3. **The engineers' contingency budget** in the Daniel/Marcus vignette is literal money in a scene
   about engineers. Not a metaphor. It stays and needs no ruling.
4. **Dead metaphors are still sites.** `costly` for *expensive* is one. The test `[A]` set is
   remoteness from this context, not whether a reader still hears the ledger.

### SCOPE RULING, `[A]` 2026-08-29 — BOOK 1 IS NOT SWEPT FOR METAPHOR

**Asked whether book 1 needs updating, `[A]` ruled the two halves apart.**

**Book 1 IS repaired wherever it says something false** — the backward lines, conditions ruled
apart and still fused, anything asserting what has been ruled out. This follows from book 1 being
the source book 2 is drafted from: a reader meeting a false sentence is misled once, a drafting
session meeting it carries it into new text, where it has to be found again. Not optional.

**Book 1 is NOT swept for metaphor.** 58 of the 94 sites are in book 1, and that is most of a pass
spent on a book no reader may ever see. Instead:

- **the rule goes in the handoff**, so every future drafting session applies it to what it touches
  — including the material book 2 has not reached, which a book 1 sweep could not have covered;
- **book 1's metaphors are fixed only in the paragraphs a session is already drafting from.**

**The evidence behind the split, and the reason the rule cannot simply be dropped:** `fund` was in
book 1 first, in the Z0 apex paragraph, and reappeared in book 2's twin. **The source's vocabulary
propagates, not only its claims.** A handoff rule catches that at the moment of transfer; a sweep
of book 1 would not have caught it at all, since book 2's copy was written before any sweep.

**Do not repair a book 1 metaphor in order to match book 2.** Under `[A]`'s answer about what book 1
is for, book 2 running ahead is not a defect, and matching the twins is what let them drift in the
first place — one book repaired, the other not.

**Line numbers.** Book 1 is cited by `L####` across several notes. Today's edits held the line count
because every one was within a line. A pass that reflows paragraphs will not. Check with
`quotecheck term` before and after.

**Consequence for `job28`:** the metaphor pass is book 2 only, 36 sites. With the backward sort that
is one session's work rather than two.

### How this pass should run

The `fund` fix is the model: **name the mechanism the metaphor was standing in for.** Where no
mechanism can be named, the sentence is making a claim nobody has stated, and that is the finding
— report it rather than paraphrasing it into different vocabulary. Where the exchange is genuinely
the claim, the site goes to `[A]` with the sentence quoted, not silently kept.

Book 2 only, per the scope ruling above. Where a book 1 paragraph is being drafted from at the
time, fix it then.

## 7.3 Also carried to `job28`

- **`backward` still drafted in both books** — 14 lines in book 1, 6 in book 2, counted by `Job25`
  and never sorted by kind. Some are the retired mechanism and false; some are register 3,
  describing the classical figure's arrows, and stay. **The sort needs `[A]` line by line.**
  Book 2's Ch 7 has `Forward` and `Backward` as section headings with three transitions written
  under them — a structural decision, not a substitution. Report rather than restructure.
- **`bridges theory and practice`, bk1 L136** — filler metaphor, unfixed, low stakes.
- **The section *Disregarding, and not seeing at all* announces three things and treats two.**
  The third — where looking has stopped there is nothing left to decline — is a consequence of the
  second rather than a separate case. May be correct as written. Not settled.
- **The old close of that section**, `So asking whether a lean is something a person does or
  something they are…`, no longer closes it: the three fates now follow it. Reads acceptably;
  `[A]` may want it moved.

## 7.4 Live files at the end of this session

`rev2-0814g.md` · `BOOK2-20260829i.md` · this file, `REPAIRS-job16-book1-defects-20260825d.md`.
All earlier letters quarantine.

---

# PART 8 — THE BOOK 2 METAPHOR PASS, RUN AND CLOSED, `job27-defects-20260829`

**`[A]` chose to run it in this session rather than hand it on**, saying he would spend consecutive
sessions if one could not finish it. Book 2 finished in one. **Book 1 remains out of scope**, `[A]`
confirming Part 7's ruling when asked again directly.

## 8.1 What was changed

24 sites. Nineteen in one pass over the ordinary-usage group, then `budgets every effort`, then four
found only by rescanning. The full before/after strings are not repeated here; the pattern is:
**name what is actually lost or done, rather than pricing it.** Examples: self-sufficiency *leaves
them short of* intimacy; hardness *has kept them from* intimacy; relationships *have suffered for*
the need to keep moving; suspicion *nobody has done anything to deserve*; pleasure pursued only where
it *demands nothing*; looking that stops where it would *take something from them*; detachment
entered *with the sight that understanding gave*; the vignette closes now read *the trouble is the
echo*; Daniel *weighs out* every effort; enthusiasm *plays down* risk; the Nine's seeing is the
*least recognised* competence.

**Live master at the close of the pass: `BOOK2-20260829l.md`.**

## 8.2 EXEMPT — do not reopen

**The realm-economics passage, bk2 L400–L476, ~21 sites including the `economy` thesis sentence.**
**`[A]`, 2026-08-29: the economics there is close enough to literal.** The passage's claim is that
the physical realm genuinely works that way — finite resources, spending depletes them — and that a
Five carries that real arrangement into a realm where it does not hold. **The vocabulary is the
subject, not a figure.** Remove it and the error being described has no name. This is not the same
as the overruled proposal in Part 7, which would have spared *live* metaphors on the grounds that
they carried an argument; this passage is exempt because its economics is not a metaphor at all.

Also exempt, agreed with `[A]`: the Eight's *force, position, and leverage* (physical); the
engineers' *contingency budget* (literal money, engineers arguing over a real line item); `weigh`
and `weighed` throughout (scales); *realms exchanged* (a swap); and `discount` at L709 meaning
dismiss, where the ledger sense is dead and every alternative reads heavier.

**Flagged, NOT changed, because it is doctrine and not style:** `gain`, in *focused on possibility
and gain*. That phrase is part of how enthusiasm is defined. **`[A]` has not ruled on it.**

## 8.3 THE CENSUS METHOD FAILED TWICE — `job28` MUST NOT TREAT A COUNT AS A TARGET

1. **Missing words.** The first list omitted `resources`, `exchange rate`, `repay`, `arithmetic`,
   `discount` and `weighed` — all inside the one passage that mattered most.
2. **Missing inflections.** It held `budget` and not `budgets`, so a real metaphor two sentences from
   an exempt literal one went unseen.
3. **Stemming is not the fix.** A stemmed rescan returned 87 hits, most of them noise: the stem `fee`
   matched `feel`, `feels`, `feeling`, `feedback` — in a book where feeling is a core term. It did
   surface `economy`, `discounting`, `discounts`, `credited` and `credit`, which no earlier list held.

**Conclusion for the backward pass and any future census: the count is a starting list, never a
total, and never a target to work down to. The passage has to be read.**

---

# PART 9 — `job28 defects 8-29`: THE BACKWARD CENSUS, APPLIED

**Session:** `job28-defects-20260829`. Set: `MANIFEST-job28-20260829.md`, 34 ok / 0 mismatched /
0 bad count / 0 missing / 0 not in manifest. Text session; the record was NOT opened at all. Its
reach was confirmed through `setcheck.py sweep` only: 17,506 w, seventh append, parent 16,861.
All eight figures were absent from the set and were sent by `[A]` in session, in two batches.

Unlike Parts 1–8, **every substitution in this Part is APPLIED**, not drafted. Files below.

## 9.1 THE RULING THAT RESET THE PASS

`[A]`, this session, in three steps:

1. **The disintegration direction is not a movement.** It is a temporary lean caused by stress.
   That kind of backward is ALLOWED, because it is not motion of the endeavor cycle.
2. **`runs the loop` means `applies to the whole loop`** — the direction holds at every position.
   Not wrong, but misleading, because `runs` is the traversal verb everywhere else in both books.
3. **A stress transition is a lean-sized change IN THE FIXATION.** The six transition
   passages in the two books are therefore CORRECT AS THEY STAND, provided the surrounding
   text makes clear they are lean changes and not process motion.

This overturned two earlier calls made inside this same session: that the figure needed a redraw,
and that the six transitions needed rewriting. **Neither was done.** The proposed rewrite of book 1's
A → Z transition was withdrawn before it was written.

## 9.2 APPLIED — the `runs` collision (5 sites, 2 books)

`runs` was doing two jobs: an arc runs (traverses), and a direction runs (holds at every position).
Same shape as `residue`, `step`, `cycle`. Each string verified unique before writing, read back after.

| Book | Was | Now |
|---|---|---|
| 1, figure caption | `integration runs A → B → Z ... disintegration runs the reverse` | `integration is the direction A → B → Z, entering detachment on its seeing side; disintegration is the reverse direction, entering on its blind side.` |
| 1, Ch 5 | `under stress the same loop runs backward` | `under stress each orientation instead leans toward the one before it` |
| 1, Ch 5 | `It runs A → Z → B → A.` | `It holds at every position on the loop: A leans toward Z, Z toward B, B toward A.` |
| 2, Ch 7 | `Moving with the order is **integration** ... Moving against it is **disintegration**` | `The pull that goes with the order is **integration** ... The pull that goes against it is **disintegration**` |
| 2, Ch 8 | `Disintegration runs the same lines backward. ... each realm retreats along its own loop instead of advancing,` | `Disintegration is the same lines read backward. ... each realm pulled toward the orientation behind it rather than the one ahead,` |

The book 2 Ch 7 site sat two lines under that chapter's own **`This is a statement about directions,
not about motion.`**

## 9.3 APPLIED — the twin summary sentence (2 sites, 2 books)

`[A]`: *"that looks to me like an incorrect claim of process motion, not of fixation lean."*
The transitions are leans; the sentence summarizing them made a person travel into detachment.

| Book | Was | Now |
|---|---|---|
| 2, Ch 7 | `Coming forward, a person enters it seeing, with the sight that understanding gave. Coming backward, a person enters it blind, as shutdown.` | `A lean from caution shows it seeing, with the sight that understanding gave. A lean from enthusiasm under stress shows it blind, as shutdown.` |
| 1, Ch 5 | `Detachment is thus entered from either side, and the two entries differ: integration (B → Z) enters it seeing, with the sight that understanding earned; disintegration (A → Z) enters it blind, as shutdown.` | `Detachment thus appears from either side, and the two appearances differ: a lean from caution (B → Z) shows it seeing, with the sight that understanding earned; a lean from enthusiasm under stress (A → Z) shows it blind, as shutdown.` |

**Every `seeing` and `blind` word was left exactly in place.** These are the seeing/blind pair, which
the naming pass owns and which `know` does not transfer to. See §9.7.

**Both of these are now themselves DEPRECATED** — see §9.5. They still make the lean's DIRECTION the
reason for blindness, and Ch 11 does not.

## 9.4 THE REAL DEFECT: Ch 7 / Ch 5 MAKES THE ROUTE THE CAUSE OF BLINDNESS

Chapter 7 (book 2) and Chapter 5 (book 1) both explain the blind arrival by HOW the person came:
*arriving by collapse rather than understanding*. **Book 2 Ch 11 replaces this outright.** Blindness
is laid down at the crossing, by what became of a fear there:

> A fear arriving from the cautious orientation meets the desire for comfort, and the two interact
> badly: an aversion meets an aversion to that aversion, and the second wins ... It depends on the
> fear being carried past detachment rather than handled — on detachment reached by reactively
> avoiding fear rather than by relinquishing it.

and the four fates of a fear that follow it, closing on **`Only a blocked fear is a failure of seeing.`**

On this account **the route causes nothing.** The lean decides only whether a fear gets looked at;
the blocking does the rest. A blind arrival and a seeing one differ in what became of the fear.

**This is a whole replacement, not a repair, and this session did NOT write it.** It moves the cause
of blindness from Ch 7 to Ch 11 and so decides what Ch 7 is for and how it hands off.

## 9.5 APPLIED — five DEPRECATED markers in book 1

`[A]` approved marking book 1's incorrect parts in place. **In the file, never a separate one:**
every status file this project has made has fallen out of the set or gone stale. Book 1 is one
paragraph per line, so a marker at the head of a paragraph returns on the same line as every grep
hit inside it — it cannot be missed by the search that would carry the error forward.
Single literal `[DEPRECATED` so it can be counted. Book 1 is not sent outside the project.

**Text A** (blindness by route) — `[DEPRECATED — blindness explained by the route taken. Superseded by book 2 Ch 11's crossing account: a fear carried past detachment rather than met. Do not draft from this.]`

- L554, the figure caption
- L576, the `A → Z (under stress)` transition
- L582, the summary sentence repaired in §9.3

**Text B** (disintegration as motion) — `[DEPRECATED — disintegration written as motion. It is a lean-sized change of position, not a process. Do not draft from this.]`

- L586, `The walkthroughs above ran the whole loop` — counts the backward walkthrough as a run,
  four sentences before the same paragraph says complete loops always run in the integration direction
- L598, `The cycle describes the _direction_ of a person's movement`, in Direction and Depth —
  a motion word in the passage grounding the ruling that direction and depth are independent positions

**Open with `[A]`, raised and not answered:** the L576 marker sits on a paragraph `[A]` explicitly
called correct as it stands. Only its closing clause is at fault. A marker attaches to a paragraph
and book 1 is one paragraph per line, so approved text is inside the mark. `[A]` may lift it and let
L582 carry the fault alone.

**NOT marked, deliberately:** L590, `These cycles describe actual psychological processes, not
theoretical constructs.` Plural, and disintegration is not a process. But this is a LIVE question
with a ruling owed — flagged 08-19, unresolved — and marking it deprecated would file a question as
an answer. Ch 5's title `The Psychological Reality of the Cycle` carries the same weight.

## 9.6 BOOK 1 HAS NO CROSSING ACCOUNT — BLOCKED ON `[A]`

Searched: no `carried past`, no aversion meeting an aversion to itself, no four fates, no
`failure of seeing`. Book 1's only aversion material is caution's definition and the basic fear at
the floor of Appendix G. **The replacement for book 1's Ch 5 exists only in book 2.**

So book 1's half is caught between two standing rules: it is FALSE, so *repair book 1 where false*
says fix it; but writing book 2 Ch 11 into book 1 is BACK-PORTING, out of scope in each of the last
two set notes, and adjacent to the prohibition on repairing a book 1 passage to match book 2.

The markers are the interim answer. The permanent one needs `[A]` to say what book 1 is for — the
same question he gave a first, uncertain answer to on 08-28. If book 1 is only the source book 2 is
drafted from, deleting the false claim and leaving the gap suffices. If it is a book, it needs the account.

## 9.7 THE SEEING / KNOWING MESSAGE, RELAYED BY `[A]` IN SESSION

Not in any file in the set. Carried here verbatim so it is not lost again:

> On the seeing/knowing naming — read this before you touch any sentence with `seeing` in it.
> `OPEN-from-job25-20260829.md` §3 records a ruling of `[A]`'s: the detached orientation sees into a
> realm as a whole regardless of how much of what it sees reaches consciousness. Seeing is the
> invariant. Both books use the seeing family for the quantity that varies, which under the ruling is
> backwards, and §3.2 lists the sites. The ruling deliberately left the word open. Nobody writes a
> substitution on the strength of it. That still holds.
> What has changed since that file was written is that one site now has a word. In `job27` the Ch 11
> paragraph beginning How much of a realm a person knows was rebuilt with `[A]` in session, and he
> chose `know` for the varying quantity, leaving `see` for the invariant. The before and after strings
> are in `REPAIRS-job16-book1-defects-20260825e.md` Part 6. The paragraph now runs the one quantity
> through from the fixation to the lean and reads better for it.
> So: `know` is a precedent, not a ruling. If your work brings you to a site on the §3.2 census, use
> `know` or stop and ask him — the failure to avoid is a second word being chosen at a second site
> because the first choice wasn't visible. It doesn't transfer everywhere: the blind face and the
> seeing face are a named pair, and the two load-bearing sites — book 1 L1490 and L2294, the
> destruction of the seeing itself that grounds Ch 16's mobility asymmetry — need rewritten sentences
> rather than a swapped word, as §3.2 already says.
> Do not run the naming pass. It is about twenty sites across two books and it is not your job.
> Report anything you touch.

**Touched this session:** two sites, both in §9.3, both in the seeing/blind PAIR rather than on the
§3.2 census. No `seeing` or `blind` word was moved, added or removed. No §3.2 site was opened.

## 9.8 THE FIGURES — ALL EIGHT CHECKED, NONE NEED CHANGING

Checked by reading label text and arrowhead geometry, not by grepping — a figure can hold a claim in
a direction with no text at all, which is how the wing error survived.

**The census could not have reached `orientation-cycles.svg` without `[A]` sending it.** Its claim
lives in three arrowheads and one label. No text search over the set would ever have returned it,
and its caption in book 1 states the same thing a third time. **A census whose subject can appear in
a figure is not complete until the figures are in the set.** Ask for them in §1.0, not later.

`orientation-cycles.svg` draws two panels: `Integration (forward)` running A → B → Z → A, and
`Disintegration (reverse)` running A → Z → B → A. Under §9.1 both panels draw LEAN directions, so
the arrows and the label are ALLOWED and **the figure is correct as drawn.** An earlier call in this
same session — that it needed redrawing, and that no convention existed for depicting a skipped
passage — was overturned by `[A]`'s ruling and NOT acted on.

The other seven hold no direction claim. The only `reverse` strings in any SVG are
`orient="auto-start-reverse"` arrowhead attributes. `opposite-relationship.svg` is the corrected
file: geometric title, and its labels match book 1's prose word for word.

## 9.9 CENSUS METHOD — §8.3's LESSON HELD

`backward` alone returned 14 sites in book 1 and 6 in book 2. Widening past the single word found
three more in book 1, **including the figure caption**, which no count of `backward` would ever reach.
Of the ~23 sites, five needed the `runs` repair, two needed the summary repair, five got markers, and
the rest — leans, grid directions, reading order, the appendix's reversed walk, the glossary's
`step of stress` — were CORRECT AS DRAFTED and were not touched.

**A count is a starting list, never a total. The passage has to be read.** Second consecutive session
in which this held.

## 9.10 FILES OUT OF THIS SESSION

| File | Words | md5 | Lines |
|---|---|---|---|
| `rev2-0814j.md` (book 1) | 56,384 | `d5bfc25b7490d7867aaf30190cf37df3` | 2,566 |
| `BOOK2-20260829n.md` (book 2) | 17,699 | `d3ad6aac80de86b3436d9f8ea6b81d4a` | 868 |

**Line counts are unchanged in both books through every edit and every marker**, so every line
citation in the set still lands. Quarantine `rev2-0814g/h/i` and `BOOK2-20260829l/m`.

**Typo found in a sentence being edited and NOT fixed, because it is not this pass:** book 1 L556,
`as if though their real fixation isn't`.

---

# PART 10 — `Job29 book 2 ch 7 drafting 8-30`: THE CH 7 BLINDNESS ACCOUNT, AND THE JOB18 RULING APPLIED

**Session:** `Job29 book 2 ch 7 drafting 8-30`. Set: `MANIFEST-job28out-20260830.md`, 42 ok /
0 mismatched / 0 bad count / 0 missing / 0 not in the manifest, verified after unpacking. Screen
fires two, both benign. **Text session; the record was opened only at the end, after all
substitutions were applied and read back, per `[A]`'s standing solution of 2026-08-29.**

**The set arrived under a label naming no session** — `job28out-20260830`, which names `job28`'s
outputs. There is no set note from `job28`, no `OPEN-` file from it and no forward manifest, so the
next session's set was never cut and this is `job28`'s closing directory. `[A]` supplied the name.

**Every substitution below is APPLIED**, each string verified to occur exactly once before writing
and read back after.

## 10.1 Ch 7's blind arrival — the route no longer carries the cause

Part 9.4 named the defect: Ch 7 and book 1 Ch 5 explain the blind arrival by *arriving by collapse
rather than by understanding*, and Ch 11 lays blindness down at the crossing instead.

**Part 9.4's reading is half right, and the half matters.** Ch 11 keeps the route for the SEEING
side, in the same words Ch 7 uses — *leaning back toward caution, detachment has been arrived at by
way of understanding, and the sight gained there is retained*. Only the blind side is replaced. So
**Ch 7's forward `B to Z` passage is not false and was NOT touched.**

| Book | Was | Now |
|---|---|---|
| 2, Ch 7 `A to Z` | `Arriving by collapse rather than by understanding, they enter detachment on its blind side.` | `They enter detachment on its blind side.` |
| 2, Ch 7 heading | `### The two ways into detachment` | `### Detachment's two faces` |
| 2, Ch 7 lead-in | `Detachment is therefore entered from both sides, and the two arrivals are not the same thing.` | `Detachment therefore shows two faces.` |

**Nothing of Ch 11's machinery was imported.** The cause is already in the sentence above the cut
clause — *the wanting does not vanish; it survives as carelessness … hazards simply no longer looked
at* — which is Ch 11's blocking in Ch 7's own words. **The decision this settles, and it was the one
`job28` said it could not make:** Ch 7 describes the two faces and names the lean directions; the
crossing mechanism stays in Ch 11 and is not restated four chapters early. Same shape as R10a.

The heading and the lead-in were the *entered from either side* framing `[A]` rejected on 08-29.
Part 9.3 repaired the sentence under the lead-in and left the lead-in itself standing. The retired
heading occurs nowhere else in either book.

## 10.2 `job28`'s DEPRECATION OF ITS OWN SUMMARY SENTENCE LOOKS WRONG — `[A]` TO DECIDE

Part 9.3 marks its own two repaired sentences deprecated, and book 1 **L582 carries the marker**.
The stated ground is that *a lean from enthusiasm under stress shows it blind* still lets the lean's
direction be the reason.

**Book 2 Ch 11 says the direction of the lean IS the reason**, in as many words: *Which face appears
is set by the direction of the lean, because detachment's two neighbours are what produce them* —
the backward lean retaining the sight gained at caution, the forward lean's not-seeing protecting the
giving way. The lean is upstream of the blocking, not a rival account to it. **On that reading L582
is correct and its marker should lift.** Book 2's twin was left standing for the same reason.

**Not repaired either way. This is a finding for `[A]`, not a change.**

## 10.3 THE JOB18 RULING OF 2026-08-25, APPLIED IN BOTH BOOKS — five sessions late

`RULINGS-job18-20260825.md` Part 1 has held this with exact strings since 08-25, ruled and unapplied.
Both strings still matched exactly once in the copies held here. **One defect, three sites.**

| Book | Was | Now |
|---|---|---|
| 2, Ch 7 | `Everyone's thoughts make all three passages; what distinguishes people is where those thoughts habitually come to rest. That is what a fixation is — not a place a person stands, but the place they habitually stop.` | `Everyone's thoughts make all three passages; what varies is what those thoughts are about.` |
| 1, Ch 5 L594 | `What distinguishes people is not which passages their thoughts make — everyone's make all three — but where those thoughts habitually come to rest. ` (trailing space included) | deleted whole |

Book 1's join was read back: *…a completed thought makes all three in the cycle's forward order.
When one thought ends the next arises conditioned by it…*

**Book 1 was taken although this session's name says book 2.** Grounds: applying a prepared list
with exact strings is what a text session is permitted to do, and the ruling calls the two books one
defect, so applying half would leave book 1 asserting what book 2 had just stopped asserting. That
drift is the pattern this project keeps hitting.

**A consequence, not an edit.** The inherited `comes to rest` collision — every thought resting *in
turn* at all three against thoughts *habitually* coming to rest at one — was carried by the deleted
sentence in each book. Both books now use the phrase in the transient sense only. **The word does
one job again and there is nothing left to repair.**

## 10.4 THE EXCURSION SENTENCE — book 2's twin of a marked book 1 line

Part 9.5 marked book 1 L586 DEPRECATED for writing disintegration as motion. **Its book 2 twin was
neither marked nor repaired**, and it sits inside the list of arc scales, between *whether a whole
arc ever completes depends on the scale* and the bounded-undertaking case — so the excursion reads
as an arc partly run. That is the conflation `[A]`'s tolerance is expressly conditional on avoiding:
*as long as it's clear that it's a lean change and not process motion.*

| Book | Was | Now |
|---|---|---|
| 2, Ch 7 | `A person's fixation is home, and what happens are excursions — a single step forward or back, and then a return.` | `A person's fixation is home, and what varies is the lean — which way they are pulled from it, and how far. That is a change of position, not a passage run.` |

Book 1's twin keeps its marker; lifting it is `[A]`'s.

## 10.5 THE L556 TYPO, FIXED

Found by `job28` in a sentence it was editing and left as outside its pass.

| Book | Was | Now |
|---|---|---|
| 1, Ch 5 L556 | `as if though their real fixation isn't` | `as if their real fixation were not` |

## 10.6 THE FOLD CHECK, RUN — `job28`'s practice, and it works

`job28`'s message about the lost turn is reproduced whole in this session's set note and goes to the
handoff as a practice. **It was run here at the point the message specifies**, before assembling.

The working directory held 43 files: the 42 in the arrival manifest, every one still matching its
hash, plus `BOOK2-20260830.md`, the one file written. `diff` against its parent returned three
single-line substitutions with no insertion or deletion elsewhere, and `BOOK2-20260829n.md` still
carried the md5 its manifest row declares, so the parent was not edited in place. **The word drop
confirmed the diff independently: 17,699 → 17,679 is −20, exactly seven words from the transition,
two from the heading and eleven from the lead-in.** Two commands, and nothing was concluded from
recollection.

## 10.7 FILES OUT OF THIS SESSION

| File | Words | md5 | Lines |
|---|---|---|---|
| `rev2-0814m.md` (book 1) | 56,362 | `26e3d1cc772238ac88d295060b90544f` | 2,566 |
| `BOOK2-20260831.md` (book 2) | 17,669 | `0fe6ff3e1d0452bbb788112422c028f8` | 868 |

**Line counts unchanged in both books through every edit**, so every line citation in the set still
lands. Quarantine `rev2-0814j.md`, the intermediate `rev2-0814k.md`, `BOOK2-20260829n.md` and the
intermediates `BOOK2-20260830.md` and `BOOK2-20260830b.md`.
