#!/usr/bin/env python3
"""setcheck.py - version 1.8, 2026-08-24

Read-only checks for the book project. It NEVER renames, moves, copies or
deletes anything. Renaming is quarantine.py's job and a `SUPERSEDED__live__`
rename is done by hand; this tool only looks and reports.

Subcommands
    sweep     find every handoff-shaped file in a tree, by content, and read
              its version line. Answers "where did HANDOFF-<date>.md go".
              Also lists append-only records by their RECORD MARKER, which is
              the only thing that can date a copy of a file that carries no
              date on its name and has no successor.
    bare      every project file OUTSIDE the live directory that carries no
              status on its name. sweep only sees handoffs; this sees the rest.
    screen    the pre-assembly restriction screen: which candidate files carry
              a restriction string or a restricted-name prefix.
    verify    check files against a manifest's md5 and word counts.
    manifest  write a manifest for a named set.
    stage     compare a download folder against the live directory and PRINT
              the mv commands that would install it. Prints only - see below.
    count     print the canonical word count for files.

THE CANONICAL WORD COUNT
    `LC_ALL=C wc -w`. The locale is not decoration: the same tool under
    `C.UTF-8` returns a higher figure, because in the C locale wc does not
    count a whitespace-delimited token that holds no ASCII printable
    character - a standalone em dash between spaces is not a word. These files
    are full of those. count_words() below reproduces `LC_ALL=C wc -w` exactly
    and needs no wc, so it gives the same answer on any platform.
"""

import argparse
import hashlib
import os
import re
import sys

RESTRICTION_STRING = b"does not go into a drafting set"
CARRY_NOREAD_STRING = b"travels in every set and is not read by a text session"
# Both tools hold the screen's literals as their own search strings, so
# both match themselves. Exempted by name, and the exemption is printed.
TOOL_NAMES = ("setcheck.py", "quotecheck.py")
HANDOFF_MARKER = b"HANDOFF"
RESTRICTED_PREFIXES = ("JOB6-ONLY__", "VOID__", "SUPERSEDED__")
COLLISION_RE = re.compile(r"(_\d+|\(\d+\))(?=\.[^.]+$)")
TEXT_SUFFIXES = (".md", ".txt", ".py", ".svg")
# .py belongs here: the checker and quarantine.py are project files too, and
# a tool that cannot see itself cannot tell you it is stale.
PROJECT_SUFFIXES = (".md", ".svg", ".zip", ".csv", ".docx", ".py")


def count_words(path):
    """Reproduce `LC_ALL=C wc -w` exactly, without calling wc."""
    with open(path, "rb") as fh:
        data = fh.read()
    return sum(1 for tok in data.split()
               if any(0x21 <= byte <= 0x7E for byte in tok))


def md5_of(path):
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


SKIP_DIRS = {".git", ".cache", ".local", ".config", ".venv", "venv",
             "node_modules", "site-packages", "__pycache__", ".npm", ".cargo"}


def walk(root, suffixes=TEXT_SUFFIXES):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if d not in SKIP_DIRS and not d.startswith(".")]
        for name in sorted(filenames):
            if suffixes is None or name.endswith(suffixes):
                yield os.path.join(dirpath, name)


def read_bytes(path, limit=None):
    with open(path, "rb") as fh:
        return fh.read() if limit is None else fh.read(limit)


def version_line(path):
    """First line that looks like a version declaration, or None."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            stripped = line.strip().lstrip("> ").strip()
            # A version line starts with the backticked filename. Matching on
            # "words**" alone picked up body prose that merely mentions a count.
            if stripped.startswith("`HANDOFF") and "words" in stripped:
                return stripped
    return None


RECORD_MARKER = b"RECORD MARKER"
# What an append-only record declares about itself, in its own rules block.
# Detection is by content, never by name - the whole point is that this
# file's name carries nothing.
RECORD_SHAPE = b"Append only."


def record_marker(path):
    """Last RECORD MARKER line in an append-only record, or None.

    The author record carries no date on its name and has no successor, so
    neither the naming convention nor the quarantine prefix can date a copy
    of it. Because it is append-only a stale copy is not wrong, only short,
    which leaves no internal evidence. The marker supplies the evidence; the
    LAST one is the live reach, since each append writes a new one below.
    """
    found = None
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            stripped = line.strip().lstrip("> ").strip()
            if stripped.lstrip("*").startswith("RECORD MARKER"):
                found = stripped
    return found


def cmd_sweep(args):
    """Find handoff-shaped files by content, never by name."""
    hits = []
    records = []
    scanned = 0
    saw_void = False
    for path in walk(args.root, (".md",)):
        scanned += 1
        if os.path.basename(path).startswith("VOID__"):
            saw_void = True
        head = read_bytes(path, 4096)
        if HANDOFF_MARKER in head and b"read this first" in head:
            hits.append(path)
        # A marker LINE, not the phrase anywhere: the handoff describes this
        # practice in prose and must not be mistaken for a record because of it.
        marker = record_marker(path)
        if marker or RECORD_SHAPE in read_bytes(path):
            records.append((path, marker))

    print(f"root     {os.path.abspath(args.root)}")
    print(f"scanned  {scanned} markdown file(s)\n")
    if not saw_void:
        print("*** No VOID__ file was seen anywhere under this root. If a quarantine")
        print("*** directory exists, THIS RUN DID NOT REACH IT. Re-run from the")
        print("*** project root before treating a negative result as a finding.\n")

    if records:
        print(f"{len(records)} append-only record(s):\n")
        for path, marker in sorted(records):
            print(f"  path     {path}")
            print(f"  words    {count_words(path)}   (LC_ALL=C wc -w)")
            if marker:
                print(f"  marker   {marker}")
            else:
                print("  marker   *** NONE - PREDATES THE PRACTICE OR IS A STALE COPY ***")
            print()
        print("The LAST marker is the file's reach. An append-only record cannot")
        print("be dated by its name and has no successor, so a stale copy is not")
        print("wrong, only SHORT - every sentence in it is accurate and what came")
        print("later is simply absent. Compare word counts across copies; the")
        print("shorter one is the stale one. A copy with NO marker tells you")
        print("nothing about its own reach and must not be assumed current.\n")

    if not hits:
        print("No handoff-shaped file found anywhere under", args.root)
        print("Record that as the finding. Absence is a result, not a gap.")
        return 0

    print(f"{len(hits)} handoff-shaped file(s) under {args.root}\n")
    unmarked = []
    for path in hits:
        name = os.path.basename(path)
        current = args.current and name == args.current
        marked = current or name.startswith(RESTRICTED_PREFIXES)
        print(f"  path     {path}")
        print(f"  md5      {md5_of(path)}")
        print(f"  words    {count_words(path)}   (LC_ALL=C wc -w)")
        print(f"  version  {version_line(path) or '(no version line - predates the convention)'}")
        if current:
            status = "CURRENT - correctly bare"
        elif marked:
            status = "marked on the name"
        else:
            status = "*** BARE - no status on the name ***"
        print(f"  status   {status}")
        print()
        if not marked:
            unmarked.append(path)

    if unmarked:
        print("ACTION: these carry no status on the name. A handoff at large with")
        print("no status is the condition that produced the branch. Rename by hand")
        print("to SUPERSEDED__live__<name> unless it is the current one.")
        for path in unmarked:
            print("   ", path)
    else:
        print("Every handoff found carries its status on its name.")
    return 0


def cmd_bare(args):
    """Project files outside the live directory with no status on the name.

    `sweep` only recognises handoffs. Notes, briefs, architectures and figures
    go stale too, and a bare copy of one is the same hazard for the same
    reason.
    """
    live = os.path.abspath(args.live) if args.live else None
    rows = []
    for path in walk(args.root, PROJECT_SUFFIXES):
        name = os.path.basename(path)
        if name.startswith(".") or name.startswith(RESTRICTED_PREFIXES):
            continue
        if name.startswith("DO-NOT-ASSEMBLE__"):
            continue
        parent = os.path.abspath(os.path.dirname(path))
        if live and (parent == live):
            continue
        if any(part.startswith("DO-NOT-ASSEMBLE__")
               for part in os.path.abspath(path).split(os.sep)):
            continue
        rows.append(path)

    if not rows:
        print("Nothing bare outside the live directory.")
        return 0

    print(f"{len(rows)} file(s) outside the live directory with no status on the name.")
    print("Each one needs a prefix, or needs to be in the live directory.\n")
    for path in sorted(rows):
        print(f"  {md5_of(path)[:8]}  {count_words(path):>7}  {path}")
    print("\nScreen by content before assigning a status. A folder name is not a status;")
    print("that is the rule the 08-17 quarantine run was found to have relied on.")
    return 0


def cmd_stage(args):
    """Print the moves that would install INCOMING into LIVE. Runs nothing.

    The recurring failure this addresses: downloading straight into the live
    directory. When the name already exists the browser saves alongside it as
    `name_1.md` or `name (1).md`, and a suffix says nothing about which file is
    newer - that inversion has already cost this project a correction. So the
    old file leaves first and the new one moves in deliberately.
    """
    for label, path in (("incoming", args.incoming), ("live", args.live),
                        ("quarantine", args.quarantine)):
        if not os.path.exists(path):
            print(f"error: {label} directory does not exist: {path}")
            return 1
        if not os.path.isdir(path):
            print(f"error: {label} path is not a directory: {path}")
            return 1

    live = {os.path.basename(p): p for p in walk(args.live, PROJECT_SUFFIXES)
            if os.path.abspath(os.path.dirname(p)) == os.path.abspath(args.live)}
    incoming = [p for p in walk(args.incoming, PROJECT_SUFFIXES)
                if os.path.abspath(os.path.dirname(p)) == os.path.abspath(args.incoming)]
    if not incoming:
        print(f"{args.incoming} exists and holds no project files.")
        return 0

    moves, notes = [], []
    for path in sorted(incoming):
        name = os.path.basename(path)
        if COLLISION_RE.search(name):
            notes.append(f"{name} - suffix looks like a download collision. Check which "
                         f"file is newer BY CONTENT before installing; the suffix does "
                         f"not tell you.")
        if name not in live:
            moves.append(f"mv -n {path} {os.path.join(args.live, name)}")
            continue
        old = live[name]
        if md5_of(old) == md5_of(path):
            notes.append(f"{name} - identical to the live copy. Nothing to install.")
            continue
        stamp = md5_of(old)[:8]
        stem, ext = os.path.splitext(name)
        parked = f"SUPERSEDED__live__{stem}-{stamp}{ext}"
        moves.append(f"mv -n {old} {os.path.join(args.quarantine, parked)}")
        moves.append(f"mv -n {path} {os.path.join(args.live, name)}")

    for note in notes:
        print("note:", note)
    if notes and moves:
        print()
    if moves:
        print("# Paste these. This tool does not run them.")
        for line in moves:
            print(line)
    else:
        print("No moves needed.")
    return 0


def cmd_screen(args):
    """Pre-assembly screen. Run this on candidates BEFORE a set goes out."""
    flagged = []
    carry = []
    exempt = []
    for path in walk(args.root):
        name = os.path.basename(path)
        reasons = []
        blob = read_bytes(path)
        if name in TOOL_NAMES:
            # This file holds both literals as the strings it searches for, so
            # it matches itself. A known false positive since 2026-08-24,
            # exempted by name 2026-08-29. Reported below, never silent.
            exempt.append(path)
            continue
        if CARRY_NOREAD_STRING in blob:
            carry.append(path)
            continue
        if RESTRICTION_STRING in blob:
            reasons.append("carries the restriction string")
        if name.startswith(RESTRICTED_PREFIXES):
            reasons.append("restricted prefix on the name")
        if reasons:
            flagged.append((path, reasons))

    if exempt:
        for path in exempt:
            print(f"exempt: {path} - a tool holding the screen's literals as its")
            print("        own search strings. Not a verdict about the set.\n")

    if carry:
        print(f"{len(carry)} file(s) CARRY, DO NOT READ - keep these in the set:\n")
        for path in carry:
            print(f"  {path}")
        print("\nA doctrine session reads these and rules from them. A text session")
        print("does not, and says which it is before it starts. Carrying them is")
        print("what keeps them from going stale; dropping them is what let the")
        print("author record fall four days behind on 2026-08-25.\n")

    if not flagged:
        if carry:
            return 0
        print("Nothing fired. Note what this does NOT prove: a figure carries no")
        print("text to grep, so an out-of-set figure passes this screen clean.")
        print("Check figures against the manifest, not against this.")
        return 0

    print(f"{len(flagged)} file(s) fired - drop these from the set:\n")
    for path, reasons in flagged:
        print(f"  {path}\n      {'; '.join(reasons)}")
    print("\nA handoff quoting the restriction string fires too. That is the")
    print("screen working; read the hit before you act on it.")
    return 0


def parse_manifest(path):
    """Rows as {name: (md5, words, scope)}. scope is 'set' or 'reference'.

    A reference row is a file the manifest vouches for but that is NOT part of
    the set - the corrected figure, for instance. Missing reference rows are
    reported and are not failures.
    """
    rows = {}
    cols = None
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            if not line.startswith("|") or line.startswith("|---"):
                continue
            cells = [c.strip().strip("`") for c in line.strip().strip("|").split("|")]
            # The header row names the columns. Read the order off it rather
            # than assuming one: a hand-made manifest with words and bytes
            # swapped used to be parsed in silence, and every count checked
            # against the wrong column. 2026-08-29.
            lower = [c.lower() for c in cells]
            if "md5" in lower and cols is None:
                cols = {name: i for i, name in enumerate(lower)}
                continue
            if len(cells) < 3 or len(cells[1]) != 32:
                continue
            if cols:
                i_words = cols.get("words")
                i_scope = cols.get("scope")
            else:
                i_words, i_scope = 2, 4
            if i_words is None or i_words >= len(cells):
                continue
            scope = cells[i_scope] if (i_scope is not None and i_scope < len(cells)) else "set"
            try:
                rows[cells[0]] = (cells[1], int(cells[i_words]), scope)
            except ValueError:
                continue
    return rows


def cmd_verify(args):
    rows = parse_manifest(args.manifest)
    if not rows:
        print("No usable rows in", args.manifest)
        return 1

    present = {os.path.basename(p): p for p in walk(args.root, None)}
    ok = bad = missing = miscount = 0
    reference_absent = []
    for name, (want_md5, want_words, scope) in sorted(rows.items()):
        if name not in present:
            if scope == "reference":
                reference_absent.append(name)
            else:
                print(f"  MISSING   {name}")
                missing += 1
            continue
        path = present[name]
        got_md5, got_words = md5_of(path), count_words(path)
        if got_md5 == want_md5 and got_words == want_words:
            print(f"  ok        {name}")
            ok += 1
        elif got_md5 == want_md5:
            # Right file, wrong count. The file is fine and the MANIFEST is
            # wrong about it - which is how a set can condemn a correct
            # handoff. Loud, and a failure. 2026-08-29.
            print(f"  BAD COUNT {name}")
            print(f"              manifest says {want_words} words, file has {got_words}")
            print("              md5 matches, so the FILE is right and the row is wrong.")
            print("              Counts are LC_ALL=C wc -w; C.UTF-8 runs 1-2% high.")
            miscount += 1
        else:
            print(f"  MISMATCH  {name}")
            print(f"              manifest {want_md5}  {want_words} words")
            print(f"              found    {got_md5}  {got_words} words")
            if got_words == want_words:
                print("              same word count, different bytes - line endings,")
                print("              most likely. Re-download rather than edit.")
            bad += 1

    # A manifest cannot hash itself, so its own presence is never an extra.
    extra = sorted(set(present) - set(rows) - {os.path.basename(args.manifest)})
    print(f"\n{ok} ok, {bad} mismatched, {miscount} bad count, "
          f"{missing} missing, {len(extra)} not in the manifest")
    if reference_absent:
        print("Reference rows, vouched for but not set members - absence here is correct:")
        for name in reference_absent:
            print("   ", name)
    if extra:
        print("Not in the manifest (extra files are not harmless - say so in your report):")
        for name in extra:
            print("   ", name)
    return 1 if (bad or missing or miscount) else 0


def cmd_manifest(args):
    refs = {os.path.basename(p) for p in (args.reference or [])}
    lines = [f"# SET MANIFEST - {args.label}", "",
             "| File | md5 | words | bytes | scope |", "|---|---|---|---|---|"]
    for path in list(args.files) + list(args.reference or []):
        name = os.path.basename(path)
        lines.append(f"| `{name}` | `{md5_of(path)}` | {count_words(path)} | "
                     f"{os.path.getsize(path)} | {'reference' if name in refs else 'set'} |")
    lines += ["",
              "**Counts are `LC_ALL=C wc -w`.** In the C locale wc does not count a token holding",
              "no ASCII printable character, so a standalone em dash is not a word; under `C.UTF-8`",
              "it is, and the figure runs higher. Verify md5 after copying, not before."]
    text = "\n".join(lines) + "\n"
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text)
        print("wrote", args.out)
    else:
        print(text)
    return 0


def cmd_count(args):
    for path in args.files:
        print(f"{count_words(path):>8}  {path}")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("sweep", help="find handoff-shaped files by content")
    p.add_argument("root", nargs="?", default=".")
    p.add_argument("--current", metavar="NAME",
                   help="filename of the live handoff, so it is not flagged as bare")
    p.set_defaults(func=cmd_sweep)

    p = sub.add_parser("bare", help="unmarked files outside the live directory")
    p.add_argument("root", nargs="?", default=".")
    p.add_argument("--live", metavar="DIR",
                   help="the live directory, whose files are correctly bare")
    p.set_defaults(func=cmd_bare)

    p = sub.add_parser("screen", help="pre-assembly restriction screen")
    p.add_argument("root", nargs="?", default=".")
    p.set_defaults(func=cmd_screen)

    p = sub.add_parser("verify", help="check a directory against a manifest")
    p.add_argument("manifest")
    p.add_argument("root", nargs="?", default=".")
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("manifest", help="write a manifest for a set")
    p.add_argument("--label", default="unlabelled set")
    p.add_argument("--out")
    p.add_argument("--reference", action="append", default=[], metavar="FILE",
                   help="a file the manifest vouches for that is not a set "
                        "member; repeat the flag for each one")
    p.add_argument("files", nargs="+")
    p.set_defaults(func=cmd_manifest)

    p = sub.add_parser("stage", help="print the moves to install a download folder")
    p.add_argument("incoming")
    p.add_argument("live")
    p.add_argument("--quarantine", default="quarantined-1",
                   help="where superseded live files are parked")
    p.set_defaults(func=cmd_stage)

    p = sub.add_parser("count", help="canonical word count")
    p.add_argument("files", nargs="+")
    p.set_defaults(func=cmd_count)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
