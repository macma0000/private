# TODO — carried forward
Master: `rev2-recursion.md` (52,478 words, zero purple, zero open @@).

## OPEN — raised 2026-07-31, not yet discussed

### 1. The paradox of effort
[A] raised; not yet explored. Related material already in play, for whoever picks this up:
- Choosing does not spend voluntariness — *satisfaction* does (voluntariness notes §4). So effort
  as such may not be the problem; crediting is.
- Voluntariness is NOT effort: the middle levels are the most effortful in the book, and Level 8
  works desperately (voluntariness notes §1). Effort peaks low; what falls monotonically is
  something else.
- The inverted U: choosing peaks in the middle because it requires both room to act *and* something
  unresolved (voluntariness notes §3). Heavy choosing is a symptom of partial boundness, not of
  freedom.
- Climbing is "difficult in a particular way — not effortful, but destabilizing" (Ch 15, What Moves
  a Person). And: "encouragement to try harder does not lift anyone. Effort needs something to push
  against."
- The recursion result: the way out cannot be a shutting down of the capacity, since the same
  folding is what notices the fixation (Ch 16, What Follows From Recursion).
- Trying not to try is itself trying — the regress the guardian result already hits from another
  direction (a maintained state needs a maintainer, notes on the counterfeit summit).

### 2. Another reorganization of the book
[A] flagged; scope not yet stated. Context that will bear on it:
- Ch 15 is 6,300 words, Ch 16 now ~5,000 — the two largest by a wide margin.
- Ch 16 now runs: inner world → recursion → orientations → habit → one cycle → samsara at thought
  scale → illusion of the self → what follows from no-self → choicelessness → counterfeit summit →
  the exit → two ends of the ladder. Twelve sections; the origin material and the liberation
  material may want separating.
- The realms material [A] proposed (deeper look at the two realms, six realms, physical/psychic
  split of the incarnate and non-incarnate) is undrafted and has no home. Ch 3 judged too early.
- All ten figures sit in Ch 5–11; Part III has none.
- Second writer is working forward from Ch 1 and has reached Ch 2. Any reorganization forward of
  his position collides; behind it does not.

## PENDING — earlier, still open
- **Remedies for the fixations** (karma / emptiness / bodhicitta) not yet in the book. Drafting
  agreed for Ch 5 in plain English, futility reading excluded. Blocking-fears table (release-methods
  notes, Addendum 2 C2) is the missing half and should probably go in with it.
- **The borrowing appendix** — what the book takes from the contemplative traditions and where it
  departs. Agreed as the right home for the accounting; undrafted.
- **Six callbacks remain** in Ch 6 (types 3, 4, 6, 7, 8, 9). Three done. Rule: the callback should
  stand on its own where the derivation begins — no "as we saw," no pointing back.
- **The helix** (descent as the orientation cycle running backwards, drop at the Z0 crossing) —
  deferred, not rejected. Two unresolved conflicts recorded in voluntariness notes §B7.
- **Second writer to read Ch 6** and judge whether the Ch 2 images are the ones Ch 6 reaches for.

## PARKED — carried over from the read-through flag files (verified still present 2026-08-01)
These were logged in READ-FLAGS-ch3-through-15.md and READ-FLAGS-PASS2.md, which are now deleted.

- **Garbled Hornevian back-reference** (Appendix D, harmonic section): reads "observation reads the
  S realm"; should be **H realm**. One-word fix, never applied.
- **Harmonic triads** (Appendix D): the competency/reactive derivation rests on an attention
  doctrine that is nowhere stated in Ch 6. Three options — cut it, build it, or **state the missing
  premise** (one sentence in Ch 6 would make the derivation go through). Never ruled on.
- **F32 — the "orphaning of types 3 and 6" passage** (Ch 12): true-but-unbridged reflection facts,
  and an undefined feeling-term. Never addressed.
- **Close-read B — the D(1) merger** (Ch 15, Summit and the Exit): "actualization" fuses two
  different formulations of Level 1's desire. Unresolved.
- **Close-read C — Level 0 as both floor and ceiling**: Appendix G titles the recursion base "The
  Floor" while Level 0 sits at the *top* of the health axis. The collision is still there, and it
  is why the floor/ceiling metaphor was kept out of the descent material.

## FOR THE AI-INTERACTION SECTION (raised 2026-08-01, undrafted)
Placement: start as an appendix ("A Note on Working with AI"); if it keeps producing claims about
how thinking goes wrong rather than method notes, it has argued its way into Part III. The bare
**AI disclosure** should move separately to the back matter, after the Conclusion — writer 2
objects to its position, not its content, and a reader can only evaluate it once they have read
the book.

### The four things [A] named
1. **Dependence on memory and organization.** [A] is "almost totally dependent" on the AI for
   holding the whole and organizing it. This is the plainest practical finding and probably the
   first thing a reader wants.
2. **Literalism as a diagnostic.** The AI takes things more literally than intended — *"and that's
   also what most readers will do."* So the misreading is not a defect to be worked around; it is
   an early warning that the text will be misread the same way. Three outcomes: [A] supplies
   detail and the problem resolves; another iteration resolves it; or it cannot be made sensible
   and is dropped. **The third outcome is the valuable one** — the process kills claims that
   cannot survive being stated plainly.
3. **The process opens new avenues.** Iteration surfaces questions neither party had.
4. **The AI produced new material** — usually filling gaps [A] had overlooked, but once a complete
   new insight: **that detachment trained in one realm alone can look like holiness while the
   strongly engaged other realm runs unchecked** (the counterfeit summit, Ch 16).

### [C]'s additions, if wanted — the failures, which are the other half
- **Over-precision.** Discussion-register precision crossing into the text and making loose claims
  look exact. Cost three separate repairs (the correspondence, "One Vocabulary," the analog ruling)
  before the mechanism was named.
- **Laundering.** AI-generated material gaining authority by being cited back — the project has a
  standing rule against it.
- **Derivation on demand.** Four routes to the same three orientations, produced whenever asked.
  This is the foreword's multiply-determined-thought warning demonstrated rather than asserted, and
  it is why *constraint* rather than *prediction* became the test.
- **Incomplete merges and silent reversion** (writer 2's Ch 1), and describing applied edits in
  paraphrase so [A] could not tell proposal from applied text.
- **The asymmetry that governs the whole collaboration:** generating explanations is cheap;
  testing costs something. The moments that moved the work were the ones where [A] contradicted a
  prediction (the Level 8 disability correction), not the ones where the AI produced something
  plausible.

### [A]'s further material for the AI section (2026-08-01) — the negatives, and the balance
**Naming:** the section may call the AI **Claude** rather than describing it generically.

**The foreword as the worked example.** [C] drafted a foreword; [A] rewrote it. [A] did not expect
the draft to be near-final, but *was surprised how much it would have distressed a reader*. It was
useful as a list of what needed saying. What it showed: **Claude cannot reliably imagine how small
changes land in a reader's mind.** Writer 2 was "a bit outraged" by that inability.
**The consequence [A] draws: every sentence in the book needs tweaking in that regard, and that is
manual labour.** If this were solved it would save months. That is the current state of the tool.

**The balance, in [A]'s own terms — this should not be softened in either direction:**
- Without AI, **the book could not have been produced at all.**
- A professional writer might have produced *part* of it — the realms, the orientations, and the
  consequences of the new theory. **Most of the spiritual-connection, depth, and escape material
  would never have been discovered.** That material came out of the dialogue.
- Learning how Claude works — mechanically, and by developing an intuition for how it thinks — was
  **a gradual process**, and is itself part of what there is to report.
- For purely logical work at scale (his example: finding vulnerabilities in very large codebases)
  this is something **only AI could do, and it does it shockingly well.**
- On the language and psychic side, **less well — but still shockingly better than [A] expected.**

**[C] note for whoever drafts this:** the shape of the finding is that the tool is strong where the
work is *combinatorial and checkable* and weak where it is *judged by effect on a reader*. The
book's own two realms map onto that split almost exactly, which is either a neat coincidence or
worth a sentence.

## AUTHOR REVIEW OWED — Appendix H first person (2026-08-01)
Appendix H ("A Note on Working with AI") is written throughout in [A]'s first person and makes
claims about his experience, his judgment, and what surprised him. It is the only appendix where
Claude has put substantial words in the author's mouth *about himself* rather than about the
theory. [A] will revise. Until then, treat it as draft regardless of its position in the file.

## REMINDER REQUESTED — the Z seam (2026-08-02)
[A] asked to be reminded of this later. Full discussion in
`THEORY-NOTES-gradient-and-Z-split.md`, Addendum E1–E8. Summary of what is on the table:
- **Blindness derived rather than located:** Z is the only orientation whose way of resolving a
  conflict (quieting the disturbance) destroys its own competence (seeing). Repairs Ch 11, where
  Z+'s slide is currently the *definition* rather than the *consequence*.
- **The feedback loop:** conflict causes blindness; blindness lets the two pulls coexist. Explains
  why conflicted-Z is stable, which nothing currently does.
- **The cut at the Z seam is now derived** from three independent directions rather than asserted.
- **Continuity revision:** Z−/Z+ as one varying quantity (how much still registers) rather than
  "opposite conditions sharing a name" — fixes a clash with the analog ruling.
- **[A]'s latest:** the strength of the discontinuity varies with level of health. Would soften
  "the levels do not wrap" from absolute to practical, and make the exit the one legitimate
  crossing. **Needs [A]'s ruling; one day old.**
- **Testable:** whether a Z− reads a Z+ as ahead or behind depends on the observer's own overlap.
  Writer 2 is a 2 (HZ) and could be asked.

## NEXT SESSION — split Chapters 15 and 16 (decided 2026-08-05, deferred for room)
Master: `rev2-0805b.md`. Both chapters are ~3x the median chapter (6,625 and 6,173 words);
Part III is now as large as Part I. The splits do not touch Part boundaries and require no
renumbering before Chapter 15, since these are the last two chapters.

**Cut points, already visible in the section lists:**
- **Ch 15 divides at "What Moves a Person."** Before it: what the Levels are and how they map
  (Overview, Where a Person Stops, Beneath the Levels: The Rule That Drives the Descent, The Correspondence, One Vocabulary,
  What the Health Axis Is Toward). After it: what moves a person (What Moves a Person, What the
  Climb Requires, The Descent Narrated, The Summit and the Exit, The Three Floors). ~3,000 each.
- **Ch 16 divides where its own title does.** Origins: Where the Inner World Came From, What
  Follows From Recursion, Principles Not Laws, Where the Orientations Come From, Habit: The
  Carrier. Endings: One Cycle at Every Scale onward — Samsara at Thought Scale, The Illusion of
  the Self, What Follows From No-Self, Choicelessness, The Counterfeit Summit, The Exit, The Two
  Ends of the Ladder. ~3,000 each.

**The expensive part — 45 references need re-pointing, each a judgment call:**
38 to "Chapter 15" and 7 to "Chapter 16". Each must be read in context to decide which half it
means. Do NOT sweep. Verify every one afterward; two renumbering errors have already occurred on
this project (bare "Appendix A" refs, and the F.n subsections), both caught only by checking after.
Also check the 16 "Appendix G" references, which point into Ch 15's material.

**Still deferred, needs writer 2's reading of Parts II–III (he is at Ch 4–5):**
Part boundaries; whether Ch 14 moves; the framework/application restructure.
