# NOTE — the three outcomes at the Z crossing, and the burial reflex

**Cut by `job21-doctrine-20260826`.** Source: `[A]` in session, 2026-08-26, working from the
anxiety-transition material in the author record and the two-scales note.

**Status of everything below: `[A]`'s, stated in session, NOT YET RULED** — except where a line is
marked as already-ruled or as `[C]`'s reading. It was reached in one continuous conversation and is
written down here because it did not exist anywhere but the transcript. **A later session must not
cite this note as doctrine.**

**Why it exists.** It began as the fall-account repair (handoff §0 item 7, first bullet) and
overtook it. The fall repair is now downstream of this and is treated at §7.

---

## 1. THE RESULT IN ONE PARAGRAPH

A fear arriving at the transition into detachment has **three** possible fates, not two. It can be
**buried** — blocked from consciousness, surviving intact and hidden. It can be **reconciled** —
thought through and met. Or it can be **accepted** — a general surrender rather than the resolution
of a particular fear. **Only burying descends the axis.** Burying has a reinforcement motor laid
down before there was anything propositional to examine, which is why it strengthens with use and
defends itself. The way out is recognition aimed at **the burial reflex** rather than at the buried
contents.

---

## 2. THE THIRD OUTCOME — `[A]`, and it is the new thing

> we say blindness occurs when fear arrives at Z+ and that happens when the fear is not handled -
> that is, thought through and reconciled. it occurs to me that there is a third possibility, in
> between - a general surrender, not reconciling a particular fear but acceptance. i think that would
> not cause blindness but forgetfulness - a more gentle elimination from consciousness - not "i dare
> not look", but "i don't care anymore". as opposed to reconciling the fear which would be "i'm ready
> for more problems".

**"In between" was withdrawn by him in the next exchange** — *no need to call the third choice
middle*. **Do not reintroduce the middle framing.** It was withdrawn for a reason: a middle position
on the detachment stretch is not a third outcome at all, only a place on a gradient the model already
has, and it would have collided with Ch 11's account of the apex without sight.

### 2.1 What is left of the fear — `[A]`

> an accepted fear is no longer a fear - maybe a regret that is accepted.

So acceptance **destroys** the fear rather than hiding it. Nothing is left to feed the chain and
nothing is left to lock.

**`[C]`, and it needs `[A]`'s check:** a regret is about something over, so it makes no demand and
generates no next move — which is a fear with its forward pull removed. Offered as the reason the
residue is a regret specifically.

### 2.2 What acceptance costs — OPEN, and `[A]` left it open deliberately

Asked whether acceptance moves a person down the axis:

> i think not directly, because no additional fear is buried. whether it reduces diligence to go
> downwards or rather increases tranquility to go upwards, i don't know, maybe either.

**Keep the "maybe either" as it stands.** It means acceptance is not one thing, and something not yet
identified decides which way a given acceptance runs. **This is a gap about a second-order effect;
the first-order result — acceptance does not bury, therefore does not lower — holds regardless of how
it is closed.** The account can be written without it.

### 2.3 Two arguments for the third outcome — `[C]`, offered in session, `[A]` did not rule on them

- **The two-outcome model overpredicts blindness.** Every unmet fear becomes buried. Transitions are
  constant and reconciling is rare and effortful, so on a strict binary nearly everyone should accrue
  blindness nearly continuously. A third disposal fixes this structurally rather than by adjusting
  rates. — **REASSIGNED 2026-08-30. This argument now belongs to `ignored`, not to `given up on`.**
  *Under the four fates, the fate that absorbs the ordinary unmet fear without cost to sight is
  ignoring: fear intact, want intact, only the occasion let pass. Giving up on is not that — it drops
  the want, which is a change in the person and is not what happens to most fears most of the time.
  Giving up on survives as an outcome on the other grounds in this section; it just no longer carries
  this one.*
- **It is not imported.** Release and surrender are already what the transition into detachment *is*
  in book 1's own account (Ch 13's Shiva passage: dissolution releases what has been held). So the
  third outcome is the transition's own character showing up as one of its results.

### 2.4 VOCABULARY COLLISION — must be settled before this is drafted anywhere

**`surrender` and `acceptance` are both already in use near detachment.** The B→Z transition is
described as release and surrender; and `despair/surrender` appears in the author record as a
*stacking-side* disposal, which is a different thing entirely. **Whatever the third outcome is
called, it cannot be either of those words without work.** Flagged by `[C]`, unresolved.

---

## 3. WHAT SEPARATES BURYING FROM ACCEPTING

`[A]`'s first criterion was a decision — *acceptance is a decision, at least in the sense that a
person is aware that a choice has been made, whereas the route to blindness happens in blindness.*

**`[C]` over-read that** and built structure on it; `[A]` corrected twice. The corrections are the
content here, not the first version.

**Correction 1 — the general comment is plainer than `[C]` took it for.**

> i think this is a statement about all decisions - some are made quickly without much consideration
> and others are very deliberate.

That is the continuum book 1's habit section already runs, from the involuntary to the chosen. **It
is not a new commitment and must not be written up as one.**

**Correction 2 — the separation is depth, not degree. `[A]`:**

> a difference of depth maybe than degree. some deep part must see to recognize a threat, but the
> information is blocked by design (i will avoid saying intentionally) from consciousness. that
> reaction must be a unconscious and reflexive and reinforced by another unconscious recognition that
> unpleasant anxiety has been avoided.

**So burying is not the far, unconsidered end of the deliberation continuum. It sits below the floor
of it.** The continuum governs conscious decisions; burying is not one.

### 3.1 This saves book 1's claim, with one repair to its reasoning — `[C]`

Book 1, Ch 5:

> This is denial, and it is not a decision: a decision to not see could happen only after a thing has already been seen.

On `[A]`'s account something **has** seen — a deep part recognises the threat. The conclusion stands;
the stated reason does not, as written. **The correct form is that a decision not to see would
require having *consciously* seen** — which is the footing already settled on 08-21, that the
material is registered but not consciously available.

**This is a candidate text repair and is NOT on any repair list. It is not written here as one** —
writing the replacement is a doctrine act and the wording is `[A]`'s to rule. Recorded so it is not
lost.

### 3.2 `by design` — a word the model can supply

`[A]` avoided *intentionally* and reached for *by design*, which has the same hazard at one remove.
**The model already licenses a third word:** a fixation is ruled (08-18) to be a choice repeated
often enough that it stopped being made and sank toward the involuntary. So an arrangement can have a
function and a history without anyone having intended it. **`[C]` proposes `learned rather than
designed`.** Not ruled.

---

## 4. THE REINFORCEMENT MOTOR — **NOT SUPERSEDED. It answers a different question from the 08-30 trigger.**

> A newer account of what makes the loop pay was ruled on 2026-08-30 — recognising a burial threatens
> to undo it, so the recognition is itself a threat and burying that avoids a real present anxiety.
> **It does not replace the preverbal account below.** `[A]` was asked directly and said of the
> preverbal account **"it sounds true"**, and his 08-29 ruling that laying-down and reinforcing run
> continuously stands.
>
> **Three questions, three answers, and they do not compete.** How the reflex was *learned* is this
> section's, and it is preverbal. What makes the loop *fire* is entry — a fear becoming unbearable.
> What keeps it from decaying is *maintenance* — the burial generating its own material to bury. All
> three stand. `[A]` corrected `[C]` for collapsing entry into maintenance; collapsing them leaves
> entry unexplained and the account with no beginning.

**`[C]`'s objection, raised and then answered by `[A]`.** If the anxiety never reaches consciousness
there is no felt event to reward, and recognising that something unpleasant *did not happen* requires
a comparison with a state that never occurred.

**`[A]`'s answer:**

> but in the past the anxiety hasn't been blocked but at least semi consciously been felt. this is at
> a preverbal operation, probably set down at a preverbal stage of life. and has become hidden as
> rational consciousness developed on top of it.

**RULED 2026-08-29 by `[A]`, and it corrects what this section said: *"both happen continuously."***
The laying-down and the reinforcing are not one-then-the-other. The learning was laid down when the
anxiety *was* felt, **and it goes on being fed** — so the reflex is not frozen at whatever strength
it reached before words. *This paragraph previously read: "Once learned, the reflex runs without any
felt event and without any counterfactual." That is wrong, and §4.2 below was already inconsistent
with it — the consequences drawn there all require a live reinforcer.*

**Two things follow, and the second is not yet ruled.** `blindness strengthens with use` (§4.2)
stands. And new fears get their own burial laid down across a lifetime, so **`preverbal` describes
only the oldest layer** — everything later is the ordinary Ch 17 case, a choice repeated until it
sinks beneath understanding, the choice being the choice not to look. §4.4 below leans on the
preverbal origin to dissolve the chooser problem; under this it dissolves only for the earliest
layer, and for the rest the problem does not arise because there *is* a chooser. **`[A]` was shown
this and did not dispute it; it is not ruled.**

### 4.1 The paragraph that already says this — Ch 17, and it has never been pointed at blindness

> What hardens in an infant is an expectation — *I do this and my feelings change* — which begins provisional, gets confirmed, and stops being tested.

**That is the motor, already written, in the general case.** An act, a felt change, confirmation, and
the testing stopping. Book 1 states it about the laying-down of strategies at large. **Pointing it at
the burial reflex is the whole cost of this section.**

Ch 17 also has the property that makes the reflex survive its own origin: a habit is laid down
beneath understanding, so nothing has to be believed for it to keep running.

### 4.2 What the motor buys — `[C]`, three consequences

The blindness loop has been described as self-maintaining, and **what maintained it was never
stated.** With the motor:

- **Blindness strengthens with use** rather than merely persisting.
- **It accrues in small increments** — which is what a reinforcement history looks like, and matches
  `[A]`'s 08-26 statement that each addition to blindness is a small fraction of one of Riso's levels.
- **It becomes more reflexive over time** — the same sinking-toward-involuntary the habit section
  already describes. **So the fixation account and the blindness account run on one process.**

### 4.3 Why only one of the three locks — `[C]`

**Acceptance has no reinforcer.** No anxiety was avoided, so nothing is rewarded, so it does not
strengthen itself. Burying defends itself because it prevents the looking that would undo it;
acceptance defends nothing and the material can drift back into view without meeting resistance.
**Two kinds of downward motion, one that locks and one that does not — with a mechanism rather than
an observation.**

### 4.4 A tension this removes — `[C]`

Fixation is ruled to be a choice repeated until it stopped being made. That fits nothing predating a
chooser. **Book 1 already saw this and made the qualification for the oldest layers** — hardening
works on something propositional, and the first strategies are older than any capacity for
propositions. So the preverbal origin is not a new commitment; it is the qualification already in the
text.

---

## 5. THE WAY OUT — `[A]`, and it gives Ch 15's promise an object

Asked whether acceptance is the only route out for a fear laid down before there was anything
propositional to examine:

> i think not the only. i think it requires conscious recognition of the buried fears one by one, or
> better, a recognition of the automatic burial process.

### 5.1 It dissolves a problem `[C]` had raised

`[C]` had argued that reconciling needs a proposition, that the oldest layers have none, and that
acceptance would therefore be the only disposal reaching the oldest material. **True of the fear, not
of the process.** The reflex is watchable in the present tense whatever age it was laid down at,
because it is running now. So there is something to bring to mind; it is not the buried content.

**That is why book 1 can say the only handle at those layers is the felt quality itself and still
promise a way up: the handle is the felt quality of the burying, caught as it happens.**

### 5.2 It gives Ch 15's standing claim a specific object

Ch 14's closing paragraph already says the way back up is not another escape from the fear but
awareness of the cycle it turns, and that this is the only real victory over it. **`[A]` has now said
which cycle: the burial reflex.** The abstract claim gains an object. **`[C]`'s reading, and it
should be checked against Ch 15 itself before anything is drafted** — *the cycle it turns* may have
been meant as the orientation cycle, in which case this is an addition rather than a specification.

### 5.3 Why the process route beats the one-by-one route — `[C]`

`[A]` said *or better* and did not give a reason. The machinery supplies one: **taking fears one at a
time reduces a stock while the reflex keeps adding to it.** Given that blindness accrues in fractions
of a level and is reinforced every time it fires, the one-by-one route can be outrun by the thing it
is trying to clear. Recognition of the process closes the tap. **Offered as the reason for his
preference; not his statement.**

---

## 6. THE THREE OUTCOMES, TABULATED — **REPLACED 2026-08-30. FOUR OUTCOMES, AND THE NAMES CHANGE.**

> **`[A]` ruled four fates at the crossing, in an order:** `worked through`, `given up on`,
> `ignored`, `blocked`. `worked through` replaces `reconciled` and `given up on` replaces
> `accepted`; `buried` is
> `blocked`. `ignored` is the addition, moved here from after the crossing when he sited the decision
> to ignore at **Z+**.
>
> | | fear survives? | want survives? | in view? | descends the axis? |
> |---|---|---|---|---|
> | **worked through** | no — met and dealt with rather than disposed of | n/a | yes | no |
> | **given up on** | no — the want behind it is dropped; a regret remains | no | yes | no |
> | **ignored** | yes, intact and deferred; only the occasion let pass | yes | yes | not directly |
> | **blocked** | yes, hidden and stable | yes | **no** | **yes — the only one that does** |
>
> **The order is not a list.** Book 1 assigns the two ends of the crossing to the two transitions, so
> within one crossing a fear meets the sighted end first and the end that turns away second. Settling
> and giving up on happen while the fear is in view; what survives that reaches the end that turns
> away.
>
> **The sort runs on two questions: is the fear in view, and is it disposed of.** What is in view can
> be worked through, given up on or ignored; what is not can only be blocked. One combination is empty —
> nothing can be disposed of that was never seen — and the emptiness is content, not a gap.
>
> **WHAT SURVIVES FROM THE PARAGRAPH BELOW, and it is only part of it.** The rule holds: which
> outcomes are available at a crossing is set by whether there is sight there. **What died is the
> assumption riding on it** — that at Z+ there is no sight, so burying is all that is left. `[A]`
> retracted the automatic trigger on 2026-08-30: **"Z+ disposes of fears unwisely. the blindness loop
> is real but not necessarily usual."** Z+ has sight for some fears and not for others, and the
> disposal differs accordingly.

*Retained below as first written.*

| | fear survives? | descends the axis? | self-reinforcing? | reached how |
|---|---|---|---|---|
| **buried** | yes, hidden and stable | **yes — the only one that does** | yes, motor at §4 | below the floor of decision |
| **reconciled** | no, met and dissolved | no | n/a | conscious, deliberate |
| **accepted** | no, gone unmet; residue is regret | no, not directly (§2.2 open) | no | conscious, endorsed by not rejecting |

**`[C]`, and it keeps the third outcome from becoming an escape hatch:** two of the three require the
fear to be in view. One cannot decide to accept what was never seen. **So which outcomes are
available at a given crossing is set by whether there is sight there** — which is what the
near-side/blind-side material in the author record was already governing. Without this, acceptance
would make descent inexplicable.

---

## 7. WHAT THIS DOES TO THE FALL ACCOUNT — the job this session was sent to do

The standing repair (handoff §0 item 7, first bullet) asks whether *full-axis collapse available in
full only to the 9* survives, given that the arc count it rested on was superseded.

**`[C]`'s finding, in three steps, and step 3 is the one that matters:**

1. The ground it was actually built on was arc-count, which is gone. The suggested rescue — the
   engaged realm as witness — is a claim about what collapse is *like*, not about whether it can
   happen.
2. `[C]` tried to rebuild it on *only the 9 rests on the detachment stretch in both realms*. **`[A]`
   corrected the reasoning that got there** (see §8), and the descent being a forward turn means
   every type passes through detachment on every turn, so passing is not the distinction.
3. **The question is the wrong shape.** With blindness accruing in fractions of a level, one
   transition at a time, **there is no such event as a full-axis collapse.** The bottom of the axis is
   hundreds or thousands of buried transitions. Nothing makes it *available* to one type and not
   another; a type can only make it faster or slower.

**So `[C]` reads the availability claim as dissolved rather than repaired**, and what replaces it is a
rate-and-correlation claim: **the 9 is the type whose two realms are both decided in the same
terrain**, so its realms move together — either both protected or both exposed. Every other type has
at least one realm whose anxiety is disposed of elsewhere and so is not descending in lockstep, and
that realm is the vantage the witness leg wanted.

**NOT RULED. `[A]` has not seen this stated in this form.** It also rests on the near-side/blind-side
material in the author record, which is his own working-through and carries his own hedge — *i'm not
as sure as i sounded* — including the open question of whether catching the fear at the near side has
to be **learned** rather than coming with the fixation. **That hedge is now more important, not less,
because the fall account would sit on top of it.**

**CORRECTED LATER THE SAME SESSION — see §11.3. The rate has TWO contributors, not one.** This
section as first written had the rate set by where the fixation sits at the crossing. It is also set
by how much the earlier passages left unresolved. **Read §11 before using anything in §7.**

---

## 8. TWO CORRECTIONS `[A]` MADE TO `[C]` THIS SESSION, recorded so they are not re-made

- **Nothing goes backward; that idea was dropped.** `[C]` used *the long way around, the backward walk
  through the landmarks*. **`[C]` took it from the fall account's own filing in `RULINGS-20260816b.md`,
  where the phrase is still sitting.** It was withdrawn about forty lines below in the same file (the
  landmarks are coloring, the motion is the per-step turns) and again on 08-20 (the descent is a blind
  **forward** turn). **The stale phrase remains in a live file with both of its corrections filed
  elsewhere — a text-of-the-rulings-file defect, not a manuscript one. Not fixed here.**
- **`[C]` over-read the decision criterion.** See §3, corrections 1 and 2.

---

## 9. OPEN, IN PLAIN WORDS

| Question | Where |
|---|---|
| Does acceptance reduce diligence, increase tranquility, or either? | §2.2 — `[A]` left it open on purpose |
| What is the third outcome called, given the two collisions? | §2.4 |
| Does Ch 5's *not a decision* get the reworded reason, and in whose words? | §3.1 |
| Is *learned rather than designed* the phrase? | §3.2 |
| Was Ch 15's *the cycle it turns* the orientation cycle or the burial reflex? | §5.2 |
| Does the fall account's availability claim get cut rather than repaired? | §7 |
| Does catching the fear at the near side have to be learned? | §7, `[A]`'s own hedge, older than this session |
| Does Ch 7 name the Z arrival's difference, or leave it to Part 3? | §11.6 |
| What replaces Ch 7's two stale headings and three route narrations? | §11.5 — no wording exists |

---

## 10. POINTING OUTWARD — not followed, flagged only

**The ascent question `[A]` minted 2026-08-25 — how the way up the levels differs by fixation — gets a
candidate answer from this note that the note did not set out to give.** If the way out is recognition
of the burial reflex, then **the act is the same everywhere** — a reflex is a reflex — **while its
contents are fixation-shaped.** That is `[A]`'s own null-result option, arriving with a reason rather
than as a shrug. It is one of the two readings that entry was set up to test against each other.

**Not developed. `[C]` stopped here deliberately** — that question was minted as its own item and this
note has already overtaken the one it was cut for.

---

# 11. ADDED LATER THE SAME SESSION — the spoiled arrivals, and what they hand the crossing

**Appended rather than inserted**, so that nothing above renumbers. **The material in §11.1 and
§11.2 is `[A]`'s, from 2026-08-25, and already lives in
`NOTE-resolution-rate-and-the-descent-20260825.md` §2–§4 under the scope problem.** What is new on
08-26 is only **the connection** — that this material answers a question about the three spoiled
arrivals and about book 2's Ch 7. **Cite the 08-25 note for the claims; cite this section only for
the connection.**

*Procedural note on why this is here rather than there.* The resolution-rate note is named in the
handoff and in the manifest. Amending it would change its bytes, force a new name, and break live
pointers for the sake of one section. **`[C]`'s judgment, not a rule** — `[C]` recommended the
amendment first and reversed on the pointer cost. `[A]` accepted the reversal. The cost of doing it
this way is that a session reading the 08-25 note alone will not learn the connection exists; **the
handoff must route to both.**

## 11.1 The question `[A]` put

Whether a passage failing somewhere **other than** the Z crossing changes what happens when the arc
reaches Z. `[C]` had offered two readings and could not choose between them: spoiled arrivals might
**load** the crossing (more unresolved fear delivered) or **starve** it (less at stake, so less fear
raised). **Opposite predictions about who accrues blindness fastest, so not a wording choice.**

## 11.2 The record answers it — LOADING, and `[A]` had already said so on 08-25

> But A's fears are rushed through B because A just gives up. the fear is something more is happening
> that i want to think about so those arcs aren't resolved.

> i would add: that carrying failure back into Z+ territory creates more blindness, and the same for
> A's abandonment.

**A short-changed passage hands the crossing MORE.** `[C]`'s starvation reading is wrong and is
recorded here only so a later session does not re-derive it.

**The accounting, stated:**

> it's possible that many of B's fears are resolved before completing the cycle through Z in which
> case no blindness. only the unresolved one count.

**What the crossing has to handle is whatever the earlier passages failed to resolve.** So the three
spoiled arrivals are not three parallel cases: **two of them are inputs to the third.**

### 11.2a It also settles the scope question, and settles it as CONTINUOUS

`[C]` had asked whether spoilage is the ordinary condition of every arc that stops short, or
specifically what stress does. `[A]`, 08-25:

> i would say there is a B phase for both Z+ and A and it's more of sooner or later and more often or
> less than a qualitative difference, the thing being abandonment rather than resolution.

**More or less often, sooner or later — not a kind.** So spoilage is ordinary and varies by degree,
and **the three disintegration arrivals are its visible extreme rather than three kinds of it.**
This fits what is already ruled: that integration and disintegration are observations rather than
processes, and that a fixation is defined by a step not taken.

## 11.3 CORRECTION TO §7 — the rate has two contributors

§7 read the fall as a rate claim with one contributor: where the fixation sits at the crossing.
**There are two.** The second is how much the earlier passages left unresolved. Both feed the same
quantity — how often a crossing buries — and they are independent of each other.

**This strengthens §7 rather than weakening it**, but it means the fall account cannot be written as
a fact about fixation position alone.

## 11.4 THE THREE ARRIVALS, as `[C]` explained them and `[A]` did not dispute

Each orientation can be arrived at twice over: having lived the passage that leads into it, or not.
**Each spoiled arrival is missing exactly what the skipped passage would have supplied.**

| Arriving at | passage lived | passage not lived |
|---|---|---|
| detachment | enters seeing — release earned by understanding | shutdown; numbness in place of acceptance; wanting survives as carelessness |
| caution | alertness in the service of getting something | anxiety — worry without the sense that understanding will help |
| enthusiasm | release into action; appetite returns with the seeing intact | brittle energy rather than real optimism |

**The orientation is genuinely reached in every case.** What is absent is not the orientation but the
content the prior passage would have deposited in it.

**`[A]`'s correction, and it governs the table:** blindness happens only while traversing Z.
**Spoilage and blindness are two things and `[C]` had fused them.** Spoilage is a quality of an
arrival, at any node, momentary, no debit. Blindness is an accrual, at the Z crossing only, in
fractions of a level, and it locks. **They coincide at exactly one of the three rows**, which is
presumably why the drafting fused them too.

*Book 2's Ch 7 is already right about this in its vocabulary* — it calls only the detachment arrival
blind; the caution arrival is anxiety and the enthusiasm arrival is brittle energy. **The defect
there is the routes, not the naming.**

## 11.5 THE Ch 7 FINDING, widened — text-touching, NOT for this session

**Chronology is the finding.** Ch 7 was drafted 2026-08-17. Nothing-runs-backward was ruled
2026-08-19. **The section predates its governing ruling by two days and nothing has looked at it
since.**

**Three kinds of site, not one:**

1. **Two section headings.** `Forward` and `Backward`. The second names a motion the model no longer
   holds. The distinction the chapter is actually drawing is the one in §11.4's table — passage
   lived or not — so the headings themselves go, not only the sentences under them.
2. **Three route narrations** under `Backward` — *A to Z*, *Z to B*, *B to A* — each describing a
   backward transit as the route taken. Destinations and characters are correct; the mechanism is the
   superseded one.
3. **One clause in the framing paragraph:** *moving against it is disintegration*, two sentences after
   the chapter correctly declares itself to be about directions and not motion.

**The awkward part.** That framing sentence is currently the repair template for book 1's transit-verb
defect — the fix at five book 1 sites is to make the arrows chapter obey what the cycle chapter
already declares, citing book 2's Ch 7. **It does say the right thing, and then contradicts itself
three subsections below.**

**NOT REPAIRED HERE. No replacement wording is written**, because writing one is a doctrine act and
the wording is `[A]`'s to rule. **Do not hand this to a text session as a strings-and-substitutions
job; there are no strings yet.**

## 11.6 THE OPEN QUESTION THIS LEAVES — `[A]` has not answered it

Given that blindness happens only at Z, and that Ch 7's business is the cycle and not the core
dynamics:

**Does Ch 7 name the difference at the Z arrival at all — that this one costs something the other two
do not — or does it describe the three arrivals evenhandedly and let Part 3 be the first place the
reader learns one of them is different?**

*`[C]`'s reading, offered and not ruled:* Ch 7 should carry the spoiling account for all three
arrivals and **say nothing about the mechanism of blindness**, leaving *blind* as the name for
detachment's blind side, already available from the orientations chapter. That keeps the cycle
chapter to the cycle, which the architecture requires, and stops the book explaining blindness twice
in two registers. **Stating the skipped-passage account early has a specific hazard:** it invites the
reader to take blindness as a spoiled arrival — momentary and recoverable — at the one place the book
most needs the two kept apart.

## 11.7 A `[C]` FAULT RECORDED, because it recurred within one session

`[C]` twice used the superseded backward framing: once taking *the long way around, the backward walk*
from the fall account's own filing (§8), and once, after being corrected, describing Ch 7 as drawing
the good arrivals under `Forward` and the spoiled ones under `Backward` **without flagging that those
headings are the stale text under discussion.** Descriptive rather than asserted, but unmarked.
**The general form: quoting a manuscript's superseded framing without marking it reads as endorsing
it, and `[C]` is the more likely to do this the more of the stale text it has just been reading.**
