# BOOK 2 — PART 3 AND PART 4 ARCHITECTURE — 2026-08-30

**AMENDED 2026-09-02 by `Job43 drafting 09022026`, and it takes the next letter:
`BOOK2-PART34-ARCHITECTURE-20260902e.md`. Quarantine `BOOK2-PART34-ARCHITECTURE-20260902d.md` as
`SUPERSEDED__live__`.**

**THE RULED PLACEMENT AT Ch 15 IS APPLIED. `BOOK2-20260902.md` → `BOOK2-20260902b.md`, 27,318 w →
27,574 w, 1,297 lines → 1,307.** All seven blocks moved, the four minimal statements and the two
rewrites on arrival written, the partial-registering paragraph dropped as the join check ruled, and
**the chapter has its title**. *Do not apply this placement again: §1's Ch 15 and Ch 16 sections now
describe the master rather than instruct a change to it.* Surgical edits at four sites, **not a
retyping**: this head, §1's Ch 15 heading and title paragraph, and the pointer at §1's head.

**AMENDED 2026-09-02 by `Job42 architecture 09022026`, and it took the letter
`BOOK2-PART34-ARCHITECTURE-20260902d.md`.**

**`[A]`'s 09-02 ruling on where the fixation descriptions live is carried out here as a ruled
placement**, in the form he set on 09-02 for the recursion chapter — *put your decision into the
architecture file as a ruled placement*. **Ch 15 gains a descriptive first half and Ch 16 gives it
up.** Surgical edits at five sites, **not a retyping**: this head, §1's Ch 15 section, §1's Ch 16
section, §7's new items, and §8's third correction to the Parts 1 and 2 file.

**THE MEASUREMENT THAT DECIDED IT, and it is larger than the handover said.** `OPEN-from-job41-20260902.md`
found detachment's two faces stated in three chapters. **It is stated in five** — Ch 4 introducing the
clear and blind faces, Ch 7 saying which neighbour produces each, Ch 11's *Detachment's lean is not
like the others*, Ch 13's *Why detachment is the odd one*, and Ch 16's *The two ends, and what lies
between them*. Only two of the five are full descriptions, and those two are the pair that collapses.

**No chapter is added and no chapter number moves.** The renumber `Job41` discharged stands.

**AMENDED 2026-09-02 by `Job41 drafting 09022026`, and it takes the next letter, the date and `b`
being taken: `BOOK2-PART34-ARCHITECTURE-20260902c.md`. Quarantine
`BOOK2-PART34-ARCHITECTURE-20260902b.md` as `SUPERSEDED__live__`.**

**PART 3 IS IN THE MASTER AND THE CHAPTER NUMBERS ARE NO LONGER HANDLES.** `BOOK2-20260902.md`
carries the part as Ch 13–17, so every `Ch 1x` in this file naming a book 2 Part 3 chapter has been
shifted by one and now names the chapter it will keep: **the recursion chapter is Ch 13, *Underneath
the cycle* is Ch 14, *The Fixations Themselves* is Ch 15, the Levels chapter is Ch 16, and
*Falling and rising* is Ch 17.** Seventy-one sites. **References to book 1's chapters were not
touched** — they are always written `book 1's Ch N` or `book 1 Ch N` and were held out of the pass by
that prefix, and the two `Ch 18` references are book 1's as well.

**The handles moved inside the amendment history too, and deliberately.** Those blocks describe past
passes, but what they carry are handles rather than recorded facts — that is what the deferral
declared them to be — so leaving them at the old numbers would have left the file naming the same
chapter two ways. **What no block's wording claims is that a past session used the number now
printed.**

**`Ch 12 — Learning to See` is placed but undrafted and its number is reserved**, which is why Part 3
opens at 13 and not 12. See §1's header.

**AMENDED 2026-09-02 by `Job39 drafting 09012026`, and it takes a letter, the date being taken:
`BOOK2-PART34-ARCHITECTURE-20260902b.md`. Quarantine `BOOK2-PART34-ARCHITECTURE-20260902.md` as
`SUPERSEDED__live__`.** Surgical edits at four sites, **not a retyping**. **`[A]` RULED A NEW CHAPTER
INTO PART 3** — the recursion material, opening the part — after this session found that the census
marks book 1's origins chapter PLACED while the architecture specifies only half of it. The part
header, a new §1 section, §7 item 5 and a new §7 item 13 are the four sites. **No other chapter's
content is touched and nothing above is retracted.**

*~~CHAPTER NUMBERS ARE NOT CHANGED IN THIS PASS, DELIBERATELY, AND EVERY `Ch 1x` BELOW IS A HANDLE
RATHER THAN A FINAL NUMBER.~~ **DISCHARGED 2026-09-02 by `Job41 drafting 09022026`, in the pass this
deferral named.** The estimate of some forty sites was low; it was seventy-one. The reasoning is
retained because it is the record of why the numbers were wrong for two days: inserting a chapter at
the head of Part 3 shifts the four after it by one, book 2 uses no chapter numbers in prose so
nothing in the manuscript depended on them, and this file's one known defect class is a rewritten
section leaving lines that point at it still standing. `[C]` call, stated rather than asked.*

**AMENDED 2026-09-02 by `job38-drafting-20260902`, and it takes a new date:
`BOOK2-PART34-ARCHITECTURE-20260902.md`. Quarantine `BOOK2-PART34-ARCHITECTURE-20260901b.md` as
`SUPERSEDED__live__`.** Surgical edits at three sites, **not a retyping**, and **all three are the
same defect**: `[A]`'s 09-01 ruling that a letter never names a phase killed the notation
requirement, the §1 Ch 14 section was rewritten in that pass, and **three other lines that depend on
it were left standing** — the Ch 16 cross-reference, §7's item 12, and the DRAFTED pointer, which now
names the whole-chapter file. *The lesson is `[C]`'s and goes in the handoff: a rewritten section is
not a discharged ruling until every line that points at it has been grepped.*

**AMENDED 2026-09-01 by `Job36 doctrine 09012026`, and it takes a new date: `BOOK2-PART34-ARCHITECTURE-20260901.md`.
Quarantine `BOOK2-PART34-ARCHITECTURE-20260831b.md` as `SUPERSEDED__live__`.** Surgical edits at five
sites, **not a retyping**. **Ch 16** loses the retracted arisings clause it carried in bold and gains
`[A]`'s continuum ruling on Z0, which closes the two-faces question the census routed here. **Ch 17's
falling sequence** gains the first brake's three 09-01 entries. **The open-items table** is repointed,
and two file references now name the 09-01 letters.

**Session `Job31 architecture 8-30`, §0 slot 6.** This is the real architecture pass the 08-15
provisional file was written to hold a place for.

**Supersedes `BOOK2-PART3-PROVISIONAL-20260815.md`**, which was explicitly provisional and is now
fifteen days behind the doctrine. **Does not supersede `BOOK2-ARCHITECTURE-20260815b.md`**, which
remains the authority for Parts 1 and 2 — but corrects two things in it, listed at §8.

Provenance: `[A]` where marked, `[C]` otherwise. **§7 lists every call `[C]` made this session, in
one place, so a later session can find them without reading the file through.**

**REVISED 2026-08-31 by `job34-architecture-20260831`, superseding
`BOOK2-PART34-ARCHITECTURE-20260831.md`.** *Changes, and there are no others:* **`[A]`'s four rewritten
sketches are placed — book 2 carries them, at Ch 16, immediately after the crossing account** (§1,
Ch 16). **Ch 14 gains the notation requirement that placement creates** (§1, Ch 14). §6 gains what
stays open on them. §7 gains the two calls, under their own date. No chapter's content is otherwise
touched and nothing above is retracted.

---

## 0. WHAT DECIDED THIS PASS

The provisional file was written on 2026-08-15. Between 08-26 and 08-27, four sessions produced an
account of the descent that the model had never had: the three outcomes at the crossing, the burial
reflex and its reinforcement, detachment's dwell, the ignoring habit, urgency as an analog quantity,
and two brakes. **Almost all of it is falling mechanism, and the provisional file's falling chapter
is book 1's account, in which nothing happens at a crossing.**

Three older rulings also reach this part and neither 08-15 file knows about them: **Level 0 is
abolished** (08-23), **a level is many turns and the turn is the quantum of depth** (08-20), and **a
fixation is where the process moves very much more slowly, not where it halts** (08-27).

---

## 1. PART 3 — THE DEPTH OF FIXATION

**Five chapters, DRAFTED AND PLACED 2026-09-02 as `BOOK2-20260902.md` Ch 13–17, and the numbers
below are final.** Book 2's chapter numbering throughout this file is
`BOOK2-ARCHITECTURE-20260815b.md`'s, where Part 2 runs Ch 6–12 and Part 3 opens at 13. **`Ch 12 —
Learning to See` is placed but undrafted, and the master reserves its number rather than closing the
gap** — closing it would have bought one renumber now at the price of a second when Ch 12 is written.
*The provisional file numbers the same chapters one lower again because it was written before
Learning to See was confirmed into Part 2. That numbering is void — see §8.*

**What is still owed here is not the prose.** Each section below specifies a chapter that now exists;
read it as the record of what was asked for, against which the placed text can be checked. *The
`[C]` calls at §7 stand as made.*

### Ch 13 — Where the Inner World Came From

**Opens the part. RULED 2026-09-02 by `[A]`.** Book 1's Ch 17 *Where the Inner World Came From* and
*What Follows From Recursion*, as one chapter. **Title not settled**; this file uses the description.

**How it came to be missing.** `CENSUS-book1-into-book2-20260901.md` carries one row for book 1's
origins chapter — 2,736 w, destination Ch 15, **PLACED, architected** — and the Ch 15 specification
below covers its second half only. Three sections of the first half appear nowhere in book 2 and in
no architecture file, and nothing was ever decided against them. **The census decided the unit whole
where its own method rule says to read both passages**, which is the same class of miss it records
against itself twice at the passage level. *Found by `Job39 drafting 09012026` while drafting Ch 15
from the same book 1 chapter.*

**What the chapter carries.** The picture an animal holds of its surroundings; predicting another
animal by consulting one's own machinery, which turns the picturing capacity inward as a way of
reaching outward; the imaginary self as the by-product, real in the only sense inner things are and
not an object, which is why looking for it turns up only more content. Then what follows from a
picture that contains the one holding it: **that the two realms differ in admitting self-reference
rather than in being material or not**; that a fixation stays out of view because it is a bias in the
picturing and not an item in the picture; that detachment is the odd orientation because it is the
capacity turned back on its owner, which is also why any way out runs through it and why it is the
one orientation with two faces; **that recursion is why there are scales at all**; and that the way
out therefore cannot be a shutting down of the folding, since noticing a fixation is itself an act of
it. No fault is being corrected — the self is a by-product of something working as it should.

**Why it opens Part 3, and why nowhere else was available.** *`[C]`'s reasoning, which `[A]` accepted
when he ruled it.*

- **Not Part 1.** That is where a reader learns the types, and mechanism placed there is an
  abstraction carried through nine type descriptions that do not use it — the same reason the mental
  deposits are kept out of the early chapters.
- **Not Part 4.** The imaginary self is this model's own version of no-self. Meeting it first among
  the parallels makes the book's own foundation arrive as a borrowing, which the presentation rule at
  Ch 14 forbids in as many words.
- **The two sections are one argument and are not split.** The consequences are unintelligible
  without the account that produces the self-reference, which is why book 1 runs them consecutively.
- **At the head, because two things Part 3 already asserts are grounded only here.** Detachment being
  the one orientation that *can* have two faces — book 2's Ch 4 asserts the two faces and its Ch 11
  says which one appears, and neither says why there are two. And the existence of scales, which the
  cycle chapter has been using since Part 2.

**What this costs, stated.** *`Ch 14 opens the part`* was a `[C]` call at §7 item 5 and it loses its
position, **not its reason**: it opens the part because the crossing account needs the passages
fundamental first, and a chapter sitting in front of it does not touch that. **The two chapters are
adjacent and stay so.**

**ONE COLLISION TO RESOLVE WHEN THIS IS DRAFTED, AND IT IS NOT A CONTRADICTION.** Ch 15 explains why
the direct inward look for one's own fixation fails — there is no proposition in it to inspect. This
chapter explains why it never shows up as an item — it is a bias in the picturing. **Both are book
1's and both are true; one has to be the account and the other a second angle on it**, or a reader
gets the same fact explained twice in two chapters. *`[C]` recommendation, not ruled: this chapter
carries the structural version, since it is the one that follows from recursion, and Ch 15 keeps the
developmental version, which is what its own argument earns.*

**THE OTHER TWO SECTIONS OF THAT BOOK 1 CHAPTER ARE STILL UNPLACED.** *Principles, not laws* — that a
principle of the mind is one path described as though it ran alone, which is why the correspondences
are tight at the ends and loose in the middle, why nobody sits at a position, and why the notation is
not measurement — **is not in this chapter and has no home.** It is the ground of the correspondence
guard Ch 16 already states, so as drafted that guard stands on nothing. It also states the model's
own weakness plainly, which makes it the same kind of thing as the appendix on designing the tests
that the census carried on exactly that ground. **Open, and on the list by name at §7 item 13.**

### Ch 14 — Underneath the cycle: the three transitions

Opens the rest of the part, immediately after the recursion chapter. **`[C]` call — the 08-15b file
left the placement open with three candidates.** *Its position at the head of the part was superseded
2026-09-02 and its reason was not; see the section above.*

The three passages are fundamental and the orientations are derivative, names for the three ways a
process can come to rest. Two transformations and one ending-and-arising, never three passages of a
kind. Book 2's Ch 7 has already given the ordering; this says what the ordering is made of.

**Why it opens the part rather than closing Part 2 or sitting late.** When the 08-15b file left this
open, the falling chapter was a description of a person drifting downward and nothing in it happened
at any particular passage. **The whole descent now sits at one transition.** A reader who has not
been told that the passages are the fundamental thing will meet the crossing into detachment as a
special fact about detachment rather than as the general structure showing itself at one node. Ch 16
depends on this chapter, which rules out placing it late; Part 2 is drafted and complete and does not
use the material, which is reason enough not to reopen it.

**AND IT NAMES THE PHASES. Added 2026-08-31 as a notation requirement; REWRITTEN 2026-09-01, when
`[A]` ruled the notation out. The requirement is created by the sketches and is not optional if
they are placed.** *Read `Ch 16's sketches` until 2026-09-02, when the ruled placement at Ch 15 moved
them; the requirement is unaffected by which chapter holds them.* In book 2, `A`, `B` and `Z` name orientations a person holds — positions on the
loop at Ch 7, position names at Ch 11. The 08-31 sketches also used them for the phases of a single
endeavor, with both senses inside one sentence, and the plan was for this chapter to give the second
sense.

***`[A]` RULED ON 2026-09-01 THAT THERE IS NO SECOND SENSE.*** **A letter marks where a person stands
— orientation, fixation, lean — and is never used of a phase an endeavor has reached.** Phases are
named in words, and where the kinship should show, in the orientation's own adjective: **the
enthusiastic phase, the cautious phase, the detached phase**, which is `[A]`'s own usage in his
rewrite. Where the resemblance is not the point, the plain nouns serve: the impulse, the examination,
the ending. **Book 2 therefore adopts no arc notation at all.** His reasons: book 2 had none, so
taking the letters was the change and refusing them the default; the letters in the sketches glossed
verbs that had already said it; and typography cannot carry the distinction, because his own text
glosses both senses in parentheses two lines apart.

**So what this chapter owes is the correspondence, not a notation** — that the phases are what the
orientations are named after, which is why the phase takes the orientation's adjective. That claim
belongs here because this is the chapter that makes the passages fundamental and the orientations
derivative. **It also states the letter rule itself**, being the only place in book 2 that says what
a letter means. Book 1 already has the correspondence sentence, in its cycles chapter: *the phases of
initiation, continuation and finishing correspond to the orientations A, B and Z.* **`[A]` cited that
line himself on 08-31**, when he approved `stage` becoming `phase` in his rewrite.

**DRAFTED WHOLE 2026-09-02.** `CH13-UNDERNEATH-THE-CYCLE-20260902.md`, cut by
`job38-drafting-20260902`, which absorbs `CH13-PHASES-20260901b.md` as its last two sections and
supersedes it. Its grandparent
`CH13-NOTATION-20260901.md`, written earlier the same session to establish the second sense, is
quarantined. **Book 1 keeps its 17 uses and is untouched, being a reference.**

**`phase` is the word, and it is his choice.** `stage` is not book 1's term in this sense;
`orientation` is a way of attending and `stance` is a position held, so neither is free; `moment` is a
point where these need a span.

**Kept out.** The Trimurti and Freud. Book 1 introduces the transitions *through* the Trimurti and
book 2 must not, or the foundation arrives as a borrowing. **The presentation rule: name the book's
transitions first, Trimurti and Freud afterward as two instances.** *That rule makes a promise Part 4
has to keep — see §2.*

**A SPECIFICATION CHANGE, AND IT IS NOT OPTIONAL.** Both 08-15 files state that a fixation is the
next transition failing to start. **`[A]` ruled the opposite shape on 08-27: a fixation is where the
process moves very much more slowly, NOT where it halts.** Two manuscript sentences are already
recorded as needing new wording on that ruling — book 1's Ch 15 *the place they habitually stop* and
book 2's Ch 7 near-twin. **This is a third site and it is the one that matters most**, because here
the claim would be stated as doctrine rather than in passing. Nothing is drafted, so it costs
nothing now. ***`[A]` said the wording is open and that no replacement is to be written on the
strength of the ruling.***

### Ch 15 — The Fixations Themselves

**RULED PLACEMENT, 2026-09-02. THE CHAPTER GAINS A DESCRIPTIVE FIRST HALF AND THE ORIGIN MATERIAL
BECOMES ITS SECOND.** `[A]`, 09-02: *the descriptions of the fixations, including "The two ends, and
what lies between them" and what follows, should all go at the beginning of chapter 15* — and, when
`Job41` read *what follows* narrowly, his own correction of the scope: *doesn't "and what follows"
come after all the orientation material both before and after the change?* **It does.** So the
material is every passage that describes what a fixation is or what it does, wherever it currently
falls, on both sides of the crossing machinery.

**Ch 15 is not a compromise site; it is the earliest site available.** The descriptions use the
crossing, which is the ending passage and arrives in Ch 14, and they use detachment's oddness, which
is derived in Ch 13. Nothing that describes a fixation can precede those two chapters, and nothing
requires it to come later. **The ruling lands the material at the first place it can go.**

**The new order of the chapter, and each item names where it comes from:**

1. **Detachment's range.** Ch 11's *Detachment's lean is not like the others*, moved entire, absorbing
   Ch 16's *The two ends* except that section's last paragraph.
2. **Disregarding, and not seeing at all**, moved **whole** from Ch 11. *`[A]` corrected the scope on
   09-02: its four paragraphs are not two kinds of thing.* **Three things are easy to run together**
   *is the four fates in miniature — declining to attend is* ignored, *the looking stopping is*
   blocked *— and* **The three are not two kinds of thing** *is Ch 15's* Habit carries it *word for
   word. The other two paragraphs apply that content to the leans; they are a use, not a subject.*
   **It sits ahead of the fates rather than merging into them**, which puts the miniature first and
   the full account immediately after — the shape `[A]` asked for.
3. **The four fates**, and *Blocking is not a decision* — both from Ch 16.
4. **Which fixation handles a fear, and what it has to work with.** From Ch 16.
5. **The four sketches.** From Ch 16. `[A]`'s own text and his own first line — *the difference
   between the fixations shows plainly if the same endeavor is walked through in each* — which is a
   description of the fixations and nothing else.
6. **Then the chapter as drafted**, unchanged: two channels, the hinge, habit carries it, why it does
   not turn over, what previous thoughts have laid down.

**TWO PAIRS INSIDE THE CHAPTER'S SECOND HALF, FOUND 09-02 AND NEITHER REACHED BY THE RULING.**

- **A fixation cannot be found by looking for it, and is known by what it produces.** Ch 13's *A slant
  on everything rendered* derives it from recursion; Ch 15's *The hinge* derives it from development.
  Two complete accounts. **The join check settles it and it is not a cut.** *Habit carries it* follows
  *The hinge* and closes on undoing a fixation meaning *restoring the original to the level where it
  can be declined — making it available again*, **which presupposes a fixation can be brought into
  view, and the paragraph that licenses that is the one a cut would take.** *Cut it and the reader has
  two paragraphs saying a fixation cannot be found, nothing saying it can be seen, and then a section
  ending on making it available again.* **Both stay, each being load-bearing where it sits. Ch 15's is
  reworded to read as returning to something already met rather than as arriving at it.**
- **The arising hands nothing on.** Ch 14's *What the odd one carries* states it as its chapter's
  central claim; Ch 15's *What previous thoughts have laid down* derives it again to start the mental
  deposits. **Also not a cut.** *What follows the clause is* it is laid down instead, *which has no
  reason without it, and nothing after the mental deposits stands on the derivation.* **The clause
  stays and stops being a derivation: it names the claim and points back to Ch 14.**

**Why the descriptions come first and the origin second.** Ch 14 closes by saying the orientations
come first in a reader's experience and the passages first in the thing itself. Ch 15 runs the same
way: what a fixation does at the ending, which the reader can check, and then why it is there at all.
**The old title, *Where Fixations Come From*, covered the second half only. RULED 2026-09-02 by `[A]`: the chapter is *The Fixations Themselves*.** *`[C]` recommended *What Fixations Do, and Where They Come From* and offered the short form; he took the short form.*

**THE ONE DEPENDENCY, AND IT IS DISCHARGED WITHOUT MOVING ANYTHING.** `OPEN-from-job41-20260902.md`
holds that *the crossing* is a term the reader does not have until Ch 16 introduces it, so *Which
fixation handles a fear* would arrive in Ch 15 undefined. **The crossing is not the health axis's
term.** It is the passage into detachment — the ending, which Ch 14 gives as one of the three
passages. **Ch 14 names it, in one sentence, at *What the odd one carries*, where it already says
that what changes a person's depth happens at the one place a process ends.** Ch 16 then keeps what
is genuinely its own: that a level change can happen there and nowhere else.

**THE SECOND DEPENDENCY, AND IT IS WHY THE FATES MOVE.** Three of the four sketches end on anxiety
left unattended and accumulating, and *unattended* is the ruled genus over *ignored* and *blocked*.
The sketches therefore cannot precede the four fates. **Under the narrow reading of the ruling the
fates stay in Ch 16 and the sketches are stranded there with them; under his own widened reading
they travel together.** His widening is what makes the placement possible.

**THE SCOPE WIDENED AGAIN ON 09-02, AND SO DID THE METHOD.** `[A]`, on being shown the marked
chapters: *i was suggesting that you might need to add repetition rather than delete it — in relation
to the parts that are to be moved.* **A move may create a need at the source, not only satisfy one at
the destination**, and the minimal statement left behind is part of the move rather than a concession.
*And on removal, same exchange:* **maybe it is necessary, but it should be done with the awareness of
the other place it occurs.** Both are now standing rules at §7 of the handoff.

**AND IT ANSWERS A SECOND QUESTION THAT WAS LEFT UNANSWERED.** `Job41` found Ch 11's *Disregarding,
and not seeing at all* saying the four fates and the blocking paragraph again, four chapters before
Part 3, and put to `[A]` whether Ch 11 gives them up; the question was overtaken. **It does not need
a separate answer.** Both copies converge here, so the book carries one crossing account rather than
two, and the choice of which copy survives is not made — the passage is written once, in this
chapter, out of both.

**WHAT CH 11 KEEPS.** The eight wings, reading a person either way, fractional leans, opposite, and
where the two systems disagree — and a short closing section holding the three-things distinction:
declining to attend to what has been seen, the looking stopping without anything being decided, and
nothing left to decline where the looking has stopped, with the leans as what makes the difference.
**That distinction is `[A]`'s own, sited in Ch 11 by his 08-15 instruction, and it is about reading a
lean rather than about the fate of a fear.** *Its involuntary-to-chosen paragraph — `something
registers, it carries a feeling…` — stands word for word in Ch 15's `Habit carries it` and is the
only near-verbatim pair in the master. Ch 15 keeps the full statement, habit being its subject and
the load-bearing use being there; Ch 11 compresses to a single sentence.*

**WHAT CH 13 KEEPS, UNCHANGED.** *Why detachment is the odd one* is a derivation from recursion, not
a description, and the drafting record treats it and Ch 11's competence-and-method derivation as two
independent routes to the same fact with neither superseding the other. **Ch 4 and Ch 7 keep their
short statements** — the reader's first meeting with the two faces, and which neighbour produces
each, which the arrows need.

**WHAT THIS BREAKS, STATED SO IT IS NOT BROKEN SILENTLY.** `Job34` sited the crossing account
immediately after *Where a level change can happen* because the two read as one passage — the first
says where a level change can happen, the second whether it does. **That pairing was right while the
fates existed only there.** It does not survive the fates being stated twice in one book, and the
repair is one sentence in Ch 16 naming blocking as the fate that accrues. *`Job34`'s second call, that
the sketches follow the crossing account, is not overturned but carried: they still follow the fates,
in their new chapter.*

**THE JOIN CHECK, RUN ON `[A]`'s INSTRUCTION 2026-09-02 AND WRITTEN OUT BECAUSE §7 NOW REQUIRES IT.**
Every move was read at both ends — the section that follows the gap it leaves, and the section that
follows it where it lands. **Four of the seven were marked wrongly before this was run.**

1. **Detachment's lean is not like the others, leaving Ch 11.** *Nothing after it in Ch 11 depends on
   it — it is the chapter's second-to-last section — and Ch 13 derives the two faces for itself.*
   **But Ch 11's whole subject is leans, and this is the section saying detachment's lean does not
   work like the other two.** Removed outright, the chapter ends on the eight wings, fractional leans
   and the disagreement with the classical rule, and **the reader carries a wrong generalization for
   four chapters. A MINIMAL STATEMENT MUST STAY: one range with two directions, not two conditions,
   with the full account named as later.**
2. **The two ends, leaving Ch 16.** *Where a level change can happen* follows the gap and **leans on
   the range directly** — the crossing opens only at the two extremes of what is being registered.
   **A MINIMAL STATEMENT MUST STAY**, and it is the two sentences that are about the axis rather than
   about detachment. **On arrival the block does not survive as written:** it opens *both ends of
   this axis are detachment*, and there is no axis in Ch 15. **THE OPENING IS REWRITTEN.**
3. **Disregarding, and not seeing at all, leaving Ch 11.** *It is the last section of Ch 11 and of
   Part 2; nothing follows it inside the part.* **A MINIMAL STATEMENT MUST STAY** — the three named,
   and the leans as what makes the difference — because the siting is `[A]`'s own and because it and
   item 1 together are what Ch 11 now closes on. *Without them Part 2 ends on a point about how the
   classical evidence was gathered.*
4. **The four fates, leaving Ch 16.** ***Spoiled arrivals* stays in Ch 16 and turns on the contrast** —
   a spoiled arrival passes and nothing is debited, blindness accrues and locks — **which needs the
   four nameable at that point.** **A MINIMAL STATEMENT MUST STAY, and one sentence naming blocking is
   not enough: the four are named in brief and the full account, with the ordering and the two-question
   sort, is Ch 15's.** **On arrival:** the section opens by saying only one of the four lowers a person
   *on the axis*, which the reader has not met. **THAT CLAUSE POINTS FORWARD INSTEAD.**
5. **Blocking is not a decision, leaving Ch 16.** **NOTHING OWED.** *Ch 4 carries the small version —
   a decision to not see could happen only after a thing has already been seen — and Ch 17 is the only
   other user and comes later.*
6. **Which fixation handles a fear, leaving Ch 16.** **NOTHING OWED.** ***Spoiled arrivals* follows the
   gap and leans on the fates, not on this.** *Ch 17's two rate-setters are its other user and come
   later.*
7. **The four sketches, leaving Ch 16.** **NOTHING OWED at the departure** — nothing in Ch 16 or Ch 17
   stands on them. **On arrival they are followed by *Two channels*, which opens the developmental
   account fresh and leans on nothing above it**, so the join is clean but bare. **ONE TRANSITION
   SENTENCE IS OWED THERE**, and it is the seam between the chapter's two halves.

**AND THE CHECK FOUND A THIRD PAIR NOTHING HAD FLAGGED, THE TIGHTEST IN THE BOOK.** *The two ends*'
last paragraph sites partial registering in the middle of the range — *enough registered to feel the
weight of a thing, not enough to look at it* — and ***Where a level change can happen*, the very next
section, says it again in almost the same words.** **Adjacent sections.** So that paragraph does not
need to be held back for the next section's sake: **the next section already carries it, and the
paragraph goes.** *This is why Ch 16's remnant is the both-ends point alone.*

**WHAT IS OWED AND IS NOT THIS JOB'S — two items, each named at §7.** ~~Book 1 carries **two
deprecation marks whose superseding text is named as *book 2 Ch 11's crossing account***; after this
placement that text is Ch 15's, and repointing them is a book 1 edit and job 3's.~~ **DONE THIS
SESSION — there were three marks, not two, and `[A]` authorized the repoint when it was put to him.
See §7 item 17.** **Ch 11's incomplete
sentence** — *A realm can go little known for other reasons; this is the route that runs through
detachment* — travels with the material and is repaired at the destination, restoring the point the
08-29 repair dropped, that a realm going unknown does not mean the person is detached in it. **And
the chapter's title.**

Book 1's Ch 17, minus the spiritual reach at its end, plus Appendix G.2's floor. Two channels,
wanting and hurting; the hinge of anticipation; a fixation as a strategy that outlived its problem;
why it is invisible to its owner — a strategy laid down before understanding existed was never held
as a belief, so there is nothing in it to inspect. Then habit as the carrier: habit runs without
belief, so it builds the trap and keeps the summit alike. The desire/fear asymmetry — desire cycles
because it can be answered, fear freezes because it cannot.

**And the mental deposits close the chapter. `[C]` call, and it departs from the standing
recommendation — see below.**

**Not merged with Ch 14.** The 08-15 file named these two as the remaining merge candidate. They
were one question then. Ch 15 has since gained the deposits as its closing move, and merging would
put four steps in one chapter — what a process is made of, where it can stall, how a child's strategy
hardens, why it goes on producing itself — with the strongest arriving last after a long approach.
Ch 14 is also a claim about processes as such, true of a candle; Ch 15 is about a person's history.

#### The deposits — siting, and a departure stated as the ruling file requires

`RULINGS-job18-20260825.md` §2.4 rules the deposits **mechanism, not identity**: they explain how a
fixation sustains itself, they do not displace the types, and the register is the answer to *why does
it hold?* — never *what you really are underneath*. §2.5 hands the siting to this job and asks that a
departure be said out loud.

**The recommendation is written in BOOK 1's chapter numbers, and that changes what it says.** Two
things fix it. Its hook — *Ch 5 already says a thought is conditioned by the one before it* — is book
1's cycles chapter; book 2's Ch 5 is where the types come from and carries no such sentence. And its
reason for the site it picks, *where the small scale and the contemplative traditions already meet*,
is close to a restatement of book 1's own forward pointer in that same paragraph, which sends the
reader to Ch 14 for the thought-scale loop read against the traditions.

**So the site named is book 1's Ch 13, which in book 2 is Part 4.** `[C]` departs, for two reasons:

- The deposits are ruled mechanism, and mechanism is Part 3's remit. Sited in Part 4, book 2 would
  finish its account of the model without ever saying why a fixation holds, and then supply it inside
  the borrowed part.
- **The reason that made book 1's Ch 13 right is the reason it cannot be right in book 2.** Book 1
  introduces its foundations through the traditions. Book 2 forbids that by the presentation rule at
  Ch 14 above. A foundation arriving inside Part 4 arrives as a borrowing.

**Every constraint the recommendation set is kept.** Ch 1 and the type profiles get nothing. The
cycle chapter gets nothing new — and it is where the hook already sits, drafted, in book 2's own
text at L620. The deposits enter **once, late**, as the answer to the question Ch 15 leaves hanging:
why does a strategy laid down before understanding go on producing itself?

**The term is `[A]`'s own coinage** — 2026-08-30, minted to avoid the traditional *volitional
formations*. So Part 3 owes Part 4 nothing for the vocabulary. **Two consequences, both cheap:**

- **Appendix E gains an entry.** A term coined to avoid a traditional term still has the traditional
  concept behind it. The ledger exists for exactly this, and leaving it out would apply the book's
  standard less strictly to itself than to the parallels it records.
- **Part 4 gets a second instance of the pattern it runs on.** Part 3 states the mechanism under
  `[A]`'s word; Part 4 meets volitional formations and says where the idea came from and what it was
  called. Stronger than a parallel noticed afterward, because the borrowing is admitted rather than
  discovered — which is the register the whole part has to hold.

### Ch 16 — The depth of fixation: the Levels and the core dynamics

**AMENDED 2026-09-02. THE CHAPTER GIVES UP EVERY PASSAGE THAT DESCRIBES A FIXATION, TO Ch 15 — see
the ruled placement there, which carries the reasoning and is not repeated here.** What leaves:
***The two ends, and what lies between them*** except its last paragraph, ***The four fates***,
***Blocking is not a decision***, ***Which fixation handles a fear, and what it has to work with***,
and ***The four sketches***. **The specification below is not retracted; it is relocated**, and every
bullet of the crossing account still governs the passage — in its new chapter.

**What Ch 16 keeps is the axis and nothing else:** the head, the nine rungs, the rule beneath them,
the correspondence, the same nine names in two shapes, what the axis is toward, ***Where a level
change can happen***, and ***Spoiled arrivals***. **It keeps two sentences of the description as
well, because they are about the axis rather than about detachment:** that both ends of this axis are
detachment, one seeing and one blind, which is why the top and the bottom are mistaken for each
other; and the last paragraph of *The two ends*, which sites partial registering in the middle of the
range and is what *Where a level change can happen* is about to use.

**And it gains one sentence.** With the four fates gone, the statement that a level change can happen
only at the crossing no longer has the fates standing behind it, so Ch 16 must name **blocking** as
the one fate of the four that accrues, referring back rather than restating. *That single sentence is
the whole repair for the pairing `Job34` made and this placement breaks.*

Book 1's Ch 15, plus Appendix G.1, plus the crossing account moved up from falling.

**What the axis is.** One currency, two objects; the axis's object is oneself, and the derivation
that it cannot be a realm — if it were, health would just be another name for type, and every Six
would be fixed at one level for life. **The three floors**: the same nine-position pattern found on
the physical world, the inner world, and the way a person handles their own fixation, with the third
being a different sort of quantity from the first two.

**The nine rungs, individually named.** Riso and Hudson's Level names, credited at first use, carried
as book 1 carries them — the full table, with four landmarks marked to a stance and the rest shading
between. **A reader must be able to name where someone is.** The core-dynamics rule with the
four-term chain (`[A]`, 08-26: *yes, four*), and the correspondence stated as observed rather than
derived, tight at the ends and explicitly loose in the middle.

**Then the geometry, in the amount §7 specifies:** level change happens only at the crossing into
detachment, and that crossing is passable only at the extremes of registering — full registering
going up, none going down, partial registering held in the trap.

**Then the crossing account, moved here from falling. `[C]` call.** It sits immediately after the
geometry because the two read as one passage: the geometry says *where* a level change can happen,
this says *whether* it does.

- **The four fates.** *RULED 2026-08-30. This bullet used to read three, and used the two names that
  were replaced.* A fear arriving at the crossing is **worked through**, **given up on**, **ignored**
  or **blocked**. **Only blocking descends the axis.** The first three arrive sighted; what separates
  them is what gets dropped. **Worked through** — the fear is met and dealt with rather than disposed
  of; nothing is dropped because there is nothing left over. *(`settled` was ruled for this fate on
  08-30 and replaced on 08-31: book 1 already has a fear settling into a fact, which is the descent.
  `worked through` is both books' existing phrase for the same thing.)* **Given up on** — the want behind the fear is dropped, so the fear is
  genuinely gone and a regret remains. **Ignored** — nothing is dropped; fear and want both stay
  intact and only the occasion is let pass, which is why it returns. **Blocked** — turned away from
  before it arrives.
  **The four are ordered, not listed.** Within one crossing a fear meets the sighted end first and
  the end that turns away second, so settling and giving up on happen while it is in view and what
  survives that reaches the end that turns away. **The sort is two questions:** is the fear in view,
  and is it disposed of. One combination is empty — nothing can be disposed of that was never seen —
  and the emptiness is content, not a gap.
  ***`[A]`'s own "in between" framing for the third outcome is WITHDRAWN. Do not reintroduce it.***
  ***And arrival at Z+ does NOT automatically fire the blindness loop — retracted 2026-08-30. Z+ is
  where blindness can happen and the only place it does; it is not what makes it happen.***
- **Why burying is not a choice.** Something deep sees the threat and the information is blocked *by
  design* from consciousness; the reaction is reflexive, reinforced by a second unconscious
  recognition that an unpleasant anxiety was avoided — **and the reinforcement was laid down when the
  anxiety was at least semi-consciously felt, at a preverbal stage, hidden as rational consciousness
  grew on top of it.** This must precede the machinery: a reader who thinks burying is chosen reads
  everything after it as weakness.
- **The dwell, and what happens upstream of it.** The fear lives in a **realm**, so the fixation
  handling it is that realm's, not the person's type. Enthusiasm and caution act *before* the
  crossing — enthusiasm underruns the examination so contingencies arrive unprocessed, caution
  settles most of them upstream and fails by overload instead. **Detachment acts at the crossing, and
  its instrument is dwell time:** slow at the caution end and more is processed, quick at the far end
  and less is.
- **Spoilage is not blindness.** Arrivals at caution and enthusiasm without the prior passage lived
  are spoiled — anxiety in place of alertness, brittle energy in place of appetite. **Spoilage is a
  quality of one arrival, momentary, no debit. Blindness is an accrual, at the Z crossing only, and
  it locks.** They coincide at exactly one of the three arrivals, which is why the drafting fused
  them. *Book 2's Ch 7 is already right about this in its vocabulary.*

**THEN THE FOUR SKETCHES, AND THEY CLOSE THE CHAPTER'S ACCOUNT. `[C]` call, 2026-08-31.**

**The text is `[A]`'s own**, held verbatim at `SKETCHES-rewrite-by-author-20260901.md` §1. He called
book 1 Ch 15's four walked-through sketches incomprehensible and rewrote them himself on 08-31. Book
1's originals are DEPRECATED in `rev2-0814m.md` and are **not** book 1 copy — he ruled the same day
that book 1 is not being fixed, only used as a reference for writing book 2. **So his text had no home
in either book, and this is the decision that gives it one.**

**Book 2 carries them.** Book 2 has no walked-through endeavor anywhere, and the crossing account
above is entirely machinery — the four fates, the reflex, the dwell, spoilage — with no lived instance
in it. One endeavor run four ways is what a reader needs to hold that machinery.

**Here, and not earlier, and the reason is in his text.** Three of the four sketches end on anxiety
left unattended and accumulating: the cautious sketch, the Z− sketch, and the Z+ sketch's last
sentence, that unattended anxiety goes on causing stress though it is not consciously seen. **That
thread has nothing to rest on until the crossing account exists**, and it is deliberate — it is how
the sketches tie an ordinary endeavor to the descent. Placing them earlier means cutting it, which
would be fitting his text to a slot rather than the reverse.

~~**Ch 14 and Ch 15 were both considered and neither takes them.** Ch 14 is specified above as a claim
about processes as such, true of a candle; the sketches are about four kinds of person. Ch 15 is a
person's history and the deposits, which is a different subject.~~ **SUPERSEDED 2026-09-02 by the
ruled placement at Ch 15, and only the Ch 15 half of it. Ch 15 takes them.** *The reason given against
Ch 15 was that its subject is a person's history; the placement makes the fixations themselves that
chapter's first subject, so the objection is answered by the chapter having changed rather than by
being overruled.* **The reason against Ch 14 stands untouched**, and so does the reason given below
for the sketches coming after the crossing account — they still do, in the chapter both now sit in.
**What Ch 14 does owe them is the phase
names and the letter rule** — see the rewritten addition at that chapter. *This read `the notation`
until 2026-09-02; `[A]` ruled the notation out of existence on 09-01 and the line was missed in that
pass.*

**What the sketches do that nothing else in the part does.** `[A]`'s closing paragraph, which he
deleted and then approved in replacement, states it: what arises differs by fixation; and where the
arising is the same, the difference falls later, each endeavor resting longest where its person is
comfortable. **Either way the fixation is at work before the endeavor's own shape can account for
it.** That is also the paragraph's job as a guard — the sketches walk the phases in order, which
invites a reader to conclude the fixation is one of them.

**CORRECTED 2026-09-01 BY `[A]`'s RULING, AND THIS FILE CARRIED THE CLAUSE IN BOLD.** The sentence
above used to read *what arises differs by fixation, so the fixation has selected the population of
arisings before any endeavor begins*. **That clause is cut** — it is the selecting-the-population
claim `[A]` retracted on 08-20 and ruled deleted from book 1's Z+ sketch on 08-26, and he ruled it
out of the closing paragraph on 09-01. **Nothing replaces it.** A drafting session writes the
paragraph as `SKETCHES-rewrite-by-author-20260901.md` §2 item 7 now prints it. *Found by grepping the
clause across the whole set rather than by going to the site the set note named — this file was the
second site and no file named it.*

**THE DRAFTING PRECONDITION IS DISCHARGED. 2026-09-01.** The seven changes `[A]` approved singly, and
his three typos, are applied in **`SKETCHES-APPLIED-20260901.md`**, cut by
`job37-drafting-20260901`. **That file is the text to place; `SKETCHES-rewrite-by-author-20260901b.md`
§1 stays as the verbatim record of what he typed and is not the placement copy.** Two further changes
were ruled by him in the drafting session itself and are in the applied file: **`if he acts` becomes
`if they act`**, and **the five phase letters come out** on the letter rule at Ch 14 above, leaving
the three that name a person's fixation.

**`resolving` and `arising` are dead names at every scale. `[A]` 2026-09-01:** they were his proposals
for Z− and Z+, an earlier session rejected them, **and the rejection is of the names, not of one use
of them.** A `[C]` proposal to reuse the pair for the two ends of an endeavor's detached phase was put
to him and refused. Where the sketches must point at one end, they **describe** it — *the seeing end
of the detached phase*, *the end that turns away* — which is the crossing account's own language.

**Hazard.** *Level 1 is Z−* is an identity in the currency only. A sentence that lets the reader infer
the healthy person is thereby detached breaks the ruling in its first paragraph. **And the 08-23
session found three later passages stating that identification flat where the correspondence hedges
it; two of them carry real weight. This chapter is where that starts.**

**RULED 2026-09-01 — Z− AND Z+ ARE ONE CONTINUUM AND Z0 IS THE ZERO-LEAN POINT ON IT.** `[A]`:
*there is a continuum between z- and z+ and z0 is just a point somewhere in the middle. so z0 is an
ideal that's important only as representing total detachment which is important in spiritual
traditions.* **This closes the two-faces-of-Z0 question the census routed here, and closes it by
striking it rather than answering it:** *how many faces does fixation-Z0 have* presupposes that Z0 is
a stance able to carry one face or two, and on the continuum the two faces belong to the two
directions of lean away from the point, not to the point. **Book 1's one-face assumption is struck,
not decided.** It sits inside the *Additional Topics* section the census already cut from book 2, so
it dies with that section and needs no mark.

**What the ruling settles for this chapter.**
- **Blank unawareness of one's own pattern is not near the middle; it is the blind extreme.** So
  nothing new moves into Level 1's neighbourhood and the difficulty book 1 predicted for the top of
  the health axis does not arise. *`[C]`'s supporting derivation, and it is `[C]`'s: a fixation is a
  standing preference about where attention is directed, so not attending to one's own fixation is
  that preference turned on oneself, with the same two ends the crossing has — the pattern seen and
  looked away from, or never seen at all, which are the ignored and blocked fates read on the third
  floor.*
- **Partial registering sits in the middle of the axis, which is where the trap already is.** The
  crossing is passable only at the extremes of registering; no lean either way is Z0 read on the
  third floor. **The geometry and the position now agree instead of being stated separately.**
- **Realm-Z0's two-valuedness is forced, not chosen.** Book 1 calls it *deliberately* two-valued. At
  zero lean there is no lean to decide which face shows, so something outside the position must, and
  the health axis is what is available. **Do not write it as a design decision.**
- **Total detachment is the absence of both pulls, which is why the midpoint is the ideal and why it
  is nearly unoccupied.** The two ends are where detachment is least pure — Z− weighs and decides as
  the cautious person does at low amplitude, Z+ runs on impulse and returning boredom as the
  enthusiastic person does without arriving; both shade toward an active orientation. *This step is
  `[C]`'s and `[A]` ruled it in with the continuum.*
- **THE HAZARD ABOVE IS UNCHANGED AND SHARPENED.** The health axis being the sight coordinate on the
  third floor still says nothing about which orientation a person is fixed at in either realm.

**AN UNANSWERED COST, RECORDED SO IT IS NOT REDISCOVERED.** If the health axis is the sight
coordinate on the third floor, the third floor is still said to carry the whole nine-position
pattern, and **where its enthusiasm and caution positions sit is unaccounted for**. Ch 16 already
calls the axis a different sort of quantity from the other two floors, so there is room for an
answer; none is written anywhere. **Put to `[A]` when it next matters; it blocks nothing now.**

### Ch 17 — Falling and rising, and the problem of leverage

**Merged, and the merge is `[A]`'s, 08-15, reaffirmed by him 2026-08-30 after being asked directly
whether the new material forces two chapters.** It does not, once the crossing account moves to
Ch 16. Both chapters then land near 4,000 words.

*Measured 08-30, since the question was about length:* book 1 supplies about 1,900 words of falling
across two sections of its Ch 17, plus about 990 in its Ch 5 that tells the same thing a second time
and collapses when told once; and about 1,150 of rising, plus the leverage section of its Ch 18. The
new material is nine mechanisms in no chapter of either book, all landing on the falling side. Book
2's longest drafted chapter is Ch 5 at 4,807 words; most run 500–2,100.

#### The chapter does not walk down the rungs. `[C]` call, on `[A]`'s 08-20 handover.

`[A]`, 08-20, said the Levels-or-turn question was one of presentation and did not decide it. **The
material has since decided it.** Blindness accrues in fractions of a level, one crossing at a time,
so a rung is a stretch containing many crossings rather than a step. The routing between fixing a
failing and hiding it shifts by degrees as sight fails rather than switching on at Level 7. The
correspondence is loose in the middle by ruling. **A chapter organized rung by rung would be
sequenced by markers whose looseness its own mechanism asserts.**

**This does NOT mean the rungs go unnamed** — Ch 16 names all nine and carries the table. It means
the chapter's argument advances by the crossing, and the rungs are used to say how far down someone
is.

**Book 1's *The Descent, Narrated* splits.** Its description of the bottom three rungs comes across
nearly whole and belongs here: one goal reached three ways, reckless action drowning out the
knowing, then the world remade so the delusion can hold, then the organized effort exhausting itself
and leaving destruction with nothing to aim at.

**One sentence of book 1's does not come across, and it is now a defect there.** That section opens
by saying the fixation pattern descends in backward order through the orientations, Z → B → A → Z.
**That is the four landmarks read as a motion, withdrawn by `[A]` on 08-20 when he ruled the descent
a blind forward turn and the landmarks coloring.** Book 1 half-catches it a few lines later, saying
it narrates rung by rung without claiming any rung is an orientation. *A second benefit of dropping
it: joining the health axis to the circle is the reserved depth-and-threshold question, and that
sentence is the one place book 1 quietly does it.*

**The replacement sentence, specified so whoever writes it is not deciding doctrine while choosing
words.** The old sentence does two jobs. **The first — explaining why the rungs have the characters
they have — needs no replacement, because it should never have been done there;** Ch 16's
correspondence settles it as an observation with four landmarks. **The second — saying what carries a
person down — is what the new sentence must carry:** crossings into detachment that bury a fear
instead of resolving it, one at a time, each taking a fraction of a level.

***Two versions exist and the shorter one is available now.*** The accrual half is **ruled** —
fractions of a level, one crossing at a time, no event of collapsing — and a repair written on that
alone retires the sentence. **Naming the buried fear is ruled as of 2026-08-30** — the four fates are
ruled, and the fate that descends is `blocked`. *This sentence used to read that the outcomes were
entirely unruled, which was true when it was written.* **Writing either is not this job's** — it is book 1 text, and it lands on the open question
of who writes replacement wording for what a doctrine session closes, which is already blocking two
other repairs.

#### Falling — the sequence

1. **What descends and what it is counted in.** How much of one's own condition registers, accruing
   in fractions of a level, one crossing at a time. **There is no event of collapsing** — the bottom
   of the axis is thousands of separate crossings. First, because it replaces book 1's drift language
   and everything after depends on the descent being granular.
2. **Two contributors to the rate, independent of each other:** where the realm's fixation sits at
   the crossing, and how much the earlier passages left unresolved. **The fall cannot be written as a
   fact about fixation position alone.**
3. **The second entrance — ignoring.** A fear already seen and let in can have attention withheld
   from it. **That is not burial and the person is not blind** — by `[A]`'s 08-27 ruling, sight
   decides the split. Repeated, it becomes a **general** habit that short-circuits the examination:
   the fear registers and keeps its pull, the weighing stops. **Urgency decides whether it can
   continue, and urgency is a slope, not a line** — the model's second continuous quantity.
   Consequences make an ignored fear urgent, at which point it must be weighed or blocked.
4. **The loop.** Book 1's trap transferred to the axis: the lower a person is the less able to
   dissolve fears, and the disturbance is produced by the same act that must not be examined. **Stated
   alone this puts everyone at the floor**, which `[A]` rejects — *a bell curve with most people at
   average levels*.
5. **The first brake.** Consequences press; people struggle harder when things go badly and others
   support them. **The trigger sits outside the blindness** — it does not reach the job lost or the
   money gone — so it keeps working through it, and a person can be driven to struggle without seeing
   why. **Blindness does not weaken the response; it selects the route**, between fixing the failing
   and hiding it. Wanting not to know runs at **every** rung, so the routing shifts by proportion
   rather than switching part way down.

   **RULED 2026-09-01, AND THE BRAKE IS NO LONGER `[C]`'s ASSEMBLY ON SINGLE WORDS OF ASSENT.**
   `[A]` ruled the consequence he had previously widened rather than answered: **the route cannot be
   urged, only re-sighted.** Telling someone to fix rather than hide asks for an output they cannot
   select; what helps is whatever restores sight. **`[C]`'s case, which he accepted:** the second
   brake works by imported sight, so if the first brake's routing is also by sight the intervener is
   not adding a second force but redirecting effort already being spent — **the two brakes are one
   mechanism met twice**, and 8 below falls out of them rather than being deduced separately.

   **AND `[A]` SUPPLIED THE ROUTING MECHANISM, WHICH §5 OF THE BRAKE NOTE SAID DID NOT EXIST.** *the
   basic question for the struggling person is which is more painful, staying as they are or facing
   the pain of unburying their fears and unfortuanately, because of blindness, it is a question of
   immediate pain, not the prospect of long term improvement.* **Blindness does not corrupt the
   comparison; it removes one of its terms**, leaving only what can be felt now. **This also gives
   the brake its shape**: consequences press, the pain of staying rises, and the person faces the
   fear when it passes the pain of unburying — a restoring force that grows with displacement, which
   is what the bell-curve rejection required. **And it makes the low tail thin but real without a
   separate assumption** — further down there are more layers to unbury, so the crossing point sits
   further out. *Measured 09-01: this comparison exists at one site in the whole set,
   `a small discomfort now against the larger one that staying would cost` in the Z+ sketch, where it
   governs dropping a single endeavor. Nothing in either book states it of the brake.*

   **`[A]`'s GUESS, MARKED AS ONE AND NOT RULED — how the comparison is ever made at all.** *the
   person makes the comparison in a rare moment of clarity, and forgets it again many times until
   there is enough of a foundation to do it consciously.* **This gives the ruled forgetting/blindness
   distinction its home** — homeless in both manuscripts since 08-27, and its own note says it
   belongs beside the brake. **Each condition gets a job: blindness is why the moment is rare,
   forgetting is why it does not carry.** *It does not reopen the ruling above: the moment of clarity
   is the sight arriving, and it arrives unbidden, so urging still cannot produce it. It does not
   touch the forbidding on insight mid-collapse either — these moments fall in the ordinary run, not
   during a drop.* **It also gives a mechanism to the ruling that a level is many turns and the
   Levels are recognition markers rather than units:** the foundation accumulating is what makes a
   level take many turns. *`[C]`'s observation, unruled and recorded as a shape only: this is a
   second accumulation running opposite to the first — evasion lays layers down, retained sight
   builds foundation up.*
6. **The second brake.** Another person, working by **imported sight** rather than force, and working
   better when the intervener has been rescued or rescued themselves — which supplies both what to
   try and the knowledge that rescue is possible. **Not conditional on stress** (`[A]`, 08-29),
   because it happens outside the person's psyche. *That draws a boundary as well as answering: the
   model can say the intervention reaches the person and by what means, and nothing about what makes
   an intervener succeed.*
7. **How far down.** Climbing one level gets harder with depth, and harder faster than the pressure
   to climb gets stronger. **No absorbing floor** — `[A]`, 08-27: *coming up from the bottom happens.*
8. **The levels do not wrap**, derived: the return could only be made by the faculty the bottom has
   lost, so below the last choosing rung there is no unaided recovery — the way back is stepwise, or
   **by outside help.**

**`[C]` observation, not ruled, and it is why 8 closes the falling half rather than opening it.**
Book 1's derived observable already reserves a place for outside help and has never had an account of
it. **The intervention brake is that account.** Placed after both brakes, the wrapping derivation
lands as the thing they were already required by rather than as a separate deduction.

**The two forbiddings sit here** (see §7 on how much of the winding structure book 2 carries): no
fully witnessed level drop, and no insight reported mid-collapse.

**The exclusion on the inverted U should be revisited rather than carried.** The 08-15 spec kept it
out because it invites the reader to hear the axis as a scale of effort. **The brake ruling now says
exactly that — what fails at the bottom is aim, not energy.** It has a mechanism it did not have.

#### Rising, and then the leverage problem

The exit is the climb performed on the last layer — withdrawal along the arc, quiet and seeing, then
the sighted return, **with the gain arriving only on re-engagement**. Every rung's climb shows the
summit's shape in miniature; there is no growth technique different in kind from climbing. **Active
starvation**, brought here by the R7 cut: training the realm you live in does not merely neglect the
other, it unchecks it, because the realms compete for attention. The graded cut, thinnest at the top,
and thin-at-top is safe. The preverbal qualification — the oldest layers were never propositions. Calm
as prerequisite, not goal. The plateau, and the year as the unit.

**The way out, which the rising half has never had as an object.** `[A]`, 08-26: not acceptance
alone — **conscious recognition of the buried fears one by one, or better, a recognition of the
automatic burial process.** *Only the second generalises; the first is local to a realm.* **NOT
RULED**, with the rest of the three-outcomes material.

**The counterfeit summit** closes the climb. Book 1 files it in its Ch 18 only because that is where
its contemplative material lives; under this split it has no reason to sit apart from the climb, and
Appendix E records it as having no precedent.

**Then the leverage problem, stated and left.** Everything a person does about their own condition
proceeds from the position that needs moving. **State it and stop.** The two ways out are Part 4's,
and the reader should feel the gap. *This is the strongest reason the Part 3/Part 4 line falls where
it does: the problem is the model's, both answers are the traditions'.*

---

## 2. PART 4 — PARALLELS

**Five chapters, in two movements.** The material is two kinds of thing and the 08-15 sketch orders
it by tradition, which hides the difference.

The Buddhist and Hindu parallels were part of how the account developed, **so their agreement is
partly inheritance** — which is the borrowing ledger's whole point and the reason this part must not
read as the ancients agreeing. **The Stoics, Horney and Freud are the opposite case**: found
afterward to line up, none of them shaping the model. Book 1 says in its own voice that this makes
them better evidence than the Buddhist parallels, and it is the one place in either book where a
parallel is worth more than a borrowing.

**Movement one — the borrowed material**, in the register of a source rather than a confirmation.

1. **The same structure, found elsewhere.** *Merged from the sketch's first two chapters.* The three
   poisons read as the orientations; the Trimurti as the **transitions**, not the positions; and
   karma, rebirth, samsara and momentariness read at the scale of a thought, where they can be
   watched. Karma demystified as habit with a long horizon. One claim at three magnifications.
   *Book 1's poisons section still carries the unapplied 07-28 repair — do not carry it across
   broken.*
2. **No-self, and what follows.** Emptiness **named and stopped short**, with the vow and its reason
   stated. Book 1 does this twice and book 2 follows the same practice. **And volitional formations
   meet the mental deposits here** — see §1, Ch 15.
3. **Choicelessness.** Z0 the orientation distinguished from sustained choicelessness; the third,
   ideal sense set aside; the two forms. The suppression/dissolution criterion — same instruction,
   two outcomes, and the difference is whether the seeing is in it.
4. **The three releases, and the answer to leverage.** Book 1's Ch 5 *What Makes a Step a Release*,
   arriving here rather than in Part 2. Consequence answers appetite, nothing-stands-on-its-own
   answers guarding, care answers withdrawal. **And the two ways out of the leverage problem Ch 17
   left open.** Bodhicitta and the vow as safeguards installed before they are needed. Then the exit,
   and whether it holds.

**Movement two — where the agreement is not inheritance.** Short, and it carries the evidential
weight.

5. **The Stoics and Freud, and what their standing is.** **`[C]` call, and it fills a hole.** The
   presentation rule at Ch 14 promises Trimurti *and Freud* as the two instances; the 08-15 sketch
   delivers the Trimurti and never delivers Freud, whose correspondence exists only in the theory
   notes and appears in neither manuscript. **The placement: id on the ending-and-arising passage,
   ego on the first transformation, superego on the second** — the developmental order falls out, and
   the superego formed by relinquishment lines up with Shiva. *Known loss, stated: no type-specific
   prediction.* The Stoics join it. **The chapter's subject is the standing itself** — nothing was
   borrowed from these, so the agreement counts as evidence.

**This fixes a problem the provisional file raised and could not solve.** It worried that sending the
Stoics to Part 4 and Horney to an appendix would get their shared standing said twice or not at all.
With a chapter whose subject *is* that standing, it is said once. **`[A]`'s ruling that there is one
Horney place stands** — the appendix keeps the Hornevian triad correspondence and refers back here;
it is not a second treatment.

**Sizing.** Adding chapter 5 without the merge would take book 2 to twenty-two chapters against book
1's eighteen, in the book that is meant to be simpler. Merged, Part 4 is five and the total stays at
twenty-one.

**The standing constraint on the whole part.** The laundering rule and Appendix E both say the
agreement is partly inheritance. **A part that reads as *and look, the ancients agreed* inverts the
book's own standard.**

---

## 3. LEVEL 0 IS ABOLISHED, AND BOTH 08-15 FILES STILL ASK WHETHER IT GOES IN

**Ruled by `[A]` 2026-08-23, in both books:** *the exit is the upper half of Level 1 — make it match
riso*, and *riso's self-actualization is our liberation.* Book 1's argument for a rung above Level 1
was that Level 1 still retains a desire and a desire is still a rung; **self-actualization stands
where the desires stand on Riso's chart and is not one**, so the premise fails.

**Book 2 has no drafted text on Level 0**, so the cost is to book 1 and to the two 08-15 files, which
have carried the question as open for eight days.

**The gain to Part 3 is larger than the loss, and it dissolves the seam the provisional file called
the hard part.** That file's problem: Part 3 must describe an approach to something it cannot name,
since *type sets the length of the walk* raises *walk to where*, and book 1 answers by pointing at
its contemplative chapters. Its workaround was to name the destination obliquely and keep the word
*liberation* out of Part 3 entirely. **Not needed.** Liberation and self-actualization are one thing
under two names — an identity, not a resemblance — so **Part 3 names its destination in Riso and
Hudson's own words, credited, and owes Part 4 nothing for it.**

**What Part 3 loses is the reason the top cannot be held.** The old argument: the deepening reaches
the apex and the arising has no rung above to land on, so it lands back in engagement — renewal, not
residence. **The renewal survives**, since there is still nothing above the top of Level 1. **What
fails is calling the apex *not a position***, which was earned by its being off the structure; on
Riso's chart it is drawn, on the top row, with an arrow arriving at it.

**The replacement, and Part 3 can carry it in its own voice. `[C]` call.** A maintained state is a
habit maintained by the habit of maintaining it, and that regress has no floor. **Habit is already
Ch 15's** — this is the same faculty pointed at the top of the ladder instead of the bottom.

**And that half-answers the other open item those files carry.** The maintained-nibbāna ruling was
recommended out of book 2 on **register** grounds — contemplative material in a book that has not
mentioned practice. **Its structural content is exactly what the impermanence argument now needs:** a
state held by a trained habit rather than by continued seeing. **So the content comes into Part 3
without the name; the name goes to Part 4 or nowhere.** The register rule is kept and Part 3 does not
lose the argument along with the vocabulary.

---

## 4. HOW MUCH OF THE WINDING STRUCTURE BOOK 2 CARRIES

**`[C]` call.** Book 2 carries what the ruling **forbids and implies**, and not the geometry it is
stated in.

**Comes across:** the turn as the unit of depth; level change only at the crossing into detachment;
the crossing passable only at the extremes of registering, with partial registering held in the trap;
and the two forbiddings — no fully witnessed drop, no insight mid-collapse.

**Stays in the notes:** the two coordinates taken as a shape, cycle angular and axis vertical, and
the non-uniform pitch that falls out of it.

**The reason is the ruling's own.** The structure was left **unnamed** because every candidate name
overcommitted, and **undrawn** because a figure has to pick a pitch and the pitch is the feature that
turned out not to be uniform. **Book 2 stating a shape it then refuses to name or draw asks a reader
to hold a picture they cannot check** — and the picture does no work, since everything book 2 needs
survives as the crossing rule and the two forbiddings, which are statements about when a thing can
happen rather than about what it looks like. With the geometry gone, the non-uniform slope has
nothing left to be a property of.

**Nothing depends on the part dropped.** The one place the unification of falling and rising earns
its keep — the exit being the climb performed on the last layer, every rung's climb showing the
summit's shape in miniature — is a separate ruling that stands without any coordinate framing.

**Placement, which the provisional left open:** split, not one chapter. The crossing rule and the
extremes rule go in **Ch 16**, immediately before the four fates. The two forbiddings go in
**Ch 17**, where the descent is being described. *This removes the awkwardness the provisional
flagged, where the structure sat at the close of Ch 16 and Ch 17 opened cold.*

**The no-figure rule is untouched and now trivially satisfied rather than a conspicuous absence.**

---

## 5. THE TESTS THAT GATE DRAFTING — SMALLER THAN THE PROVISIONAL SAYS

**The sharpest test in the set no longer gates anything.** The reasoning was: a tradition producing
liberation by purely mental or purely physical means breaks the two-realm requirement; the
requirement is Part 3's most novel claim; settle it before that chapter is written. **The chapter is
cut and the propagation is out of book 2** (`[A]`, 08-15), so **no book text is exposed to it.** The
ruling stands as doctrine and the test is still worth running for the project — it gates no drafting.

**What genuinely gates Part 3 is one task at one source, and the provisional already noticed they
take the same sitting.** Read Riso and Hudson's own Level descriptions once and check both: that no
unaided recovery is visible below the last rung where choosing is available, and that the middle
levels do not map tightly enough to embarrass the ruling that the correspondence's interior is loose.

*The fourth listed test — whether a Z− reads a Z+ as ahead or behind — belongs to Ch 12, Learning to
See, not to Part 3. The provisional's own note to check book 1's Ch 14 passage first still applies.*

**One of the two has gained independent support since.** No unaided recovery below the last choosing
rung is the same claim as the levels not wrapping, and it is what makes the **intervention brake**
necessary rather than merely available — outside help is the *aided* case the observable leaves open.
`[A]`'s own instruction to look at how people come up from the bottom points at it from the other
side.

**And a note on what the R7 cut cost, which is now much less than it was.** On 08-15 the two-realm
requirement propagated down the ladder was the most novel thing Part 3 had. Part 3 has since acquired
the crossing account, the burial reflex, the dwell, the two brakes and the depth-versus-motivation
ordering, **none of which is in book 1 anywhere.** Part 3's claim to be doing something new no longer
rests on the cut material.

---

## 6. WHAT IS STILL OPEN, AND WHAT BLOCKS DRAFTING

~~**Part 3 CANNOT BE DRAFTED YET.**~~ **SPENT 2026-09-02: Part 3 is drafted whole and placed in
`BOOK2-20260902.md` as Ch 13–17.** *This line was left standing when the part was drafted between
09-01 and 09-02, and the items below it are still live — what they no longer do is block anything.*
Ruled and usable: the dwell; sight defining the split; urgency;
forgetting distinct from blindness; the dissolution of the collapse claim; the intervention brake;
slowing-not-halting; Level 0's abolition; the turn as the quantum; the four-term chain.

**Not ruled, and Ch 16 and Ch 17 rest on them:**

| Open | Where |
|---|---|
| ~~**The three outcomes at the Z crossing**~~ — **CLOSED 2026-08-30. Four fates, ruled, with the ordering and the two-question sort** | `NOTE-the-three-outcomes-…-20260826c.md` §6, which carries the ruled table above the superseded one |
| **The first brake** — **RULED 2026-09-01, no longer an assembly on single words of assent**; the route cannot be urged only re-sighted, the routing mechanism is the immediate-pain comparison, and the two brakes are one mechanism met twice | `NOTE-the-dwell-and-the-brake-20260901.md` §5, and Ch 17's falling sequence above |
| **The step missing from the external route** — **no longer the largest open thing, and no longer load-bearing.** The retraction of *does not turn into* on 2026-08-30 opened an internal route, so the descent no longer stands or falls on this. **`[C]`'s bridge is dropped, not left hanging:** `[A]` 2026-08-31 said self-blame usually contributes and blaming the world would too, so the attribution is not the variable and the bridge is not needed. The pain rising is what does the work | `NOTE-the-two-tests-…-20260827c.md` §6 and §4.5 |
| **The tail** — re-derived from a weaker premise, no threshold, nobody barred | same, §12 |
| **What replaces the availability claim; whether the 9 is extreme in anything** | dwell note §3.3 |
| **The B-side account** — everything is scoped to fears arriving from *enthusiasm*; **nothing anywhere is written for the caution end.** A drafting session would be inventing | handoff §0 item 7 |
| **Substance abuse and the descent** — `[A]`'s subject, no position taken | handoff §0 item 7 |
| **`[A]`'s fourth job for consequences** — what determines whether the attempt succeeds, and comfort-now against comfort-later tied to unconscious/conscious. **His, unhedged, never worked on** | same |
| **Who writes replacement wording for what a doctrine session closes** — blocks the Ch 17 sentence above and two other repairs | handoff §0 item 7 |

**OPEN on the sketches, and neither blocks drafting Part 3:** the seven changes `[A]` approved on
08-31 ~~are unapplied and~~ **were applied on 09-01 as `SKETCHES-APPLIED-20260901.md` and travelled
into the master with the rest of the part** — they are the precondition stated at Ch 16, which the
ruled placement moves to Ch 15; and **who wrote the originals is
unsettled** — he asked for his own text to be found, agreed the method is to look through session
notes for where `[C]`'s version first appeared rather than searching the author record, and **said not
to spend the work yet.**

**Deliberately not carried into any chapter:** lean movement and orientation movement (`[A]` content
not to mention them for now); cross-talk between realms, which is ruled but which `[A]` has not sited.

**Left where they are, being Part 1 and Part 2 questions:** *how the three orientations know*;
*Principles, Not Laws*; the Z+ naming, where book 1's Ch 11 prints *blindness* and the ledger has the
naming open — **one of the two is stale and it is now pressing, since Ch 16 and Ch 17 both use the
blind face by name.**

---

## 7. EVERY CALL `[C]` MADE THIS SESSION — in one place

**Each goes into the handoff's open list by name.** *The Level 0 case is why: it sat on two files'
open lists for eight days after `[A]` had closed it, and nothing caught it until this session. Items
carried by name get revisited; items settled inside a file get inherited.*

1. **Falling and rising stay merged, and the crossing account moves up into Ch 16.** §1. *`[A]`
   reaffirmed the merge on 08-30 after being asked directly; the move of the crossing account is
   `[C]`'s.*
2. **Ch 17 runs on the crossing, not rung by rung**, and book 1's *Descent, Narrated* splits. §1.
   *On `[A]`'s 08-20 handover of the question as presentation.*
3. **The deposits close Ch 15** — a departure from the standing recommendation, stated as that file
   requires. §1.
4. **Appendix E gains the deposits**, and Part 4 meets volitional formations there. §1, §2.
5. **~~Ch 14 opens Part 3~~ — superseded 2026-09-02: the recursion chapter opens it and Ch 14
   follows immediately. Ch 14 still does not merge with Ch 15.** §1. *Only the position is
   superseded. The reason the call was made — Ch 16's crossing account needs the passages fundamental
   before it — is untouched by a chapter placed in front.*
6. **Part 4 runs in two movements**, with a fifth chapter for the Stoics and Freud. §2.
7. **The habit regress replaces *the apex is not a position*.** §3. **The softest of these** — it
   substitutes one argument for another rather than placing material.
8. **The maintained-state content enters Part 3 without its name.** §3.
9. **Book 2 carries the winding structure's consequences and not its geometry**, split across Ch 16
   and Ch 17. §4.
10. **The two-realm literature test gates no drafting**; the Riso-reading test is one sitting. §5.

**ADDED 2026-08-31 by `job34-architecture-20260831`. Same rule — each goes into the handoff's open
list by name.**

11. **Book 2 carries `[A]`'s four rewritten sketches, at Ch 16, immediately after the crossing
    account.** §1. *The question is his — he asked whether book 2 carries them and in which chapter.
    The answer is `[C]`'s. Ch 14 and Ch 15 were considered and the reasons against both are at the
    site.*
12. **~~Ch 14 gives `A`, `B` and `Z` their second sense, as phases of a process.~~ VOID — `[A]`
    ruled on 2026-09-01 that there is no second sense.** §1. *Corrected 2026-09-02. The call was made
    on 08-31, killed by his ruling the next day, and the Ch 14 section in §1 was rewritten in that
    pass while this line and one at Ch 16 were left standing. **What replaces it is not a `[C]` call
    at all** — the chapter now owes the phase names and the letter rule, both of which are his.*

**ADDED 2026-09-02 by `Job39 drafting 09012026`. Same rule — it goes into the handoff's open list by
name.**

13. **The recursion chapter opens Part 3.** §1. **`[A]`'s ruling, not a `[C]` call** — the reasoning
    is `[C]`'s and he ruled on it. **Three things ride on it and each is separately open:** the
    chapter is drafted, titled *Where the Inner World Came From* and placed as Ch 13, and the
    numbers of the four chapters after it were shifted by one on 09-02, in this file and in the
    master; and **`Principles, not laws` is still unplaced**, which is the part of that book 1 chapter this ruling does not reach. *The census row
    marking the whole chapter PLACED should be corrected in the same pass as whatever settles the
    last of those.*

**ADDED 2026-09-02 by `Job42 architecture 09022026`. Same rule — each goes into the handoff's open
list by name.**

14. **The fixation descriptions gather at the head of Ch 15.** §1. **`[A]`'s ruling, not a `[C]`
    call**, and his own widening of its scope is what made it possible. What is `[C]`'s is the order
    inside the chapter, the split of *The two ends* between the two chapters, and the finding that
    Ch 15 is the earliest site rather than a convenient one.
15. **The crossing is named in Ch 14 and is not the health axis's term.** §1. **`[C]` call, made
    rather than asked**, and it is what discharges the one dependency the handover called blocking.
    One sentence at *What the odd one carries*; nothing else in Ch 14 moves.
16. **Ch 11 gives up the four fates and the blocking paragraph and keeps the three-things
    distinction.** §1. **`[C]` call on a question `[A]` was asked and never answered**, and it is
    settled as a consequence of item 14 rather than on its own: both copies of the crossing account
    converge in Ch 15, so which copy survives stops being a question.
17. **`[C]` FINDING, AND `[A]` AUTHORIZED THE REPOINT THE SAME SESSION — DONE, NOT OWED.** The
    handover said **two** of book 1's deprecation marks name their superseding text as *book 2 Ch 11's
    crossing account*. **There are three** — book 1's stress account carries the same mark verbatim at
    the figure caption, at the A→Z entry and at the paragraph after it. After this placement that text
    is in Ch 15, so all three were repointed. **`rev2-0814p.md` → `rev2-0814q.md`, md5 `27f90a58`,
    still 2,594 lines and still 57,180 words** — three strings of equal length, so no citation moves
    and no line count changes. Book 1 still carries nine inline marks plus the block mark; **no mark
    was added, removed or reworded beyond the chapter number**, which is why an architecture session
    made the edit rather than handing it to job 3.
    *A fourth site mentions Ch 11 and the crossing at L1485 and was NOT touched: it is inside the
    quoted sketches-rewrite note, it records what was true when it was written, and it is a question
    about book 2 rather than a pointer from book 1.*

---

## 8. CORRECTIONS TO THE TWO 08-15 FILES

**`BOOK2-ARCHITECTURE-20260815b.md` — still the authority for Parts 1 and 2. Two corrections:**

- **Its §4 inventory still lists *what a rise requires* as a Part 3 chapter and calls it the most
  novel in the part.** Its own §2 records `[A]`'s cut of that chapter and says the propagation stays
  in the notes. **The inventory line is the stale one.**
- **Its §7 item 5 asks whether Level 0 goes into book 2.** Closed 08-23 — abolished. See §3.
- **ADDED 2026-09-02. Its Ch 11 specification is superseded in part by the ruled placement at §1's
  Ch 15.** That specification gives Ch 11 the disregard/denial contrast, detachment's lean as one
  quantity across a range, and Z0 as unselective receptivity, and closes: *Part 3 cannot start
  without this: the health axis is the Z arc turned on a third object, and "Level 1 is Z−" is
  unreadable otherwise.* **The requirement it states is met and the site it names is not.** Part 3
  now derives detachment's two directions for itself, in Ch 13, from recursion — so the part does
  start without Ch 11's description — and the description itself is in hand at Ch 15, one chapter
  before the axis needs it. **What survives in Ch 11 is the three-things distinction, which is
  `[A]`'s own and was sited there by his instruction.**

**`BOOK2-PART3-PROVISIONAL-20260815.md` — SUPERSEDED by this file.** Its chapter numbers ran one
below the live architecture because it predated Learning to See being confirmed into Part 2; its
Level 0 material is void; its falling chapter predates the entire crossing account. **Its appendix
proposal at §3A is NOT superseded and is carried forward unexamined** — this session did not reach
it, and the working appendix's removal-before-publication instruction is live.

---

## MANIFEST ROW

| File | md5 | words | bytes | scope |
|---|---|---|---|---|
| `BOOK2-PART34-ARCHITECTURE-20260902b.md` | generated at set-cut | | | set |

**A file cannot carry its own md5.** Left for `setcheck.py manifest` to fill.
