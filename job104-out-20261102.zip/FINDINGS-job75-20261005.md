# FINDINGS — `Job75 coherence 09232026`

Cut 2026-10-05. The session opened 2026-09-23 on `job74-out-20260923.zip` and ran over several
days while `[A]` carried questions between it and `Job70 doctrine 09152026`.

**This is the one file a drafting session works from for today's rulings.** Nine doctrine files
from `Job70` fed it. They are moved to `spent/` with this cut, and **where any of them disagrees
with a row here, the row here wins**. `Job70` asked for that, because this session had the
manuscript and `Job70` did not.

**Every site was located by content in `BOOK2-20260923.md`, which this session did not edit.**
Every blockquote below is a sentence of that master, checked with `quotecheck.py quotes`.
`[A]`'s words are given in italics with their date and never as blockquotes.

**How the rows are marked.**

- **RULED** — `[A]` said it, in this session or in a `Job70` sitting, and his words are given.
- **`[C]` DECISION** — a fault this session recorded without asking, because a ruling already
  covers it. The ruling is named.
- **`[C]` REPAIR SENSE** — how the repair might go. A drafting session may use it or write its
  own, and must show `[A]` the sentences around the change before and after.
- **NOT RULED** — a `[C]` reading. Do not act on it without asking `[A]`.

**Not in this file, by `Job70`'s instruction and `[A]`'s agreement:** the unease material
(`NEW-MATERIAL-the-unease-loop-20260923b.md`). It is undrafted, needs a sitting of its own, and
is not in this set. See the set note.

---

## PART ONE — THE RULINGS, EACH IN ITS OWN ROW

### 1. A detached person raises wants and fears, less intensively — RULED

`[A]` 2026-09-23, in this session: *yes. a fixation is a fixed place on the orientation cycle.
wants and fears are processed in the enthusiastic and cautions phases even for a detached
fixation, just less intensively.*

**Site — `Underneath the Cycle`, *Where a fixation acts*.** Wrong:

> A detached person raises no wants or fears of their own.

The sentence before it stands and already says the ruling: *A person whose fixation is detached
gives little attention to the arising and little to the examining.*

`[C]` REPAIR SENSE: a detached person raises wants and fears like anyone, and raises fewer,
because little attention goes to the arising and the examining. *What a detached person wants is
peace* stays.

### 2. Wants come from the mental deposits, and a realm raises nothing — RULED

`[A]` 2026-09-23, through `Job70` (`CORRECTION-to-job70-closures-20260923.md`): *the cycles apply
to the whole, not by realm*; and of a Five noticing someone else's emotional situation, *it
depends on mental deposits which were determined by fixations and history.* This stands with his
09-12 ruling that a process arc has no realm and a want takes the realm of the matter it is
about.

**What a detached person wants is not counted by sources.** The sentence in the closures file
giving a detached realm's wants *three sources* is struck whole.

**Sites, all wrong in wording; what they say about a detached person having wants stands.**

*Where the Types Come From*, the opening:

> A detached realm can therefore be worked on with two kinds of motivation: what arises in the detached realm, and what the other realm supplies.

The Nine's sketch:

> A Nine has no other realm to supply them motivation, so a Nine works with the wants and fears that arise in their own two realms.

*The Cycle*, *The two faces of detachment* — wrong twice, since a process does not run in a
realm either:

> A process running in a realm where the person is detached still raises fears, and a fear reaching the end of its process moves the person.

*The Fixations Themselves*, *The range of detachment* — the first sentence is wrong twice, for
the same reason:

> A process running in a detached realm raises a want, and examining the want raises a fear about it.

> How many fears a realm raises depends on how much the person examines in the realm.

> A Nine, detached in both realms, has only what their own processes raise.

`[C]` REPAIR SENSE: the person's thoughts raise wants out of the mental deposits; a want or fear
takes the realm of what it is about; a detached person gives the arising and the examining
little attention, so fewer are raised about matters in that realm.

**Checked and holding.** *Supplies motivation* (Ch 5's opening, the Two, Four, Five and Seven,
and *The range of detachment*) is about what the person can turn their noticing on, not about
where a want comes from. `Job70` flagged it for a check; the uses are consistent with the ruling
and none says a realm raises anything.

### 3. The lean sets how much attention reaches each phase, and is a source of nothing — RULED

`[A]` 2026-09-23, through `Job70` (`CORRECTION-to-job70-closures-20260923.md`). **This
supersedes his own 09-16 answer** *2 is true because detachment has a lean*, which the word
register carried as *Detachment's lean is a source of a detached realm's own wants.* A center
nearer the arising raises more wants; a center nearer the examining weighs more fears; whether
an arriving fear is processed or ignored (09-16) follows from where the center sits.

**No manuscript site is wrong.** The 09-16 instruction to name detachment's lean once at Ch 4,
as a source of a detached person's wants, was never applied by `Job74`, and its purpose has now
gone. **Do not add it.** The register entry is rewritten in letter `c`.

### 4. A detached person's actions are placed by motive, like anyone's — RULED

`[A]` 2026-09-23, through `Job70`: *Z- fixing is fending off and Z+ changing the
subject/distraction/ignoring is a want.* Asked whether the earlier claim covered only fixing a
disturbance: *yes.*

Fixing a disturbance is fending off and comes at the cautious phase; distraction is a want and
comes at the enthusiastic phase. **`Job70` had recorded as ruled that a detached realm releases
no action of its own and that every detached action comes at the cautious phase. `[A]` never
said it, and it is struck.**

**Site — the Z+ sketch in *The four sketches*: NO CHANGE.** *An impulse toward something
enjoyable arises and goes straight to action* stands as written. Recorded so no later session
reopens it.

### 5. Every orientation has something it cannot easily bear; `aversion` is the cautious phase's — RULED

`[A]` 2026-09-23, through `Job70`: *i question my use of the word aversion - i think it should
be reserved to cautious phase*; *all have a standing dislike*; and asked whether the book needs
a class word, *no need for the general term.*

So **`aversion`** names only what the cautious phase raises by examining — fear and
disappointment. Each orientation's standing dislike is described in plain words, and **no term
names it**. The coinage *standing dislike of disturbance* in `Job70`'s files is retired and
appears nowhere.

**Site — the orientations chapter, all three sentences:**

> What an enthusiastic person is averse to is disappointment. What a cautious person is averse to is losing control. What a detached person is averse to is suffering with nothing softening it.

`[C]` REPAIR SENSE, from `Job70` and needing no new word: the paragraph's own lead-in, *something
a person cannot easily bear*, carries all three — *what an enthusiastic person cannot easily bear
is disappointment*, and the same for the other two.

**The `aversion` census.** Holding, both in the cautious phase: *Underneath the Cycle*'s *the
examining raises an aversion* and its *Disappointment* section. Faults, all in the fixations
chapter:

> Giving way to easy wanting sounds slack, and it is not — it holds a person in place. A fear arriving from the cautious orientation meets the desire for comfort, and the two interact badly: an aversion meets an aversion to that aversion, and the aversion to the aversion wins.

**This sentence is the fear-of-fear loop described in the retired word.** The first *an
aversion* is the arriving fear and is correct. A repair that only swaps the word for the other
two loses the sentence's connection to the loop.

> A person is averse even to recognizing what happened, because recognizing the burial would begin to undo it.

> The blindness loop runs on the aversion to recognizing what happened, and would run the same way in anybody.

> What blocks it is an aversion to looking, not to the fear itself, so nothing about the fear ever has to be faced — a person turns away from something before knowing what it was.

**Two names for one thing.** *Underneath the Cycle* calls the last of these *a fear of looking*.
**`fear of looking` survives** (`Job70`, accepted): it is a fear.

### 6. A fear lasts one thought; only the tension and the content cross — RULED

`[A]` 2026-09-23, in this session: *yes* — *A fear also lasts only one thought* and *No fear is
kept somewhere and brought back* both stand. Through `Job70`: *the want becomes a fear, the
tension and the content cross and that creates the next want.*

So a want and a fear are one thing at two moments of one cycle. **Only two things cross into
the next cycle: the bodily tension, and the content of the unresolved matter.** Neither a want
nor a fear crosses. The tension produces a desire for relief; the unresolved matter gets the fear
raised again.

**`Job70`'s files say *an ignored fear keeps its feeling*. Read every such phrase as *ignoring
leaves tension behind*.** The tension is the bodily tension ruled 09-12 — a feeling of fear with
no object. It is not a fear.

**No site in *Underneath the Cycle* changes.**

### 7. What ignoring leaves — RULED

Follows from row 6 and from the 09-12 ruling that ignoring lays down a deposit. **Ignoring
leaves the bodily tension, the unresolved matter, and the habit of ignoring a little stronger. It
does not leave the fear, and it does not leave the want.**

**Site — *The four fates*, wrong three times** (it denies the deposit, the tension and the
unresolved matter):

> Ignoring leaves nothing mental at all: not the fear, and not the want behind the fear.

The rest of that paragraph — the bodily tension, what a person can do with it — stands.

**Site — *The four fates*, *Ignored*, right in substance and wrong in wording**, since it reads
as the want waiting between thoughts:

> The want was never given up, so the problem still stands, and the fear comes back the next time the problem is met.

`[C]` REPAIR SENSE: the matter is unresolved, so the want is raised again, and the fear with it.

**Holding, and the sentence the others must agree with** — the health-axis chapter: *An ignored
fear is not laid down at all. What does get laid down is the ignoring itself, which is why it
comes more easily each time.*

### 8. Forgetting is ignoring after the tension has subsided — RULED

`[A]` 2026-09-23, through `Job70`: *i think forgetting is a later stage of ignoring when the
feeling has subsided.* This keeps his 09-12 ruling that forgetting is the same fate as ignoring,
and gives it a mechanism: one fate at two times.

**Site — *Disregarding, and not seeing at all*.** The book gives forgetting a different
mechanism — ignoring become habitual:

> A person who has left fears alone often enough no longer does it on purpose, and the fear is simply forgotten. Ignoring and forgetting are one act at the two ends of the run from the chosen to the involuntary.

`[C]` REPAIR SENSE: forgetting is what ignoring becomes once the tension has subsided, so the fear
stops being raised although nothing was settled. The run from the chosen to the involuntary can
stay where the paragraph uses it of ignoring itself (*on purpose or by habit*), but it is not
what separates forgetting from ignoring.

### 9. Burying and ignoring are one turning away at two strengths — RULED

`[A]` 2026-09-23, through `Job70`: of burying and ignoring, *that is the only difference at
first, but the fear of fear feedback loop leads to more differences.* Burying is the same turning
away, at a feeling the person cannot bear. **Everything that separates them later is produced by
the loop.**

**Sites to read against it:** *Disregarding, and not seeing at all* (the three things easy to run
together) and *The four fates* (*Two questions sort them*). The book separates them by whether the
fear came into view. That is compatible **only if** the sentences make *not coming into view* the
effect of a feeling the person cannot bear, and not a second mechanism. The book already says
*Blocking happens only to a fear the person cannot bear*. `[C]` reading: most sentences already
comply. A drafting session checks each one and shows `[A]` any it changes.

### 10. A buried fear is mental deposits — RULED

`[A]` 2026-10-05, in this session: *buried fear is mental deposits.* The fear that was buried
ended with its thought, like any fear. **A buried fear is what the burial laid down, and later
thoughts raise fears out of it.**

**So these stand:** *No fear is kept somewhere and brought back*; *Underneath the Cycle*'s *A
blocked fear comes with a fear of looking at the original fear*; and **`[A]`'s climb wording, whole**
— a buried fear *comes back into view* (the deposit's content, finally looked at), the person
faces it, and *the fear has been released* (from what the deposit kept producing). Retiring a
buried fear changes that deposit.

**The repair is one definition, stated once where burial is explained:** a buried fear is what
the burial laid down, and later thoughts raise fears out of it.

**Site needing that definition to read right** — *The four fates*:

> A burial also leaves the fear itself, surviving hidden and stable, and blocking is the only fate that leaves a fear surviving that way.

*Hidden* and *stable* are true of the deposit. *The fear itself* reads as the fear and has to be
made to read as the deposit.

**Site that is close to right** — the health-axis chapter: *A blocked fear stays in the mental
deposits.* It has the right place and makes the fear a thing inside the deposits instead of the
deposit itself.

**An ordering problem to solve while placing the definition.** The fixations chapter explains
burial before its section *What previous thoughts have laid down* introduces the term *mental
deposits*. The definition either uses *Underneath the Cycle*'s plain wording, *what earlier
thoughts have laid down*, or the term moves earlier. This is the older fault that the deposits
are used before they are introduced.

**Drafting row from `Job70`:** the falling-and-rising chapter's *bringing back into view what was
kept out of view* reads naturally as the subject matter avoided, which is true. Keep it only if
the sentences around it do not make it sound like a stored fear.

### 11. A fear is settled only at the ending — RULED

`[A]` 2026-10-05, in this session: *i don't like "worked out before the ending". what's wrong
with "settled only at the ending"?* Recorded in his words. **Do not use *worked out before the
ending*.** The register line stands: every aversion is raised in the cautious phase and meets
its fate at the ending.

**Sites:**

*Underneath the Cycle*, *Where a fixation acts*:

> Many fears are raised, and most are settled before the ending.

*The Fixations Themselves*, *Which fixation handles a fear*:

> A cautious person does the opposite and settles most of what might go wrong before the detached phase is reached.

`[C]` REPAIR SENSE, shown to `[A]`, who answered *ok*: each sentence already says the cautious
person examines heavily, so the repair only drops *settled before*. For example, *Many fears are
raised, and each is settled at the ending*, and *examines most of what might go wrong before the
detached phase is reached*. This keeps clear of the fate name *worked through*.

The neighbouring enthusiastic and detached descriptions were checked for the same slip and do not
have it.

### 12. Panic and the grab are thoughts cut short, not reflexes — RULED

Panic: `[A]` 09-16, a thought whose examining is cut short, *a judgement* being made in it; 09-23,
panic acts *on fear*, so its action comes at the cautious phase. The grab: put to `[A]` in this
session as `Job70` set it out, and `[A]` 2026-10-05: *i agree.* **A grab is a thought whose
examining is cut short.** The thing has to be taken as wanted before anyone reaches for it, so a
want is raised. The reaching comes before the examining gets anywhere. **A grab's action comes at
the enthusiastic phase**, because it goes toward something. **A reflex is different** — catching a
falling glass, flinching, a hand off a hot pan — and raises no want. **The grab stays sited at the
enthusiasm end; only the mechanism changes.**

**Site — *The range of detachment*, both halves wrong:**

> At the caution end the extreme is panic. Panic is a fear that arrives too fast to be thought about while it is running. Panic cannot be examined and cannot be decided about, in any realm and under any orientation. What answers panic is a reflex.

> At the enthusiasm end the extreme is a grab at something wanted, made before any thought about the thing has happened. A grab is too fast to be thought about, and a reflex is what answers it.

`Underneath the Cycle` already has panic right: *Panic is a thought and not a reflex, because a
judgment is made in panic.* The two extremes are not symmetrical. A grab runs less of its thought
before acting, which is why the paragraph's mistake is an easy one to make.

**Also note:** under row 11, panic's action at the cautious phase is an action, not a settling.
The panicked fear still meets its fate at the ending.

### 13. The health axis runs from not noticing to noticing — RULED

`[A]` 2026-10-05, through `Job70`, given to this session: *The health axis runs from not noticing
to noticing, not from uncomfortable to comfortable. If Chapter 16 anywhere says or implies that a
healthier person is more comfortable, that is now a fault.*

**Sites.** The correspondence passage speaks in the book's own voice (*watching what a person is
like at each*), and the table's column *What a person is like* is the book's, not Riso and
Hudson's. Their level names are in the first column. So both are faults:

> It falls from calm clarity, through insecurity, through recklessness, to blindness.

The table's Level 1 row gives *calm clarity* in the same column.

*The two ends, and what lies between them*:

> Both ends of this axis are detachment. The clear calm at the top and the burnt-out bottom are both Z, one seeing and one blind, which is why the two are so often mistaken for each other: from outside they can look alike — quiet, unmoved, wanting nothing — and they could hardly be further apart.

`[C]` REPAIR SENSE, from `Job70`: calm at the top may be right as an **outcome** of noticing —
a person who notices unease can act on it, and over years may end up calmer — and is wrong as a
**definition** of the axis.

**Holding:** *What corresponds appears to be how much of what is there a person actually
notices*; *it is not how much a person suffers or how hard they are trying*; *Calm is not the
goal.*

### 14. Detachment is not indifference; a buddha is outside the model — RULED

`[A]` 2026-09-23, through `Job70`: *is a detached person with no leans the same as a buddha with
no attractions or aversions. i think not and that is new to the book. a detached person is still
averse to disturbances while a buddha is indifferent to them.* On the word: *ok. keep buddha*;
*if we leave out the article "the" and use lower case buddha, i think that names a class of
people, not guatama buddha. using the class rather than the particular man is better.* On
equanimity: *ok to omit equanimity*; `Job70` reports that his understanding of equanimity includes
a lack of any dislike of disturbance.

**So:** a person with no attraction and no aversion at all — every orientation's standing
dislike gone — is outside the model. **The boundary runs between pure detachment, which still
minds disturbance, and equanimity, which is the buddha's state.** `equanimity` stays out of the
book. The buddha sentence says nothing about how anyone gets there.

**Site — the orientations chapter, the Z entry.** New: detachment is not indifference, and a
detached person minds disturbance. No figure is named there. The entry opens:

> Stepped back, neither reaching for what attracts nor trying to avoid what threatens.

*Trying to avoid* is `[A]`'s 09-09 wording and stays. A reader meets *neither … nor* and hears
indifference, so the new sentence belongs right after it.

**Site — the opening of Part 3**, where Ichazo and Naranjo are named and the book says *This
book keeps that claim.* New: the class defined in the sentence first, the word second, lower
case, no article. Prefer *the absence of caring* to *indifference* there (`[A]`). `Job70`'s
draft in `ANSWERS-for-job75-from-job70-20260923d.md` §4 is `[C]`'s and NOT RULED. It travels in
`spent/` for a drafting session to consult.

### 15. The counterfeit summit — RULED, `[A]`'s own account

`[A]` 2026-09-23, through `Job70` (`…20260923e.md`): *fixations and phases are separate things.
every fixation orientation has a detached phase. abiding in the detached phase can be trained.*
Imagining himself trained to physical detachment, he would *remain vigilant in the physical
realm* and *use detachment as a tool* when fear got in the way. Conscience: *a psychic cautious
phenomenon — understanding the disadvantages of hurting others.* Labels: *ok to drop labels.*
`Job70` reports his account of the deception: observers see one realm and take the person to be
like that throughout.

**What follows:**

- **What is trained is abiding in the detached phase**, which everyone passes through in every
  thought. No orientation is trained. The trained person's fixation is unchanged.
- **One counterfeit, and the error is the observers'.** The attainment and its marks are real;
  observers read an orientation off conduct in one realm and generalize it to both. Nobody is
  performing, and the book accuses no one.
- **Trained detachment is a tool used at moments**, not a state the person is in.
- **Conscience is psychic caution.** For a person cautious in the psychic realm it is muted while
  they abide and intact afterward. For a person enthusiastic in the psychic realm it was learned
  as a rule, and working without it may unlearn it — **the period of working without it does
  that, not the training. The chapter must not say training damages conscience.**
- **The examples come back without labels**, one kind of person per realm, described by what
  they do.
- **`[A]`'s guess, not a finding:** abiding *probably weakens* the fixation. The book may say the
  model predicts it — a fixation is attention concentrated at one phase, so attention spent
  abiding elsewhere is not concentrated there — and may not state it as observed.

**Site — *The summit, and what counterfeits it*, the third paragraph.** Faults:

> There is also something that looks like the summit and is not, and the model says exactly who is liable to it.

**`the model says exactly who is liable to it` is a remnant of book 1's list of types** (only
Twos, Fours, Fives and Sevens), never says who, and is false under the ruling that anyone can
train abiding.

> What observers recognize as holiness is mostly physical-realm indifference — austerity, fearlessness, unconcern with comfort and pain — and that half can be trained alone.

> Conscience is a psychic-realm motive, and training that realm to indifference loses it as a side effect.

and the closing *Not corruption. A casualty of the training.* **Stays:** *with the other realm
running entirely unchecked behind it*, which already carries the observers' error.

**What happened to the examples** (`Job70` asked). Book 1's section *The Counterfeit Summit* had
a warrior-monk discipline (*the fearless fanatic*), the figure trained the other way (*the
soulless manipulator*), *the biographies of fallen teachers*, the untrained case, the list of
types, and the safeguards (bodhicitta, the vow). Book 2 kept only the holiness paragraph,
shortened. The examples were already gone in `BOOK2-20260914.md`, the oldest master in the set,
and the claim inventory shows the section without them from its 09-02 build. Both architecture
files give only *the counterfeit summit closes the climb*; the Part 3/4 file sends the safeguards
to Part 4. **No reason for dropping the examples is written anywhere in the set.** The record was
not read. The likeliest history is that the 09-02 drafting session wrote the chapter from the
one-line instruction.

**Caution for the replacement examples** (`Job70` accepted it). `Job70` offered two, both NOT
RULED: a person trained to work on a bleeding body or keep moving under fire, and a person
trained to sit with someone in the worst hour of their life and stay level. **The psychic one
sits close to the Five's sketch** (*the type most able to look at an emotional situation without
standing inside it*), and **the physical one close to the Seven's** (*a person who can act while
everyone else is still absorbing*). A reader may hear training turned into type, which the ruling
rules out. Move the examples away from those sketches or mark the difference in the sentence.

**`indifference` after this:** never of a person or of detachment. **The Four's sketch keeps
*indifferent to how truthful an inner life is*** — ordinary English about the physical world.

**New material, not in the model and not sited:** `[A]` *young people operate by rote before they
start understanding and continue when understanding is absent* — a rule followed by rote. It is
what the conscience case needs. Flagged for doctrine.

### 16. Where action comes — RULED 09-16, and the stress hypothesis restated — RULED 09-23

Already written by `Job74` in *Action without a full thought* and *What falling takes from
capacity*, and checked: holding. **`Job74`'s detached case — *stops disposing of what arrives* —
stands.** The 09-23 explanation in `Job70`'s files says *stops taking in and disposing*. Taking in
is ruled unlimited (09-10), so `Job74` was right to drop *taking in*. `[C]` DECISION.

**The arc account carries the superseded forms** and is re-cut with this set as
`ARC-ACCOUNT-from-job75-20261005.md`.

---

## PART TWO — FAULTS RECORDED WITHOUT ASKING (`[C]` DECISIONS)

Each is against a ruling already in force, which is named.

**A. The enthusiastic sketch says the detached phase is never inhabited.** *The four sketches*:

> The detached phase is never inhabited at all.

Against `[A]` 09-23, *every fixation orientation has a detached phase*, and against the same
chapter's *Everybody acts in the detached phase too*.

**B. Two phase names that are not phase names.** *The four sketches*: *sits at the active phase of
hope* and *sits at the active phase of fear*. Phases are named only *the enthusiastic phase*, *the
cautious phase*, *the detached phase* (09-16).

**C. Damage from retiring `crossing`.** *The range of detachment*:

> The blindness comes about when a fear is carried past the detached phase rather than disposed of, and the detached phase is reached by reactively avoiding fear rather than by relinquishing fear.

Every thought reaches the detached phase, and a fear meets its fate inside it. The sentence uses
the phase as though it were the orientation, or a place a person arrives at.

**D. Time wording missed by the attention repairs.** The orientations chapter:

> The longer a person stays with the fear at the caution end, the more of the fear is looked at.

Against 09-12 and 09-16: *attention*, not time.

**E. One name, two things: *where a person stands*.** *Underneath the Cycle* uses it for the
orientation (*The letters `A`, `B` and `Z` name only where a person stands*), then three paragraphs
later for depth (*Nothing that happens in the enthusiastic phase or the cautious phase changes
where a person stands*). The falling-and-rising chapter uses it for depth again (*Where a person
stands is still a running total*). One thing, one name.

**F. The Five repair from `Job72`'s findings was not applied.** The Five's sketch still says:

> A Five's cautious physical realm supplies motivation a Five can turn on the psychic realm, so a Five does look there.

and *What a Five notices in the psychic realm is whatever bears on the fears of the physical
realm. Everything else a Five has taken in goes unnoticed*. `[A]` 09-16: *does->can*, and a Five
*also notice[s] things no fear pointed at, such as someone else's emotional situation*. **What
directs that noticing is now the mental deposits (row 2), not the lean.** `Job72`'s repair line
adding *which a Five processes in wanting peace* was `[C]`'s and is not to be written.

---

## PART THREE — CHECKED AND HOLDING

- **Why a fixation does not turn over.** `Job74`'s set note listed it as owed. The answer is now
  on the page in *What previous thoughts have laid down* — *fifty years of making the same move
  lays down the same kind of thing* — and it agrees with the 08-25 ruling that the hardening is
  the accumulation. Discharged.
- **The 09-16 open item on panic against the stress hypothesis** is settled by panic acting on
  fear, and the page agrees.
- **`Job70`'s reading that the health axis was ruled to have no top is wrong in its premise.** The
  09-06 *no top* ruling is the cycle's, in *Relational Positions*. The health-axis chapter says
  *Level 1 is a genuine top*, and nothing is wrong there. The reading's conclusion — a buddha is
  outside the model rather than high in it — stands on the 09-23 ruling alone.
- **`wordcheck.py` on the master:** thirty hits, every one a permitted use.

---

## PART FOUR — OPEN, FOR DOCTRINE

- **Is a want laid down?** *Underneath the Cycle*: *When a thought ends, the want the thought
  carried is laid down. The next thought arises out of what was laid down, and raises nearly the
  same want again.* The 09-23 ruling says only the tension and the content cross and a want is made
  fresh each thought. Laying down into the deposits may be a different thing from crossing, in
  which case the sentence stands. `[C]` could not settle it and did not put it to `[A]`. The
  coffee example's *the decision is laid down* is the same question.
- **Each end of detachment's own want.** *The range of detachment* gives the caution end *to be
  rid of fear itself* and the enthusiasm end *pleasure itself*. Under row 3 the lean is a source
  of nothing, but a center nearer the arising raises more wants. `[C]` reading: the passage is
  compatible. NOT RULED.
- **Whether a detached person's dislike of disturbance is why a disturbance gets noticed.** `Job70`
  states it. The book says *Wanting peace does not make a person look for anything* (the
  orientations chapter and *The range of detachment*). `[C]` reading: compatible, since noticing a
  disturbance is not looking for one. NOT RULED.
- **A rule followed by rote** (row 15), new material.
- **The unease material** — its own job. See the set note.
