#!/usr/bin/env python3
"""quotecheck.py - verify that a document's quotations and line citations
are actually present in the source they claim.

Companion to setcheck.py. setcheck verifies that a file is the file it
says it is; quotecheck verifies that a claim about a file's contents is
true. A section may only be headed MEASURED if quotecheck passes on it.

  quotes <doc> <source>            every blockquote in doc must appear in source
  term  <doc> <source> --term W    every 'L####' citation in doc must have W at that line
  sweep <dir>                      every blockquote in dir against every file in dir

Exit status is 1 if anything fails, so it can gate a commit or a handoff.
"""

import argparse
import os
import re
import sys
import unicodedata

# Typographic substitutions that survive copy-paste but break naive matching.
FOLD = {
    "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
    "\u2013": "-", "\u2014": "-", "\u2212": "-", "\u2026": "...",
    "\u00a0": " ", "\u200b": "",
}


def norm(s):
    """Fold typography, strip markdown emphasis, collapse whitespace."""
    s = unicodedata.normalize("NFKC", s)
    for a, b in FOLD.items():
        s = s.replace(a, b)
    s = re.sub(r"\*{1,3}([^*]+)\*{1,3}", r"\1", s)   # **bold** / *italic*
    s = re.sub(r"_{1,3}([^_]+)_{1,3}", r"\1", s)     # _italic_
    s = re.sub(r"`([^`]+)`", r"\1", s)               # `code`
    s = re.sub(r"\s+", " ", s)
    return s.strip().lower()


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def blockquotes(doc_text):
    """Yield (first_line_no, text) for each contiguous run of '> ' lines."""
    out, buf, start = [], [], None
    for i, line in enumerate(doc_text.splitlines(), 1):
        if line.lstrip().startswith(">"):
            if start is None:
                start = i
            buf.append(line.lstrip()[1:].strip())
        else:
            if buf:
                out.append((start, " ".join(x for x in buf if x)))
            buf, start = [], None
    if buf:
        out.append((start, " ".join(x for x in buf if x)))
    return [(n, t) for n, t in out if t]


BQ_MARK = re.compile(r"(?m)^[ \t]*>+[ \t]?")


def haystack_of(source):
    """Normalised source text with its own blockquote markers removed.

    Without the strip, a quotation spanning a line break inside a
    blockquoted source picks up a stray '>' and fails. Book 1 stores each
    paragraph on one long line, which is why this went unnoticed until
    2026-08-24."""
    return norm(BQ_MARK.sub("", read(source)))


def found(n, haystack):
    """True if the normalised quote n occurs in haystack, honouring '...'
    elisions as ordered non-overlapping fragments."""
    frags = [f.strip() for f in n.split("...") if f.strip()]
    if not frags:
        return False
    if len(frags) == 1:
        return frags[0] in haystack
    pos = 0
    for f in frags:
        hit = haystack.find(f, pos)
        if hit < 0:
            return False
        pos = hit + len(f)
    return True


def check_quotes(doc, source, min_words):
    haystack = haystack_of(source)
    rows, bad = [], 0
    for lineno, quote in blockquotes(read(doc)):
        n = norm(quote)
        if len(n.split()) < min_words:
            rows.append(("skip", lineno, quote, "shorter than --min-words"))
            continue
        frags = [f.strip() for f in n.split("...") if f.strip()]
        if len(frags) == 1:
            n = frags[0]
        if len(frags) > 1:
            # An elided quote: each fragment must occur, in order, without
            # overlapping. Walk the source rather than matching the whole.
            pos, missing = 0, None
            for f in frags:
                hit = haystack.find(f, pos)
                if hit < 0:
                    missing = f
                    break
                pos = hit + len(f)
            if missing is None:
                rows.append(("ok", lineno, quote, "elided; fragments found in order"))
            else:
                rows.append(("FAIL", lineno, quote,
                             f"fragment not found in order: {missing[:50]!r}"))
                bad += 1
        elif n in haystack:
            rows.append(("ok", lineno, quote, ""))
        else:
            # Locate the longest leading fragment that does match, so the
            # report says where the quote stops being the source's words.
            words, keep = n.split(), 0
            for k in range(1, len(words) + 1):
                if " ".join(words[:k]) in haystack:
                    keep = k
                else:
                    break
            note = ("no match at all" if keep == 0
                    else f"diverges after word {keep}: ...{' '.join(words[max(0,keep-4):keep])} ^")
            rows.append(("FAIL", lineno, quote, note))
            bad += 1
    return rows, bad


CITE = re.compile(r"\bL(\d{2,5})\b")


def check_term(doc, source, term):
    src_lines = read(source).splitlines()
    t = term.lower()
    rows, bad, seen = [], 0, set()
    for lineno, line in enumerate(read(doc).splitlines(), 1):
        for m in CITE.finditer(line):
            n = int(m.group(1))
            if (lineno, n) in seen:
                continue
            seen.add((lineno, n))
            if n > len(src_lines):
                rows.append(("FAIL", lineno, f"L{n}", "beyond end of source"))
                bad += 1
            elif t in norm(src_lines[n - 1]):
                rows.append(("ok", lineno, f"L{n}", ""))
            else:
                rows.append(("FAIL", lineno, f"L{n}", f"{term!r} does not occur on this line"))
                bad += 1
    return rows, bad


CARRY_NOREAD_STRING = "travels in every set and is not read by a text session"


def sweep(root, min_words, exclude):
    """Every blockquote in every markdown file under root, against every other
    markdown file under root. Reports quotes no other file accounts for.

    Orphans are NOT failures by themselves. A file that is the ORIGIN of its
    own quotations - the author record holds `[A]`'s typing - orphans all of
    them by design, and a file quoting a book that is not in the set cannot
    be checked here at all. Read the orphan list; do not gate on the count.
    """
    names = sorted(f for f in os.listdir(root) if f.endswith(".md")
                   and f not in exclude)
    hay = {f: haystack_of(os.path.join(root, f)) for f in names}

    # A CARRY, DO NOT READ file stays a haystack - matching against it prints
    # no content - but it is never listed as a DOCUMENT, because listing its
    # quotes prints its text. On 2026-08-29 a text session ran this and had
    # the author record quoted back at it, restriction and all. --exclude
    # would have prevented it and was not used; a guard that must be
    # remembered is not a guard. 2026-08-29.
    withheld = sorted(f for f in names
                      if CARRY_NOREAD_STRING in read(os.path.join(root, f)))
    docs = [f for f in names if f not in withheld]

    print(f"sweep: {len(names)} markdown file(s) under {root}")
    if exclude:
        print("excluded: " + ", ".join(sorted(exclude)))
    if withheld:
        print("not listed as documents (CARRY, DO NOT READ - still searched "
              "as sources): " + ", ".join(withheld))
    print()
    print(f"{'document':<46}{'quotes':>7}{'matched':>9}{'orphan':>8}  accounted for by")
    orphans, total, matched_all = [], 0, 0
    for doc in docs:
        qs = [(l, q) for l, q in blockquotes(read(os.path.join(root, doc)))
              if len(norm(q).split()) >= min_words]
        if not qs:
            continue
        by, m = {}, 0
        for lineno, quote in qs:
            n = norm(quote)
            where = [s for s in names if s != doc and found(n, hay[s])]
            if where:
                m += 1
                for s in where:
                    by[s] = by.get(s, 0) + 1
            else:
                orphans.append((doc, lineno, quote))
        total += len(qs)
        matched_all += m
        top = ", ".join(f"{s[:24]}({c})"
                        for s, c in sorted(by.items(), key=lambda x: -x[1])[:2])
        print(f"{doc[:46]:<46}{len(qs):>7}{m:>9}{len(qs)-m:>8}  {top}")
    print(f"\n{total} quote(s) of {min_words}+ words; {matched_all} accounted for, "
          f"{len(orphans)} orphaned")
    if orphans:
        print("\nORPHANS - no other file in the set contains these:")
        for doc, lineno, quote in orphans:
            shown = quote if len(quote) <= 88 else quote[:85] + "..."
            print(f"  {doc} L{lineno}: {shown}")
    print("\nAn orphan is a question, not a verdict. Expect them from a file that")
    print("is the origin of its own quotations, and from one quoting a book that")
    print("is not in the set. Anything else is a quotation with nothing behind it.")
    return len(orphans)


def report(rows, bad, header):
    print(header)
    for status, lineno, what, note in rows:
        shown = what if len(what) <= 72 else what[:69] + "..."
        tag = {"ok": "  ok      ", "FAIL": "  FAIL    ", "skip": "  skip    "}[status]
        print(f"{tag}doc L{lineno}: {shown}")
        if note:
            print(f"            -> {note}")
    ok = sum(1 for r in rows if r[0] == "ok")
    skipped = sum(1 for r in rows if r[0] == "skip")
    tail = f", {skipped} skipped" if skipped else ""
    print(f"\n{ok} verified, {bad} failed{tail}")
    return 1 if bad else 0


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    q = sub.add_parser("quotes", help="blockquotes in doc must appear in source")
    q.add_argument("doc")
    q.add_argument("source")
    q.add_argument("--min-words", type=int, default=6,
                   help="ignore quotes shorter than this (default 6)")

    w = sub.add_parser("sweep", help="every blockquote against every file in a set")
    w.add_argument("root", nargs="?", default=".")
    w.add_argument("--min-words", type=int, default=6,
                   help="ignore quotes shorter than this (default 6)")
    w.add_argument("--exclude", action="append", default=[], metavar="FILE",
                   help="a file to leave out entirely; repeat the flag")
    w.add_argument("--strict", action="store_true",
                   help="exit 1 if any quote is orphaned (default exits 0, "
                        "because orphans are expected - read the note it prints)")

    t = sub.add_parser("term", help="every L#### citation must carry the term")
    t.add_argument("doc")
    t.add_argument("source")
    t.add_argument("--term", required=True)

    a = p.parse_args()
    if a.cmd == "sweep":
        n = sweep(a.root, a.min_words, set(a.exclude))
        sys.exit(1 if (a.strict and n) else 0)
    if a.cmd == "quotes":
        rows, bad = check_quotes(a.doc, a.source, a.min_words)
        sys.exit(report(rows, bad, f"quotes: {a.doc} against {a.source}"))
    else:
        rows, bad = check_term(a.doc, a.source, a.term)
        sys.exit(report(rows, bad, f"term {a.term!r}: {a.doc} against {a.source}"))


if __name__ == "__main__":
    main()
