# NOTE — the small arcs and what a step is made of

Recorded 2026-08-15, out of the verification session. **Nothing here is ruled.** `[A]` marks the
author's suspicion as offered; `[C]` marks my readings, which arrived on request and carry the
usual discount. Captured so the idea is not lost and not developed by accident.

**Do not draft from this. Do not place anything in book 2's architecture on it.** Its bearing on
the growth part is that the growth part must not contradict whatever this settles into.

---

## 1. What was proposed `[A]`

It has not been developed at what kind of arc the Z crossing happens on. It is not the
orientations changing. The suspicion: **a series of smaller arcs, each clearing a small bit of
fear** — the bit there before, gone after. And then, added: **the step is itself an amalgam of
small steps, both the falling and the effortful rising.**

Alongside it, and confirmed against R6 rather than new: **the step rule is general.** Everything
is easier near the top; near the bottom volition is limited by reflexive fear and blindness.

## 2. The polarity, which needs correcting before anything is built on it `[C]`

As stated, the clearing was "a clean Z− → Z+ transition." On the settled polarity that is the
wrong direction, and R7.6 already draws the distinction the suspicion needs:

> suppression quiets responsiveness and leaves the centre intact; dissolution removes the
> centre. An impulse *seen* and not followed completes; an impulse *blocked* is pushed down and
> stays — Z− quieting by completing the object vs. Z+ by emptying it, at the smallest scale.

So "there before, gone after" is a **clean Z− operation** — full registering, object completed.
Emptying at Z+ is the failure mode that leaves the thing in place. R2's filing agrees from the
other side: the fall is forward drift Z−→Z0→Z+ with registering draining.

**Open:** whether the author means Z+ in a third sense — arousal discharged rather than capacity
closed. If so this collides with Part III's open item (Z+ naming: unknowing vs. blindness), and
that item stops being a naming preference and becomes a structural ambiguity that must be
settled before the small arcs can be described at all.

## 3. What the amalgamation costs, and why it probably costs nothing `[C]`

R6's naming retraction fixes the quantum: "one step per revolution is exactly the structure."
So the amalgam cannot be of sub-revolution pieces. It has to be **an amalgam of whole turns**,
each still a single step.

Consequence: **a Level is many turns**, and the real quantum is finer than a Level. R6 survives
untouched. Two things fall out that were already wanted independently:

- R2's middle landmarks are coloring and permanently loose — now with a reason, since they are
  coarser than the thing they label. Part III's test (a tight L4–L6 mapping embarrasses R2)
  becomes easier to pass, not harder.
- The R&H question dissolves. Their Levels are landmarks; the book's quantum is the turn. "Experience
  the fear in the Level in which one finds one's self and all the subsequent fears above it" is
  simply a great many turns. No contradiction to manage — see `VERIFY-20260815.md` item 1.

**The alternative, if the amalgam is of sub-revolution pieces:** R6's one-step-per-revolution
goes, and with it the naming retraction's whole rationale. Recorded as the branch not taken
unless `[A]` takes it.

## 4. The one real tension, and it is between rulings, not with the suspicion

R6: "level change happens only at the seam crossing; the rest of any turn is angular, at
constant depth."

R2's filing and R5.3: the level gain attaches to **re-engagement** consolidating the self-ward
registering — and R2 says explicitly that "E6's one legitimate crossing is of the seam;
re-engagement crosses a different edge."

Two edges at the same angular position, traversed in succession. **Which one carries the depth
change?** Unresolved between the rulings as written. It bears directly on the suspicion: if each
small step requires both a seam approach and a re-engagement, then each small step is a full
turn, which is what §3 already needs.

## 5. The template each small arc must satisfy

Not a new constraint — R5.3 already forbids otherwise: growth at every level must show the
summit's shape in miniature, i.e. **withdrawal, seeing, and the gain arriving only with
re-engagement**. Any account of the small arcs has to give all three phases at the small scale,
or it breaks R5.3 rather than extending it.

R6 adds the direction: the climb is a sighted forward turn per layer, the descent a blind
backward turn per layer. So the falling amalgam is of blind backward turns — micro-lapses rather
than one collapse — and R6's forbidding still applies to each: no fully witnessed drop, no
seeing reported mid-collapse.

## 6. A correction on the record, mine `[C]`

I put it to `[A]` that R5's graded cut and R6's binary gate could not both be general. **That was
wrong and the rulings file says so.** R5.2 defines thickness as how readily the
quieting-by-not-looking fires, with tolerance rising with registering. The grading governs how
hard it is to *reach* an extreme; R6's binary governs what the crossing *requires* once there.
Different jobs. No fork.

One substitution to keep visible rather than merge: R5.2's mechanism for the grading is
**tolerance**; `[A]`'s gloss this session was **volition**. Possibly the same thing seen from
two sides — voluntariness is the axis's variable — but they are not the same claim and should
not be silently unified.

Also recorded: the inverted U of choosing puts volition low at **both** ends. At the bottom it is
unavailable, at the top unnecessary. Any statement of the grading that reads as monotonic in
volition is wrong at the top.

## 7. Open questions, in the order they need answering

1. The polarity — is the clearing a Z− operation (§2), or is a third sense of Z+ intended? If
   the latter, Part III's Z+ naming item must be settled first.
2. Is the amalgam of whole turns (§3, preserves R6) or of sub-revolution pieces (costs R6's
   one-step-per-revolution and its naming retraction)?
3. Which edge carries the depth change — the seam crossing or re-engagement (§4)?
4. Does the small-arc account add a constraint, or only content to R6's crossing? If only
   content, it is cheap and R6 pays nothing. If it constrains, say what it forbids — the method's
   test applies to it like anything else.

## 8. What this touches if it goes anywhere

R5.3, R6, R2's filing, R4 (a cleared bit is a handover that completed), R7.6's
suppression/dissolution criterion, Part III's Z+ naming item and the loose-middle test, and
`VERIFY-20260815.md` item 1. No applied text.
