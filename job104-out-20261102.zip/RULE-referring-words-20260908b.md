# STANDING RULE — the referring-word count

**Letter `b`, 2026-09-08. Supersedes `RULE-referring-words-20260908.md`; quarantine the parent.**

**Ruled 2026-09-08 by `[A]`. For section 9 of the style guide, *Write for what a reader can actually
hold*, where the restate-rather-than-point-back bullet already stands. This replaces that bullet's
status: it is not a rule of wording, and it cannot be applied by judgement.**

---

## Why the existing bullet has not held

`[A]` has given this correction repeatedly, most recently on 2026-09-08: **`[C]` is far better at
holding what a word refers back to than a reader is. For a reader the limit is one or two. So `[C]`
must write differently for a reader than it would for itself.** He notes that he has said this
before, that it was heard, that the text was fixed, and that it keeps recurring.

**The recurrence is the point, and it has the same cause as the concision fault.** A drafter
resolves a reference without effort and therefore cannot feel the cost of it. **Reading the sentence
back does not help, because reading it back is the thing that is too easy.** So a rule phrased as
*restate rather than point back* asks the drafter to notice something they are constitutionally
unable to notice, and it will go on being broken by sessions that have read it and agreed with it.

**What replaces judgement is a count**, which can be performed without feeling anything.

---

## The check

**Referring words:** *it*, *its*, *that*, *this*, *those*, *these*, *them*, *they*, *the other*,
*there*, *the same*, *such*, *the former*, *the latter*, *in those respects*, *the first*, *the
second*.

**Run it on every sentence written.**

1. **Count the DISTINCT referring words in the sentence.** More than one, rewrite. Two
   occurrences of the same word count once. **A third-person plural pronoun repeating the subject of
   its own sentence is not counted** — *They don't ask more of others than they ask of themselves*
   resolves one subject and costs a reader nothing. **Amended 2026-09-08 by `[A]`, on `Job59`'s
   count: the earlier wording counted occurrences, and a reader's load is referents.**
2. **For each one, find what it points at.** If it reaches back past the previous sentence, rewrite.
3. **Count how many names one thing has been given across the passage.** More than one, rewrite. A
   second name is a reference the reader has to resolve, whether or not it is a pronoun.

**Steps 2 and 3 need a reader and cannot be machine-checked.** Step 1 can, and `refcount.py` does it.
*That* and *there* are left out of the automatic flag, because a machine cannot separate a
demonstrative from a complementizer or an expletive; a drafter still watches the demonstrative use.

**Rewriting means naming the thing.** Extra words are cheap, as the concision rule already says.

---

## A caught instance, from the day the rule was made

**Written by `Job58 drafting 09082026`, and passed by `[C]` on review before `[A]` caught it:**

> What a realm is like crosses differently. Its standards, its limits and how much of it there is to
> go round do not carry, because the two realms are not alike in those respects, and a person who
> applies one realm's terms to the other ends up with a demand that cannot be met where it has been
> made.

**What the count finds.** *In those respects* points back at three items across a clause boundary.
*The other* points back at a realm named earlier in the sentence. And one thing has been given four
names in two sentences: *what a realm is like*, then *its standards, its limits and how much of it
there is to go round*, then *those respects*, then *one realm's terms*.

**`[C]` had already repaired the opening of that pair and did not see any of this**, which is the
rule's own evidence: a reviewer who can hold the references cannot review for them, and must count
instead.

---

## What the rule does not cover

**A passage can pass the count and still be too dense.** The same passage runs four parallel cases
in one paragraph, each with a general opening and a specific unpacking, and no referring word is at
fault in that. **Density of that kind is a separate matter and is not fixed by this check** — the
repair there is one case per paragraph.

Both faults come from the same source and neither is caught by reading the text back.
