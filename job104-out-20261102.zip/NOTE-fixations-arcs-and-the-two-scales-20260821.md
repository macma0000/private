# NOTE — fixations, arcs, and the two scales

Cut 2026-08-21 by `Job11 doctrine 2e session 8-20`. Set verified before work began:
**17 ok, 0 mismatched, 0 missing, 0 not in the manifest.**

**Supersedes `NOTE-how-fixations-work-20260821.md` and `WORKSHEET-fixations-and-arcs-20260821.md`,
both cut earlier the same day by this session.** Both are stale for one reason: they are written at
the thought scale throughout, and `[A]` relocated the subject to the endeavor partway through the
day. Quarantine both as `SUPERSEDED__live__`; nothing in either is lost here.

**Nothing in this file is `[C]`'s to rule.** `[A]` marks his words, `[bk1]` book 1 quoted, `[ruled]`
settled earlier, `[C]` mine — and mine arrived on request throughout, which is the shape the
sharpening rule names.

**Checking — 31 blockquotes, every one verified against the source it claims.** Against
`rev2-0814b.md`: **8 verified**, and the run's other failures are blockquotes that do not claim book
1. Against `NOTE-small-arcs-and-the-step-20260815.md`: **2 verified**. Against `AUTHOR-RECORD.md`:
**21 verified** — `[A]`'s typing, which fails against book 1 by design, as that file's header
declares. 8 + 2 + 21 = 31, with nothing unaccounted for.

### Two `quotecheck` defects found while running this, recorded and not fixed

Neither is fixed here, because changing a tool mid-session invalidates the set that has just verified
against it — the precedent set when a `setcheck` change was recorded rather than made.

1. **A leading ellipsis produces a false failure.** The `…` is only stripped when a quote has two or
   more elided fragments, so a quote beginning mid-sentence is tested with the ellipsis attached. The
   rulings file's quotation of book 1's synonym gloss matches byte for byte and is reported as *no
   match at all*.
2. **A source whose quotes are line-wrapped cannot be checked at all**, and this is the serious one.
   The haystack is normalised without stripping `>` markers, so any quotation spanning a line break
   in the source fails. Book 1 stores each paragraph on one long line, so checks against it work —
   which is why this went unnoticed. **Checks against the author record, the notes, the rulings and
   the handoff are systematically unreliable**, and the MEASURED convention has been resting on a
   tool that only works against one of the files it is pointed at. Verifying `[A]`'s quotations above
   required stripping the markers by hand first.

**And the second defect earned its keep immediately.** Re-checking this file against the record
showed one of `[A]`'s statements — *yes - thought deposits- but you don't need to invoke the arc for
that* — answered in conversation and never written down. It is now in the record, marked as
recovered. **That is the near-loss the author record exists to prevent, happening again on the day
after the practice was created, and caught only because a check was run.**

---

## 1. THE RELOCATION — the day's largest result

**`[A]`, and it is the finding everything else here depends on:**

> yes. an endeavor. and that's what sticks at the fixation. the though arc was a red herring. it's
> the endeavor that A rushes around when a desire fails and what stacks when B obsesses.

**Book 1's own text confirms it, and the measurement is blunt.** The section titled *Fixation as a
Stopped Arc* opens:

> The difference between the fixations shows plainly if the same smallest arc is walked through in each.

It then walks four. Across those four paragraphs the word **pursuit** appears five times, alongside
*the action*, *alternatives*, *a problem*, *a worry*. The blind-detachment walkthrough reads:

> An impulse toward something enjoyable arises (A) and moves straight to action — the examination not skipped but deferred, waiting until the action runs into trouble.

An action that runs into trouble and is then dropped is not a single thought. **The section declares
the thought scale and describes endeavors.**

**That is where the stopped arc came from.** Endeavors stick; thought arcs do not; the section filed
the first phenomenon under the second's name. And it is the standing hazard the architecture names —
*the small arcs are momentary process; the relation between the orientations and the figure is
habitual fixation* — realised in book 1 itself rather than in a drafter.

**What it dissolves.** *Do arcs stall* never contained a conflict. Thought arcs run without stopping
**and** something sticks at the fixation, and both hold because they concern different objects. The
two accounts did not need reconciling; they needed separating.

### 1.1 The division of labour, and it should be stated in the book

**Thoughts deposit. Endeavors stick.** `[A]` ruled the first half and then narrowed it:

> yes - thought deposits- but you don't need to invoke the arc for that, even thought it happens.

So the depositing is a fact about thoughts, not about their three-part shape. **Demoted, not
denied** — thoughts do run arcs; the arc is simply not what does the depositing. A later session
reading *doesn't need the arc for that* as *thoughts don't run arcs* would undo §5 by accident,
which is the same class of error as the scale confusion itself.

**`[C]`: the two-scales sentence is worth one place in the book by itself.** It is the sentence that
would have prevented the confusion, and it is cheap: two scales, two jobs, said once and not
restated.

---

## 2. WHAT A FIXATION IS — the definition, and what it rests on

### 2.1 What the three have in common — `[A]`

> the three fixations are all related by the fact that it is uncomfortable to go forward and nobody
> would want to go backward.

**Book 1 supports the backward half and makes it stronger than preference.** Integration is *the
direction in which natural experience would lead as a person sees the drawbacks of their current
orientation*, and *the integration loop is a map of ripenings — each orientation, fully lived, points
toward the next.* Disintegration is *the direction in which competence tends to decompose.* Going
backward means surrendering a gain in understanding. There is nothing there to want.

*Counting:* `[A]`'s 08-19 ruling that nothing runs backward and this statement are **one source
twice**. Only book 1's decomposition sentence is independent.

### 2.2 The definition — `[A]`, proposed and then softened by him

> the definition is where the person is stopped whether in an endeavor or not - does that work?

and, the same day:

> well, it isn't necessarily stopped because the person can and often does face discomfort and move
> on, but there would be a tendency to try to avoid that.

and, settling it:

> the fixation is where one habitually stops.

**`[C]`: *habitually* carries the softening rather than reversing it** — it says where a person stops
as a rule, not always. So the definition and the tendency are one statement, not two.

**Three things must travel with it.**

- **The subject is the person, not the arc.** *Stopped* was the old vocabulary, said of the arc, and
  arcs no longer stop. Said of the person it does not collide — but it is one word from the sentence
  ruled out of book 2, so the subject has to be visible in the sentence itself.
- **Say what is stopped.** Alone, *stopped* names a pattern rather than a reason — the standing
  complaint against *habitually*. Book 1 supplies the tendency being blocked: *each orientation,
  fully lived, points toward the next.* **What is stopped is the forward step that living the
  orientation fully would otherwise produce.**
- **The common fact stands beside it**, or the definition is quoted alone and is thin. Together they
  answer both questions: where a person stops, and why they stay stopped.

### 2.3 What holds it there — `[A]`, 08-20, and it is the cause the model lacked

The discomfort of going further, from the familiar to the unfamiliar, strong from years of entrenched
habit, a form of aversion with a different object at each place: **disappointment** for enthusiasm,
**loss of control** for caution, **naked suffering** for detachment. And each orientation's blindness
keeps it in place, because crossing that blindness *is* the move to the next orientation.

**Habit does not compete with this; `[A]` joined them himself.** Book 1 has habit running without
belief, which says why a fixation keeps operating — not why the person will not leave. The discomfort
is strong *because of* entrenched habit. Habit is why the price is high, not an alternative to there
being a price.

### 2.4 What survives from the older accounts

**Untouched by the removal of stalling, because none of them mentions an arc stopping:**

- > A fixation is a strategy that outlived its problem.
- > A fixation is a stance that has completed that return trip.
  Strategic in what it contains, automatic in how it runs. *(Voice rule: the word `stance` is retired
  in book 2; the claim is not.)*
- The stability account — a desire has a completion condition and a fear has none.
- `[A]`'s cause at §2.3, and the blindness that maintains it.

**Struck, and listed so nobody restores them:** *a fixation is the next passage failing to start*;
*the place a person's process arcs habitually rest*; *one habitual stopping point per realm*; and the
half of the intentional-versus-reactive test that sorted stops into stalls.

---

## 3. WHAT A FIXATION DOES — characterization, and what it forbids

**`[A]`, on what he meant:**

> i was saying the cycles behave differently depending on which orientation the fixation is in.

- **Enthusiasm.** The desire is satisfied or not; either way the endeavor ends and another begins,
  on the same object or a new one. **Nothing of emotional significance is left.**
- **Caution.** The problem is solved or not; if not, the endeavor reaches detachment carrying
  anxiety. Its characteristic failure is the stacking — worry that will not close.
- **Detachment.** The anxiety is dropped and forgotten, or it makes more blindness, and the blindness
  diminishes awareness and functioning.

**`[A]` ruled the deposit question, and it is not what either side had:**

> all arcs complete whether satisfactorily or not. every thought has a residue but those connected
> with a blindness loop are particularly permanent.

> not nothing. all memories are residues. i meant nothing of emotional significance.

So **everything deposits; what varies is permanence**, and permanence comes from the blindness loop.
Detachment keeps its special place without being the only place anything is left: it is where what is
left stops going away.

**Book 1 supplies the mechanism, and this is the one convergence today that counts.**

> So desire cycles because it can be answered, and fear freezes because it cannot — and a stack of unanswerable things is precisely what accumulates. The level chains of Appendix G are that stack written out: a person cycles around the desire of their level while the fear of it stands frozen, held in place by the frozen fears above it.

Enthusiasm's endeavors run on desire, which is answerable, so their deposits discharge. Caution's and
detachment's run on the unanswerable kind. **Why this convergence counts where the day's others did
not:** book 1 argues it from the nature of the two things and only afterwards notices that Riso's
level chains are that stack written out. The argument does not come from Riso, and `[A]`'s
independent reading of Riso is an instance of it.

**What characterization forbids.** No arc that fails to close, in any fixation, ever. **Nothing but a
blindness loop makes anything permanent** — so no account may have caution or enthusiasm accumulating
permanently on its own. And no account may have an enthusiasm fixation accumulating anything weighty
at all.

### 3.1 The word, and `[A]` raised it first

`residue` is taken. Measured: **five occurrences in book 1, on three lines, and no others.**

| Line | Chapter | Sense |
|---|---|---|
| 1133 ×3 | Ch 11, the Z0 paragraph | the **neighbour trace** |
| 1546 | Ch 15 | the **settled residue of handling** — the health-axis place |
| 1626 | Ch 16 | **what is left over** at Level 1, distinguishing summit from exit |

**`[A]` asked whether the Z0 sense is the carrying of aversion to the blind side. It is not**, and
the pairing runs opposite to the recollection:

> The rest comes from noticing what each lean actually adds: a motivational residue from its neighbor.

> Z− carries a trace of B's corrective concern — seeing tinged with caring — which is why it still wants problems seen and fixed; Z+ carries a trace of A's wanting — not-seeing tinged with recklessness — which is why nothing that would disturb its comfort gets looked at.

> It does not go looking (that would be B's residue) and does not look away (that would be A's)

**At the dangerous end the residue is *wanting*.** Caution's trace belongs to the sighted end.

**The carrying `[A]` was remembering is two paragraphs earlier and book 1 does not call it residue:**

> Two pulls reach a person in the middle of the Z arc — the wariness left over from caution, and the wanting that draws toward comfort — and they do not agree.

**Where the two were joined is `NOTE-overlap-and-truthfulness-20260815.md` §1.3, which is `[C]`'s and
unruled, and says so on its own face.**

**Verdict unchanged, reason corrected.** Either way the blocking sentence is *Z0 is the absence of
residue*, which under the 08-21 ruling would now say a person at pure detachment has no memories. The
accumulating thing stays **what previous thoughts have laid down**.

### 3.2 The memory clause is now in, by ruling rather than by drift

*All memories are residues* is stronger than 08-18's *probably*, and the handoff carries the clause as
**neither adopted nor refused** — *separable and much weaker; nothing in the model needs it and it
exposes the line to an argument the book has no stake in*. The 08-18 wording ruling rejected
`accumulated past thoughts` precisely because it *would have installed it without anyone ruling it*.
**It has now been ruled, which is the right way for it to arrive.** Cost unchanged: no part of the
model turns on it, and printing it hands a reader a dispute the book does not need. **`[A]` to say
whether he intends it in the text or only in the reasoning; the model runs either way.**

---

## 4. THE BLINDNESS LOOP — what feeds it, and what cannot

### 4.1 It is a detachment phenomenon and was never at caution — `[A]`

> the anxiety that triggers the blindness loop does so only in Z where there is aversion to aversion.
> for B aversion is their way of life.

**Right, and it follows from ruled doctrine:** *A and B take the object as target; Z takes the arousal
itself* `[ruled]`. Caution recoils from the threat, not from its own recoiling, so there is no engine
for not-looking at caution at all.

**`[C]`, and it supplies a mechanism §3 only asserted.** The loop needs **two** pulls in disagreement.
A live caution delivers wariness and almost no counter-pull toward comfort, so nothing needs quieting
and the anxiety is not made to disappear — **it stands, and standing unanswered anxiety is the
stacking.** So caution's failure and detachment's failure are two outcomes of the same arriving
anxiety, and what decides which is how much wanting meets it. **Forbids:** no blindness in a realm
where nothing pulls toward comfort. *`[C]`'s join of `[A]`'s argument and book 1's trap paragraph;
tidy, and produced on request.*

**Not immunity.** Every endeavor ends at detachment in everyone; *one quantity across a range… with
every degree between them occupied*; and a caution fixation in one realm says nothing about the other.

### 4.2 Abandonment does not feed it — `[A]`'s prediction, and its narrowing

> that brings up the prediction that abandonment at A doesn't risk the blindness loop.

**It follows from `[A]`'s own walkthroughs** — a failed desire carries nothing to detachment — and
book 1 states it independently: *Enthusiasm has no native response to negatives at all… It does the
one thing attraction can do — replaces the blocked pursuit with a fresh one. The loss is not
processed and not fled.*

**Unscoped it fails**, because a Three would then have no route into blindness at all, and book 1
says *anyone of any type can be found high on the axis or low.* **`[A]` resolved it from Riso:**

> there apparently is a background fear present even when the fixation is A - the person does not
> want to process the fear (going to B) but it must still motivate the person somehow.

> so A doesn't process fear they don't go there, they try to jump over it.

**So the prediction is about the route, not about people.** Enthusiasm does two different things with
the two channels: an abandoned **desire** carries nothing and is safe; a jumped-over **fear** is
unprocessed and is exactly what arrives at detachment undismissed. **The Three falls by the fear it
jumps over, not by the desires it drops.**

**And the background fear is not a new object.** It is the hurting channel, which the model has had
since the origins chapter — *Two channels run from the start: wanting and hurting* — with an
enthusiastic relation taken to it. *Feelings persist through the whole of a life; what develops is the
relation taken to them.*

### 4.3 What the loop can and cannot reach — `[A]`, and it gives the conscious split a footing

> i think it is registered - it's just not consciously available. apparently unconscious understanding
> doesn't trigger avoidance.

**This follows from the meta ruling.** Detachment's avoidance is aimed at what stirs, never at
content. Understanding that stays unconscious stirs nothing, so the avoidance has nothing to act on.

**Three consequences.**

- **The conscious/unconscious distinction has a footing**, which the handoff listed as owed: it
  decides whether the loop can fire at all.
- **It reconciles with `[A]`'s 08-20 statement** that the long description was for unconscious arcs.
  What is unconscious there is the content; what the loop reacts to is the felt disturbance.
- **The blind end is a failure of conscious availability, not of registration.** Both books say
  otherwise — book 1's *at Z+ the registering has stopped* and book 2's drafted *at the far end the
  registering has stopped*. **That repair is now motivated. See §6.**

*Cost `[A]` should weigh before ruling the wording: how much registers is not only Ch 11's variable —
it is the health axis's quantity turned on another object, which is what lets the top of the axis read
as clear-eyed detachment. Renaming reaches past one chapter.*

### 4.4 Blindness can also be acquired relationally — `[A]`, first person

`[A]` reports part of his psychic blindness originating in aversion to what his *seeing* did to a
family member. **Book 1 already owns the channel:** *Each has its innate twin in the parent… The
signal works by producing its copy in the caregiver.* The book states that coupling running from
child to parent; his ran the other way.

**It is not a second mechanism.** Asked whether care supplied the loop's second pull, `[A]`:

> i am psychic Z. maybe if i was A i would have laughed at her and if i were B i would have feared
> her. i think i just instinctively took the easy way out.

Detachment took the cheapest way out of a disturbance — the ordinary mechanism. **The account of care
as a safeguard installed from outside the cycle is untouched.** And his three-way contrast is book 1's
own three moves against a negative met from a memory: *A turns toward the next positive. B engages the
negative. Z steps back from the negative.* *(He wrote that passage; not counted as support.)*

---

## 5. GETTING OUT — what `[A]`'s route shows, and what it does not

**It is the climb, not a technique distinct from it.** Checked against the rule forbidding an exit
different in kind from climbing, and against the template requiring withdrawal, then seeing, then the
gain arriving only on re-engagement. `[A]`'s account has all three in order — the quieting; the
information arriving without recognition; answering another person's questions, where the gain
arrives as confidence. **A template satisfied by an account not built to satisfy it.**

**Every element is an outside term, as the leverage problem requires** — *like trying to move
something while standing on it*, with two ways out, and *Both safeguards sit outside the cycle, and
they must: nothing inside the cycle can brake the fall.*

**What it adds is an answer to a problem the book poses and leaves.** The trap says a person cannot
start: *The conflict produces the not-seeing, and the not-seeing preserves the conflict.* **The
unconscious route starts anyway, and §4.3 says why: it is outside the reach of the avoidance, not
outside the person.** `[C]`'s reading of one case, his, told by someone who knows the theory.

**No upward feedback. `[A]` refused it:**

> confidence is the only feedback and it came late. it's more like rock climbing but falling
> painfully every time one tries - but getting higher slowly each time.

and, on where the falls land:

> land back apparently without progress because it was slow.

**So the falls are excursions, not level drops**, which leaves untouched the rule that every real drop
contains an unwitnessed moment. Book 1 already has the shape — *a person's fixation is home, and what
happens are excursions — single steps forward or back, and then a return* — and what `[A]` adds is
the **ratchet**: the return is not quite to the starting point. Without something like it the model
has no route up at all.

**State it as *what accumulates is position, not ease*.** Each attempt costs what the last one cost.
Say *it gets easier* and the refused feedback is back.

**Consequence for the growth material, and it is larger than it looks.** Book 1 warns that *someone
who assumes progress will be steady reads a long plateau as failure — and by the account given here,
that reading is itself a hardening.* `[A]`'s account makes the warning too mild: not a plateau, but
repeated painful failure with one encouraging signal arriving late. **Anything written in an
encouraging register produces the hardening the book warns about, in the reader it is aimed at.**

### 5.1 What starts it, and the ordering that follows

**The entry point, `[A]`:** *first to be aware there is a problem which blindness strongly suppresses
but if someone is curious enough about why their life isn't working, that's a start.* **That is the
reader the Foreword already describes.**

**Caution is not the only noticer.** `[A]` supplied the counterexample himself — a Seven whose life was
failing and who was motivated — with the qualification: *it happens all the time but only after
everything else fails*, and then a correction to that:

> i think that remark was flip -that's the second worst case after never. it must depend on how
> deeply stuck one is in the fixation.

**`[C]`, offered and not ruled:** each orientation's signal is the exhaustion of its own remedy —
vigilance reports early and cheaply, replacement reports only when there is nothing left to reach for
and a gap appears. Enthusiasm's remedy *never registers a failure*, because each failure is answered
by the next pursuit.

**And a consequence for ruled material.** The types have been ordered by walk length using native
access to quiet. Access to quiet is not access to **noticing**, and the two run differently — the Nine
has the best quiet and, with no engaged realm, the weakest signal that anything needs doing. **Starting
and progressing are ordered differently, and the existing ordering speaks only to the second.**
*(Book 1 explains the Nine's double reputation another way — the same grid position read at two
depths. Two explanations of one fact, not support for each other.)*

### 5.2 RESERVED — and this session stopped at it three times

`[A]`'s *it must depend on how deeply stuck one is… in the higher levels volition runs into less
blockages* is the depth-and-threshold question in its own words. **It must have a session to itself,
and not one that has argued about either coordinate.** This session argued about both all day.

**Two flags for whoever takes it**, both from live material:

> the inverted U of choosing puts volition low at **both** ends. At the bottom it is unavailable, at the top unnecessary. Any statement of the grading that reads as monotonic in volition is wrong at the top.

*(`NOTE-small-arcs-and-the-step-20260815.md` §6.)* `[A]`'s claim survives that — fewer *blockages* is
not more *volition* — but the one is a step from the other.

> One substitution to keep visible rather than merge: R5.2's mechanism for the grading is **tolerance**; `[A]`'s gloss this session was **volition**.

*(Same note.)* **`[A]` has now glossed it as volition twice, on 08-15 and on 08-21.** Two independent
occasions of the same substitution is evidence about which word he means. **It is still not a ruling.**

---

## 6. THE THOUGHT SCALE — what it keeps, and why

**`[A]` was willing to drop book 1's *one claim you can check in the next sixty seconds* and then
kept it:**

> maybe best to keep it and point out its similarity and also its difference.

**The difference, and book 1 concedes it in one clause.** Each orientation is defined twice over —
by what it is drawn to or holds off from, and by a competence: *doing*, *understanding*, *seeing*. At
the thought scale the competences are present and the feelings are not, and where the two disagree
book 1 chooses motion:

> That seizing, classified by its motion rather than by the worry's unpleasantness, is the arc's A-moment.

**`[A]` ruled that the emotional tone is the essential mark**, holding it loosely — *to me the
connection seems coincidental but i suspect there is something deeper.* **So thought arcs are
attenuated instances**, and the sixty-second claim is checkable for shape and competence, not for
content. **It survives with its scope named.**

**Where the thought arc is still needed — one place, after `[A]`'s narrowing.** Being the instance a
reader can watch. The ending-and-arising argument runs at three sizes and would stand on the other
two; the scales need a floor and the thought supplies it, which is the same job again. **Depositing
does not need it.** Nothing else in the book should lean on it.

**Not needed in the four sketches**, which looked like they required it and are endeavors.

### 6.1 Two labelings, one shape — `[A]`

> we labeled the points of the thought arcs with the transitions between orientations which is
> different that the other cases.

**Right.** The thought arc is described by its **passages**; the endeavor by its **stations** — *from
eager beginning through chastened middle to ripened letting-go*. The ruled position is that the
transitions are fundamental and the nodes are stopping places, so **the endeavor carries the
vocabulary that ruling demoted**, and it is now the scale that bears the weight.

**It recasts without strain.** *Eager beginning* is the passage out of detachment into enthusiasm;
*chastened middle* is enthusiasm meeting difficulty and becoming caution; *ripened letting-go* is
caution giving way to detachment. **`[A]` to rule whether the endeavor is rewritten by its passages
so both scales speak one vocabulary.**

### 6.2 A `[C]` flag withdrawn, on the record

`[C]` claimed `[A]`'s *arcs arise at Z and end at Z* was derived at the thought scale and might not
carry to endeavors. **Wrong.** Book 1 makes it across scales in one breath: *At the smallest scale,
that is every thought's death and the next thought's birth. At the largest, it is what the physical
realm shows as one life ending and another beginning… One shape, three sizes.* Nothing was inherited
without argument.

---

## 7. THE DIALECTIC — considered and dropped

`[A]` raised the resemblance of action / reaction / resolution-becoming-a-new-action, and then:

> dialectical synthesis feels close but you're right it adds nothing.

**Three reasons on the record.** The formula is **not Hegel's** — Fichtean in origin, popularized by
Chalybäus, and attributed to Hegel almost universally; *searched, not read in the primary sources,
and it would need a proper check before print.* The fit **breaks at the third passage**, because
dialectical synthesis preserves what it supersedes while the book's third passage preserves nothing —
*an ending, then an arising with no antecedent moment*. And the book already carries two three-cycles
as parallels, so a third adds no weight; **triads are cheap**, and the book's own admission is that
three *is not a number I can demonstrate.*

**Kept from it:** the disagreement is worth more than the resemblance, since the parallel fails
exactly where the account is most its own.

---

## 8. TEXT REPAIRS THIS SESSION GENERATED — for job 3, never for a doctrine session

None of these gets a replacement written by a repair session; what replaces them is above.

| Where | What | Why |
|---|---|---|
| bk1 Ch 15, the section title and its opening | *Fixation as a Stopped Arc*, and *one habitual stopping point per realm* | no arc stops; and the section describes endeavors while announcing thoughts (§1) |
| bk1 Ch 15 | *a pursuit ended by dropping rather than deciding does not close; it persists unresolved* | all arcs complete (§3) |
| bk1 Ch 15 | the nesting paragraph, *arcs frozen inside arcs*, and its temporal consequence | rests on the above; replaced by what a completed arc leaves (§3) |
| bk1 Ch 15 opening | caution *weighing without arriving*, against its own sketch three paragraphs later | the sketch is the surviving half (§1) |
| bk1 Ch 5 | *This smallest scale is also where the deepest question, what a type ultimately is, gets its answer* | wrong in subject as well as predicate; only the predicate has been cut (§1) |
| bk1 Ch 5 | *The cycle's largest arc is a life* | no life-scale traversal in book 1's own three-scale list; found 08-19, still unruled |
| bk1 Ch 11 **and** bk2 Ch 11 | *at Z+ / at the far end the registering has stopped* | registration continues; conscious availability is what fails (§4.3) — **and see the cost note there** |
| bk1 Ch 5 | *the one claim you can check in the next sixty seconds* | kept, scope to be named (§6) |
| bk1 App G, the open-questions appendix | *a fixation is an arc arrested before its ending*; temporal nesting | same cause as the Ch 15 nesting |

**Already ruled and still unapplied, carried from the handoff:** book 1 Ch 15's retracted arisings
clause, and book 2 Ch 7's fixation sentence.

---

## 9. OPEN, IN PLAIN WORDS

| Question |
|---|
| Is the endeavor rewritten by its passages, so both scales use one vocabulary? (§6.1) |
| Does the memory claim go in the text, or stay in the reasoning? (§3.2) |
| Is emotional weight the same variable as permanence, or two? (§3) |
| Is what is carried past detachment the same as the neighbour trace, or something else? (§3.1) |
| Does a caution fixation build anything lasting on its own, or only hand it on? (§3, §4.1) |
| With the selecting clause retracted, what decides what arises? |
| Is the signal always the exhaustion of the orientation's own remedy? (§5.1) |
| Does depth set how soon overwhelm arrives? **RESERVED — its own session** (§5.2) |
