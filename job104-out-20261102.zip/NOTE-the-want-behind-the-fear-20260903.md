# NOTE — the want behind the fear, and what the two disposing fates actually do

**Produced 2026-09-03 in `Job45 doctrine 09032026`. It came out of closing the external route and
then following `[A]`'s question about the core dynamics.**

**Status: FIVE THINGS ARE RULED BY `[A]` — §2, §7B.5, §9.1, §9.4 and §10.2 — plus two text
decisions at §11. Everything else is inference from those rulings and from the books' existing
rules, and is NOT ruled. NOTHING HERE IS APPLIED and no drafting has been done.** *Two of the four
sites are measured (§7A, §7B); Ch 17's brake and the closing paragraph are NOT.*

**How to read the marks.** Every claim below carries one of three:
**`[A]`** — his, this session or earlier, quoted where quoted.
**BOOK** — stated in `rev2-0814q.md` or `BOOK2-20260902b.md`, with the site.
**`[C]`** — inference, mine, unruled.

---

## 1. WHAT CAME FIRST — the external route, CLOSED

**`[A]`'s route, 08-27:** ignoring, then external problems accumulate, then stress, and stress
causes examination to be skipped. **The objection, `[C]`'s, 08-27:** skipped examination is what
the ignoring habit already is, so the route does more of the same thing faster and never reaches
blindness — and sight is what the descent requires.

**CLOSED 2026-09-03 by `[A]`.** The step is urgency, not stress.

> that seems right. ignored fear doesn't do the blindness descent until urgency forces if to go
> down or up. does that sound right?

**The route as ruled:** a fear is left; consequences gather around it; the fear becomes urgent; an
urgent fear cannot be left, so it has to be weighed or turned away from; turning away is what
costs sight.

**BOOK — and this is why the closure is a closure and not new work.** Book 2 Ch 17's *The second
way down, which is not blindness* already carries the whole route in `[A]`'s own terms, ending
*the habit of not taking things up is therefore not a way of avoiding the crossing. It is a way of
arriving at it with more to lose.* No session recorded that the open question had been discharged
by the drafting. **The 08-27 note's §17 item 3 is now closed and its §6 with it.**

### 1.1 Two corrections made in passing, both `[C]`'s errors

- **`[C]` said stress decides which way the fork goes. It does not.** BOOK, book 2 Ch 17: *which of
  those happens depends on how much sight is left by then*, and the mechanism is `[A]`'s 09-01
  ruling — blindness does not corrupt the comparison of immediate pains, it removes one of its
  terms. **Sight decides. Stress is not in the mechanism.** The decider question `[C]` raised is
  therefore not open and was never open.
- **`[C]` said the fork is `down or up`. It is down or not-down.** BOOK, book 2 Ch 15's *The four
  fates*: worked through, given up on and ignored all happen in view and none takes anything from a
  person's seeing; blocking is the only one that does. *Given up on* is neither down nor up.

### 1.2 `[A]`'s fourth job for consequences — CLOSED, and it was answered four days after he raised it

`[A]` on 08-27 registered a fourth job for consequences: they motivate improvement, what determines
success is worth thinking about, and one tradeoff is comfort now against comfort later, related to
unconscious against conscious response. **The 08-27 note called it the largest untouched thing in
the file.**

**It was answered on 09-01 and nobody connected the two.** `[A]`'s routing mechanism — the
struggling person is settling which is more painful, staying as they are or facing the pain of
unburying, and because of blindness it is a question of immediate pain and not the prospect of
long-term improvement — **is** the comfort-now against comfort-later tradeoff, with the finding
that blindness removes the later term. The unconscious/conscious half is his 09-01 guess: the
comparison is made in a rare moment of clarity and forgotten many times until there is enough
foundation to make it consciously. **All of it is drafted, in book 2 Ch 17.**

**What was left of it is the success half**, and that is what §2 onward came out of.

---

## 2. RULED 2026-09-03 — A FEAR ENDS WHEN THE WANT BEHIND IT ENDS

> i think dissolving a fear might require also dissolving the desire causing it.

and, on `[C]`'s statement of it back to him:

> i think that's true.

**This is `[A]`'s and it is the foundation of everything below. It is in neither book and in no
rulings file.**

**What forced it.** `[C]` had offered that working through dissolves the *intolerability* of
failing rather than the prospect of it, leaving the want intact. **`[A]` killed that reading:**

> i think not because the intolerability of the pain of consequence is driving it.

**He is right and the reading is dead.** If the pain of the consequence is real, the fear of
failing is accurate, and an accurate fear is not something inner work makes tolerable.

### 2.1 What it does NOT collapse, and why — `[C]`

The obvious consequence is that working through and giving up on collapse into one fate, since both
must end the want. **They do not, and `[A]`'s own asymmetry rule is what keeps them apart.**

**BOOK, book 1 L1762:** *a desire has a completion condition — it is satisfied or it is blocked,
and either way it ends and is replaced. A fear has none.*

**So a want has two exits, and the two fates take one each:**

- **Worked through** — the want ends by being **satisfied**. The fear that depended on it goes
  because there is nothing left to fail at. **Nothing is left over** — which is exactly what book 2
  Ch 15 already says of this fate.
- **Given up on** — the want ends by being **relinquished unmet**. What is left over is **a
  regret** — which is exactly what book 2 Ch 15 already says of this one.

**The regret is the mark of which exit was taken.** The book's two descriptions were written
independently of this rule and both fall out of it. *That is the strongest evidence in this note
that the rule is right.*

### 2.2 The third possibility is blocked by `[A]`'s own rule — `[C]`

Someone may say a fear can be worked off by succeeding while the want continues. **BOOK, book 1
L1762:** *the feared thing failing to happen does not retire the fear; it confirms the vigilance
that seemed to prevent it.* **Success does not end a fear. It ends a want, and the fear goes with
the want.**

---

## 3. WHAT THE CORE DYNAMICS DO TO THE FATES — `[A]`'s question, and it is the hinge

> the desire you mention is, according to core dynamics, the result of the fear one level higher.
> so what does dropping that desire do? uncover the fear of the upper level?

**BOOK, book 1 L1512:** *a fear is answered by a desire — the desire to secure whatever the fear
anticipates losing — and pursuing that desire breeds a new fear, of failing at it, which is
answered in turn one level down. Descent is fear capitalized into desire, over and over.*

**`[A]`'s reading is correct.** The want behind a fear is the want whose pursuit bred it, and that
want sits one level up. Dropping it exposes the fear that want was answering, at the upper level.

***`[C]` GOT THIS WRONG IN THE SESSION AND CORRECTED IT.*** `[C]` first said the exposed fear is at
the same level, one step back along the chain, and told `[A]` his reading was off. It was not.
**Recorded so the wrong version is not re-derived.**

### 3.1 Fears and desires are not equally droppable — `[C]`

The four fates give a **fear** four exits. The core dynamics make the **want** an answer to a fear.
So dropping the want does not finish anything at the rung above — it removes a cover, and the fear
beneath is left standing unanswered. **A fear cannot be dropped; only met, relinquished, ignored or
blocked.** So the person is returned to the same fork one rung higher.

### 3.2 There are two kinds of giving up on and the book has one word for both — `[C]`

- **The want is an ordinary one** — this job, this person, this outcome. Dropping it exposes
  nothing, because it was covering nothing. **BOOK's** *either way the person is finished with it*
  is true of this case.
- **The want is a rung's desire.** Dropping it exposes the fear beneath. **The book's sentence is
  false of this case.**

***MEASURED 2026-09-03 AND `[C]`'s READING OF THE SITE WAS WRONG.*** `[C]` put book 2 Ch 15's
*Either way the person is finished with it* in question. **It stands.** The *it* is the fear, and
the person IS finished with that fear in both cases; what §3.1 exposes is a **different** fear one
rung up, which the sentence says nothing about. **True and incomplete, not false. No book sentence
in this note is in question.** See §7A for the measurement.

---

## 4. WHAT THE TWO FATES DO ON THE LADDER — `[C]`, and `[A]` called the result a surprise

**Worked through takes the fear and leaves the want.** The breeding stops — the fear that was being
capitalized into the next desire down is gone — but no layer is removed. **It stops the descent. It
does not climb.**

**Giving up takes the want, and the fear goes with it.** A layer is removed. **The descent
capitalizes fear into desire; this takes a desire back out. It is the descent run backwards.**

> it seems so but it is a surprise.

### 4.1 Why the ranking was the wrong question — `[C]`

**They are not competing goods.** Working through is how a person stops going down. Giving up is
how a person comes back up. Neither substitutes for the other. *This is the same shape as the two
pressures in `NOTE-the-two-pressures-and-misattribution-20260902.md` §2 — consequences supplying
energy, the deposits supplying the occasions — and if it is stated in the book it should probably
be stated the same way.*

### 4.2 Why climbing hurts and stopping the fall does not — `[C]`

Working through delivers relief. Giving up delivers a regret and a bare fear, and returns the
person to the same fork one rung up. **A better account of why climbing is slow than the book
currently has.**

### 4.3 The climb route narrows with depth — `[C]`, and it is derived twice over

**BOOK:** all four fates but blocking happen in view, and where sight has gone blocking is the only
one left. **So the climb is available in inverse proportion to depth and closes at the floor.**

**And a second derivation reaches the same asymmetry from the other side.** Working through needs a
**satisfiable** want. **BOOK, book 1 L1516:** each new desire is the previous desire cloaked in one
more layer, and near the bottom the desire is the early one *pursued mindlessly and desperately*
with the fear that the attempts *are hopeless* — **a want that cannot be satisfied.** So working
through is available near the top and stops being available with depth, **until giving up is the
only exit left**, and every step then costs a regret.

***`[C]` FLAGS THIS AS THE STRONGEST RESULT IN THE NOTE.*** It survives whatever is decided about
the ranking, it is derived from two independent places in the books, and it is not in either book.

---

## 5. THE BELL CURVE FROM BOTH ENDS — `[A]` supplied the upper half

> awareness is the ultimate escape but i think a person can work their way up one level at a time -
> as already noted, there is less motivation as one rises.

**`[A]`'s 09-01 brake gave the lower half only:** the pain of staying grows with distance fallen, so
the force pushing a person up is strongest at the floor — *a restoring force that grows with
displacement*, which is what produced a population gathered in the middle rather than piled at the
bottom.

**His point here gives the upper half.** The same force weakens as a person rises, because it is
powered by the pain of staying. **So people are pushed off the floor from below and run out of push
before the summit.** `[C]`: the bell curve is now bounded at both ends by one mechanism rather than
by a restoring force plus an assumption.

**And it puts awareness in the right place** — not a better rung, but the one move not powered by
pain, which is why it is the only one that does not weaken as it succeeds. `[C]`.

---

## 6. NEITHER FATE IS THE WAY OUT — `[C]`, and it agrees with two things already ruled

**BOOK, book 1 L1446:** the way back up is *not another escape from the fear but awareness of the
cycle it turns*. **BOOK, book 2 Ch 17:** the one object worth recognizing is *not the individual
fear but the arrangement that disposes of fears without consulting anyone*.

**That object is not a fear, so it has no fate.** The four fates cannot produce it however well a
person plays them. Working through, done perfectly, holds a position. Giving up, done perfectly,
walks a person back down the chain to the bare basic fear with nothing over it. **Neither steps off
the ladder.** *This is the same limit `[A]` put on the closing paragraph in `Job44` — a limit on
what a person can do alone — reached from a different direction.*

---

## 7. THE TRADITIONS — WHAT THE MODEL DOES AND DOES NOT SHARE WITH THEM

`[A]` on the ruling in §2:

> it sounds similar to a basic tenet of buddhism.

**`[C]` FIRST BUILT A CHAIN JOINING THE TWO AND `[A]` BROKE IT THE SAME HOUR. The broken version is
recorded because it is the obvious move and a later session will make it again.** `[C]` had it that
wanting produces suffering, suffering is feared, and therefore wanting produces fear — with `[A]`'s
own remark, *most people fear suffering*, supplying the middle step.

> now i'm unsure - most people are not aware wanting produces suffering.

**He is right and the join does not hold.** The two chains fear different objects.

- **`[A]`'s rule:** pursuing a want breeds a fear **of failing at it**. The object is failure. It
  requires no insight — fearing to lose what you want is the ordinary condition.
- **The Buddhist claim:** wanting is itself what produces the suffering. A fear attached to *that*
  would require a person to have already seen it.

**In this model nobody is afraid of wanting.** `[C]` joined the chains on the word *suffering* and
the two ends do not meet there.

***A SECOND `[C]` ERROR IN THE SAME PARAGRAPH.*** `[C]` cited book 1 L1656 — *In the beginning the
basic fear is aversion to instinctual suffering and the basic desire its relief* — as the same pair
with the arrow reversed. **The arrow there runs fear to desire, which is the core dynamics
direction and not the reversal at issue.** The citation was doing no work.

### 7.1 What replaces it — `[C]`, and it is the model explaining the tradition rather than agreeing with it

**Every fear the chain generates points at failing to secure the want. None of them points at the
wanting.** So the machinery directs attention to getting the thing and never to whether the getting
is the problem.

**That is why the insight has to be imported** — by a tradition, a teacher, or the intervener —
instead of arising from the ordinary operation of the mind. **It rests on the book's own
definition of a fixation as a standing preference about where attention is directed**, and on Ch
16 declining to treat the fears turning inward as an improvement in sight.

*This is a stronger position than the convergence `[C]` first proposed: the model accounts for the
tradition's difficulty instead of borrowing its conclusion.*

### 7.2 Where the two DO meet, and it is one place only — `[C]`

**At the floor.** The want there cannot be satisfied — book 1 L1644, the early desire *pursued
mindlessly and desperately* with the fear that the attempts *are hopeless* — so relinquishing is
the only exit left, and a person is forced to the position the tradition arrives at by insight.

**A convergence in outcome and not in reasoning.** That is the safe form of it and the only form
this note asserts.

*Two other convergences are already in the books and are not new here: Ch 13's self as a position
produced by the folding, not an object and not findable by looking inward; and Level 0 as freedom
from fixation, named as the goal of many spiritual traditions.* **Whether the traditions are named
at all is Part 4's first question and is not this note's.**

---

## 7A. MEASURED 2026-09-03 — book 2 Ch 15, and `[C]`'s guess was wrong twice

**`[C]` guessed this section would have to give up a sentence. It gives up nothing, and the site
that actually owes something was not the one named.**

### 7A.1 The sentence `[C]` put in question STANDS

**BOOK, Ch 15 *Disregarding, and not seeing at all*:** *Either way the person is finished with
it.* The **it** is the fear. Under §2 the person is finished with that fear on both routes. What
§3.1 exposes is a **different** fear, one rung up, about which the sentence claims nothing.
**True and incomplete.**

### 7A.2 THE RULING IS ALREADY IN THE BOOK, AT ONE OF THE TWO FATES — and this is the real finding

**BOOK, Ch 15 *The four fates*, the giving-up entry:** *the want behind the fear is dropped, and
with the want gone the fear is gone with it.* **That is §2's ruling, stated.**

**BOOK, the worked-through entry:** *the fear is met and dealt with rather than got rid of.
Nothing is left over, so nothing has to be put anywhere.* **It says nothing about the want.**

***The book states the rule for one fate and not the other, which is why it was never seen to be
general.*** **What the section owes is one clause in the worked-through entry**, saying the want
ends there by being met rather than relinquished. **That is the whole of it.**

### 7A.3 The sorting questions survive and are one short of complete — `[C]`

**BOOK:** *Two questions sort them: whether the fear is in view, and whether it is disposed of* —
four combinations, one empty, and the text says so. **But the two questions put worked through and
given up on in the SAME cell, and the text does not say that.**

**§2 supplies the missing question: how the want ended — satisfied, or relinquished unmet.** Three
questions separate all four fates, and **the regret is the observable that answers the third.**
*An addition, not a repair.*

### 7A.4 The ordering is untouched — `[C]`

**BOOK:** the four are ordered by the crossing's own geometry, the seeing end met first and the
turning-away end second. **Both disposing fates sit at the seeing end.** §4's ladder ranking runs
on a different axis and does not collide with this one. **Nothing to reconcile.**

---

## 7B. MEASURED 2026-09-03 — book 2 Ch 16, *The rule beneath them*

**The section gives up nothing. It has a declared hole that this chain fills, and it already holds
half of what §4.3 claims is new.**

### 7B.1 The declared hole — BOOK

*The rule fixes which fears and desires sit at which levels, and in what order. It does not fix the
motion along them. Whether a person descends, holds or climbs, and how fast, is set by other
things.* **§2 and what comes off it are those other things. Nothing is withdrawn to make room.**

### 7B.2 The section already carries the inverse of the ladder operation — BOOK

*Each new desire is the previous desire with one more layer of unawareness over it.* **The descent
adds a covering; §4 has giving up taking one off. The section states the downward direction of an
operation whose upward direction it does not mention.**

### 7B.3 ***A THIRD `[C]` ERROR — §4.3 IS HALF ALREADY IN THE BOOK***

`[C]` flagged §4.3 as the strongest result in this note and said it was in neither book. **The
first of its two derivations is drafted, in this section:** *Climbing requires seeing the present
desire as a covering over an earlier one. Every step down adds a covering... What the climb depends
on is the thing the descent degrades.*

**What is genuinely new is only the second derivation** — working through needs a satisfiable want,
far down the want cannot be satisfied, so giving up is the only exit left. §4.3's claim of novelty
is corrected to that half.

### 7B.4 What the section is missing is a JOIN, not a claim — `[C]`

**Ch 16:** climbing requires seeing the present desire as a covering.
**Ch 15:** giving up on drops the want.
**On this chain they are one act** — seeing the covering is the recognition, dropping it is the
move. **The book has both halves in different chapters and no sentence connecting them.**

### 7B.5 RULED 2026-09-03 — the covering is LOCAL, one rung

`[A]` asked whether all the desires up the chain must be seen. **They must not.** The desire covers
the fear **one level up** — the fear it answers — and the requirement is one step of self-seeing,
not a survey.

***`[C]`'s word `reflexive` was carrying two meanings and only one was meant*** — seeing that the
desire is a covering, with no claim about seeing the stack. **Corrected.**

**Why a survey reading is false to the model — `[C]`:** the chain is walked one rung at a time, each
step delivering an unanswered fear at the fork. If a person had to see every covering above them
first, the first step would require the last step's clarity and nobody could start. **`[A]`'s own
point that a person can work their way up one level at a time depends on the requirement being
local.**

### 7B.6 What the covering does, and why the climb is hard — `[C]`

**A covered fear is out of view because it has been ANSWERED, not because it was refused.** The
desire took it up and turned it into something to pursue, and the pursuing occupies the attention.
**This is a third condition beside blocking and ignoring and the book has no name for it.**

**So nothing prompts a person to drop a desire.** The desire is the answer that is working; the
fear it covers is not pressing because the pursuit holds it down. **The layer that could be removed
is the one giving no trouble.** What presses is the fear at the person's own level, bred by the
pursuit — and that is not the one whose removal climbs.

**Which is why the noticing is needed after all, and it is weaker than `[C]` first made it:** seeing
the desire as a covering gains no leverage. **It supplies the reason to drop something that is not
hurting.**

**The sequence, and the book has not stated it:** the pressure that brings a person to the fork
comes from below, and the move that climbs is made above, on the desire covering the fear one rung
up. *A better account of why people arrive ready to act and do the wrong thing than anything in the
text.*

---

## 7C. MEASURED 2026-09-03 — book 2 Ch 17, the brake

**Loses nothing. One of the two things `[C]` brought to it was already there.**

### 7C.1 ***A `[C]` NOVELTY CLAIM THAT FAILED*** — the thin tail is already derived

§4.3 called the second derivation the one genuinely new half. **BOOK, the brake paragraph:**
*further down there is more to unbury, so facing costs more, so the point where the comparison
flips sits further out.* **Same result by a different route — cost of facing rather than
availability of the exit.** *Worth having as a second derivation; NOT a gap.*

### 7C.2 The upper half of the bell curve IS absent — and this is Ch 17's one gain

**BOOK states the middle-gathering as a PREMISE:** *Most people sit somewhere in the middle of the
range and stay there for decades, which is a fact about the world and not a modeling preference.*
***That sentence is an admission that it is not derived.*** The chapter then derives only the lower
bound — consequences push back, harder the further down.

**`[A]`'s point supplies the upper bound (§5):** the force is the pain of staying, so **it weakens
as a person rises**, and they stop where it no longer exceeds the cost of facing. **The middle
becomes an equilibrium rather than an assumed fact.**

### 7C.3 The §11.1 repair site confirmed — and the chapter already agrees with itself two lines later

**The sentence taking the step:** *Blindness does not corrupt that comparison. It removes one of
the terms.* **But the guess paragraph two lines below already says** the comparison is probably not
made deliberately at all, and gives blindness as why the moment of clarity is rare. ***That is the
ruling, reached 09-01 and never carried back up to the sentence above it.*** **The repair aligns
two paragraphs already in the same chapter.**

### 7C.4 The floor case of the climb argument is here too — `[C]`

**BOOK, *What reaches someone the consequences no longer reach*:** at depth a person cannot
generate a belief that anything could be different, and what reaches them is an intervener. **So
§4.3's first derivation is in the book TWICE — this chapter and Ch 16.**

---

## 7D. MEASURED 2026-09-03 — book 2 Ch 17, *Rising* and *What is actually being undone*

**Loses nothing.**

### 7D.1 ***`[C]`'s §6 IS ALREADY THE BOOK'S ARGUMENT, STATED MORE FULLY***

**BOOK:** recognition of the buried fears works but is **local** — each fear recovered is one fear
in one realm and there are a great many; **better is to recognize the burying itself**, the
arrangement that disposes of fears without consulting anyone, **which generalizes where the other
does not.**

**§6 adds only that the arrangement is not a fear and so has no fate** — a restatement in the
fates' vocabulary, not a new claim.

### 7D.2 The join `[C]` said Ch 16 was missing is ALREADY DRAFTED, in this chapter

**BOOK, *Rising*:** *The other one uses the same crossing, made in full sight instead of blacked
out, and it is the more surprising half, because it turns out not to be a different subject.*

***The ascent IS a crossing. The four fates are what happens at a crossing.*** **The book ties the
climb to the crossing machinery in one sentence. What it does NOT do is name which fate climbs.**

### 7D.3 The two accounts are SEQUENTIAL, not rival — `[C]`, and this is what §4 is actually for

**BOOK's climb:** withdraw along the arc into the quiet, see what is there, and return — a hardened
thing reopened, *a thing held as a fact given back its status as a question*. **That step RESTORES
a fear to view. It stops there.**

**§4's material:** what happens to the fear once it is in view is the fates, and **whether a layer
comes off depends on which one.**

***The book has the recovery; this chain has the disposal. `[C]` had them as rivals and they are
consecutive.***

---

## 8. THE DESCENT RULE IS STATED TWO WAYS INSIDE BOOK 1 — measured 2026-09-03

***`[C]` FIRST REPORTED THIS AS A DISCREPANCY BETWEEN THE TWO BOOKS. MEASURED, IT IS INSIDE BOOK 1.
Book 2 states the rule faithfully; it inherited the cleaner half of book 1's own inconsistency.***
**This is `[C]`'s fourth wrong novelty or scope claim today, and the fourth found by measuring
against the manuscript rather than by reasoning further.**

### 8.1 The three statements

- **BOOK 1, *Beneath the Levels: The Rule That Drives the Descent* — NO BRANCH.** *a fear is
  answered by a desire — the desire to secure whatever the fear anticipates losing — and pursuing
  that desire breeds a new fear, of failing at it, which is answered in turn one level down.*
- **BOOK 1, the four-sketches section — BRANCH.** *A fear avoided rather than faced becomes the
  desire of the level below... each evasion lays a layer over the ones already there.*
- **BOOK 1, the Core Dynamics introduction — BRANCH.** the desire *can lead* either to working
  through the fear or to papering it over.
- **BOOK 2, Ch 16 — NO BRANCH.** The rule statement, carried across accurately.

### 8.2 The real difference is the CONDITION, and `[A]`'s word reconciles it — `[C]`

**The rule statement says a fear is *answered* by a desire and reads as automatic. But answering a
fear with a desire is not facing it — it is substituting a pursuit for it.** ***Being answered by a
desire IS the unattended route, described without saying so.***

**The rule statement omits the alternative; the other two name it. Neither is wrong. Succumbing
(§9.1) is the condition the rule statement leaves out.**

### 8.3 The second difference is cosmetic and should still be fixed — `[C]`

**The rule statement puts the answering desire at the fear's OWN level**, with the bred fear one
level down. **The four-sketches statement has the avoided fear becoming the desire of the level
BELOW.** *Same alternation, different placement of the level boundary. Nothing in the mechanism
turns on it — but two sections of one book draw the line in different places.*

### 8.4 What this does to the repair

**The unattended clause of §9.3 now has TWO sites, not one: book 2 Ch 16's chain AND book 1's rule
statement.** *Without it book 1 goes on contradicting itself two sections apart.*

***And it names a defect class the coherence check cannot reach.*** That check inventories book 2
and consults book 1 only where an assumption needs meeting. **A rule stated two ways inside ONE
book, two sections apart, is invisible to it — and so is the same rule stated two ways across the
two books.**

---

## 9. SUCCUMBING, AND THE CONDITION THE DESCENT RULE IS MISSING

### 9.1 RULED 2026-09-03 — `[A]` distinguishes giving up on from succumbing, then names succumbing

> i almost said given up on - there's a difference between given up on and succumbing to - i think
> given up on means given up on avoiding the feeling of fear and succumbing to means burying the
> feeling of fear by ceasing to think about it.

and, when `[C]` asked whether succumbing is a fifth fate:

> i meant succumbing as the unclean resolution - either ignoring or the blindness mechanism.

**So succumbing is not a fifth fate. It is a name for the PAIR — and the book already has that
name.** **`unattended`, ruled 08-30, is the genus over `ignored` and `blocked`.**

### 9.2 THE TWO CHAINS BECOME ONE — `[C]`, and this resolves §8

**Read book 1's *avoided* as `unattended`:**

- **book 1 supplies the CONDITION** — a fear left unattended becomes the desire of the level below;
- **book 2 supplies WHAT HAPPENS when the condition holds** — the chain, rung by rung.

**An attended fear is worked through or given up on and the chain stops there. An unattended one
gets the desire of the level below.** **Neither book is wrong. Book 2 states the rule without its
condition, which is why it reads as automatic.**

### 9.3 What this costs the text — `[C]`, ONE CLAUSE

**book 2 Ch 16's chain must say a fear *left unattended* is answered by a desire one level down.**
Without it the section says wanting anything is a descent. **NOT RULED AS A TEXT CHANGE.**

**And it gives the four fates a job they do not currently have:** they are written as what becomes
of a fear at the crossing; on this they are **also the switch on the Levels chain** — the two
attending fates stop it, the two unattended ones continue it. **Ch 15 and Ch 16 are about one
mechanism and neither says so.**

### 9.4 RULED 2026-09-03 — what `[A]` reads Riso as saying, and it bears on the chain's shape

> riso says upon falling, the desire arises as a less desirable alternative after the upper level
> fear is succumbed to.

**book 2 Ch 16 currently has the desire aimed at what the fear is about** — *the desire to secure
whatever the fear anticipates losing.* **On `[A]`'s reading the fear is succumbed to first and the
desire that arises is a LESSER ALTERNATIVE to what was surrendered.** *Different chains.*

**Book 1's conservation property leans `[A]`'s way** — *nothing new is ever wanted, only the same
want at a further remove* — which reads as one want degrading rather than a want being secured.
**NOT MEASURED against Ch 16's text. Flagged, not ruled as a change.**

---

## 10. HOW A LEVEL IS BUILT — `[A]`, and the lower half was already ruled

> falling one level is built of smaller steps. ignoring builds slowly to burying and many buryings
> constitute a level.

### 10.1 The second stage is `[A]`'s own 08-27 ruling restated

**Blindness accrues in fractions of a level, one crossing at a time, and there is no such event as
a full-axis collapse.** *Many buryings constituting a level is that ruling the other way round. Not
new.*

### 10.2 The first stage is new, and Ch 15 supplies its mechanism without connecting it — RULED

**BOOK, Ch 15, the paragraph immediately BEFORE the four fates:** *The three are not two kinds of
thing with a line between them. What a person does about what registers runs from the involuntary
to the chosen, and a choice repeated often enough stops being made and sinks back toward the
involuntary end.*

**That is ignoring hardening into burying, written out. What the book never says is that this is
what the descent is made of.**

**`[A]`'s claim, and it needed one round to state precisely:**

> i thing repeated ignoring causes a blindness eventually, but i'm don't claim the blindness happens
> entirely in a single crossing.

**`[C]`'s reading, accepted by `[A]`: the SLIDE is the accrual.** Each repetition moves the handling
of that kind of fear further toward the involuntary end; the further it has sunk, the less of the
fear reaches the person. **Sight is not lost at a point where ignoring becomes blocking, because
there is no such point.**

**BOOK's *Only a blocked fear is a failure of seeing* SURVIVES**, because blocking is a matter of
degree: a handling half sunk is half blocking and costs sight in that proportion. **The sentence is
true at every point on the run; it is not a claim about four boxes.**

### 10.3 Two ledgers, not one — `[C]`

- **Every crossing writes to the DEPOSITS.** *`[A]`'s `Job44` ruling: what is blocked or ignored
  goes into the deposits and accumulates unseen.*
- **A crossing writes to BLINDNESS in proportion to how far that handling has already sunk toward
  the involuntary end.** An early ignoring costs almost nothing; a late one costs nearly what a
  blocking costs.

*A smooth version of `[A]`'s two stages rather than two mechanisms.*

### 10.4 The join this produces — `[C]`, and it is the only new sentence the exchange needs

**The involuntary-to-chosen continuum is in Ch 15, one section before the fates. The accrual of
blindness in fractions of a level is `[A]`'s 08-27 dissolution ruling. NOTHING SAYS THEY ARE THE
SAME THING.**

### 10.5 It answers a residue `[C]` left open and did not expect answered

`[C]` had asked whether ignoring descends at all, since Ch 15 says it leaves fear and want intact
and only lets the occasion pass. **It does not descend directly. It descends by BECOMING burying.**
*Ignoring is the holding pattern until it stops being a choice.*

---

## 11. TEXT DECISIONS TAKEN BY `[A]` THIS SESSION

**Neither is applied. Both are §5 material for the handoff and work for a drafting session.**

1. **book 2 Ch 15, the worked-through entry — ADD A CLAUSE.** The want ends there by being **met**
   rather than relinquished, which is why nothing is left over. *This makes §2's rule visible on the
   page without stating it as a rule, since the giving-up entry already carries its half.*
2. **book 2 Ch 15, after the sorting paragraph — ADD ONE SENTENCE.** The two questions leave worked
   through and given up on together; what separates them is **how the want ended**, with the regret
   as the mark. ***NOT a third sorting axis*** — `[A]` was given `[C]`'s reasoning that a third
   question makes eight combinations and puts the empty-combination argument for blocking onto a
   structure nobody has checked. **The two questions and the empty combination stand unchanged.**

### 11.1 RULED 2026-09-03 — blindness works by keeping the comparison UNCONSCIOUS

**`[C]` put it to `[A]` that if the comparison is unconscious it was never going to weigh a
prospect a year out, so immediacy follows from unconsciousness rather than from blindness.**
`[A]` ruled: **by keeping the comparison unconscious.**

**The repair site is book 2 Ch 17:** *Blindness does not corrupt that comparison. It removes one of
the terms.* **A step is inserted, not a sentence withdrawn** — blindness keeps the comparison below
consciousness; what is below consciousness cannot weigh a prospect a year out. **The conclusion is
unchanged.**

**Measured: the claim stands at six sites and only ONE is manuscript.** The other five are the brake
note, the Part 3/4 architecture, the handoff, the two-pressures note and the author record. *Records
of what was ruled take a dated line, not a rewrite; the architecture file also specifies, so it
takes the amendment.*

**What the ruling buys — `[C]`:** three things the book had separately become one mechanism — the
routing comparison, blocking as a learned reflex, and blocking strengthening each time it runs.
**BOOK's *Blocking is not a decision* survives untouched**, since a comparison made below
consciousness is not a decision. **And the entrenchment gets its content:** what is reinforced is
the outcome of the comparison.

**It also repays §1.2's fourth job.** That job asked what determines success and tied it to
unconscious against conscious response. **The comparison is the same one either way; what conscious
response changes is that the long-term term becomes available to be weighed.**

### 11.2 RULED 2026-09-03 — the 08-27 sweep finding, and the manuscript stands

`REPAIRS-job16-book1-defects-20260825*.md` §2.14 specifies *runs its own arc*; book 1 reads *runs
its own smaller arc*. **`[A]`: the manuscript stands and the REPAIR RECORD holds the defect.**
*`smaller` is doing work — the arcs are smaller than the orientation cycle the paragraph has just
described.* **The 08-27 note's §16 and §17 item 9 are closed.**

---

## 12. WHAT MUST HAPPEN BEFORE ANY OF THIS IS DRAFTED

**`[A]`, this session: no drafting yet.**

**THE MEASUREMENT — ALL FOUR SITES RUN 2026-09-03. NOTHING IS GIVEN UP AT ANY OF THEM.**

| Site | Status |
|---|---|
| book 2 Ch 15, *Take one fear at a time* and *The four fates* | **MEASURED — see §7A. Loses nothing; gains one clause and one sorting question.** |
| book 2 Ch 16, *The rule beneath them* | **MEASURED — see §7B. Loses nothing; owes one clause (§9.3) and one join (§7B.4).** |
| book 2 Ch 17, the brake and *Why this does not take everyone to the floor* | **MEASURED — see §7C. Loses nothing; gains the upper half of the bell curve and the §11.1 step.** |
| book 2 Ch 17, *Rising* / *What is actually being undone* | **MEASURED — see §7D. Loses nothing. §6 is already the book's argument; §4's ladder material is SEQUENTIAL to the book's climb, not rival.** |

**What the chain actually owes the book is FOUR ADDITIONS, none structural** — the clause and the
sentence in Ch 15 (§11), the unattended condition in Ch 16's chain and in book 1's rule statement
(§8.4, §9.3), the upper half of the bell curve in Ch 17 (§7C.2), and the inserted step making the
comparison unconscious (§11.1).

**THE CAUTION, and it is the same one `Job44` entered.** §3 onward is four inferences deep from a
rule ruled this session, and the last chain built this far past the text had two of four links break
on first contact with something `[A]` knew — the fourth cause and the locatable-source distinction
in the two-pressures note. **`[C]` stopped rather than building further, and `[C]` was wrong SIX times in
this session** — §1.1 twice, §3's level, §7's chain, §7B.3's novelty claim, and §7B.5's word
`reflexive`. **`[A]` caught five of the six.** ***And FOUR further claims of novelty or scope failed
measurement*** — §7A.1, §7B.3, §7C.1, §7D.1 and §8's cross-book framing. **Every one was found by
measuring against the manuscript, none by reasoning further. That is the argument for the next
session being a composing session and not another doctrine one.** *A session taking this up should treat §3, §4
and §6 as needing a check they have not had.*

**The coherence check cleared the four fates section on 09-02.** Reopening it on one session's
inference, before the inference has been measured against the text, is how a good finding costs more
than it is worth.
