# OPEN ITEMS RAISED BY `job25-drafting-20260829`

Cut by the drafting session. Nothing here is ruled. Each item is stated as the
question, not as an answer, so that a later session does not cite it as doctrine.

---

## 1. WHAT REINFORCES THE BURIAL REFLEX — doctrine, and it needs the record open

**The question.** If a fear is blocked before it reaches awareness, the person feels
nothing when the blocking fires. There is no relief to reward it, and noticing that
something unpleasant did not happen would require comparing against a state that never
occurred. So what keeps the reflex running?

**Where the material is.** `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md`
§4 carries `[A]`'s answer of 2026-08-26 verbatim, and §4.1 points at a Ch 17 passage
about an infant's expectation hardening which the note says already contains the
mechanism and has never been pointed at blindness. **That note is marked on its face as
not yet ruled and not citable as doctrine, and this passage is not among its exempted
lines.**

**Why it was not taken here.** Ruling it means reading `[A]`'s words in the record and
deciding what they commit the model to. This session kept the record closed. It also
reaches past Ch 11: it bears on when a fixation forms, which both books treat as a habit
set down early, and a claim of that reach acquires its own authority once it looks ruled
— `[A]`'s own test, and his stated reason for declining to rule the level-feedback
corollary on 08-27.

**Also unruled in the same region:** whether the reflex is better called learned than
designed.

**Not blocking.** The Ch 11 drafting states that the blocking is not decided, which `[A]`
ruled 2026-08-29, and says nothing about how it was learned.

---

## 2. TWO SCALES THE CHAPTER DOES NOT JOIN — put to `[A]`, unanswered

How a realm comes to be little seen, and what becomes of each fear that arises in it, are
different scales. The drafted passage states both and leaves them apart, deliberately.
**Does the chapter need them joined?**

A first attempt built the realm-level description out of a run of individual fears and was
withdrawn: that is the move set aside by the 08-20 ruling that the fixation causes the
stopping rather than being constituted by what happens in each arc.

---

## 3. RULED 2026-08-29 — DETACHMENT SEES THE REALM WHOLE

**`[A]`'s wording, in session:**

> the detached orientation see into a realm as a whole regardless of whether all of
> what they see is available to consciousness

and, asked whether the person who notices each fear and settles none of it sees the realm
whole:

> they see into the real as a whole, that doesn't mean they think about it

**RULED. What it fixes:** seeing into the realm is the invariant of the orientation. What
varies is how much of what is seen becomes available to consciousness, and what is then
done with it.

**Two things ruled with it, by consequence and stated to keep the ruling narrow:**
seeing a realm whole is what the detached orientation does, so a realm is not seen whole
without it; and seeing each thing as it arrives is NOT the same as seeing the realm
entire.

**THE WORD IS DELIBERATELY LEFT OPEN.** `[A]` ruled the rule and not the naming. Nobody
writes a substitution on the strength of this ruling. See the census below.

### 3.1 Why the naming is a separate pass — and it was already owed

The books use the seeing family for the VARYING quantity throughout. Under this ruling
that is backwards: seeing is the invariant.

**But the ruling does not create this.** Every site below was already in tension with the
08-21 ruling that *the blind end is a failure of conscious availability, not of
registration*. If registration survives, descent does not destroy the seeing. **Nobody
counted the sites.** One has been repaired — Ch 11's, on 2026-08-25 for book 1 and
2026-08-29 for book 2 — and that repair chose `is seen` over `registers` on the stated
ground that *the book calls this quantity seeing everywhere*. **Under this ruling that
ground is backwards and the repaired sentence uses the reserved word.** It is not wrong
as prose; what varies really is how much surfaces.

### 3.2 THE CENSUS — the sites a naming pass must judge

About 500 occurrences of the seeing family across both books; almost all ordinary
English. The sites where seeing names the VARYING quantity:

**Load-bearing, need a rewritten sentence, not a substitution:**

| Site | What it says |
|---|---|
| bk1 L1490 | *the terminal levels are precisely the destruction of the seeing itself. The faculty that ascent depends on is the very thing descent destroys* — the ground of Ch 16's mobility asymmetry |
| bk1 L2294 | *the terminal levels (7–9) are the progressive destruction of the seeing itself* — App G, cites the asymmetry by name |

**The face pair — `blind face` 7 sites bk1 + 2 bk2, `seeing face` 2 sites bk1:**
bk1 L516, L518, L1454, L1506, L1614, L1770 · bk2 L356. The naming of the pair is what is
at issue, not each sentence.

**`seeing lean` — bk1 L1624, L1830, L1936.** All three are the Level 1 description.

**`clear seeing` of Z− — bk1 L1364, L1370.**

**Ch 11's Z-range sentence — bk1 L1129, bk2 L846.** Already repaired; revisit under the
ruling.

### 3.3 What this ruling does NOT reach

It is about the detached orientation. Whether the health axis's seeing quantity is the
same object is NOT settled here — `[A]`'s 08-20 captured material has enthusiasm unable
to see the bigger picture and caution unable to see the whole, which if ruled would make
whole-realm seeing detachment's alone and the health axis's quantity something else
again. **That material is captured and unruled. Do not assume it.**

---

## 4. SECOND CENSUS — `BACKWARD` STILL DRAFTED IN BOTH BOOKS

**The ruling it violates was closed 2026-08-19 and is not new.** Nothing runs backward:
under stress, forward arcs meet overwhelm sooner, so what book 1 recorded as a backward
step is a forward run with a passage skipped. Destinations correct, route wrong. The
08-20 descent ruling did the same for the winding structure — the descent is a blind
forward turn.

**Nobody has counted the drafted text against it.** `backward` stands on **14 lines in
book 1** (L556, L574, L654, L826, L834, L1082, L1112, L1173, L1253, L1612, L1991, L1993,
L1997, L2105) and **6 in book 2** (L592, L604, L771, L781, L787, L850).

### 4.1 Two distinct kinds, and the first is not a wording repair

**ARCHITECTURE — a drafting decision, not a substitution:**

- **bk2 L592 — `### Backward` is a section heading.** Ch 7 is built as *Forward* / *Backward*,
  with three backward transitions written out beneath it. The retired mechanism is the
  chapter's structure.
- **bk2 L604** — *Coming forward, a person enters it seeing… Coming backward, a person
  enters it blind, as shutdown.* The two faces of detachment are still explained by two
  directions. Under the ruling they are one forward passage, run through or skipped.
- **bk2 L771** — *Disintegration runs the same lines backward.* States the retired
  mechanism directly.

**NOT AFFECTED — `backward` here names a lean's direction on the circle, which is a
position, not a motion, and survives the ruling:** bk2 L781 (`−` = a backward lean toward
the previous orientation), L787, L850. **A naming pass must not sweep these.**

Book 1's 14 lines are uncounted by kind. Someone must sort them the same way before any
repair.

### 4.2 What was already repaired

Two sites in this neighbourhood were handled today: Ch 11's closing sentence *Vision and
blindness are the two ends of one orientation, reached by opposite routes* was cut in the
rewrite, `[A]` having pointed out that opposite routes is the retired mechanism. The rest
stand.

### 4.3 Why this session did not take it

Ch 7's two-part structure is a drafting decision of a size this session could not finish
well. **Recorded, not started.**

---

## 5. THE SECOND BRAKE — RULED 08-27, NOT DRAFTED, AND IT IS BLOCKED ON ARCHITECTURE

**What is ruled (2026-08-27).** A second brake exists: intervention from outside the
person. What works differs in each case and the intervener must find it; it works much
better if the intervener has been rescued or rescued themselves. Asked whether the shared
experience supplies the content or the search, `[A]` ruled **both**. **The two brakes work
by opposite means** — the first is force triggered by consequences and needs no
self-recognition; the second **imports sight the person cannot produce.**

**Why this session did not draft it.** Both brakes are descent material: the trigger being
consequences, sight selecting the route between fixing and hiding, and now the imported
sight. **No chapter in either book says any of it.** In book 2 this is Part 3, and **the
architecture for Parts 3 and 4 has not been written.** Drafting it would mean either
extending book 1, which is under repair rather than extension, or deciding Part 3's shape
by default from the end of a drafting session. **That is the largest architectural
decision outstanding and must not be made sideways.**

**BLOCKER, and it should be answered before anything is written:** the first brake was
ruled conditional on stress. **Nobody has asked whether the second is.** If help also
fails under stress the two brakes fail together and the low tail is thicker than the model
currently claims.

---

## 6. WHAT THIS SESSION LEFT UNTOUCHED

- **The B-side account** — the largest drafting item outstanding. The whole current thread
  is scoped by `[A]` to fears arriving at detachment from enthusiasm. **Nothing anywhere
  has been written for fears arriving from the caution end, and nothing about it is
  ruled.** A drafting session would be inventing, not writing.
- **`forgetfully blind`, bk1** — `[A]` replaced it in book 2 with *unconsciously but
  militantly blind* during this session. **Book 1's twin sentence still carries the old
  phrase**, which fuses the two conditions ruled apart on 08-27.
- **Two further bk1/bk2 divergences created today**, both `[A]`'s own revisions to book 2
  with book 1 unchanged: the cut of *and every degree between them is occupied*, and
  *concerned clarity* replacing *tranquil clarity*. **Neither is on any repair list.**
