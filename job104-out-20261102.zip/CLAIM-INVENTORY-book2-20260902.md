# CLAIM INVENTORY — book 2

**Built by `Job44 coherence 09022026`, 2026-09-02, from `BOOK2-20260902b.md` (27,575 w,
1,307 lines, md5 `6ef4edb7`) and from nothing else.**

**This file survives the session and is UPDATED at each later change, not rebuilt.** When a
chapter is redrafted, moved or renumbered, the entries for its sections are re-read against
the new text and amended; entries elsewhere that cite it are checked. Rebuilding from scratch
loses the record of what was checked and found sound.

---

## UPDATED 2026-09-06 by `Job53 coherence 09062026`

**Re-read against `BOOK2-20260906b.md` — 30,885 w, 1,421 lines, md5 `d2ef43ce`.** The master
moved four times between the build and this pass, 27,575 w to 30,885 w. **Nothing here was
rebuilt.** Every entry was re-read against the new text; the entries that changed carry
`RE-READ 09-06` and quote what changed them.

**Twelve of the faults below are discharged on the page**, marked `DISCHARGED 09-06` at the
head of each, with the sentence that discharges it quoted. **Nothing was ruled or drafted
here** — the prose was written by the drafting sessions of 09-04, 09-05 and 09-06, and this
pass only records that it landed and says what it landed as.

**Five headings were renamed on 09-04 and the entries below carry the new names.** Older fault
text still quotes the old ones and is left as written, because it is a record of what was found
at the time.

| Was | Is |
|---|---|
| Ch 7 *Detachment's two faces* | *The two faces of detachment* |
| Ch 11 *Detachment's lean is not like the others* | *The lean in detachment is not like the others* |
| Ch 13 *What the folding separates* | *What self-reference does* |
| Ch 15 *Detachment's range* | *The range of detachment* |
| Ch 17 *Why this does not take everyone to the floor* | *…to the bottom* |

**One section is new** — Ch 16's *What a level is made of* — and has an entry below.

---

## UPDATED 2026-09-07 by `Job57 coherence 09072026`

**Re-read against `BOOK2-20260907b.md` — 32,533 w, 1,489 lines, md5 `e79a8abd`.** The master
moved twice since the 09-06 pass, 30,885 w to 32,533 w, both moves on 09-07. **Nothing here was
rebuilt.** The entries touched by the two-stage doctrine were re-read and carry `RE-READ 09-07`.

**Nothing found on 09-06 is discharged here.** The 09-07 drafting session applied the eleven
items owed by `SET-NOTE-from-job55-20260907.md`, and this pass records what that left standing
rather than re-auditing what it closed.

**The pass was aimed at one class of fault.** `Job55` ruled seeing to have two stages — a whole
taken in, and an attending that picks parts out of it — with `take in` naming the first, `notice`
the act of the second, and `sight`/`seeing` the capacity to do the second, which is what the
health axis measures. `Job56` made the vocabulary pass and warned that a sentence assuming the
single-stage account while using neither word cannot be searched for. **Nine faults were found
by reading cold and all nine were ruled by `[A]` in this session** — faults 25 to 33 below.

**One entry's section has been renamed.** Ch 11 *What the leans do with what registers* is now
*What the leans do with what a person notices*, `register` having been retired from book 2 on
09-07. Older fault text still quotes the old name and is left as written.

**What this pass did NOT do.** The per-entry sweep stopped at the entries the two-stage doctrine
touches. Entries elsewhere still describe the text accurately and were not re-read line by line.
**An entry that records the old vocabulary is not stale**, because the text still carries it: the
repairs are owed prose and none of them is written. A later pass re-reads those entries once the
drafting session has run.

---

## UPDATED 2026-09-12 by `Job65 coherence 09122026`

**Re-read against `BOOK2-20260912.md` — 35,695 w, 1,580 lines, md5 `1065e37e`.** The master moved
four times since the 09-07 pass, 32,533 w to 35,695 w, on 09-08, 09-09, 09-10 and 09-12. **The
09-08 and 09-09 coherence runs did not re-read the entries** — the 09-09 run appended its own
findings and followed one word through the book instead, as its closing paragraph says — so this
file has carried findings newer than the entries beside them for three days. **Nothing here was
rebuilt.** Entries touched by the four drafting sessions carry `RE-READ 09-12`.

**One section is new and had no entry** — Ch 17's *What falling takes from capacity*, which carries
the stress account. **Ch 17 had ten entries against eleven sections.**

**Fault 13 is discharged.** Forgetting, which appeared in Ch 17's brake section and nowhere else in
book 2, is gone from Ch 17 and is now defined in Ch 15 *Disregarding, and not seeing at all*, where
`[A]`'s 09-12 ruling put it: ignoring and forgetting are one act at the two ends of the run from
the chosen to the involuntary.

**Four new faults, 44 to 47.** Two of the four were ruled by `[A]` in this session and both are
owed prose; the two others are recorded as questions. **Nothing was drafted and nothing was ruled
by `[C]`.**

---

## HOW TO READ AN ENTRY

Each section gets three lines.

- **Asserts** — what the section claims, in the inventory's words, not the section's.
- **Assumes** — what a reader must already have for the section to work.
- **Met at** — where each assumption is stated, by chapter and section title. `book 1` marks
  an assumption met outside book 2. `NOT MET` marks one that is not stated anywhere and is
  carried to the faults list.

**Every entry was made from the text.** No entry was made from the architecture file, and the
architecture file was not open while the entries were written. An entry that could not be made
from the text is marked `UNREAD` rather than filled in; there are none in this cut.

**Section titles are the handle, not line numbers.** Book 2's line count moved 872 → 1,307 on
09-02 and will move again.

---

## SCOPE

**Book 2 only**, per `[A]`'s ruling of 2026-09-02: *the coherence job works on book 2 only and
touches book 1 when necessary.* Book 1 is consulted and never inventoried. Where an assumption
of book 2's is met in book 1 rather than in book 2, the entry says so and names the book 1
section, so that which of book 2's foundations sit outside book 2 stays visible.

**Part 3 is inventoried whole — 40 sections.** Parts 1 and 2 are inventoried at the sections
Part 3 reaches back to — 19 of them — plus the four chapters Part 3 never touches, entered at
chapter level only and marked as such, because test (b) needs to see them.

---

# PART 1 — sections Part 3 reaches back to

## Ch 1 · A New Theory of the Enneagram (no sections)

- **Asserts** — nine types are three orientations in two realms, 3 × 3, and could not have been
  eight or ten; a hardened orientation is a **fixation**; a person holds one per realm.
- **Assumes** — nothing. This is the book's first substantive claim.
- **Met at** — n/a. *This is where `fixation` is named for the reader without being explained,
  which is the standing rule; the explanation arrives at Ch 15.*

## Ch 3 · The Two Realms (no sections)

- **Asserts** — everything falls in one of two realms, **H** physical and **S** psychic; the
  physical **corrects through pushback**, the psychic **compounds through feedback** because it
  has no outside and whatever is done loops back through the doer; neither realm is the real
  one; there is one error and it runs both ways — applying either realm's principles inside the
  other.
- **Assumes** — nothing prior.
- **Met at** — n/a. **Ch 13's *What the folding separates* revises this section's criterion; see
  fault 5.**

## Ch 4 · The Three Orientations (no sections)

- **Asserts** — three orientations **A** enthusiastic, **B** cautious, **Z** detached; their
  competences are **doing**, **understanding** and **seeing** respectively, seeing being
  *plain, instinctive, concept-free observation*; **detachment has two faces**, clear and
  blind; denial *is not a decision: a decision to not see could happen only after a thing has
  already been seen*; what separates the three is **where attention goes**, and *what hardens,
  in a realm, is the attending*.
- **Assumes** — the two realms.
- **Met at** — Ch 3. *This section is the source for four things Part 3 leans on: the three
  competence words, the two faces, the small version of blocking-is-not-a-decision, and
  attending as the thing that hardens.*
- **RE-READ 09-06 — the section has gained two claims and both are things other chapters
  had been using without a source.** *What an enthusiastic person is averse to is
  disappointment. What a cautious person is averse to is losing control. What a detached
  person is averse to is suffering with nothing softening it. How much of it a person can
  bear depends on how deeply caught they are in the orientation.* That is the aversion
  objects and the tolerance rule, and Ch 5's nine sketches now stand on it. And *There is one
  attention and two realms, so what goes to one is not going to the other*, which is fault 6
  discharged. **So the section is now the source for six things, not four.**
- **RE-READ 09-07 — the section gained five paragraphs of new doctrine and the competence word
  changed.** Detachment's competence is now **taking in**, not seeing. The two stages are stated
  here: *Everything a realm holds is taken in, whole and at once*, and *Picking one part out of
  what was taken in and attending to that part is a second and different act. This book calls
  that act noticing, and it is work.* Motivation brings the noticing on and also sets how wide
  the taking in is; the three widths follow; a person does one or the other and not both at once;
  and `intuition` is defined here. **So the section is now the source for eleven things.** Two of
  the new paragraphs carry faults — see faults 27 and 30 — and one older sentence in it does, at
  the clear face.
- **RE-READ 09-12 — the section was worked on at all four drafting sessions and three of its claims
  are now stated differently.** The width sits on **what is open to noticing** and never on the
  taking in, which is fault 35 discharged. The competence is **being able to notice more**, fault
  36 discharged. The ordering now has **four positions in `[A]`'s own wording** — wanting a
  disturbance gone is the narrowest, then enthusiasm, then caution, then wanting to solve a
  disturbance, which is the widest — and this supersedes the account Part 3 used to lean on, in
  which the enthusiasm end had nothing narrowing it. **`part of the realm` is gone** as the way to
  say what a want is about. Denial is now held apart from ordinary turning away and is turning away
  that has become automatic. `caught` is defined here and restated at Ch 10 and Ch 15. **So the
  section is now the source for fourteen things.**

## Ch 5 · Where the Types Come From — the nine sketches, entered together

- **Asserts** — each type is its two fixations at work; and, inside the sketches rather than as
  a stated principle, that **a person's attention sits in the realm they are enthusiastic in
  and the other realm runs underneath**, *the enthusiastic realm takes the foreground*, and
  where nothing is enthusiastic *nothing competes for the foreground*.
- **Assumes** — the grid of pairs; the three competences.
- **Met at** — Ch 1, Ch 4. **The foreground claim is stated only inside the Type 1 and Type 6
  sketches and is never generalized; Ch 17 leans on it hard. See fault 6.**
- **RE-READ 09-06. All nine sketches gained a closing block on 09-05 and the chapter is a
  different object.** Each one now asserts **what a person of that type can do when less
  caught in the fixations**, realm by realm, and every one of the nine reaches it the same way:
  by naming the orientation one step on from the one held. *The step past enthusiasm is
  caution* (the One, the Two, the Three, the Seven, the Eight), *the step past caution is
  seeing* (the Four, the Five, the Six), *the step past detachment is engagement* (the Nine).
- **Assumes, newly** — the tolerance rule, **met at Ch 4**; and **the cycle's ordering, which
  is NOT met at Ch 4 and is first stated at Ch 7**. See fault 19.
- **Two of the nine assert something stronger than the rest and assert it nowhere else** — the
  One's and the Eight's, where the quiet realm *does not become visible at any depth*. See
  fault 20.
- **RE-READ 09-07.** The nine framing phrases are struck, the Nine's block is repaired to the
  taking in, the Four's obsession passage is repaired, and two of the twelve instances moved to
  Ch 10. **What the sketches still carry, and it is four faults' worth:** the four detached-realm
  openers name the competence *see* (fault 28); the Five's obsession passage is the Four's
  unrepaired (fault 25); the Nine's block gives depth as the reason for its two faces (fault 33);
  and the growth halves depend on a crossing between realms that the book never names (fault 24).
- **RE-READ 09-12.** `a detached realm` is now defined in this chapter, where the short form starts
  being used, on `[A]`'s instruction of 09-10 — *"i continually forget that 'a detached realm'
  really means a realm in which the fixation is in the detached orientation."* Ch 4's one earlier
  use and Ch 7's and Ch 10's distant uses take the long form. **The Nine's block no longer says a
  Nine has no want of their own**: every realm raises wanting and fearing whatever orientation is
  held there, and lending is a second source on top of that.

---

# PART 2 — sections Part 3 reaches back to

## Ch 6 · The Grid (no sections)

- **Asserts** — the 3 × 3 table of pairs; **aligned** types on the diagonal, **mixed** off it;
  folding the table exchanges realms; the row/column order is not arbitrary but the reason has
  not yet been given.
- **Assumes** — three orientations, two realms, nine pairs.
- **Met at** — Ch 1, Ch 3, Ch 4.
- **RE-READ 09-06 — one claim added, on 09-06.** *With the same orientation on both sides a
  person has only ever attended one way. A mixed type has watched themselves attend in two
  different ways. An aligned person takes their own way of attending to be how things are. So
  one set of rules gets carried across both.* It assumes only that attending is something a
  person does, **met at Ch 4**.
- **And the section says in its own voice that the ordering has not been earned yet:** *Until
  the reason for it is given, a step from one cell to its neighbor is only a step, with no
  direction to it.* That sentence is what makes fault 19 sharp rather than mild.

## Ch 7 · The Cycle (head)

- **Asserts** — the three orientations stand in a closed order, A → B → Z → A, each fully lived
  pointing to the next; **this is a statement about directions, not motion**; a fixation is *a
  habit set down early and held so long that it is simply where they live*; **integration** is
  the pull with the order, **disintegration** against it.
- **Assumes** — the three orientations.
- **Met at** — Ch 4.

## Ch 7 · Forward / Backward

- **Asserts** — the six passages, each requiring what the current orientation resists; B → Z
  enters detachment *on its clear-seeing side*, A → Z *on its blind side*.
- **Assumes** — the two faces of detachment.
- **Met at** — Ch 4.
- **RE-READ 09-07.** The B → Z arrival is forward and stands. **The A → Z arrival asserts a
  route the model does not have** — see fault 32 — and the two naming words are both retired,
  see fault 31.

## Ch 7 · The two faces of detachment

- **Asserts** — a lean from caution shows detachment seeing, a lean from enthusiasm under stress
  shows it blind; detachment alone contains these opposites.
- **Assumes** — the six passages; leans, informally.
- **Met at** — Ch 7 Forward/Backward. *Leans are not defined until Ch 11 and this section uses
  the word ahead of it; the use is loose and survives.*
- **RE-READ 09-07. Both of this section's two sentences are faulted.** The first names the ends
  with the retired words (fault 31); the second asserts the backward route (fault 32). **The
  section survives and is rewritten, not cut** — `[A]` ruled 09-07 that *two faces* stays as the
  name for the thing before leans exist, and that the two faces are to be described rather than
  labelled.
- **RE-READ 09-12.** The four fates are out of this chapter, fault 39 discharged: Ch 7 keeps only
  looked at against turned away from, and the four are given once, at Ch 15.

## Ch 7 · What kind of thing this is

- **Asserts** — every process runs its own arc through the orientations; the **thought arc** and
  the **endeavor arc** are named; at the scale of **character usually none completes** and what
  varies is the lean.
- **Assumes** — the cycle as an ordering.
- **Met at** — Ch 7 head. **Why there are scales at all is not stated here; Ch 13 supplies it
  six chapters later.**

## Ch 7 · The smallest scale

- **Asserts** — every process makes three passages, **arising, development, ending**; *in a
  lived process each passage completes at an orientation: arising at A, development at B,
  ending at Z*; the thought arc closes into a loop, each thought arising conditioned by the one
  before; *everyone's thoughts make all three passages; what varies is what those thoughts are
  about*.
- **Assumes** — the orientations and the cycle.
- **Met at** — Ch 4, Ch 7 head. **This section attaches the letters to passages, which Ch 14
  forbids. See fault 1.** *Its `conditioned by the one before it` is also the hook Ch 15's
  mental deposits answer.*

## Ch 8 · Relational Positions (no sections) — entered at chapter level

- **Asserts** — six positional relations between any two types, read off the grid two realms at
  a time.
- **Assumes** — the grid, the closed loop.
- **Met at** — Ch 6, Ch 7. **Nothing in Part 3 uses this chapter. See fault 8.**

## Ch 9 · Relational Dynamics — entered at chapter level

- **Asserts** — energizing/burdening by one step ahead or behind; appreciation, looking up and
  respect held apart; position-by-position dynamics; realm friction as a second and independent
  mechanism.
- **Assumes** — Ch 8's positions.
- **Met at** — Ch 8. **Nothing in Part 3 uses this chapter. See fault 8.**

## Ch 10 · The Figure's Own Lines — entered at chapter level

- **Asserts** — the classical triangle and hexad fall out of the grid; the realms alternate
  strictly in the hexad; twelve **crossing relations** the figure does not draw; disintegration
  is the same lines read backward.
- **Assumes** — the grid, ahead/behind, integration as the forward direction.
- **Met at** — Ch 6, Ch 7, Ch 8. **Nothing in Part 3 uses this chapter, and its *crossing
  relation* is the older half of the `crossing` collision. See faults 8 and 2.**

## Ch 11 · Leans, and the Classical Wings (head)

- **Asserts** — nobody holds an orientation purely; a lean shades a type and never changes it;
  three positions per orientation, **−**, **0**, **+**, giving nine named positions; these are
  instances of the orientation, not a fourth thing.
- **Assumes** — the orientations and the cycle's order.
- **Met at** — Ch 4, Ch 7. *This is where Part 3's nine named positions come from.*

## Ch 11 · The eight wings / Reading a person either way / Fractional leans / Opposite / Where the two systems disagree

- **Asserts** — eight wings not two; lean and wing are two descriptions of one movement; a lean
  has a strength written as a fraction, named from the nearer orientation; exact opposition
  needs fractional leans; the classical evidence was gathered with the classical ruler.
- **Assumes** — the grid, the positions, ahead/behind.
- **Met at** — Ch 6, Ch 8, Ch 11 head. **Part 3 uses the fractional apparatus nowhere; what it
  uses is the bare direction of lean.**

## Ch 11 · The lean in detachment is not like the others

- **Asserts** — a lean in detachment **alters what the orientation does**, unlike the other two;
  the two faces are *one range with two directions*, not two conditions; a wing read alone will
  not say which end a person is at; what the range is made of belongs with the depth of
  fixation.
- **Assumes** — the two faces; leans.
- **Met at** — Ch 4, Ch 7 *Detachment's two faces*, Ch 11 head. *This is the minimal statement
  left behind on 09-02 when the full description moved to Ch 15; it is doing its job — it
  forwards rather than duplicating.*

## Ch 11 · What the leans do with what a person notices

- **Asserts** — three things easy to run together and only one chosen: declining to attend to
  what was seen, the looking stopping undecided, and nothing left to decline where looking has
  stopped; the leans make the difference — residual vigilance watches, the forward lean turns
  away from looking.
- **Assumes** — leans, and the two directions of detachment's lean.
- **Met at** — Ch 11 head, Ch 11 *Detachment's lean is not like the others*. *The minimal
  statement left behind on 09-02; the full one is Ch 15's* Disregarding, and not seeing at all.
- **RE-READ 09-07. The section was repaired on 09-07 and the repair simplified it.** All three
  cases now take the material in; what differs is what happens after. *Leaning forward toward
  enthusiasm, a person turns away from looking, and what goes unattended was taken in and never
  noticed at all.* **The heading was renamed with the retirement of `register`.**
- **RE-READ 09-12.** The second paragraph, which repeated Ch 15 word for word, is cut, and fault 37
  is discharged.

---

# PART 3 — inventoried whole

## Chapter 13: Where the Inner World Came From

### A part of the world that contains the rest

- **Asserts** — the physical realm does not refer to itself; brains came to carry a picture of
  their surroundings and act on the picture; the picture is itself physical and *nothing was
  added to the world*; **a part of the world now contained a version of the rest of it**.
- **Assumes** — that there is a physical realm and that it runs on cause and effect.
- **Met at** — Ch 3.

### The turn inward

- **Asserts** — the pressure that mattered became other animals; predicting one means carrying a
  picture of its picture; the shortcut is to consult one's own machinery; **the shortcut requires
  turning the picturing capacity inward**; what comes out contains itself.
- **Assumes** — the picturing capacity.
- **Met at** — Ch 13 *A part of the world that contains the rest*.

### The imaginary self

- **Asserts** — the self is what the tracking capacity produces turned on itself; it is not an
  error and not an object; **looking inward for it does not work**, because everything found
  there is arranged around it.
- **Assumes** — the turn inward.
- **Met at** — Ch 13 *The turn inward*.

### What self-reference does

- **Asserts** — self-reference is *the property that divides the two realms most sharply*; the
  physical admits none and the psychic does little else; **the line between the realms is that
  one admits self-reference and the other does not**; the folding is the looping described
  before.
- **Assumes** — Ch 3's account of the two realms, and specifically its looping.
- **Met at** — Ch 3. **The section says it is describing what Ch 3 described, and Ch 3's stated
  criterion is pushback against feedback, not self-reference. See fault 5.**

### A slant on everything rendered

- **Asserts** — a fixation is not one of the things pictured but **a slant on how everything is
  rendered**; hunting inward for it means looking through the thing looked for; it is **read off
  what it produces**, which is what makes a type description recognizable.
- **Assumes** — that a fixation is a standing thing; the picturing.
- **Met at** — Ch 1, Ch 7 head, Ch 13 *The turn inward*. **This claim is derived again from
  scratch at Ch 15 *The hinge*. Open finding, `[A]`'s. See fault 12.**

### Why detachment is the odd one

- **Asserts** — enthusiasm and caution are directed at things and detachment at one's own
  reaction; it is the picturing capacity turned back on its owner; **that is why detachment is
  the only orientation with two faces** — the turn can be made with something in view or as a
  reflex; **any way out runs through detachment**, being the only orientation that addresses the
  apparatus.
- **Assumes** — the three orientations and their competences; the turn inward.
- **Met at** — Ch 4, Ch 13 *The turn inward*. **The two faces are derived a second time at
  Ch 15 *Detachment's range*, from a different premise. Open, `[A]`'s. See fault 12.**

### Why there are scales

- **Asserts** — recursion makes nesting possible and **that is why there are scales**; without it
  a process would come in one size; *the scales have been in use since the cycle was introduced,
  and this is where they come from*.
- **Assumes** — that the book has been using scales.
- **Met at** — Ch 7 *What kind of thing this is*. **Nothing after this section uses it. See
  fault 9.**

### The same capacity, turned the other way

- **Asserts** — the same folding turned outward is language, which is why there are contemplative
  traditions; **the way out cannot be a shutting down of the folding**, since noticing a fixation
  is itself an act of it; there is no fault to correct; the self feels real because it was built
  as **a position** for a contest in which the other side holds one too.
- **Assumes** — the folding; a fixation as a slant on the picturing.
- **Met at** — Ch 13 *What the folding separates*, *A slant on everything rendered*. *The
  rules-out-quieting claim is picked up at Ch 17 *Rising* — `Calm is not the goal` — which is
  the payoff and is not a restatement.*

## Chapter 14: Underneath the Cycle

### (head)

- **Asserts** — the cycle has been used as an ordering and that is what fixes position and what a
  lean is measured against; **underneath the ordering are three passages and the passages are the
  fundamental thing**; the orientations are the names of the three ways a process comes to rest;
  this reverses the order of introduction deliberately.
- **Assumes** — the cycle as an ordering; leans measured against it; the three passages.
- **Met at** — Ch 7 head, Ch 7 *The smallest scale*, Ch 11 head.

### Two transformations and one arising

- **Asserts** — the three passages are not three of a kind; development and ending **transform**
  something, the same matter going in and coming out altered; the arising does not — **nothing
  crosses**, there is an ending and then a beginning with no third thing belonging to both; the
  odd passage leaves the odd orientation.
- **Assumes** — the three passages; that detachment is the odd orientation.
- **Met at** — Ch 7 *The smallest scale*, Ch 13 *Why detachment is the odd one*. **Its `Nothing
  crosses` sits ten lines above the coinage of `the crossing`. See fault 2.**

### What the odd one carries

- **Asserts** — a transformation hands the process on; **the arising hands nothing on**; therefore
  depth is an account of **one passage rather than of the round** — nothing in the two
  transformations changes where a person stands; **coins the crossing** — *the passage a process
  makes into detachment as it ends*.
- **Assumes** — the asymmetry of the three passages.
- **Met at** — Ch 14 *Two transformations and one arising*. **`The arising hands nothing on` is
  derived again at Ch 15 *What previous thoughts have laid down*. Open, `[A]`'s. See fault 12.**

### The phases and their names

- **Asserts** — every process runs a beginning, middle and end and the orientations are named
  after them; the phases take the orientations' names — **enthusiastic, cautious and detached
  phase**; a person's orientation is not a phase; **the letters keep the first job only — `A`,
  `B` and `Z` name where a person stands and are never used of a phase**.
- **Assumes** — the three passages; the orientations; the letters.
- **Met at** — Ch 4, Ch 7 *The smallest scale*. **The rule is broken by Ch 7 *The smallest
  scale*, which the reader met seven chapters earlier. See fault 1.**

## Chapter 15: The Fixations Themselves

### The range of detachment

- **Asserts** — for the other two a lean shades without altering; **detachment's competence is
  seeing and its characteristic failure is not-seeing**, opposite functions both belonging to it;
  the reason is that **its way of settling a conflict destroys its own competence**, quieting a
  disturbance meaning ceasing to attend; which face appears is set by the lean's direction; the
  blind side **holds a person in place** — an aversion meets an aversion to that aversion and the
  second wins, which is *being unable to bear knowing*; **because the realm loops the state does
  not decay** — turning away relieves a fresh anxiety and that is what holds the blindness, a
  feedback loop and not a habit; the two positions are **one quantity, not two conditions**; the
  0 position is **unselective receptivity**, not perfection and not a place a person sits;
  knowing little of a realm is **not by itself evidence of detachment** in it.
- **Assumes** — the three competences; leans and their directions; that the psychic realm loops;
  the two faces.
- **Met at** — Ch 3, Ch 4, Ch 11 head, Ch 11 *Detachment's lean is not like the others*.
  **This derives the two faces a second time, from the method-destroys-competence premise rather
  than from the turn inward. See fault 12.**
- **RE-READ 09-07 — the section was largely rewritten and its central contradiction is now
  derived rather than asserted.** *Taking in is at its widest where nothing is pulling, and
  noticing needs something pulling before it happens at all. A detached person wants nothing, so
  they take in the most of any of the three and notice the least.* The competence is taking in;
  the failure is not noticing; the 0 position is shortened and `unselective receptivity` is gone.
  **Two sentences did not move with it** — the lean paragraph's *sight that deepens as the lean
  moves further from caution* (fault 26) and *What is seen is the same at either end of the
  range* (fault 29), the second of which carries the section's load. **And the section asserts a
  place for a mechanism it does not supply:** *because the two orientations either side of
  detachment are what produce them* never says by what means. See the paragraph owed, below the
  faults.
- **RE-READ 09-12 — the section is the most changed in the book and three of the sentences the
  09-07 pass faulted are gone.** *A detached person wants nothing* is gone, `[A]` having ruled it
  false on 09-08: what a detached person wants is peace, and wanting peace does not make a person
  look for anything. *What is taken in is the same at either end of the range* is deleted, fault 43
  discharged, and *sight that deepens as the lean moves further from caution* is gone with it.
  **Four things are newly asserted here.** Pain is what raises a fear, and examining a want is one
  case of that rather than the whole account. The lean acts on how much of a fear is left when the
  fear reaches the enthusiasm end, and **does not hold the blindness in place** — the loop does.
  Burying is **not automatic**: it happens only where the fear is more than the person can bear.
  And **the spread** — anything that would bring the buried material to mind raises a fresh anxiety
  of its own, so the number of things a person turns away from grows over time.
- **Assumes, newly** — that a person can be more or less deeply caught, **met at Ch 4**; that there
  is buried material to be brought to mind, **met in this section**.

### Disregarding, and not seeing at all

- **Asserts** — three things easy to run together, only declining to attend being chosen; the
  leans make the difference; the three are not two kinds of thing — **what a person does about
  what registers runs from the involuntary to the chosen**, and a choice repeated sinks back; a
  fear taken one at a time is **thought through, given up on, blocked, or seen and left alone**;
  **only a blocked fear is a failure of seeing**.
- **Assumes** — leans and their two directions; that fears are the unit at issue.
- **Met at** — Ch 11 head, Ch 11 *What the leans do with what registers*. **That the unit is a
  fear rather than a want is not stated until *Why it does not turn over*, four sections later.
  See fault 3.**
- **RE-READ 09-12.** The last of the four cases is rewritten on `[A]`'s 09-12 rulings and the
  section now carries what discharges fault 13. **Ignoring and forgetting are one act**, at the two
  ends of the run from the chosen to the involuntary, and what brings the fear back is the problem
  it was about, still standing. The old separator — that an ignored fear stays intact and only the
  occasion is let pass — is gone from here and from every other site.

### The four fates

- **Asserts** — a fear reaching the crossing meets **one of four fates and only one leaves a
  person seeing less**; the four are **ordered by the crossing's own order** — the seeing end
  first, the end that turns away second; *worked through*, *given up on*, *ignored*, *blocked*;
  **two questions sort them** — in view, and disposed of — and one of the four combinations is
  empty because nothing can be disposed of that was never seen.
- **Assumes** — the crossing; that detachment has two ends and a process passes the seeing one
  first; that the unit is a fear.
- **Met at** — Ch 14 *What the odd one carries*, Ch 15 *Detachment's range*. **The unit again;
  see fault 3.** *That a process meets the seeing end first is asserted here and derived nowhere
  — it follows from the cycle's order, B → Z → A, but the book never joins the two. See
  fault 4.*
- **RE-READ 09-07.** *A process reaches detachment at the caution end, where fears are still
  seen, and leaves by the enthusiasm end* **already uses the naming `[A]` ruled 09-07** and is
  the one site in the book that does. The rest of the chapter names the ends `seeing` and
  `blind`; see fault 31.
- **RE-READ 09-12 — the four entries were restructured and the section gained a paragraph carrying
  a new term.** `[A]` asked whether the entries were a list, which caught two of the four at six
  sentences against two, and all four are comparable again. The `ignored` entry no longer says the
  fear and the want stay intact; what keeps it apart from `given up on` is now that the want was
  never given up, so the problem still stands. **`bodily tension` enters the book here**, in a
  paragraph after the four entries saying what each fate leaves behind: ignoring leaves nothing
  mental and leaves a bodily tension, a burial leaves bodily tension at full strength along with
  the fear itself. **The term is never called a fear, at this site or any other.**
- **Assumes, newly** — that a fear can be held in the body with nothing it is about. **NOT MET
  anywhere earlier; it is introduced here.** *Nothing later in book 2 uses it. See fault 47.*

### Blocking is not a decision

- **Asserts** — something deep enough to recognize a threat does, and keeps it from
  consciousness; **the keeping is reflexive, learned rather than designed**, reinforced each time
  by a second unconscious recognition; the reinforcement was laid down before words and
  **rational consciousness grew on top of it**; each new fear gets its own blocking, later layers
  being the ordinary case of a choice sinking; **a decision not to see is not what happens**.
- **Assumes** — the small version of the claim; the involuntary-to-chosen run.
- **Met at** — Ch 4, Ch 15 *Disregarding, and not seeing at all*. *Minimal then full, which is
  the ruled acceptable shape.*
- **RE-READ 09-12 — two paragraphs added and the second changes what the entry condition means.**
  The block stops the noticing and leaves the feeling untouched, so a burial is felt although
  nothing about it was noticed. And **the fear does not come from the content**: a feeling of fear
  arrives along with what a person takes in, the thing taken in becomes the thing feared because
  the feeling came with it, and the strength of the feeling is a fact about the person rather than
  about the thing. Without the second, a reader takes the unbearableness to be a property of the
  thing.

### Which fixation handles a fear

- **Asserts** — a fear lives in one realm, so **the fixation that handles it is that realm's, not
  the person's type**; enthusiasm and caution act **before** the crossing — enthusiasm cutting
  the examination short, caution settling upstream and failing by overload; **detachment acts at
  the crossing and its only instrument is time**; every process passes the whole range, so
  **dwelling, not presence, is what separates people**.
- **Assumes** — the crossing; the two realms and two fixations; leans in detachment.
- **Met at** — Ch 1, Ch 3, Ch 11 head, Ch 14 *What the odd one carries*. **Restated at Ch 17
  *What actually descends* as the two rate-setters; the later one is shorter and second, which is
  the ruled acceptable direction.**

### The four sketches

- **Asserts** — the same endeavor walked through under each fixation, loose by intention and
  exact in shape; **what arises differs by fixation** — impulse, attraction, mild disturbance,
  boredom; **each endeavor rests longest where its person is comfortable**; **the fixation is at
  work before the endeavor's own shape can account for it**; buried anxiety **accumulates** and
  goes on causing stress unseen.
- **Assumes** — the phases and their names; Z− and Z+ as lean positions; the two ends of
  detachment; the crossing.
- **Met at** — Ch 11 head, Ch 14 *The phases and their names*, Ch 15 *Detachment's range*.
- **RE-READ 09-12.** The closing sentence no longer says the origin of a fixation lies in a
  person's earliest history. **Two things bear on it — constitution, and what happened in a
  person's earliest years — and how much each contributes is not known.** That is `[A]`'s 08-29
  closure reaching a manuscript for the first time. The (Z+) sketch now leads with forgetting and
  makes the weighing the less common case.

### Two channels

- **Asserts** — a newborn's reactions are installed and contain no understanding; **two channels,
  wanting and hurting**, each with an innate twin in the parent; **two channels do not make three
  orientations and the third is not a third channel — the three are relations to the two**;
  differentiation cannot fail to happen; one comes to predominate, first by constitution then by
  what the surroundings answer; **it settles separately in each realm**.
- **Assumes** — the three orientations; two realms.
- **Met at** — Ch 3, Ch 4. **The third relation is glossed *quietly understand it*, and
  understanding is Ch 4's word for caution's competence, not detachment's. See fault 7.**
  **Whether an infant has a psychic realm yet, given Ch 13's account of where it comes from, is
  not addressed anywhere. See fault 10.**
- **RE-READ 09-12.** *First by constitution, and then by what the surroundings answer* is now
  *First by constitution, and then by how the people around the child respond*, on `[A]`'s
  instruction — he rejected the verb at the sketches and then ruled the inherited sentence changed
  with it.

### The hinge

- **Asserts** — **the hinge is anticipation**; behavior merely emitted begins to be deployed;
  **a fixation is a strategy that outlived its problem**; **the second reason the direct look
  fails** — a strategy laid down before understanding was never held as a belief, so there is no
  proposition to doubt; **it is recognized all the time** in what a person does; a fixation is
  known by what it produces.
- **Assumes** — the first reason the direct look fails.
- **Met at** — Ch 13 *A slant on everything rendered*. **Both reasons are full derivations two
  chapters apart. Open, `[A]`'s. See fault 12.**

### Habit carries it

- **Asserts** — **habit needs nothing believed to keep running**, so nothing is lost when belief
  changes; the same faculty carries an infant's strategy and a trained attainment; something
  registers, carries a feeling, pulls, and only then is anything chosen — **repeat a choice and
  it stops being made**; a fixation is **strategic in what it contains and automatic in how it
  runs**, which accounts for both earlier claims; **undoing one means restoring the original to
  the level where it can be declined**, not replacing it.
- **Assumes** — the involuntary-to-chosen run; that a fixation cannot be caught in the act; that
  it outlived its problem; **that a fixation can be brought into view at all**.
- **Met at** — Ch 15 *Disregarding, and not seeing at all*, *The hinge*, and — for the last —
  *The hinge*'s **it is recognized all the time**. *That dependency is why the fourth paragraph
  of* The hinge *is load-bearing and was not cut on 09-02.*

### Why it does not turn over

- **Asserts** — everything else in a person turns over, so why does one way of attending stay;
  **wanting and hurting are not symmetrical** — a desire has a completion condition and a fear
  has none, the feared thing failing to happen confirming the watching; **desire cycles because
  it can be answered and fear freezes because it cannot**; what accumulates is the unanswerable
  kind.
- **Assumes** — the two channels.
- **Met at** — Ch 15 *Two channels*. **This is what licenses `fear` as the unit throughout the
  chapter, and it arrives after four sections that already use it. See fault 3.**

### What previous thoughts have laid down

- **Asserts** — every thought that finishes **leaves something behind**, because the arising hands
  nothing on; the next thought arises out of it; **coins the mental deposits**; they set what
  arises and how it feels; a fixation strongly influences their content but **other influences
  are in them too**, which is why two people with the same pair are not the same person; **the
  hardening is the accumulation** — the residue is the habit, and a fixation is the shape the
  deposits have taken; this answers **why a fixation holds**, not what a person is.
- **Assumes** — the arising hands nothing on; that each thought arises conditioned by what came
  before.
- **Met at** — Ch 14 *What the odd one carries*, Ch 7 *The smallest scale*. **The
  hands-nothing-on premise is restated here in full rather than referred back to. Open,
  `[A]`'s. See fault 12.**

## Chapter 16: The Health Axis

### (head)

- **Asserts** — two things meet: the orientations already in hand, and **a new axis of health**;
  the scale is **Riso and Hudson's Levels**, borrowed as a measure of depth, their descriptions
  not reproduced; **what is used is the shape of the scale and the names of its rungs**; the
  scale is theirs and checkable, what moves a person along it is this book's.
- **Assumes** — orientations, type, lean.
- **Met at** — Ch 1, Ch 4, Ch 11 head.

### The nine rungs

- **Asserts** — the nine levels with their names and what holds at each, Level 4 being the entry
  to the descending slope.
- **Assumes** — nothing of book 2's; this is the borrowed scale.
- **Met at** — n/a. *Reported as Riso and Hudson's.*

### The rule beneath them

- **Asserts** — beneath the bands is a generating process, **the core dynamics**, running within
  the psychic realm: a fear answered by a desire, taken up as an attitude, issuing in behavior,
  breeding a fear of failing at it, answered one level down; seeded by the basic fear and ending
  when it is realized; **the rule fixes order and not motion**; it **conserves what is wanted**,
  each desire the previous one with a further layer of unawareness; and it **obscures itself**,
  the climb depending on what the descent degrades.
- **Assumes** — the psychic realm; that direction of movement around the cycle is set by other
  things.
- **Met at** — Ch 3, Ch 7 head. *The mid-descent return of an early desire as a late fear is
  stated here and used nowhere. Minor; noted under fault 9.*
- **RE-READ 09-12 — the section gained three things and one of them is faulted.** The store is
  now split by fate: **a blocked fear stays in the mental deposits, an ignored fear is not laid
  down at all, and what does get laid down is the ignoring itself**, which is why it comes more
  easily each time. That last is `[A]`'s correction of 09-12 and it is what gives the forgetting
  ruling its engine. **The descent is given two phases** — above the unhealthy band the chain does
  the work on its own, and from Level 7 down burial and blindness drive the fall — with the rungs
  table quoted as the evidence for where burial starts. **And the childhood guard**: panic can
  happen at any level and very early in life, so a person at any level may be carrying material
  buried in childhood. **The two-phase sentence is faulted; see fault 44.**

### The correspondence

- **Asserts** — read the Levels top down and the stance falls from calm clarity through
  insecurity through recklessness to blindness, which is **a walk through the orientations from
  Z− through B through A to Z+**; the four are **landmarks and not a rung-by-rung key**; **this
  is an observation**, and what is offered for why it holds is interpretation held to lower
  weight; it does **not** say a healthy person is detached — **what corresponds is how much is
  seen**.
- **Assumes** — the nine named positions; Z− and Z+; that type and health are independent.
- **Met at** — Ch 11 head, Ch 15 *Detachment's range*, and — for independence — Ch 16 *What the
  axis is toward*, which comes after. *Forward dependency, mild: the section asserts the
  independence and the argument for it arrives two sections later.*
- **RE-READ 09-12.** The ordering quantity is now named — **how much of what is there a person
  actually notices**, with both scales taking away from the same whole — and the claim is hedged,
  *what corresponds appears to be*, which is `[A]`'s wording. Fault 42 discharged. **The sentence
  that follows it says what goes unnoticed on the health axis is what blocking has taken, which is
  a fourth site naming blindness as the only mover. See fault 44.**

### The same nine names, two different shapes

- **Asserts** — the nine labels name two structures and they are not alike: **the orientations
  lie on a cycle that closes and the Levels on a bounded range that does not wrap**; positions on
  the cycle can be treated precisely and the Levels cannot; **that looseness holds of every
  statement made here about the Levels**.
- **Assumes** — the cycle's closure; the Levels.
- **Met at** — Ch 7 head, Ch 16 *The nine rungs*. **This is where the axis's granularity would be
  settled and it is not settled; see fault 11.**

### What the axis is toward

- **Asserts** — what a person meets at each level has an orientation's shape but **is not one of
  the two realms**, since otherwise health would be another name for type; **follow the fears
  down and they turn inward** until the world has almost gone; **the axis's object is oneself** —
  a third appearance of the same nine-position pattern, toward one's own fixation; the third is
  **a different sort of quantity** — not a stance freely taken but **a place arrived at**; so the
  **independence of depth and direction becomes a result rather than a rule**.
- **Assumes** — the nine positions; two realm-stances; that a person's type is fixed.
- **Met at** — Ch 1, Ch 6, Ch 11 head.

### The two ends, and what lies between them

- **Asserts** — **both ends of the axis are detachment**, one seeing and one blind, which is why
  they are mistaken for each other; what separates them is the range set out with the fixations;
  **the middle, the point of no lean, is nearly unoccupied**.
- **Assumes** — the range and its two directions; the 0 position.
- **Met at** — Ch 15 *Detachment's range*.
- **RE-READ 09-07.** *One seeing and one blind* is about the top and bottom of the health axis
  and **stands as written** — `[A]` ruled 09-07 that `blind` is kept for the health axis alone.
  What is retired is `blind` as a name for one end of the lean.

### Where a level change can happen

- **Asserts** — **a person's place does not drift**; it changes at **the crossing and nowhere
  else**, the rest of the round turning at constant depth; the crossing is **not always
  passable** — it opens only at the two extremes of what is registered, full sight being the
  climb and blacked out the fall; **partial registering holds a person where they are, and most
  of a life is spent there**.
- **Assumes** — the crossing; that the two transformations change nothing.
- **Met at** — Ch 14 *What the odd one carries*.
- **RE-READ 09-12.** `registered` is gone and the section reads **partial noticing** throughout.
  The claim is otherwise as entered, and it is one of the four sites at issue in fault 44: the
  crossing is where a level changes, and the two openings it names are full sight and blacked out,
  with nothing in between moving a person at all.

### Spoiled arrivals

- **Asserts** — the four fates named in brief; **a spoiled arrival is a quality of one arrival**
  and passes; **blindness accrues, happens at the crossing alone, and locks**; the two coincide
  at the arrival into detachment, which is why they are run together.
- **Assumes** — the four fates; that arrivals can be reached without living the passage.
- **Met at** — Ch 15 *The four fates*, Ch 7 *Backward*. *The brief naming is the minimal
  statement written on 09-02 and it is doing its job.*

### What a level is made of — NEW SECTION, entered 09-06

- **Asserts** — a level is **many crossings**, not one, and what stands at a level is all of
  them together; **their order is fixed**, what was laid down at one level having been laid
  down before anything at the level below it; **what is covered stays available as memory and
  not as footing** — *How a person functions is set by the level they are standing on, and a
  clear recollection of a higher one supplies nothing to act with*; **a climb is measured in
  years**, each level healed on its own and only the one being stood on available to work on.
- **Assumes** — that blindness accrues one crossing at a time; that a level below is reached
  by covering what is already there.
- **Met at** — Ch 16 *Spoiled arrivals*, Ch 16 *The rule beneath them*.
- **This section and *The same nine names* together discharge fault 11**, which had the axis
  used as a continuous quantity and never said to be one.
- **It also carries a claim nothing else in book 2 makes: that a higher level stays available
  as memory.** Nothing later uses it. Recorded, not raised — test (b) cannot tell a terminal
  passage from an abandoned one, which `[A]` ruled on 09-02.
- **RE-READ 09-12 — the section gained the shrinking paragraph and with it a second statement of
  what falling is.** Each burial puts one thing out of reach, anything leading to the buried thing
  goes out of reach with it, **so the part of a person's world that can still be approached shrinks
  with every burial, and a person falls as it shrinks.** That is `[A]`'s 09-12 reversal of the
  causal direction. **Nothing here says the shrinking outruns the burials, and no rate is given.**
- **Assumes, newly** — that anything leading toward buried material is turned away from, **met at
  Ch 15 *The range of detachment*, in the spread paragraph added the same day.**

## Chapter 17: Falling and Rising, and the Problem of Leverage

### What actually descends

- **Asserts** — one thing moves and it is **how much of a person's own condition registers**; it
  moves **in fractions of a rung, one crossing at a time**; **there is no event of collapsing**;
  **two independent rate-setters** — where the realm's fixation sits at the crossing, and how
  much the earlier part of the process left standing; so **the fall cannot be read off position
  alone**.
- **Assumes** — the crossing; the two rate-setters; **that a rung can be moved in fractions**.
- **Met at** — Ch 14 *What the odd one carries*, Ch 15 *Which fixation handles a fear*. **The
  fractional granularity of the axis is asserted here and stated nowhere else. See fault 11.**
- **RE-READ 09-07.** `registers` is gone from the section and it now reads *how much of their
  own condition they notice*. **The two rate-setters are where the separation of noticing from
  sight is already carried** — the fixation's position at the crossing, and what the earlier part
  of the process left standing — which is why fault 26 needs no new paragraph. The first
  rate-setter still names the ends `seeing`; see fault 31.
- **RE-READ 09-12 — there are now three rate-setters, not two, and the third is a different kind of
  thing.** What a person has learned about handling fear is the third, and the section says outright
  that it came from outside the person — from parents, teachers, friends, anybody close enough to
  be copied. The section holds it apart from the other two as a **skill** rather than a motive, and
  says a skill for handling fear has to be installed long before the moment it is needed. **That
  makes three places where something outside the person acts on the account; see fault 14.**
  **The section's opening claim — one thing moves on this axis, and it is how much of their own
  condition a person notices — is faulted; see fault 44.**

### What falling takes from capacity — NEW SECTION, entered 09-12

- **Asserts** — falling lowers how much a person can bear, **by adding stress**, and two things
  produce the stress: **what is not seen is not taken into account**, so things go wrong in ways a
  person had no way to expect; and **what is buried goes on producing anxiety**, felt without being
  understood, and an anxiety that cannot be traced cannot be addressed, so what it forces is a
  reaction that was not thought out. **How much a person can bear is what decides whether the next
  fear is faced or turned away from**, so the descent feeds itself.
- **Assumes** — that burial takes something from what a person sees; that what is buried goes on
  acting; **that how much a person can bear is what settles a fear's fate**.
- **Met at** — Ch 15 *The range of detachment*, for the capacity and for the loop. **This is the
  engine the brake in *Why this does not take everyone to the bottom* has to oppose, and the two
  sections are adjacent.**
- **It is the second of the two sections that say what the falling is**, the other being Ch 16
  *What a level is made of*. This one has the fall carried by how much a person can bear; that one
  has a person falling as their world shrinks. **Whether the two are one account said twice is not
  settled here.**

### The second way down, which is not blindness

- **Asserts** — a fear can be seen, admitted, and have **attention withheld**; nothing is hidden
  and what stops is the weighing; done enough it becomes **a general habit of not taking the
  question up**; **urgency is a slope, not a line**; the habit is not a way of avoiding the
  crossing but **a way of arriving at it with more to lose**.
- **Assumes** — ignoring as one of the four fates; the crossing.
- **Met at** — Ch 15 *The four fates*.
- **RE-READ 09-12.** *Done once, that is a fear left for later* is now *a problem left for later*,
  with the fear coming back when the problem is met again — the wording that follows from the 09-12
  ruling on what an ignored fear leaves. **The heading names its case by position**, which is on
  the standing style list and is owed to a later session.

### Why this does not take everyone to the bottom

- **Asserts** — the mechanism as set out has a hole and everyone should end at the bottom; they
  do not, which is a fact about the world; **consequences push back** and their trigger is not
  self-recognition, so blindness does not reach them; blindness **does not weaken the response,
  it selects where the response goes**; **what fails at the bottom is aim, not energy**; the
  routing has a mechanism — **blindness removes one term** of the comparison of immediate pains
  rather than corrupting it; the force **grows with the distance fallen**, which produces the
  middle-gathered population and the thin tail; and a **guess** — the comparison is first made in
  a rare moment of clarity, blindness being why it is rare and forgetting why it does not carry,
  with something accumulating across many such moments.
- **Assumes** — blindness as a loss of sight of one's own condition; the crossing.
- **Met at** — Ch 15 *Detachment's range*, Ch 16 *Where a level change can happen*.
  ~~**Forgetting, as a thing distinct from blindness, appears here and nowhere else in book 2.
  See fault 13.**~~ **DISCHARGED 09-12** — forgetting is gone from this section, and Ch 15
  *Disregarding, and not seeing at all* now defines it as one act with ignoring.
- **RE-READ 09-12 — the guess is now a full account and the entry's last line is out of date.**
  What was a guess about a rare moment of clarity is replaced by an argument from the taking in:
  blocking stops the noticing and never stops the taking in, so a person who turns away from their
  own condition has taken that condition in all the same, the turning away is taken in with it, and
  both are laid down. **A moment of clarity that gets disposed of is not lost.** That is also what
  the section offers for why leaving a rung takes many turns — the turns are the time it takes for
  enough to be laid down. **The brake is stated entirely in terms of buried material**, the
  comparison being between staying and the pain of unburying, **which is what fault 45 is about.**

### What reaches someone the consequences no longer reach

- **Asserts** — far down consequences stop being enough, because the comparison needs **a belief
  that anything could be different** and that belief is about the person's own condition; **what
  reaches them is another person, working by supplying sight** rather than force; help becomes
  necessary exactly as the first thing weakens; **the model says this happens and by what means
  and says nothing about what makes an intervener succeed**; and for anyone helping — **the route
  cannot be urged, only re-sighted**.
- **Assumes** — the routing-by-sight mechanism.
- **Met at** — Ch 17 *Why this does not take everyone to the floor*. **An outside footing arrives
  here and Ch 17 *The problem of leverage* says the account produces none. See fault 14.**

### Two things that cannot happen

- **Asserts** — **nobody watches themselves go down**, a drop being made blacked out; **nothing
  is understood in the middle of a collapse**, insight requiring the crossing open in the other
  direction.
- **Assumes** — the crossing's two openings.
- **Met at** — Ch 16 *Where a level change can happen*.

### The last stretch

- **Asserts** — the bottom rungs are **one goal reached three ways and the goal is not to know**
  — by action, by remaking the world, by exhaustion.
- **Assumes** — the bottom three levels' descriptions.
- **Met at** — Ch 16 *The nine rungs*.

### Rising

- **Asserts** — the climb uses **the same crossing in full sight**; the climb at any rung has the
  shape of the whole ascent — **withdraw along the arc into the quiet, see, and return** — and the
  gain arrives **on re-engagement**; **no growth technique differs in kind from climbing one
  rung**; the middle layers were laid down as ideas and can be met as ideas, **the oldest were
  never ideas at all** and the only handle is the felt quality; **calm is not the goal but the
  condition**; **the realms compete for attention**, so training one **unchecks** the other and
  the cut must be graded, thinnest at the top; the time goes into preparation and **the unit for
  checking it is the year**.
- **Assumes** — the crossing in full sight; that quieting is not itself the exit; **that the
  realms compete for a single attention**; **layers**; **that a person can put themselves at a
  position on the cycle**; **that something sets a person preparing**.
- **Met at** — Ch 16 *Where a level change can happen*, Ch 13 *The same capacity, turned the
  other way*, and — for the realms — **Ch 4's closing paragraph, one attention and two realms,
  so what goes to one is not going to the other. Fault 6 was discharged 09-06 and this line said
  otherwise until 09-12.** **`Layer` carries three unrelated senses by this point. See fault
  15.** **Putting oneself on the cycle is met nowhere. See fault 51.** **What sets a person
  preparing is met nowhere. See fault 52.**

### What is actually being undone

- **Asserts** — **acceptance does not do it**, leaving the arrangement intact; what undoes it is
  **conscious recognition of the buried fears, one at a time**, which works and is local;
  **better is to recognize the burying itself**, a single thing running under all of them, which
  **generalizes** and is the only object whose recognition would reach material not yet laid
  down.
- **Assumes** — burying as a single arrangement; that fears are buried at the crossing.
- **Met at** — Ch 15 *Blocking is not a decision*, Ch 16 *Spoiled arrivals*.

### The summit, and what counterfeits it

- **Asserts** — at the top there is **no residence**, the state being renewed rather than held;
  it **could not be held**, since a maintained state needs a habit of maintaining and that needs
  its own, with no floor; **habit does not become a different faculty at the top**; and a
  **counterfeit summit** — detachment trainable toward one realm alone, physical-realm
  indifference wearing the marks of the whole, with conscience lost as **a casualty of the
  training**.
- **Assumes** — habit's indifference to what it carries; that the realms can be trained
  separately.
- **Met at** — Ch 15 *Habit carries it*, Ch 17 *Rising*.

### The problem of leverage

- **Asserts** — everything a person does about their own condition **is done from the position
  that needs moving**; this is why resolving to be different produces a more determined version
  of the same person; going up means **giving up one's footing before there is anything else to
  stand on**; there are **two ways out — remove the need for a footing, or find one outside** —
  and **this account produces neither**; both have been found by people not building a model of
  personality.
- **Assumes** — the self as a position.
- **Met at** — Ch 13 *The same capacity, turned the other way*. **The flat `produces neither`
  against the intervener two sections earlier. See fault 14.**

---
# THE FOUR TESTS

Run over the inventory above, not over the text. Each fault is stated as a question. **This
session rules nothing, moves nothing and drafts nothing.**

## (a) Is everything a section assumes stated earlier?

**Fault 3 — DISCHARGED 09-06. Both pieces of prose are on the page.** Ch 14's *What the odd one
carries* now closes: *Four things can become of what it carries. It can be worked through, and
nothing is left over; given up on, leaving a regret in its place; ignored, kept whole while the
occasion passes, which is why it returns; or blocked, turned away from before it is seen at all.
Only the last leaves a person seeing less than before.* **It names the four and says only one
costs sight, and it does not carry the ordering** — which is what the ruling required of it.
*The second piece is fault 4 and is discharged there.*

**Fault 3 — RULED BY `[A]` 2026-09-02, and it is not the fault first reported.** *The
original entry read: the unit at the crossing is a fear and the reason it is a fear arrives
four sections after the work is done.* **That reading was wrong.** The four fates were made
inside the 08-26/08-27 descent work — the architecture file's own §0 says so — and were phrased
fear-only because falling was the subject, then sat in the Levels chapter until 09-02. `[A]`
identified the fear framing as an accident of that context. **So *Why it does not turn over*
never licensed the unit**; its job is to say why the residue accumulates, and its late position
is correct.

**WHAT `[A]` RULED.** The fates are kept and are NOT moved out of Ch 15, because *Blocked — it
survives hidden and stable* leans on the feedback loop *Detachment's range* supplies, and that
section must come first. **The fates are said TWICE — minimally in Ch 14, fully in Ch 15** —
which is the minimal-then-full shape ruled 09-02.

**TWO PIECES OF PROSE ARE OWED AND BELONG TO A DRAFTING SESSION.** `Job44` composed neither;
kind 12 does not draft.

1. **Ch 14 — a minimal statement of the four fates**, sited at the hole the chapter already
   leaves. *What the odd one carries* coins the crossing and says *what it was carrying has to
   go somewhere or nowhere*, and never says what the somewhere and the nowhere are. Two or three
   sentences naming the four and saying that only one costs a person any sight. **It must NOT
   carry the ordering** — that is what keeps it minimal and what keeps it inside what Ch 14 can
   support.
2. **Ch 15 — the join under the ordering, which is fault 4 and is NEW prose, not a restatement.**
   *The four fates* asserts *a fear meets the seeing end first and the end that turns away
   second* and derives it nowhere. The derivation is the cycle's order: a process arrives at
   detachment from caution's side and leaves toward enthusiasm's.

**NOT DECIDED and left to the drafting session's assignment:** whether the fates keep fear as
their headline case with the want named alongside, or drop to Ch 14's neutral cargo with Ch 17
supplying the fear. `[A]` was given both and ruled the arrangement, not the vocabulary.

*Superseded original entry, kept because the reasoning in it was measured and may be wanted:* *Disregarding, and not seeing at all*, *The four fates*,
*Blocking is not a decision* and *Which fixation handles a fear* all take a **fear** as the
thing that reaches the crossing and is disposed of. Why it should be a fear and not a want is
answered at *Why it does not turn over*: *desire cycles because it can be answered, and fear
freezes because it cannot. What accumulates in a person is the unanswerable kind.* A reader
meeting the four fates has no reason yet to think wants are excluded — and Ch 15's own sketches
have wants reaching the ending. **Question: does the asymmetry want a minimal statement early
in the chapter, with the full derivation staying where it is?**

**Fault 4 — DISCHARGED 09-06.** Ch 15's *The four fates* now derives it in its second paragraph:
*A process reaches detachment at the caution end, where fears are still seen, and leaves by the
enthusiasm end, where the turning away has gone furthest. So a fear that is disposed of at all is
disposed of while it is still in view, and what survives that reaches the end that turns away.*
**The join is made from the cycle's order, at the section that rests on it.** *Original entry
follows.*

**Fault 4 — that a process meets detachment's seeing end first is asserted and never derived.**
*The four fates* rests its whole ordering on it: *a fear meets the seeing end first and the end
that turns away second.* It follows from the cycle's order — a process arrives at detachment
from caution's side and leaves toward enthusiasm's — but **no section joins the two**, and the
cycle's order was last in view eight chapters earlier. **Question: is the one-sentence join
wanted, and where — at *The four fates* or at Ch 14's coinage of the crossing?**

**Fault 11 — DISCHARGED 09-06, at the ruled site and at one more.** *The same nine names, two
different shapes* now closes: *The rungs are also not units. What the axis measures varies
continuously, and a rung is a stretch of it wide enough to recognize. A person is usually between
rungs rather than on one, and moves by amounts far smaller than a rung.* **And the new section
*What a level is made of* supplies the other half of the 08-20 ruling** — *a level is not the work
of one crossing. It takes many of them.*

**Fault 11 — RULED BY `[A]` 2026-09-02: it goes in Ch 16's *The same nine names, two different
shapes*.** Prose owed to a drafting session; `[C]` composed none. That section is already the one
telling the reader what kind of object the scale is — that the Levels do not wrap and that no rung
takes a definite orientation — so the granularity is one more sentence in a section built for the
job. **Ch 16's head was the other candidate and was not taken**, since it would have mixed the
claim in with the borrowing.

*What it has to establish:* the rungs are **recognition markers on a continuous quantity, not
units of it** — ruled 2026-08-20, a level being many turns with the turn as the quantum of depth,
and never carried into book 2. Ch 17's *What actually descends* then gets what it already
assumes: *it moves in fractions of a rung, one crossing at a time*, *there is no event of
collapsing*, and *why leaving a rung takes so many turns*.

*Original entry follows.*

**Fault 11 — the health axis is used as a continuous quantity and is never said to be one.**
Ch 17 opens on *fractions of a rung* and *far smaller than a level*, and later on *why leaving a
rung takes so many turns*. The whole no-event-of-collapsing argument depends on it. Ch 16's
*The same nine names, two different shapes* is where this would be settled and settles something
else — that the Levels do not wrap and cannot be assigned orientations precisely. **Nowhere does
book 2 say that the Levels are recognition markers on a continuous axis rather than units of
it.** *That is ruled doctrine from 2026-08-20 — a level is many turns, the quantum of depth is
the turn, the levels are markers and not units — and the manuscript does not carry it.*
**Question: does that ruling want a home, and is Ch 16's *The same nine names* the place?**

*Mild, recorded and not raised as a fault:* Ch 16's *The correspondence* asserts that type and
health are independent and the argument for it arrives two sections later at *What the axis is
toward*. The assertion is defensible on its own, so this is an ordering note rather than a hole.

## (b) Is everything a section states used later, or does it stand alone?

**TEST (b) FOUND NOTHING WRONG IN BOOK 2. RULED BY `[A]` 2026-09-02.** All three of its findings
are **terminal passages, complete where they stand**, and the test could not tell them from
abandoned ones because it cannot see intent and Part 4 does not exist. *A later run should not
report these three again.* **The limit is the test's, not the book's.**

**DISCHARGED 09-06.** Ch 8 now opens: *The relational material is derived from the model and from
watching how these pairings actually go. It is practical advice rather than a further part of the
account, and it holds only so far as those two do.* **It went further than the ruling asked** —
`[A]` ruled on 09-04 that the material is derived from the model **and from observation**, and the
clause says both. *Original entry follows.*

**PROSE OWED, and it is the one thing this test did produce.** `[A]` ruled that **the reader
should be advised** that the relational chapters are practical advice derived from the theory.
One clause at Ch 8's opening, where the relational material begins and its scope can be set. It
matters because **Ch 9's position-by-position dynamics is a different kind of claim from Ch 7's
cycle and is not defended the same way**, and the reader needs to know that before reading it, not
after. `[C]` composed none.



**Fault 9 — CLOSED 2026-09-02: both are debts paid, complete when paid.** Ch 13's *Why there are scales* discharges what Ch 7 incurred; Ch 16's early-desire-returning-as-late-fear is a consequence noted where it falls out. *Original entry follows.*

**Fault 9 — two passages state something and nothing downstream touches it.**
Ch 13's *Why there are scales* derives the scales from recursion and closes *this is where they
come from* — a backward payment on Ch 7, with nothing after it using the result. Ch 16's *The
rule beneath them* states that *the desire of an early level returns near the bottom as the fear
that that very thing is now out of reach*, and nothing uses it. **Question: are these
back-payments that are meant to stand alone, or is one of them the start of something Part 4
picks up?**

**Fault 13 — DISCHARGED 09-06.** Ch 17's *Why this does not take everyone to the bottom* no longer
names forgetting anywhere. It now reads: *What is seen in it does not carry because it is a
recognition about the person's own condition, and that is precisely what blocking exists to
dispose of — so the arrangement that made the moment rare disposes of it once it has come. The
moments keep coming because the buried material keeps growing.* **Blindness, blocking and the
deposits do the three jobs, and forgetting is out of book 2.**

**Fault 13 — RULED BY `[A]` 2026-09-02, and NOT the way `[C]` proposed. Forgetting drops out of
the model.** *`[C]` reported it as: the blindness/forgetting distinction is real work and is
stated only inside a hedge, so it should stand somewhere firmer.* **`[A]` ruled that there is no
distinction to site.**

**`[A]`'s account.** What is blocked or ignored still goes into the deposits and accumulates
there, unseen — Ch 15 has every finished process leaving something behind, and the Z+ sketch says
it outright: *any anxiety that is dropped goes unattended and accumulates, and buried anxiety
continues to cause stress even though it is not consciously seen.* **So what accumulates across
clear moments is not insight but the buried material itself, and it works by pressure rather
than by memory.** Nothing has to survive the clear moment, because what is building is not the
seeing but the thing to be seen. That is why the moments become more frequent and why one of
them eventually lands.

**Three jobs, no new mechanism.** Blindness explains why the moment is rare. The blocking reflex
explains why what was seen does not carry — the insight is a recognition about the person's own
condition, which is exactly what blocking exists to dispose of. The deposits explain why the
moments keep coming.

**It also dissolves the objection `[C]` raised against the blocking reading.** Blocking
strengthening each time it runs — *reinforced each time it runs, by a second recognition, also
unconscious, that an unpleasant anxiety did not have to be felt* — is no longer a problem,
because the two run in opposite directions and are meant to: **the arrangement entrenches while
the material it holds down grows.** Same shape as *Detachment's range*, where an aversion meets
an aversion to that aversion.

**PROSE OWED to a drafting session** — Ch 17's *Why this does not take everyone to the floor*
stops naming forgetting and names the deposits instead. *`[C]` composed none. Two candidates
`[C]` raised and `[A]` did not take: forgetting as a separate mechanism, and inertness — a
retained but ineffective insight, on the ground that a habit was never a belief.*

**CLOSED 09-04 BY `[A]`, AGAINST THE READING BELOW: the deposits are NOT a second force.** They
supply the occasions and set the price; the flip still comes from consequences, outside. *A second
force would raise both terms of the comparison at once, and the middle-gathering and the thin tail
would stop following from it.* **So there is one pressure and the two do not have to be held
apart.** *Original entry follows.*

**LEFT OPEN, and it is new.** This gives the model a claim it has not made anywhere: **buried
material has a growing effect, and that effect is what eventually forces sight.** Ch 17 currently
has one force growing with distance fallen and locates it in **consequences, from outside**. This
is a **second pressure, from inside**, and the two have to be held apart. *Question: where is the
inside pressure stated, and does *Why this does not take everyone to the floor* now carry two
mechanisms rather than one?*

*Original entry follows.*

**Fault 13 — forgetting appears once and carries weight.** Ch 17's *Why this does not take
everyone to the floor* distinguishes it from blindness — *blindness is why the moment is rare,
and forgetting is why what was seen in it does not carry* — and it is **the only appearance of
forgetting as a mechanism in book 2**. The distinction is ruled doctrine and the manuscript
states it once, inside a passage explicitly held as a guess. **Question: should the
distinction stand somewhere firmer than the hedge it currently sits inside?**

**Fault 8 — CLOSED BY `[A]` 2026-09-02: the relational material is practical advice derived from the theory, is not picked up, and is not meant to be.** *A terminus by design, not a branch left hanging — `[C]` had described it as a fork in the book and it is not one.* **What survives is the advisory clause at Ch 8's opening, recorded at the head of test (b).** *Original entry follows.*

**Fault 8 — Part 3 uses nothing from Ch 8, Ch 9 or Ch 10.** Relational positions, relational
dynamics and the figure's own lines have no consumer in Part 3, and Part 3 assumes nothing from
them. This is reported because test (b) run over the book finds it, **not as a defect** — the
three chapters answer the classical Enneagram and Part 3 does not need them. **Question: is
that division intended, and is it stated to the reader anywhere?**

## (c) Is any claim derived twice from scratch?

**Fault 12 — three pairs, all already known and all `[A]`'s.** Recorded here so the inventory
carries them, not re-opened:

1. **A fixation cannot be found by looking for it and is known by what it produces** — derived
   in full at Ch 13 *A slant on everything rendered* from recursion, and in full at Ch 15
   *The hinge* from development. Two chapters apart.
2. **Detachment's two faces** — derived at Ch 13 *Why detachment is the odd one* from the
   inward turn, and at Ch 15 *Detachment's range* from the method that destroys the competence.
   `[A]` has been asked whether this is on purpose and has not answered.
3. **The arising hands nothing on** — full at Ch 14 *What the odd one carries*, full again at
   Ch 15 *What previous thoughts have laid down*. The dependency check of 09-02 found both
   load-bearing where they sit.

**Nothing new is found by this test.** *The inventory's advantage over a text search is that it
compares what sections claim rather than what words they use, and on that comparison the census
is complete at three.*

**One near-pair, and it is not a fault:** the sinking of a repeated choice below the level of
decision is stated at Ch 15 *Disregarding* (one sentence), at *Blocking is not a decision* (one
clause) and at *Habit carries it* (in full). That is minimal, minimal, then full — the ruled
acceptable shape — but three statements inside one chapter is dense. **Question: is the clause
in *Blocking is not a decision* wanted?**

## (d) Is anything assumed but never stated anywhere?

**Fault 6 — DISCHARGED 09-06.** Ch 4's closing paragraph now reads: *Attending is something a
person does, continuously, and not a place they stand. There is one attention and two realms, so
what goes to one is not going to the other. And what hardens, in a realm, is the attending.*
**Ch 17's graded cut and counterfeit summit now have a source eight chapters upstream.**

**Fault 6 — RULED BY `[A]` 2026-09-02: the principle goes in Ch 4.** Prose owed to a drafting
session; `[C]` composed none. The site is Ch 4's closing passage on attending — *attending is
something a person does, continuously, and not a place they stand. And what hardens, in a realm,
is the attending* — which is the sentence that can carry it, and which already has attention as
the quantity that varies. **Ch 3 was the other candidate and was not taken; Ch 12, reserved and
undrafted, would have absorbed it late.** Ch 4 puts it eight chapters before Ch 17 needs it and
in the chapter that owns attention.

*What it has to establish, for the two things Ch 17 builds on it:* that a person has two realms
and one attention, so attention given to one is withdrawn from the other. Ch 17's *Rising* then
gets its graded cut — training the realm you already live in **unchecks** the other — and its
counterfeit summit, detachment trained toward one realm alone.

*Original entry follows.*

**Fault 6 — that the two realms compete for one pool of attention.** Ch 17's *Rising* states it
flatly and builds two things on it: the graded cut in training, and the counterfeit summit
where one realm is trained and the other runs unchecked. **In the rest of book 2 the claim
exists only inside Ch 5's type sketches** — the Type 1's *the enthusiastic realm takes the
foreground*, the Type 6's *nothing competes for the foreground* — where it is an observation
about particular types and is never generalized. **Question: does the principle want stating in
its own right, and if so, in Ch 3 with the realms or in Ch 4 with the attending?**

**Fault 18 — DISCHARGED 09-06.** Ch 16's *The rule beneath them* now carries, between the chain
and the sentence about what the rule fixes: *A fear left unattended at a crossing stays in the
deposits, and it is from what has collected there that the fears at each level are drawn.* **One
sentence, at the ruled site.**

**Fault 18 — RULED BY `[A]` 2026-09-02 the same session it was found. The Levels' fears and the
crossing's fears were never related.** The Levels have fears of their own, one per rung, generated
by the chain at *The rule beneath them* — a fear answered by a desire, the desire becoming an
attitude, the behavior breeding *the fear of failing at the very thing* — and Ch 16 says what they
are about: *near the top they are about the world … partway down the fear first lands on the person
themselves.* The fears that MOVE a person on that scale are a different set: Ch 17's *each fear
turned away from before it arrives takes a little of the seeing with it*, which are Ch 15's crossing
fears, living in a realm and handled by that realm's fixation. **So the scale was defined by one set
of fears and moved by another, with nothing saying how they stand.**

**`[A]`'s answer, and it is better than the one `[C]` proposed.** `[C]` offered that the crossing
fear is the occasion and the Levels fear what it is really about — the realm fear underneath being
the fear of not being enough. **`[A]` ruled a different relation: there are two kinds of Levels fear,
the crossing fear stays UNSPECIFIED, and that is not a contradiction. The crossing fears that are
buried or ignored are what all accumulated deposited fear consists of, so the Levels' fears are drawn
from that stock.** *This does not require a crossing fear to be secretly about the self, which is
what `[C]`'s version required and what would have narrowed Ch 15's* a fear lives in one realm or the
other.

**It rests on machinery already in the book.** Ch 15's *What previous thoughts have laid down* has
the arising handing nothing on and the mental deposits being what the next thought arises out of; the
Z+ sketch has *any anxiety that is dropped goes unattended and accumulates, and buried anxiety
continues to cause stress even though it is not consciously seen*. So this is one more thing the
deposits account for and needs no new mechanism.

**Checked against the two things it could have broken, and it breaks neither.** It does not disturb
the independence of depth and type, saying nothing about which realm a fear came from. And it does
not make the Levels' chain depend on the crossing — the chain still generates its own fears rung by
rung; what this supplies is where the material comes from, not what orders it.

**PROSE OWED, and it belongs to a drafting session.** One sentence, sited in Ch 16's *The rule
beneath them*, after the chain is described and before *the rule fixes which fears and desires sit at
which levels* — the one place where the reader holds both the crossing and the Levels and has just
been told the fears are the Levels' own.

**Fault 10 — CLOSED BY `[A]` 2026-09-02, the session it was found. It was not a fault.**
*`[C]` reported it as: Ch 15's* Two channels *has a psychic-realm fixation settling in infancy,
while Ch 13 has the psychic realm constituted by self-reference arriving with the turn inward,
and the book never says when in a life that capacity comes in.*

**`[A]`'s answer: the two realms, with their different principles of operation, are what every
person encounters and therefore what they learn.** A realm is not a capacity a person develops.
It is a part of the world — one that pushes back, one that loops — and an infant meets both by
being in the world. So *Two channels* needs nothing from Ch 13 and there was never a
precondition to meet. **Ch 13 is about how the psychic realm as a domain came to exist, a
question about the species, not about when an individual acquires it.**

**THE WORDING IS DONE, 09-04.** The section is renamed *What self-reference does* and now reads:
*This is also the property that divides the two realms most sharply, and it is what the earlier
account of them was describing.* **Self-reference is the cause and not the criterion, and Ch 13 no
longer claims to replace Ch 3.** *Original entry follows.*

**What it leaves is a wording matter in one section, and it is the same one as fault 5.** Ch 13's
*What the folding separates* says the line between the realms **is** self-reference. Under `[A]`'s
reading the line between them is the fact about the two domains that a person meets — pushback
against compounding — and **self-reference is why** the psychic one compounds instead of
correcting. That is the stronger claim and it also disposes of fault 5, where Ch 13 claims to be
restating Ch 3's division while replacing it: the two are not rivals once self-reference is the
cause rather than the criterion.

## FOUND 2026-09-06 by `Job53` — five faults in material written since the build

**Fault 23 — RULED BY `[A]` 2026-09-06: what a person is caught in is the FIXATION, not the
orientation.** The two sites saying *caught in the orientation* are wrong and become either
*caught in the fixation in that realm* or plain *caught in the fixation*. **PROSE OWED at Ch 4's
tolerance rule and at Ch 15's *The range of detachment*.**

**AND HE RECORDED A STANDING DECISION WITH IT, WHICH A LATER SESSION MUST NOT UNDO AS A REPAIR:**
Part 1 speaks of orientations and Part 3 speaks of fixations in orientations. **That inconsistency
was weighed and accepted.** It is not a fault and is not to be raised again.

**WHICH OF THE TWO FORMS IS TAKEN DECIDES FAULT 20, AND `[A]` HAS NOT YET CHOSEN.** *Caught in the
fixation in that realm* keeps caughtness per realm, and a person then has two of it while the axis
is one — the obstacle recorded under fault 20 survives. *Caught in the fixations*, plural and not
realm-indexed, makes caughtness one quantity per person, and the obstacle goes.

**THE RECOMMENDATION BELOW IS WITHDRAWN. `[A]` GAVE A MECHANISM 2026-09-06 THAT DECIDES IT THE
OTHER WAY, AND THE REALM INDEX STAYS.** *fixations tend to occur in pairs because stress is realm
neutral. blindness is associated with realm. capacity is probably a combination of both and
blindness is an important part.* **So capacity has a realm-neutral input and a realm-specific one,
and the sentence in Ch 15 is right to name the realm.** The wording ruling stands — `fixation`,
not `orientation` — and the realm index stays with it.

**AND IT RESTORES HIS FIRST ANSWER TO FAULT 20 WITH A REASON UNDER IT.** He said *close if not
identical*, withdrew it as a hedge, then held identity provisionally. **The mechanism gives the
first answer its grounds: the realm-neutral input couples the two fixations, which is why they
pair; the realm-specific one keeps them from coinciding.** Close, and not identical, and now for a
stated reason rather than as a hedge.

**SETTLED BY `[A]` 2026-09-06: ONE TERM, NOT TWO. CAPACITY IS SET BY STRESS, AND BLINDNESS ACTS
ON CAPACITY THROUGH STRESS.** *stress reduces capacity by reducing the amount of pain one can
tolerate... blindness through contributing to stress... i would accept that definition of stress.*
**So `stress` in book 2 now means whatever reduces how much pain a person can tolerate**, and that
is a definition the book does not currently give anywhere.

**How blindness feeds it, in his words:** what is not seen is not taken into account; and the
anxiety that goes with blindness forces an unthought-out reaction that can be destructive.

**And the descent is defined by it:** *inability to process fear moves a person down the levels —
i would say that's capacity.*

**WHAT THIS PRODUCES, AND IT IS NEW TO BOOK 2: A DESCENT THAT FEEDS ITSELF.** A fear beyond
capacity is turned away from; turning away accrues blindness; blindness raises stress; stress
lowers capacity; the next fear is likelier to be beyond it. **Book 2 has no self-feeding term
today.** Ch 17's *Why this does not take everyone to the bottom* has one growing quantity — the
buried material, which supplies more occasions — and it only recurs. This one accelerates.
**`[A]` ANSWERED 2026-09-06: THE BRAKE SCALES TOO.** *it's possible that the pain of consequences
can match the pain that is causing them without limit.* **Worse functioning draws a worse response,
so consequences grow with the descent and the brake is not a fixed quantity.** The account holds
without a ceiling on either side.

**`[A]` NAMED AN EXCEPTION 2026-09-06: the pain of staying can be lowered directly rather than
faced.** **The brake works by consequences raising the pain of staying until facing looks better,
so anything that lowers that pain without raising capacity or reducing blindness defeats it.**

**The two cases he named are not the same kind of thing in the model.** **Numbing leaves the
comparison standing and falsifies one of its terms.** The descent continues with its only brake
disabled, so the model predicts acceleration — which is what it should predict. **And it needs no
new term: it is the same move as blocking, which also disposes of pain without facing what causes
it, done by other means.** *That siting is a recommendation of this session and not a ruling.*
**The second case removes the comparison rather than answering it, so it falls outside the account
rather than being an exception within it.**

**A CARE JUDGEMENT RECORDED WITH THE DOCTRINE, FOR WHOEVER DRAFTS THIS.** People in difficulty
read books of this kind. **Written as a move in a comparison it would read very badly.** This
session recommends the book state that the brake can be defeated by lowering the pain of staying
rather than facing it, and not enumerate the ways.

**AND IT UNCOVERS THE REAL GAP, WHICH IS NOT THE BRAKE.** Consequences act on **how painful it is
to stay**. Blindness acts on **capacity**. The two act on different quantities and meet only where
the turning-away is decided — **and Ch 17 decides it two ways, in two sections, and never says
they are one thing.**

**Version one, *Why this does not take everyone to the bottom*: a comparison.** *Which is more
painful — staying as they are, or facing the pain of unburying.* **Consequences enter here**, by
raising the first term.

**Version two, *What reaches someone the consequences no longer reach*: a threshold.** *A fear gets
turned away from when it is more painful than the person can bear at that moment.* **Consequences
do not enter here at all** — the test is one pain against a capacity, and the alternative is not
in it.

**`[A]` JOINED THEM 2026-09-06, AND THE JOIN RUNS THROUGH SIGHT.** *capacity to function in the
facing of pain certainly depends on understanding how much external pain failing will cause.* **So
what staying costs enters the decision only as far as the person understands it.** The threshold
and the comparison are then one thing: **capacity is how much facing has to hurt before staying
looks worse, and how bad staying looks is limited by sight.**

**This is why the earlier objection dissolves.** Capacity looked as though it had to be either the
person's alone, leaving no brake, or partly their circumstances, contradicting stress as its
source. **It is neither: it is their circumstances as far as they can see them, and how far they
can see is theirs.**

**IT ALSO DERIVES A SENTENCE THE BOOK ALREADY ASSERTS.** Ch 17: *an intervener supplies what
consequences no longer can.* **Consequences stop reaching a person because the person can no longer
see them**, and an intervener supplies the sight. That sentence has been standing on nothing.

**AND IT MAKES THE BRAKE FAIL IN EXACTLY THE RIGHT PLACE.** Blindness both compounds the descent
and shrinks the consequence term, **so the brake weakens precisely as the descent deepens** — one
quantity working both sides, rather than two quantities that had to be balanced against each other.

**`[A]` ASKED WHICH CAPACITY IS MEANT AND DID NOT SETTLE IT.** *there is capacity to function and
capacity to function in the facing of pain. i don't know which we mean. maybe they are the same.*
**THIS SESSION'S ANSWER: two, sharing their slow input.** Capacity to function is the standing one
and the book has it — *How a person functions is set by the level they are standing on.* Capacity
to face pain is the momentary one and is what decides the fork; Ch 17 already gives it a fast input
the other does not have — *a person who is calm bears more than the same person alarmed.* **Same
slow input, which is the level; one extra fast input.** *Recommendation, not a ruling.*

**PROSE OWED: the requirement that consequences must be understood to count.** `[A]` called it new
and obvious in retrospect. **It is stated nowhere in book 2.**

*The two versions the join reconciles follow.*

**`[A]`'s settlement of capacity requires version two. His answer about the brake requires version
one.** *They can very likely be joined — what a person can bear may be a way of saying how much
facing must hurt before staying looks better — but book 2 asserts both and joins them nowhere.*
**PUT TO `[A]` AS THE ONE THING THIS THREAD NOW TURNS ON.**

**A COLLISION TO CHECK BEFORE THE DEFINITION IS WRITTEN.** `stress` already occurs in book 2 in
the classical sense — Ch 10's *the directions a person is said to move under growth and under
stress*, which reports the older system's vocabulary and means the disintegration direction. **Under
the new definition the book both defines `stress` as a quantity and uses it as the name of a
direction.** *Ch 7's two uses read consistently with the new definition and need no repair.*

**THE THREE CLAIMS BELOW WERE RECORDED BEFORE THE SETTLEMENT ABOVE. ① AND ② STAND AS WRITTEN;
③ IS SUPERSEDED — blindness is not a separate input.**

**THREE CLAIMS THE BOOK DOES NOT YET MAKE, ALL HELD TENTATIVELY — he said `probably`.**
**① Stress is realm-neutral.** `stress` occurs three times in book 2 — Ch 7's A to Z, Ch 7's two
faces, Ch 17's intervener — and none of them says this. **② A person's two fixations tend to sit
at similar depths.** Stated nowhere. **③ Blindness is an important part of what sets capacity.**
Ch 15's sentence currently gives that job to caughtness alone, and Ch 17's intervener gives it to
stress alone; neither mentions blindness. **PROSE OWED for all three, and doctrine wanted before
prose, since `probably` is not a ruling.**

**THE SUPERSEDED RECOMMENDATION FOLLOWS.**

**THIS SESSION RECOMMENDS THE PLURAL, NOT REALM-INDEXED, EVERYWHERE.** It is already what sixteen
of the eighteen sites say, so it is two edits rather than sixteen. It is what the axis tracks —
the chain of fears and desires the TYPE runs on, the type being the pair. And it leaves the
identity `[A]` is holding provisionally with nothing standing against it.

*Original entry follows.*

**Fault 23 — the one quantity fault 20 is about is named two ways, with two different objects,
and the split is clean.** **Sixteen sites say `caught in the fixations`** — every closing block in
Ch 5 that has one. **Two sites say `caught in the orientation`** — Ch 4's tolerance rule, *how
deeply caught they are in the orientation*, and Ch 15's *The range of detachment*, *how deeply
caught the person is in the orientation they hold in that realm*. **Those eighteen are the whole
of it in book 2.** *The two sites that break the count of eighteen are the One's psychic realm and
the Eight's physical, which say `does not become visible at any depth` instead — the two sites of
fault 21.*

**A fixation and an orientation are not the same thing in this model, so this is more than a
wording split.** An orientation is one of three ways of attending, held one to a realm. A
fixation is the chain of fears and desires a type runs on. **So `caught in the fixations`, plural,
is caught in the pair, which is the type; `caught in the orientation` is caught in one of the two,
in one realm.**

**This bears directly on fault 20 and may decide it.** The axis tracks *how a person handles the
chain of fears and desires their type runs on*, met as their own case — which is what `caught in
the fixations` says and not what `caught in the orientation` says. **So the phrase used in sixteen
places is the axis-like one and the phrase used in two is the realm-indexed one**, and the
obstacle recorded under fault 20 — that caughtness is per realm and the axis is not — rests
entirely on those two sites.

**Question, and it is the same question as fault 20 reached from the words rather than the
claims: is the thing a person is caught in the orientation, the fixation, or both, and does the
answer differ by realm?**

**A DEPENDENCY BETWEEN THE 09-06 BRIEF AND THE FAULT 19 REPAIR, STATED PRECISELY.** *The brief is
about the subjective experience of seeing in a detached realm and most of it is doctrine this kind
does not touch. One subsection of it lands on drafted text.*

**Six sketch blocks describe a detached realm the same way** — the Two's and the Four's physical,
the Five's and the Seven's psychic, and both of the Nine's. Each says the sight is available and
specific, that attention is in the other realm, that **the sight goes unused**, and that a less
caught person **uses what they can see**. The Two's names the content outright: *what a situation
actually requires — the errand, the repair, the thing that has to be arranged.*

**The brief's account of Z would make that wrong in a particular way.** If the taking-in is whole
and immediate and **the attending is what picks anything out of it, and is work**, then nothing in
what arrives is anything in particular until attention goes to it. **There is then no formed sight
lying idle.** There is a whole taken in and a picking-out not done. *The sight goes unused* becomes
*the attending has not happened*, which is a different claim with a different remedy.

**AND IT REACHES EXACTLY FOUR OF THE TWELVE INSTANCES OWED AT Ch 10** — the four of the
detachment-to-enthusiasm step, drawn from the Two's and the Four's physical realms and the Five's
and the Seven's psychic. **Those four say the capacity that opens is acting on what is seen. Under
the brief it might be the attending instead, or the attending first and the acting second.**

**RESOLVED 2026-09-06 WITHOUT RULING THE BRIEF'S FIRST QUESTION, AND THE ORDER IS NO LONGER
FORCED.** `[A]`: *experientially, it's the second. objectively, i don't know.* **The second answer
is taken for the prose on a ground that does not depend on his experience: a fixation is a standing
preference about where attention is directed, which is what the second answer names, and the first
answer requires a formed sight held complete and unacted on — a thing the model has nowhere to
keep.**

**What the four instances say:** the attending is what opens up, and the acting follows from it.
**What the six sketch blocks say:** what would be picked out if the attending happened, rather than
what is seen and going unused. **A clause each, not a rewrite** — the named content stays, since
under the second answer it is what attending would find and not what is sitting there.

**THE BRIEF'S FIRST QUESTION STAYS OPEN**, and the fault 19 repair no longer waits on it.

**Fault 24 — a tool carried from one realm into the other is drafted at four sketch sites and
stated as a claim nowhere.** *Raised by `DOCTRINE-BRIEF-two-stages-of-seeing-20260906.md` §6,
which named three sites; a fourth was found on checking, and all four were located by content in
`BOOK2-20260906b.md` rather than taken from the brief's stale numbers.*

**The Eight** — *it is the unwatched realm that supplies the principles which invade the other
one*, and the fortress working exactly as designed in the wrong realm. **The One** — the measure
carried into the physical realm, giving a standard nothing can meet. **The Four** — *the mode they
bring across is understanding*, so physical action turns interpretive. **The Two** — *The trouble
starts where the two realms are confused*, the psychic realm's ceilinglessness applied where it
does not belong.

**Two of the four call the crossing a fault and one calls it a gift**, and nothing anywhere says
what decides which. **There is no general statement of the mechanism at all.**

**THIS IS THE THIRD TIME Ch 5 HAS DONE THE SAME THING, AND THAT IS THE FINDING WORTH MORE THAN THE
FAULT.** The foreground claim lived in two sketches until it went to Ch 4 on 09-06. The
never-visible-at-any-depth claim lived in two sketches until `[A]` ruled it an exaggeration on
09-06. This is the third. **The sketches are where general claims get made, because writing nine
particular cases is where a general mechanism first becomes visible — and nothing in the drafting
route sends them anywhere else.**

## The four found alongside it



*All four are in prose written on 09-04, 09-05 and 09-06, and all four are stated as questions.
This kind does not rule and does not draft.*

**Fault 20 — `[A]` 2026-09-06, and he revised it the same hour. HELD PROVISIONALLY AS THE SAME
QUANTITY, NOT RULED.** He first said *close if not identical*, then withdrew that as a hedge:
*it's unclear to me — i was hedging. i am willing to say they are the same and possibly change my
mind later.* **So the working position is identity, held loosely and open to reversal.**

**AN OBSTACLE TO IDENTITY, MEASURED IN THE TEXT AND PUT TO HIM, NOT YET ANSWERED: caughtness is
per realm and the axis is not.** Ch 15 makes caughtness realm-indexed — *how deeply caught the
person is in the orientation they hold in that realm* — so a person can be deeply caught in one
realm and less so in the other. Ch 16 makes the axis single and not realm-indexed: *That is the
axis's object: not a realm but oneself*, and what it tracks is how a person handles *the chain of
fears and desires their type runs on*, the type being the pair. **Under identity a person would
have two axis positions, or would have to be equally caught in both realms.** Neither is in the
book.

*The rest of this entry was written under the first form of the ruling and is left as written.*

**The two are a third loose correspondence, and the book has never said so.** How deeply caught a
person is in an orientation and where they stand on the health axis run closely together and are
not one quantity.

*What the ruling settles.* Ch 4 and Ch 5 are not using the health axis early, so the sketches'
*less caught* is not a claim about health wearing the clothes of a claim about type. And Ch 17 is
allowed its crossing from one to the other, since close is what it needs.

*What it leaves.* **The book has two quantities that both measure how far into a fixation a person
is, and says nothing about how they stand.** A reader meets *how deeply caught* at Ch 4, meets the
axis at Ch 16, and is never told they are neighbours — or that they are two.

**PROSE OWED, and both the wording and the site are a later session's.** *What it has to
establish:* the two are closely related and are not the same quantity, at the same strength as the
book's other two loose correspondences — Ch 16's between the Levels and the orientations, *near
enough to be worth having, not close enough to count on*, and Ch 17's between the two stacks,
which is stated in those very terms. **This is the third of them, which is itself worth a
session's attention: three times the book has found two orderings that run together and refuse to
coincide.**

*Original entry follows.*

**Fault 20 — how deeply caught a person is, and where they sit on the health axis, are never
related, and a great deal now rests on the first.** Ch 4 sets a person's tolerance by it: *How
much of it a person can bear depends on how deeply caught they are in the orientation.* Ch 15's
*The range of detachment* says the same of the capacity that gives way at the crossing: *What
sets that capacity is how deeply caught the person is in the orientation they hold in that
realm.* **Those two sites are the whole of it in book 2** — the phrase occurs nowhere else — and
what stands on them is large: **all nine of Ch 5's closing qualifications**, and Ch 17's *A person
further down is harder to help*, which reaches the same quantity from the axis end.

**The axis is defined as something that sounds like it.** Ch 16's *What the axis is toward* has a
person's place on it as *not an orientation freely taken but a place arrived at, the settled
result of how the fixation has been handled over a long time*, and the axis's object as *not a
realm but oneself*. **Nothing says whether being deeply caught is being low on that axis.**

*Why it matters either way.* **If they are the same**, Ch 4 and Ch 5 are using the health axis
twelve chapters before it exists, and the sketches' *less caught* becomes a claim about health
that reads as a claim about type — in a chapter whose job is to derive the types. **If they are
different**, book 2 has two quantities that both measure how far into a fixation a person is and
never distinguishes them, and Ch 17 crosses from one to the other in a single paragraph.
**Question: is how deeply caught a person is the same thing as where they stand on the health
axis?**

**Fault 19 — SETTLED WITH `[A]` 2026-09-06. The repair is a strip and two sitings, and none of it
is written yet.**

**1. Ch 5 — strip the framing phrase from all nine closing blocks.** The phrase is *the step past
X is Y*; the capacity it introduces stays, attached to the person instead of to a place on the
loop. The One's becomes *A One less caught in the fixations weighs how hard a thing will actually
be before deciding what ought to be done about it.* **No claim is lost, and the sketches stop
using an ordering they do not have.** The word `engagement` goes out with the frames, which
settles the second name for `doing`.

**2. Ch 7 — one sentence, next to the line already there.** *Forward* closes on what the step
requires being what such a person habitually resists; the added sentence says that resistance is a
matter of degree. Minimal here, full at the figure chapter — the shape `[A]` has ruled acceptable
before.

**3. Ch 10 — the full statement, sited under *The relations the figure does not draw*.** That
passage already asserts *as that grip loosens they come to resemble those types more closely* and
gives the resemblance no content, then says the claim is set down to be tested. **The twelve
instances are what it lacks.** Two sentences of general form — a fixation loosening makes some of
the orientation ahead available in that realm, and the type holding that orientation in that realm
is the type the classical arrow points at — then **twelve instances, each of the six mixed types in
each of its two realms**, in the sketches' own words, **naming the type ahead**.

*Why all twelve rather than six.* Each mixed type appears twice in two different steps, because its
two realms hold different orientations. **That is what shows the move to belong to the orientation
rather than to the type**, which six instances could not show. It also disposes of a realm-choice
constraint that six would have carried: of the twelve, six coincide with a hexad arrow and six land
on the diagonal, so any six-instance selection would have had a safe half and an unsafe half for a
later session to break silently.

*`[A]` proposed announcing the passage as an update of the sketches, and withdrew it.* An
announcement of that kind is a sentence about the text's own arrangement, which his own standing
rule excludes, and it is not accurate — the sketches keep every claim they make. **The two
sentences of general form do the work an announcement would have done.**

*Original entry follows.*

**Fault 19 — Ch 5's nine sketches turn on the cycle's ordering, and the ordering is first stated
at Ch 7.** Every one of the nine closing blocks reaches its point by naming the orientation one
step on: *the step past enthusiasm is caution*, *the step past caution is seeing*, *the step past
detachment is engagement*. Ch 4 gives the three orientations and no order among them; Ch 1 gives
none.

**Ch 6 makes it sharp rather than mild, because it says so itself.** The grid chapter, which comes
after the sketches, tells the reader the order has not been earned yet: *The rows and columns run
enthusiastic, cautious, detached because that is the order the orientations were introduced in,
and nothing so far has turned on that.* And: *Until the reason for it is given, a step from one
cell to its neighbor is only a step, with no direction to it.* **Something has turned on it — nine
times, one chapter earlier.** The Nine's is the strongest case, *the step past detachment is
engagement* being the wrap-around, which is the part of the ordering Ch 7 works hardest to earn.
**Question: does the ordering want a bare statement in Ch 4, or do the sketches want their closing
blocks moved to where the ordering is available?**

*Recorded with it, and it is a word rather than a claim:* **the Nine's block names the step past
detachment `engagement`**, where Ch 4's name for that orientation's competence is **doing**. The
other eight blocks use Ch 4's words.

**Fault 21 — RULED BY `[A]` 2026-09-06: the two sentences are an exaggeration and both are
wrong as written.** *the b realm is the quiet realm — it's noticed less and often functions
without being noticed. but it's accessible.* **So there is no realm that stays shut at any depth,
and nothing in Part 3 is limited by this.**

**PROSE OWED, and it is a replacement rather than a strike.** What goes in is that the quiet realm
is noticed less and often runs without being noticed, and that it is reachable. Where it goes is a
later session's; **the two sites are the two sketches, but the fact is one fact and belongs in one
place.**

**The two sites are the two mixed types whose pair is enthusiasm and caution** — the One,
enthusiastic physically and cautious psychically, and the Eight, the same two the other way round.
Those are the only two, so the claim did not appear twice by accident and its replacement should
not be written twice either.

**THIS BLOCKS PART OF THE FAULT 19 REPAIR AND MUST BE DONE FIRST.** The twelve instances owed at
Ch 10 include the One's psychic realm and the Eight's physical realm, both stepping from caution to
detachment. **Those are precisely the two realms these sentences declare shut.** Until they are
replaced, two of the twelve have no capacity to state and the sketches contradict the passage that
cites them.

*Original entry follows.*

**Fault 21 — that a realm stays invisible however healthy a person gets is stated inside two
sketches and nowhere else.** The One's: *They do not become visible at any depth, because a One
judges everything by them and so never has occasion to judge them.* The Eight's: *It does not
become visible at any depth, because an Eight approaches everything already guarded, and so has
nothing to compare it against.* **This is a limit on what the whole of Part 3 offers**, since
Part 3's climb is recognition and this says recognition of one's own quiet realm is unavailable
to two of the nine at any height. **It is the same shape as fault 6 before it was discharged** —
a general claim living inside particular sketches — and its reason differs between the two sites,
which is what makes it look like a general claim rather than two local observations. **Question:
is this a general claim about mixed types, and if so where is it stated in its own right?**

**Fault 22 — MARKED DOWN 2026-09-06 BY THE SESSION THAT RAISED IT, AND `[A]` AGREED. The
sentence stays.** He asked whether it could be dropped; on reading the paragraph whole rather than
its last sentence, the fault is smaller than it was reported and the deletion costs more than it.

*Why it is smaller.* **Found by people who were not building a model** is about how a way out gets
taken in a life, not about who first described it. **The account producing the second does not
compete with that.** What is left is that the sentence's reassurance has to be inferred: it never
says that this is why the limit is not the end.

*Why dropping it costs.* **It is the last sentence of book 2 as the book currently stands**, Part 4
being undrafted, and without it the book ends on *what the account does not give is a way to do it
alone*. **It is also the only place in book 2 that says anyone has actually got out** — the ascent
chapter gives the mechanism everywhere and reports the fact nowhere else.

**If it is strengthened later it wants a clause, not a deletion.** *Original entry follows.*

**Fault 22 — the closing paragraph now produces one of its two ways out and still describes both
as found elsewhere.** *The problem of leverage* reads: *There are two ways out of a problem of
that kind: remove the need for a footing, or find one outside oneself. This account produces the
second.* Its last sentence: *Both ways out have been found, more than once, by people who were not
building a model of personality when they found them.* **The second is no longer only theirs**,
the account having just supplied it in consequences and the intervener. *The repair of 09-06 fixed
the middle of the paragraph and this sentence still reads as the paragraph did before it.*
**Question: does the last sentence still say the right thing about the way out this account
produces?**

*Also recorded and not raised: `remove the need for a footing` is named as one of the two ways out
and is never said what it would consist of, at that site or anywhere. That was true at the build
too and is not new.*

## Findings outside the four tests — vocabulary, and two internal contradictions

These came out of building the inventory and are not what the four tests look for. They are
reported because one word doing two jobs has cost this project four times.

**Fault 1 — DISCHARGED 09-04, and by the route the inventory recommended rather than by a
qualifier.** Ch 7's *The smallest scale* now reads *In a lived process the arising is enthusiastic,
the development cautious, the ending detached* — **the letters went out with the sentence**.
Ch 14's rule stands unchanged and is no longer broken: **every letter left in book 2 names a
position a person occupies**, checked against the text this session and not taken on trust.
*Original entry follows.*

**Fault 1 — Ch 14's letter rule is broken by Ch 7.** *The phases and their names* rules: *`A`,
`B` and `Z` name where a person stands — the orientation held in a realm, with its lean — and
they are never used of a phase. That is what keeps the two readable side by side: a letter
always means a person.* Ch 7's *The smallest scale* says: *In a lived process each passage
completes at an orientation: arising at A, development at B, ending at Z.* **The letters are
attached to passages there, seven chapters before the rule forbidding it.** Ch 7's other letter
uses — *A to B to Z and back to A*, and the six passage headings — are orientations a person
stands at and are clean.

**Fault 2 — `crossing` and *Nothing crosses* are ten lines apart in Ch 14.** Reported by `Job43`
and reworded at the coinage; recorded here because the inventory confirms both are load-bearing
and neither can go. The older half — Ch 10's twelve **crossing relations** — is the one that
would give way if it ever bites.

**Fault 15 — DISCHARGED 09-06.** `layer` now occurs twice in book 2 and both are Ch 16's sense:
*one more layer of unawareness* in *The rule beneath them*, and *the climb performed on the last
layer*, which the ruling identified as Ch 16's sense and left alone. **Ch 15 reads *the later
blockings*; Ch 17's *Rising* reads *the oldest material*.**

**Fault 15 — RULED BY `[C]` 2026-09-02, `[A]` deferring the wording choice. Three edits in two
sections.**

- **Ch 16 keeps `layer`.** There the layering is the mechanism and not a description of it — the
  rule conserves what is wanted and each level adds one covering, so a layer is a unit the chapter
  counts with. Nothing else carries that.
- **Ch 15's become `blockings`.** The word is already in the sentence — *each new fear gets its own
  blocking laid down, and the later layers…* — so *the later blockings* costs nothing and is more
  exact, one blocking per fear being what is stacked.
- **Ch 17's become `material`.** *Rising* already uses it two sentences on: *what is to be caught in
  the oldest material is subtle and has never been anything but background.*

**`[C]`'s original report of the ambiguous sentence was wrong and the ruling is smaller because of
it.** *The exit is the climb performed on the last layer* was reported as sitting two sentences
before the developmental ones. It is the **last sentence of the preceding paragraph**, which is
entirely about climbing rungs — so it is Ch 16's sense, keeps the word, and stops being ambiguous as
soon as the next paragraph gives up `layers`. No edit there.

**THE RESIDUE IS CLOSED, 09-04 BY `[A]`, AND IT IS ON THE PAGE.** The two stacks correspond
approximately and are not one stack: *A person who falls loses the highest reaches of thinking
first, and those are the last a person learns, so falling runs roughly backward through a life.
The correspondence is as loose as the one between the Levels and the orientations.* **And the
difference that keeps them apart is stated with it** — *What a child cannot yet do distresses
nobody and is no sign of ill health.* *Original entry follows.*

**RESIDUE, and it is a claim rather than a word — LEFT OPEN.** Ch 17's stack is ordered by **age in
a life**, the oldest laid down in infancy. Ch 16's is ordered by **position in a descent**. The text
reads as though they were one stack and Ch 16's rule does not support it — the chain generates its
fears rung by rung within a descent, not across a lifetime. **The rename hides this rather than
fixing it, which is an argument for the rename: it stops one word asserting an identity nobody has
argued.** *Question: are the developmental strata and the axis's coverings the same stack?*

*Original entry follows.*

**Fault 15 — `layer` carries three unrelated senses, two of them in adjacent paragraphs.**
Ch 15 *Blocking is not a decision*: **later layers** = blockings laid down one per fear over a
life, a chronological stack. Ch 16 *The rule beneath them*: **one more layer of unawareness** =
the Levels' coverings, a vertical stack. Ch 17 *Rising*: **the oldest layers were never ideas at
all** = developmental strata, ideas over pre-verbal expectation. And the sentence immediately
before that — **the exit is the climb performed on the last layer** — is ambiguous between the
Levels' stack (the basic fear at the top) and the developmental one (the oldest material). *This
is the `residue` / `step` / `cycle` / `arc` class.* **Question: which of the three keeps the
word?**

**Fault 7 — RULED 2026-09-02: the sentence keeps the competence vocabulary, and the third
relation becomes *quietly see it*.** `[C]` recommended it, `[A]` assented. Prose owed to a
drafting session — one word in Ch 15's *Two channels*.

**Why the competence word rather than a description that avoids it.** The sentence's job is to
show that the three orientations are **relations to two channels rather than three**, and using
Ch 4's three competence words in order is what makes that visible. The alternative considered
and not taken was a description leaning on none of them — taking the feeling in without doing
anything about it — which would have been safer for an infant who has none of this vocabulary
but would have hidden what the sentence is for.

*Original entry follows.*

**Fault 7 — *Two channels* gives detachment caution's competence word.** Ch 4 fixes the three:
doing, **understanding**, seeing — seeing being *plain, instinctive, concept-free observation,
knowing something through having looked at it rather than through having worked it out*. Ch 15's
*Two channels* glosses the three relations to feeling as *react to the feeling, weigh it and
respond, or **quietly understand it***. The third is detachment, and *understand* is the word
Ch 4 gives to caution. **Question: is *quietly see it* the repair, or does the sentence want
rewriting further?**

**Fault 5 — CLOSED WITH FAULT 10 BY `[A]` 2026-09-02; see there for the ruling. The repair is one sentence in Ch 13's *What the folding separates*: self-reference is why the psychic realm compounds, not the criterion that divides the two.** *Original entry follows.*

**Fault 5 — Ch 13 revises Ch 3's criterion for the realms while saying it is restating it.**
Ch 13 *What the folding separates*: *This is also the property that divides the two realms most
sharply, and it is what the earlier account of them was describing … the line between the realms
is not that one is material and the other is not. It is that one admits self-reference and the
other does not.* Ch 3's stated division is **pushback against feedback**, and its computer
analogy is hardware against software; neither is self-reference. Feedback and self-reference are
not the same thing — a thermostat has the first and not the second — so this is a genuine
sharpening presented as a recollection. **Question: is Ch 13 correcting Ch 3, or does Ch 3's
looping paragraph already carry self-reference closely enough that the sentence is fair?**

**Fault 14 — RULED BY `[A]` 2026-09-02: the intervener DOES supply a footing and not only sight.**
So `[C]`'s proposed distinction — sight against a footing to act from — is rejected, and the
closing sentence is **wrong rather than under-explained**.

**What the book's last three sentences currently say.** *There are two ways out of a problem of
that kind: remove the need for a footing, or find one outside oneself. This account produces
neither. Both have been found, more than once, by people who were not building a model of
personality when they found them.*

**What the ruling does to them.** The middle sentence is false — the account produces the second
exit, with a mechanism, at *What reaches someone the consequences no longer reach*. The final
sentence loses *both*, since one of the two has now been found here. **The paragraph stops being
a limit on the whole model and becomes a limit on what a person can do alone**, which is less
bleak and is what the chapter's own material supports.

**The narrowing that keeps the paragraph honest, from `[A]`'s two bottoms.** Depth improves three
ways and they are not the same kind of thing. **Consequences** push back harder the further down
and at some depth win — that is the turning point, it happens to most people, no intervener.
**An intervener** supplies what consequences no longer can, far down. **Deliberate self-change**
is what *Rising* describes and what the leverage paragraph is about. The first two are not
solutions to the leverage problem because nothing is levered — the person is moved rather than
moving. **So the closing sentence is wrong that the account produces no outside footing, and
right that it gives a person no way to do it alone.** Both need saying.

**PROSE OWED to a drafting session — the closing paragraph of the book.** `[C]` composed none.

**THE TURNING POINT IS NOT COINED — `[A]` 2026-09-02.** `[C]` checked all nine uses of *the
bottom* and every one means the low end of the scale; **no site uses it for the depth a
particular person reached, so there is no word doing two jobs and nothing to repair.** The
concept has one consumer and plain description covers it, a term with one consumer being what
`[A]` already rejected for the fixation/phase genus. **Coin it if Part 4 needs it repeatedly.**
*One site of discipline meanwhile: the section title says `the floor` for Level 9 correctly and
`Everyone should end at the bottom` four lines below means the floor and should say so.*

*Original entry follows.*

**Fault 14 — the leverage section says the account produces no outside footing, two sections
after producing one.** *The problem of leverage*: *There are two ways out of a problem of that
kind: remove the need for a footing, or find one outside oneself. This account produces
neither.* *What reaches someone the consequences no longer reach*: *What reaches them is another
person … a view of the person's situation that the person cannot produce and someone else can.*
A reader will collide the two. The distinction available is that the intervener supplies
**sight** and not a **footing to act from** — the leverage problem being about where the wanting
and the effort proceed from, which is still the person's own position. **Nothing in the text
draws that distinction.** **Question: does the leverage section want a clause holding the
intervener apart, or is the intervener in fact one of the two ways out?**

**Fault 16 — RULED 2026-09-02: NO new prose in Parts 1 or 2. One clause in Ch 14.** `[C]`
recommended it, `[A]` assented after asking whether an intermediate mention was possible.

**The intermediate mention already exists.** Ch 7's *The smallest scale* names the three
passages — arising, development, ending — and says everyone's thoughts make all three. That is
the parts mentioned without the idea being formally named, and it is in the book already. **So
nothing has to be added; the existing mention becomes deliberate rather than accidental**, in a
section being rewritten anyway under fault 17.

**Ch 4 gets nothing, and that is a decision rather than an omission.** Its closing line — *what
hardens, in a realm, is the attending* — reads correctly at face value: attending is continuous
and it hardens. It is thinner than what the line turns out to mean once fault 17's ruling is in,
but it is not wrong. **A forward pointer there would break the reversal Ch 14 is built on** and
would ask the reader to hold a promise for ten chapters.

**Ch 14 claims the earlier material in one clause** — and under this arrangement it claims
something the reader has actually met, Ch 7's three passages, rather than something they were
never told. The chapter already says it reverses the order of introduction deliberately; what it
never says is that the earlier material has been using the unnamed thing all along.

**Why fault 17's ruling made this bigger before it made it smaller.** With an orientation being
the part of a process a person lingers in, Ch 4's closing line is the book's **first statement of
the central relation**, stated before either term exists. `[C]` raised that as an argument for
repairing forward; `[A]`'s question about an intermediate mention found the cheaper answer.

*Original entry follows.*

**Fault 16 — the phase idea is load-bearing in Parts 1 and 2 under no name.** Ch 4 closes on
*attending is something a person does, continuously, and not a place they stand. And what
hardens, in a realm, is the attending* — a statement about phases, three chapters before the
passages appear and ten before they are named. Ch 7's *The smallest scale* does the same:
*everyone's thoughts make all three passages; what varies is what those thoughts are about.*
Read forward, without Ch 14's apparatus, both look like statements about what a person is.
Ch 14 says it reverses the order of introduction deliberately; it does not say that what it is
naming has been in use since Ch 4. **Question: does Ch 14 want a clause claiming the earlier
material, or do Ch 4 and Ch 7 want forward pointers?** *Found 2026-09-02 when `[A]` corrected
`[C]` on three cases `[C]` had read as person-states and which are phases.*

**Fault 17 — RULED BY `[A]` 2026-09-02. An orientation is a PART OF A PROCESS — the part a
person lingers in. The point reading is wrong and both sentences carrying it are wrong.**

**Neither option `[C]` offered was taken.** `[C]` put a point at the close of a passage against
the stretch a process occupies. `[A]` ruled a third thing and then corrected `[C]`'s
over-separation of it: the orientation IS part of the process, and comfort is not what makes it
so — comfort is one person's relation to that part. Ch 15 already draws that line: *every process
passes through the whole range of detachment, so being present at the seeing end is not what
separates people — dwelling there is.* **Presence is the part; dwelling is the comfort.**

**Three words, one place-type and its two occupations — the same arrangement as the letters.**
**Orientation** — the part, as a kind. **Phase** — that part in one particular process.
**Fixation** — that part as the place a particular person lingers. *So `phase A` and `fixation A`
are not two things sharing a letter by coincidence: they are the same part of a process, met once
as a stretch an endeavour passes through and once as the stretch its owner does not leave.*

**TWO SENTENCES ARE WRONG AND NEED REWRITING, NOT QUALIFYING.** Prose owed to a drafting session;
`[C]` composed none.

1. **Ch 7 *The smallest scale*: *in a lived process each passage completes at an orientation*.**
   `[A]`: *just wrong.* A passage does not complete at an orientation — the orientation is part
   of the process, not a boundary it reaches. **This also disposes of the `arising at A,
   development at B, ending at Z` question that opened the session: the sentence is not repaired
   by a letter qualifier, it is replaced.**
2. **Ch 14 head: *the orientations are the names of the three ways a process comes to rest, one
   at the close of each*.** Same reading, same fault. Ch 14's own *The phases and their names* is
   already correct — *an enthusiastic phase while the impulse is still carrying it* — so the
   chapter contradicted itself and the head is the half that goes.

**What `[C]` raised and `[A]`'s correction removed:** that comfort would have to define an
orientation, and so would need stating somewhere rather than being inferred from the four
sketches. It does not — the orientation is defined as a part of the process, and comfort explains
only why a given person's fixation sits at one part rather than another, which Ch 7 already says:
*a habit set down early and held so long that it is simply where they live.*

*Original entry follows.*

**Fault 17 — Ch 14 contradicts itself on what an orientation is, and Ch 7 carries one half.**
Ch 14's head: *the orientations are the names of the three ways a process comes to rest, one at
the close of each* — a **point at the close of a passage**. Ch 14's *The phases and their names*:
*an endeavor has an enthusiastic phase while the impulse is still carrying it, a cautious phase
while it is being weighed, and a detached phase as it comes to an end* — **the whole stretch**.
Two sections apart, in one chapter. Ch 7's *The smallest scale* carries the first: *in a lived
process each passage completes at an orientation.*

**Part 3 needs the stretch and cannot work with the point.** Ch 15's *Which fixation handles a
fear* turns on *being present at the seeing end is not what separates people — dwelling there
is*; the sketches turn on *the seeing end of the detached phase is short and ineffective* and on
a person staying in action *only while it is comfortable*. None of that is available if an
orientation is a point a passage completes at.

**Question: is an orientation a point a passage completes at, or the stretch a process
occupies?** *This is the largest fault the first coherence check found. It also decides the
wording of Ch 7's* The smallest scale*: under the stretch reading that sentence is not repaired
by a qualifier but by saying each passage IS a phase rather than completing at one.* *Raised by
`[A]` 2026-09-02 as a suspected deprecation; checked against the handoff's §5, both architecture
files and book 2's text, and no deprecation exists — the 08-30 `comes to rest` ruling is a
different matter and is recorded as finished.*

---

## FOUND 2026-09-07 by `Job57 coherence 09072026` — nine faults, all ruled the same session

**All nine come from one cause.** `Job55` split seeing into two stages on 09-07 and `Job56`
made the vocabulary pass the next day. What a search cannot reach is a sentence that assumes
the single stage while using neither `take in` nor `notice`, and every fault below is one.
**None of them is drafted. All nine are prose owed to a kind 11 session.**

**A count withdrawn, and it is worth recording.** The first report put the number at fifteen
sites and `[A]` corrected it: *i thought we used "taken in" for detached realms and "see" only
for its conventional meaning.* The verb `see` in its ordinary sense is not a fault and needs
nothing. What survives is the NOUN — `sight` and `seeing` name the capacity to notice — and the
italicised competence word. **The check that matters is whether a sentence makes the absence of
pull the reason for the capacity to notice**, not whether it contains the word see.

---

**Fault 25 — the Five's obsession passage is the Four's, unrepaired.** Ch 5's Five: *The Five's
seeing is in the psychic realm; the physical realm, where the studying happens, has none... The
Five, understanding without sight, has no way to know when enough has been understood, because
that judgment takes seeing.* The Four's twin was repaired on 09-07 to *The Four's taking in is
in the physical realm* and *That judgment takes the whole at once, and understanding cannot
assemble it.* **The book itself names them as one thing** — *The Four obsesses inwardly and the
Five obsesses outwardly, and it is one structure seen twice.* Under the ruling the Five's
version says the judgment takes noticing; what it takes is the whole, held at once. **Repair:
the Four's sentence with the realms exchanged.**

**Fault 26 — RULED BY `[A]` 09-07, and the ruling corrects the report.** Ch 15's *The range of
detachment* says *sight that deepens as the lean moves further from caution, and motivates less
as it does: the realm is seen precisely because nothing in it is tugging*, and two paragraphs
later says *a person is allowed to notice less of what they take in*. Those are opposite, inside
one section. `[C]` proposed that the sight thins as the lean leaves caution. **`[A]`: *not
sight, noticing.*** What caution lends is motivation, and motivation brings noticing on, so what
thins is how much noticing happens. Sight is the capacity and the lean does not move it.
**Consequence recorded with the ruling: the lean acts on noticing and only blocking acts on
sight**, which is why a lean is not a position on the health axis and why the two can be stated
separately. *No new paragraph is needed — Ch 17's two independent rate-setters already carry
the separation and want the terms brought into line.*

**Fault 27 — RULED BY `[A]` 09-07 (*yes*): the width paragraph drops its ordering clause.**
Ch 4's new width paragraph closes *What differs is the width, and it grows in the order the
cycle runs.* That names the cycle three chapters before Ch 7 introduces it, and two chapters
before Ch 6 says in its own voice that *nothing so far has turned on that... Until the reason
for it is given, a step from one cell to its neighbor is only a step, with no direction to it.*
**This is fault 19's class, reopened by prose written 09-07 and one chapter earlier than fault
19's site.** The width fact does not need the order: the paragraph above it already gives the
three widths one orientation at a time. **Repair: the three widths stated without an order.**

**Fault 28 — RULED BY `[A]` 09-07: detachment's competence is named `see` at six sites.**
Ch 4 names the three competences *doing*, *understanding* and *taking in*. Ch 5 opens each
sketch by naming the competence in each realm, in italics, and at the detached realm all four
say *see* — the Two's *stepped back, and so they* see *it*, the Four's *see* it *plainly*, the
Five's and the Seven's *stepped back and* see *it*. Two more sites use the noun: the Seven's
*the realm where seeing is their competence*, and Ch 9's Maya and Daniel, *her husband's psychic
detachment carries a clear-sightedness she relies on more than she notices*. **The Nine's is
already right** — *A Nine takes in both realms whole, and that competence is the least
recognized in the Enneagram.* **Repair: `take in` at all six.** *Recorded with it: the Four's
sketch was repaired at four places on 09-07 and its opener was not, because the repairs were
made in the body of each block and the competence line sits above the body.*

**Fault 29 — RULED BY `[A]` 09-07: *What is seen is the same at either end of the range* is
false as written.** Ch 15, at the close of *The range of detachment*. The sentence carries the
section's load: it is what keeps the two ends from being two different competences, the same
thing arriving at both and only the permission differing. Under the ruling what is the same at
either end is what is **taken in**, and what is seen is exactly what differs. **Repair: *What is
taken in is the same at either end of the range*, with the third sentence unchanged.** The
clause before it, *not assembled out of pieces, but seen as it is*, has the same fault in milder
form — the contrast is with the cautious person assembling, and the thing contrasted is the
taking in.

**Fault 30 — RULED BY `[A]` 09-07: Ch 4's clear face gives the absence of pull as the reason for
seeing.** *In its clear face the step back is a vantage point, and the person sees the realm
precisely because nothing in it is tugging at them* — five paragraphs after the same chapter
states that the absence of pull is what widens the taking in. **The blind half of the same
sentence pair is already correct**, which is what makes the paragraph name the right act on one
side and the wrong one on the other. **Repair follows the Nine's, which is the same claim
already in line:** the step back is a vantage point because nothing is tugging, so the realm
arrives whole and nothing bends it.

**Fault 31 — RULED BY `[A]` 09-07, and the ruling replaces both words. `clear` and `blind` are
retired as the names of detachment's two ends. The ends are the CAUTION END and the ENTHUSIASM
END.**

Census. **Three nouns for the one thing:** *faces* (Ch 4, the Nine's sketch, Ch 7's section
heading and its text, Ch 13, Ch 16), *sides* (Ch 7, and the four sketches at Ch 15), *ends*
(Ch 15 throughout, Ch 17). **Two adjective schemes:** `clear` at two naming sites only — Ch 4's
*clear face* and Ch 7's *clear-seeing side* — against `seeing` everywhere else.

The reasoning, and `[A]` supplied the decisive step. `[C]` proposed naming the ends by noticing
and not noticing. **`[A]`: *one side notices out of caution, the other out of enthusiasm. the
difference is how they treat anxiety.*** So both ends notice, and neither end is distinguished
by sight or by noticing in general. What differs is what becomes of an anxiety arriving there —
taken up at one end, turned away from at the other, which is what Ch 15's *The four fates*
already says.

**What the ruling settles.** The ends take the names the lean notation already uses, so `Z−`
and the caution end name one thing rather than two. **`blind` is kept for the health axis
alone**, where it is the word for sight that has been lost; Ch 16's *one seeing and one blind*
therefore stands. **`two faces` survives**, as the name for the thing before leans exist, and
Ch 13's derivation of it is untouched. **The two faces are to be DESCRIBED rather than
labelled** — `[A]` asked for this in as many words. The description settled: the step back gives
the same thing in both, the realm arriving whole with nothing pulling to bend it, and what
differs is what happens when part of what arrived is disturbing.

**Sites owed the change:** Ch 4's two-faces paragraph; the Nine's *blind face of detachment*;
Ch 7's section and its two sentences; Ch 13's *with nothing in view*; Ch 15's *The four
sketches* throughout, including the two headings *A person detached on the seeing side (Z−)*
and *A person detached on the blind side (Z+)*; Ch 15's *Which fixation handles a fear*; and
Ch 17's first rate-setter. *Ch 15's *A process reaches detachment at the caution end... and
leaves by the enthusiasm end* is already in the new naming and stands.*

**Fault 32 — RULED BY `[A]` 09-07: Ch 7 asserts a route the model retired. The cycle does not
run backward, and Z+ is reached from Z−.** `[A]`: *we deprecated the idea that the cycle can run
backwards. Z+ comes from Z− even though Z+ has the characteristics of A.*

Two sentences, both in Ch 7. The **A to Z** paragraph closes *They enter detachment on its blind
side*, and *The two faces of detachment* says *A person driven there from enthusiasm under
stress is detached and blind, shut down.*

**Census run at `[A]`'s instruction, and nothing else in book 2 asserts it.** Ch 7's own head is
already correct — *This is a statement about directions, not about motion.* Ch 10's *each realm
pulled toward the orientation behind it* is a lean and stays. Ch 7's **B to Z** runs forward.
Ch 7's **Z to B** and **B to A** describe what a person is like and name no route.

**Two passages already carry the account these two sentences contradict.** Ch 15's enthusiastic
sketch: *at the seeing end of the detached phase they often drop it completely. Once past that
end they are free to start another endeavor, unless the anxiety went by the seeing end without
being dealt with* — a forward run through the range, the caution end passed without the anxiety
being taken up. And Ch 16's *Spoiled arrivals*: *An arrival reached without living the passage
that leads to it is spoiled: anxiety in the place of alertness, brittle energy in the place of
appetite.* **So Ch 7 is two chapters out of step with Part 3, and Part 3 is where the repair
already exists.** *`[A]` noted that the quoted sketch carries fault 31's `seeing end` and it is
repaired with the rest.*

**Fault 33 — RULED BY `[A]` 09-07: the Nine's block attributes to depth what belongs to the
lean.** The block says the accurate judgement and the negligence belong to the same person and
that *which one shows depends on how hard they are holding to comfort*. Holding to comfort is
how caught a Nine is, and the block says so itself a few lines later. **Depth and direction are
independent**, so a Nine can be deeply caught and leaning either way.

**What decides which face shows is the lean, in the same realm**, because the lean is what
supplies the motivation noticing needs — a trace of caution is something pulling, a trace of
enthusiasm is a pull toward what attracts and what would disturb it is not taken up. **A Nine
has no other realm to draw on**, being detached in both, which is why the lean is the whole of
it there. What depth sets is how much a Nine can bear once something has been taken up, which
the block already says correctly. **Leans arrive at Ch 11 and the sketch is at Ch 5, so the
reason is given as the two faces**, which Ch 4 will have described by then.

*A wider reading was raised and withdrawn.* `[C]` read `[A]`'s *which of the other orientations
asks* as another person supplying the motivation, and built a three-case account on it —
someone cautious asks, someone enthusiastic asks, nothing asks. **`[A]` corrected it: he meant
the lean within one person.** Nothing of the withdrawn reading is carried.

---

## THE PARAGRAPH OWED — one, and it is the only one

`[A]` asked 09-07 whether any of the new ideas needs a paragraph to itself rather than being
worked into existing material. **One does: detachment has no motivation of its own, and gets it
from a neighbour.**

It is the mechanism behind two of the things settled this session, and the book asserts a place
for it and leaves it empty. Ch 15 says the two faces come from the neighbours — *because the two
orientations either side of detachment are what produce them* — and never says by what means.
The means is motivation. A trace of caution in the lean is something pulling, and something
pulling is what brings noticing on; a trace of enthusiasm is a pull toward what attracts, and
what would disturb that is not taken up.

**The same fact answers fault 24.** A mixed type's detached realm gets its noticing from the
realm alongside it, which is the orientation crossing; a Nine has no such realm and gets it from
the lean alone. **So the lean case and the other-realm case are one claim, and the book has
neither. Written once, it does the work at both.**

**Three were considered and do not need their own paragraph.** The separation of noticing from
sight is already carried by Ch 17's two rate-setters. The forward route to the enthusiasm end
fits inside Ch 7's two repaired sentences, and why such an arrival is spoiled is Ch 16's and
stays there. The Nine's two faces fit in the block's existing closing lines.

---

## FAULT 24 — where it lands, added 2026-09-07

Fault 24 stands open and unchanged. **What this session adds is the site.** The two crossings
`[A]` settled at the end of `Job55` — an orientation crossing between a person's two realms
helps, a realm's principles crossing is the critical confusion — have no prose anywhere in
book 2.

The second is drafted at four sketches and never named as one thing: the One's psychic-realm
measure carried into the physical, the Eight's physical-realm moves carried into the psychic,
the Two's carrying of the psychic realm's ceilinglessness, the Five's carrying of the physical
realm's finite resources. **The first is in the book at exactly one place and is not recognised
as a crossing at all** — Ch 5's growth halves, *attends to that realm, and then acts on what
they see*, where the attending needs motivation the detached realm does not have.

**So the four sketches say a crossing between realms is what goes wrong, and the growth halves
of the same sketches depend on a crossing between realms going right, and nothing tells the
reader those are different.** It is not a new section: it is the sentence the growth halves
need, plus one line at each of the four confusion sketches saying what kind of crossing they
are.

---

# WHAT THIS SESSION DID NOT COVER

- **Ch 2's nine profiles and Ch 5's nine sketches are inventoried in aggregate, not one by one.**
  Part 3 reaches back to them at exactly two points, both recorded. A section-by-section
  inventory of the eighteen would be a job of its own and nothing in Part 3 turns on it.
- **Ch 12, *Learning to See*, is reserved and undrafted.** Whatever it states will change the
  `met at` line of any Part 3 entry whose assumption it turns out to supply. Fault 6's attention
  claim is the likeliest candidate.
- **Part 4 does not exist.** Test (b) cannot distinguish a passage that stands alone from one
  whose consumer has not been written. Faults 9 and 13 both carry that caveat.
- **Book 1 was consulted at no point in building this inventory.** No assumption of book 2's was
  found to be met in book 1 rather than in book 2 — every `met at` line above names a book 2
  section. *That is itself a finding: Part 3's foundations are outside Part 3 but they are not
  outside book 2.*

---

# FOUND 2026-09-09 by `Job61 coherence 09092026` — the tracking check on FEAR

Ten items, **all ruled by `[A]` in the same session**, all owed prose. Sites are lines of
`BOOK2-20260909.md`, which this session did not touch. Full statements and proposed wordings are
in `REPAIRS-job61-20260909.md`; unruled material from the same session is in
`NOTE-doctrine-from-job61-20260909.md`.

**Fault 34 — burying attributed to a fixation.** Ch 15's two dwelling paragraphs (1133–1135) count
fears that arrive while a person is standing at the enthusiasm end, giving an A or B fixation a
protection Ch 17's rate paragraph (1399) and Ch 15's **Which fixation handles a fear** (1213) both
deny. RULED: burying belongs to Z+, every arc passes through Z+, no fixation is exempt. Class (a).

**Fault 35 — the width sits on the taking in.** Eight sites: 367, 369, 633, 1117, 1143, 1145, 1151,
1155. RULED: taking in is always whole and never narrowed; what narrows is **what is open to
noticing**; any desire and any fear narrows it, strength setting how much. Three layers, not two.
The phrase is fixed. Class (d) in part — no sentence anywhere licensed applying the rule to fears,
though three sites do it.

**Fault 36 — detachment's competence named as the taking in.** Four sites: 363, 387, 633, 1115.
Everyone's taking in is whole, so the competence names nothing. RULED: the competence is **being
able to notice more** — a capacity, not a performance, since a detached person may notice least.
Ch 4's Z entry also loses *bracing* for *trying to avoid*, on `[A]`'s ruling.

**Fault 37 — the three-way distinction and its explanation said twice.** Ch 11 (989–991) and Ch 15
(1163–1165), the second paragraph word for word identical. RULED: keep both, and Ch 11's second
paragraph goes — it repeats the section two paragraphs above it, breaks that section's own
deferral, and states the harder of the two forms first. Class (c).

**Fault 38 — a fixation placed inside detachment.** Seven sites: 381, 639, 645, 729, 1133, 1135,
1139. `[A]`: *"fixations can sit only at orientations."* The three after Ch 11 take `lean`; the
four before it lose the mechanism sentence entirely, since naming a lean by description is itself a
ruled fault. Class (a).

**Fault 39 — the four fates given in full at two chapters.** Ch 7 (731–733) and Ch 15's fates
section, eight chapters apart, with Ch 16 (1377) summarising. RULED: Ch 7 keeps only *looked at or
turned away from* and gives up the four. Class (c).

**Fault 40 — `recognition` does two jobs.** It names what causes blocking (1199, 1475) and what
undoes it (1131, 1475, 1537, the Level 1 table row), twice in adjacent paragraphs of Ch 17. Fifth
instance of one word two jobs, after `residue`, `step`, `cycle`, `arc`. RULED: `detect` for the
below-noticing sense, `recognition` kept for the exit.

**Fault 41 — Ch 4 and Ch 15 differ by one word on the second source.** 415 says a non-detached
realm has wanting **or** fearing; 1127 says **and**, and lends both. `[A]`: fear comes from an
enthusiastic realm too, *"in a less forceful way"*. Ch 4 is the site to change. **Carried with it:**
a fear can traverse a detached realm without being eliminated, and the first source as written
admits no such return. Not a third source — it enters through the first.

**Fault 42 — the correspondence names one ordering quantity where there are two.** 1321–1331,
*What corresponds is how much is seen — a quantity both scales are ordered by*. Ch 4 orders by what
is **open to noticing** (widest wherever nothing pulls); Ch 16 orders by what is **actually
noticed**. The single phrase hides a reversal at the enthusiasm end, and cuts against the 09-07
separation of noticing from sight. Class (a).

**Fault 43 — the sameness sentence is now empty.** 1155, *What is taken in is the same at either
end of the range*. `[A]`: *"as it stands it's meaningless and so should be deleted."* What replaces
its job: the competence is one thing and **the use** differs — at the caution end the openness is
spent processing arriving fears, at the enthusiasm end on nothing. `Job57` had ruled the sentence
in for that job on 09-07; the use account supersedes it. Same paragraph: *rather than assembling it
out of pieces* moves onto the noticing.

**Also ruled, and not a fault in the four-test sense:** Ch 16's *the basic fear, which no prior
desire produced* (1307) contradicts the book at three places and is false — `[A]`: *"each basic
fear does have a want behind it."* And Ch 15 gains new prose, his content, saying what peace
amounts to at each of the three positions in both realms.

**Not re-run this session:** the per-entry sweep. This check followed one word through the book
rather than re-reading the inventory entry by entry, which is what the tracking check is. Ch 2's
nine profiles and Ch 5's nine sketches remain inventoried in aggregate.

---

# FOUND 2026-09-12 by `Job65 coherence 09122026` — the descent's two phases against the rest

Four faults. **Faults 44 and 45 were ruled by `[A]` in this session and both are owed prose.**
Faults 46 and 47 are recorded as questions and neither was put to him. Sites are section titles;
the master this session read is `BOOK2-20260912.md` and no line in it was touched.

## Fault 44 — blindness is named as the only thing that moves a person, at four sites, and the two-phase descent says otherwise

**Class (a) and class (c) at once.** Four sites say a person's place on the health axis changes
only through blindness:

- Ch 17 *What actually descends* — one thing moves on this axis, and it is how much of their own
  condition a person notices; where a person stands is a running total of what happened at the
  crossings.
- Ch 16 *Where a level change can happen* — the crossing opens only at the two extremes of what a
  person notices, and partial noticing holds a person where they are.
- Ch 16 *Spoiled arrivals* — blindness accrues, happens at the crossing and nowhere else, and locks.
- Ch 16 *The correspondence* — on the health axis, what goes unnoticed is what blocking has taken.

Against those, Ch 16 *The rule beneath them* now says a person can descend several levels with very
little blindness laid down, and that above the unhealthy band **the chain does the work on its own**.

**RULED BY `[A]` 2026-09-12, and the ruling keeps the four sites:**

> there is usually material buried in early childhood that is present in the upper levels. the
> normal riso abandonment of resolving fears leading to descent always potentially operates.

So blindness remains the only thing that moves a person. **What is false is the second half of the
two-phase sentence.** Little NEW material is buried above the unhealthy band, and that part of the
observation stands. What buys a rung up there is still a fear turned away before it is noticed, and
what makes so many fears turnable-away is ground already covered in early childhood. The fall above
Level 7 runs on old burial rather than on none.

**What the repair has to do, and it is one sentence's worth:** the two-phase paragraph keeps its
observation and gives up the inference. The chain governs which fears arrive at each level; the
crossing is still where the level changes. **The childhood paragraph already standing in the same
section is what makes this true, and the repair should lean on it rather than restate it.**

*`[C]` had put an alternative to him — that the axis has two measures on it rather than one — and
his ruling closes it. The reason he gave is better than the one `[C]` offered, which was that the
bottom rung has to be reachable.*

## Fault 45 — the brake reads as empty above the unhealthy band

**Class (a).** Ch 17 *Why this does not take everyone to the bottom* states the brake entirely in
terms of buried material. What the struggling person settles is which is more painful: staying as
they are, or **facing the pain of unburying what has been buried**. Both terms of the comparison
climb as the fall goes on, and further down there is more to unbury, so facing costs more.

Nothing in that chapter says buried material exists above the unhealthy band. A reader arriving
from Ch 16's two phases — where most fears are ignored rather than buried and little blindness is
laid down — will take the pain of facing to be near zero up there, and the brake to be idle across
most of the range.

**The fact that answers it is already in the book** and sits in the other chapter: panic can happen
at any level and very early in life, what is buried then stays buried, and a person at any level
may be carrying childhood material. **The repair is a join, not an argument.** The comparison has
to be set up where the reader can see that the second term is never empty.

*Nothing is owed to the brake's construction. Five sessions before this one — `Job31`, `Job32`,
`Job33`, `Job49` and `Job63` — each declined to assemble one, and this session found one already
written and sound.*

## Fault 46 — *not laid down at all* against the bodily tension, and they are two sections apart

**Class (c) in reverse — one claim stated twice with different scope.** Ch 15 *The four fates* says
ignoring leaves **nothing mental at all**, and leaves a bodily tension. Ch 16 *The rule beneath
them* says an ignored fear **is not laid down at all**.

Both were written on 09-12 and both are `[A]`'s content. The second drops the word that makes the
first consistent with itself. A reader who has the bodily tension from Ch 15 meets a flat denial
of it one chapter later.

**Stated as a question:** should Ch 16's sentence read that nothing mental is laid down, or does
`laid down` already mean the mental deposits and nothing else throughout the book? *Not put to
`[A]`. If `laid down` is deposits-only, the sentence is right as it stands and nothing is owed.*

## Fault 47 — the bodily tension does no work after it is introduced

**Class (b), recorded and not raised.** `bodily tension` is introduced at Ch 15 *The four fates*,
given a duration and a way of being let go of, and identified at a burial with panic. **No later
section uses it.** The stress account at Ch 17 *What falling takes from capacity* runs on the
anxiety that buried material produces, which is a different thing and is named differently.

Recorded rather than raised, on `[A]`'s 09-02 ruling that test (b) cannot tell a terminal passage
from an abandoned one. *It is worth one look by a doctrine session, since the tension was ruled
into the book eight days after the stress account was written and the two may want joining.*

## An amendment to fault 14, not a new fault

Fault 14 had an outside footing arriving at Ch 17 *What reaches someone the consequences no longer
reach* while Ch 17 *The problem of leverage* says the account produces none. **There is now a
third outside thing**: Ch 17 *What actually descends* makes what a person learned about handling
fear the third rate-setter and says it came from other people. That one is not a way out and does
not contradict the leverage section, but it is a third place where something outside the person
acts, and the flat *produces neither* is the sentence all three press on.

## Carried to the doctrine note, unruled

`[A]` 2026-09-12, offered as a guess and marked as one: **the habit of ignoring may itself arise
from blindness already laid down** — *"i think most people have blindness from childhood and that
other forms of neglecting fears might actually arise from it"*, and, asked whether ignoring can
also arise on its own, *"my guess is that it can arise independently. but just a guess."*

Nothing in the book turns on it today, and the fault 44 repair does not depend on which way it
goes. **If ignoring arises only from blindness, the four fates stop being four independent things**
and one of the two unattended fates becomes downstream of the other.

## Not covered by this pass

Parts 1 and 2 were re-read only at the entries the four drafting sessions touched. **Ch 2's nine
profiles and Ch 5's nine sketches remain inventoried in aggregate**, as they have been since the
build. The four tests were not re-run whole over the amended entries; what is above came from the
re-read itself.

---

# THE FOUR TESTS RE-RUN OVER PART 3 — `Job66 coherence 09122026`, 2026-09-12

Run over the inventory's Part 3 entries against `BOOK2-20260912.md` (35,695 w, md5 `1065e37e`),
which is unchanged since Job64. **Job65 amended entries from its re-read and did not re-run the
tests**, and test (d) had not been run over Part 3 since 09-02. **This session rules nothing,
moves nothing and drafts nothing.** Six faults, numbered from 48.

## (d) Is anything assumed but never stated anywhere?

**Fault 48 — Ch 16, the basic fear. OPEN, and no repair can be proposed until it is ruled.**
The chapter leans on the term three times in one paragraph: the descent is seeded at the top by
the basic fear, the basic fear has a want behind it, and the descent ends at the bottom when the
basic fear is finally realized. The rungs table uses it a fourth time at Level 1. **Those four
are every occurrence in book 2 and nothing anywhere says what a basic fear is.** The term is
Riso and Hudson's, and the paragraph that borrows the scale has just told the reader their
descriptions are not reproduced here.

Two things are missing beyond the definition. A basic fear is a different kind of thing from the
fears the rest of the book runs on — a crossing fear is raised inside a running process by
examining a want, while a basic fear stands before any process, one per type, and seeds
everything below; the book never says the two are different kinds. And a basic fear belongs to a
type rather than to a realm, which on Ch 15's rule that a fear lives in one realm or the other
leaves it nowhere to live.

**`[A]` answered the second of those 2026-09-12 by denying its premise** — the process arc does
not run in a particular realm and the fears are of the process arcs. See item 1 of
`NOTE-doctrine-from-job66-20260912.md`, which is a live collision with the 08-19 realm-typing
ruling. **The term is undefined either way.**

*Job61 09-09 touched this term from another side — `[A]` ruled then that each basic fear has a
want behind it, which the prose now carries. The definition was not raised.*

**Fault 51 — Ch 17 *Rising*, the climb written as a journey. SETTLED IN SESSION 2026-09-12.**
*Withdraw along the arc into the quiet, see what is there, and return* reads as a person moving
themselves to a position on the cycle. Nothing in book 2 provides for it: Ch 7 says the loop is
about directions and not motion, Ch 11 never says what moves a lean, and Ch 10's grip-loosening
account gives one step only, to the type ahead — which does not reach detachment from an
enthusiastic realm. `[A]`: *"how is that the decision is there when the fear reaches Z."* Every
process arrives at detachment by itself, so nobody travels. **A wording fault, not a doctrine
one.** Repair 3.

**Fault 52 — Ch 17 *Rising*, what sets a person preparing.** The section describes the
preparation and the practice and never says what starts it. `[A]` supplied the missing claim and
it is in no file before 2026-09-12: the pain of life not working has to be understood as coming
from fears not faced. Repair 4.

**Nothing else.** The candidates checked and met: the crossing (Ch 14), the four fates (Ch 14 and
Ch 15), spoiled arrivals (Ch 7 *Backward*), the nine named positions (Ch 11's −/0/+ notation),
panic (Ch 15), capacity to bear and stress lowering it (Ch 4), the single attention (Ch 4), the
infant differentiation (Ch 15, used again in Ch 17).

## (a) Is everything a section assumes stated earlier?

**Fault 53 — Ch 15 *Blocking is not a decision* spends the mental deposits before they are
earned.** *Both are laid down alongside everything else previous thoughts have laid down* uses
the deposits as established; *What previous thoughts have laid down* establishes them two
sections later, opening by saying the question has been open since the beginning of the book.
About sixty lines. Small, and the late siting of the deposits is ruled and not in question.
Repair 5.

**Nothing else new.** `Depth` used in Ch 14 before the axis arrives is fault 20 and stands.
`Layer` is fault 15 and stands.

## (b) Is everything a section states used later, or does it stand alone?

**Clean over Part 3.** The entries most likely to orphan were checked and each is picked up. The
correspondence table is used twice after it is drawn — for what corresponds being how much a
person notices, and to turn the independence of depth and direction from a rule into a result.
Panic is defined at the caution end and used again in the burial account and in what both
extremes leave open. Constitution and the infant differentiation are used again in Ch 17's
account of what hardens in an infant.

## (c) Is any claim derived twice from scratch?

**Clean over Part 3.** The passages that look like repetition point back rather than rebuild. Ch
16 *The two ends* names the range set out with the fixations rather than deriving it again. Ch 17
*What actually descends* takes the crossing as the only place depth changes rather than
re-deriving Ch 16's result. The four fates said twice is the minimal-then-full shape `[A]` ruled
09-02 and is not a fault.

# TWO FAULTS RULED IN SESSION, FROM `[A]`'s OWN ACCOUNT

These were not turned up by the tests. They came out of the exchange and are recorded here so the
sites are findable.

**Fault 49 — Ch 15 *Which fixation handles a fear*, the split is too clean.** *Enthusiasm and
caution both act before the crossing* against *A detached person acts at the crossing itself*
tells a reader that for a person detached in neither realm nothing acts at the crossing at all.
`[A]` 2026-09-12: *"no. but i think it is more superficial since there is less attention there."*
The difference is an amount, not a split. Repair 1.

**Fault 50 — five sites say time at the crossing where the quantity is attention.** `[A]`
2026-09-12: *"i think time means attention. attention is probably more accurate and time a poorer
metaphor"*, and *"dwell is just a synonym for time."* The five sites are listed in Repair 2. The
gain is that the crossing stops having a mechanism of its own and draws on Ch 4's single
attention. Ch 17's three rate-setters stay independent under the change; that was checked.

# CARRIED TO THE DOCTRINE NOTE, UNRULED

Four items, in `NOTE-doctrine-from-job66-20260912.md`: whether a process arc has a realm at all
(a live collision with the 08-19 realm-typing closure, and it falsifies Ch 15's *the realm the
process ran in*); which fixation handles a fear one realm lends to the other; whether both
fixations contribute at every position of an arc; and whether an enthusiastic realm sends more to
the crossing than a cautious one, which `[A]` called *"seems wrong"* and deferred, and which the
book asserts in two places.

# NOT COVERED BY THIS PASS

Parts 1 and 2 were read only where Part 3's entries sent this session — Ch 4, Ch 7, Ch 10, Ch 11.
**The four tests have still never been re-run whole over Parts 1 and 2**, and Ch 2's nine profiles
and Ch 5's nine sketches remain inventoried in aggregate. The inventory entries were not rebuilt;
only the Rising entry's assumptions and met-at line were amended.

---

## UPDATED 2026-09-16 by `Job72 coherence 09152026`

**Not re-read entry by entry.** This session ran against `BOOK2-20260915.md` (37,380 w, md5
`60a65b20`), which is six masters on from the 09-06 pass. The session's time went on `[A]`'s new
arc account and on sixteen items of its own, all of which are in
`FINDINGS-job72-20260915.md`. What follows is what a later pass must know before trusting an entry
above.

**Entries below are STALE wherever they touch:**

- **the passages and the phases.** A passage is now the move from one phase to the next, and the
  passages are the arising, the development and the ending, and nothing else. The phases are the
  enthusiastic phase, the cautious phase and the detached phase, and nothing else. `impulse`,
  `examination` and `resolution` are no longer names for anything.
- **how long a person spends at either end of the detached phase.** The word is `attention` again,
  not `dwell`.
- **what a detached realm generates.** Nothing, apart from the want for peace. Fears are processed
  at the caution end and ignored at the enthusiasm end, and the lean sets which.
- **where a detached realm's wants come from.** The lean, and the other realm when it is not
  detached. Ch 4's *because wants and fears arise in every realm, whatever orientation* goes.
- **what a Five notices in the psychic realm.** Not only what bears on the physical realm's fears.
- **the life of a desire and the life of a fear.** See `ARC-ACCOUNT-from-job72-20260916.md`. A fear
  lasts one thought cycle; a long desire is raised again and again out of the mental deposits; a
  larger arc is a run of thought cycles with no sharp edge.
- **disappointment.** Now part of the account, in the cautious phase, in both of its two cases.
- **reactive action and panic.** Three cases: no cycle, a truncated cycle, a cycle fully lived.
  Panic is a truncated cycle. Nothing is skipped.

**The four tests were not re-run.** Parts 1 and 2 were surveyed only for governed words, using
`wordcheck.py`, and Ch 2's profiles were read for that purpose and found clean.

**What a later pass should do first:** run `wordcheck.py` against the master it has, then re-read
the entries for Ch 14 and Ch 15, which today's rulings move most.

---

## UPDATED 2026-10-05 by `Job75 coherence 09232026`

**Not re-read entry by entry.** This session ran against `BOOK2-20260923.md` (38,752 w, md5
`40eb4fb3`), cut by `Job74`, which drafted the arc account into Ch 14 whole and retired `crossing`.
The session's time went on tracking what moves a detached person, and on the questions carried
between `[A]` and `Job70 doctrine 09152026`. Everything ruled, and every site found, is in
`FINDINGS-job75-20261005.md`. What follows is what a later pass must know before trusting an entry
above.

**Ch 14's entries above describe a chapter that no longer exists.** `Job74` replaced *Two
transformations and one arising* and *What the odd one carries* with eight sections. *The phases and
their names* was rewritten and moved up; seven are new: *Where a fear meets its fate*, *One thought, step by step*, *What a thought
leaves*, *A want that lasts, and a fear that comes back*, *Disappointment*, *Action without a full
thought* and *Where a fixation acts*. **No entry exists for any of them.** Ch 15's *Why it does not
turn over* is dissolved into *What previous thoughts have laid down*. Ch 7's *The smallest scale* is
cut back. Ch 16 and Ch 17 lost the noun `crossing`.

**The 09-16 section just above is itself now partly wrong.** Two of its lines are superseded:

- *what a detached realm generates — Nothing, apart from the want for peace.* **Superseded.** A
  detached person raises wants and fears like anyone, less intensively (`[A]` 09-23).
- *where a detached realm's wants come from — The lean, and the other realm.* **Superseded.** Wants
  and fears come from the mental deposits; a realm raises nothing; the lean is a source of nothing
  and sets how much attention reaches each phase (`[A]` 09-23, superseding his own 09-16 answer).

**Entries above are STALE wherever they touch:**

- **what crosses between thoughts.** Only the bodily tension and the content of the unresolved
  matter.
- **what ignoring leaves, forgetting, and burying.** Ignoring leaves the tension, the unresolved
  matter and the habit; forgetting is ignoring after the tension subsides; burying is the same
  turning away at a feeling the person cannot bear. **A buried fear is mental deposits** — the fear
  itself ended with its thought.
- **where a fear is settled.** Only at the ending.
- **where action comes.** By motive, for everyone including a detached person. Panic and the grab
  are thoughts cut short, not reflexes.
- **`aversion`.** The cautious phase only. What each orientation cannot easily bear has no term.
- **the health axis.** It measures noticing, not comfort.
- **the counterfeit summit.** What is trained is abiding in the detached phase, which anyone can
  do; conscience is psychic caution; nothing about the types who are liable.
- **the boundary of the model.** A person with no attraction and no aversion at all is outside it.

**The tracking check was run on one object: what moves a detached person** — from where a want is
raised, through what the lean does, to where a detached person's action comes. Every site it found
is in the findings file. It was not run on the fear or on motivation again.

**The four tests were not re-run.** Parts 1 and 2 were read where the tracking sent this session —
Ch 4, Ch 5's opening and the Five, Seven, Eight and Nine sketches, and Ch 7 whole.

**What a later pass should do first:** build entries for Ch 14's eight sections, then re-read
Ch 15 and Ch 17 entry by entry against `FINDINGS-job75-20261005.md`. Do this after the drafting
session that applies the findings, not before.

---

## UPDATED 2026-10-06 by `Job77 coherence 20261006`

Run against `BOOK2-20261005.md` (39,839 w, md5 `d50bf9bb`), cut by `Job76`, which applied
`FINDINGS-job75-20261005.md`. Everything ruled in this session, and every site, is in
`FINDINGS-job77-20261006.md`. **This section replaces the Ch 14 entries above**, which describe a
chapter that no longer exists. It then gives what the re-read of Ch 15 and Ch 17 found.

### Chapter 14: Underneath the Cycle — entries for the current nine units

#### (head)

- **Asserts** — the cycle has so far ordered the orientations, and the order places a person's
  orientation and measures a lean; **underneath the ordering are three passages**: the arising
  (detached phase to enthusiastic phase), the development (enthusiastic to cautious), the ending
  (cautious to detached); every process makes all three; **each phase lies between two passages
  and is split in two**; the split matters most in the detached phase, whose halves are the
  **caution end** and the **enthusiasm end**; Z− is at home in the caution end and Z+ in the
  enthusiasm end; the passages are harder to see and more basic, and **a fixation acts through the
  passages of each thought**, because what hardens is a habit of noticing.
- **Assumes** — the cycle's order; the lean; the three phases; that a fixation is a habit of
  noticing.
- **Met at** — Ch 7 head, Ch 7 *The smallest scale*, Ch 11 head; the phases and passages, Ch 7 *The
  smallest scale*; the lean notation Z− and Z+, Ch 11. **Uses `fixation` defined at the Part 3
  opening.**

#### The phases and their names

- **Asserts** — beginning, middle and end are the enthusiastic, cautious and detached phases; **an
  orientation is the phase a person is most comfortable in and prefers**, and a person tends to
  prolong it because they cannot easily bear what the next phase would bring; preferring a phase is
  not being stuck in one process; **the letters name only where a person stands, never a phase**.
- **Assumes** — what each orientation cannot easily bear.
- **Met at** — Ch 4, the paragraph beginning *Each of the three also comes with something a person
  cannot easily bear*. Holds.

#### Where a fear meets its fate

- **Asserts** — a fear meets its fate in the detached phase, somewhere between the caution end and the
  enthusiasm end; **the four fates**, each in one sentence; **only blocking leaves a person seeing
  less**, so depth changes only in the detached phase.
- **Assumes** — the four fates, which Ch 15 *The four fates* states in full.
- **Met at** — stated here first and in full at Ch 15. The register's rule that the fates are stated
  in full only in Ch 15 holds, since this section gives one sentence each. **Its *ignored, which
  settles nothing, so the fear returns with the problem* is explained by *A want that lasts*, two
  sections on. Holds.**

#### One thought, step by step

- **Asserts** — a thought takes about a second and is where the passages are actually made; the
  shoelace and coffee example: **a want at the arising** (or a pain or pleasure starting a thought),
  **examining at the development raises an aversion**, a fear is one kind of aversion, and **at the
  ending the fear meets one of the four fates**; deciding on a next step works a fear through; with
  nothing to fear, nothing meets a fate.
- **Assumes** — the passages; the four fates.
- **Met at** — Ch 14 head; *Where a fear meets its fate*. Holds.

#### What a thought leaves

- **Asserts** — the next thought is separate; **what the ended thought was still carrying is laid
  down**, and the next arises out of what was laid down; *the decision is laid down*.
- **Assumes** — the mental deposits.
- **Met at** — **NOT MET until Ch 15 *What previous thoughts have laid down***, where the term is
  coined. Forward dependency. **Open for doctrine:** whether a want is laid down, which
  `FINDINGS-job75` Part Four carries and this section asserts.

#### A want that lasts, and a fear that comes back

- **Asserts** — a want that seems to last a month is raised again thought after thought; **a fear lasts
  one thought** and is raised again out of what was laid down and out of the problem, which still
  stands; **no fear is kept somewhere and brought back**; an ignored fear comes back because the
  problem raises it; a blocked fear is turned away from, and later thoughts raise fears shaped by it
  about a problem the person can no longer notice.
- **Assumes** — laying down; ignoring and blocking.
- **Met at** — *What a thought leaves*; *Where a fear meets its fate*. **`turns away from looking`
  falls under `FINDINGS-job77` row 7.**

#### Disappointment

- **Asserts** — disappointment is the second kind of aversion and meets the same four fates; it
  belongs to the cautious phase in both of its two cases, a want judged unmeetable and an outcome that
  did not meet the want; what a new thought raises after a pain depends on where attention is
  concentrated.
- **Assumes** — aversion; that attention is concentrated at one phase.
- **Met at** — *One thought, step by step*; the concentration of attention, **NOT MET until *Where a
  fixation acts***, two sections on. Minor forward dependency.

#### Action without a full thought

- **Asserts** — an action follows no thought, a thought cut short, or a full thought; **a reflex is
  an action no thought comes before**; snapping is a thought whose examining is cut short; **action
  is placed by its motive**, toward at the enthusiastic phase and fending off at the cautious phase;
  panic is a cut-short thought and not a reflex; a cut-short thought still makes all three passages
  and raises little.
- **Assumes** — the passages; the phases.
- **Met at** — Ch 14 head. **This definition of `reflex` is the one `FINDINGS-job77` row 3 protects.**

#### Where a fixation acts

- **Asserts** — the hardened orientation is a fixation; **the definition sentence makes a fixation
  *be* attention concentrated at one phase** (`FINDINGS-job77` row 2 repairs it); a fixation acts in
  every thought and so at every size; **the fixation that acts is the one held in the realm the
  thought is about**; the enthusiastic fixation: cursory examining, little raised, fears arriving
  little understood and seeming less urgent; the cautious: heavy examining, many fears, most
  arriving understood, each meeting its fate at the ending; the detached: little attention at the
  arising and the examining, wants and fears raised less intensively, wanting peace; fears arriving
  at a detached person's ending are processed near the caution end or ignored near the enthusiasm
  end, and the lean and how far it goes influence which.
- **Assumes** — `fixation`; the realm of a thought; the lean and how far.
- **Met at** — Part 3 opening; Ch 15 *Which fixation handles a fear* (**stated again there**, see
  test (c) below); the lean, Ch 11.

**Test (c), derived twice:** *the fixation that acts is the one held in the realm the thought is
about* is stated here and again at Ch 15 *Which fixation handles a fear*. The second is fuller, and
covers matters on both sides. Not a fault unless a later style job finds the first restated.

### Ch 15 — re-read entry by entry

- ***The range of detachment*** — **the most changed section in the book again.** New since its
  09-12 re-read: two sources of motivation set out in full; pain and pleasure starting a process; the
  job example in three paragraphs; panic and the grab as cut-short thoughts, with the reflex set
  apart; each end's standing want. **Faults: `FINDINGS-job77` rows 3, 4, 7, 8 and 9, and Part Two A.**
  The job example and the lean paragraph are to be rebuilt, not reworded.
- ***Disregarding, and not seeing at all*** — forgetting is now ignoring after the feeling subsides.
  **Part Two C** (*the feeling of the fear lasts*). Row 7 (*turning away from looking*).
- ***The four fates*** — settled now names only worked through and given up on, and *unattended* the
  other two; ignoring lays down the habit and the knowledge; a buried fear is what the burial laid
  down. **Part Two D** (*Two of the four*). Row 4: the history of burying is sited beside the
  deposits, not here.
- ***Blocking is not a decision*** — **row 4**, the third sentence of the learning paragraph; **row 3**
  (*reflexive*). The section's argument stands under row 5.
- ***Which fixation handles a fear*** — **Part Two B** (*acts* in the detached phase). Its *examines
  most of what might go wrong before the detached phase is reached* carries the 10-05 repair.
- ***The four sketches*** — the A and B sketches now concentrate attention at a phase, and the Z−
  sketch runs a process *quickly and at low amplitude* (*low amplitude* is left for the style job).
  **Part Two E** (*it accumulates*, in the Z+ sketch).
- ***Two channels*, *The hinge*, *Habit carries it*** — unchanged in substance. *The hinge* has row 3
  (*a reflex follows*). *Habit carries it* ends *It also says what undoing one would involve*, an *It*
  the handoff's style list already carries.
- ***What previous thoughts have laid down*** — the mental deposits coined. **Row 4's account of what a
  burial lays down is sited here.**

### Ch 17 — re-read entry by entry

- ***What actually descends*** — row 3 (*turning away is a reflex*, *a habit can reach a reflex*).
  Otherwise holds.
- ***The second way down, which is not blindness*** — **Part Two E and F**: one fear left indefinitely
  and pressing harder; *keeps its pull*.
- ***What falling takes from capacity*** — **Part Two E** (*left holding fears*). The cautious case
  holds.
- ***Why this does not take everyone to the bottom*** and ***What reaches someone the consequences
  no longer reach*** — hold under row 4; checked at `Job70`'s request.
- ***Two things that cannot happen*, *The last stretch*** — unchanged; hold.
- ***Rising*** — row 3: *displace a reflex* becomes *the habit of turning away*. The climb holds under
  row 4.
- ***What is actually being undone*** — **row 6**: the *Better is to recognize the burying itself*
  paragraph offers a single thing whose recognition generalizes, which the ruling removes. The three
  things are to be kept apart.
- ***The summit, and what counterfeits it*** — rewritten by `Job76`. **Rows 1 and 2**: the closing
  expectation covers only enthusiastic and cautious fixations, its reason is replaced, and *the
  person's fixation is unchanged* becomes the type. **Part Four:** conscience for a person detached in
  the psychic realm is not covered.
- ***The problem of leverage*** — unchanged; holds.

**The four tests were not re-run across the book.** Test (a) was run on Ch 14's new sections, above,
and found two forward dependencies, *mental deposits* and the concentration of attention. Test (c)
found one double statement.

**What a later pass should do first:** after the drafting session applies `FINDINGS-job77`, re-read
*The range of detachment*, *Blocking is not a decision*, *What previous thoughts have laid down* and
*What is actually being undone*, which that drafting will rebuild.

## UPDATED 2026-10-12 by `Job79 coherence 20261010`

Against `BOOK2-20261011.md` (40,396 w, md5 `22eca00d`). The master was read through in full. Entries
were not re-cut one by one; this section records which units carry a fault, and
`FINDINGS-job79-20261012.md` is the authority for each.

- **Ch 4, *The Three Orientations*** — the noticing paragraph and the moment-to-moment paragraph: `draws`
  becomes `pulls` (item 4). The detached person's want: the same. The paragraph after the stress
  paragraph: *can bear less in the other as well* (item 1). The capacity account otherwise holds.
- **Ch 5, the Five's and Six's sketches** — `point` for what a fear does to noticing (item 4).
- **Ch 11, *The lean in detachment is not like the others*** — *not looked at* names the attending
  stage, not the noticing stage (item 9).
- **Ch 14, *Disappointment*** — *Disappointment is another kind*; the first way a want disappoints is two
  thoughts; *belongs to the cautious phase both times* (items 5, 6). ***Where a fear meets its fate*** — the
  regret sentence (item 8) and the frame (item 7).
- **Ch 15, *The range of detachment*** — `draws` (item 4). ***Disregarding, and not seeing at all*** — the
  regret sentence (item 8). ***The four fates*** — all four entries written for a fear; the regret entry and
  *the regret is the mark of it* (items 7, 8). ***Blocking is not a decision*** — the move *learned*,
  against the last chapter (item 2). ***What previous thoughts have laid down*** — the burial paragraph is
  replaced by `Job70`'s gradual account (answers file, item 5).
- **Ch 16, *The two ends, and what lies between them*** — *its middle* (item 3).
- **Ch 17** — holds under the capacity sweep. *What is actually being undone* is the right side of item 2.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on disappointment.

## UPDATED 2026-10-17 by `Job83 coherence 20261016`

Against `BOOK2-20261016.md` (42,986 w, md5 `7612914c`), cut by `Job82`, which added *Gratification* to Ch 14 and *The
unease loop* to Ch 15 and re-cut the fates. Everything ruled in this session, and every site, is in
`FINDINGS-job83-20261017.md`. Part 3 was read through in full; Parts 1 and 2 were read except the type sketches of
Ch 2 and Ch 5. **This section adds entries for the two new sections and replaces the 10-06 entry for *Disappointment*.**
The entries were made from the text.

### Ch 14 · Disappointment — replaces the 10-06 entry

- **Asserts** — a disappointment arises when the outcome is settled and the want cannot be satisfied; where an
  aversion about the outcome had been raised, the disappointment is what is left when the aversion is given up; **a
  disappointment meets all four fates**; the shoelace is two thoughts: the first finds the lace broken and gives up the
  want to tie it, the second raises a want to fix the lace, the aversion is given up and a disappointment is left;
  tying the pieces together works it through, wearing other shoes gives it up.
- **Assumes** — the four fates; aversion; giving up.
- **Met at** — *One thought, step by step*; *Where a fear meets its fate*. Holds.

### Ch 14 · Gratification — NEW SECTION

- **Asserts** — whatever gratifies becomes expected when repeated and then stops gratifying, so **no way of seeking
  gratification keeps working**; a person who expects a gratification to last is disappointed when it ends; a fear of
  losing the gratification develops with the expectation; when a gratification wears off the person feels worse and
  blames circumstances; a new behavior brings relief because the person now expects less, and the person credits the
  behavior; **the drawback of seeking gratification is constant useless behavior**.
- **Assumes** — disappointment; a fear.
- **Met at** — *Disappointment*, the section before; a fear, *One thought, step by step*. Says nothing of unease or
  bodily tension, which come later; not a fault. **`FINDINGS-job83` item 6** (*the relief came from the wearing off*).

### Ch 15 · The unease loop — NEW SECTION

- **Asserts** — a fear worked through still leaves bodily tension (house sale); a later thought wants to be rid of the
  tension, finds it cannot be, and raises a new fear; **the unease loop** is that round, each turn a whole thought and
  worked through; it buries nothing and takes nothing from noticing; **unease and bodily tension refer to the same
  thing**; each orientation runs it with a different want, and each has a way out by its competence; at the enthusiasm
  end of the detached phase the fear is ignored, and the only way out is the capacity to bear discomfort, which can be
  built and can carry over (the migraine account); the harm the unease loop does may have a limit and the blindness
  loop's does not; the way out is taken when staying is the worse pain; turning over a matter is the unease loop when
  the plan differs each turn and ignoring when it repeats; present, noticed and acted on are separate; a habitual fear
  against buried material; letting go of tension against a skill for handling fear; **idle discomfort is unease, from
  buried fears and ignored aversions**; distraction is a gratification and wears off; with neither, no distraction is
  needed.
- **Assumes** — the four fates; bodily tension; every fate leaves bodily tension; the blindness loop; a skill for
  handling fear; gratification; the health axis measuring noticing.
- **Met at** — *The four fates*; *The range of detachment* (the blindness loop); *Gratification* in Ch 14; the health
  axis, **NOT MET until Ch 16** — *A person higher on the health axis notices more* is the book's first use of *health
  axis* (`FINDINGS-job83` item 9). The skill for handling
  fear is named here and defined in Ch 17 *What actually descends* (**forward dependency**). **Faults:
  `FINDINGS-job83` items 3, 4, 5 and 8.**

### Ch 16 and Ch 17 — which units carry a fault

- **Ch 16, *Where a level change can happen*** — holds; its *for years* sentence is to be shown to `[A]` with item 4.
- **Ch 17, *Why this does not take everyone to the bottom*** — items 1 and 2: the facing side as a growing amount, and
  the last sentence of the two-pains paragraph.
- **Ch 17, *What reaches someone the consequences no longer reach*** — item 2: the counted-part claim and the reason
  it gives; minor intervention is common.
- **Ch 17, *Rising*** — item 2 (the connected-pain sentence; the desperation sentence to read against the ruling) and
  item 3 (*An ignored aversion is still in view*).
- **Ch 5, the opening** — item 7 (*Book 1 calls that the critical confusion*).

**Tests (a) to (d) were not re-run across the book.** Test (a) was run on the two new sections and found two forward
dependencies. The tracking check was run on the pain of staying and on unease.

## UPDATED 2026-10-18 by `Job85 coherence 20261017`

Run against `BOOK2-20261017b.md`, cut by `job84 drafting 20261017` at letter `b`. Everything ruled in this session,
and every site, is in `FINDINGS-job85-20261018.md`. **This block replaces the 10-17 entry for *The unease loop*, and
gives the current state of the Ch 17 units `Job84` changed.** The entries were made from the text. Where a unit
carries a fault ruled in this session, the entry says so; the text is not yet repaired.

### Ch 14 · Disappointment — amends the 10-17 entry

- **Asserts** — as the 10-17 entry. **Fault: `FINDINGS-job85` item 6** — the aversion that meets its fate is *given up*
  twice; the ruled form is *given up on*.

### Ch 15 · The unease loop — replaces the 10-17 entry

- **Asserts** — a fear worked through still leaves bodily tension (house sale); a later thought wants to be rid of the
  tension, finds it cannot be, and raises a new fear; **the unease loop** is that round, each turn a whole thought and
  worked through; it buries nothing and takes nothing from noticing; **unease and bodily tension refer to the same
  thing**; **the unease lasts as long as the matter stays unresolved**; each orientation runs it with a different want,
  and each has a way out by its competence; **at the enthusiasm end the fear is ignored, leaves some bodily tension,
  which fades, and is raised again when the person next meets the problem**; **a buried fear does not fade in this
  way**, and facing it takes the capacity to bear discomfort, which can be built on any pain and carries over (the
  migraine account: stopping an automatic resistance carried over to the automatic turning away; her fears were not too
  deeply buried, and she could stay with the anxiety); the harm of the blindness loop has no limit; a way out of the
  unease loop is always open, taken when staying is the worse pain; turning over a matter is the unease loop when the
  plan differs each turn and ignoring when it repeats; the loop is run many times without feeling troubled; present,
  noticed and acted on are separate; **the health axis reflects how much a person notices, not how comfortable the
  person is**; a habitual fear against buried material; letting go of tension against a skill for handling fear; idle
  discomfort is unease, from buried fears and ignored aversions; the matter behind an ignored aversion can still be
  noticed; distraction is a gratification and wears off; **an ignored disappointment leaves the matter unresolved and
  some bodily tension**, and the matter raises the aversion again; **ignored aversions and buried fears are the two
  sources of lasting unease**, ended by being given up on and by being faced; with neither, there is no chronic unease.
- **Assumes** — the four fates; bodily tension; the blindness loop; a skill for handling fear; gratification; the
  health axis.
- **Met at** — *The four fates*; *The range of detachment*; *Gratification* in Ch 14. The health axis is named here in
  `[A]`'s wording ahead of its chapter (the `FINDINGS-job83` item 9 fault, repaired). The skill for handling fear is
  still a **forward dependency** on Ch 17.
- **Faults: `FINDINGS-job85` items 3 and 4** — a habitual fear treated as a source of unease and as ended by its matter;
  the claim that a habitual fear grows past bearing and is blocked, which `[A]` did not write. Item 4's replacement
  (*Buried material can leave a person unable to handle life …*) is ruled.

### Ch 17 · What falling takes from capacity

- **Asserts** — falling lowers how much a person can bear by adding stress; what is not seen is not taken into
  account; what is buried goes on producing anxiety; the descent feeds itself; under stress a person looks like the
  orientation behind their own.
- **Fault: `FINDINGS-job85` item 5** — a third source is ruled (perceiving the inability to handle life as a threat);
  *Two things produce it* and *Both lower* count two.

### Ch 17 · Why this does not take everyone to the bottom

- **Asserts** — something must push back; consequences do, all the way down; blindness decides where the response
  goes; the comparison of two pains, with facing imagined unbearable at every depth; desperation leaves a person open
  to trying something new, and nothing makes facing the first try; the pain of staying is present the whole time and
  greater further down; short of unbearable it adds stress and can speed the fall, and it slows the fall only
  sometimes; the fall is slow because a level is many blocked fears; a climb ends when staying stops being unbearable.
- **Fault: `FINDINGS-job85` item 2** — the pushback is given as exactly what produces the middle; the slowness of the
  fall is a second reason (`[A]`: *both*).

### Ch 17 · What reaches someone the consequences no longer reach

- **Asserts** — all of the felt pain counts, so the pain of staying rises at every depth; far down a person is open to
  trying something new but unlikely to try facing first, and may still come to it alone; help from someone who can see
  the person's condition makes facing more likely and is common; an intervener changes what the person can bear and how
  much arrives at once; urging lowers what a person can bear.
- **Fault: `FINDINGS-job85` item 1** — the heading, the sentence before it and the third paragraph's opening say
  consequences stop reaching a person.

### Ch 17 · Rising

- **Asserts** — as before, with the 10-17 repairs: all of the pain of life not working counts; facing the oldest
  material has little reason to seem helpful; the matter behind an ignored aversion can still be noticed.
- **Fault: `FINDINGS-job85` item 6** — *Giving up ignored aversions* and *given up* become *given up on*.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on consequences, on a habitual fear
and on an aversion given up.

## UPDATED 2026-10-19 by `Job87 coherence 20261018`

Run against `BOOK2-20261018.md`, cut by `job86 drafting 20261017`. Everything ruled in this session, and every site, is
in `FINDINGS-job87-20261019.md`; `Job81`'s update for this session is in `RELAY-from-job81-20261019.md`. **This block
gives the current state of every unit `Job86` changed.** The entries were made from the text. Where a unit carries a
fault ruled in this session, or is named by the relay, the entry says so; the text is not yet repaired.

**The chapter is now *Falling and Rising*.** The 09-02 heading *Falling and Rising, and the Problem of Leverage* and
the 09-02 entry *The problem of leverage* are history. The entry below replaces the latter.

### Ch 15 · The unease loop — amends the 10-18 entry

- **Asserts** — as the 10-18 entry, with `Job86`'s repairs: the habitual-fear paragraphs now come last in the section.
  **Lasting unease also produces fears**; a habitual fear is raised by its matter every time, is noticed and worked
  through every time, and **is kept going by buried fears or ignored aversions, and by the unease loop**; the matter is
  only what the fear attaches to; it usually eases when the source of lasting unease ends, and other things affect it.
  **Buried material can leave a person unable to handle life; the person perceives the inability as a threat; the
  perception is not blocked, and persists with the situation.**
- **Faults:** `FINDINGS-job85` items 3 and 4 are **repaired**. **The relay bears on this unit:** *burying* and *buried*
  here are blind blocking only (`[A]` in the relay: *Buried stays with blind blocking only.*), which agrees with the
  text as it stands. Not re-checked against discomfort blocking beyond that.

### Ch 17 · What falling takes from capacity

- **Asserts** — falling lowers how much a person can bear by adding stress; **three** things produce the stress: what
  is not seen is not taken into account; what is buried goes on producing anxiety; a person who cannot handle life
  perceives the inability as a threat, the inability coming from things going wrong unexpectedly and reactions not
  thought out together, and the threat persisting with the situation; all three lower how much a person can bear; the
  descent feeds itself; under stress a person looks like the orientation behind their own.
- **Faults:** `FINDINGS-job85` item 5 is **repaired**. The relay lists the third source as not yet approved; it was
  approved in `Job86` (`FINDINGS-job87` Part Two, note 1).

### Ch 17 · Why this does not take everyone to the bottom

- **Asserts** — as the 10-18 entry, with **two things gathering people in the middle: the fall is slow, and something
  pushes back**; the pushback grows with the distance fallen and is one of the two.
- **Faults:** `FINDINGS-job85` item 2 is **repaired**. **Named by the relay's sweep:** the comparison of the pain of
  staying with the pain of facing, and the climb ending at the middle, are to be limited to buried material.

### Ch 17 · What reaches someone who cannot see their own condition

- **Asserts** — the paragraph before the heading: the recognition still depends on what happens in the person's life,
  comes into view under painful consequences, and far down rarely comes without help, because the person cannot connect
  the consequences to their own condition. Then: all of the felt pain counts, so the pain of staying rises at every
  depth; far down a person may still come to facing alone; **an intervener** (defined here, at first use) works through
  sight and on what the person can bear; steadying and a little at a time; the looking is the person's own; urging
  lowers what a person can bear.
- **Faults:** `FINDINGS-job85` item 1 is **repaired**. **Named by the relay's sweep:** *how the recognition builds
  under consequences*, which is the paragraphs just before the heading.
- **Met at** — the last section of the chapter, which now agrees with it under `FINDINGS-job87` rows 1 and 2.

### Ch 17 · Rising

- **Asserts** — as the 10-18 entry, with *given up on* at the two aversion sites.
- **Faults:** `FINDINGS-job85` item 6 is **repaired**. The relay adds that a person can rise through material blocked
  by discomfort alone, one fear at a time; *Rising* says nothing against it, but its statements of difficulty are about
  buried material only by implication, and the sweep is the drafting session's.

### Ch 17 · Why trying harder does not change a person — replaces the 09-02 entry *The problem of leverage*

- **Asserts** — everything a person does about their own condition is done from the position the self occupies; that
  is why a person who resolves to be different ends up doing what they already did, only harder; going up means giving
  up one's footing, which does not respond to effort; help from outside works well, in healthy families and twelve-step
  programs, and the person is moved by someone else, not by their own effort.
- **Assumes** — the self as a position.
- **Met at** — *Where the Inner World Came From* (*The self is that position*); the intervener section; *Rising*.
- **Faults: `FINDINGS-job87` rows 1 to 3, all ruled, with the whole section's new wording approved (row 4).** Effort is
  said never to help, against the looking and the practice; *works well* has no object; the lever figure's words are
  left unexplained. **With the approved wording the unit will assert:** a person does what they do about their condition
  as they already are, and can work only on what they notice, while what needs to change is what they do not notice;
  the climb is hard because going up means bringing the unnoticed into view, which trying harder at the noticed does not
  do; help from outside works well at changing a person, and someone else helps the person see. **It will assume** the
  health axis as noticing. The 09-02 *Met at* note on *produces neither* and fault 14 is obsolete: that sentence was cut
  by `Job86`.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on own effort in a climb.

## UPDATED 2026-10-26 by `Job89 coherence 20261026`

Run against `BOOK2-20261026.md`, cut by `job88 drafting 20261023`. Everything ruled in this session, and every site, is
in `FINDINGS-job89-20261026.md`; the four updates `Job81` sent to this session are `RELAY-from-job81-20261026g.md` to
`-20261026j.md`. **This block gives the current state of every unit `Job88` changed.** The entries were made from the
text. Where a unit carries a fault ruled in this session, the entry names the finding by its subject; the text is not
yet repaired. Every sentence of text proposed in the seven relays `Job88` applied was found in the master; the sentences
not found are instructions, `[A]`'s words, or wording `[A]` changed in `Job88` (*issues in*, *that strategy*, the
climb's 10-19 form).

### Ch 15 · The range of detachment — amends earlier entries

- **Asserts** — in the job example, some fears are *noticed and let alone* (ignored) and some *never noticed* (blocked).
  At the paragraph *A conversation, a place*: anything leading toward buried material raises a fresh anxiety, **the fear
  of looking at the buried fear**, turned away from automatically; the number of things turned away from grows.
- **Faults:** *never noticed, and those fears are blocked* holds for burial only (finding: discomfort blocking starts
  noticed). The growth sentence is one of the two places that already state what the new expansion sentence explains
  (finding: burial all at once or gradual).

### Ch 15 · The four fates — amends the *Blocked* entry

- **Asserts** — *Blocked*: turned away from before it is noticed; **two kinds**. Blind blocking: in panic, to a fear the
  person cannot bear, automatic and all at once, the same act as denial, a buried fear, kept in place by the blindness
  loop. Discomfort blocking: a bearable but uncomfortable fear; aversion turns attention elsewhere each time; a habit
  builds until the fear is no longer noticed; no blindness loop; a later matching fear can be noticed and looked at.
  Fears differ in strength.
- **Faults:** the entry's opening line, and the two-questions paragraph (*blocking is what happens when the fear never
  comes into view*), contradict discomfort blocking, which begins with the fear noticed (`[A]`: *it's a continuum of
  noticing*). A relayed addition distinguishing it from ignoring waits for drafting.

### Ch 15 · Blocking is not a decision

- **Asserts** — unchanged by `Job88`: the threat is detected and not noticed; the feeling arrives; the turning away is
  laid down; no choice, because nothing was noticed; a decision not to look is not what happens.
- **Faults:** true of burial only. For discomfort blocking *the decision starts out feeling like a choice and becomes
  more automatic each time* (`[A]`).

### Ch 15 · The unease loop — amends the 10-19 entry

- **Asserts** — facing a buried fear takes the capacity to bear discomfort, and **the first discomfort to be borne is
  the fear of looking**; in the migraine case the same capacity let her bear the fear of looking; the unease from a
  buried fear does not wear off, and the fresh anxiety is the fear of looking. Unchanged: two sources of lasting unease;
  a fear is blocked only when the person cannot bear it; buried material can leave a person unable to handle life.
- **Faults:** sources of lasting unease are three, not two (finding: the sources of lasting unease); the perceived
  inability is one thing with two names (`[A]`: *same. merging them would be good.*); *a fear is blocked only when the
  person cannot bear the fear* holds for burial only (finding: what a person can bear).

### Ch 15 · The Z+ sketch and *What previous thoughts have laid down*

- **Not changed by `Job88`.** **Faults found by this run:** the Z+ sketch reads every unnoticed turning away as a burial,
  and names two sources of unease; the opening paragraph of *What previous thoughts have laid down* says burying develops
  gradually from fears at first noticed, against the *Blocked* entry (`[A]` agreed to `Job81`'s separation: one fear is
  buried all at once, and what develops gradually is how soon the turning away comes).

### Ch 16 · The process that produces the levels — replaces the entry *The rule beneath them*

- **Asserts** — the core dynamics: an unsettled fear leads to a desire, taken up as an attitude that produces behavior,
  which brings the fear of failing at the strategy; the money example; the connection goes out of view through aversion,
  and the fear above is blocked; that is going down a level; ignoring does not move a person down. Descent is fear turned
  into desire, seeded by the basic fear, ended when the basic fear is realized; the basic fear behaves like any fear.
  Levels 1 to 6 mostly discomfort blocking; childhood blind blocking carried at every level; fresh blind blocking mostly
  Levels 7 to 9. Panic at any level and early in life. The process fixes order, not movement; it conserves the original
  want and hides its own working; climbing requires seeing the present desire as a covering.
- **Faults:** *what is buried then stays buried* reads as permanent (`[A]`: *same in that regard, but preverbal fears are
  immune to logic and therefore more difficult to access.*).

### Ch 16 · What the axis is toward

- **Asserts** — follow the object of the wants down: oneself at Levels 1 and 2, the world at 3 to 6, the self-image at 7
  to 9; the axis's object is oneself; how the fixations have been handled.
- **Faults:** none. *Follow the object of the wants down* approved by `[A]` in this session: *yes.*

### Ch 16 · Where a level change can happen

- **Asserts** — the level changes only in the detached phase; three fates leave it; a person falls when fears are
  blocked and rises when blocked fears are retired; a fear blocked by discomfort can come back into view; before a
  buried fear can be seen the fear of looking must be borne; a climb through buried material is rare.
- **Faults:** *Each fear turned away from before the fear is noticed* holds for burial only.

### Ch 16 · What a level is made of

- **Asserts** — blindness accrues one crossing at a time; a level is many crossings; each burial puts something out of
  reach; order fixed; what is covered is not gone; **a climb of any real distance through buried material is measured in
  years**.
- **Faults:** a level is said to be made of blindness and burial only, but *blindness is only what burial produces, but
  preexisting blindness can operate at all levels* (`[A]`), and Levels 1 to 6 are mostly discomfort blocking.

### Ch 17 · Leaving fears unweighed — the old *The second way down, which is not blindness*, retitled

- **Asserts** — unchanged text: a fear noticed, admitted and left unweighed; a habit of not taking things up; urgency is
  a slope.

### Ch 17 · The second way down, which is not blindness — new

- **Asserts** — discomfort blocking defined again; it takes a person down a little at a time and is the usual way down
  in Levels 1 to 6; no blindness loop; a person can rise through it alone, one fear at a time; a buried fear is faced
  alone only when staying is unbearable.

### Ch 17 · What actually descends, Why this does not take everyone to the bottom, What reaches someone

- **Asserts** — as the 10-19 entries, with `Job88`'s changes: the person reacts as if facing the buried fear would be
  unbearable, without being aware of the reaction; *through buried material* at the end of a climb; leaving a rung
  through buried material takes many turns.
- **Faults:** the fall and the intervener are tied to what the person cannot bear, and sinking to burial (findings: what
  a level is made of; what a person can bear). `[A]`, to `Job81`: stress, the lean, the strength of the fixation, learned
  skill, the habit already built and understanding one's own blindness bear on both kinds of blocking.

### Ch 17 · Rising and What is actually being undone

- **Asserts** — the climb through buried material: the fear of looking arrives first; reaching the top means no blocked
  fear is left, of either kind; a person reacts to a buried pain as if facing it would be unbearable, without being aware
  of the reaction; recognition of each kind of blocked fear.
- **Faults:** *how often a fear gets handled instead of buried, which is a rate* ties the rate to burial only.

### Ch 17 · Why trying harder does not change a person

- **Asserts** — the approved three paragraphs from `FINDINGS-job87`, in place.
- **Faults:** none.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **a blocked fear**: from whether it
is noticed and whether it can be borne, through what decides its blocking, to what it lays down, whether it makes a
person blind, what unease it leaves, and how it ends.

## UPDATED 2026-10-28 by `Job91 coherence 20261026`

Run against `BOOK2-20261027.md`, cut by `Job90 drafting 20261026`. Everything ruled in this session, and every site, is
in `FINDINGS-job91-20261028.md`; the five updates `Job81` sent to this session are `RELAY-from-job81-20261027.md`,
`-20261027b.md` to `-20261027d.md`, and `-20261028.md`. **This block gives the current state of every unit `Job90`
changed.** The entries were made from the text. Where a unit carries a fault ruled in this session, the entry names the
finding by its subject; the text is not yet repaired.

### Ch 4 · The Three Orientations — amends earlier entries

- **Asserts** — unchanged by `Job90`: at the enthusiasm end turning away can become automatic; automatic turning away is
  denial and happens before the thing is noticed; turning away brings relief; what was never noticed cannot be got at
  afterwards.
- **Faults:** denial is blind blocking only (finding: denial); *cannot be got at* — intentional access only is blocked
  (finding: what was never noticed); attraction and aversion to be introduced here with wants and fears (finding:
  *aversion* in the *Blocked* entry; relay `20261027d`).

### Ch 7 · The two faces of detachment

- **Asserts** — what differs between the two faces of detachment is what happens to the fear; when the fear is very
  unpleasant the person turns away in panic and the fear is barely noticed.
- **Faults:** none new. Agrees with finding 1 (a buried fear is glimpsed).

### Ch 14 · Where a fear meets its fate

- **Asserts** — blocked: turned away from until no longer noticed; blocked all at once in panic, or gradually through
  discomfort; only blocking leaves a person seeing less.
- **Faults:** *seeing* → *noticing* (finding: discomfort blocking and seeing).

### Ch 14 · One thought, step by step

- **Asserts** — unchanged: a want is an attraction or an aversion; a fear is one kind of aversion.
- **Faults:** definitions replaced by a sentence recalling Ch 4 (relay `20261027d`, consequences in relay `20261027`).

### Ch 15 · The range of detachment

- **Asserts** — the job example's three fates: ignored, blocked by discomfort, buried (turned away from in panic and barely
  noticed).
- **Faults:** *a fear about losing work was blocked then* is a burial (finding: *blocked* used for burial); *never
  notices what would interrupt the peace* and *what is being avoided was never noticed* to be worded by finding 1.

### Ch 15 · Disregarding, and not seeing at all

- **Asserts** — the leans paragraph (caution: noticed and let alone; enthusiasm: noticed less each time, or barely
  noticed); in a burial the noticing does not happen; a fear blocked by discomfort is noticed at first and the turning
  away feels like a choice; only a blocked fear is a failure of seeing.
- **Faults:** *the noticing simply does not happen* and *cannot get at what they never noticed* (findings 1 and 3);
  *failure of seeing* (finding: discomfort blocking and seeing).

### Ch 15 · The four fates

- **Asserts** — *Blocked* opens on the aversion; blind blocking and discomfort blocking as `Job81`'s reordering; the same
  four fates meet every aversion; the two questions spelled out; only one fate leaves a person seeing less.
- **Faults:** *A buried fear never comes into view at all* (finding 1); *the person's aversion turns their attention
  elsewhere* and the placement of *every aversion* (finding: *aversion*); *seeing less* (finding: seeing).

### Ch 15 · Burial is not a decision

- **Asserts** — the threat never comes into view; a decision needs a prior noticing, so a burial is not a decision;
  discomfort blocking is different because the fear is noticed at first.
- **Faults:** at the first burial the fear is glimpsed, and what makes it no decision is that panic does the turning
  away, not the person (finding 1).

### Ch 15 · The unease loop

- **Asserts** — three sources of lasting unease: ignored aversions, blocked aversions, being less able to handle life
  than others are; blocked aversions cause the third; only a skill for handling fear changes whether a fear is blocked,
  of either kind.
- **Faults:** *With buried material, the fear is never noticed* holds for later fears (finding 1); *Her buried fears were
  never noticed* to be worded by finding 1.

### Ch 15 · The Z+ sketch and *What previous thoughts have laid down*

- **Asserts** — the Z+ sketch's three sources and its two kinds of turning away; a fear may be glimpsed before panic turns
  the person away; as the turning away comes sooner it reaches further; burying develops gradually.
- **Faults:** *So burying develops gradually* (finding: *So burying develops gradually* — the main burial is quick, the
  layers of fear of the fear build up after, all blindly buried).

### Ch 16 · The process that produces the levels; Where a level change can happen; What a level is made of

- **Asserts** — what is buried in childhood stays buried until faced; a person falls when fears are blocked, each taking a
  little of the person's noticing; Levels 1 to 6 mostly discomfort blocking, which leaves no blindness; blindness only
  from burial, earlier blindness at every level.
- **Faults:** none. *What a level is made of* agrees with the 10-28 ruling (relay `20261028`); *desire* in the Levels
  chapter to be checked against the one-name rule (relay `20261027d`).

### Ch 17 · What actually descends; What falling takes from capacity; Why this does not take everyone to the bottom; What reaches someone who cannot see their own condition; Rising

- **Asserts** — each fear blocked takes a little of the seeing; both kinds of blocking named at each site of what a person
  can bear; the third source of stress is being less able to handle life than others are; how often a fear gets handled
  instead of being blocked.
- **Faults:** *takes a little of the seeing* → *noticing* (finding: seeing); the third source's cause, both from blocked
  aversions (finding: two causes).

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **a buried fear**.

## UPDATED 2026-10-29 by `Job93 coherence 20261028`

Run against `BOOK2-20261028.md`, cut by `job92 drafting 20261027`. Everything ruled in this session, and every site, is
in `FINDINGS-job93-20261029.md`; the three updates `Job81` sent to this session are `RELAY-from-job81-20261029.md`,
`-20261029b.md` and `-20261029c.md`. **This block gives the current state of every unit `Job92` changed, and of the one
unit this session found faulty that `Job92` did not touch.** The entries were made from the text. Where a unit carries a
fault ruled in this session, the entry names the finding by its subject; the text is not yet repaired.

### Ch 4 · The Three Orientations — amends earlier entries

- **Asserts** — attraction and aversion are the two directions a person can be drawn; liking and disliking are only felt
  and need not motivate; a want is what motivates a person to bring something about, raised by an attraction or an
  aversion; a fear is an aversion to something that might happen, arising from an attraction or an aversion; every fear
  has a want behind it; after a panic, the automatic turning away from fears about the same matter is denial, which comes
  before a later fear is noticed; turning away eases the anxiety, unnoticed, and the easing holds the turning away in
  place; what was turned away from cannot be found by deliberate looking, can come back into view by itself, and intuition
  can act on it; a person notices something only when it bears on something they want or fear.
- **Faults:** the panic is placed at the enthusiasm end (finding: Chapter 4 places the panic at the enthusiasm end).

### Ch 7 · The two faces of detachment

- **Asserts** — a fear more than the person can bear brings panic at the caution end; the want to be rid of the fear carries
  the person to the enthusiasm end, where the fear is no longer noticed.
- **Faults:** none.

### Ch 14 · Where a fear meets its fate; One thought, step by step

- **Asserts** — only blocking leaves a person noticing less; a pain usually raises the want to be rid of it, a pleasure
  often raises the want for more; a want is what motivates a person to bring something about.
- **Faults:** none.

### Ch 15 · The range of detachment

- **Asserts** — the job example's three fates: ignored, blocked by discomfort, and buried after growing until panic turns
  the person away; a fear about losing work buried years before; the blindness comes about when panic buries a fear more
  than the person can bear; what is avoided is no longer noticed; a burial crosses the detached phase, panic at the caution
  end, turning away completed at the enthusiasm end; a person leaning toward enthusiasm notices less and less of what would
  interrupt the peace.
- **Faults:** none.

### Ch 15 · Disregarding, and not seeing at all; The four fates; Burial is not a decision

- **Asserts** — in a burial the fear grows until panic turns the person away, and panic, not the person, does the turning
  away; later threats are turned away from before they are noticed; intentional access to what was buried is blocked; in
  discomfort blocking the person does the turning away; denial is the effect of a burial; a fear is usually buried only
  after it has come up repeatedly and grown; the same four fates meet every aversion; only a blocked fear is a failure of
  noticing.
- **Faults:** the fate the fear meets before the panic is not stated (finding: what happens to the fear before the panic).

### Ch 15 · The unease loop

- **Asserts** — the bodily tension builds every turn (house-sale example); the buried fears are no longer noticed (migraine
  case); a burial is felt though the buried fear is no longer noticed; with buried material the fear is never noticed.
- **Faults:** *the tension builds every turn* (finding: does the tension build in the unease loop); *never noticed* (finding:
  *With buried material, the fear is never noticed*).

### Ch 15 · The Z+ sketch and *What previous thoughts have laid down*

- **Asserts** — the buried fear is no longer noticed; a fear comes up repeatedly and grows until panic turns the person away;
  the main burial is quick, perhaps within a week; layers of fear of the fear follow, each buried, each bringing the
  turning away sooner.
- **Faults:** the week to be read from the panic (finding: what happens to the fear before the panic, `[C]` decision).

### Ch 16 · The process that produces the levels

- **Asserts** — *want* throughout, with Riso and Hudson's *desire* named once; the discomfort of the fear turns the person's
  attention from the connection; descent is fear turned into want.
- **Faults:** none.

### Ch 17 · What actually descends; The second way down; What falling takes from capacity; Two things that cannot happen; Rising

- **Asserts** — each fear blocked takes a little of the noticing; blocked aversions lead to things going wrong unexpectedly
  and to reactions not thought out, together leaving a person less able to handle life than others are; a drop is made
  blacked out; the climb crosses in full sight instead of blacked out.
- **Faults:** *blacked out* at both sections (finding: *Two things that cannot happen*).

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **a buried fear**, from its growth
before the panic.

## UPDATED 2026-10-29 by `Job95 coherence 20261029`

Run against `BOOK2-20261029.md`, cut by `job94 drafting 20261028`. Every site is in `FINDINGS-job95-20261029.md`. **This
block gives the current state of every unit `Job94` changed, and of the three units this session found faulty that `Job94`
did not touch.** The entries were made from the text. Where a unit carries a fault found in this session, the entry names the
finding by its subject; the text is not yet repaired.

### Introduction

- **Asserts** — the three are orientations and the two are realms; three in each of two gives the nine types.
- **Faults:** the author speaks as *My proposal is that…* (finding: the Introduction still speaks as the author).

### Ch 2 · The Common Thread Between the Types

- **Asserts** — every type's self-image is a story built around a survival strategy that once made sense.
- **Faults:** *how we see ourselves* (finding: the Introduction still speaks as the author, same sweep).

### Ch 3 · The Two Realms; Ch 4 · The Three Orientations — amends earlier entries

- **Asserts** — the psychic realm is what happens in a person's mind; only the same three orientations are possible toward
  the content of each realm, stated plainly; a fear grows until panic turns the person away; the panic happens at the caution
  end, where the fear is still in view, and the turning away is completed at the enthusiasm end; the automatic turning away
  after that is denial.
- **Faults:** none. The panic fault the 10-29 `Job93` block named is repaired.

### Ch 5 · Where the Types Come From; Ch 6 · The Grid; Ch 9 · Relational Dynamics

- **Asserts** — the nine combinations are the nine Enneagram types, stated plainly; a person with the same orientation on
  both sides seems to have only ever noticed one way; in every position except Equal and Identical there seems to be an
  unevenness in perceived capability.
- **Faults:** none.

### Ch 13 · The imaginary self; Ch 14 · Underneath the Cycle

- **Asserts** — the self seems to be what a capacity built for tracking other minds produces when turned on the mind doing
  the tracking, with researchers on both sides named; a passage is the move from one phase to the next.
- **Faults:** none.

### Ch 15 · The range of detachment

- **Asserts** — in detached people the competence seems to be the ability to notice more, and the characteristic failure
  seems to be not noticing what would disturb a person's peace; the job example's fears are ignored, blocked by discomfort,
  or buried after growing until panic; each fear meets one fate.
- **Faults:** the buried group is set apart from the ignored fears and the fears blocked by discomfort (finding: the job
  example sorts the fears into groups that never meet).

### Ch 15 · The unease loop

- **Asserts** — the unease loop is the round of a fear, bodily tension, a want to be rid of the tension, and a new fear;
  every turn leaves a little bodily tension, kept up while the matter stays unresolved and able to build only when the turns
  come close together; with buried material the fear is no longer noticed; a habitual fear is noticed every time.
- **Faults:** *the fear* reads as the habitual fear (finding: two sentences in a row say a habitual fear is not noticed and
  is noticed).

### Ch 15 · The hinge; What previous thoughts have laid down

- **Asserts** — a fixation seems to be a strategy that outlived its problem; the conscious person seems to be pressed to give
  the feeling what it demands; a fixation seems to be a habit, a shape the mental deposits have taken; before the panic the
  fear has usually been ignored or blocked by discomfort, coming back stronger each time; once the person has panicked, the
  main burial happens quickly, perhaps within a week.
- **Faults:** none. The week fault the 10-29 `Job93` block named is repaired.

### Ch 16 · The Health Axis

- **Asserts** — depth of fixation was matched to Riso and Hudson's levels by reading their descriptions, not by watching
  people.
- **Faults:** none.

### Ch 17 · What falling takes from capacity; Two things that cannot happen; Rising

- **Asserts** — a detached person under stress seems to stop disposing of arriving fears; an enthusiastic person under
  stress seems to stop short of acting; a person may feel the discomfort of a fear, or the panic, at the moment of turning
  away, but does not notice the going down; a fall cannot bring insight, since every step takes something from what a person
  notices; a climb happens in the detached phase, as a fall does, and in a climb a blocked fear comes back into view and is
  faced; giving up on ignored aversions is the way out most within a person's reach.
- **Faults:** *the way out* reads as a way up (finding: *Rising* now calls two different things a way out). The *blacked
  out* fault the 10-29 `Job93` block named is repaired.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **bodily tension**, and on **the
author's own voice** across the body of the book.

## UPDATED 2026-10-29 by `Job97 coherence 20261029`

Run against `BOOK2-20261029b.md`, cut by `job96 drafting 20261029`. Every site is in `FINDINGS-job97-20261029.md`. **This
block gives the current state of every unit `job96` changed.** The entries were made from the text. No fault was found in
this session.

### Ch 1 · A New Theory of the Enneagram — replaces the 10-29 `Job95` entry filed under the Introduction

- **Asserts** — the three are orientations and the two are realms, stated plainly; three in each of two gives the nine types.
- **Faults:** none. The author-voice fault the 10-29 `Job95` block named is repaired. That block filed the sentence under the
  Introduction; the sentence is in Chapter 1's second paragraph.

### Ch 2 · The Common Thread Between the Types

- **Asserts** — the gap between how we see ourselves and how we actually move through the world is not a flaw; the *we* is
  general and stays, on `[A]`'s scoping of the 10-28 ruling.
- **Faults:** none.

### Ch 15 · The range of detachment

- **Asserts** — the job example's fears are ignored, or blocked by discomfort, or ignored or blocked several times and coming
  back stronger each time, until one fear is more than the person can bear and panic buries the fear.
- **Faults:** none. The fault the 10-29 `Job95` block named (the job example sorts the fears into groups that never meet) is
  repaired.

### Ch 15 · The unease loop

- **Asserts** — with buried material the buried fear is no longer noticed; a habitual fear is noticed every time and worked
  through every time.
- **Faults:** none. The fault the 10-29 `Job95` block named (two sentences in a row say a habitual fear is not noticed and is
  noticed) is repaired.

### Ch 17 · Rising

- **Asserts** — giving up on ignored aversions is the way out of lasting unease most within a person's reach; a better
  distraction is never a way out.
- **Faults:** none. The fault the 10-29 `Job95` block named (*Rising* calls two different things a way out) is repaired.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **how a fear comes to be buried**, and on
**a way out**.

---

## UPDATED 2026-11-01 by `Job101 coherence 20261101`

Run against `BOOK2-20261030.md` (md5 `88d97cff`, 45,230 w), cut by `job100 drafting 20261030`. Every site is in
`FINDINGS-job101-20261101.md`. **Chapter numbers moved:** `job100` added *What Becomes of a Fear* as chapter 15, so the old
Ch 15 *The Fixations Themselves* is now Ch 16, the old Ch 16 *The Health Axis* is Ch 17, and the old Ch 17 *Falling and
Rising* is Ch 18. Entries above keep the numbers they were written under. Sections that moved: *Disregarding*, *The four
fates*, *How a fear comes to be buried*, *Burial is not a decision*, *The blindness loop*, *The unease loop* and *Lasting
unease* are now in Ch 15; *Spoiled arrivals*, *Two things that cannot happen* and *The last stretch* are in Ch 18; *The
second way down, which is not blindness* is now *Discomfort blocking and the fall*.

### Ch 7 · The Cycle — head

- **Asserts** — there is an order among the three orientations; the classical directions of integration and disintegration
  correspond to the order, integration with it and disintegration against it. **New:** because a type is a pair of
  orientations, the order predicts the classical directions for each of the nine types — on every classical line, growth is
  one step forward along the order in one realm or both, stress one step back — and the classical Enneagram gives no reason
  for its lines. **Asserted** here, **shown** at Ch 10 *The Figure's Own Lines*. Register 3 (correspondence).
- **Checked:** all nine types by hand; 1→7, 7→5, 5→8, 8→2, 2→4, 4→1 forward in one realm; 3→6, 6→9, 9→3 forward in both.
  Holds. The 09-15 condition (*If the classical Enneagram is right*) is gone, on `[A]`'s 11-01 ruling.
- **Faults:** none.

### Ch 8 · Relational Positions — head

- **Asserts** — ahead is a position on a circle, and the circle comes from the order. The condition on the classical
  directions is gone.
- **Faults:** none.

### Part 3 opening

- **Asserts** — every thought runs through three phases; attention concentrated at one phase shows the fixation; depth is
  measured by the Levels; a person falls when a fear is turned away from where a thought finishes, and rises when a blocked
  fear is faced there.
- **Faults:** none.

### Ch 14 · Underneath the Cycle

- **Asserts** — beginning, middle and end name the three passages; the detached phase is split into a caution end
  (overlapping the ending) and an enthusiasm end (overlapping the arising); a fear is settled only at the caution end, and a
  fear not settled meets its fate at the enthusiasm end; only blocking leaves a person noticing less.
- **Faults:** (1) five sentences place every fate *at the ending* — finding 1; `[A]` 11:47 agreed to *in the detached
  phase*. (2) *The phases and their names* says letters are never used for a phase, which his 10-30 ruling supersedes for
  Part 3; owed to the letters pass.

### Ch 15 · What Becomes of a Fear (new chapter)

- **Asserts** — the leans decide how a fear is left unsettled (leaning toward caution: noticed and let alone; leaning toward
  enthusiasm: usually ignored, then forgotten, and a fear uncomfortable to look at noticed less each time, until one grows to
  panic); a process reaches the detached phase at the caution end and leaves by the enthusiasm end; discomfort blocking is
  found uncomfortable at the caution end and the turning away happens at the enthusiasm end; a burial crosses the detached
  phase the same way; the unease loop and lasting unease as before.
- **Faults:** none new. Finding 4 (a person placed at or near an end) is held for `[A]`.

### Ch 16 · The Fixations Themselves — *The range of detachment*; *Which fixation handles a fear*

- **Asserts** — before the detached phase a fixation changes how much examining is done; everybody handles fears in the
  detached phase; every process passes the caution end then the enthusiasm end; what separates people is the attention given
  each end; the account for each of the four fixations.
- **Faults:** one sentence in *The range of detachment* is in finding 1 (*left unattended at the ending*).

### Ch 18 · Falling and Rising — *Why this does not take everyone to the bottom*; *Rising*

- **Asserts** — the routing is decided by comparing the pain of staying with the imagined pain associated with facing buried
  material; when a person does face, the pain of staying drove it; the pain of life not working is named in *Rising*; fear
  and pain are coupled and can be taken one at a time.
- **Faults:** (1) *the same comparison* with two different first terms — **dissolved** by `[A]`'s 11-01 ruling (relay
  `RELAY-from-job99-20261101c.md`) that the two pains are one thing, *the pain of life not working*; the rename is owed. (2)
  *one rung at a time* against *a full level takes many* — `[A]` 12:45 agreed to cut it.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **the fear in the job example** and on **a
fear raised by a cautious fixation**.

---

## UPDATED 2026-11-01 by `Job103 coherence 20261101`

Run against `BOOK2-20261101.md` (md5 `148dcb9d`, 45,342 w), cut by `Job102 drafting 20261101`. Every site is in
`FINDINGS-job103-20261101.md`. Chapter numbers as in the `Job101` block.

### Ch 14 · Underneath the Cycle; Ch 16 · *The range of detachment*

- **Asserts** — as in the `Job101` block. Every fate is now met *in the detached phase*.
- **Faults:** the `Job101` block's fault (1) is **discharged**: the five sentences say *in the detached phase*. Fault (2),
  letters never used for a phase, is still owed to the letters pass.

### Ch 15 · *The unease loop*

- **Asserts** — the way out is taken when *the unease* becomes the worse pain than doing what the way out requires.
- **Faults:** none.

### Ch 18 · Falling and Rising — *Why this does not take everyone to the bottom*; *What reaches someone who cannot see their own condition*; *Rising*

- **Asserts** — the pain that consequences bring is called the pain of life not working: a person's life not working the way
  other people's lives do, in either realm, because the cause is in what the person does not see; it is the one name, and
  the staying side of every comparison but the unease loop's; *staying* names the choice; the work of rising is one buried
  fear faced in one crossing of the detached phase.
- **Faults:** the `Job101` block's faults (1) and (2) are **discharged**. **New:** the explaining paragraph says that in the
  psychic realm *nothing outside pushes back*, against the section's *Consequences do.*, which counts *the person who left*
  as pushback at every depth. `[A]` 16:25: *a person leaving can have a psychic effect.*; 16:26 *yes* to taking *pushes
  back* out of both realm sentences. Owed to drafting.

**Tests (a) to (d) were not re-run across the book.** The tracking check was run on **the pain of life not working**.
