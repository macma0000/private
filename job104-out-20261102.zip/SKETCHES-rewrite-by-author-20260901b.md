# The four sketches — `[A]`'s rewrite, 2026-08-31, amended 2026-09-01

**STATUS, 2026-09-01: this file is the VERBATIM RECORD and is NOT the text to place.** The seven
changes at §2 and the typos at §3 are applied in **`SKETCHES-APPLIED-20260901.md`**, cut by
`job37-drafting-20260901`, together with two further changes `[A]` ruled in that session —
`if he acts` to `if they act`, and the removal of the five phase letters. **§1 below is left exactly
as he typed it and must stay that way.**

**SUPERSEDES `SKETCHES-rewrite-by-author-20260831.md`, cut 2026-08-31. Quarantine the parent as
`SUPERSEDED__live__`.** One surgical change, **not a retyping**: `Job36 doctrine 09012026` applied
`[A]`'s 09-01 ruling cutting the retracted arisings clause from §2 item 7's closing paragraph, and
recorded the ruling under it. **`[A]`'s draft at §1 is untouched.**

**Authored by `[A]` in the Job33 session, pasted into chat. NOT PLACED. Not in book 1, not in
book 2.** Book 1's originals at `rev2-0814m.md` are deprecated in favour of this; see the mark above
the lead-in sentence there.

**`[A]` ruled the same day that book 1 is not being fixed — it is a reference for writing book 2.**
So this text is not book 1 copy. **Where it goes is an architecture question**, and the live form of
it is: does book 2 carry the sketches at all, and in which chapter? Book 2 currently has no
walked-through endeavor anywhere and **no arc notation at all** — `(A)`/`(B)`/`(Z)` runs 17 times in
book 1 and 0 times in book 2 — so placing them means adopting the notation, which is itself a
decision.

---

## 1. `[A]`'s draft, verbatim as pasted

*The lead-in below is retained from the old text unchanged and `[A]` kept it.*

> The difference between the fixations shows plainly if the same endeavor is walked through in each. The sketches are loose by intention — they describe a person, not a rule — but the shape of each is exact.
>
> An enthusiastic person's (A) fixation sits at the active stage of hope: an impulse arises the moment the previous pursuit ends. Enthusiasm is that person's place of comfort. When the endeavor runs into trouble, whether when being thought through or in execution, the tendency of the cautious stage is to judge that it is too difficult and the detached resolving stage often decides to drop it completely. The detached arising stage is then free to initiate another endeavor unless anxiety gets past the resolving stage.
>
> A cautious person's (B) fixation sits at the active stage of fear: an impulse arises, is recognized as attractive and moves quickly to examination for threats.
> The motion toward it is eager — the examination is the cautious persons place of comfort. They generate alternatives, see the flaw in each and generate more. The ending often comes late and under duress: forced by need or exhaustion, the worry or fear moves into the detached resolving stage which may resolve or drop it, or let it pass to the next stage. If anxiety arrives at the detached arising stage, it is buried and a new endeavor is initiated.
>
> A person detached on the resolving side (Z−) runs the whole arc, but quickly and at low amplitude. What arises is mild — a small disturbance, noticed. The person is moved to consider addressing it (A), weighs what that would take (B), and decides (Z): sometimes that it is not worth the trouble, sometimes to act. Often the ending is a genuine decision, because the weighing was done — and if he acts, the action begins a new arc inside the decision. But, the less cautious the lean, the more likely anxiety passes on to the detached arising stage, it is buried and then a new endeavor is initiated.
>
> A person detached on the arising (Z+) starts from the vacuum the stage itself creates: boredom. An impulse toward something enjoyable arises (A) and goes straight to action. The person stays in action only while it is comfortable. When the comfort thins, sooner that for the (A) fixation, the weighing does happen (B) — but it is brief and it is unpleasant, and what it decides is to abandon rather than to resolve: a small discomfort now against the larger one that staying would cost. The resolving detached stage is short and ineffective. Before long a new impulse arises, usually for a related alternative: the same fun by another route. Each drop seems to be a clean ending and each new pursuit a fresh start. What the drop does not do is answer anything, so the boredom it returns again. The drop, however, is not always clean. Any anxiety that is dropped is buried and accumulated and buried anxiety continues to cause stress even though it is not consciously seen.

---

## 2. Changes `[A]` approved in the same session — AGREED, AND NOW APPLIED IN `SKETCHES-APPLIED-20260901.md`

**Not applied above, and deliberately so: §1 is the verbatim record.** Item 1's revert reads
`Z−`/`Z+`; on 2026-09-01 `[A]` ruled that a letter marks where a person stands and never a phase, so
in the applied file the revert gives letters only at the two sketch openings, which name a person's
position, and describes the ends elsewhere.

Each was put to him singly and approved. **Apply these when the text is placed.**

1. **`resolving` / `arising` revert to `Z−` / `Z+`.** He renamed the two faces, then ruled the new
   names out: both are arc words. `arising` is the arc's A-moment (22 uses in book 1, one of them two
   lines from the new name), so *arising detachment* reads as detachment at the arc's beginning, the
   opposite of where Z+ sits; every completing arc ends in `resolution`, so *resolving detachment*
   names something all detachment does. **The plain gloss the books already carry is seeing face /
   blind face and sighted side / blind side** — by sight, which is the ruled criterion. Nothing new
   is needed.
2. **`stage` becomes `phase`.** `stage` is not in book 1 in this sense; **book 1 line 590 already
   says the phases of initiation, continuation and finishing correspond to A, B and Z** — a place on
   the arc, distinct from `orientation` (way of attending) and `stance` (position held). `moment` is
   a point, and these need a span.
3. **`buried` becomes `unattended`** wherever it spans both fates — the cautious sketch, the Z−
   sketch, and *any anxiety that is dropped*. `unattended` is the genus over **ignored** (in view,
   returns) and **blocked** (never seen, descends), it is already in both books twice each doing this
   job, and it sits on the ruled definition of a fixation. **The last clause stays the blocked
   species:** *continues to cause stress even though it is not consciously seen*. Using the genus also
   removes the automatic-burial reading, which would contradict the 08-30 retraction — Z+ disposes of
   fears unwisely, the loop is real but not necessarily usual.
4. **Cut *because the weighing was done*** from the Z− sketch. That is the criterion `[A]` replaced
   on 08-27: the clear side is defined by sight, not by the examination having completed. The
   sentence should say the ending is genuine because the fear was in view.
5. **Restore the enthusiastic person's signature, minus one clause.** The old text's *endings are
   never inhabited at all; each resolution is overwritten by the arising that replaces it* is the only
   thing in the old sketch not restated in the new one, and it is what keeps the enthusiastic person
   distinct from Z+ — one arrives at the ending and does not stay, the other does not arrive.
   **`[A]` ruled out *or before it ends*:** an arc cut off mid-flight has not completed, so there is
   no resolution to overwrite. Keep the overwriting, drop that clause.
6. **The returning boredom.** *so the boredom it returns again* is a broken sentence produced by
   removing gendered pronouns from *the boredom it returns him to is the boredom he began with*.
   **`[A]`'s intent was only to drop the pronouns.** Suggested: *so the boredom comes back
   unchanged* — no pronoun, and *unchanged* carries the closed circle.
7. **The closing paragraph goes back in, rewritten.** `[A]` deleted it, then approved this
   replacement. It is needed because the new sketches walk the phases in order, which invites a reader
   to conclude the fixation is one of them:

> Two things repeat across the four. What arises differs — a fresh impulse for the enthusiastic person, an attraction for the cautious one, a mild disturbance on the seeing side, boredom on the blind side. Where the arising is the same, the difference falls later: the enthusiastic person is at home in the impulse and the cautious one in the examination, and each endeavor rests longest where its person is comfortable. Either way the fixation is at work before the endeavor's own shape can account for it.

   **AMENDED 2026-09-01 BY `[A]`'s RULING — a retracted clause is CUT from the paragraph above, and
   the paragraph as printed above is the ruled form.** What was cut, in full:
   ` — and where it differs, the fixation has selected the population of arisings before any endeavor begins.`
   The list of what arises for each of the four now takes a full stop and nothing else changed.
   **Why:** that is the selecting-the-population claim `[A]` retracted on 08-20 — *i don't/no longer
   agree* — and ruled deleted whole from book 1's Z+ sketch on 08-26. The retraction removed the
   exclusivity, not the influence; `selected … before any endeavor begins` is the exclusive-and-prior
   form. **Nothing replaces it**, because the paragraph's last sentence — *Either way the fixation is
   at work before the endeavor's own shape can account for it* — already carries the point in the
   weaker form he kept, and *either way* still reads correctly across the two branches that remain.
   *The clause was carried forward from the old closing paragraph, which stated it in the same words
   and is deprecated; nothing here is a criticism of the rewrite.*

   *The old closing paragraph listed threats as what arises for the cautious person. `[A]`'s rewrite
   changed that — the cautious person's arising is an attraction, turned into a threat by
   examination. **The selection claim that observation was narrowing is now cut**, so what remains is
   the move of the enthusiastic/cautious difference to which phase each settles in, which the
   paragraph states.*

---

## 3. Uncorrected typos in `[A]`'s draft, listed and not fixed

`persons` → `person's`; `sooner that for` → `sooner than for`; `the boredom it returns again` — see
item 6, which is the substantive form of the same break.
