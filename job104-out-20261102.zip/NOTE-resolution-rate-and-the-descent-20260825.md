# TWO OPEN DERIVATIONS — resolution rate, and fuzzy fixation position

**Entry A — Resolution rate as the descent quantity** (§0–§8)
**Entry B — Fixation position is fuzzy everywhere** (§9)
**Entry C — What abandonment leaves: the vague self-referential fear** (§10)
**Entry D — TASK: does the climb differ by fixation?** (§11) — a question to attempt, not a position

Entries A and C are two halves of one mechanism. A gives the *rate* (how many fears arrive at Z
undismissed); C gives what an arriving one *is* and why it compounds. Read together.

---

# ENTRY A: RESOLUTION RATE AS THE DESCENT QUANTITY

**Generated:** 2026-08-25, in job16 `book 1 defects` (job 3, a repair session).
**Status: OPEN. Nothing here is ruled.** A repair session may not write doctrine, so none of
this has been applied to any text. It is written down so a doctrine session can take it up with
the author record properly in its set.

**Provenance warning.** `[A]` said of this material *"I said something like that already."* The
author record was NOT in this job's set and was NOT read. Everything below is reconstructed from
one session's conversation. **A doctrine session must locate the prior statement in the record
before ruling any of it** — the record's version is the source, this note is not.

---

## 0. WHAT PROMPTED IT

`[A]`, on whether the blindness mechanism explains Riso's Levels:

> i'm not sure whether the blindness mechanism is a correct explanation for riso's levels. i can't
> see a better one. what do you think?

Two objections were raised against blindness in reply, and `[A]`'s next message answered both.
The answers are §2 and §3 below. `[A]` has NOT ruled that blindness explains the Levels; the
question he asked remains open. What follows removes two obstacles to it, which is not the same
as establishing it.

---

## 1. THE PRIOR SPLIT THIS RESTS ON — also unruled

`[A]`, earlier in the same session:

> i think only conscious arcs nest. unconscious arcs leave emotional residues so there are no
> stacked arcs to finish - but there is emotional residue that needs to be faced and dissolved.

Two routes down, each with its own way back: a stack of open arcs is finished; a deposit is faced
and dissolved. **Vocabulary collision to settle before this is written anywhere:** `residue` is
already the neighbour trace and is on the two-jobs list; `deposit` is the ruled word for what an
ending leaves (note of 08-21 §3). A third sense of `residue` should not be minted.

---

## 2. THE SCOPE PROBLEM, AND ITS DISSOLUTION

**Objection raised.** The blindness loop is detachment's. Routing every type's descent through
detachment makes detachment structurally privileged going down — mirroring the way Z− looked
privileged going up — which reads as detachment absorbing work belonging elsewhere.

**`[A]`'s answer:**

> it's possible that many of B's fears are resolved before completing the cycle through Z in which
> case no blindness. only the unresolved one count. But A's fears are rushed through B because A
> just gives up. the fear is something more is happening that i want to think about so those arcs
> aren't resolved. Of course A sometimes does proper B, probably depending on A's lean.

**The dissolution.** Every fear runs the cycle regardless of fixation. What differs by fixation is
**how many arrive at Z still unresolved**. Detachment is therefore not the gateway to descent but
the **accounting point** — the place the count is taken, with the count set upstream by the
fixation. The privilege was an artifact of describing the mechanism at the wrong end.

**The quantity this proposes: resolution rate.** B resolves most of its fears in the examination,
so few arrive and little blindness accumulates. A resolves almost none, so nearly all arrive.
A descends faster than B not because A is nearer to blindness but because A's resolution rate is
lower. Same mechanism, different throughput — quantitative and located, rather than a difference
in kind.

**New content in `[A]`'s A account.** The 08-21 note §4.2 had A jumping over fear, resolved from
Riso, and was explicitly *about the route, not about people*. `[A]` has now given the **content of
what is jumped over**: *something more is happening that I want to think about*, and A will not
stay for it. That is a fear **about the examination itself**, not about the thing feared — which
is why book 1 can say enthusiasm has no native response to negatives: the negative is never the
object. **Not believed to be stated anywhere in either book. Check the record.**

---

## 3. OVERLOAD — THE SECOND ROUTE, AND THE HYPER-VIGILANCE CASE

**Objection raised.** A cautious person low on the axis is not obviously unseeing — they are
vigilant, threat everywhere, awareness turned up rather than down. If blindness is the descent
quantity, that case must be handled. Handling it as *blind to the fear itself while vigilant about
its proxies* is a patch fitted to an awkward case, not a prediction.

**`[A]`'s answer:**

> Ye.s B can be blind. B can also be overloaded - and that's an unresolved passage to Z.

**Why this is not a patch.** Overload is a second branch of the mechanism, supplied from `[A]`'s
side rather than fitted to the objection. The vigilant cautious person sees so much that the
weighing cannot close; what does not close arrives at Z undismissed. Blindness accumulates in
someone whose visible mode is heightened awareness, with no contradiction — the fear is unresolved
because the examination was **overwhelmed**, not because it was skipped.

**The objection is withdrawn.**

**The symmetry the two routes amount to:** *A does not stay long enough; B stays too long; both
deliver the same undismissed fear to Z.* Enthusiasm underruns the examination, caution overruns it.
Neither closes it.

---

## 4. WHERE THIS CONNECTS — the earlier pasted passage

From the author record, pasted by `[A]` this session, on where the anxiety's fate is decided: the
anxiety travels the cycle regardless of fixation; its fate is decided at the **transition into Z**;
a clean transition discharges it, an overwhelm reaction lets it survive; surviving to Z− with sight
it may be caught and dissolved, surviving to Z+ it goes into blindness; and what sits in blindness
is **stable**, which explains both A's apparent lack of fear and the stability of core fears.

§2 and §3 are the same picture with the count made explicit. **Note that `[A]`'s word there was
already `overwhelm`** — §3's `overloaded` is very likely the same idea, which is one specific place
the record must be checked rather than this note trusted.

**The bridge this makes available** (flagged in-session as a reading, not as `[A]`'s claim): an
anxiety that survives its transition undissolved becomes a **stable hidden fear**, and a stable
hidden fear is what Appendix G's chain calls F(n), which generates the desire of the level below.
The chain already runs on fears and desires; this would say where its fears come from. **This is
the bridge from the arc machinery to the fear layering that book 1 asserted and never derived** —
the assertion that was struck from Ch 15 this session.

**Self-correction to carry:** the pasted passage's line *fixation in A - no anxiety, just release*
is overturned six lines later by *that would explain A's apparent lack of fear* — **apparent**. If
the passage is cited as support, the first line must be marked as the naive version or it will be
quoted against the §4.2 narrowing.

---

## 5. WHAT BLINDNESS DOES AND DOES NOT EXPLAIN — the framing offered

Offered in-session as `[C]`'s view, not ruled:

- **Riso's cascade** (fear evaded → desire to escape it → that desire breeding its own fear)
  explains **content and order** — why level n's desire is that particular thing and why it sits
  below level n−1. A quantity cannot do this.
- **Blindness** explains **why down is worse** — which the cascade cannot. Nothing in
  "fears breed desires breed fears" makes the tenth link worse off than the second. The health
  axis is an axis of seeing; App G's self-obscuration rule is already a blindness claim, not a
  cascade one; and the mobility asymmetry (descent funded by unwatched reaction, ascent consuming
  the faculty descent degrades) is blindness doing work no cascade can do.

**So: blindness may not be the explanation of Riso's Levels, but the explanation of why they are
levels of *health* rather than merely a sequence. The cascade gives the ladder its rungs;
blindness gives it its direction.** `[A]` has not ruled on this framing.

**Also noted in-session:** *I can't see a better one* is weak grounds for holding a mechanism, and
was the reason the now-dead nesting depth reading survived as long as it did.

---

## 6. THE TWO GAPS

**6.1 Lean as the modulator.** `[A]`: *A sometimes does proper B, probably depending on A's lean.*
This makes resolution rate a **wing-scale quantity** and would tie descent rate to the leans — a
large connection, only sketched. Interacts with the ruled-but-unapplied numeric lean values in
Ch 11 and with the wing-scale clause in the handoff's §5.

**6.2 Overload needs a non-circular threshold.** At present the only mark of an overwhelmed
examination is that it did not close, and the only consequence is that it did not close. Until
overload has an independent mark, it explains the hyper-vigilance case by naming it. This is the
weakest joint in §3 and should be attacked first.

---

## 7. WHAT THIS DOES *NOT* SETTLE

- **The count.** *Many nestings per level* — `[A]`'s ground for killing the nesting depth reading —
  is untouched by anything here. That claim is about the **conscious/nesting** route; all of §2–§3
  is the **deposit** route. Still unanswered from this session: whether the count is **ruled** or a
  **working position**.
- **Whether nestings lead to fear layering at all.** Asked this session, answered honestly as *the
  book does not have that account*. §4's bridge is a route to layering via the deposit side, not
  via nesting. Enthusiasm remains the test case: it has no nesting whatsoever (the next impulse
  overwrites the last) yet descends like anyone else — which on §2 is now expected rather than
  anomalous, since A's descent runs entirely on unresolved passage.
- **Whether blindness explains the Levels.** `[A]`'s original question. Two obstacles removed; the
  question stands.

---

## 8. FOR THE DOCTRINE SESSION — order of business

1. **Find the prior statement in the author record.** `[A]` believes he has said this before.
   Reconcile; the record wins over this note everywhere.
2. Rule or reject **resolution rate** as the descent quantity (§2).
3. Rule or reject **overload** as the second route (§3), and give it a non-circular mark (§6.2).
4. Decide the **vocabulary** before any of it is written: the third sense of `residue` (§1).
5. Only then consider the **F(n) bridge** (§4) — it is the largest claim here and rests on 2 and 3.

---

# ENTRY B: FIXATION POSITION IS FUZZY EVERYWHERE

## 9.1 What `[A]` said

Arising from the Ch 11 repair, where a draft clause read *at Z+ it is complete*:

> we talked about the Z-/Z+ divide having a width. […] that's a way of saying the fixation's
> position is fuzzy. so "at Z+ it is complete" make me uncomfortable.

Asked whether the fuzziness belongs to Z specifically or to fixation position everywhere:

> everywhere. it's just less obvious.

**Status: stated by `[A]`, not ruled.** No text has been changed on the strength of it.

## 9.2 The distinction that matters

`[C]` had first read the width as a property of the **arc** — a stretch near the end rather than a
point. `[A]`'s reading is a property of the **fixation**: a person is not located *at* a position,
they occupy a fuzzy region near it. A range may have a definite endpoint; what it cannot have is a
person standing exactly on it. **The trouble with a terminal clause is not that it names an extreme,
but that it puts a person there and reports their state.**

## 9.3 Effect on the Ch 11 repair — none outstanding

The drafted repair now describes a **gradient with no endpoint state**, and lets the book's own
existing phrasing carry position by *leaning* rather than standing (*the same 9 leaning Z+*). It
therefore says strictly less than the general claim and is consistent with it without asserting it.
**The Ch 11 wording does not depend on how Entry B is ruled.**

## 9.4 Three consequences flagged, none resolved

- **What a lean is.** The book currently has a lean as a position between poles — a fixation *at* B
  leaning toward A. If position is fuzzy everywhere, a lean is arguably **the fuzz being
  asymmetric** rather than a point being offset. These predict differently. **Live now**, because
  the numeric lean values in Ch 11 are already ruled and still unapplied (handoff §5), as is the
  wing-scale clause.
- **Appendix F, in the opposite direction from where it expects trouble.** App F assumes position is
  inferable from relative endorsement of neighbouring items *everywhere except near Z*, which it
  names as the exception needing dedicated Z− and Z+ item families. If fuzziness is general, **Z is
  not an exception in kind** but the place where a general fact is large enough to see — which is
  exactly `[A]`'s *less obvious* elsewhere. Arguably a better story than the appendix's, but a
  different one. App F's advance prediction of a measurable seam at Z would need restating.
- **Interaction with Entry A.** If position is fuzzy, *where a person habitually stops* is a
  **distribution rather than a place** — which fits resolution rate well, a rate being a property of
  a distribution and not of a point. **Flagged with suspicion rather than as support:** convenient
  corroboration between two unruled claims from the same session is the thing to check hardest, not
  the thing to lean on.

## 9.5 Not searched

No census has been done of sites in either book that assert a definite fixation position. Ch 11's
leans, the wing scale, App F, and Ch 5's account of where a type comes from are the obvious places
to look first.

## 9.6 Sentences that place a person exactly — four found, no sweep done

Four sites surfaced in one session, none of them on any repair list. The pattern, not the
individual sites, is the finding.

- **bk1 Ch 11**, the Z-range gradient: draft clause *at Z+ it is complete*. **Already handled** —
  the endpoint clause was removed and position is now carried by the book's own *leaning*.
- **bk2 Ch 11**, the same sentence. Same treatment.
- **bk1 Ch 16 (L1624)**: *Level 1 is not the top of the Z range but just short of it. Its stance is
  Z−*. Places a level at a position.
- **bk1 Ch 11 (L1135)**: *Z0 sits at the apex of the detachment range — the point where detachment
  is complete and the decay toward wanting has not begun.*

**The Z0 case may not be a defect, and the distinction is the open question.** Two readings, pulling
opposite ways:

- **Z0 as a defined limit** — the position where detachment is complete and decay has not begun. A
  construction, possibly not somewhere anyone stands. Book 1 supports this a few lines on: Z0 is the
  mirror's *stance*, and the stance alone is silent about whether anything is received. On this
  reading *the point where* is exactly right and softening it would blur a definition.
- **Z0 as occupied** — Ch 11 also treats it as somewhere a person is found (a doubly-detached 9 at
  the apex). Under Entry B that person occupies a region near Z0, not Z0.

**So the sentence may conflate Z0-the-limit with being-at-Z0.** If so the repair is a distinction,
not a word swap. `[A]` considered *point* → *place* and `[C]` advised against it: the softer word
papers over the question rather than settling it, and *sits at* plus *the apex* does the locating
regardless.

**`[A]`'s question, unanswered and worth answering first:** does it matter to be precise about this
that early in the book? Ch 11 is Part 2. A doctrine session should settle whether fuzziness is
something the reader needs at introduction or only at the point where it changes a prediction
(App F's item families, the lean values).

**No sweep has been run.** Four sites found incidentally; the census for exact-position language has
not been done in either book.

---

# ENTRY C: WHAT ABANDONMENT LEAVES — THE VAGUE SELF-REFERENTIAL FEAR

**Arose from:** redrawing the Ch 15 Z+ sketch after `[A]` ruled the sketch wrong (see the repairs
file, §2.4). Grew past a sketch repair into the deposit route's mechanism.

**Status: `[A]`'s, stated across four messages, NOT ruled.** Nothing applied. `[C]`'s two wrong
turns are recorded below because a later session reading only the conclusion would repeat them.

## 10.1 The chain, in `[A]`'s terms

1. **B happens for both A and Z+.** `[A]`: *"there is a B phase for both Z+ and A and it's more of
   sooner or later and more often or less than a qualitative difference, the thing being abandonment
   rather than resolution."* **This corrected `[C]`'s redraw**, which had Z+ skipping B entirely — a
   two-phase process, which Ch 5 forbids (every process makes all three passages; what distinguishes
   people is where they stop, not which passages they make).
2. **What happens in B is a quick unpleasant decision.** `[A]`: *"since B is the phase where the more
   difficult is done, it is a quick but unpleasant decision to avoid the further unpleasantness."*
   Abandonment, not resolution — a small discomfort now against the larger one staying would cost.
3. **A and Z+ are one mechanism at two settings** — sooner or later, more often or less. **Better
   than the A/Z+ discriminator `[C]` had drafted**, which asserted a difference in kind that this
   says is not there.
4. **What is abandoned is the processing of contingencies.** `[A]`'s correction of `[C]`'s *the
   failure*: what is given up is **the work B was there to do** — finding out what the failing means
   and what follows from it. An activity, so abandoning it is an act.
5. **What is left behind is a vague unresolved fear — and it is partly about the abandoning.**
   `[A]`: *"what is really left behind is unresolved fear however vague - knowing that something was
   abandoned rather than processed is something a Z+ would want not to know."*
6. **Carrying it back into Z+ territory makes more blindness. Same for A's abandonment.** `[A]`.

## 10.2 Why the self-reference is the load-bearing part

- **A fact cannot drive the loop; a fear can.** `[C]` first had the *failure* left lying around and
  the not-looking applied to it as a separate move. Wrong: per the meta ruling, detachment's
  avoidance is aimed at what **stirs**, never at content. A fact stirs nothing and gives the loop
  nothing to act on. A vague unresolved fear is exactly what §4.3 requires.
- **The avoidance must cover its own tracks.** If part of the fear's content is *that I abandoned*,
  then what must not be known is that not-knowing is what happened. **This gives the loop its second
  pull without inventing anything** — the disturbance is generated by the same act that must not be
  examined.
- **So blindness compounds rather than piling up.** Looking at any one deposit exposes the practice,
  not a single episode.
- **Vagueness is a product, not a hedge.** A fear never processed has no shape, because shape is what
  B would have given it. Hence the deposits are necessarily indistinct — which is why they cannot be
  addressed one at a time, and why the way out is *facing and dissolving* rather than *finishing*
  (Entry A §1's two routes).

## 10.3 Relation to §4.2 — CONSISTENT, and more specific

§4.2 narrowed `[A]`'s prediction: an abandoned **desire** carries nothing and is safe; a jumped-over
**fear** is what arrives undismissed. The narrowing exists because unscoped it left a Three with no
route into blindness at all.

**Entry C does not overturn it.** The desire genuinely is discharged. What §4.2 did not name is that
abandoning the *processing* leaves something else standing — and that something is the fear §4.2
calls jumped-over. **Entry C says where the jumping-over occurs and what it consists of.**

**Two readings were put to `[A]` and he took the first:** (a) the failure carried back undismissed
*is* §4.2's jumped-over fear, seen at the moment of abandonment — nothing changes; (b) §4.2's
narrowing is too tight and abandonment as such generates blindness — which would put the Three back
where §4.2 was built to rescue him from. **`[A]` confirmed (a).** Also fits his earlier statement
that A's fear is *something more is happening that I want to think about*.

**Abandonment and failure are not the same object**, though they coincide in time: the pursuit is
over the moment he leaves (abandonment, complete); what goes forward is the unprocessed fear.

## 10.4 What this fixes in Entry A

**Entry A §6.2 flagged overload as needing a non-circular mark** — at present the only sign of an
overwhelmed examination is that it did not close. Entry C supplies a mark from the other side: **the
fear's self-reference**, not the closure it lacks. Worth testing whether the same mark works for B's
overload route as for A/Z+'s abandonment route.

## 10.5 Terminology caution

***Contingencies* is colder than the surrounding prose and is a coinage in the making.** If this
becomes doctrine it wants a plainer form in the book — *what follows from it*, *what it means for
what comes next* — with the precise term kept for the derivation. Note also that `residue`,
`deposit`, and the third-sense problem from Entry A §1 are still unsettled and this entry adds
another candidate object to name.

## 10.6 What is NOT settled

- Whether the Ch 15 section can carry A and Z+ being **one mechanism at two settings**, or needs a
  line saying so outright. Judgment about the section, not about doctrine.
- Whether the redrawn Z+ sketch takes a closing sentence for the carried fear. `[C]` drafted *"The
  failure goes back with him, unlooked-at, and each one he carries makes the not-looking a little
  easier"* — **not applied**, and now superseded in substance by 10.1(5): it should be the fear, not
  the failure, and the self-reference should show.
- Whether §4.2 needs amending in the note of 08-21, or whether Entry C simply sits alongside it.

---

# ENTRY D: DOES THE CLIMB DIFFER BY FIXATION? — a task, not a position

**`[A]`, setting it:** *"try to describe differences in the way up the levels - the difficult facing
of fears - as the fixations apply to it, although there may not be any."*

**The caveat is load-bearing. A null result is a real answer here, not a failure of the attempt.**
Write it up as *no fixation-dependence found, and here is why* if that is where it lands.

## 11.1 What Riso does and does not supply — `[A]`

> i think riso's only type dependent part of the levels is the different characteristics including
> fears and desires of 9 types at 9 levels - which we don't have access to anyway.

**Two consequences, and the second is the sharper one.**

- The generating rule (fear → answering desire → next fear) is **type-independent**. What varies by
  type is the *content* at each rung — the particular fears, desires, attitudes, behaviours — and
  that content is the substance of Riso and Hudson's own book, deliberately not reproduced (Ch 15
  says so outright).
- **So there is nothing to read the answer off.** Any per-fixation account of the climb has to be
  **derived from this model**, not lifted. This removes the temptation named below before it arises.

**Note App G's own scoping**, which supports `[A]`: the model states its chains for the six
**half-types**, not the nine types, because a type is a pair of half-types and the recursion runs in
each realm separately — and it drops attitude and behaviour precisely because their value is
type-level specificity. So the model has already declined to carry the type-dependent layer.

## 11.2 The two readings to test against each other

**Toward a difference — descent already has per-fixation routes.** Entry A: A underruns the
examination, B overruns it, and each delivers the same undismissed fear to Z by a different failure.
If ascent is the reverse — doing the processing that was abandoned — then what must be overcome is
fixation-specific: **A has to stay where it will not stay; B has to stop where it cannot stop.** A
real asymmetry, and it needs no new machinery.

**Toward no difference — the book already says the climb runs on one faculty.** Seeing is not
volitional (Ch 8); the way back up is awareness of the cycle rather than another escape from the
fear (Ch 14); App G's self-obscuration rule has ascent consuming *the one faculty descent degrades*
— one faculty, not three. And **Entry C makes the deposits necessarily vague**, since shape is what
B would have given them; vague deposits may not sort by fixation at all. On this reading ascent is
the same act everywhere and only the *quantity* facing a person differs.

**Both may be true, and this is the hypothesis `[C]` would test first:**

> **The obstacle is fixation-shaped; the act is not.**

Stated as the thing to test, not as the conclusion.

## 11.3 Constraint carried from the 08-25 session

The chain and the correspondence are **different-strength instruments**: rung-level precision must be
sourced to the chain (causally derived, rung to rung, `[A]` confirmed); the correspondence gives
**four approximate sample points** and cannot support rung-level claims. **This applies going up
exactly as it does going down** — it is what killed the nesting-depth reading.

## 11.4 Depends on

Entries A and C. If resolution rate and the abandonment mechanism are rejected, the
toward-a-difference reading in 11.2 loses its basis and the task reduces to the one-faculty reading.
**Do not attempt Entry D before A and C are ruled.**
