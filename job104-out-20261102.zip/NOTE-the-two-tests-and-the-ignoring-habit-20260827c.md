# NOTE — the two tests, the ignoring habit, and what it costs the brake

**Session `Job24 doctrine 8-27`. Cut by `[C]` at the end of the session, from the session itself.**

**Does not supersede `NOTE-the-dwell-and-the-brake-20260827.md`.** That note is from earlier the same
day and stands. This one **changes one thing in it** — the brake — and §7 below says exactly what.

**Read §1 first, then §2. Everything from §4 on is derived and marked as such.**

**THIS FILE WAS CUT ONCE AND THEN RECUT.** The session cut it, cut a set, and `[A]` chose to keep
going. **§10 onward is the second half of the day** — a correction he made to the first ruling, one
new ruling, one new brake, and empirical material from outside the model. **§10.1 corrects something
§1.1 says**, so read §10 before acting on §1.

---

## 1. THE RULINGS

Two are `[A]`'s in content and were ruled in his own words. Three were assented to with a single word
against a case `[C]` built, and they are marked so, because the provenance is not the same and should
not be flattened by whoever reads this next.

### 1.1 RULED — `[A]`'s own content

**The clear side of detachment is defined by sight.**

> the clear side of detachment is defined by sight - i think a fear seen might be later ignored but
> not buried.

Not by the examination having completed. This replaces the criterion book 1 Ch 15 currently states.
See §3 for the site and §5 for what the repair has to decide.

**Forgetting and blindness are two different conditions.**

> the forgetting-versus-blindness difference - i will commit to them being different.

Ruled narrowly and deliberately. **What is ruled is the difference, not the test for it.** His
observation that *they would react differently to a challenge* is his, but it was offered before the
commitment and the commitment was to the difference alone. The challenge test is treated as derived —
§4.4.

### 1.2 RULED BY ASSENT — `[C]`'s case, `[A]`'s *yes*

These three came in a chain. `[C]` framed the questions and argued the cases; `[A]` answered *yes*.
They are rulings, and they are flagged here because a later session may want to know how thin the
assent was.

**Stress is the switch.** Consequences in the world always press; stress decides whether the press
mobilises a person or collapses them.

**The brake is conditional on stress.** See §7 — this is the change to the earlier note.

**The distribution is bounded for most, with a tail.** Below some level of stress the brake holds and
people are kept in the middle; past it the response collapses, the loop runs unopposed, and those
people go to the floor and do not come back.

*`[C]` pointer, and it is the reason this session stopped advancing:* the tail is a claim about real
people, it entered the model on one word, and nothing in its wording ties it to the stress switch it
was derived from. **On `[A]`'s own test — a derived claim recorded as a ruling survives its premise —
the tail is the kind of thing that test was written for.** It is recorded as ruled because he ruled
it. Whoever revisits the stress switch should revisit the tail in the same pass.

### 1.3 `[A]`'s, STATED AND HEDGED — not ruled

> i think a habit of ignoring applies generally to new fears.

> i thing something in between. habits short circuit examination. but i think it's distinct from the
> blindness loop.

> ignoring costs sight eventually, and the two collapse back together after long enough - but not
> directly through a psychic mechanism - rather by external problems accumulating and stressing a
> person. stress will cause examination to be skipped.

All three are his content. None was put to him as a rule and none was ruled. **The third is the
external route, and it is the load-bearing one** — it is what keeps the chronic ignorer from sitting
permanently at the top of the health axis. See §6 for the step it is missing.

---

## 2. THE SHAPE, IN PLAIN WORDS — **SUPERSEDED 2026-08-30. Three fates and the placement below are both wrong.**

> **`[A]` ruled four fates at the crossing, in an order: `worked through`, `given up on`, `ignored`,
> `blocked`.** Two of the three names below are also replaced — `reconciled` becomes **worked
> through** and `accepted` becomes **given up on**, both words having been found already doing the
> other's job in the books. *`settled` was ruled for the first fate on 08-30 and replaced on 08-31:
> book 1 already has a fear settling into a fact, which is the descent.*
>
> **And ignoring moves back to the crossing.** He sited the decision to ignore at **Z+**, on the
> ground that Z+ is the position that chooses pleasure over fear and dropping a fear without
> processing it is that sort of act. So it is a disposal alongside the others, not something that
> happens afterwards.
>
> **What the section still gets right and what the ruling preserved:** the clear-side rule in §1.1 is
> untouched — a fear that was seen can be ignored but not buried. What distinguishes ignoring from
> giving up on is what gets dropped. **Giving up on drops the want behind the fear**, so the fear is
> genuinely gone and a regret remains. **Ignoring drops nothing** — fear intact, want intact, only
> the occasion let pass — which is why it returns. The sort runs on two questions: whether the fear
> is in view, and whether it is disposed of. Nothing never seen can be disposed of, so `blocked` is
> the only fate on the unsighted side.
>
> The habit paragraphs below — that ignoring generalises, that it short-circuits the examination, and
> the external route through accumulating consequences — are **not** superseded by this.

A fear arrives. What can happen to it:

- **Buried** — blocked before it reaches consciousness. Survives intact and hidden. Descends the axis.
- **Reconciled** — weighed to a conclusion and released. Sighted.
- **Accepted** — given up on rather than resolved, but in full view. Sighted. Leaves a regret.

Those are fates **at the crossing**. Then, afterwards:

- **Ignored** — the fear is already in, already seen, and attention is withheld from it.

Ignoring is not a fourth fate at the crossing. It is what can happen to a fear that has already been
let in, and that is why it cannot be burial: the fear was seen, and by the ruling in §1.1 that puts
the person on the clear side regardless of what they do with it next.

Repeated, ignoring becomes a habit, and the habit is **general** — it meets new fears, not only the
one it was learned on. What the habit does is **short-circuit the examination**: the fear still
registers, still carries its feeling, still pulls; the weighing stops running.

That leaves a person who sees everything and settles nothing. They are not blind. But the problems
they are not settling accumulate in the world, and the accumulation stresses them, and **stress is
what decides whether pressure mobilises a person or collapses them**. Collapsed, they lose the forward
answer. That is how the ignorer eventually arrives where the blind are, by a route that runs outside
the psyche and through their circumstances.

---

## 3. THE FINDING THAT OPENED THE DAY: THE TWO BOOKS TEST THE SPLIT DIFFERENTLY

**Book 1 Ch 15, *Where a Person Stops* (L1462) defines the split by ROUTE:** resolution reached
*through* examination — fully weighed, then genuinely released — is detachment that keeps its sight;
resolution grabbed to *skip* examination, *"it's fine, never mind"*, is false resolution, detachment
that has stopped looking.

**Book 2 Ch 11 (L846) defines it by REGISTERING:** what varies between detachment's two positions is
how much of the realm registers — near the caution end the realm is seen, further along less arrives,
at the far end the registering has stopped. Stated explicitly as one quantity, not two conditions with
a boundary.

These look like the same distinction and are not, and **acceptance is the case that pulls them
apart.** An accepted fear was not weighed to a conclusion — that is what makes it a general surrender
rather than the resolution of a particular fear. By book 1's letter it is therefore the blind side. By
book 2's it is clean.

`[A]` ruled for book 2. **Book 1's sentence is the loose one.**

### 3.1 What the naming question turned into

The session opened on the first of the four questions `SET-NOTE-from-job23` left: what the third
outcome is called. **That question was withdrawn as the wrong question.**

Acceptance is not a different arrival needing its own name. It is a **second route to the same side of
the seam.** Reconciling and accepting both arrive sighted; they differ in what became of the fear, not
in where the person stops. The three outcomes are dispositions of a fear; the Z split is a side of a
seam. Two axes, and the three-outcomes note's table had been treating them as one.

**Found on the way, and it constrains any future naming:** book 1 Ch 15 already assigns `resignation`
and `regret` to Z− as its B-tinged affect — *the sober mood of things seen and let go* — which
converges with `[A]`'s *maybe a regret that is accepted* but spends `resignation` as a name. And
`relinquish` is spent in the other direction: book 2 Ch 11 L844 uses it for the good crossing itself,
the blind end depending on *detachment reached by surrendering to fear rather than by relinquishing
it*.

---

## 4. DERIVED — `[C]`'s, and none of it ruled

Marked so it cannot be mistaken for `[A]`'s later. Each of these is load-bearing somewhere above.

### 4.1 Book 1's example is the ignoring habit, not blindness

*"It's fine, never mind"* — the grabbed resolution that skips examination — is the ignoring habit
described exactly, and book 1 files it under blindness. It skipped the weighing; it did not stop
looking. **So the Ch 15 sentence holds two different failures under one name**, and the ruling in §1.1
is what separates them.

### 4.2 Chapter 17's gradient is the mechanism

Ch 17 already states it generally: a person acquires their stances at the far end of a gradient
running from involuntary to chosen — something registers, it carries a feeling, the feeling pulls, and
only then does the person do something about it, which is a choice; and **repeat a choice often enough
and it stops being made, it sinks back down the gradient and runs by itself.**

The ignoring habit is one instance. The choice that sinks is *the choice not to pursue*. Because it is
that choice and not the registering that sinks, the fear still arrives and what stops is the weighing.

**Same carrier as burial, different thing laid down.** Burial keeps the fear from consciousness at all;
ignoring leaves it in plain sight and removes the examination behind it. Same gradient, opposite ends
of the arc.

*Caution:* that paragraph has never been pointed at any of this in the text. Pointing it at burial was
already an unruled move in the 08-26 note; this is a second pointing, by `[C]`, and it inherits the
same uncertainty.

### 4.3 The forward cost — **THE WITHDRAWAL BELOW IS ITSELF WITHDRAWN, 2026-08-30**

> `[A]` retracted *does not turn into* on 2026-08-30: **"i guess there is intentional non-attending,
> automatic non-attending and defended blindness. three places on a spectrum but the feedback nature
> of defended blindness is a tipping point - a qualitative change."** So an internal route from the
> habit to the blindness does exist, and the external route below is no longer the only one down.
>
> **This does not restore the claim recorded here.** What was withdrawn was a *trainable motor* — the
> burial reflex getting quicker with deliberate practice. That is still not the mechanism. The
> mechanism he gave is a tipping point: the third thing is not a further degree of the first two but
> an act that pays for itself, which is why repetition alone never reaches it. **Do not re-propose
> the trainable motor. The route back is the feedback, not the practice.**

*Recorded below as first proposed, so it is not re-proposed in its original form.*

`[C]` first proposed that long ignoring trains the burial reflex, so the cost of ignoring is paid by
the *next* fear, which arrives at a crossing where the reflex is quicker. **This required the burial
motor to be trainable by deliberate acts and not only laid down early.** `[A]` was asked directly and
did not grant it. He gave a different account instead — the habit generalises **as ignoring** (§1.3),
and sight is lost later by the external route.

**The trainable-motor claim is withdrawn.** It is not in the model. Nothing above rests on it.

### 4.4 The challenge test

Both routes end with the thing out of view; only one defends the exit. Book 2 L844 has the far end
holding an aversion even to recognising the conflict, since merely seeing it is itself a threat. A
forgotten thing has no such guard — point at it and the person looks, with reluctance perhaps, but
they look. A thing held down by the reflex fights the pointing, and the fighting is not about the
fear's content but about the looking.

**So the test is not whether the fear is out of mind. It is whether being reminded meets resistance.**

`[A]` said they would react differently to a challenge. He ruled the difference and not the test.

### 4.5 The bridge `[A]` has not addressed — **HE HAS SINCE ADDRESSED IT. NOT RESOLVED HERE.**

> **Pointer, not a closure.** On 2026-08-30 `[A]` ruled the entry condition in his own words: a fear
> becoming unbearable, which is how painful it is set against how much the person can bear. He also
> ruled `painful` in place of `urgent` for that variable. The candidate below reaches for the same
> place from a different direction. **Whether it is the same claim has not been checked and is not
> checked here.** Two sessions have deliberately declined to join pieces of this area into a case;
> this note is being marked, not argued.

`[A]`'s external route needs a step that costs **sight**, and stress skipping examination does not
supply one — see §6. `[C]`'s candidate: accumulated problems don't merely add stress, they make the
ignored fears **expensive to look at**. An unexamined fear is cheap while nothing has come of it. Once
the consequences have arrived, looking means facing what has already happened and one's own part in
letting it — which is the point at which not-seeing becomes preferable to seeing, and that is the
entry condition the blind end needs.

**Put to `[A]` twice. Not answered either time.** Do not treat it as his.

---

## 5. WHAT THIS COSTS THE TEXT

### 5.1 Book 1 Ch 15, L1462 — a defect with a site, NOT repaired here

The sentence states a route where the model now means a condition. **The repair is bigger than a
wording swap**, because the sentence's example belongs to a third thing the book did not have:

| In the sentence | Now |
|---|---|
| *through examination → keeps its sight* | one of **two** ways of arriving sighted; the other is acceptance |
| *skip examination → stopped looking* | **two failures run together** — the ignoring habit (skipped weighing, sight intact) and blindness (stopped looking) |
| *"it's fine, never mind"* | an example of the **ignoring habit**, currently filed under blindness |

**No replacement wording is written here.** Who writes it is still the question `[A]` has not answered
— whether a doctrine session drafts what it closes on the day.

*Noted for whoever repairs it:* this is the same Ch 15 stretch that carries the *habitually stop*
sentence left open on 08-27. **One pass, not two.**

### 5.2 `THEORY-NOTES-gradient-and-Z-split.md` — an argument now leaning on a replaced premise

That file records `[C]`'s objection to dropping the `Z−`/`Z+` notation, one ground being that dropping
it *loses the path definition — Z− is detachment reached through understanding, so the sight is
retained*. **The path definition is what was replaced this morning.** The objection may still succeed
on its other grounds. It does not come apart today, but **nothing should touch the notation before
that argument is re-checked.**

### 5.3 Book 2 Ch 11's far end is INCOMPLETE, not wrong — drafting

L594 and L846 describe the far end as difficulties simply no longer looked at, forgetfully blind to
what it would be uncomfortable to know. **That description now fits three different people**: the
blind, the chronic ignorer, and the Nine who sees the realm with tranquil clarity and engages nothing.
The chapter measures one quantity — how much registers — and both of the first two register fully at
the moment they are looked at.

### 5.4 The forgetting/blindness distinction has NO HOME in either manuscript — drafting

Ruled doctrine as of today and stated nowhere. **Drafting work, not repair, and not on the job list.**
It belongs beside the brake, which is in the same condition.

---

## 6. THE STEP MISSING FROM `[A]`'s EXTERNAL ROUTE — **STILL OPEN, BUT NO LONGER LOAD-BEARING**

> **Pointer, not a closure.** This section's force came from the external route being the only route
> down. `[A]`'s retraction of *does not turn into* on 2026-08-30 opened an internal one — see §4.3 —
> so the descent no longer stands or falls on the step named below. The step is still missing.
> Whether the 08-30 entry ruling supplies it is unchecked.

His route: ignoring → problems accumulate → stress → *stress will cause examination to be skipped.*

**But skipped examination is what he had just defined the ignoring habit to be.** A stressed person
skipping examination is doing more of the same thing, faster. Nothing in that yet costs them sight,
and **sight is what the descent requires.**

So the route as stated does not reach blindness. Either §4.5's bridge closes it, or something else
does, or the collapse-back-together claim in §1.3 does not follow.

**This is the first thing to put to him next.**

---

## 7. WHAT CHANGES IN `NOTE-the-dwell-and-the-brake-20260827.md`

**Its §5 stands except for one thing: the brake is now conditional on stress.**

That note has the brake as a restoring force that **grows with displacement** — the further down, the
harder the struggle — which is what produced the bounded distribution `[A]` insisted on against the
proposal that most people never start. It has the blindness not weakening the response but **selecting
its route**, fixing or hiding, with sight doing the routing.

Today puts a switch **upstream of that routing**. The chain is now three steps:

1. **Consequences press.** Always. The trigger is in the world, not in any recognition of one's own
   condition — that half is unchanged, and it is still why the brake reaches through the blindness.
2. **Stress decides whether there is a response at all** — mobilise or collapse. NEW.
3. **Sight decides where the response goes** — fixing or hiding. Unchanged, and still unruled in its
   assembly.

**The cost:** the restoring force now weakens exactly where it was supposed to be strongest, since the
people furthest down are the most stressed. The bounded distribution survives as *bounded for most,
with a tail* (§1.2). **That is a harder and more falsifiable claim than yesterday's** — it says there
should be a population that does not come back, not merely people low on the axis.

**Book 2 already contains the switch and does not know it.** L594: caution would be the forward
answer, *but stress prevents it*, and the person collapses inward instead. That sentence is the
disintegration account and it is doing this work already.

---

## 8. §1.0 ON ARRIVAL — clean

`setcheck.py verify MANIFEST-job24-20260827.md` — **29 ok, 0 mismatched, 0 missing, 0 not in the
manifest.** `screen` fired three, all benign: the record and `setcheck.py` as carry-do-not-read, the
handoff quoting the restriction string.

**`AUTHOR-RECORD.md` arrived at 12,492 w**, last marker `2026-08-27 · Job23 doctrine 8-27` (doctrine
append), agreeing with handoff §1.1 and with `SET-NOTE-from-job23-20260827.md`. **All three of Job23's
appends landed.** The failure job 22 warned about has not recurred.

**One discrepancy, benign and recorded so it is not re-found:** `SET-NOTE-from-job23-20260827.md`
states **28 ok** for its check of the outgoing set against `MANIFEST-job24-20260827.md`. That manifest
carries **29** rows and verify returns 29. Job23 most likely ran the check before its own set-note row
went into the manifest. **No file is missing or extra**, and its own arrival check — 30 ok against
`MANIFEST-job23-20260827.md` — is a different number for a different set and is not in question.

*The set was sent twice, identical zip, and `§1.0` was not re-run on the second. `md5` of the incoming
zip was compared instead.*

---

## 9. OPEN, IN PLAIN WORDS

1. **The missing step in the external route** — §6. Largest, and first.
2. **Does the *expensive to look at* bridge close it** — §4.5. Put twice, unanswered twice.
3. **Who writes replacement wording for what a doctrine session closes** — asked 08-27, still open,
   and it is now blocking the Ch 15 repair.
4. **The three remaining questions from the three-outcomes note**, untouched today: Ch 5's *reason*
   reworded to *consciously*; what Ch 15's *the cycle it turns* meant; whether acceptance moves a
   person at all.
5. **Whether the tail should be re-examined when the stress switch is** — §1.2.
6. **The Ch 15 repair**, with the *habitually stop* sentence, in one pass — §5.1.
7. **Two drafting items with no home**: the forgetting/blindness distinction, and the far end's three
   occupants — §5.3, §5.4. Both sit beside the brake, which is in the same condition.

---

# SECOND HALF OF THE DAY — cut after the set was already cut

## 10. `[A]` CORRECTS THE SIGHT RULING: IT ATTACHES TO THE PASSAGE, NOT TO THE FEAR

### 10.1 The correction

> "a fear seen can be ignored but not buried" could be true of a particular passage through Z one
> time and neither seen nor ignored a later time. we're talking about A only, right?

**§1.1 recorded the protection as attaching to the fear** — seen once, safe from burial thereafter.
It attaches to **the crossing**. The same fear can be seen and set aside on one passage and blocked
before sight on a later one.

**What this fixes:** the collision `[C]` flagged in §4.5 is gone. The bridge no longer has to be
restricted to newly arriving fears, because a recurring fear may go under on a later passage without
contradicting anything.

**What this costs, and `[C]` argued the opposite earlier in the same session:** `[C]` had told `[A]`
that one-way sight is what makes the way out work — that recognition is a permanent subtraction
rather than a delay, because a seen fear cannot be re-buried. **On the per-passage reading that
argument fails.** Recognising a fear protects that crossing and no other, so the descent can resume
next time round. **The way out is a holding action unless something else makes recognition stick, and
nothing in the model currently says what would.** `[C]` withdrew the argument in the session.

### 10.2 The scope, and the reason for it

> that it comes from A, not the content of the fear. but fears from A, i think, feel less urgent than
> a fear arising at B.

**Everything in this note is an A-side account** — fears arriving at detachment from enthusiasm, the
collapse book 2 already describes at L594 where caution would be the forward answer but stress
prevents it. Arrivals at detachment from caution are a separate story nobody has told.

*`[C]` reading, and `[A]` did not dispute it:* the scope is not a boundary drawn around the account,
it is a consequence of the account. **A fear that does not press is precisely the kind that can be set
aside at no cost, so the ignoring habit lives on the A side because that is where fears are
ignorable.** And the B side gets the opposite failure from the same variable — a fear that presses
cannot be skipped, so it is weighed and weighed again, which is book 1's B fixation, the stop in
examination where the weighing will not close. **Same variable, opposite failures.**

---

## 11. URGENCY DECIDES WHETHER A FEAR CAN BE IGNORED — RULED, AND IT IS ANALOG

> can an urgent fear be ignored? i would say no, but i suspect it's a somewhat analog question, not a
> sharp digital threshold.

**An urgent fear cannot be ignored. How urgent it must be before ignoring stops working is a slope,
not a line.**

The analog shape is not a hedge on the ruling. **It is the second continuous quantity in the model** —
book 2 already has the split at detachment as one quantity with no boundary, every degree between the
ends occupied. Urgency now works the same way.

### 11.1 What it does to `[C]`'s bridge — the bridge shrinks

`[A]` accepted the *expensive to look at* bridge in the session (*you're right*) and then asked how
much it overlapped with what was already recorded. **The answer turned out to be: almost entirely,
and the residue is smaller than the bridge was.**

- **It adds no mechanism to the blind end — it adds an entrance.** Book 2 L844 already has that end
  holding itself, aversion meeting aversion, with aversion even to recognising the conflict because
  seeing it is itself a threat. The text gives that as a steady state and never says how anyone gets
  into it.
- **It supplies the reinforcer the 08-26 note says acceptance lacks.** That note: acceptance has no
  reinforcer, no anxiety was avoided, so nothing is rewarded. Ignoring starts the same way. **Once the
  consequences land, not-looking does avoid anxiety, and the habit acquires the motor burial already
  runs on.**
- **So the bridge reduces to this:** consequences make an ignored fear **urgent**. The cheap fear
  becomes expensive because it now presses, and at that moment it stops being ignorable and must go
  somewhere — weighed, or blocked. **That fork is the stress switch, in a new place, doing the same
  work.**

### 11.2 What it does to the tail — THE TAIL LOSES ITS DERIVATION

**§1.2's tail was derived from the stress switch being a switch**, and only from that. Analog removes
the premise. The three parts, as `[C]` put them to `[A]`:

1. Every step after the switch loses its warrant. Not false — **unsupported**, and nothing else in the
   model has been pointed at it.
2. **Nothing in the model says how the two forces scale.** A restoring force that weakens with depth
   can bound a distribution or fail to, depending entirely on rates the model has never given.
3. **`[C]` got this wrong in the morning.** The argument was that the brake weakens where it should be
   strongest, since the people furthest down are the most stressed. But **the people furthest down
   also have the most consequences**, and consequences are what drive the mobilisation. **Both
   quantities rise together, and the morning's case quietly assumed the interference wins.** With a
   discrete switch that assumption was hidden; analog exposes it.

---

## 12. THE TAIL, RE-DERIVED FROM A DIFFERENT PREMISE — and it is weaker

> my intuition is that it's harder to recover, the lower the level one is at because one is more
> debilitated regarding facing reality and that overrides with whatever increased motivation one has
> to escape. i said that before - each level down the harder it is to go up even one level.

**A correction on the record, made in the session:** what he said before is adjacent but weaker. On
08-27 he said *the less a person can see, the harder they have to work to get by*, citing Riso's
levels. **That is about the cost of daily functioning. Tonight's claim is that the difficulty of
climbing ONE LEVEL rises with depth and OUTWEIGHS the increased motivation.** The ordering is new, and
the ordering is exactly what §11.2 said the model had never supplied.

**So the tail returns, from a different premise and in a weaker form.** No threshold is needed, which
is what makes it compatible with the analog reading. **Nobody is barred from returning; the climb gets
slower with depth, and slower faster than the pressure to climb gets stronger.**

**And it converges with something already filed.** The 08-26 note §5.3 argues the one-by-one route can
be outrun by the reflex, since blindness accrues in fractions of a level and is reinforced every time
it fires. **Same race, seen from the other side** — his is the climb getting steeper, that one is the
tap staying open while you bail. Neither was derived from the other.

### 12.1 And then `[A]` closed the absolute reading

> coming up from the bottom happens. look into 12 step programs like alcoholics anonymous. that might
> tell you more than i can.

**There is no absorbing floor.** The tail is people stuck in practice, not people barred. **§1.2's
wording, which says they do not come back, overstates it and should be read against this section.**

---

## 13. THE SECOND BRAKE — RULED

> yes, intervention. and i think what works is different in each case and the person who intervenes
> needs to find it. it works much better if the person who intervenes has been rescued or rescued
> themselves because they know how it feels and know rescue is possible.

Asked whether the intervener's shared experience is what makes the intervention work or what lets
them find what works for this person:

> the intervener's experience does both.

**The model now has two brakes, and they work by opposite means.**

| | **First brake** (ruled 08-27, morning) | **Second brake** (ruled 08-27, evening) |
|---|---|---|
| Trigger | consequences in the world | another person |
| Needs self-recognition? | **no** — that is why it survives the blindness | **no**, but it supplies what the person cannot see |
| Mechanism | force, bypassing sight | **sight, imported** |
| Conditional on stress? | yes, ruled this morning | **no — ruled 2026-08-29** |

**RULED 2026-08-29 by `[A]`:** stressed people are harder to help and some interveners specialise in
exactly that, but stress does not switch the second brake off. **His reason, and it is the part worth
keeping:** the intervention *happens outside the person's psyche*, "so there isn't anything beyond
that to say."

**That draws a boundary, not just an answer.** The first brake is a fact about the person and the
model owns it. The second is a fact about somebody else acting; the model can say that it reaches
the person and by what means — imported sight — and nothing about what makes an intervener succeed.

**What it settles:** the two brakes do not fail together, so the low tail is not thickened by this.
*The tail's own problem is untouched and stands where §17 leaves it — it entered on one word and was
derived from stress being a discrete switch, which `[A]` has since called a slope.*

*`[C]` reading, unruled:* **a person at depth cannot generate the belief that rescue is possible,
because that belief is about their own condition, which is what the blindness blocks.** So the
intervener is not supplying extra force; they are supplying sight the person cannot produce, borrowed
from someone who has been there. **That is why the second brake becomes necessary as the first
weakens** — the missing ingredient at depth is the thing they are blind to, not the effort they lack.
It also makes intervention the answer to a standing problem: recognition has always been the exit, and
the person furthest from it is least able to recognise anything. **Intervention is how recognition
reaches someone who cannot reach it.**

---

## 14. THE EMPIRICAL MATERIAL — NOT DOCTRINE, AND IT IS FROM OUTSIDE THE MODEL

`[A]` sent the session to look at 12-step programs. **Everything in this section is from web search on
2026-08-27 and none of it is ruled. It is evidence about one domain — addiction — and treating depth
of addiction as depth on the health axis is an assumption nobody has argued.**

**The bottom is relative, not fixed.** Naming the moment *hitting bottom* implied an objectively fixed
point, while the experiences of people entering AA showed it to be relative. In one member study
(N=263) bottoms were self-identified as high 36.1%, middle 44.5%, low 19.4%. **That is `[A]`'s analog
reading appearing in data rather than in the model.**

**`[C]` MADE AN ERROR HERE AND `[A]` CAUGHT IT.** The same study found high-bottom members more often
entered via introduction by an existing member and low-bottom members more often via court order.
`[C]` read this as coercion-by-strangers at depth against peers near the top, and built a two-stage
account on it. **`[A]` asked whether the coerced cases were also being handled by 12-step people. They
were.** The field measures **how people got through the door, not who did the work inside it** — AA's
own literature says groups welcome members from court programs and treatment facilities, some arriving
under pressure, and that who referred them is not their concern. **The split was an artefact of
reading a referral field as though it described the intervention. Retracted.**

**And the follow-up went against the picture `[C]` was assembling.** Court-mandated treatment has been
associated with **increased** retention and completion versus non-mandated. In a large Texas audit
(N=27,198), those legally coerced showed less psychological distress and greater likelihood of
completing than non-coerced clients, which the authors read as the voluntary clients presenting later
and more severely impaired.

*`[C]` reading, unruled, and it inverts `[C]`'s own earlier sequencing:* if people arriving under
compulsion are in better shape than those arriving voluntarily, **compulsion is reaching people
earlier in the descent, not deeper into it.** Coercion **intercepts**; waiting for a person to come on
their own is what produces the deep cases. **A consequence delivered early is an intervention** — the
court order is the first brake arriving on time rather than late.

**Two cautions carried with all of the above.** AA's own effectiveness evidence is described as scarce
and mixed. And in the US, mandating 12-step attendance has been held to violate the establishment
clause unless a secular alternative is offered, so the court-to-AA pipeline these studies measured is
legally contested and may not describe current practice.

*Sources, for anyone re-checking:* the member study is in the Journal of Social Work Practice in the
Addictions (2011); the coerced-treatment audit is a Texas retrospective on PubMed Central; the
retention finding is a residential-treatment follow-up on PubMed Central; AA's own position is in its
literature for courts and treatment programs.

---

## 15. REGISTERED AND NOT TAKEN UP — `[A]`'s fourth job for consequences

> and a fourth job, they motivate a person to try to improve - and what things determine success is
> something we should think about. one tradeoff is comfort now vs comfort later which is related to
> unconscious vs conscious response.

**This was raised by `[A]` and never worked on.** It is his, unhedged, and it contains two things the
model does not have: **what determines whether the attempt to improve succeeds**, and **a comfort-now
against comfort-later tradeoff tied to the unconscious/conscious distinction.**

Consequences now do four jobs: trigger the first brake, stress the person, make fears urgent, and
motivate improvement. **Whether that is one mechanism seen four ways or four uses of one trigger is
open.** `[C]` asked whether the expense and the stress are the same thing seen from two angles and
`[A]` did not answer.

**This is the largest untouched thing in the file.**

---

## 16. A SWEEP FINDING — a repair record disagrees with the manuscript by one word

A full `quotecheck sweep` was run across the whole outgoing set: 294 quotations of six or more words
across 29 files. **Every orphan resolves to a known cause** — the record is the origin of its own
quotations, `VERIFY-20260815.md` quotes outside books not in the set, the recovery note quotes the
record's superseded opening under a heading that says *Before*, and the handoff's one live orphan
quotes a superseded book 2 file and is stamped **DO NOT APPLY** three lines below. **No quotation in
the set has drifted from its source.**

**But `REPAIRS-job16-book1-defects-20260825.md` §2.14 records a repair that was applied in modified
form.** Its `REPLACE:` string reads *runs its own arc*; book 1 L550 reads *runs its own smaller arc*.
Everything else in that repair landed exactly.

***`[C]` recommends NOT changing the manuscript.*** *smaller* is doing work — the arcs are smaller
than the orientation cycle the paragraph has just described, and dropping it costs the reader that
relation. **The defect is in the repair record, not the text.** A dated line has been added at that
entry recording the divergence. **Not ruled; `[A]` has not seen it.**

---

## 17. OPEN, IN PLAIN WORDS — REPLACES §9

§9 was written at the first cut. **This list supersedes it.**

1. **`[A]`'s fourth job for consequences** — §15. His, unhedged, untouched, and the largest thing
   here.
2. **What makes recognition stick** — §10.1. The per-passage correction removed the argument that made
   the way out permanent, and nothing has replaced it.
3. **The step missing from the external route** — §6, now largely answered by §11.1: consequences make
   the fear urgent. **Confirm that with `[A]` rather than assuming it.**
4. ~~Whether the second brake is conditional on stress~~ — **CLOSED 2026-08-29, ruled not conditional. See §13.**
5. **Who writes replacement wording for what a doctrine session closes** — still unanswered, still
   blocking the Ch 15 repair.
6. **The Ch 15 repair**, in one pass with the *habitually stop* sentence — §5.1.
7. **The three remaining questions from the three-outcomes note**, untouched both halves of the day:
   Ch 5's *reason* reworded to *consciously*; what Ch 15's *the cycle it turns* meant; whether
   acceptance moves a person at all.
8. **The B-side account** — §10.2. The whole of this note is A-side and nobody has written the other.
9. **The sweep finding** — §16. `[A]` has not seen it.
10. **Three drafting items with no home**: the forgetting/blindness distinction, the far end's three
    occupants, and now **the second brake** — §5.3, §5.4, §13.
