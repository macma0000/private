# NOTE — the overlap, and the truthfulness principle

**REVISED 2026-08-24 by `Job15 tools session 8-24`. Replaces
`NOTE-overlap-and-truthfulness-20260815.md`; quarantine that file.** One repair, formatting only:
the conclusion in §2 was set as a blockquote though it quotes nothing, and a `>` block used as a
callout fails `quotecheck` exactly like a fabricated quotation. It is now bold text. **No word of
the note changed** — `quotecheck sweep` accounts for all seven of its remaining quotations.

Recorded 2026-08-15, out of the architecture session. `[A]` marks the author's statements as
offered; `[C]` marks my readings, which carry the usual discount. **One of the two is ruled and one
is not** — §2 is doctrine, §1 is a suspicion with a derivation attached that wants `[A]`'s ruling
before anything is built on it.

---

## 1. THE OVERLAP, AND BLINDNESS TO BLINDNESS — not ruled

### 1.1 What was proposed `[A]`

The Z−→Z+ transition depends on **whether the Z− aversion is carried into the Z+ fulfillment
desire.** When it is, the desire is fulfilled *by* blindness — and, importantly, **by blindness to
blindness.** That carrying is what was being called **the width of the overlap.**

A clean transition, with no overlap, is distinguished from an overlapping one with resulting
blindness. **Probably the clean transition is an ideal that seldom if ever happens.**

Added, and it is the load-bearing part: **Z0 is another ideal. The concept is not a real thing
without zero overlap, which we think does not exist. Possibly no overlap is reachable with
extensive spiritual training.**

### 1.2 What book 1 already has `[C]`

Both endpoints are written, in Ch 5's Z→A passage:

> Done well, this is a release into action: appetite returns with the seeing and detachment still
> intact. But remnants of aversion mix with beginnings of attraction — aversion fights attraction,
> a fight is what Z most wants to avoid and the only way out is a reflexive drive toward
> compulsive inattention and unawareness.

And the self-preserving loop is Ch 11:

> The conflict produces the not-seeing, and the not-seeing preserves the conflict. That is why the
> blind end is not a passing condition a person drifts through but somewhere they can remain.

**So what is new is not the mechanism but two things on top of it:** the *variable* between the two
endpoints — how much aversion is carried — and the meta-turn, **blindness to blindness**, which is
R1's aversion-to-aversion applied at the pole. That naming does real work: it says why Z+ is a
place rather than a phase, and why self-report fails there in particular.

### 1.3 The identity, and what it earns `[C]`

**Zero overlap and Z0 are the same absence.** Book 1's Ch 11 calls Z0 *"the absence of residue, and
therefore the absence of selection: unselective receptivity"* — and the residues are exactly what
the overlap is made of, B's remnant wariness against A's growing wanting. The identity is latent in
the book's own words.

**The gain: it derives settled doctrine instead of stipulating it.** "Z0 always blurred, a limit
not a place" has stood as an assertion. It now has a reason — Z0 is blurred because the two
residues overlap, and they always do.

### 1.4 The tension, and a resolution offered `[C]`

**"Possibly reachable with extensive training" collides with Ch 18**, which rules it out by a
regress rather than by degree:

> *Complete* choicelessness — zero blur, the ranging collapsed to a point, fear gone altogether —
> is an ideal. It is never actually held: even the best-trained state is a habit maintained by the
> habit of maintaining it, and that regress has no floor to rest on.

R5.4 restates the same thing: the trained habit holds the *position*, not the seeing.

**The resolution is already in ruled doctrine.** Ch 15 assigns Z0 to Level 0 — *"it belongs instead
to Level 0, the exit… off the ladder rather than atop it"* — and R5.3 makes Level 0 the mid-phase
of a passage, **touched and renewed, never occupied**. So:

**Training can touch zero overlap. It cannot hold it.**

That gives the "maybe" its yes, keeps R5.4 and Ch 18 intact, and makes Z0 and Level 0 **one kind of
object** rather than two that happen to resemble each other. It is more than `[A]` said, so it
wants ruling rather than adopting.

### 1.5 What it settles, and what it must be checked against

**It dissolves the Z+ naming question** (Part III item 4, and the reason the item was raised). The
pole is not named by choosing a noun between "blindness" and "unknowing"; it is named by what makes
it, and *blindness to blindness* is the handle. "Blind" survives everywhere as an ordinary
adjective. **Close the ledger item on that basis, not on a preference.**

**Check before building:** R5.3 has the exit as a *sighted* Z→A arising. If the clean transition is
an ideal that seldom happens, the exit is correspondingly rare — which probably strengthens the
account, since that is what the traditions report, but it touches ruled doctrine and should be
looked at rather than nodded through.

**Also open:** whether "overlap" here is the same word as E8's *observer's* overlap (does a Z− read
a Z+ as ahead or behind, by observer's overlap). If the same, that is a connection worth recording.
If not, one word is doing two jobs.

---

## 2. THE TRUTHFULNESS PRINCIPLE — ruled `[A]`, 2026-08-15

### 2.1 The principle

**What can be written is always an ideal pointing at patterns in reality — not reality itself. So
every time reality is interpreted, that has to be remembered: what is said here means *look for
this*, not *this is exactly so*.**

Ruled to apply so that **all existing claim-wordings are understood that way — as metaphors.**
`[A]`: this will entail difficult judgments in the drafting phase.

Note the ruling's verb. It is *understood*, not *rewritten* — the statement does the work globally
and the drafter applies the frame sentence by sentence, changing wordings only where they resist
being read that way. It is not a mechanical sweep like the prediction-language item.

### 2.2 It is cheaper than it sounds, because the book already obeys it

Six existing instances of one move, performed without the rule ever being stated:

- **Z0** — *"best read as limits: places a person can be near, and never exactly at"* (Ch 11).
- **Complete choicelessness** — *"never actually held… the limit the trained state approaches, and
  nowhere else"* (Ch 18).
- **The notation** — *"names the middle of a range, and the range is not error"* (Ch 17).
- **The four landmarks** — loose in the middle, and R2 makes the looseness permanent (Ch 15).
- **Positions are analog** — nobody sits at one (settled doctrine).
- **Level 0** — cannot be occupied, only touched and renewed (R5.3).

**And §1's clean transition is the seventh.** The principle is not a new claim; it is an unstated
one the book has been keeping. That makes it a passage rather than a project.

### 2.3 Three registers — the test that makes the drafting judgments decidable `[C]`

The ruling as stated would, taken flat, require hedging the arithmetic — and the counting argument
that yields nine, and Ch 10's derivation of the hexad, are exact and must not be softened. `[A]`'s
own qualifier is what prevents this: *"every time reality is **interpreted**."* The principle bites
at interpretation, not at internal structure. Book 1 says the same in one line, Ch 17:

> a principle is exactly true about its own path and only sometimes true about an outcome

So the drafter's question is only ever **which register is this sentence in:**

1. **Internal to the model — exact, and hedging it is an error.** Three orientations in two realms
   gives nine and could not give eight or ten. The hexad closes at six steps. There are three
   mirror pairs and no others. These are true about their own path.
2. **Applied to a person or to the world — an ideal pointing at a pattern.** "A Five imports
   understanding into the psychic realm" means *look for this*. This is the register the ruling
   governs, and it is most of the book.
3. **Correspondence — where the model is set beside R&H, the classical figure, or the traditions.**
   Already handled carefully in places (*"This is an observation, not a derivation"*, Ch 15) and
   carelessly in others. The ruling makes the careful treatment general.

### 2.4 The constraint rule is itself an ideal — `[A]`, ruled 2026-08-15

`[C]` reported a tension here: that "look for this, not this is exactly so" softens while "a
derivation must forbid something" hardens, and that the two rules therefore had to be allocated
rather than blended, or the book would go unfalsifiable.

**`[A]`: that is logic, and it is `[C]`'s. Take the constraint rule as an ideal — without it the
writing would make less sense — and let drafting handle the difference between ideals and reality
case by case.**

**The tension was manufactured, and book 1 already says so in the sentence `[C]` truncated.**
Ch 17, quoted in full:

> A principle of this kind is hard to refute. Show a person in whom it plainly does not hold, and
> the account can always answer that another path dominated — which may be true, and is
> unfalsifiable as it stands. That is a real weakness. The defense against it is not to argue but
> to be specific: to say which path, how strong, and under what conditions it should win, so that
> a claim can fail somewhere. **Where this book manages that, it is worth more. Where it does not,
> the reader is entitled to less.**

That last clause is graded, not a gate. `[C]` quoted up to "specific" and stopped, sharpened the
rule into a test, and then reported the collision that sharpening created. The rule was never a
test.

**What this changes for drafting.** The question is not *does this sentence forbid something* —
pass or fail — but **have I been as specific as this claim allows.** Where the answer is no, say
so, and the claim is worth less. That is a writing standard, and it needs no allocation scheme:
the three registers of §2.3 still tell a drafter what kind of sentence they are writing, and this
tells them how hard to push it.

*R7.8's tradition clause is the case that shows why the standard still bites without being a gate.
"Both realms quiet enough" names no threshold, so nothing could have failed it — not a rule
violated, a claim worth less than it appeared to be.*

**Standing rule amended.** The handoff's method line — *"Constraint, not prediction, is the test —
a derivation must forbid something"* — should be read as this ideal, not as a gate.

### 2.4a It applies to itself, and that is not a regress `[C]`

The obvious objection is that the truthfulness principle is itself a claim, so by its own terms it
only points at a pattern — and therefore says nothing.

The book already answers this, in its own doctrine rather than by importing a hedge. Ch 5:
*"everything that arises does so from causes and conditions, which themselves arose from causes and
conditions, with nothing anywhere standing on its own."* The principle turned on its own statements
is that, applied reflexively. It looks like a regress only under a demand for a foundation, which
the book explicitly declines to supply — and declining it is the same move, made about the world,
that Ch 5 has already asked the reader to accept.

Worth stating in the text when the principle is written, because a reader who takes the principle
seriously will raise it immediately.

### 2.5 Placement — it settles an open item

**"Principles, Not Laws" cannot be an appendix and cannot sit at book 1's Ch 17.** If the principle
governs how every sentence is read, it goes early. Book 2 has the slot ready at the end of Ch 1:

> A word before beginning. What follows is a theory, and like any theory it is subject to testing
> and refinement. Do not take it as gospel, not to be questioned. Check it against your own
> experience and against the people you know, and use what works.

That paragraph currently says *the theory might be wrong*. The principle says something different
and stronger — *that even where it is right, it is a pattern to look for and not a description of
what is exactly so*. The two belong together and the second is missing.

---

## 3. WHAT THIS TOUCHES

**§1:** R1, R5.3, R5.4, R2's Z0 doctrine, Ch 5's Z→A passage, Ch 11's Z0 and blind-pole sections,
Ch 15's assignment of Z0 to Level 0, Ch 18's complete choicelessness, Part III item 4 (Z+ naming —
dissolved), E8's overlap test.

**§2:** book 2's Ch 1 closing paragraph; book 1's Ch 17 "Principles, Not Laws" and its placement;
the method's constraint rule; the drafting of every applied sentence in book 2; the
prediction-language item on the TODO, which is the same problem in a narrower form.

## 4. STATUS

§2 is ruled and may be drafted from. **§1 is not ruled.** Its §1.3 identity and §1.4 resolution are
`[C]` constructions offered on `[A]`'s suspicion; the architecture places nothing on them, and Part 3
must not either until they are ruled.
