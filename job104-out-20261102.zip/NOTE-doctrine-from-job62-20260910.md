# Doctrine note from Job62 (drafting, 2026-09-10)

For the next doctrine session. Everything here is `[A]`'s own material, raised during a
drafting session and deliberately kept out of the prose.

DECLARED: the five blockquotes in this note are `[A]`'s spoken words from the Job62 session,
not passages from book 1 or book 2, so `quotecheck quotes` fails all five by design. There is
no source file to check them against; the conversation is the source. `[C]` comment is marked as such and
is not ruled. Nothing in this note has been written into book 2.

Carries forward the whole of `NOTE-doctrine-from-job61-20260909.md`, which is unaffected by
anything here and is still the note to read first.

---

## 1. Passage into Z+ is usually forgetting

`[A]` 2026-09-10, verbatim:

> two thing i have noticed. first is that passage into Z+ usually involves simply forgetting -
> dropping everything and looking for something more pleasurable. second, it seems to happen in
> a self reinforcing way - similar to the blindness loop - the relief of dropping rewards that
> same operation so it proceeds quickly to completion.

`[C]` findings, none ruled.

What the book already has: Ch 11's Z+ paragraph has the dropping (*what they decide is to
abandon rather than to resolve*) and the related alternative (*the same fun by another route*).
What the book does not have is that the dropping is forgetting rather than deciding.

**What this would change in the prose.** Ch 11 says the weighing *does happen* and is brief and
unpleasant. If passage into Z+ is usually forgetting, the weighing is ABSENT rather than short,
and the Z+ paragraph's account of the drop as a small discomfort weighed against a larger one
is wrong. This is a real repair owed if the claim is ruled; it was not made in Job62 because
the claim is new doctrine.

## 2. The dropping loop is not the blindness loop

`[A]` 2026-09-10, verbatim, answering whether the two are the same:

> i think they are different. i feel no fear when i drop something. i feel the relief of
> discomfort vanishing. my blindness started in my childhood when i noticed saying certain
> things caused my mother to withdraw. i imagine i felt panic.

`[C]` reading, put to him and not corrected. **Three differences, each supported by something
already in the book.**

- **What each runs on.** Dropping runs on relief from discomfort and needs no fear; the book's
  Z+ passage starts from boredom, and boredom is not a fear. Blindness runs on the aversion to
  recognising what was buried, so a fear must already be there.
- **What each leaves.** After a drop the book says the boredom comes back unchanged — nothing
  hidden, nothing accumulated. After a burial the fear survives hidden and stable.
- **What decides which happens.** The book's own condition: blocking happens only to a fear the
  person cannot bear. Ordinary discomfort is dropped; something unbearable is buried. `[A]`'s
  childhood case fits — panic at a mother withdrawing is past bearing, and the book says panic
  is answered by a reflex, which is the reflex that buries.

So the two are not stages of one thing but two answers to two sizes of trouble. This is why the
relief appears in both accounts (Ch 4, Ch 17): relief rewards turning away in both, but what is
turned away from is boredom in one case and an unbearable fear in the other.

**The dropping loop is a mechanism the book currently lacks.** Ch 11 asserts that the caution
end of the detached phase is *short and ineffective* for a Z+ person and gives no reason. The
loop `[A]` describes — each drop relieves, the relief rewards dropping, the next drop comes
faster — would supply one.

## 3. Three stores, not two

`[A]` 2026-09-10, verbatim:

> the bodily tension observation was about what carries fear from one process arc to the next.
> that's probably hours whereas mental deposits last longer. what dropping leaves is the problem
> unsolved - and the bodily tension which i would keep separate because it's not purely mental
> and it can be let go by deep breaths or exercise.

This refines his 09-09 contentless-remainder claim, which the Job61 note carries. The stores are
now three and distinct:

| store | span | nature | released by |
|---|---|---|---|
| bodily tension | ~hours, arc to arc | not purely mental | deep breaths, exercise |
| what previous thoughts have laid down | long | mental, beneath understanding | recognition |
| the problem itself, unsolved | until solved | not a store of fear at all | solving it |

`[C]` notes. The third is not a store: the book already says nothing in the physical realm is
altered by being ignored. The first is new and bears on the growth material — it is one thing a
person can do that requires no insight at all, which nothing else in Ch 17 offers.

## 4. Fixations may be partly biologically determined

`[A]` 2026-09-10: *"it's possible that fixations are determined by biological tendencies"*,
immediately corrected to *"i meant to say partially determined."*

**This one DID reach the prose, in the one hedged form he gave it.** Ch 15's fixation paragraph
now reads *Some of what makes a fixation may come from biological tendency. The rest was a
choice, repeated until the choice sank below deciding.* — and the strategic account that follows
is now scoped to the chosen part. Before the repair the paragraph said a fixation simply IS a
choice that has sunk, which is a larger claim than he holds. The book says nothing else anywhere
about biology or inheritance. If the doctrine session wants the claim out, or wants it stated
properly somewhere, the site is Ch 15's *What a fixation is made of* section.

## 5. Free choice against motivation determined in advance

`[A]` 2026-09-10, verbatim:

> much of the descriptions of motivations and processes depend of the artificial and blurry
> distinction between freedom to choose and motivation determined in advance. this is a tricky
> subject since both views are correct in their own way and they seem to contradict each other.
> i don't know whether it's good to acknowledge this in the book.

`[C]` note: the book has one place that already treats them as ends of one scale rather than
rival claims — Ch 15's *Disregarding* section, *runs from the involuntary to the chosen, and a
choice repeated often enough stops being made and sinks back toward the involuntary end.*
Whether that covers what he means, and whether to say so openly, is for the doctrine session.
**Take this together with item 4**, since a biological share is one form of determined-in-advance.

## 6. A section on the three things tied to the orientation cycle

`[A]` 2026-09-10, verbatim:

> another thought is to make more explicit the relationship between the three different things
> that are connected with the orientation cycle: fixations, stages of the process arc and single
> thoughts. so much depends on the distinction between positions on the process arc and fixation
> positions that a small section at the beginning of part 3 might be useful.

`[C]` evidence from Job62's own repairs, which is the part worth more than the recommendation.
**Several of today's repairs came from exactly this confusion:**

- the fixation placed at points inside detachment (six sites, Job61's finding)
- Ch 15's dwelling paragraphs, which counted where a PERSON stands when the count wanted where
  a PROCESS is
- *the enthusiasm end*, which means a stage a process passes through in one sentence and a place
  a person dwells in the next — both senses now appear within three paragraphs of each other

**One thing for the doctrine session to weigh:** the distinction is needed as early as Ch 4 and
Ch 7, where the two faces of detachment are described. So a section at the start of Part 3 may
need a shorter first statement earlier in the book.

---

## Carried from Job61's note, untouched and still owed

Listed only so nothing is lost; the Job61 note has all of it in full.

- the three wants behind the basic fears, one per orientation, each for help from the
  orientation one step ahead
- the nine per-type derivations and the object rule (objects come only from realms that are
  not detached) — to be tested first, and Riso and Hudson's wordings still need checking
  against his copy
- the basic desire IS the want and the basic fear is that want in doubt
- the contagion question
- the cautious lean having the deepest understanding of reality
- bodhicitta as register-3 correspondence
