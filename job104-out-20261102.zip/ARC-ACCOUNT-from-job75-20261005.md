# THE ARC ACCOUNT — `[A]`'s material of 2026-09-16, brought up to 2026-10-05

**Re-cut 2026-10-05 by `Job75 coherence 09232026`, at `Job70`'s request.** Supersedes
`ARC-ACCOUNT-from-job72-20260916.md`, which moves to `superseded/`. The parent was cut by `Job72`
and settled with `[A]` on 09-16. Rulings of 09-16 to 10-05 changed it in five places, and a file
that instructs a drafting session must not contradict the rulings it carries. **Each change is marked
`CHANGED` with its ruling. Everything else is the parent's text, except two `[C]` notes `Job74` has
discharged and which are dropped: the placement of the no-sharp-edge sentences in Ch 7, and the
reading of Ch 4's three responses to a failure.**

Everything here is `[A]`'s, except where a line says `[C]`. `Job74` drafted most of it into
*Underneath the Cycle* on 09-23. **The manuscript is what exists. This file is the account that
manuscript is checked against.** The repairs it implies are rows in `FINDINGS-job75-20261005.md`,
and a drafting session works from those rows, not from this file.

Read with `WORD-RULINGS-book2-20261005.md`, letter `c`.

## 1. The two sizes

- A **thought cycle** is one run of the three passages and takes about a second. This is the only
  size at which the passages are literally made — Ch 7 already says the cycle is not an analogy at
  the scale of a single thought.
- A **process arc** at any larger size is a long run of thought cycles.
- Ch 7's three sizes (a thought, an undertaking, a life) all stand. So do Ch 16's descent and
  Ch 15's fifty years of making the same move.
- **CHANGED.** A process arc has no realm (`[A]` 09-12). **The cycles apply to the whole person, not
  realm by realm** (`[A]` 09-23). A want or a fear takes the realm of the matter it is about.

## 2. What holds a long arc together, and what does not

**CHANGED.** The parent quoted Ch 14's *Nothing crosses* and *The arising hands nothing on*. `Job74`
rewrote Ch 14 and neither sentence is on the page now. Ch 14 says instead: *When a thought ends, the
next thought is a separate thought.* What does cross is below.

So a long desire is **not one desire lasting**. Each thought ends and lays down what it was
carrying. The next thought arises out of what previous thoughts have laid down, so nearly the same
desire is raised again. A person pursuing something for a month raises that desire many times a
minute, each time out of what the last one left. The arc ends when the desire stops being raised —
the thing was got, or the desire was given up.

**CHANGED — what crosses.** `[A]` 09-23: *the want becomes a fear, the tension and the content cross
and that creates the next want.* Only two things cross from one thought to the next: the **bodily
tension**, and the **content of the unresolved matter**. A want does not cross and a fear does not
cross; within one thought, the want becomes a fear. The tension produces a desire for relief, and
the unresolved matter gets the fear raised again. *The parent said the bodily tension acts by shaping
what the next cycle raises, never by crossing into it. That is superseded.*

`[C]`, NOT RULED and carried to doctrine: whether *lays down what it was carrying* means the want is
laid down. Laying down into the mental deposits may be a different thing from crossing.

**An arc has no sharp edge.** A cycle belongs to an arc when the desire it raises is nearly the
desire the arc is about, and the mental deposits carry other influences too, so each cycle's
desire is a near copy rather than a repeat. `[A]` 09-16: his *less real* meant exactly this — *the
lack of a clear boundary about which thought cycles would belong to a particular process arc*.

**CHANGED — where wants come from.** Wants and fears come from the mental deposits, *which were
determined by fixations and history* (`[A]` 09-23). The lean is a source of nothing; it sets how
much attention reaches each phase.

## 3. A fear lasts one cycle

A fear is raised in one cycle and **settled only at that cycle's ending** (`[A]` 10-05). A fear
that **returns** is raised again out of the deposits and out of the problem, which still stands.
Nothing is stored and brought back (re-affirmed by `[A]` 09-23).

- **Ignored** — CHANGED: ignoring leaves the bodily tension, the unresolved matter, and the habit of
  ignoring a little stronger. It leaves neither the fear nor the want. The problem raises the fear
  again. **Forgotten** is ignored after the tension has subsided (`[A]` 09-23).
- **Blocked** — CHANGED: **a buried fear is mental deposits** (`[A]` 10-05). The buried fear ended
  with its thought, like any fear. What the burial laid down is a deposit, and later thoughts raise
  fears out of it, even after the problem is gone. Burying is the same turning away as ignoring, at
  a feeling the person cannot bear, and the fear-of-fear loop produces every later difference
  (`[A]` 09-23).

## 4. One cycle, step by step

1. **The arising.** A desire appears. A pain or a pleasure can start the cycle instead, and then
   the desire is to be rid of the pain or to have more of the pleasure. `[A]` 09-16: pain and
   pleasure start a process, and *how is up to wording since we decline to specify the method*.
2. **The development.** The person examines the desire. Examining raises an aversion when the
   examination finds trouble. **`aversion` belongs to this phase only** (`[A]` 09-23): fear and
   disappointment are the two aversions.
3. **The ending.** The aversion meets one of the four fates. Deciding that another step is needed
   is one way of working it through, and then the next cycle's desire is the desire to take that
   step.

If the desire is met and the examination finds nothing, the ending has nothing to dispose of and
the cycle closes.

## 5. Disappointment, and where it sits

A desire disappoints in two ways:

- the **examination judges** that the desire cannot be met; or
- the person **meets an outcome** that did not meet the desire, which is a pain, so a new cycle
  starts.

`[A]` 09-16: *in the case of the world, a new cycle starts with failure. there could be denial in
Z+, a new plan in A or disappointment in B. that keeps disappointment in B for both.* **So
disappointment belongs to the cautious phase in both cases**, and what becomes of a failure depends
on where the person's attention is concentrated.

Ch 7's *a resolution that both satisfies and disappoints* is a different use — the feel of any
ending — and stays.

## 6. Reactive action, truncated cycles, and panic

`[A]` 09-16, three cases:

1. **No thought cycle.** A reflex: the hand comes off the hot pan. No thought preceded the action,
   and no want is raised.
2. **A truncated cycle.** One cycle concludes something (that restraint is too painful, say); the
   next cycle raises the desire to end the pain, and the examining is cut short. `[A]`: *the
   snapping would be another thought cycle where the desire to end the pain was decided, with the
   snapping occurring at the end of a truncated cycle.*
3. **A cycle fully lived.**

**CHANGED — where the action comes.** RULED 09-16: an action is placed by the motive behind it.
Going toward comes at the enthusiastic phase; fending off comes at the cautious phase; the same
outward act can be either (`[A]`: *there is happy aggression and angry aggression*). **The snap
fends off the hurt, so it comes at the cautious phase**, cutting the examining short. *The parent
said the action happens at the ending. That is superseded.* A detached person's actions are placed
the same way (`[A]` 09-23).

**Panic is a truncated cycle, not a reflex** — `[A]`: *panic must involve some sort of judgement and
so a thought cycle so it's separate from a reflex.* **CHANGED:** panic acts on a fear (`[A]` 09-23,
*on fear*), so its action comes at the cautious phase. **A grab** at something wanted is also a
truncated cycle, and its action comes at the enthusiastic phase (`[A]` 10-05, *i agree*).

**Nothing is skipped.** Ch 14's *every process runs a beginning, a middle and an end* stands, and
the book does not say a phase is skipped. A truncated cycle raises little, so its ending has little
to dispose of.

**CHANGED — the stress hypothesis.** RULED 09-23, `[A]`: *yes* — *Stress cuts short the work of a
person's own phase, and the person acts on what is in hand unworked.* A cautious person acts on a
fear that was raised and never weighed; this case is a plain consequence of the truncated cycle and
loses its *I suspect*. The enthusiastic case and the detached case keep *I suspect*. The detached
case is written as *stops disposing of what arrives*, since taking in is not limited (09-10). *The
parent described the cautious case as acting on an unexamined want. That is superseded.*

## 7. Where the fixations act

A fixation is attention concentrated at one phase (`[A]` 09-12), so a fixation acts in every cycle
and therefore at every size.

- **Enthusiastic**: much attention at the arising, cursory examining, so little is raised and little
  is settled.
- **Cautious** — CHANGED: heavy examining, so many aversions are raised, and **each is settled at the
  ending**. *The parent said most are settled before the ending; `[A]` 10-05 ruled that a fear is
  settled only at the ending, and rejected the wording* worked out before the ending.
- **Detached** — CHANGED: little attention at the arising and little at the examining, so wants and
  fears are raised **less intensively, not never** (`[A]` 09-23). What arrives at the ending is
  processed at the caution end and ignored at the enthusiasm end, and where the center sits decides
  which. A detached person wants peace and minds disturbance. *The parent said a detached realm
  generates nothing of its own. That is superseded.*

## 8. What a drafting session must not do with this

- Do not write the phase mapping (which realm is busy in which phase) as doctrine. It is `[A]`'s
  and is carried unruled from 09-12.
- Do not introduce `aversion` outside the cautious phase.
- Do not write *skipping a phase* anywhere.
- Do not write that a realm raises anything, or that a process runs in a realm.
- Do not write *worked out before the ending*.
- Do not write the unease material. It is a separate job.
