# NOTE — the dwell, the cross-talk, and the brake

**LETTER `c`, cut 2026-09-06 by `Job51 drafting 09062026`. Two of the three `b` marks are amended
to say that the account they pointed at is now drafted, and nothing else changed; quarantine
`NOTE-the-dwell-and-the-brake-20260901b.md` as `SUPERSEDED__live__`.** The support half of `[A]`'s
brake and the replacement for *imported sight* are both in `BOOK2-20260906b.md`. **The third mark,
at the rate question, is untouched** — closure 4 has no drafted home yet.

*What the `b` file said of itself, retained:* **LETTER `b`, cut 2026-09-06 by `Job50 drafting 09062026`. Three marks added and nothing else
changed; quarantine `NOTE-the-dwell-and-the-brake-20260901.md` as `SUPERSEDED__live__`.** The marks
sit at `[A]`'s brake, at the ruling that the route cannot be urged, and at the rate question. **No
text of this note was rewritten** — each mark is a blockquote added below the paragraph it bears on,
so what the note said on 09-01 is still readable as it stood.

**SUPERSEDES `NOTE-the-dwell-and-the-brake-20260827.md`, cut 2026-08-27. Quarantine the parent as
`SUPERSEDED__live__`.** One surgical change, **not a retyping**: §5.6 is rewritten as a closure and
§5.7 and §5.8 are new. **§5 is no longer the least settled thing in this file** — `[A]` ruled the
consequence he widened on 08-27, supplied the routing mechanism §6 said did not exist, and offered
one guess, marked as a guess. **§1 to §4 and §6 to §7 are untouched.**

**Session `Job23 doctrine 8-27`. NOTHING IN THIS FILE IS RULED except the two items §1 names as
ruled, and those two are stated there in one line each so they can be cited without reading further.**
**Do not cite anything else here as doctrine.**

**Everything in §3, §4 and §5 follows from the blindness mechanism and stands or falls with it.**
`[A]` has twice declined to say whether that mechanism correctly explains Riso's levels, and said on
2026-08-24 only that he cannot see a better one. That uncertainty is inherited by every derived claim
below and is not restated at each one.

Read with `AUTHOR-RECORD.md`'s 08-27 doctrine block, which carries `[A]`'s words verbatim. This file
is the working-out; the record is the source.

---

## 1. THE TWO RULINGS

**The fall account.** The claim that full-axis collapse is available in full only to the 9 is
**dissolved, not repaired.** Blindness accrues in fractions of one of Riso's levels, one Z crossing at
a time, so there is no such event as a full-axis collapse for any type to have available. The bottom
of the axis is hundreds or thousands of buried crossings.

*It is in neither manuscript.* It lives only in `RULINGS-20260816b.md`, so the dissolution repairs no
book text. **What replaces it is not settled** — `[A]` accepted the dissolution and refused the second
half, saying he does not know whether the 9 is extreme. See §3.3.

**Slowing rather than stopping.** As a matter of the actual process, **a fixation is where the process
moves very much more slowly, not where it halts.** This repairs a tension standing since 08-21, where
all arcs complete and yet a fixation is where a person stops — claims that cannot both be literally
true.

***The wording is open and `[A]` said so explicitly.*** He does not know what the books should say.
**No replacement is to be written on the strength of this ruling.** See §6.

---

## 2. WHAT THE SESSION WAS SENT TO DO, AND WHAT IT FOUND INSTEAD

It opened on the fall account, which had been the standing doctrine question since 08-21b. That closed
in one exchange. What took the rest of the session was the machinery `[A]` produced while answering
the follow-up — a processing account for detachment, which the model had never had.

---

## 3. THE DWELL

### 3.1 Where a fear is handled

`[A]`'s relocation: **the fear lives in a realm, so the fixation that handles it is that realm's
fixation, not the person's type.** A person has two, and every fear is routed to one of them. Types do
not process anything; realms do.

### 3.2 The three fixations, now complete

Enthusiasm and caution act on a fear **before** the crossing. Enthusiasm underruns the examination —
`[A]`'s own content for what it jumps over, *the fear is something more is happening that i want to
think about* — so contingencies arrive unprocessed. Caution resolves most of them there, and its
failure is the opposite one, overload.

**Detachment acts at the crossing, and its instrument is dwell time.** Z− carries a lean of caution;
every process passes through Z−; a Z− fixation moves slowly there and so is more able to process the
fear. A Z+ fixation moves quickly through and processes less.

**A general consequence, and it repairs an 08-24 objection.** Everyone passes through both ends of the
Z range, so presence and dwell are different things. The objection that no Z− fixation means no
protection — which sat badly against anyone of any type being found high or low — dissolves: a Z−
fixation stops there, a Z+ fixation is moving when it goes past. Enthusiasm and caution move quickly
through **both** ends, so they get little dwell at either; caution does not need it, having worked
upstream, and enthusiasm did neither.

*`[C]` reading, not `[A]`'s:* the two ends of the Z range inherit their neighbours — Z− gets caution's
examining, Z+ gets enthusiasm's hurry — so the three accounts are not independent. Detachment supplies
the dwell; what is done during it is borrowed from whichever orientation the position leans toward.

### 3.3 What this does to the 9 — OPEN

On dwell the 9 is **extreme in spread rather than in speed**: a Z− nine processes unusually well in
both realms, a Z+ nine unusually badly in both, a mixed type averages. On resolution rate the fast
faller is the type underrunning the examination in both realms, which is the enthusiastic aligned
type, not the 9.

**`[A]` has not accepted *extreme* in any form.** The spread reading was shown to him and not disputed,
which is not the same thing. What the 9's realm-coupling is *for* — rate, or the missing vantage —
remains open, with the vantage reading being that the 9 has no realm standing outside the drift.

---

## 4. THE CROSS-TALK

**`[A]`: what crosses between realms is recognition — *maybe not the details but the need for
caution*, and *plain wariness*, not caution the orientation.**

So what crosses is a warning, not a capability and not content. The person learns that this is a place
where something goes wrong without being noticed. It makes them look; it does not do the work. It
flows from the realm that has the wariness to the realm that does not.

**The awareness gate is part of the mechanism rather than a precondition outside it.** To recognise a
process as a process rather than as this one fear, a person needs to have seen it run in more than one
setting; the second realm is the second setting. This connects to `[A]`'s 08-26 way out — conscious
recognition of the buried fears one by one, *or better, a recognition of the automatic burial
process*. The first route is local to a realm; only the second generalises.

*`[C]` observation:* book 1 already says the aligned types have no internal contrast to reveal that
the realms differ, and grow by discovering that they do. So the types least able to develop cross-talk
unaided are the ones the book says must be told — which makes cross-talk the model's own account of
why the teaching helps.

### 4.1 Orientation movement — `[A]`, hedged, and DELIBERATELY NOT IN THE TEXT

> movement in the lean happens but we don't want people assuming that orientations move easily if ever
> even though it would be possible. maybe possible only if riso's basic fear is dissolved.

**He added that he is content not to mention movement in the lean for now.** So: held as doctrine,
absent from the text, and no sentence is written on it.

*Why the books are not wrong as they stand.* They say in three places that the position holds and the
grip loosens — Ch 4's *awareness, not the elimination of the orientation*; Ch 13's *not moving to a
better orientation*; book 2's *nothing about a person changes type*. Both books hedge with *usually*
and *ordinarily*. If orientation movement requires the basic fear to be dissolved, it is a
liberation-scale event — the basic fear sits at the top of the chain, and core fears are stable
because hidden in blindness — so anyone for whom an orientation moved is at the top of the ladder, and
the flat-sounding statements are defensible rather than merely hedged.

**Three timescales, where the model had two:** the stress offset, temporary and read now; the lean,
**long lasting** and slowly movable — `[A]`'s word, 08-27; and the orientation, movable only at the
dissolution of the basic fear, if at all.

*A `[C]` error corrected on the record:* `[C]` reported the 08-23 ruling as calling leans *permanent
offsets* and proposed correcting it. **`[A]`'s own words were *the lean is a static adjustment to the
fixation*.** *Permanent* is asserted of the lean in no live file — not the handoff, not either
manuscript, not the record. There was nothing to correct. *Long lasting* is an addition, and *static*
stands alongside it: static is how the offset is read, long lasting is how long it holds.

---

## 5. THE BRAKE — the largest thing in this file, and the least settled

### 5.1 The problem

`[A]`: **the lower the level of health, the less able a person is to dissolve fears.** Two mechanisms
already in the model produce it — Riso's descent has the operative desire become *not to know*, and
`[A]`'s 08-25 account has blindness compounding, since the disturbance is made by the same act that
must not be examined.

**A positive loop with no brake takes everyone to the floor.** `[A]` rejected the proposal that most
people never start: *it looks to me like a bell curve with most people at average levels.*

### 5.2 `[A]`'s brake

> people struggle harder when things go bad and other support them in resisting

**This is a restoring force, not a weakening of the loop** — it grows with displacement, which is what
produces a bounded distribution. `[C]`'s four candidates were all ways of making the loop weaker and
none of them gives the shape.

> **WRITTEN 2026-09-06 by `Job51 drafting 09062026`**, in `BOOK2-20260906b.md`, at the health axis
> chapter's section on what reaches someone the consequences no longer reach. The support half of
> this brake is now drafted text and this section is no longer the only place it exists.
>
> *What `Job50` wrote here, retained:* **MARKED 2026-09-06 by `Job50 drafting 09062026`.** The support half of the quoted brake —
> *others support them in resisting* — had no content when this was written. `[A]` supplied it on
> 09-05 and it is closure 6 of `CLOSURES-SITED-job49-20260905.md`: an intervener supplies comfort
> and calming, which raises what the person can bear, and divides a truth small enough that no
> part of it is a threat by itself. The intervener needs sight of their own in order to divide it.
> Nothing is handed to the person.

### 5.3 Why the brake survives the blindness — `[A]`: *yes, consequences*

**The trigger is consequences in the world, not any recognition of one's own condition.** Blindness
destroys the ability to see one's own condition; it does not reach the job lost or the money gone. So
the trigger sits outside the blindness and keeps working through it, and a person can be driven to
struggle without seeing why.

The support half is not the falling person's own faculty either, so it is not degraded directly. It
erodes by a different route and with a lag, people low down being harder to help. *`[C]`:* that
predicts the restoring force weakening **near the bottom** rather than everywhere, which makes the low
tail thin but real.

### 5.4 `[A]`'s correction, and it is the shape of the thing

> i think the effort is resisting the consequences but fixing or hiding are optional

`[C]` had the mobilisation supplying one pool that fixing and hiding divide. **`[A]` puts the
mobilisation upstream of both: the response is resisting the consequences, and how it is routed —
fixing the failing, or hiding it from oneself — is the open variable.**

**The blindness does not weaken the response. It selects the route.** So the brake and the loop are
not two forces balancing; they are one response routed by sight, which is the quantity the whole model
runs on. Consequences: enormous effort low down is compatible with the brake being real, since the
effort is going somewhere else; and what fails at the bottom is aim, not energy, which is what the
model claims elsewhere.

### 5.5 The widening — `[A]`

> in the sense that blindness is the cause, all the levels involve wanting not to know

**Not only from Level 7 down.** Level 7 is where the not-knowing becomes explicit in Riso's own
wording, not where it begins. This removes a discontinuity `[C]` had built: routing is a **proportion**
that shifts as sight fails, not a threshold that switches on part way down — which matches a descent
that accrues in fractions.

**NOT RULED, on `[A]`'s own test:** *it think it is a corollary to the blindness mechanism. does it
need a rule?* A consequence of the mechanism rather than a choice, so ruling it would let it survive
its premise if the premise is revised.

*`[C]` observation, and it exceeds what the correspondence can carry:* if the not-knowing is present
at every rung, the alignment of Riso's ladder with the orientations is one quantity read at nine
heights rather than nine facts lined up. **The correspondence is approximate at four sample points by
`[A]`'s reconfirmed 08-24 ruling, so this cannot be asserted.** Recorded as a shape, not a claim.

### 5.6 RULED 2026-09-01 — this section is no longer open, and the mechanism it said was missing exists

**`[A]` answered the question he widened on 08-27.** *`[C]`: if the route is selected by sight rather
than chosen, urging someone to fix rather than hide does nothing, because you are asking for an
output the person cannot select; what helps is whatever restores sight.* **`[A]`: *i agree.***

**The route cannot be urged, only re-sighted.** *The case `[C]` argued and he accepted:* the second
brake works by imported sight, so if the first brake's routing is also by sight, the intervener is
not adding a second force — they are redirecting effort the person is already spending. **The two
brakes become one mechanism met twice**, and the levels-do-not-wrap derivation falls out of them
rather than being deduced beside them.

> **WRITTEN 2026-09-06 by `Job51 drafting 09062026`.** The replacement account is in
> `BOOK2-20260906b.md` at the same section named above, and the paragraph on urging there carries
> the pressure-stress-tolerance reason. **The wording *imported sight* now appears nowhere in either
> master.**
>
> *What `Job50` wrote here, retained:* **MARKED 2026-09-06 by `Job50 drafting 09062026`. *Imported sight* is superseded.** `[A]` ruled
> on 09-05 that what an intervener supplies is capacity and a truth given a little at a time —
> closure 6 of `CLOSURES-SITED-job49-20260905.md`. The intervener's sight is a qualification they
> need in order to size the pieces, not something transferred to the person. **The conclusion this
> paragraph draws is untouched:** the route still cannot be urged, and the intervener still adds no
> second force. Urging fails for a reason now stated — urging is pressure, pressure is stress, and
> stress lowers the one thing that decides the outcome.

### 5.7 RULED 2026-09-01 — the routing mechanism, and it is `[A]`'s

> the basic question for the struggling person is which is more painful, staying as they are or
> facing the pain of unburying their fears and unfortuanately, because of blindness, it is a question
> of immediate pain, not the prospect of long term improvement.

**Blindness does not corrupt the comparison. It removes one of the terms**, leaving only what can be
felt now. That is why the route is not choosable, stated as a mechanism rather than as a property of
sight.

**It also gives the brake its shape, which §5.2 had only as a requirement.** Consequences press, the
pain of staying rises, and the person faces the fear when it passes the pain of unburying. **A
restoring force that grows with displacement** — which is exactly what was needed when `[A]` rejected
everyone-to-the-floor with *a bell curve with most people at average levels*. **And the low tail
comes out thin but real with no separate assumption:** further down there are more layers to unbury,
so the pain of facing is higher and the crossing point sits further out.

> **MARKED 2026-09-06 by `Job50 drafting 09062026`.** The rate this section leaves open — whether a
> person further down is held more by rising stress or moved more by pressing consequences — has one
> source for both terms as of 09-05. Closure 4: blindness leaves trouble unhandled, and that same
> trouble raises the stress on one side and the pain of staying on the other. **The thin low tail is
> unaffected**, having always been a pain quantity.

***Measured 2026-09-01, because `[A]` thought this might already be in the books.*** The comparison
occurs at **one site in the whole set** — *a small discomfort now against the larger one that staying
would cost*, in the Z+ sketch, where it governs dropping a single endeavor. **Nothing in either book
states it of the brake.** §6 below is unchanged: this is drafting work.

### 5.8 `[A]`'s GUESS, MARKED AS ONE AND NOT RULED — how the comparison is ever made

> my guess is that the person makes the comparison in a rare moment of clarity, and forgets it again
> many times until there is enough of a foundation to do it consciously.

**Offered as a guess and recorded as one.** He said first that blindness definitely blocks the
opportunity to compare, and called the question a hard one.

**What it does: it gives the forgetting/blindness distinction its home.** That distinction has been
ruled doctrine since 08-27 and stated nowhere in either manuscript, and
`NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` §5.4 says it belongs beside the brake.
**Each condition now has a job: blindness is why the moment of clarity is rare, forgetting is why it
does not carry.** *That names what each does rather than how to tell them apart, which is what the
narrow 08-27 ruling deliberately left aside.*

**Checked before recording, and neither collides.** §5.6's ruling stands: the moment of clarity is
the sight arriving, and it arrives unbidden, so urging still cannot produce it. **The forbidding on
insight mid-collapse is untouched** — these moments fall in the ordinary run, not during a drop.

**And it supplies a mechanism to a ruling that had none:** a level is many turns and the Levels are
recognition markers rather than units. **The foundation accumulating is what makes a level take many
turns.**

*`[C]`'s observation, unruled, recorded as a shape and not as a claim:* this is a second accumulation
running opposite to the first — evasion lays layers down, retained sight builds foundation up.

---

## 6. WHAT THIS COSTS THE TEXT

**Two sentences now need new wording and none exists:** book 1 Ch 15's *a type is not a place a person
stands but the place they habitually stop*, and book 2 Ch 7's near-twin. They were already flagged as
needing repair together.

**This is not a substitution.** The sentence's force is its contrast — standing is static, stopping is
something the process does. A long dwell is nearer to standing than a stop is, so replacing the verb
blurs the contrast rather than sharpening it. Whoever repairs it must rebuild the contrast on
different words or decide the body keeps the crisp version and the precision goes elsewhere.

***`occupies` was considered and set aside 08-27.*** `[A]` suggested it; it is doing five jobs across
the two books at nine sites, and it collides with *stands* inside the target sentence, book 1 Ch 16
already pairing the two directly. **`[A]`: *no, not now.*** Do not revive it without dealing with the
nine sites.

**The brake needs writing, not repairing.** No chapter says that the trigger is consequences or that
sight selects the route. That is drafting work and it is not on the job list.

**A text item `[A]` raised, not doctrine:** the books say *orientations* early and *fixations* later,
**which is how it should be** — he is not asking for it to be levelled — but the transition wants
handling deliberately rather than left implicit.

---

## 7. OPEN, IN PLAIN WORDS

| Question | Where |
|---|---|
| What replaces the availability claim, and is the 9 extreme in anything? | §3.3 |
| Is the 9's realm-coupling about rate or about the missing vantage? | §3.3 |
| Does the mobilisation account stand as assembled? | §5.4, §5.6 |
| If sight selects the route, is *restore sight* the model's practical claim? | §5.6 |
| What do the two stopping sentences say instead? | §6 |
| Do the stopping sentences and the 08-25 exact-position sentences get settled together? | §6 — put to `[A]` 08-27, unanswered |
