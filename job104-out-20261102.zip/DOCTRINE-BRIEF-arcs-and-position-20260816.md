# DOCTRINE BRIEF — what sets a realm's place on the Z stretch

**Not a handoff.** Deliberately named so it cannot be mistaken for one: two files masquerading as
`HANDOFF-20260815b.md` is what caused the 08-16 fork. This is one question, for one session.

Raised by `[A]` on 2026-08-16 in the drafting session `drafting-8-15`. **The drafting session
produced the framing below and had been inside the Z material all day; discount its constructions
accordingly.** Provenance `[A]`/`[C]` throughout, and the distinction is load-bearing here.

---

## 1. THE QUESTION, IN `[A]`'S WORDS

Two asks, hours apart, which turn out to be one question from opposite ends.

> since every thought completes, do you think it's more accurate to say that the fixation chooses
> the residue that leads to the next thought?

> the place is related mostly to arc cycles but a fixation at z might also be related to it. that
> brings up the question of how do fixations affect the mini cycles/arcs?

The first asks what a fixation *does* to an arc. The second asks what the arcs *add up to*. **`[A]`
has not joined them; `[C]` observes that they are the same claim from two ends.**

**`[C]`'s sharpening, flagged by `[A]` and kept separate:** `[C]` restated the second as *"a realm's
place on the Z− to Z+ stretch is the aggregate of where its arcs are resting."* `[A]`: *"i didn't say
that but it sounds good."* **The loose form is the claim.** "Aggregate" is one candidate mechanism
among several — accumulation, frequency of completion, depth of frozen context, or the current arc's
position averaged over time are all different and are not distinguished by what was said.

## 2. WHAT IS ALREADY ON RECORD — most of the first ask is answered

Book 1's Ch 15, the paragraph following the four sketches:

> the endings differ more than anything else: chosen under duress, decided, dropped, overwritten.
> **A type shows most nakedly in how its thoughts end.**

> What arises differs by type… **because the fixation selects the population of arisings before any
> single arc begins.**

So a fixation **selects what arises** and **shapes how it ends** — both ends of the arc, in `[A]`'s
own text. R7.5 gives it per type (*"The 3 starves every ending," "The 6 substitutes at every
ending"*), R4 defines a fixation at arc level (the next transition failing to start), and book 1's
Ch 5 supplies the link between arcs: *"When one thought ends the next arises conditioned by it."*

**What is not on record is the second ask** — what the shaped arcs amount to for the realm.

## 3. THE FINDING THAT MAY DECIDE IT — book 1 already gives the self-ward twin

Ch 15, *"What the Health Axis Is Toward"*, L1546:

> Where a person sits on the health axis is a different kind of thing: **not a stance freely taken
> but a place arrived at, the settled residue of how the fixation has been handled over time.**

**A place on an axis, defined as the settled residue of how something has been handled over time.**
That is the shape of `[A]`'s proposal — self-ward, and already written.

**And R2 supplies the symmetry**: one currency, two objects, realm-ward and self-ward. If the
self-ward place is a settled residue of handling over time, the realm-ward place being generated the
same way is not a new kind of claim but the other half of one already made.

**`[C]`, and it is an inference, not a quotation:** this is the strongest support the proposal has,
and it is `[A]`'s own sentence rather than a construction. **It is also short enough to be suspect —
exactly the shape the sharpening rule names.** Rule it, do not adopt it.

Book 1's own mechanism for how momentary becomes habitual is in the same chapter, L1476–1478:

> A stopped arc does not disappear. It persists as unresolved context, and arcs arising within it
> can stop partway too — so the stopping goes farther, into new layers: arcs frozen inside arcs.

> each layer is older and longer-lived than the layers below it. Thoughts churn by the minute; the
> fixation that frames them moves at the pace of a life.

**Nesting, not averaging.** If that is the mechanism, the habitual is not a statistical summary of
the momentary — it is *frozen* momentary, layered. Which is a different answer from `[C]`'s
"aggregate", and better evidenced.

## 4. A VOCABULARY HAZARD, MEASURED — "residue" does three jobs

Same shape as the arc/range finding, and it matters more, because `[A]`'s first ask uses the word.

| Sense | Where | What it is |
|---|---|---|
| **Neighbor trace** | Ch 11 L1133 | *"a motivational residue from its neighbor. Z− carries a trace of B's corrective concern"* — and **Z0 is the absence of residue** |
| **Unresolved context** | Ch 15 L1476, App G L2301 | what a **stopped arc** leaves; nests |
| **Settled residue of handling** | Ch 15 L1546, and L1626 at Level 1 | the **health-axis place** |

**`[A]`'s question — "the residue that leads to the next thought" — is sense 2. Ch 11's
"Z0 is the absence of residue" is sense 1.** Whether they are one thing or three is not settled
anywhere, and the answer changes what the proposal claims. **Settle the word before settling the
question.**

## 5. WHAT MUST NOT BE BUILT ON

- **`NOTE-overlap-and-truthfulness-20260815.md` §1 — unruled.** It is about residue in sense 1 —
  whether the Z− aversion is carried into the Z+ desire — and it already identifies zero overlap
  with Z0. Any account of the Z position in terms of residue runs straight into it. **Rule §1 first,
  or keep clear of it.**
- **`NOTE-small-arcs-and-the-step-20260815.md` — unruled, and required reading for this.** `[A]`'s
  suspicion that the step is an amalgam of smaller arcs is the same territory; its §7.2 and §7.3 are
  open. Nothing is built on it and nothing should be. **It was not in the drafting session's file
  set, which is why that session stopped rather than constructing the join.**

## 6. THE HAZARD THIS QUESTION IS

**It crosses the two scales, deliberately.** The standing hazard: *"the small arcs are momentary
process; the relation between the orientations and the figure is habitual fixation… a drafter who
lets one read as the other produces a chapter wrong in a way that looks like completeness."*

`[A]`'s proposal makes a **habitual** fact out of **momentary** ones. That may be exactly right — §3
suggests book 1 already does it self-ward — but crossing the line deliberately and crossing it by
accident produce the same sentences, and nothing currently distinguishes them. **A ruling here should
say which crossings are licensed, not only whether this one is.**

## 7. WHAT A RULING WOULD CLOSE

- **Position or exercise** — whether a realm's place on the stretch is something the realm *is* or
  something the person *does*. Currently blocks book 2's Ch 11 and the half-attainment derivation.
- **The residue question** itself.
- **Two book 2 Ch 5 sentences** — the Three's *"no step back and no vantage point on either one"* and
  the Nine's *"seeing twice over"* — both waiting on the first item.
- **Possibly R2's fall account**, *"available in full only to the 9"*, which R11 left open.

## 8. FILE SET, AND CHECK IT FIRST

`RULINGS-20260814.md` · `CONSOLIDATED-THEORY-20260814.md` · `rev2-0814b.md` ·
`NOTE-small-arcs-and-the-step-20260815.md` · `NOTE-overlap-and-truthfulness-20260815.md` ·
`BOOK1-INDEX-20260815.md` · this brief — **seven.** Say what is missing before starting.

**`rev2-0814b.md` is to be grepped, not read through.** Every quotation above was measured from it;
none came from a summary. Two claims died this session that had come from summaries of it.

## 9. WHAT THIS BRIEF DOES NOT AUTHORIZE

Touching book 2's text; re-opening the architecture (`BOOK2-ARCHITECTURE-20260815b.md` is live);
or adopting §3's inference because it is tidy. **§3 is `[C]`'s, arrived at on request, and is the
fourth time this session that a short inference of `[C]`'s looked stronger than it was.**
