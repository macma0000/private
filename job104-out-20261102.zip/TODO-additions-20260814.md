# TODO — items generated 2026-08-11 to 08-14, to merge into `TODO.md`

Kept separate rather than rewritten into `TODO.md`, so nothing of yours is clobbered. Note the
existing `TODO.md` header is stale: it names `rev2-recursion.md` as master. Current files are
`rev2-0811f.md` (book 1) and `DRAFT-alt-version-0811i.md` (book 2).

## WORKING PRACTICE — changed 2026-08-14

`[A]` **New thinking goes into notes, not into spot edits of book 1.** It may be that book 1 is
never rewritten and the rewrite goes directly into book 2 instead. Book 1 stays the repository.

`[C]` Two consequences worth holding a future session to. First, notes must now be **written to be
written from** — quoting the text they would change and where it sits, not merely describing the
idea, because there may be no later pass over book 1 to reconstruct the context from. Second, the
notes are already at five files and will sprawl; a spine is needed before that becomes the scattered
material the handoff warns about.

## VERIFY — against sources, before print

- **Riso and Hudson on upward movement.** Two things ride on it: whether Chapter 15's claim that
  the added material accounts for *the motion their rule deliberately leaves open* is accurate, and
  whether any new ascent mechanism can be described as filling a gap. If they do give an account of
  climbing, that sentence is wrong in a way that reads as modest and is hard to spot.
- **Nirvana principle** — content confirmed, the usual attribution of the term is not.
- **Where Freud locates self-observation** (split-off ego, or superego precursor).
- **Horney** — that she gives no healthy form of moving away.
- **Object relations / interpersonal psychoanalysis** as the field's own correction of the purely
  intrapsychic frame.

## DAMAGE — not design questions, unaffected by any parking

- **Chapter 6's seeing paragraph does not parse.** `non volitional seeing has different way to
  fail`; `keeps looking until it the discomfort overcomes the understanding`; and `mechanism` twice
  for a psychic-realm phenomenon. Last session's blindness rewrite landed incompletely and it has
  been in the master ever since.
- **Appendix D, harmonic section:** `observation reads the S realm` should be **H realm**. One word,
  carried on the TODO since before this session.

## RULINGS OWED

- **`competence` → `strength`.** Writer 2 has now said twice he will use "strength" throughout, and
  has applied it in his latest draft. 26+ sites in book 1, and it collides with "strengths and
  weaknesses" — visibly, in his own text, where `Each strength is real` is followed three paragraphs
  later by `They also differ in their weaknesses`.
- **The magnitude claim.** Chapter 3: `Much human suffering comes from trying to use one realm's
  principles in the other`. `[A]` agrees with writer 2 that this is too strong. The *mechanism* is
  load-bearing and stays; only the estimate of how much of life it accounts for is at issue.
- **Chapter 13 against Chapter 17** on whether Z→A is a transition at all. Blocks any section led by
  "the three transitions."
- **Writer 2's DRAFT.docx** — rebase his changes onto current book 2, or read his version standalone
  first. He was working from `0811b`, five versions stale; see `REVIEW-changes-20260811.md`.
- **Detachment as volitional.** Writer 2 has asserted three times, independently, that it is chosen
  — on seeing, on falling asleep, and on looking away from something disturbing. Settled doctrine
  says blindness is not chosen. He is the natural test subject and keeps returning the same reading.

## STRUCTURE — book 1

- **Design intent (2026-08-11):** say nothing beyond the simple orientations before the integration
  and disintegration cycles; then maybe add the transitions and say the orientations are fixations
  there. Under this, two of 2026-08-11's edits want deleting rather than refining — see
  `REVIEW-book1-changes-in-context.md`, items 1 and 2.
- **Swap Chapters 5 and 6.** 27 references, individually. Now interacts with the design intent above.
- **Chapter 6's two forward references:** `see Chapter 12.)` and `(Chapter 11 says why)`.
- **Prediction language,** roughly fifteen sites, Appendix F the hard case.
- **Review 2026-08-11's ten changes** — `REVIEW-book1-changes-in-context.md`. In progress.

## STRUCTURE — book 2

- **Chapter 2's fate.** The derivations now carry each type's recognizable qualities, so the reader
  meets the nine types twice.
- **No growth material.** Book 2 ends on nine failures; Chapter 1 promises strengths and weaknesses.
- **The letters.** Whether to write `orientation A` and `realm H`. Book 2 is where the notation is
  introduced and the cheapest place to test it.

## PARKED THEORY — in the notes

- `THEORY-NOTES-freud-correspondence-20260811.md` — the agencies as transitions; the id as Z's blind
  face; the A/B relation intrapsychic versus interpersonal, which wants Chapter 9; fixations as
  blockages in the transition cycle, and whether that makes the orientations derivative.
- `THEORY-NOTES-cycle-release-and-climb.md` — forward movement as release of the fixation; the
  Z−/Z+ question and re-engagement as what raises a level.
- `CASE-NOTES-observed-people.md` — the 3/6/9 case, and the leans reading fitting where pure types
  did not.

## CLOSEABLE

- The item saying the attention doctrine is nowhere stated in Chapter 6. It is stated, and
  Appendix D cites it correctly.
- The Chapter 3 caution paragraph, if writer 2's `Do not take anything here as gospel` stands as the
  single caveat, as it now does in book 2's Chapter 1.
