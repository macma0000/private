# CENSUS — WHAT BOOK 1 HAS AND BOOK 2 DOES NOT — FIRST PASS — 2026-08-31

**AMENDED 2026-09-01, new date `CENSUS-book1-into-book2-20260901.md`. Quarantine
`CENSUS-book1-into-book2-20260831.md` as `SUPERSEDED__live__`.** One surgical change, **not a
retyping**: §5.2's lifted item, *The Two Faces of Z0*, is closed by `[A]`'s continuum ruling. **The
census itself is unchanged and still unfinished** — the three things its first pass did not reach,
the figures among them, are still not reached.

**Session `job34-architecture-20260831`.** Cut on `[A]`'s instruction of 2026-08-31: *everything in
book 1 that doesn't go into book 2 should be carefully decided.* No such census existed. **This is
the first pass and it is not finished** — what it did not reach is at §5.

**The standard it works to.** Book 1 is not being fixed; it is a reference for writing book 2
(`[A]`, 08-31). So this file never asks whether book 1 is right. It asks one question of each unit
of book 1: **is there a decision on record about whether book 2 carries it?** Three answers are
possible and only the third is work:

- **PLACED** — it is in book 2's drafted text, or in an architecture file that says where it goes.
- **CUT** — a ruling says book 2 does not carry it.
- **UNDECIDED** — neither. It is simply not there, and nobody has looked at it.

**Counts are `LC_ALL=C wc -w` over each unit including its heading.** Book 1 `rev2-0814m.md`,
56,943 w. Book 2 `BOOK2-20260831.md`, 17,851 w.

---

## 1. THE FRAME — every unit of book 1, and where it stands

| Book 1 unit | w | Book 2 disposition | Status |
|---|---|---|---|
| Foreword | 606 | Foreword, 194 w | PLACED, compressed |
| Ch 1 Introduction | 1,184 | Introduction 457 w + Ch 1 553 w | PLACED, compressed |
| Ch 2 The Nine Types | 3,192 | Ch 2, 3,124 w | PLACED |
| Ch 3 The Two Realms | 1,880 | Ch 3, 684 w | PLACED, **one section absent — §3** |
| Ch 4 The Three Orientations | 1,352 | Ch 4, 593 w | PLACED, but **two 08-15 additions unapplied — §3** |
| Ch 5 Integration and Disintegration | 3,638 | **SPLIT** — the cycle to Ch 7 (922 w), the depth material to Part 3 | PLACED, split ruled 08-15 |
| Ch 6 Orientations Are the Enneatypes | 3,486 | Ch 5, 4,813 w | PLACED, and it **grew** |
| Ch 7 The 3×3 Grid | 1,145 | Ch 6, 516 w | PLACED; **its figure misfiled — §5.4** |
| Ch 8 Positional Relationships | 936 | Ch 8, 498 w | PLACED, compressed |
| Ch 9 Relational Dynamics | 2,419 | Ch 9, 2,048 w | PLACED |
| Ch 10 Directions in the Classical Figure | 1,441 | Ch 10, 1,098 w | PLACED |
| Ch 11 Leans and the Classical Wings | 2,575 | Ch 11, 2,220 w | PLACED |
| Ch 12 Comparison with Classical | 2,353 | proposed Appendix B, with book 1's App D | PLACED, undrafted |
| Ch 13 Spiritual and Philosophical Parallels | 1,957 | Part 4 | PLACED as a sketch only |
| Ch 14 Learning to See | 1,907 | Ch 12, Part 2 (`[A]`, 08-15) | PLACED, **undrafted — the one gap inside Part 2** |
| Ch 15 The Depth of Fixation | 4,145 | Ch 15 | PLACED, architected 08-30/08-31 |
| Ch 16 The Descent and the Climb | 3,038 | Ch 16, merged with rising | PLACED, architected |
| Ch 17 Origins | 2,736 | Ch 14 | PLACED, architected |
| Ch 18 Endings | 3,480 | Part 4, plus the leverage problem at Ch 16 | PLACED as a sketch only |
| Additional Topics for Future Exploration | 932 | **CUT, one item lifted out — §5.2** | DECIDED 08-31 |
| App A Reference Card | 646 | proposed Appendix A | PLACED |
| App B The Complete Relational Map | 748 | proposed Appendix D | PLACED |
| App C Triad and Hexad Walks | 388 | proposed Appendix C | PLACED |
| App D The Classical Triads | 2,000 | proposed Appendix B, with Ch 12 | PLACED |
| App E What This Book Borrows | 903 | proposed Appendix E, gaining the deposits | PLACED |
| App F A Note on Designing the Tests | 1,896 | **Appendix F, restored to its own letter — §5.1** | DECIDED 08-31 |
| App G Core Dynamics | 3,550 | G.1 → Ch 15, G.2 → Ch 14, G.3 → proposed Appendix G | PLACED |
| App H A Note on Working with AI | 1,259 | proposed Appendix H | PLACED |
| App I A Hard Case — Mathematics | 268 | proposed Appendix I | PLACED |
| Conclusion | 416 | **CUT; book 2 writes its own, one item lifted out — §5.3** | DECIDED 08-31 |

---

## 2. THE APPENDIX THAT WAS DISPLACED BY A LETTER

**Book 1's Appendix F is *A Note on Designing the Tests*, 1,896 w. Book 2's proposed Appendix F is
*Karen Horney*.** The 08-15b architecture's appendix list assigns every other letter from book 1's
own set, so this one reads at a glance as carried across. It is not: the Horney material comes from
book 1's **Ch 13**, and the test-design appendix appears nowhere in either architecture file or in
book 2. **The strings `designing the tests`, `test design` and `calibration` return zero across
`BOOK2-20260831.md`, `BOOK2-ARCHITECTURE-20260815b.md` and
`BOOK2-PART34-ARCHITECTURE-20260831.md`.**

*This is exactly the failure mode the handoff records for stale rows: the shape looks complete, so
nobody checks the contents.* **It is a decision for `[A]`, not `[C]` — the appendix commits the book
to a testing programme, which is a claim about what the model is for.**

Two smaller units in the same position, neither mentioned anywhere: **Additional Topics for Future
Exploration** (932 w) and **the Conclusion** (416 w).

---

## 3. THE COMPRESSION, AND IT IS THE LARGER FINDING

Whole missing chapters are visible. **What is not visible is that the drafted chapters are
systematically shorter than the book 1 chapters they were written from, and no record says what came
out.**

Book 1's Ch 1–11 and Foreword together run **23,854 w**. Book 2's drafted equivalent — Foreword,
Introduction and Ch 1–11 — runs **17,840 w**, and that is after Ch 5 *grew* by 1,327 w. **So
something over 7,000 w of book 1 has no counterpart inside the range everyone treats as done.** Some
of it is deliberate tightening and some of it is content. Nothing distinguishes the two.

A vocabulary screen over book 1's sections in that range — distinctive terms present or absent from
book 2 — names candidates. **THREE WERE CHECKED BY HAND ON 08-31 AND TWO OF THE THREE WERE FALSE.
The corrections are below, and they matter more than the finding did.**

- **CORRECTED — Ch 4 §*The Three Moves Against a Negative*, 191 w, IS IN BOOK 2.** It is Ch 4's
  second-to-last paragraph, rewritten as prose with the bullets and the heading gone: enthusiasm has
  no native answer to a negative and turns toward the next positive, the loss neither worked through
  nor fled; caution engages, and the trouble receives attention, analysis, management; detachment
  steps back, or on its blind side does not look. **Nothing is missing but the Horney credit**, and
  that is proposed Appendix F's subject. *This was reported as the most serious absence in the book,
  on a screen hit plus a reading of book 1's side alone. It is the error §4 rule 2 warns about,
  committed in the same file that states the rule.*
- **CORRECTED — Ch 3 §*Are These Realms Really Separate?*, 451 w, IS SUBSTANTIALLY IN BOOK 2.** The
  argument is inside Ch 3's computer paragraph: neither realm is the real one, each can be described
  entirely in the other's terms, each runs on principles the other does not use. **What is dropped is
  the framing, not the argument** — the yin and yang image, *each contains the other completely*,
  *neither is more fundamental*, and the sentence saying the model's central claim depends on this.
  Whether book 2 should say that last thing out loud is a real question and a small one.
- **STANDS — Ch 3 §*This Book as Viewed through the Two Realms*, 128 w, is absent everywhere.** That
  the book is psychic-realm material written in physical-realm language, which the section calls the
  most serious trap for the reader; and the split between explanation and advice, the explanation
  being mind to mind and the advice being psychic material translated into action. **`advice`,
  `imprecise` and `precision` return zero across book 2 and both architecture files.** UNDECIDED.

**What the three checks are worth as evidence.** Two of three candidates turned out to be tightening
rather than loss. **That is the first real reading of the 7,000 w, and it points the other way from
the finding it was meant to support:** the compression may be mostly craft. It also means the screen
cannot decide anything on its own, and a section-by-section census of Ch 5 to Ch 11 has to be read
rather than measured.

**Ch 4 does carry a real debt, and it is not this one.** Two additions `[A]` ruled on 08-15 are still
unapplied — the native-desire clause at first use of *competence*, and looking versus seeing stated
in detail, which the architecture calls load-bearing for *blindness is not chosen*.

---

## 4. METHOD, SO THE NEXT PASS CONTINUES RATHER THAN RESTARTS

1. Take book 1's sections in order and ask only the three-way question at the head of this file.
2. **NEVER REPORT A PASSAGE ABSENT WITHOUT READING BOOK 2'S CHAPTER THROUGH.** A screen or a keyword
   grep can nominate a candidate; it can never settle one. **Book 2 is a rewrite, so a surviving
   passage almost always survives under different words, and a keyword miss means nothing at all.**
3. **THE TWO KINDS OF CHECK HAVE DIFFERENT RELIABILITY, AND THIS IS THE MAIN LESSON OF THE FIRST
   PASS.** A **unit-level** check asks whether a whole subject appears anywhere — three of those were
   made on 08-31 and all three held, because the subject's own vocabulary returned zero across book 2
   and both architecture files, which no rewrite survives. A **passage-level** check asks whether one
   passage of a chapter survived — **five were made on 08-31 and three were wrong, all in the same
   direction, all reported absent and all present.** *The Three Moves Against a Negative* is Ch 4's
   second-to-last paragraph; *Are These Realms Really Separate?* is inside Ch 3's computer paragraph;
   **the wraparound convention is Ch 8's third and fourth sentences, including the edge-crossing case
   stated outright — found only after grepping for `wrap`, which returns one hit, instead of reading
   the chapter.** **Passage-level findings from this pass are not to be trusted without re-reading.**
4. **A unit named in an architecture file is PLACED even if undrafted.** The census is about
   decisions, not drafting.
5. **Check the letter, not the position, when comparing appendix sets.** §2 is what that catches.
6. **Check the figures too.** A chapter's figures move with the material they illustrate, and a
   figure left behind when its prose relocates is invisible to any text-based check. §5.4.

---

## 5. THE FOUR DECIDED — 2026-08-31

**5.1 to 5.3 are the units §1 found unaccounted for, taken one at a time with `[A]`. 5.4 came out of
the section-level pass that followed and is a figure, not a unit.** Each is a `[C]` call with `[A]`'s
assent unless marked otherwise.

### 5.1 Book 1's Appendix F — CARRIED, at its own letter

**Book 2 carries *A Note on Designing the Tests*, and the appendix letters shift**: it takes F back,
Horney moves to G, and the rest move down one.

**Why book 2 needs it more than book 1 did.** It is the only place in either book that says what
would show the model to be false. Two questionnaires, one per realm, barred from mentioning the
Enneagram or borrowing phrasing from the type literature; the predicted partitions — `{1,3,7}` /
`{5,6,8}` / `{2,4,9}` in the physical realm, `{2,3,8}` / `{1,4,6}` / `{5,7,9}` in the psychic —
crossing so that each pairing holds exactly one type; the firewall, that classical results never
enter any calibration step; and the accounting rule that **a claim used as a calibration target is
spent and is no longer a test.**

**The strongest thing in it is the prediction of absence** — the physical-realm instrument should
genuinely fail to tell a 2 from a 4 from a 9. Almost any real signal violates that, which makes it
much harder to pass than the positive predictions, and **it exists nowhere else in either book.**
Book 1 rests its case partly on the comparison with the classical system; book 2 derives the nine
types at Ch 5, and a book that derives its types has to say what would refute the derivation.

**Dependencies survive the move**, which is why this costs nothing: the Hornevian analysis it cites
is proposed Appendix B, and the two claims it tests are Ch 10 and Ch 11, both drafted.

***`[A]` RULED 2026-08-31: leave it as provisional by intention.*** He was asked because the appendix
promises to replace itself with the protocol as executed once the tests are performed, and a book
should not make a commitment nobody intends to keep. **It goes in as written**, promise included.

**And it gains the testing order from the Conclusion — see 5.3.**

### 5.2 Additional Topics for Future Exploration — CUT, with one item lifted out

**Book 2 does not carry the section.** Most of it is a list of directions with nothing written under
them: applications to hiring and parenting, correspondences with Jungian functions, the Ayurvedic
doshas, tarot, martial arts, four or more realms. Book 1 can end on an open horizon because it
presents itself as a first statement. **Book 2 derives its claims, and a closing list of what it has
not done would weaken them** — several items read as speculative in a way nothing else in book 2 is.

**ONE ITEM IS NOT A FUTURE TOPIC AND IS LIFTED OUT: *The Two Faces of Z0*.** Book 1 records that
**realm-Z0 is deliberately two-valued** — the mirror's stance is silent about whether the glass is
polished or fogged, and the health axis alone decides — while **fixation-Z0 is taken to have one face
only**, because total blankness toward one's own fixation is fusion with it rather than a stance
toward it. It then flags the consequence: **if blank unawareness of one's own pattern does deserve
the name Z0, the top of the health axis becomes harder to place, since Level 1 is read as Z−.**

**This lands on a hazard `BOOK2-PART34-ARCHITECTURE-*` already carries at Ch 15** — that *Level 1 is
Z−* is an identity in the currency only, and that the 08-23 session found three later passages
stating the identification flat where the correspondence hedges it. **The two are the same problem
from opposite ends and neither knows about the other.** `fixation-Z0` and `realm-Z0` appear nowhere
in book 2, nowhere in either architecture file and nowhere in the rulings — only in book 1, in a
future-work list.

~~**Routed to a doctrine session as a question about the top of the health axis**, to be taken together
with the Ch 15 hazard. Not architecture's to settle.~~

**CLOSED 2026-09-01 BY `[A]`, AND BY STRIKING THE QUESTION RATHER THAN ANSWERING IT.** *there is a
continuum between z- and z+ and z0 is just a point somewhere in the middle. so z0 is an ideal that's
important only as representing total detachment which is important in spiritual traditions.* **On a
continuum, the two faces belong to the two directions of lean away from the point and not to the
point**, so *how many faces does fixation-Z0 have* is not a question with an answer. **Book 1's
one-face assumption is struck, not decided** — and it needs no mark, since it sits inside the
*Additional Topics* section this entry already cut from book 2. **The consequence it flagged does not
arise:** blank unawareness of one's own pattern is the blind extreme, not the middle, so nothing new
moves into Level 1's neighbourhood. **The full ruling and what it settles for Ch 15 are in
`BOOK2-PART34-ARCHITECTURE-20260901.md`**, including one unanswered cost recorded there.

### 5.3 The Conclusion — CUT, with one item lifted out

**Book 2 does not carry it.** A conclusion is written for the book it closes, and this one closes
book 1's argument: the classical comparison, the convergence with the traditions, the practical
applications, as a bulleted list of what the model does. **Book 2 has a different shape and writes
its own, at the end of Part 4.**

**LIFTED OUT: the testing order**, which the Conclusion states more plainly than Appendix F does.
First the predictions that involve no Enneagram at all — two questionnaires that never mention types,
each sorting people three ways and no further; then the two sortings crossing into nine cells; then
the seam around detachment; then the third scale, how a person handles their own fixation. **That
sequence is the appendix's own logic in one breath and goes into it under 5.1.**

### 5.4 `wraparound-grid.svg` — MISFILED, not dropped. Goes to Ch 8

**The one figure of book 1's eight that book 2 uses nowhere.** Book 1 draws on eight; book 2 uses
five — `two-realm-grid` at Ch 6, `hexad-cycle`, `triad-hexad-cycles` and `enneagram-hexagon` at Ch 10,
`opposite-relationship` at Ch 11. Of the three not carried, two belong to material book 2 relocated.
**This one belongs to prose that moved without it.**

It shows the 3×3 grid with one extra row and column repeating the first, so a move that falls off an
edge can be read as a single step. **In book 1 it sits in the grid chapter because that is where book
1 introduces direction. Book 2's Ch 6 deliberately withholds direction** — *a step from one cell to
its neighbor is only a step* — so the figure has nothing to illustrate there, and it was left behind.

**IT GOES TO CH 8, which currently has no figure at all.** `[A]` asked whether it should follow the
prose, and it should — but not for the single-realm closure, which needs no figure: a three-point
loop where enthusiastic follows detached is granted in the sentence that states it, and Ch 8 states
it. **What needs the figure is the aligned-types paragraph.** Ch 8 says the Three is Double Ahead of
the Nine, the Nine of the Six, the Six of the Three, each by one step in each realm — while on the
grid the reader was just shown, **the Nine is in the bottom-right corner and the Three in the
top-left, which looks like the furthest move on the board.** The extended grid resolves that exactly.
It also serves the sentence two paragraphs earlier, that two steps in one realm come out as one step
the other way.

**THE CAPTION MUST BE REWRITTEN AND THIS IS NOT OPTIONAL.** Book 1's caption works the example as
*integration* of the Nine to the Three. **Ch 8 does not have integration** — Ch 6 withheld direction
and Ch 10 supplies it. The caption has to work the same move as **Double Ahead**, in the position
vocabulary the chapter is using.

**A TEXT SESSION'S JOB**, not architecture's: it changes drafted text.

---

## 6. WHAT THIS PASS DID NOT REACH

- **Section-level census of Ch 5 through Ch 11.** §3 confirmed three sections in Ch 3 and Ch 4 only.
  The screen's remaining candidates in that range are unconfirmed, and the largest of them is book 1's
  Ch 5 §*What Makes a Step a Release*, 911 w, which is probably Part 3's rising material and needs
  reading rather than guessing.
- **The Foreword and Introduction**, compressed from 1,790 w to 651 w and not examined at all.
- **Book 1's figures.** Eight of them, and a census whose subject can live in a figure is not
  complete until the figures are in the set — the handoff's job 9 row records that as `job28`'s
  finding. **This set carries no figures.**
- **Nothing here is a recommendation to restore anything.** Each UNDECIDED item is a decision, and
  the two in §2 that commit the book to something are `[A]`'s.
