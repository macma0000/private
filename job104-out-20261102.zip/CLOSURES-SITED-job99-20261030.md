# CLOSURES — `Job99 doctrine 20261029` — sited, for drafting sessions

Cut 2026-10-30 by `Job99 doctrine 20261029` from `BOOK2-20261029b.md` (md5 `f49c8c53`, 44,666 w). **Site and claim, never
the finished sentence** (`[A]`, 08-30). Every ruling below carries the time of `[A]`'s answer; his words are verbatim in
`FINDINGS-job99-20261029.md` under *Rulings in this session*, and in the author record's hundred-and-first append. The order
of chapters and sections is in `PROPOSED-ORDER-job99-20261030.md`.

**Line numbers are this master's.** The reorder moves almost everything, so locate every site by its quoted words with `grep`,
never by line number (handoff §1.0).

**Read before writing:** `STYLE-GUIDE-20261030.md` (letter `m`), `WORD-RULINGS-book2-20261030.md` (letter `q`) and
`RULE-referring-words-20260908b.md`. Letters `m` and `q` carry this session's word rulings.

**Marks.** **RULED** — `[A]` answered yes, or ruled in his own words. **`[C]`, shown** — `[C]`'s, shown to him in full on 10-30,
not ruled one by one: show each in place, before and after, before applying it. **Ask** — put to him first.

**What this file supersedes:** `[A]`'s 09-02 placement of the four fates at the start of *The Fixations Themselves*, and his
approval during `job74-drafting-20260919` that the chapter keeps the four fates (A1); the 09-13 convention that a letter is
never used of a phase, for Part 3 (G1); `[C]`'s tree order for definitions, accepted 15:33 and replaced at 15:37 (F1).

---

## How to take the work

It is more than one session. `[C]` recommends three drafting sessions, each followed by a coherence run:

1. **Structure, words and repairs** — Parts A, B, C and D.
2. **The letters in Part 3** — Part G, the pilot first. It goes before the definitions and openings so they are written in the
   final forms.
3. **The glossary working file, the openings and the *New words in this chapter* sections** — Parts E and F. The condition in
   F1 (the chapter fixed first) is met by session 1's Part D3.

---

## Part A — The order

**A1. RULED 15:03 — the new chapter *What Becomes of a Fear*.** It goes between *Underneath the Cycle* and *The Fixations
Themselves*. Sections, in this order:

1. *Disregarding, and not seeing at all* — moved whole from *The Fixations Themselves*. It stays immediately before the full
   account, the shape `[A]` asked for on 09-02 (the miniature first, the full account immediately after).
2. *The four fates* — moved.
3. *How a fear comes to be buried* — new section, gathered: from *The range of detachment*, the job example (the five paragraphs from
   *Giving way to easy wanting sounds slack, and it is not — it holds a person in place.* through the one beginning *What varies
   from person to person is how far the turning away has developed over the person's history.*) and the paragraph beginning
   *A burial crosses the detached phase.*; and from *What previous thoughts have laid down*, its last paragraph (*A burial is not one event.*). The job
   example's first sentence leans on the paragraph before it in *The range of detachment*; restate what giving way to easy
   wanting is.
4. *Burial is not a decision* — moved.
5. *The blindness loop* — new section, gathered from *The range of detachment*: *Once a fear has been buried, the blindness does
   not fade.*, *A conversation, a place, a question somebody asks …* (the fresh anxiety) and *What happens to a fear after the
   burial does not depend on the lean.*
6. *The unease loop* — moved, less the migraine story (to *Rising*, A2). One sentence stays where the story was, saying that a
   buried fear does not fade the way an ignored one does.
7. *Lasting unease* — new section, split from *The unease loop*: from *Three things about unease are separate* to the end of
   that section.

**Left in *The range of detachment*:** the paragraphs on the lean and the caution end (*The lean has a different effect from the
blindness loop.* through *A person whose fixation is enthusiastic or cautious gives little attention to the enthusiasm end of
the detached phase.*). They repeat *Which fixation handles a fear*; say it once, with awareness of the other place (`[A]`
09-02), deciding which is the full statement.

**Joins to read before moving** (handoff §7): *Where a fixation acts* now ends the chapter before the new one, on a detached
person processing or ignoring an arriving fear; *What previous thoughts have laid down* now ends *The Fixations Themselves*;
*The range of detachment* now opens it, on *For enthusiasm and caution a lean shades the orientation without altering what it
does.*; *The unease loop*'s ending, once the migraine story leaves.

**Count:** Part 3 goes from five chapters to six. The table of contents is renumbered; Part 4's chapter numbers move up one.

**A2. `[C]`, shown — the rest of the order.** From `PROPOSED-ORDER-job99-20261030.md`, each with its reason there:

- *The Three Orientations* gets sections (*Attraction, aversion, want and fear*; *Enthusiastic, cautious and detached*; *Taking
  in and noticing*; *Intuition*; *When something goes wrong*; *Being caught, and what a person can bear*; *What a detached person
  does with a fear*). *Each competence is real* moves up into the second; the detachment paragraphs (*A detached person's own
  want is peace.* to *intuition can act on it*) move to the end. The capacity sentence stays immediately before the stress
  paragraph.
- *Relational Dynamics*: *Equal positions, and the mirror pairs* moves before *In everyday life*.
- *Leans, and the Classical Wings*: *Where the two systems disagree* moves after *Reading a person either way*. The chapter's last
  section stays last (`[A]`'s 08-15 siting).
- *Underneath the Cycle*: new section *The caution end and the enthusiasm end*, made from the chapter opening's paragraphs that
  split each phase into halves, placed after *The phases and their names*.
- *The Health Axis*: *Spoiled arrivals* moves to *Falling and Rising*, after *What falling takes from capacity*.
- *Falling and Rising*: *The second way down, which is not blindness* is retitled *Discomfort blocking and the fall*; *Two
  things that cannot happen* and *The last stretch* move up, before *Why this does not take everyone to the bottom*; *Rising*
  takes in the migraine story and splits into *Rising*, *The oldest material* and *A skill for handling fear*.

**A3. No change — *Where the Inner World Came From* stays first in Part 3.** `[C]` recommended it on 10-30; `[A]` did not answer
that question; it is no change.

---

## Part B — Word rulings (all in register letter `q`)

**B1. RULED 16:42 — *settled*.** *Settled* replaces *disposed of* (lines 387, 1271, 1319 three times, 1343 six times, 1345,
1387, 1453 twice, 1459, 1711), *processed* (1225, *An arriving fear can be processed*) and *dealt with* (1459, 1657). **Not
changed:** the Seven's *dealt with or released* (609) and *What arrives unprocessed* (1659), other senses. **Own wording:**
*a moment of clarity that gets disposed of* (1747) means one the person turns away from; reword it to say so. Check the
two-questions paragraph of *The four fates* reads correctly with *settled* in it.

**B2. RULED 16:44 — *mixed*.** *Non-aligned* goes at its three sites (the heading at 858, and 862, 864); the heading becomes
*Aligned and mixed*. Do it in the same pass as D1.

**B3. RULED 16:46 — *game*, and the self's realness said once.** Cut the last paragraph of *Where the Inner World Came From*
(*That is also why it feels as real as it does. … for most of a life the contest never stops.*). The chapter ends on *The self
is a by-product of something working exactly as it should.* `contest` leaves the book.

**B4. RULED 17:08, 17:17, 17:20 — *the pain of life not working*.** It stays at its three sites in *Rising* (1813 twice, 1815)
and is **not** a second name for *the pain of staying*. Owed, all from his words:

- **Bring it up where being less able to handle life than others are is first described** (*Blocked aversions can leave a
  person less able to handle life than others are. The person perceives being less able as a threat.*, line 1421; in the new
  order, *Lasting unease*): the pain of life not working is the suffering of being less able to handle life than others are —
  the practical details of life not working.
- **Say there how it differs from the pain of staying**: the pain of staying counts all the felt pain; the pain of life not
  working is the specific suffering of not being able to function in practical life.
- **At *Rising*'s sentence** (*What motivates a person to take up a skill for handling fear is the same comparison …*), set out
  his sequence of 17:17: blocked aversions leave a person less able to function in life than others; the person can see that
  others are able to function; the person **might** understand that something causes it and that the thing is his fears; then
  comes the comparison between the pain of life not working and the facing (worded per B5). *Might* stays: under the 10-17
  ruling all the felt pain counts whether or not the person makes the connection. Use the ruled name, *less able to handle life
  than others are*; never *unable to function* or *unable to handle life* on the page.

**B5. RULED 18:11, 18:18 — the facing side of the comparison.** What a person fears in facing buried material is pain: the pain
associated with the fear that arises when facing buried material. Reword the four paragraphs that state the facing side as a
principle so each says what is feared: line 1627 (*the person turns away as if facing it would be unbearable*), 1727 (*The
person reacts as if facing the buried fear would be unbearable* and *the pain the person might face*), 1743 (*The pain of
facing does not fall along with the pain of staying.* and *the person reacts as if facing a buried fear would be unbearable*)
and 1813 (*the fear of facing what has been buried* and *a person reacts to a buried pain as if facing it would be unbearable*).
His two candidate wordings: *the fear of pain associated with facing buried material* and *the fear of pain associated with
the fear that arises when facing buried material*. **The fear that arises when facing buried material and *the fear of looking*
are the same** (18:18): *the fear of looking* names an instance and stays at the sites about one buried fear (the blindness
loop's fresh anxiety, *The unease loop*, *Rising*, *What is actually being undone*); the principle wording goes at the four.
Keep *as if … unbearable* and *without being aware of the reaction* where they carry the 10-16 and 10-26 rulings. This
supersedes his 17:26 yes to *the pain of facing* at 1813 and `[C]`'s *the fear of facing*.

---

## Part C — Doctrine additions

**C1. RULED 18:22 — his cause-and-effect point, once.** Where the comparison is first set out (*Why this does not take everyone
to the bottom*, the paragraphs beginning *The routing is not a choice.* and *With a buried fear, the two pains a person weighs
are very different.*): the pain of life not working is what in the end forces the facing, though to the person it seems that
facing is what hurts. His words, 17:26: *failure causes the pain that eventually forces facing the fear - to the person it seems
like facing the fear is causing the pain even though the really the cause and effect are the reverse.* Read it against the
toothache example, where the pain of pulling is real.

**C2. RULED 18:18 — fear and pain.** Say once that fear is usually associated with pain: a person fears pain, and fear is painful.
No new loop and no new name: it is the fear of the fear, with pain as the link. Place it where the book first explains the fear
of the fear — the job example's *Being afraid is itself uncomfortable, so the person now fears the fear as well.* (line 1255;
in the new order, *How a fear comes to be buried*). The realms chapter's *Fear of fear produces more fear.* (343) only names it.
Training out of it is already in the book (the migraine story; *Trained abiding acts directly on the feeling of fear.*); his
18:11 words, *people can train themselves not to be afraid of pain and not to react to fear*, may tie the two together there.

**C3. RULED 08:05 — Part 3's opening names his two subjects.** His words: *it examines the relationship between the
characteristics of the fixations (and therefore the enneatypes) and the orientation phases and styles of thought* and *it
explores what is behind riso's levels of development.* Put *styles of thought* into the book's terms (*Where a fixation acts*,
*The four sketches*). Replace the opening's *What the chapters here take up is the limitation … where the habit comes from, how
deep it goes, and what holding it does to a person.*, whose three subjects do not match the chapters.

---

## Part D — Repairs under rulings already given

**D1. The aligned types — a site missed by the 09-06 ruling.** *Aligned and non-aligned* (to be *Aligned and mixed*) still gives
the reason `[A]` ruled wrong on 09-06: *Two aligned types together have unified approaches to both realms, and neither has
reason to notice that the realms are separate.* and *… but they have direct evidence that the realms are distinct, which puts
them closer to recognizing it than an aligned type comes naturally.* Rewrite on what survived, ruled that day (*i think that's
true*): a mixed type has watched themselves notice in two different ways and an aligned type never has, so an aligned type's
orientation is harder to see as an orientation. The grid chapter already says it (*A mixed type has watched themselves notice in
two different ways.*). Show him.

**D2. `[C]`, reported 10-30 — name Riso and Hudson's book.** After *Those descriptions are the substance of their work and are not
reproduced here.* in the health-axis chapter, name where the per-type descriptions are published (book 1's Appendix E names
*Personality Types: Using the Enneagram for Self-Discovery*). Show him.

**D3. The condition for the definitions order: nothing before its explanation (RULED 15:36, 15:37).** Fix each chapter where it
uses a word or idea before explaining it, before any *New words in this chapter* section is written. Known sites:

- *The smallest scale* (the cycle chapter): *A passage is the move from one phase to the next.* comes before it says what a phase
  is (*The three phases are the same three places on the cycle as the three orientations.*).
- *Where a fear meets its fate*: *how deep a person has fallen* before any fall is described.
- The One's section: *the examining is done where a person is cautious*, before the examining is introduced.
- *Disregarding* (in the new chapter, first section): *Ignoring leaves a tension in the body* comes before *The four fates*
  defines bodily tension.
- The cycle chapter's first sentence uses *integration and disintegration* before saying what they are.
- `[A]` placed *The health axis reflects how much a person notices* in the unease loop on 10-17; it stays.

The reorder already clears *unattended*, *lasting unease*, the blindness loop and the mirror pair. A full check is session 3's
glossary file (F2).

**D4. Say it once, with awareness of the other place (`[A]` 09-02).** Each is a short statement first and the full one later, or
two full statements to bring down to one:

- *The smallest scale* is to be the short version of the account of a thought (`[A]` approved this during
  `job74-drafting-20260919`); it is now nearly as full as *Underneath the Cycle*'s opening.
- *The range of detachment* repeats the types chapter's sentences on motivation crossing to a detached realm and *One thought*'s
  sentences on a pain or a pleasure starting a process.
- The leans chapter's last section repeats *Disregarding*'s first paragraph word for word. It is `[A]`'s 08-15 siting and the
  short statement left on 09-02; shorten it so it says the three and what the leans do, rather than cutting it.
- *Discomfort blocking and the fall* defines discomfort blocking again (*This is discomfort blocking.*); the definition is
  *The four fates*'s.
- *Where a level change can happen* says what a fall and a climb are; *What actually descends* says it again a chapter later.
  Make the first the short statement.
- *The Health Axis*'s opening calls the axis new (*The second is new — an axis of health …*), after the unease loop has named it.

**D5. Paragraph repairs under the style guide.**

- The Eight's section ends on a paragraph after its closing line (*The gap between impact and intent has the same source.*);
  every other type section ends on *Whatever a … condition, the pair still gives them what it gives*. Move it before that line.
- *What self-reference does* opens on a *This* that points two sections back, and its *Several things stated separately in
  earlier chapters follow from this one property.* names none of them.
- In the Part 3 opening, the arhat paragraph joins neither neighbor.
- The later style job's three items in handoff §4.
- Paragraphs that open by pointing back (*That*, *This*, *It*, *Which*): ten of the inner-world chapter's 27, fourteen of
  *Falling and Rising*'s 98. The referring-word count governs.

**D6. Ask — *This describes a small number of people*.** *Relational Dynamics*, second paragraph (*This describes a small number
of people, and in any real relationship it is one factor among many.*). A reader cannot tell what *This* is, or whether the
observation is rare or was seen in few people. Ask `[A]` what is meant before rewording.

---

## Part E — Openings

**E1. RULED 15:04, 18:22, 18:27 — the form.**

- Every chapter and section opening names what is coming as things about people, in the order the chapter takes them, and never
  refers to the book or its arrangement (*this chapter …*). The model is *Relational Dynamics*' opening. The Introduction is the
  one place a sentence about the book is allowed (`NOTE-introduction-recognition-20261007.md`, still waiting for `[A]`).
- It says what is covered and, when possible, why it matters — said about people (the example given: the detached phase is the
  only place a person's depth can change).
- The chapter's opening comes **before** *New words in this chapter*, and so names its subjects in plain words and words from
  earlier chapters only.
- A section of one or two paragraphs gets no opening; its first sentence says what it covers.
- **`[A]` may write the section summaries himself** (18:27: *i might attempt section summaries later*). Ask him before drafting any.

**E2. Part openings.** Parts 1 and 2 have none; each gets one, in the E1 form. Part 3's is rewritten per C3. The arhat paragraph
(D5) is decided in the same pass.

---

## Part F — The glossaries

**F1. RULED 15:09 to 15:37 — *New words in this chapter*.**

- **Title:** *New words in this chapter* (15:28).
- **Place:** after the chapter's opening (15:09, 18:22).
- **What it holds:** the words the chapter introduces and goes on to use in the rest of the chapter (15:18), in complete sentences
  that connect into readable prose (15:14), in short paragraphs by subject.
- **Each sentence** is the chapter's own defining sentence or shortened from it, so the two never disagree; each word is then
  defined twice, briefly here and in full where the chapter explains it, which `[A]`'s 09-02 rule allows.
- **Order:** the order in which the chapter explains the words (15:37), on the condition that the chapter first obeys *nothing
  before its explanation* (D3). *Most-used first* only settles ties.
- **Dependency:** a sentence uses only words from earlier chapters or defined earlier in the same section.
- A chapter that introduces no words gets no section.

**F2. Build the glossary working file first.** One entry per word: the word; its defining sentence copied exactly from the master;
the section and chapter it stands in, in the new order. Copied sentences are checked with `quotecheck.py` against each new
master, so the file cannot drift. Building it finds the remaining words used before their explanation and any further second
names; bring the second names to `[A]` one at a time.

**F3. RULED 15:09 — the glossary at the back.** The whole glossary, as a list, alphabetical, for looking a word up: each word with
its defining sentence and its chapter. It is where a reader finds a word from an earlier chapter. Book 1's Appendix E (*What
This Book Borrows*) is a different thing, a ledger of borrowings, and stays separate.

---

## Part G — Letters in Part 3

**G1. RULED 19:05 — every letter in Part 3 carries its word.** Each time a phase or a fixation is named in Part 3, the words come
first and the letter follows in brackets, with its word: *the enthusiastic phase (phase A)*, *the cautious phase (phase B)*,
*the detached phase (phase Z)*, *the caution end (phase Z−)*, *the enthusiasm end (phase Z+)*; *an enthusiastic person (fixation
A)*, *a cautious person (fixation B)*, *a detached person (fixation Z)*, *a person leaning toward caution (fixation Z−)*, *a person
leaning toward enthusiasm (fixation Z+)*. Where the letter names the phase, *of the detached phase* is not needed. Parts 1 and 2
keep bare letters. About 220 sites in Part 3.

- **Pilot first:** apply it to one section, show `[A]` in place, and do the rest only after he has seen how it reads.
- **Rewrite** *Underneath the Cycle*'s *The letters A, B and Z name only where a person stands … The letters are never used for a
  phase. So a letter always means a person.* to the new rule.
- **Also reached:** the sketches' *(A)*, *(B)*, *(Z−)*, *(Z+)*; *written Z−* and *written Z+* in *Underneath the Cycle*. The
  example `[A]` saw: *A detached person leaning toward caution (fixation Z−) is at home in the caution end (phase Z−).*
- The style guide's section 8 bullet and the register's §2 entry are amended in letters `m` and `q`.

---

## What this session did not do

- **The record's index of subjects** is still owed (handoff §9). `[A]` set this session a different job.
- **The record was searched, not read through.** A doctrine session reads it in full (handoff §1.1, `[A]` 08-20); this one
  searched it for what bore on the job: repetition, introductions, glossaries, Riso's table, the letter rulings, the aligned
  types, the game and contest passages, *disposed of*, *the pain of life not working*.
- **The doctrine backlog** at handoff §6.1 was not touched.
- No book text was written, and the claim inventory was not changed.
