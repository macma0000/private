# DEFECTS CARRIED FORWARD — revised 2026-08-25 by `Job18 doctrine 8-25`

**Supersedes `DEFECTS-carried-forward-20260825.md`.** That file listed five items. **Three are now
closed by `[A]`'s rulings** and the closures are in `RULINGS-job18-20260825.md`, which carries the
exact strings. **Two remain open**, unchanged and not started. Job 17's deviations and the
housekeeping are carried forward below because they are still live.

---

## CLOSED 2026-08-25

### Closed — bk2 Ch 7, `[A]` said DELETE and job 16 substituted

**Was §2.** Ruled: *get rid of it* stands as **deletion**. See `RULINGS-job18-20260825.md` §1.1.

**The wrinkle that made it non-trivial was void.** The worry was that plain deletion would leave
book 2 naming `fixation` without accounting for it, since the rule that made it the book's only
account is real. **But book 2 defines the term twice before Ch 7** — Ch 1's *a hardened orientation
is what this book calls a **fixation***, and the loop section's *a habit set down early and held so
long that it is simply where they live*. The rule is satisfied upstream. **It was true when the rule
was made and stopped being true since, and nobody rechecked it against the manuscript.**

### Closed — bk2 Ch 7, the dead claim in the LEAD-IN

**Was §4**, found by job 17. **It was never a separate defect.** The lead-in and the sentence after
it were one defect with the repair applied to the wrong half — job 16 repaired the sentence its row
named and did not look at its neighbour, which is the sixth instance of the pattern job 16 itself
wrote up. The single ruled replacement closes both, and closes a third site in book 1 with it.

### Closed — bk1 Ch 5, the sixty-second claim's scope

**Was §1.** The two competing scopes were not alternatives, and **neither was the one that mattered**.
Reading the 08-21 record around the ruling shows the discomfort came from `[A]`'s own line two
exchanges earlier — *beginning middle an end have no relationship to emotions which the orientations
do have*. **The difference to point out is that the bare three-part shape is not the cycle**; a
candle has the shape. Ruled, with its position ruled too: it goes **at the candle, before the
fact-claim**, and book 2 takes no difference at all. See `RULINGS-job18-20260825.md` §1.3 and §1.4.

Job 16's shape-scope was correct and is applied; it answers *checkable about what*, and the 08-21
ruling asked *how far the identity goes*. Both now stand.

---

## STILL OPEN

### 1. bk1 App G — Riso's chain has two intermediate terms the appendix omits

**Not started.** Carried unchanged from the superseded file, whose §3 holds the full statement.

In one line: App G's chain rules state *Desire to its own fear (within the level)*, while `[A]`'s
08-21 correction has *desire->attitude->behavior->fear*. **Whether that changes the chain's claim or
only its exposition is the question, and it has never been put to him.** Related and also unexamined,
from the same 08-21 passage: whether App G's *The top, and the exit* rule matches his corrected
description of Riso's figure, after he said *i was careless. riso's chart confused me.*

### 2. `[A]`'s own unanswered question — *do we need thought arcs anywhere else?*

**Still not put back to him.** Asked by `[A]` on 08-21 in the same breath as the sixty-second ruling.
Job 16's `arc` census answers it incidentally (repairs file, Part 2, census sites). **The question was
his and deserves a direct answer, not an incidental one.**

---

## PROCEDURAL DEFECT found by this session's §1.0 screen

**`RECOVERY-NOTE-20260825-procedural-changes.md` fires *drop*.** It quotes the OLD restriction
sentence verbatim in its "before" block at line 52. **This is the exact trap the note itself warns
about** — it says anything discussing the screen must break the string or be mistaken for a
restricted file, and it broke the NEW string carefully while leaving the OLD one intact three
sections earlier.

**Why it matters rather than being a curiosity:** the note will fire in every set that carries it, and
an assembler obeying the screen would drop **the one file that explains how to undo the 08-25
changes**.

**Fix:** one line break inside the quoted sentence at line 52, as the note already does for the new
string. **Not applied here** — it is job 17's undo document and a doctrine session should not edit
another session's procedural record silently.

**Also:** the screen now fires **four**, all benign — two *carry, do not read* (the record,
`setcheck.py` on its own reflection) and two *drop* (the handoff, the recovery note). The handoff's
line saying it fires three and that *a fourth hit is a real one* is now stale for the second time.
**That line should stop naming a number**; the shape of the hit list is set-dependent and will keep
changing.

---

## JOB 17'S DEVIATIONS — carried forward unchanged, still unruled

Reported by job 17 unprompted. Recorded so they are not rediscovered.

- **One authored sentence**, bk2 Ch 7's opening, where the repairs file supplied no words: *Two of
  these matter most in what follows and are named throughout: the thought arc, and the endeavor arc
  of a bounded undertaking.* Two authored choices — **`bounded undertaking`** rather than book 1's
  *bounded pursuit*, and **placement** at the end of the paragraph. **Neither is ruled.** `[C]`'s
  view stands: the vocabulary choice is right, and job 16's spec should have said which book's
  vocabulary governs where the two differ.
- **`smaller`** — job 16's `CURRENT` quote for §2.14 dropped a word the manuscript has; job 17 kept
  the manuscript's. **Job 16's transcription error, correctly handled.** General caution: job 16's
  `CURRENT` strings were transcribed by eye in places. **This session matched every string by exact
  count instead**, and states the counts in the rulings file.
- **Site 2's applied sentence** kept book 2's lead-in and comma. **This is now moot** — that whole
  sentence is deleted by the ruling above.

---

## HOUSEKEEPING

- **`AUTHOR-RECORD.md` holds two personal passages** — one on how the alternate route was found, one
  concerning a family member — each marked *`[A]` to say if any of it should be marked or kept out*.
  **Still unanswered, and not raised this session.** The file now travels in every set, which raises
  the stakes on the question rather than lowering them.
- **The record's 08-25 entry by job 16** was written without the record in view for the material it
  records, and says so on its face. Unchanged.
- **Job 18 read the record** — correctly, being a doctrine session — and **is disqualified from
  drafting**. It drafted nothing and applied nothing. **No wording for either manuscript was written
  by this session**; §1.3 of the rulings file deliberately supplies no draft sentence.
- **A new handoff has still not been cut**, two sessions running. `HANDOFF-20260824f.md` is now stale
  in more places than job 17's list: the record's count and date, `rev2-0814b.md` in four rows, the
  three-hit screen line, and its §1.1 doctrine row, which does not name the five 08-25 files that a
  doctrine set now needs. **The next session with room should cut one.**
