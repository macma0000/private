import re, sys, json

SINGLE = ["it","its","that","this","those","these","them","they","there","such"]
PHRASE = ["the other","the same","the former","the latter","in those respects","the first","the second"]

def sentences(text):
    # split on sentence enders followed by space + capital/quote
    parts = re.split(r'(?<=[.!?])\s+(?=[A-Z"*_])', text)
    return [p.strip() for p in parts if p.strip()]

def count(s):
    low = s.lower()
    hits = []
    for p in PHRASE:
        for m in re.finditer(r'\b'+re.escape(p)+r'\b', low):
            hits.append((m.start(), p))
    for w in SINGLE:
        for m in re.finditer(r'\b'+w+r'\b', low):
            # skip if inside an already-matched phrase
            if any(st <= m.start() < st+len(p) for st,p in hits):
                continue
            hits.append((m.start(), w))
    return sorted(hits)

def main(path):
    lines = open(path).read().split("\n")
    chap = "front matter"
    rows = []
    inchap = False
    for i, ln in enumerate(lines, 1):
        m = re.match(r'^## (Chapter \d+|Appendix [A-Z])', ln)
        if m:
            chap = m.group(1); inchap = True; continue
        if ln.startswith("#"): continue
        if not ln.strip(): continue
        if ln.strip().startswith(("|","-","*","1.","2.","3.",">")) and not ln.strip().startswith("**"):
            continue
        body = re.sub(r'\[\[.*?\]\]','',ln)
        for s in sentences(body):
            h = count(s)
            strict = [x for x in h if x[1] not in ("that","there")]
            rows.append({"line":i,"chap":chap,"n":len(h),"strict":len(strict),
                         "words":[x[1] for x in h],"sent":s})
    return rows

rows = main(sys.argv[1])
json.dump(rows, open("/home/claude/job59/refrows.json","w"))
tot = len(rows)
f_all = [r for r in rows if r["n"]>=2]
f_str = [r for r in rows if r["strict"]>=2]
print(f"sentences scanned: {tot}")
print(f"two or more referring words, full list: {len(f_all)}  ({100*len(f_all)/tot:.0f}%)")
print(f"two or more, excluding 'that' and 'there': {len(f_str)}  ({100*len(f_str)/tot:.0f}%)")
from collections import Counter
c = Counter(r["chap"] for r in f_str)
for k,v in sorted(c.items(), key=lambda x:-x[1])[:25]:
    print(f"  {k:16s} {v}")
