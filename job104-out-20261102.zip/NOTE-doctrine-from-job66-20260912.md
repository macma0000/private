# DOCTRINE NOTE — from `Job66 coherence 09122026`, 2026-09-12

Four things for a doctrine session, and four things `[A]` settled in this session that are not
here because they went to `REPAIRS-job66-20260912.md` instead.

A coherence session rules nothing. Everything below is either `[A]`'s own words or `[C]`'s report
of what the manuscript says, marked as such.

---

## 1. Does a process arc have a realm at all?

**`[A]` 2026-09-12, verbatim, opening the subject himself:**

> it seems to me that the process arc does not run in a particular realm. only the fixations
> depend of realms. a process arc can be about something in one realm or the other but also both.
> and the fixations certainly influence process arcs and bring realm dependencies. the fears are
> of the process arcs.

**What it collides with.** `[A]` closed this on 2026-08-19 and `HANDOFF-20260906.md` carries the
closure as load-bearing: an arc's realm is set by which realm's rules its concern answers to, with
motivation as the way to identify the concern, and motivation and realm always match. His own two
worked examples were the fence post checked because the neighbour might think you careless, which
he typed psychic, and the cows getting loose costing a livelihood, which he typed physical. The
ruling bought, among other things, that an arc cannot be mixed, because a motivation is one thing.
An arc that is about both realms is the mixed arc that ruling excluded.

**The two sentences in `BOOK2-20260912.md` that the new statement falsifies.** Ch 15 *Where a fear
comes from*: *The fear arrives where the process ends, in the realm the process ran in.* Ch 15
*Which fixation handles a fear*: *A fear lives in one realm or the other, so the fixation that
handles it is the one held in that realm and not the person's type.*

**Why the second one costs something.** The section it opens exists to answer a question the book
raises much earlier — a person has two fixations, so which one deals with a given fear. The answer
on the page is that the fear's realm picks the fixation. Take the realm off the fear and the
question is open again.

**A reading `[C]` offered and `[A]` did not rule.** What carries a realm may be the fear rather
than the arc. An endeavor can be about both realms, both fixations can be at work in it, and each
fear still goes to the fixation of the realm that raised it. On that reading the routing sentence
survives, the *realm the process ran in* sentence does not, and the alternation `[A]` describes in
item 3 below is the two fixations' fears taking turns. **This is `[C]`'s reading of `[A]`'s case,
not a ruling and not his words.**

---

## 2. Which fixation handles a fear that one realm lends to the other?

The book has one realm lending to the other already. Ch 15: *An enthusiastic or cautious realm can
also lend wanting and fearing to the person's other realm, when the other realm is detached.* The
lending was ruled 2026-09-07 and is set out in `NOTE-two-sources-of-motivation-20260908.md`.

**The gap.** The lending sentence says a fear raised in one realm can move a person in the other.
It does not say which fixation deals with the fear once it has arrived — the one that raised it,
or the one held in the realm it arrived in.

**`[A]`'s own case makes the question live, 2026-09-12, verbatim:**

> the pressure to defer seems physical to me - maybe because my fears are almost always associated
> with the physical. with psychic matters i almost always think things will work out - even when i
> make mistakes in the psychic, my concers is with the physical consequenes.

His pair is cautious in the physical realm and detached in the psychic one, which is exactly the
shape the lending sentence describes, and he reports the lending running constantly rather than
occasionally.

---

## 3. Do both fixations contribute at every position of an arc?

**`[A]` 2026-09-12, verbatim, from the case he worked through — his own difficulty answering the
question in item 1:**

> my guess is that at any position in the process arc, both fixations contribute in their
> particular ways: at b position, the SZ- psychic fixation is just waiting and the HB fixation is
> generating effort and stress. at Z position, the SZ- psychic fixation is generating resolve and
> the HB fixation is generating the desire to escape.

He described the working of it as an alternation over repeated cycles: one side retiring the fear
with *keep trying*, the other deferring it as too difficult, with the sense that the writing
matters surviving both.

**What the book cannot currently do.** As it stands each fear is routed to one fixation, so a
person's two fixations never meet inside a single endeavor. Their work sorts into two piles that
never touch, and there is no machinery for the alternation at all.

**One thing in the case is unsettled and it decides how much breaks.** In the first telling the
deferring is done by the enthusiasm end of his psychic fixation — SZ− with significant overlap
toward Z+. That leaves the routing intact, the alternation happening between the two ends of one
detached fixation. In the generalization the deferring is done by HB, a cautious physical
fixation acting at the crossing of an arc whose fear is psychic. Asked which, he answered that the
pressure to defer seems physical, quoted in item 2. **`[C]` reads that as one physical fear rather
than one fear handled twice, which is the reading in item 1 above, but `[A]` did not say so.**

---

## 4. Does an enthusiastic realm send more to the crossing than a cautious one?

**`[A]` 2026-09-12, verbatim:** *"seems wrong. defer it to the doctrine session."*

**What he was answering.** `[C]` put it to him as the book's own claim, in the course of arguing
that a Type One's physical side is the noisy one at the crossing rather than the quiet one.

**The book asserts it in two places, so overturning one overturns both.** Ch 17 *What actually
descends*, as the second of the three rate-setters: *How much the earlier part of the process left
standing is another. Enthusiasm cuts the examination short…* Ch 15 *Which fixation handles a fear*,
earlier and in the same terms: an enthusiastic person cuts the examination short so contingencies
arrive at the ending unprocessed, while a cautious person settles most of them before the ending
and fails by overload instead.

**Two things go with it.** The three rate-setters are stated as independent, so if this one falls
the falling chapter is left with two. And `[C]`'s reasoning about a Type One at the crossing rests
entirely on this claim, so that reasoning is suspended rather than standing.

**The Type One material `[A]` raised, 2026-09-12, verbatim, which is where this came from:**

> i would bring up the types with no Z fixation, say type one. that type would have desires that
> are physical and fears that are psychic. what happens when a process arc arrives at detachment?
> the desire is then dormant, if there is no fear there is nothing to do and the next cycle
> begins, if there is fear, it's probably psychic and since there is no Z fixation it is either
> resolved, passed on or discarded. - i'm not sure those are the possible fates.

`[C]` report, measured against `BOOK2-20260912.md`: the three he named are worked through, ignored
and given up on; the missing fourth is blocking, and blocking is the only fate that costs sight.
Blocking has to stay available to a type with no detached realm or four of the nine types could
never descend. `[A]` did not dispute this and did not rule it.

---

## Carried from Job65, still unruled

`[A]` 2026-09-12, offered as a guess and marked as one: the habit of ignoring may itself arise from
blindness already laid down, and it may also arise independently. Nothing in the book turns on it
today. If ignoring arises only from blindness, the four fates stop being four independent things.
