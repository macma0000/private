# FOR A DOCTRINE SESSION — cut by `Job61 coherence 09092026`, 2026-09-09

Nothing in this file is ruled and **nothing in it is owed prose**. A drafting session must not
write from it. What is settled and owed is in `REPAIRS-job61-20260909.md`.

`[A]`'s own words are quoted throughout. Everything unquoted is `[C]`'s report and carries no
authority.

---

## 1. THE THREE WANTS BEHIND THE BASIC FEARS — `[A]`, 2026-09-09, verbatim

Given in answer to whether the basic fear has a want behind it. He said it does, and then:

> A fixation people want to limit endeavors to enthusiasm. that means they need help. they want to
> trade their competence for the care and knowledge cautious people can provide. B fixation people
> want to limit endeavors to caution. they have trouble relinquishing control. that means they need
> help. they want to trade their competence for the wisdom of the big picture detached people can
> provide. Z fixation want to eliminate disturbances but their lives fail without motivation. that
> means they need help. connection with engaged people is how they get it.

He added: *"that's new and it probably needs to go somewhere else as well as characterizing the
different desires that precede the basic fears."*

### `[C]` findings on it

**All three trades are one step forward, and that is the integration direction.** Ch 10 fixes
forward as detachment giving way to enthusiasm, enthusiasm to caution, caution to detachment. An A
fixation wants what caution provides; a B fixation what detachment provides; a Z fixation what
engaged people provide. Each is exactly one step ahead. Nothing in his passage appeals to the
figure, **so the figure's forward direction has been derived a second time, from what each
fixation wants.**

**The three converge on needing another person.** Each passes through *that means they need help*.
The book has three places where a person is reached from outside — the installed care, the
intervener, and Ch 17's skill learned from other people — and none says why outside help is the
form the answer takes. This says why: what each fixation lacks is the competence it traded away,
and a competence a person does not have has to come from someone who does.

**HAZARD, and it is a ruling.** Integration names what is observed and is not a process a person
runs (R12, and the 08-19 ruling). The three wants read as a motive to move. They stay clear of the
ruling only if written as **wanting the other person's competence** — a trade between two people,
not a journey round the figure. Written the other way this reopens R12.

**Placement, `[C]` recommendation, NOT ruled.** State the three wants once, in Ch 16's core
dynamics, since the basic fear is what raised them. Two uses after that: Ch 17's **Rising**, for
why the help has to come from a person; and Ch 9's ahead-and-behind, which already describes the
trade in relational terms (*the one behind looks up to the one ahead and values the guidance*) and
could say what is exchanged and why each side needs it.

---

## 2. THE NINE BASIC FEARS DECODED — `[A]`, 2026-09-09

He proposed extrapolating the three wants to Riso and Hudson's nine basic fears, then quoted each
fear and gave his reading. **The fear wordings are his transcription of Riso; the readings are
his.** Both are reproduced as given.

He corrected `[C]`'s first objection — that three psychic fixations cannot yield nine fears —
with the rule the whole decoding runs on:

> the process is psychic - the objects of concern are in one or the other realm.

**Type 1** — *"of being corrupt, defective, evil (imbalanced)"* — *it's the mirror of eight - SB
unable to come to a conclusion and aware that the HA part incautiously participates in the physical
world which, even at best, violates the ideals of the psychic.*

**Type 2** — *"of being unwanted, unworthy of being loved"* — *just as i said - A craves the help of
B competence - that's what being wanted and loved would assure when viewed from the psychic. HZ
offers no help.*

**Type 3** — *"of being worthless"* — *same as two except the need for help appears transactional,
as merit and value - worth in both realms.*

**Type 4** — *"that they have no identity or personal significance"* — *the insecure SB's looping
examination of the psychic, and as centered on the self motivated by fear. HZ tempers worry but
provides no other motivation.*

**Type 5** — *"of being helpless useless incapable"* — *HB fails by failing to move on to resolution
and knows it which just intensifies the fear. SZ tempers worry but provides no other motivation.
helpless is recognition they are failing, useless is worry they will get on help.*

**Type 6** — *"of being unable to survive on their own, having no support"* — *basic B fear for
survival. recognition that they are failing but less understanding that what is lacking is
resolution than four and five.*

**Type 7** — *"pain and depravation"* — *HA's fear of having to face fear - of engaging in caution
where pleasure is absent. SZ provides no help.*

**Type 8** — *"of being harmed or controlled by others"* — *harmed is HB, controlled is SA wanting
not to be forced toward B.*

**Type 9** — *"loss and separation (impermanence)"* — *all about being helpless without contact with
others.*

### The Eight's first attempt, and why it does not transfer

He first wrote, against a fear he had mis-copied:

> the fear is "of pain and deprivation" that's HB - they are unable to drop worry about the
> physical, so they crave reassurance. their SA only makes it worse by getting them into trouble
> which burdens the HB.

That reading was built on HB. The fear turned out to belong to the **Seven**, which is HA;SZ and
has no HB in it, so the reading could not move with the fear. His Seven line above replaces it and
reads the fear from HA. Recorded because it is his reasoning and because a later session may want
the discarded HB reading for the Eight, where HB does apply.

### `[C]` findings on the nine

**One rule covers all nine: the objects of a type's basic fear come only from realms that are not
detached.** Four types have no detached realm — the One, Three, Six, Eight — and every reading
gives the fear an object in each realm. Four types have one detached realm, and each reading says
that realm supplies nothing (*HZ offers no help*; *tempers worry but provides no other motivation*,
twice). The Nine has two detached realms, so no realm supplies an object, and the reading points
outside the person entirely. **This is the two-sources ruling turning up in Riso and Hudson's list,
and it is the thing to test first.**

**The SA trio comes out ordered by the physical fixation.** Two (HZ) — the physical supplies
nothing and the fear stays wholly psychic. Three (HA) — an object in each realm. Eight (HB) — the
physical object is harm. Same process three times, three physical fixations, three fears.

**Six of the nine are driven by the psychic fixation with the physical supplying the object; the
Five and the Seven run the other way**, with the psychic fixation only tempering. **Those two are
exactly the types detached in the psychic realm**, and a detached realm originates no motivation,
so the drive must reach it from the other realm. The inversion is required in those two cases and
nowhere else.

**The Eight's tension is worth keeping.** An A fixation wants what caution provides, and the
Eight's basic fear is of being controlled. Wanting the competence and refusing the authority are
the same trade seen from two sides, so the Eight's basic fear names the exact way the trade fails.

**Register.** This is correspondence, not derivation — register 3. It must not become a reason to
move or change anything in the model, and the temptation will be strong if the nine come out well.

**`[C]` error corrected in session, recorded so it is not repeated:** *does the fear name a want*
was used as a test for a detached realm and does not discriminate — the One, Three and Eight name
no want either and have no detached realm. The test that works is the object rule above.

---

## 3. THE BASIC DESIRE — what it is, and the one falsifier

**`[A]`'s question, and it settled the matter:** *"is it a desire for help or a fear of not getting
helped?"*

`[C]` had said Riso's basic desire is the basic fear read forward. **That is wrong**, on the book's
own test: *given up on* works because the want behind a fear can be dropped and the fear goes with
it. A description of the fear with the sign flipped cannot be dropped. So the basic desire is the
**want itself**, and the basic fear is that want in doubt.

**Shape of the whole structure, then:** three wants, one per orientation. Each takes its objects
from whichever of the person's realms is not detached, and becomes that type's basic desire. The
basic fear is that desire in doubt.

**Ch 16's table already agrees.** Level 1: *The basic fear has been seen through. What desire
remains is the desire to be free of beliefs already recognized as illusory.* At the top the fear
goes and the basic desire goes with it — which is what happens if the fear was the want in doubt.

**What would falsify it:** a type whose basic desire cannot be read as its orientation's want for
what the next orientation provides. **Test the Five first** — *to be capable and competent* has to
come out as a want for what detachment supplies, and does not read that way on its face.

**The wordings are missing from the set.** Riso and Hudson's nine basic desires are in no file
here. `[A]` supplied the fears verbatim; the desires must be supplied the same way before anything
rests on them.

---

## 4. THE INVERSION — `[A]`'s mechanism for a detached realm meeting a want

**His account:** *"it's a desire not to want help. that sounds like SZ acting on the HB want."* And,
extending it to the Four: *"maybe the four actively wants not to think about physical consequences.
they are famously unworldly."*

**It is derivable rather than fitted.** Detachment wants to be free of the pull of wanting (Ch 4).
So a detached realm acting on a want arriving from the other realm neither pursues it nor drops
it — it turns *want help* into *want not to need help*.

**Where the detached realm sits decides whether the inversion shows in the basic fear.** The chain
runs in the psychic realm. A detached **psychic** realm sits inside the chain, so the inversion
shows in the fear itself — the Five, HB;SZ, whose fear names incapacity with the wanting suppressed.
A detached **physical** realm sits outside the chain, so the inversion never reaches the fear and
shows in how the person lives — the Four, HZ;SB, and unworldliness.

**The discriminating pair is the Five against the Six**, and it is the strongest evidence for the
mechanism. Both are cautious-driven fears about failing. The Six (cautious in both realms, nothing
to suppress the wanting) names the help — *having no support*. The Five (SZ) names only the
incapacity. Same fear, one naming the help and one not, and the difference is the detached realm.

**`[C]` over-reach, corrected by `[A]` and recorded:** `[C]` predicted the same unworldliness for
all three physically detached types — Two, Four, Nine. `[A]`: *"but only four and five have a source
of fear to threaten detachment."* An enthusiastic realm lends wanting with force; the pairing that
presses a **fear** on detachment is caution with detachment, which is the Four and the Five alone.
The Two's HZ is lent wanting by SA, and Ch 15 already says detachment gives way to easy wanting
rather than inverting it.

---

## 5. THE THIRD ROUTE, AND WHY IT IS NOT A THIRD SOURCE

`[A]`: a fear *"can come from A in a less forceful way or can traverse Z without being
eliminated."*

The second half is the piece the book lacks. Both stated sources describe a fear arriving fresh.
Two of the four fates leave a fear in existence — an ignored fear keeps fear and want intact, a
blocked fear survives hidden — and Ch 16 says later fears are drawn from what has collected.

**`[C]` recommendation, and `[A]` did not object: keep the count at two.** A fear not disposed of
shapes what the realm's own next arc raises, so it enters through the first source rather than
beside it. What is wrong is the description of the first source, not the count. **The repair is in
`REPAIRS` number 8.** A third source would also need its own account of where it comes from, and
the deposits already have one.

**Three things depended on getting this right, recorded for whoever tests it.** The Nine is not
short of motivation, only short of lent motivation — which changes what the Nine's negligence is.
The descent's self-feeding needs a term for accumulation and the two-source account has none. And a
returning fear has an object, so it narrows what is open to noticing, which is a mechanism for a
person growing narrower as they fall.

---

## 6. THE CONTENTLESS FEELING — `[A]`, 2026-09-09, and it is his newest idea

> i also think that a feeling can be carried across without content - so a feeling of fear without
> the specific object it was formerly associated with.

And on where it sits: *"i think it isn't exactly the mental deposits, it sits in something more
short term, maybe bodily tension."*

### What the outside literature says, searched at his request 2026-09-09

**The phenomenon has a name and a clinical literature.** Free-floating anxiety is described as a
diffuse unease directed at no specific object, where the emotion is felt without apparent reason
and the source lies in unconscious fears or unresolved conflicts. Freud's Angst against Furcht is
the same split; psychiatry separates generalised states, where free-floating anxiety is present
most of the time, from intermittent episodes of acute anxiety — which is `[A]`'s panic sitting
alongside it.

**The suppression route is stated much as he has it:** feelings that go unprocessed do not
disappear but become background noise, so vague unease may be carrying something more specific
underneath it.

**The bodily holding is the older half.** Reich's character armouring — chronic muscular
contraction developed as a block against emotions breaking through, anxiety among them, with
unresolved emotional stress physically embedded as chronic muscular tension. Gendlin's felt sense
comes out of that lineage, and its handle is the felt quality rather than any content, which is
what Ch 17 already says about the oldest material.

**Evidence status, stated so nothing rests on more than it should.** The phenomenon is well
described; the mechanism is contested. Reich's orgone framework has no scientific support and is a
fair target, while body-oriented therapies do show measurable effects in trials, particularly for
people who do not respond to talk alone. **So *the body holds it* is safe as a description of what
people report and unsafe as a mechanism the model rests on.**

### What the idea buys the model — `[C]`

**It answers `[A]`'s own 09-08 observation**, which was filed for doctrine as a question nobody
could answer: a fear going round his cautious realm, coming back with the focus lost, leaving him
still wanting to think about things. A feeling carried across without its content is that.

**An objectless fear moves a person without narrowing what is open to noticing**, since nothing in
the realm is pulled toward. That is the only kind of motivation a detached realm can take without
losing its competence — the same shape the bodhicitta correspondence turns on (section 8).

**It cannot be *given up on*.** That fate needs a want to drop, and a feeling with no content offers
nothing to find. So the model predicts what the clinical writing reports: this kind persists in a
way the ordinary kind does not.

### THE QUESTION THIS SESSION REFUSED TO SETTLE

**Is the short-term holder a separate thing from what previous thoughts have laid down?** The
deposits are long-term and lie beneath understanding; `[A]` is describing something that fades.
**Adding a second store is a doctrine-sized change** and was handed over rather than taken.

---

## 7. CONTAGION — is another person's feeling a source of motivation?

Raised by the pattern in `[A]`'s three comfort examples (see `REPAIRS` number 12), which differ in
whose trouble is in question — the trouble in front of them, other people's, their own. `[A]`:
*"i noticed that but didn't intend it."*

**`[C]` reading, offered and not ruled.** The enthusiasm end's case is forced: burial answers what
a person cannot bear, and that is their own suffering (Ch 4's aversion to *suffering with nothing
softening it*). The caution end's is not forced — a fear arriving in a person's realm can be about
anyone. **The middle is where something may be hiding:** a person with no lean has no want of their
own to pull them anywhere, and Ch 15's channels section already says a signal works by producing
its copy in whoever is near. For someone with no pull of their own, that is the pull most likely to
reach them.

**THE QUESTION: is another person's feeling, arriving by copying, a source of motivation in the
model?** The ruled account has two sources and contagion is neither. The mechanism is in the book
and is not connected to the motivation account.

**Recommendation given to `[A]` and accepted: leave the three examples as illustration and state no
pattern**, until this is ruled.

---

## 8. THE CAUTION LEAN AND THE LARGER PEACE — `[A]`, verbatim, asked to be noted

> the cautious lean has the deepest understanding of reality and the reality is that personal peace
> results from larger peace.

**`[C]` flag for the doctrine session.** Caution's own competence is understanding (Ch 4). This
gives the deepest understanding to Z−, which is detachment leaning toward caution rather than
caution itself. Either Z− understands more deeply than the orientation whose competence
understanding is, or **the two understandings are of different things** — B works out how a
situation will go, and Z− grasps what peace rests on. The second reading is available and is
written nowhere.

**What the claim buys.** Book 1's remedy for detachment is that what moves it must come from
outside, and the traditions install care for others early. This supplies the reason the remedy
works: caring about the larger peace is not something added to a detached person from outside their
interests — it is what their own peace requires. **That makes a growth claim rest on a fact rather
than on a prescription.**

**Consequence, stated and not settled:** if caring for others is true rather than expedient, a
person at the caution end of detachment could reach it by understanding, with nobody installing
anything. That would give detachment a route to motivation that does not come from outside, which
is what book 1's remedy says detachment lacks.

### Installed care — the word `artificial`

`[A]`: *"as book 1 says, artificially caring for others is an important technique to provide
motivation to detachment."*

**Book 1's wording is *care that has become habitual***, installed early and deliberately as a
practice, before it is needed (rev2 L654). It never says *artificial*, and its argument is that the
technique works **because a habit runs without anything having to be believed**, so the care still
works when a person's own stake has quieted. What is artificial is the installing, not the care
once running.

**But see the next section — the tradition's own account uses `[A]`'s word.**

---

## 9. BODHICITTA — the strongest correspondence in the material so far

Raised by `[A]`: *"look at the buddhist concept of bodhicitta."*

**It settles the `artificial` question in `[A]`'s favour.** The traditions distinguish *contrived*
bodhicitta — deliberately manufactured, generated by formula whether or not it is felt — from
*uncontrived*, the same wish once it arises by itself, and the practice exists to turn the first
into the second. So artificial at installation and genuine once settled is the tradition's own
account. `[C]`'s objection to the word was too strong.

**The placement matches book 1 exactly.** Bodhicitta is taught before emptiness, the stated reason
being that emptiness without it produces withdrawal rather than freedom. Book 1 says the protection
must be in place before the insight arrives, because the insight removes a person's own reason to
bother. Two accounts arrived at separately, agreeing on the order and on the danger.

**And the model predicts the shape of the only motivation that can serve detachment.** Under the
width rule, a motivation with a particular object narrows what is open to noticing, so a detached
realm cannot be moved by an ordinary want without losing the competence that makes detachment worth
having. What it needs is a motivation that moves a person and has no particular part of the realm
to pull toward. Bodhicitta meets that exactly — the aspiration is toward all beings without
exception, which is why the traditions insist on the universality. `[A]`'s larger-peace claim is
the same point from the other side, and Shantideva argues it directly.

**Register 3. A correspondence, not a derivation. It must not become a reason to move anything.**

---

## 10. CLOSED IN THIS SESSION — recorded so nobody reopens them

- **The vulnerability ordering left open 09-08 is closed.** Burying belongs to the enthusiasm end
  and every arc passes through it, so no fixation is exempt. *"A and B fixations would not be
  vulnerable"* does not stand as written. `[A]`: *"agreed."*
- **What keeps the two ends of detachment one competence** — closed by `[A]`'s use account. Both
  ends have the whole realm open to noticing; the caution end spends it on arriving fears, the
  enthusiasm end spends it on nothing. The sameness sentence that used to carry this is deleted.
- **Job59's carve-out excluding arriving fears from the width rule is reversed** by *"any
  desire/fear narrows attention"*. The Nine's block (line 639) was already written to the new rule.
