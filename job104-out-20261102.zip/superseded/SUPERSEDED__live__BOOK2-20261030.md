# The Two-Realm Enneagram Model: A New Interpretation of the Enneagram

## Foreword

The roots of this book are in my lifetime difficulty seeing the motivations of others. Many people do this easily, and some who do not have learned to use social conventions to navigate interactions regardless. I grew up without either. Despairing, blundering through life, looking for help, I heard about the Enneagram, which gave me a map that allowed me to understand how people operate.

The same search also led me to spirituality. The word spirituality here means the essence of what religions teach, rather than the worldly aspects of established religions — power and money — which are its opposite. Spirituality gave me a second map, of how I myself operate. More can be learned when the subject is always available and motivated to cooperate.

What I have seen is that almost all people are confronted by the same problem — how to reconcile their deep motivations, habits and beliefs with the hard reality of cause and effect.

The book consists of what I have learned through reading, being taught, and my own experiences, observations, inferences and speculation. My deepest wish is that this material might help others as it has helped me.

---

## Table of Contents

[[#Foreword]]

[[#Introduction]]

**Part 1 — The Model**

1. A New Theory of the Enneagram[[#Chapter 1 A New Theory of the Enneagram]]
2. The Nine Enneagram Types — Profiles and Self-Perception[[#Chapter 2 The Nine Enneagram Types — Profiles and Self-Perception]]
3. The Two Realms[[#Chapter 3 The Two Realms]]
4. The Three Orientations[[#Chapter 4 The Three Orientations]]
5. Where the Types Come From[[#Chapter 5 Where the Types Come From]]

**Part 2 — The Finer Structure**

6. The Grid[[#Chapter 6 The Grid]]
7. The Cycle[[#Chapter 7 The Cycle]]
8. Relational Positions[[#Chapter 8 Relational Positions]]
9. Relational Dynamics[[#Chapter 9 Relational Dynamics]]
10. The Figure's Own Lines[[#Chapter 10 The Figure's Own Lines]]
11. Leans, and the Classical Wings[[#Chapter 11 Leans, and the Classical Wings]]
12. Learning to See

**Part 3 — The Depth of Fixation**

13. Where the Inner World Came From[[#Chapter 13 Where the Inner World Came From]]
14. Underneath the Cycle[[#Chapter 14 Underneath the Cycle]]
15. What Becomes of a Fear[[#Chapter 15 What Becomes of a Fear]]
16. The Fixations Themselves[[#Chapter 16 The Fixations Themselves]]
17. The Health Axis[[#Chapter 17 The Health Axis]]
18. Falling and Rising[[#Chapter 18 Falling and Rising]]

---

## Introduction

The Enneagram is a nine-pointed figure, and the personality system that now carries its name is a great deal younger than the figure itself. G. I. Gurdjieff brought the diagram to his students in Moscow in the years around the First World War, presenting it as a map of how processes unfold rather than of who people are. He claimed older sources, Sufi among them, though that lineage has never been established, and he did not teach nine personality types. Those came in the late 1960s, when Oscar Ichazo, teaching in Chile, first laid a psychology over the figure. Claudio Naranjo, a psychiatrist who studied with him there, carried it to Berkeley in 1971 and worked it into the detailed descriptions in use today. From Naranjo's students it passed into Jesuit retreat work, and from there outward, until Helen Palmer, Don Riso, Russ Hudson and others made it one of the most widely used accounts of personality anywhere.

What it offers is nine types: nine consistent patterns of motivation and behavior into which, remarkably, everyone seems to fit. Each approaches life and its difficulties in its own way, and each has its strengths and its weaknesses — though the more useful observation is that the same trait is a strength in one situation and a liability in another. A Nine stays calm where others would flare, which is worth a great deal in a crisis and very little when what is wanted is for somebody to object. The same evenness, left to run, becomes withdrawal, and then a dulling that holds everything at arm's length.

Knowing the types is useful in two directions at once. Inwardly, a person sees their own characteristic responses — and, which is harder to see, that these are responses among others, settled on so long ago and repeated so often that the possibility of answering any other way has quietly disappeared. Outwardly, a person sees that everyone has such a default, that other people's are not their own, and that the number of them is limited. The nuances never end; the patterns stay recognizable.

Much of the Enneagram's popularity comes from exactly this. It is a workable modern route to the oldest instruction there is, the one cut into the temple at Delphi: know thyself.

But the Enneagram works without anyone being able to say why it works. Why nine types, and not eight, or twelve? Why these nine? How does a set of nine categories manage to be a coherent typology that fits anybody at all, rather than a list that accumulated over time and could as easily have run longer or shorter? The classical system does not answer this. The nine are simply given.

---

# Part 1 — The Model

## Chapter 1: A New Theory of the Enneagram

Nine is a strange number for a typology to arrive at. It is not two, or three, or four, where schemes of temperament usually settle. It is not a round number, of the kind that suggests somebody stopped when the list looked full. It has the awkward specificity of something that was counted rather than chosen.

Suppose it was counted. Suppose the nine are not nine separate things at all, but what comes out of combining a smaller number of things — few enough to be simple, arranged so that they yield exactly nine and could not have yielded eight or ten.

Here is what such an arrangement looks like, in fruit.

Three kinds of fruit — an apple, an orange, a banana — and two tables. Put one fruit on each table.

The same fruit on both tables: apple and apple, orange and orange, banana and banana. That is three.

Now two different fruits. An apple on the first table and an orange on the second. Or an orange on the first and an apple on the second — and those are two arrangements, not one, because the two tables are not the same table. Apple and orange, orange and apple, apple and banana, banana and apple, orange and banana, banana and orange. That is six.

Three and six is nine. Not eight, not ten, and not by anybody's choosing: three things in two places gives nine arrangements, and there is nothing to be done about it.

The step worth holding on to is the one that looked like a quibble. If the two tables were interchangeable — if an apple on the left and an orange on the right amounted to the same thing as the reverse — there would be six arrangements. There are nine because the two places are genuinely different places.

So the question this book takes up is what the fruits and the tables actually are. What are the three things, and what are the two places they can sit?

The three are orientations — three ways of being turned toward whatever a person is dealing with — and the two are realms, two domains of experience that run on entirely different principles. In each realm one of the three settles and hardens into habit. A person holds one orientation in each realm. Three in each of two gives nine, and the nine are the nine Enneagram types, with their strengths, their weaknesses, their fears, and their characteristic ways of going wrong all following from which pair a person holds.

Readers who know the classical Enneagram will be used to a type having one hardened orientation. Here a type has two, one in each realm.

This is not a challenge to the classical Enneagram. It is an underlying structure the classical system has never had — one from which the types can be derived, and to which the classical system closely corresponds.

A word before beginning. What follows is a theory, and like any theory it is subject to testing and refinement. Do not take it as gospel, not to be questioned. Check it against your own experience and against the people you know, and use what works.

---

## Chapter 2: The Nine Enneagram Types — Profiles and Self-Perception

### Overview

Before any theory, meet the nine types as people. Each type tells itself a consistent story about who it is and why it does what it does — and each story is partly true and partly a blind spot. This chapter gives each type's story in its own voice, followed by what that type usually cannot see about itself. If you don't yet know your own type, this is the place to look for yourself. The gap between the story you recognize and what it leaves out is where the interesting part is.

One caution as you read: do not score yourself against these profiles trait by trait. Finding your type is an act of recognition, not tabulation — look for the profile that feels special, maybe as a jolt, often an uncomfortable one, that no checklist produces. Read each story listening for that, and distrust a match that was merely counted.

### Type 1 — The Reformer

**How They See Themselves**

Ones see themselves as responsible, principled people doing their best in a world that often falls short. In their own mind, they are not perfectionists — they are simply people who can see clearly what is right and what is wrong, what is done well and what is done sloppily. They don't experience their standards as unusually high; they experience everyone else as unusually lax.

They see themselves as the people who care enough to do things properly. While others cut corners, they hold the line. They carry a quiet, often exhausting sense that if they don't maintain standards, things will fall apart. They are the adults in the room — not because they want to be, but because someone has to be.

Ones rarely see their inner critic as a problem. That voice feels like conscience — a moral compass that keeps them from becoming the kind of person they would despise. To silence it would feel like ethical surrender.

They see themselves as fair, honest, and improvement-oriented — not harsh. If they point out what's wrong, it's because they care. People who don't point out what's wrong simply don't care enough.

**The Gap Between Self-Image and Reality**

What Ones often don't see is that their standards can feel crushing to others, that their "helpfully pointing out errors" can land as relentless criticism, and that the anger they deny — the tight jaw, the exasperated sigh, the barely concealed irritation — is visible to everyone around them even when they themselves feel perfectly calm and reasonable.

**Core Narrative They Tell Themselves**

"I am a good person trying to make things better. I hold myself to the same standards I hold others. I just want things to be done right — is that really so much to ask?"

**What They Fear Seeing in Themselves**

That they might be wrong. That their certainty might be rigidity. That beneath the high standards is a rage they've never fully acknowledged.

### Type 2 — The Helper

**How They See Themselves**

Twos see themselves as loving, generous, and genuinely attuned to others in a way that most people simply aren't. They take pride — often without realizing it — in their ability to sense what someone needs before that person has even articulated it. They are the ones who remember your birthday, who show up when things fall apart, who make sure everyone is fed, seen, and cared for.

They see themselves as selfless — and this is where the complexity lives. In their self-image, their giving is pure. They help because they love, not because they need anything in return. They are the warm center that holds relationships together.

They often see themselves as more emotionally intelligent than others — more tuned in, more compassionate, more willing to do the relational work that others avoid. This gives them a quiet sense of indispensability.

**The Gap Between Self-Image and Reality**

What Twos often don't see: that their giving is frequently strategic, even when unconscious — a way of making themselves essential. That they often help in the ways they think others need, rather than asking what is actually wanted. That beneath the warmth is a desperate, unspoken negotiation: I will give you everything, and in return, you will love me and never leave.

They also rarely see how much resentment accumulates when that unspoken contract isn't honored.

**Core Narrative They Tell Themselves**

"I love the people in my life deeply and I show it through action. I'm the kind of person who shows up. I don't ask for much — I just want to feel appreciated for what I give."

**What They Fear Seeing in Themselves**

That their love is conditional. That they need people to need them. That without their role as helper, they don't know who they are or whether they are lovable.

### Type 3 — The Achiever

**How They See Themselves**

Threes see themselves as capable, competent, and results-oriented people who make things happen. In their self-image, they are the ones who actually get things done while others theorize, hesitate, or complain. They value efficiency, excellence, and forward motion — and they apply these values to themselves relentlessly.

They tend to see themselves as inspiring — people whose drive and success motivate those around them. They don't see their ambition as ego-driven; they see it as energy, as leadership, as proof that they take life seriously.

Threes often see themselves as highly adaptable — able to fit into any context, lead any room, master any skill. This flexibility feels like a strength, not a loss of identity.

They frequently see themselves as the person others rely on to represent the group, the family, or the company well. They carry the weight of that representation with discipline and pride.

**The Gap Between Self-Image and Reality**

What Threes often don't see: that their identity has become so fused with their performance that they've lost contact with who they actually are underneath the achievements. That their "adaptability" sometimes means they have no stable self — only a succession of roles played well. That relationships suffer when people sense they're being managed or outpaced rather than genuinely met.

**Core Narrative They Tell Themselves**

"I work hard and I deliver. I set goals and I reach them. Success isn't vanity — it's the natural result of taking your potential seriously. I am what I've built."

**What They Fear Seeing in Themselves**

That the self beneath the success is empty or ordinary. That they've achieved things no one — including themselves — actually needed. That they've been performing so long they don't know the audience from the actor.

### Type 4 — The Individualist

**How They See Themselves**

Fours see themselves as uniquely perceptive, emotionally deep, and fundamentally different from ordinary people. This difference is both their wound and their identity. In their self-image, they feel things more profoundly than others, see beauty and meaning where others see nothing, and carry an inner richness that most people never access.

They tend to see themselves as authentic above all else — unwilling to wear the masks that others wear to fit in socially. They would rather be genuinely themselves, even if that means being misunderstood, than perform a hollow version of normalcy.

Fours often see themselves as creative, sensitive, and emotionally honest — people who are willing to look at the darkness of life that others prefer to avoid. They may see themselves as ahead of their time, as outsiders who perceive what the mainstream misses.

There is frequently a sense that their suffering is meaningful — that their pain has made them deeper, more perceptive, more real than those who've lived more comfortably.

**The Gap Between Self-Image and Reality**

What Fours often don't see: that the identity built around being "different" can become its own kind of performance. That romanticizing suffering can become a way of avoiding ordinary life rather than enriching it. That they can push people away and then mourn the distance they created.

**Core Narrative They Tell Themselves**

"I feel things deeply and I don't apologize for it. I am not interested in surface-level living. My intensity and sensitivity are not problems — they are who I am. I am still searching for what will make me feel whole."

**What They Fear Seeing in Themselves**

That they are not as special as they believe. That their suffering is sometimes chosen. That the ordinariness they run from might actually be where life is lived.

### Type 5 — The Investigator

**How They See Themselves**

Fives see themselves as clear-eyed, objective, and intellectually self-sufficient in a world full of people who are driven by emotion and irrationality. In their self-image, they are the ones who actually understand — who have done the work of thinking deeply, of not accepting easy answers, of building genuine expertise rather than surface familiarity.

They see their privacy and detachment not as coldness but as clarity. They don't get swept up in social dramas because they can see those dramas for what they are. They don't need constant stimulation or company because they have a rich interior world that is genuinely satisfying.

Fives often see themselves as independent and self-contained in a way they deeply respect. They don't make demands on others and they expect none in return. This feels like integrity to them — a kind of emotional cleanliness.

They frequently see themselves as the expert — the person who actually knows, in a world of people who merely opine.

**The Gap Between Self-Image and Reality**

What Fives often don't see: that their self-sufficiency leaves them short of intimacy and aliveness. That the detachment they prize can leave others feeling shut out and irrelevant. That knowing about life and actually living it are very different things — and that they can mistake the former for the latter.

**Core Narrative They Tell Themselves**

"I observe, I think, I understand. I don't need much and I don't impose on others. The world makes more sense to me when I have time to process it privately. Knowledge is the thing I can always rely on."

**What They Fear Seeing in Themselves**

That all their knowledge and preparation hasn't actually made them ready for life. That they are lonely in a way that thinking cannot solve. That they have been a spectator of their own existence.

### Type 6 — The Loyalist

**How They See Themselves**

Sixes see themselves as responsible, perceptive, and genuinely loyal in a world where those qualities are rarer than people claim. In their self-image, they are the ones who think ahead — who see potential problems before they materialize, who don't let things slide through naive optimism, who stay when others leave.

They tend to see themselves as honest and trustworthy — people who mean what they say and say what they mean. They are suspicious of those who seem too smooth, too certain, too eager to please, because they know that real life is complicated and anyone who says otherwise is selling something.

Sixes see their vigilance as realism, not anxiety. They aren't paranoid — they're prepared. They aren't suspicious — they're discerning. In their mind, the people who don't worry are the ones who haven't thought things through.

They often see themselves as the glue in systems and relationships — the person who maintains commitments, shows up reliably, and holds the group together through consistency.

**The Gap Between Self-Image and Reality**

What Sixes often don't see: that their threat-detection system, always running, creates the anxiety it claims to prevent. That they can project hostility onto people who have done nothing to deserve that suspicion. That their loyalty, which is real, sometimes comes with invisible strings — and that they can become deeply resentful when those strings are not reciprocated.

**Core Narrative They Tell Themselves**

"I see clearly what others miss because I'm not fooling myself. I am loyal to the people and causes I believe in. I prepare for what could go wrong because I've learned that things do go wrong. My doubt is not weakness — it's wisdom."

**What They Fear Seeing in Themselves**

That their doubt undermines the very security they seek. That they sometimes sabotage trust before it can betray them. That the authority they've been seeking outside themselves has been available within them all along.

### Type 7 — The Enthusiast

**How They See Themselves**

Sevens see themselves as open, adventurous, and fully alive in a way that most people — dulled by routine, habit, and fear — have forgotten to be. In their self-image, they are the ones who say yes, who see possibility where others see obstacles, who bring energy and lightness into rooms that would otherwise be heavy.

They tend to see themselves as positive realists — not naive, but wisely optimistic. They aren't running from problems; they simply refuse to be defined by them. In a world that defaults to complaint, they choose engagement.

Sevens frequently see themselves as creative, quick, and generative — the person who makes unexpected connections, who can hold ten ideas at once, who brings a kind of mental electricity to any problem.

They often see their love of freedom and variety not as avoidance but as an authentic attitude toward life — a genuine delight in experience, in learning, in the sheer richness of what the world offers.

**The Gap Between Self-Image and Reality**

What Sevens often don't see: that the optimism can be a practiced defense against grief, limitation, and depth. That their mental speed, which they experience as a gift, can make others feel unheard or outpaced. That they can mistake stimulation for meaning, and motion for growth.

**Core Narrative They Tell Themselves**

"Life is extraordinary and there's so much of it to experience. I bring energy and possibility into whatever I'm part of. I choose not to dwell in what's heavy because I know, from experience, that focusing on what's good actually works."

**What They Fear Seeing in Themselves**

That they are running. That beneath the enthusiasm is a quiet terror of emptiness. That some of their most important relationships have suffered for their need to keep moving.

### Type 8 — The Challenger

**How They See Themselves**

Eights see themselves as direct, strong, and honest in a world that is too often weak, evasive, and dishonest. In their self-image, they are the ones who tell the truth when everyone else is performing politeness. They are the ones who act while others deliberate. They are the protectors — of themselves, and of those who cannot protect themselves.

They take enormous pride in their directness. They see it not as aggression but as respect — treating people like adults who can handle the truth, rather than coddling them with comfortable lies. In their view, the people who are offended by their bluntness are simply too fragile to function in reality.

Eights see themselves as fundamentally fair — their intensity is applied consistently, to themselves as much as anyone. They don't ask more of others than they ask of themselves. They see their willingness to take on conflict as a kind of courage that most people lack.

They often carry a quiet, fierce sense of themselves as protectors — especially of the vulnerable, the betrayed, the overlooked.

**The Gap Between Self-Image and Reality**

What Eights often don't see: that their impact and their intent are frequently misaligned — that what feels like honest directness lands as domination. That their low threshold for weakness in others can make people around them shrink. That their certainty, which feels like clarity, sometimes forecloses the truth rather than revealing it.

**Core Narrative They Tell Themselves**

"I am who I am and I don't apologize for it. I tell the truth. I protect what matters to me. I would rather have an honest enemy than a dishonest friend. My strength is not a problem — the world needs people who aren't afraid."

**What They Fear Seeing in Themselves**

That their hardness has kept them from intimacy they deeply wanted. That some of what they call strength is armor that was built from very old pain. That the vulnerability they despise in others is the very thing that would set them free.

### Type 9 — The Peacemaker

**How They See Themselves**

Nines see themselves as easy-going, accepting, and genuinely content in a way that others seem to struggle to be. In their self-image, they are not passive — they simply don't need to make everything into a conflict. They can see all sides of an issue because they genuinely understand that most conflicts come from people not feeling heard, not from irresolvable differences.

They tend to see themselves as calm, stable, and grounding — the steady presence that others can come to when the world feels chaotic. They are the ones who don't overreact, who don't take things personally, who create spaces of ease and acceptance.

Nines often see themselves as highly adaptable and unpretentious. They don't need to be the center of attention. They don't need things their way. They just want everyone to feel okay — and they see this attitude as a kind of emotional generosity.

They frequently experience themselves as comfortable with silence, with routine, with the unspectacular rhythms of ordinary life. This feels like contentment to them, even when others might see it as inertia.

**The Gap Between Self-Image and Reality**

What Nines often don't see: that their "contentment" is sometimes numbness. That their "seeing all sides" can be an avoidance of taking their own side. That the self they've made so agreeable and undemanding has quietly disappeared — and that no one can truly love a person who isn't fully there.

They also rarely see the passive stubbornness — the immovable, quiet resistance — that emerges when they are pushed past their tolerance.

**Core Narrative They Tell Themselves**

"I don't need things to be my way. I just want peace — for myself and for the people I care about. I'm not checked out; I'm just not going to create drama where there doesn't need to be any. I am comfortable with who I am."

**What They Fear Seeing in Themselves**

That they have been absent from their own life. That their comfort with merging into others' worlds is not acceptance but self-erasure. That the conflict they have avoided all their life might actually be the place where they would finally discover who they are.

### The Common Thread Between the Types

Every type's self-image is a story built around a survival strategy that once made sense — and every type's growth begins with the courage to question that story. The gap between how we see ourselves and how we actually move through the world is not a flaw to be ashamed of. It is the precise location where growth becomes possible.

The Enneagram doesn't ask you to abandon your self-image. It asks you to hold it more lightly — with curiosity rather than defense — and to become genuinely interested in what lies just beneath it.

---

## Chapter 3: The Two Realms

Everything a person deals with falls on one of two sides.

There is the world of objects, actions, and consequences. Things happen there whether or not anyone notices; when two people disagree about it, the matter can be checked. A carefully repeated experiment gives the same result no matter who runs it. Push an object and it moves; plant a seed, water it, and it grows. Results come through action, and effort works through cause and effect — which also means it can fail, when the causes are wrong or insufficient. Intention alone moves nothing. This is the physical realm, and this book abbreviates it **H**.

Then there is the inner world of thought, feeling, and meaning: private thoughts, emotions, values, one's sense of one's own mind and of other people's, consciousness itself. It belongs to each person alone. What you believe affects what you experience; what you are looking for determines what you notice; your interpretation determines what a thing means. This is the psychic realm, **S** — psychic in the sense of the Greek *psychē*, of the psyche, mind and inner life, nothing to do with extrasensory perception.

The difference that matters most is what happens when a person gets something wrong.

In the physical realm, reality pushes back. Walk into a wall and the wall wins the argument. Build it badly and it falls down regardless of your opinion of it. The pushback comes from outside, it is corrective, and it arrives whatever you believe.

The psychic realm is what happens in a person's mind. A mind can conceive of other minds conceiving of other minds, and of itself conceiving of itself. A person's thinking and feeling are part of the psychic realm, so whatever a person thinks or feels becomes part of what the person is thinking or feeling about.

There is a saying that borrows an obvious physical fact to point at a less obvious inner one: wherever you go, there you are. In the physical realm that is trivial. In the psychic realm it is the whole situation — you are both the traveler and the terrain. Nothing external pushes back. Whatever a person keeps turning over in their mind grows with the turning over. What a person believes colors what they then experience, and they take the experience as confirmation. Fear of fear produces more fear. Think one thing or think its opposite; either way you are there, and the thinking becomes part of the very thing being thought about.

So in the physical realm a person is corrected by pushback, and in the psychic realm a person keeps adding to what they are thinking about.

The plainest instance is trying to make yourself fall asleep. Everywhere in the physical realm, applying more effort gets you closer to the result. Here the effort is the very thing keeping you awake, and the harder you apply it the further away sleep gets. Nothing pushed back. The trying simply became part of what was being tried at.

Neither realm is the real one. A computer makes the point, and by a happy accident the letters fit: H for hardware, S for software. A computer is a physical object through and through, every operation in it electronics obeying the laws of physics — and the hardware alone is useless. What makes it a computer is software, which cannot be seen or touched and is nothing but information. Is software therefore not real? Does it have any existence apart from the machine that runs it? Neither position holds. You cannot understand a program by studying semiconductor physics, because a program runs on its own logic. Each can be described entirely in the other's terms; each runs on principles the other does not use.

There is one error, and it runs in both directions. Someone expects the physical world to answer to wanting — if I want it enough it will come, if I care enough they will stay — and it does not, because that world answers to action. Or someone expects the inner world to answer to force and measurement — treating consciousness as neurons and meaning as preference, or trying to secure a feeling the way one secures a door — and it does not, because in the psychic realm whatever a person thinks or feels becomes part of what the person is thinking or feeling about.

Try it against your own experience. Recall a time you tried to fix an inner state by outer means, and a time you tried to move the world by wanting. The two failures have entirely different textures.

---

## Chapter 4: The Three Orientations

Only the same three orientations are possible toward the content of each realm. This book abbreviates them **A**, **B**, and **Z**.

### Attraction, aversion, want and fear

Attraction and aversion are the two directions in which a person can be drawn: toward something, or away from it. Some attractions and aversions are only felt. Liking and disliking are of this kind. They are not chosen, and they need not motivate the person to do anything.

A want is what motivates a person to bring something about: to have something, to keep it, or to be rid of it. An attraction can raise a want to have something or to keep it. An aversion can raise a want to be rid of something.

A fear is an aversion to something that might happen, such as losing a job or spilling a cup of coffee. A fear can arise from an attraction, as the fear of losing someone arises from being drawn to them. A fear can also arise from an aversion, as the fear that a pain will return arises from disliking the pain. A fear motivates the person to keep the feared thing from happening. Once a fear is conceived, the prospect is present in the person's mind, so a fear works like any other aversion.

Some attractions and aversions also involve the will: craving and coveting on the side of attraction, hatred on the side of aversion. Every fear has a want behind it. Behind the fear of losing a job is the want to keep the job.

### Enthusiastic, cautious and detached

**A, enthusiastic.** Drawn toward what attracts, focused on possibility and gain, playing down risk. Its competence is **doing**: wholehearted engagement with the realm — action in the physical, immersion in the psychic. It can be loud or quiet. Chasing a goal is doing in its active style; hours lost in a garden or a piece of music is doing in its quiet one. Speed and volume are matters of temperament, and a slow, still person can be as thoroughly enthusiastic as a fast, loud one.

**B, cautious.** Alert to threat, to loss, to what could go wrong. Its competence is **understanding**: a worked-out grasp of how things work, what could fail, and how events will unfold. It is arrived at deliberately — noticing a thing, generalizing from it, testing the generalization against what happens next, and revising it. In some people this shows up as explicit plans and contingencies; in others it is held silently, a map kept current with no schedule attached. Both are the same competence. What marks it is wanting to comprehend a situation before trusting it.

**Z, detached.** Stepped back, neither reaching for what attracts nor trying to avoid what threatens. A detached person still minds being disturbed. What such a person wants is peace: to be free of the pull of wanting and fearing. Its competence is **being able to notice more**. While nothing is disturbing a detached person, nothing pulls their noticing toward anything in particular, so the whole realm stays open to their noticing. An enthusiastic or a cautious person is being pulled by a want or a fear, so less of the realm is open to their noticing.

Each competence is real. The enthusiast really does start things and really does throw themselves in. The cautious one really does see what is coming. The detached one really can notice anything in the realm, while nothing is disturbing them. Each competence is a genuine capacity that people holding the other two orientations do not have. Each competence is also part of why a person keeps the orientation they hold.

### Taking in and noticing

Everything a realm holds is taken in, whole and at once, with nothing assembled and nothing inferred. Picking one part out of what was taken in is a second and different act. This book calls that act noticing, and it is work.

What has been taken in stays out of view until a person wants something in it. That is when the noticing happens. So motivation is what brings the noticing on. Motivation also sets how much of what was taken in is open to noticing. The taking in itself is not limited. A want or a fear pulls a person's noticing toward what the want or fear is about. The harder a want or a fear pulls, the less of anything else is open to noticing.

An enthusiastic person wants one particular thing and is acting on it, so what is open to their noticing is narrow. A cautious person fears several outcomes at once, and working out how a whole situation will go is what those fears require, so what is open to their noticing is wider. A detached person does not look for disturbances. When a disturbance is noticed, what the person wants is to quiet the disturbance, and their noticing goes to that. When a detached person wants to solve what is disturbing them, a great deal stays open to their noticing, and the noticing can be deep. This is the widest of all. When a detached person simply wants the disturbance to go away, very little stays open to their noticing. This is the narrowest of all, narrower than an enthusiastic person's.

What separates the three orientations is what a person holding each one notices. Each person largely overlooks what people holding the other two orientations notice. The difference is not one of subject matter: two people can face the same trouble with the same facts in front of them, one noticing what could still be gained and the other what could still go wrong. Noticing is something a person does, again and again, and a person notices something only when it matters to them: when it bears on something they want or fear.

Taking in goes on all the time, whatever a person is doing. What changes from moment to moment is the noticing. Sometimes a want or a fear pulls a person's noticing toward one thing. At other times nothing is pulling, and the whole realm is open to noticing. A person moves between noticing one thing and having the whole realm open many times a day. What a person notices most is determined by the orientation they hold.

### Intuition

Intuition is a person noticing something now that was taken in earlier and never noticed at the time. A person can remember something happening only if they noticed it at the time. So the person has no memory of the thing happening. The person knows the thing and cannot say how they know.

Nothing has to be hidden for that to happen. What was never noticed was never put anywhere, so there is nothing to dig out. The material need not be old either — something taken in a moment ago is reached the same way as something taken in decades ago. And it is the only route to what a person learned before they had words for anything, since none of that was ever in words for a list of questions to ask about.

### When something goes wrong

People holding the three orientations also differ in what they do when something goes wrong — a blocked goal, a complication, an irritation. An enthusiastic person has no native answer to a negative at all, and does the one thing attraction can do: turns toward the next positive. The blocked goal is neither worked through nor fled. The person simply stops noticing the blocked goal. A cautious person engages, and the trouble gets looked at, analyzed and managed. A detached person steps back and lets the difficulty go, or does not look at it in the first place.

### Being caught, and what a person can bear

Each of the three also comes with something a person cannot easily bear. What an enthusiastic person cannot easily bear is disappointment. What a cautious person cannot easily bear is losing control. What a detached person cannot easily bear is the discomfort that fear leaves behind.

How much pain one of those produces depends on how strongly a person holds the orientation. The more strongly a person holds the orientation, the more deeply caught the person is. Deeply caught, a small disappointment produces a great deal of pain. Less caught, the same disappointment produces less.

What a person can bear is set by what previous thoughts have laid down. Stress is whatever lowers a person's capacity to bear pain. It can come from anywhere: a bad night, an illness, a worry carried in from somewhere else. A person under stress can bear less, so the same thing is harder to face than it was the day before.

Stress does not stay in the realm it came from. A person has one capacity to bear pain, not one for each realm, so a stressful week in the physical world leaves less to face an inner fear with. What differs between a person's two realms is how much pain the same kind of event produces in each. Stress lowers the one capacity, so stress lowers what a person can face in both realms at once.

One thing follows from that. Being deeply caught in a realm is stressful. So a person deeply caught in one realm can bear less in both realms. The two realms are therefore not independent, whichever one a person is more deeply caught in.

### What a detached person does with a fear

A detached person's own want is peace. While nothing is disturbing the person, wanting peace pulls the noticing nowhere. A fear can still arrive in a detached person's realm, and a fear motivates a person. A fear that was not settled is raised again later, and motivates the person again.

Detachment has two faces. Before anything disturbs a detached person, nothing in the realm is pulling at them, so the whole realm is open to noticing. The two faces differ in what happens when a disturbance arrives, such as the discomfort a fear leaves behind. Sometimes a detached person looks at the disturbance and wants to solve what is disturbing them. Sometimes the person simply wants the disturbance to go away.

Detachment lies between caution and enthusiasm. When a fear arrives for a detached person, the fear comes to the caution end first, where fears are still noticed. The fear then moves on toward the enthusiasm end, where a person wants the fear to go away. The more attention a person gives the caution end, the more likely a fear is to be settled.

At the enthusiasm end, a person is more likely to turn away from anything negative. Sometimes a fear grows until the fear is more than the person can bear, and panic turns the person away from the fear. The panic happens at the caution end, where the fear is still in view. The turning away is completed at the enthusiasm end. From then on, the person turns away automatically from fears about the same matter. That automatic turning away is denial. Denial happens before a later fear is noticed. Denial is something a person does, but not consciously. To decide not to look at something, a person would first have to notice it. Denial happens before the noticing, so there is nothing yet for the person to decide about.

Denial can become very firm. When someone else points the thing out, the person in denial turns away from it again, and may insist the thing is not real. Denial covers only the thing a person is in denial about. Everything else in the person's life can be noticed in the ordinary way.

Turning away eases the anxiety for the moment. Neither the anxiety nor the easing is noticed. Both are taken in, and the easing is what holds the turning away in place. What the person feels afterwards is unease, with nothing to explain it. What a person has turned away from cannot be found by deliberately looking for it, because trying to find it would probably set off the anxiety again. But the thing can come back into view by itself, at a time when nothing sets off the anxiety. And intuition can act on it, since only the person's awareness of it is blocked.

---

## Chapter 5: Where the Types Come From

A person has one of these three in the physical realm and one in the psychic, and they need not be the same. Three possibilities in each of two realms gives nine combinations.

This book calls a realm detached when the person is detached in it. A realm is called enthusiastic or cautious in the same way.

The nine combinations are the nine Enneagram types.

A pair is written as the physical realm first and then the psychic: Type 5 is HB;SZ, cautious in the physical realm and detached in the psychic.

Things cross between a person's two realms, and not every crossing does the same work.

A way of working can cross. A person used to taking a whole realm in at once can bring that way of working to the realm they work out piece by piece. Working a thing out piece by piece cannot produce a judgment about the whole, so a person who takes the realm in whole instead can reach a judgment they could not otherwise make.

Motivation can cross. An enthusiastic or cautious realm supplies motivation the person can direct at their other realm, when the other realm is detached. What crosses is the motivation and not anything it is about, so the person can direct it at whatever the detached realm has taken in. A person can therefore work on a detached realm with two kinds of motivation: the wants and fears the person raises about matters in the detached realm, and the motivation an enthusiastic or cautious realm supplies.

When a person applies one realm's standards and limits in the other realm, the outcome fails. A person who applies the physical realm's standards in the psychic realm makes a demand the psychic realm cannot meet.

### Type 1 (HA;SB) — The Reformer

**Physical: Enthusiastic; Psychic: Cautious**

Both competences are strong, but only one of them is in view. In the physical realm the One is *doing* — acting on the world, getting things finished, holding a line that others let slip — and this is what a One would tell you they are up to. In the psychic realm the One is *understanding*: a worked-out grasp of how the inner world runs, of what is right and what is shoddy, of the principle a situation actually depends on, held with the confidence of something arrived at rather than assumed. That second competence is not experienced by the One as a competence, or as anything in particular. It shows up in what they will not let pass. Ones are frequently the most reliable people in a room, and their sense of what ought to be done is usually accurate.

What the pair produces that neither half would alone is a person who both knows what ought to be the case and acts on it. Those two usually come apart. People who see clearly what is wrong very often do nothing about it, and people who act decisively very often have not stopped to ask whether the thing is right. The One has understanding in the realm where standards live and doing in the realm where things actually change, so the standard reaches the world. It is also why a One's word holds. A commitment made in the psychic realm was never a physical-realm calculation, so it does not get recalculated when keeping it turns out to be inconvenient.

Where a person is enthusiastic in one realm and cautious in the other, the person's focus is on the enthusiastic realm. The cautious realm runs as an automatic check on everything that is happening. A person takes in the whole of a realm without needing any motivation to do so, which is why a check can run over everything at once. When a fear arises in the cautious realm, the fear arrives already attached to what it is about. An arriving fear is an alarm. The cautious realm gets the person's focus whenever an alarm is raised there, and the rest of the time the enthusiastic realm has the foreground.

The cautious realm is not weak. A One notices each particular thing that raised an alarm, and holds off from it. What a One never notices is the holding off. Caution is what a One looks with, and a person does not look at what they are looking with.

A One also misreads caution in other people. An enthusiastic person plays down risk, and so cannot read caution wherever caution appears. The One is enthusiastic in the physical realm, so what the One cannot read is another person's care about physical difficulty. The person weighing how hard a thing actually is sounds like someone making excuses, or not caring enough to try.

So the One experiences themselves as simply getting on with things properly. The standards supplying the measure are not experienced as standards. They are experienced as plain fact about how things are.

A One is cautious in the psychic realm, and a person works out what could go wrong in the realm where they are cautious. So the fears a One works out are psychic ones: whether a thing is proper, rather than whether a thing is actually correct. Physical pain still raises fears in the physical realm, as in anyone.

Ideals are psychic-realm objects, and in the psychic realm a principle is exactly itself — nothing dilutes it, and there is no version of honesty that is honest enough. An ideal also has no end point, and for the reason sleep has none: measuring yourself against it is one more act inside the thing being measured, so every step toward it looks like the step before, and approaching never arrives. Carry that measure into the physical realm, where nothing matches an ideal exactly and never has, and the result is a standard that cannot be met by anything. A standard is a psychic-realm standard, and it crosses into the physical realm and fails there. This is perfectionism, and it comes with its own signature resentment — a world permanently falling short of a standard that was never valid there.

The inner critic is the same error turned inward. The One's own conduct is a physical-realm thing, and it is being measured against absolutes, so it is found wanting, necessarily and forever.

That permanent shortfall has a temperature. A standard nothing can meet is being missed continually — by other people, by circumstances, by the One themselves — and the friction of being thwarted that steadily is anger. Not an occasional flare, but a low, constant heat that never has an event to attach itself to, because what is thwarting it is everything.

Everyone else can see the anger: the tight jaw, the clipped sigh, the patience audibly held. The One cannot. A tight jaw and held patience are the guarding, showing on the outside. A One notices each particular thing that raised an alarm and holds off from it. Nothing raises an alarm about the holding off, so a One has no occasion to notice the guarding at all.

None of this is the whole of what a One has from the pair.

Take the physical realm first, where a One is enthusiastic. A One less caught in the physical realm can weigh how hard a thing will actually be, before deciding what ought to be done about it. They can grant that a task is genuinely difficult, and they can hear somebody else say so without hearing an excuse.

The psychic realm is different. That is where the standards sit, and they are what stays out of view, because the doing holds the foreground and the standards are experienced as plain fact about how things are. A One's looking is in the physical realm, and the standards are in the psychic. They stay quiet because a One judges everything by them and so never has occasion to judge them. A One can still come to see them, and what usually starts that is a report from outside — someone saying the jaw is tight, or that the patience was audible. Caught, a One dismisses that, because it contradicts something that is not being experienced as a standard at all. Less caught, a One can take the report as news about the guarding they judge from.

Whatever a One's condition, the pair still gives them what it gives: they know what ought to be the case, they act on it, and their word holds.

### Type 2 (HZ;SA) — The Helper

**Physical: Detached; Psychic: Enthusiastic**

In the psychic realm the Two is *doing*: wholly immersed in people, feeling, connection. The attunement they are known for is not a story they tell about themselves. It is a real competence, and they generally do sense what someone needs before it is said. In the physical realm they are stepped back. While nothing in the physical realm disturbs them, the whole physical realm stays open to their noticing.

Together the pair produces a generosity that is genuinely uncalculated. Most people weigh helping against the time and effort it will take, quickly and half-consciously, and the weighing shows. The Two does not do that weighing. The reason is not virtue. The time and effort would come out of the physical realm, and nothing in the physical realm is pulling at a Two. So help arrives early, fast, and without terms attached at the moment it is given. And because the psychic realm is where they are fully engaged, they answer what is actually wanted rather than what would be reasonable to offer, which is why their help so often fits.

A person rarely acts in the realm they have stepped back from, but when they must, they have no native way of working there and use the mode of the realm they are engaged in. The Two's engaged mode is doing, so their physical action comes out as practical service, given freely: remembering the birthday, showing up when things fall apart, making sure everyone is fed. Detachment from the physical realm also means little thought of what it takes from them, which is exactly what makes the giving look — and often be — generous.

The trouble starts where the two realms are confused. A Two's feeling becomes part of what the Two feels about, so the psychic realm appears to have no ceiling: feeling can always be raised, care always deepened. The Two carries that expectation across and waits for the physical realm to answer the same way. *If I love them enough they will stay. My care should make them grateful.* But the physical realm answers to action, not to how much a person feels, and the emotional intensity produces nothing in the physical realm. In the psychic realm there is no ceiling on what can be given, and a Two carries that into the physical realm, which has one.

So there is care without the practical follow-through, and then the sense of having been wronged when reality does not repay the feeling. Beneath the warmth sits an unspoken bargain — everything given, love and permanence expected in return — and when it is not honored, resentment gathers, unaccounted for, because nothing was ever openly asked.

And because everything the Two is engaged in lives in the one realm, the question of who they would be without the role has no available answer.

None of this is the whole of what a Two has from the pair.

Take the physical realm first, where a Two is detached. A Two takes in the whole of the physical realm. A Two's enthusiastic psychic realm supplies motivation a Two can direct at the physical realm, and a Two directs that motivation at whatever bears on the people a Two cares about. So a Two does look at the physical realm, and notices what somebody needs done. Everything else a Two has taken in there goes unnoticed. The unnoticed part includes what a situation requires beyond what anyone has asked for, and how much time and effort the helping uses up. A Two less caught in the physical realm turns the supplied motivation on more of what is there, and then acts on what they notice. The care is carried into action, and the practical follow-through arrives instead of the feeling being left to do the work by itself.

The psychic realm is different. That is where a Two is enthusiastic. A Two less caught in the psychic realm can notice how worn down the giving leaves them, rather than moving on to the next person who needs something. What a Two gives is no longer expected to be answered in kind, so nothing accumulates underneath unspoken. The question of who a Two would be without the role stops being a question a Two cannot face.

Whatever a Two's condition, the pair still gives them what it gives: they sense what someone needs before it is said, and the help fits.

### Type 3 (HA;SA) — The Achiever

**Physical: Enthusiastic; Psychic: Enthusiastic**

The Three has nothing held in reserve. Both realms are entered wholeheartedly, and the drive people notice is exactly that: doing in the physical realm and doing in the psychic, at once and without brakes. Threes really do get things done while others deliberate, really are adaptable, and really can carry the weight of representing a group well. The competence is not a performance, whatever else is.

What the pair gives is something no single-realm engagement can: nothing held in reserve. Most people commit either their effort or their heart to a thing and keep the other back. The Three commits both, which is why the drive carries other people along — enthusiasm in the psychic realm is not a technique being applied to a room, it is the state they are actually in, and it is contagious for that reason. The adaptability has the same root. Drawn toward whatever is in front of them in both realms at once, they take the shape a situation needs quickly, and without the resentment that usually comes with it.

Holding the same orientation in both realms has a particular consequence. A person who is cautious in one realm and enthusiastic in the other notices in two different ways, and feels the difference daily, from inside. A person who is the same in both has nothing to compare, and the two collapse into one undifferentiated reality with one set of rules.

For the Three that single set of rules is achievement. Success in the physical realm is expected to settle the question of worth in the psychic — and it does not, because nothing done in the physical realm reaches a question asked in the psychic, and worth is arrived at only inside the realm where the question is asked. So the Three achieves, externally and genuinely, and the internal result that was supposed to follow does not arrive. Or it runs the other way and the internal conviction fails to show up as anything outside.

There is also no detachment in either realm, which means no step back and no vantage point on either one. What accumulates in that blind spot is the gap between the roles played well and whoever is playing them, and it goes unwatched until something stops the motion.

None of this is the whole of what a Three has from the pair.

Take the physical realm first, where a Three is enthusiastic. A Three less caught in the physical realm can stay with an attempt that fell short instead of turning to the next one. The achieving still runs, but a result that did not work is looked at rather than passed over, so what gets learned in the doing is kept.

The psychic realm works the same way, because a Three is enthusiastic there too, and this is where it matters. What falls short in that realm is the achievement itself: it was supposed to settle the question of their own worth, and it does not. Caught, a Three moves straight to the next achievement, and the failure is never noticed. A Three less caught in the psychic realm notices it — and what it teaches is that nothing done in the physical realm reaches a question asked in the psychic.

Whatever a Three's condition, the pair still gives them what it gives: they get things done in the world, and they carry other people along while doing it.

### Type 4 (HZ;SB) — The Individualist

**Physical: Detached; Psychic: Cautious**

In the psychic realm the Four is *understanding* — and the depth that Fours are known for is real. They do grasp feeling more finely than most people, they do see what is under a surface, and they are not inventing the perception. In the physical realm they are stepped back, and *taking it in* whole.

The two together make an uncommon pairing: exact understanding of inner life, and a clear unattached view of the outer one. Most people looking at the world want something from it, and what they see is shaped by the wanting. The Four does not, so the world arrives undistorted — and they have, in the other realm, what it takes to say what it means. That is the combination behind the artistic gift Fours are known for. Seeing plainly is common enough on its own, and articulating feeling is common enough on its own. Having both, pointed at each other, is not.

When the Four has to act in the physical realm, the mode they bring across is understanding. So their physical action tends to be interpretive: reading meaning into the material world, and translating what they understand inwardly into something that can be shown, made, or explained. The artistic bent follows from the pair rather than from temperament. Understanding is a way of working, and a way of working crosses and holds.

Caution in the psychic realm means alertness to what could go wrong there — and what can go wrong in that realm is lack. Something missing, something not right, something other people appear to have. A Four's watching becomes part of what the Four is watching, so watching for a lack feeds the lack: the searching is part of what turns up. So the search cannot close, and the sense of difference is at once the wound and the identity.

None of which is hidden from the Four. Nothing in them is enthusiastic, so nothing is holding the foreground against the caution, and the searching is entirely in view — a Four will describe it at length and accurately. What they call it is sensitivity, or depth, or a refusal to settle for what satisfies other people. The account is correct. Only the name is flattering.

And the understanding has nothing to temper it. Taking a whole realm in at once is what a Four does in the physical realm, and it is a way of working they are familiar with, so it is within reach in the psychic realm too. Judging that enough has been understood takes the whole at once, and understanding cannot assemble it. A Four who does not reach for it has no way to say when they have gone far enough. So the analysis goes deeper rather than stopping, and the depth that is a real competence becomes obsession — the same ground worked over, more finely each time, with nothing available to say enough.

Depth and authenticity are treated as absolutes, which they can be in the realm where they live. The ordinary demands of physical life, measured against them, come out as beneath notice, even as violations of something true. But the physical world runs on its own principles and is indifferent to how truthful an inner life is, so the mundane keeps arriving and keeps being an affront.

The distance from other people follows the same route. Pushing someone away is a physical-realm action with physical-realm consequences, and consequences in that realm are exactly what a person stepped back from it does not track. So the distance is created and then, genuinely, mourned.

None of this is the whole of what a Four has from the pair.

Take the physical realm first, where a Four is detached. A Four takes in the whole of the physical realm. A Four's cautious psychic realm supplies motivation a Four can direct at the physical realm, and a Four directs that motivation at whatever bears on the lack a Four watches for. So a Four does look at the physical world, and notices what carries meaning there. Everything else a Four has taken in goes unnoticed, including what pushing someone away will do. The damage from pushing someone away arrives before a Four has noticed it coming. A Four less caught in the physical realm turns the supplied motivation on more of what is there, and then acts on what they notice. The demands of physical life get taken up, so they stop arriving as an affront, and the distance from other people is not created and then mourned.

The psychic realm is different. That is where a Four is cautious. A Four less caught in the psychic realm can tell when enough has been understood. The searching for what is missing still runs, but the analysis comes to an end, so the depth stays a competence rather than turning into obsession.

Whatever a Four's condition, the pair still gives them what it gives: the world arrives undistorted, and they can say exactly what inner life is like.

### Type 5 (HB;SZ) — The Investigator

**Physical: Cautious; Psychic: Detached**

In the physical realm the Five is *understanding*, and the expertise is not a pose: they generally have done the work, and they are often right. Their reluctance to accept an easy answer is the competence of a cautious person, operating exactly as it should. In the psychic realm they are stepped back and *taking it in* whole — which is why, from inside, their detachment is not experienced as coldness at all. It is experienced as clarity, and from where they stand that is precisely what it is.

The pair yields a rare kind of honesty. Flattery, self-deception, and the small adjustments people make to keep a situation comfortable are all psychic-realm moves, made because something in that realm is pulling. Nothing is pulling the Five there, so the adjustments do not get made. Put that next to real understanding in the physical realm and the result is someone who will tell you what is the case, including when it is unwelcome and including about themselves. They are also the type most able to look at an emotional situation without standing inside it, which is why a Five is so often the person people bring a problem to when they want it seen rather than soothed.

The Five's intellectual life is easy to misread. Reasoning about how things work, what causes what, and what will hold under pressure is engagement with the physical realm, whatever it feels like from inside. All thinking happens inwardly, but what is being thought about is checkable, and it succeeds or fails by the rules of the physical realm. The Five's famous intellectuality is physical-realm caution.

And the Five is no more in the dark about it than the Four is. With no enthusiastic realm to take the foreground, the understanding stands in full view, and a Five will give a precise account of how they think and why they decline an easy answer. They call it objectivity, or independence of mind. That account is also correct, and also generously named.

When the psychic realm has to be handled, the Five imports the mode they have: understanding. So emotion gets studied rather than felt, and a precise description of a feeling comes to stand in for the feeling, which is a substitution the Five is unusually well equipped to make convincing.

The Five's pair is the Four's with the realms exchanged, and the same thing goes wrong in the opposite place. Taking a whole realm in at once is what a Five does in the psychic realm, and it is within reach in the physical realm too — which is where a Five's directness about physical things comes from, since working a thing out piece by piece does not give it. Judging that enough has been understood takes the whole at once, and understanding cannot assemble it. A Five who does not reach for it goes on understanding with nothing to say when to stop, and the studying runs unchecked — one more paper, one more system mapped, expertise deepened past any use it will be put to. The Four obsesses inwardly and the Five obsesses outwardly, and it is one structure seen twice.

A Five also carries a physical-realm rule into the psychic realm, where the rule does not hold. In the physical realm, food, time and strength run out with use, so guarding food, time and strength is sound. A Five treats feeling and involvement the same way, and rations both. In the psychic realm, feeling and involvement mostly grow with use. The self-sufficiency is real. The rationing also keeps a Five out of the involvement that would end the sense of being a spectator, so knowledge accumulates and the sense of being a spectator does not lift.

None of this is the whole of what a Five has from the pair.

Take the physical realm first, where a Five is cautious. A Five less caught in the physical realm can tell when enough has been understood. The drive for understanding stops when the use it was wanted for is met, so the expertise deepens without becoming its own object.

The psychic realm is different. A Five is detached in the psychic realm and takes the whole of the psychic realm in. A Five's cautious physical realm supplies motivation a Five can direct at the psychic realm, so a Five can look there. Much of what a Five notices in the psychic realm is whatever bears on the fears of the physical realm. A Five also may notice things in the psychic realm that no fear pulled their noticing toward, such as someone else's emotional situation. What a Five tends not to notice is what keeping involvement to a minimum is doing to a Five. A Five less caught in the psychic realm turns the supplied motivation on more of what is there, and then acts on what they notice. Feeling and involvement stop being rationed as though they would run out, and the sense of being a spectator lifts.

Whatever a Five's condition, the pair still gives them what it gives: they will tell you what is the case, and they can look at an emotional situation without standing inside it.

### Type 6 (HB;SB) — The Loyalist

**Physical: Cautious; Psychic: Cautious**

The Six is *understanding* in both realms, and the competence is formidable. They see the problem before it materializes, they think several steps out, and they are usually the reason a system does not fall over. Their loyalty is not sentimentality; it is the same competence applied to people, and they stay when others leave.

The Six sees this as clearly as the Four and the Five see theirs, and for the same reason: two cautious realms and no enthusiasm anywhere means nothing competes for the foreground. A Six will tell you plainly that they think ahead and prepare for what could go wrong, and they call it realism. It is realism, much of the time. A Six is looking all the time, in both realms at once. Every fear a Six has raised gets looked into, and the looking goes where the fears pull it. What a Six does not notice is anything no fear pulled their noticing toward.

Holding the same competence in both realms makes the Six the only type that models how a thing can fail and how the people around it can fail, at the same time. Most planning covers one or the other. The Six anticipates the technical breakdown and also who will panic, who will quietly stop cooperating, and how the announcement will be misread — and it is those together that actually sink things. The loyalty has the same double root. It is not a feeling they are having. It is a commitment made by someone who has already understood what it will ask of them, which is exactly why it holds when sentiment would not.

As with the Three, the same orientation in both realms means no internal contrast. What the Six therefore runs across both is a single threat logic.

In the physical realm the threat logic works and gets results. A worry there can be *closed* — you can go back and check that the door is locked, and once checked, it is checked. Vigilance produces a result and then stops.

In the psychic realm the same scanning is not neutral, because a Six's watching becomes part of what the Six is watching: watching for a danger is one of the things that produces the danger. Worry about worry compounds. Reassurance is gone as soon as it arrives. Psychic certainty cannot be verified the way a lock can, so a Six has to look for reassurance again. The anxiety the vigilance was meant to prevent is manufactured by the vigilance, which is why more of it never helps.

The error also runs the other way. The Six looks for *physical* safety by psychic means — trusting an authority, a system, a person, as though trust were a wall. Trust is real, and it does real work in the realm where it operates. It stops nothing physical.

Hence the doubt that undermines the security it was looking for, as well as the strings attached to a loyalty that is nonetheless genuine.

None of this is the whole of what a Six has from the pair.

Take the physical realm first, where a Six is cautious. A Six less caught in the physical realm can tell when enough has been checked. The lock checked once stays checked, and the scanning does not start again on ground already covered.

The psychic realm works the same way, because a Six is cautious there too, and this is where it matters more. In that realm a worry can be directed at its own results, so checking a worry produces another worry, and the checking has no natural end. A Six less caught in the psychic realm can let it end. The scanning is not turned back on what it has already found, so a worry there comes to a stop instead of compounding, and reassurance that arrives is allowed to stay.

Whatever a Six's condition, the pair still gives them what it gives: a problem seen before it materializes, an eye for who will panic and who will quietly stop cooperating, and a loyalty that holds where sentiment would give way.

### Type 7 (HA;SZ) — The Enthusiast

**Physical: Enthusiastic; Psychic: Detached**

In the physical realm the Seven is *doing*, and the energy is real: they say yes, they see the possibility, they make the unexpected connection, and rooms are measurably better for their arrival. In the psychic realm they are stepped back and *taking it in* whole — which is why the Seven's refusal to be defined by what is wrong is sincere. They are not lying about not being weighed down.

The combination produces something valuable and often misread: a person who can act while everyone else is still absorbing. In a bad moment most people are held for a while by what they feel, and the holding is not optional. The Seven is not held, because nothing in the psychic realm has hold of them, and they are fully engaged in the realm where something can actually be done. So they move first. The optimism is not naivety either. They take the bad thing in perfectly well, in the realm where taking in is their competence — it simply gets no grip, and what they offer other people is the demonstration that it need not.

When feeling has to be handled, the Seven brings the mode they have, which is doing. So emotion gets acted out rather than undergone: sadness turned into a plan, anxiety into motion, emptiness into the next arrangement. The activity is not a cover story laid over the feeling. It is what feeling looks like when the only available way to engage is to do something.

Then the two realms' rules come apart. In the physical realm, discomfort really is escaped by moving away from it — that is not avoidance, it is how the realm works, and a Seven's instinct there is sound. In the psychic realm there is no away. Whatever is fled comes along, because the traveler is the terrain, and motion only postpones the arrival. Stimulation is genuinely enjoyable and genuinely does not resolve anything.

An enthusiastic person's answer to a negative compounds it. The next positive replaces the blocked one, and in the physical realm that is often the right move. In the psychic realm the negative has not been dealt with or released. A Seven has only stopped noticing the negative, and the negative is still there.

What the Seven is actually after — satisfaction, the sense of enough — is a psychic-realm product, and no quantity of experience manufactures it.

The Seven's pair is the Two's with the realms exchanged, and one consequence carries straight across. Everything the Two is engaged in lives in the psychic realm, so the question of who they would be without the helping has no answer available to them. Everything the Seven is engaged in lives in the physical realm, so the question of who they would be without the doing has no answer either. Stop a Two from giving and stop a Seven from moving, and each arrives at the same undefended place from opposite directions.

None of this is the whole of what a Seven has from the pair.

Take the physical realm first, where a Seven is enthusiastic. A Seven less caught in the physical realm can stay with what has gone wrong long enough to understand it. Moving on becomes a choice rather than the only answer available, and what is fled is not fled indefinitely.

The psychic realm is different. A Seven is detached in the psychic realm and takes the whole of the psychic realm in. A Seven's enthusiastic physical realm supplies motivation a Seven can direct at the psychic realm. A Seven directs that motivation at whatever bears on what to do next. A Seven notices enough of a bad thing to move away. What the bad thing actually is goes unnoticed, because a Seven does not stay with the bad thing long enough. A Seven less caught in the psychic realm turns the supplied motivation on more of what is there, stays with a bad thing, and notices what the bad thing is. A feeling is undergone rather than turned into the next arrangement, and sadness gets felt rather than converted into a plan.

Whatever a Seven's condition, the pair still gives them what it gives: they act while everyone else is still held by what they feel, they see what has gone wrong without being weighed down by it, and they make the connection nobody expected.

### Type 8 (HB;SA) — The Challenger

**Physical: Cautious; Psychic: Enthusiastic**

Caution is alertness to threat, and its competence is understanding — how things work, where the weakness is, what will hold. In the physical realm the Eight understands force, position, and leverage better than almost anyone, and answers a threat by removing it before it arrives. Strength neutralizes threats; walls protect. Caution does not mean hanging back. It means the threat has been taken seriously, and here it is taken seriously by being ended early.

In the psychic realm the Eight is *doing*: wholehearted engagement with people. The loyalty is real, the appetite for actual contact is real, and so is the protectiveness toward those who cannot protect themselves.

The pair explains why the protector role is real rather than a flattering description of themselves. Understanding force and position is one thing, and caring wholeheartedly about people is another, and the two rarely occur together — those who grasp power mostly use it for themselves, and those who love people mostly do not grasp power. The Eight has the first in the physical realm and the second in the psychic, so the understanding gets put to use on somebody else's behalf. It is also why an Eight is worth having in a crisis. They have already worked out where the danger is, and they are already committed to the people standing in it.

The Eight's pair is the One's with the realms exchanged, and the structure the One showed runs here too. The One and the Eight are the only types carrying enthusiasm in one realm and caution in the other. They are also the only two types in which a person cannot see their own guarding. The Four, the Five and the Six each described their caution without difficulty. An Eight's focus is on the psychic realm, where the Eight is enthusiastic, so the Eight experiences themselves as being about people, truth, and loyalty. The physical realm runs as an automatic check, and an Eight's focus goes to the physical realm whenever an alarm is raised there. An Eight notices each particular threat that raised an alarm, and guards against it. Nothing raises an alarm about the guarding, so the fortification runs as ordinary good sense rather than as anything an Eight holds at all. A One never notices the guarding in the psychic realm, which is why a One cannot see their own anger. An Eight never notices the guarding in the physical realm, which is why an Eight cannot see their own guardedness.

And in both, the same blindness runs outward, into opposite territory. The One's enthusiasm is in the physical realm, so physical caution is what the One dismisses. The Eight's enthusiasm is in the psychic realm, so psychic caution is what the Eight dismisses: the person who needs to trust before opening, who will not be direct until they feel safe, is heard as weak. The low threshold for weakness in others that Eights are known for is this and nothing else. Neither type is intentionally judging the person in front of them badly. Each is looking at an orientation they have no way of reading from the realm their focus is on.

The principles that invade the Eight's psychic realm come from the physical realm, where the guarding runs. The Eight tries to *secure* loyalty by testing it, and to *protect* against betrayal by dominating the situation. These are physical-realm moves, correct in their own realm, and they cannot do this job — because connection requires openness, and the walls that keep a body safe keep a heart alone. The characteristic loneliness is a fortress working exactly as designed, in the wrong realm. Securing and protecting are physical-realm standards, and they cross into the psychic realm and fail there.

The gap between impact and intent has the same source. Directness is offered as respect — a psychic-realm gift, and meant as one — but it is delivered with the force suited to a threat. The force comes from the guarding in the physical realm. Directness delivered with that force lands as domination on people who were never a threat. The Eight is not misjudging the person. An Eight does not notice the force, because the force is part of the guarding, and an Eight never notices the guarding.

None of this is the whole of what an Eight has from the pair.

Take the physical realm first, where an Eight is cautious. That caution is the fortification, and it is what stays out of view, because the wholehearted engagement with people holds the foreground and the guarding is experienced as ordinary good sense. An Eight's looking is in the psychic realm, and the guarding is in the physical. It stays quiet because an Eight approaches everything already guarded, and so has nothing to compare it against. An Eight can still come to see it, and what usually starts that is a report from outside — someone saying the question was heard as a test, or that the directness landed as domination. Caught, an Eight dismisses that, because what they did was plainly reasonable. Less caught, an Eight can take the report as news about the guarding they approach everything with.

The psychic realm is different. That is where an Eight is enthusiastic. An Eight less caught in the psychic realm can take the time to understand a person before engaging them wholeheartedly. They can wait to know someone. And they can recognize a person who needs to feel safe before speaking plainly as doing exactly that, rather than hearing it as weakness.

Whatever an Eight's condition, the pair still gives them what it gives: they understand force and position, they engage wholeheartedly with people, and the understanding gets put to use on somebody else's behalf.

### Type 9 (HZ;SZ) — The Peacemaker

**Physical: Detached; Psychic: Detached**

A Nine can notice anything in either realm, and that competence is the least recognized in the Enneagram. While nothing disturbs a Nine, the whole of both realms stays open to their noticing. The ability to see every side of a dispute is not indecision; it is what a view looks like from a position with no stake in it. The steadiness others come to them for is real, and so is the absence of need to make things into a conflict.

A Nine's judgment is also sounder than people usually take it to be. Other people have a side in a dispute, because of what they want or fear. A Nine is detached in both realms and has no side. When a Nine finally does say what they think, the account tends to be the most accurate one in the room. The calming effect has the same source. It is not a technique and it is not politeness. Nothing in a Nine is escalating, and people settle near a Nine the way they settle near anything genuinely still.

The same orientation in both realms means, again, no internal contrast. So one move answers everything: step back.

Both of a Nine's realms are detached, so neither realm supplies them motivation. A Nine still raises wants and fears, as anyone does, but raises fewer of them. A fear arrives with its own object, so a Nine notices what a fear has been raised about and little else. When a fear arrives, a Nine may look at the fear and want to solve what is disturbing them. Or a Nine may simply want the fear to go away. A Nine can want to solve fears in the physical realm and want fears gone in the psychic, or the reverse.

In the physical realm, wanting a fear gone fails in the plainest possible way, because nothing in the physical realm is altered by being ignored. The leak spreads, the task waits, and the consequences arrive on schedule and unnoticed — which is the Nine's famous negligence. The accurate judgment and the negligence belong to the same person.

In the psychic realm, wanting a fear gone fails oppositely, and less visibly. Stepping back in the psychic realm does not produce peace; it produces a numb imitation of peace. The conflict is unfelt rather than resolved. A Nine's feeling about the conflict stays part of what the Nine feels, so a Nine still carries the conflict they withdrew from. Resentment gathers underneath without ever being met — which is the Nine's famous anger, asleep rather than absent, and the passive immovability that surfaces when they are pushed past their tolerance.

Where noticing a thing would take something from a Nine, the noticing may not happen at all, and that is not chosen. So the long, quiet subtraction of a self that has agreed with everyone and asked for nothing is precisely what cannot be noticed while it is happening.

None of this is the whole of what a Nine has from the pair.

Take the physical realm first, where a Nine is detached. A Nine less caught in the physical realm notices what is there, and can then want something and act on what they want. The appetite returns with the accuracy still there. The leak gets attended to and the task gets done, and what needed doing was judged accurately before it was taken up.

The psychic realm works the same way, because a Nine is detached there too. A Nine less caught in the psychic realm notices a conflict and can then enter it. The disagreement gets had, and what a Nine wants for themselves gets said while it still matters, rather than gathering underneath as resentment.

What a Nine wants is peace — to be left undisturbed. Wanting peace makes a Nine forget two things a cautious person knows. A trouble left alone keeps its consequences. A Nine who does not enter a conflict still carries it. Being less caught means holding to peace less rigidly, and a Nine willing to give up some peace can look at what they would rather not see. That is what better functioning amounts to here. Not that the wanting is gone, but that the willingness to be uncomfortable is back.

A deeply caught Nine judges soundly because they have no side in what they are looking at. A less caught Nine acts on what they want, and so has stakes, and judges soundly because they can see what the wanting is doing to their view.

Whatever a Nine's condition, the pair still gives them what it gives: a view of a dispute that comes out straight, and a stillness that other people settle near.

### In Short

Nine pairs, nine types. If the nine pairs are the nine types, each type's recognizable qualities come from the two orientations a person holds, one in each realm — the competence each orientation carries, and what happens when the principles of one realm are carried into the other, where they do not hold.

---

# Part 2 — The Finer Structure

## Chapter 6: The Grid

The two realms and the three orientations can be set out as a table. Put the physical realm across the top and the psychic realm down the side, three columns and three rows, taking the orientations in the order they were given — enthusiastic, cautious, detached. Every cell is then one pairing: one orientation in the physical realm and one in the psychic.

![The two-realm grid: each type is one orientation per realm. The diagonal (3, 6, 9) holds the aligned types.](two-realm-grid.svg)

|  | **HA** enthusiastic | **HB** cautious | **HZ** detached |
|---|---|---|---|
| **SA** enthusiastic | **3** HA;SA | **8** HB;SA | **2** HZ;SA |
| **SB** cautious | **1** HA;SB | **6** HB;SB | **4** HZ;SB |
| **SZ** detached | **7** HA;SZ | **5** HB;SZ | **9** HZ;SZ |

Three orientations in two realms give nine pairs, associated with the nine types.

Along the diagonal, from the top left corner to the bottom right, are 3, 6 and 9. These are the types holding the same orientation in both realms — enthusiastic in both, cautious in both, detached in both. They can be called the **aligned** types. A person with the same orientation on both sides seems to have only ever noticed one way. A mixed type has watched themselves notice in two different ways. An aligned person takes their own way of noticing to be how things are. So one set of rules gets carried across both.

The other six — 1, 2, 4, 5, 7 and 8 — fill the cells off the diagonal. Their two realms differ. These are the **mixed** types.

Those two groups will look familiar to anyone who already knows the classical Enneagram. The three aligned types are the ones its figure draws as a triangle. The six mixed types are the ones joined by the six-sided shape inside it, the hexad.

Two cells in the same row share a psychic orientation and differ in the physical one; two in the same column share the physical and differ in the psychic. So a step across, or a step up or down, changes one realm and not the other, and a step along a diagonal changes both at once.

Three times, one type turned out to be another with its realms exchanged: the Seven is the Two that way round, the Five is the Four, the Eight is the One. Folding the table along its diagonal exchanges the realms. Fold it, and the Two lands on the Seven, the Four on the Five, the One on the Eight; 3, 6 and 9 do not move, because they lie on the fold itself. There are three such pairs and no more: three cells lie on the fold, and the other six exchange in pairs.

The rest of the book uses the grid constantly.

The rows and columns run enthusiastic, cautious, detached because that is the order the orientations were introduced in, and nothing so far has depended on that — the grid would be the same grid in any order. The order is not arbitrary. Until the reason for it is given, a step from one cell to its neighbor is only a step, with no direction to it.

---

## Chapter 7: The Cycle

There is an order among the three orientations.

Enthusiasm ends where limits and consequences are met, and caution begins there. Caution ends in understanding, and detachment begins where the need to control is released. Detachment, left unwatched, ends in easy wanting, and enthusiasm begins there again. Follow that around and it closes on itself: A to B to Z and back to A. Each orientation is a position on the cycle, and the next one lies just past the end of the one before it.

**This is a statement about directions, not about motion.** A person's orientation in a realm does not ordinarily change. It is a habit set down early and held so long that it is simply where they live. The cycle is about which way the pull goes when circumstances pull: toward the next orientation, or back toward the one before.

The classical Enneagram describes which way a person is pulled in growth and under stress, and calls the two directions **integration** and **disintegration**. The two directions correspond to the order: integration goes with the order, and disintegration goes against the order. Integration is the direction natural experience leads as a person meets the drawbacks of the orientation they hold. Disintegration is the direction competence comes apart in when stress disturbs a person's ability to focus.

Because a type is a pair of orientations, one for each realm, the order predicts the classical directions for each of the nine types. The classical Enneagram joins the nine types with lines and gives each line a direction of growth and a direction of stress. On every line, the type a person is pulled toward in growth is one step forward along the order, in one realm or in both. The type a person is pulled toward under stress is one step back, in one realm or in both. The classical Enneagram gives no reason for its lines, and the order supplies one.

### Forward

**A to B.** Experience teaches that things do go wrong. Disappointments accumulate. The person begins to understand that grasping the risks, and staying alert to them, is what actually gets them what they want. So they tend toward caution — but caution requires deferring pleasure and accepting disappointment, and an enthusiastic person habitually resists both.

**B to Z.** Then they discover that despite real effort and real understanding, things still fail in ways nobody saw coming. Too many uncertain factors bear on any outcome, and unexpected consequences are a certainty. They come to see that they cannot in fact control what happens, and they tend toward detachment — but detachment requires releasing the need to control and accepting that no amount of understanding will keep them safe, and a cautious person habitually resists both. Because they arrive by way of understanding, they enter detachment at its caution end.

**Z to A.** As detachment becomes complete it has no object of its own, and sooner or later something draws the person back into wanting. Done well this is a release into action: appetite returns with the seeing and the detachment still intact. But the fear arriving meets the want for peace, and the discomfort a fear leaves behind is exactly the disturbance a detached person stepped back to be free of. That is why this is the passage they resist.

In the case of each orientation, what the step requires is what such a person habitually resists. That is why the forward direction says what has to be true before a person takes a step, and not when they will take it. The less caught a person is in the orientation they hold, the more of what the step requires they can bear.

### Backward

**A to Z.** Repeated disappointment, or one catastrophe, defeats the optimism. Caution would be the forward answer, but stress prevents it, and the person collapses inward instead — discouraged, withdrawn, giving up. The detachment they land in is not the release the forward direction brings. It is shutdown: numbness in place of anything worked through. The wanting does not vanish; it survives as carelessness, ease still taken where it demands nothing and hazards simply no longer looked at.

**Z to B.** The resistance breaks down and the person can no longer stay disconnected. What surfaces is not energetic re-engagement but fear. They move toward caution — but as anxiety: worry without the accompanying sense that understanding will help.

**B to A.** Vigilance exhausts them, or constant worry fails to prevent the bad things anyway. Stress blocks the effort of maintaining caution, and they fail not by releasing control but by panicking into recklessness — a brittle energy rather than any real optimism.

### The two faces of detachment

There are therefore two faces of detachment.

A person still raises fears about matters in a realm where the person is detached. What differs between the two faces of detachment is what happens to the fear. At the caution end, the person looks at the fear and wants to solve what is disturbing them. Nearer the enthusiasm end, the person simply wants the fear to go away, and turns away from the fear. When a fear has grown to be more than the person can bear, the person panics at the caution end. Panic raises a want to be rid of the fear, and the want carries the person to the enthusiasm end, where the fear is no longer noticed. The person then cannot say what the fear was about.

Detachment is the only one of the three orientations that runs to both.

### What kind of thing this is

Every individual process — a thought, a project, an interaction, a relationship — runs its own arc. Processes come in sizes: a thought takes a second, an undertaking takes months, a character takes a life. The size of a process is its scale. Whether a whole arc ever completes depends on the scale. Two of these matter most: the **thought arc**, and the **endeavor arc** of a bounded undertaking.

At the scale of **character**, usually none completes. The orientation a person holds is home, and what varies is the lean — which way they are pulled from it, and how far. That is a change of position, not a passage run.

At the scale of a **bounded undertaking** — a project, a passion, a job — the whole endeavor arc is sometimes genuinely lived: eager beginning, chastened middle, ripened letting-go. Complete arcs like this run in the forward direction.

At the scale of a **single thought**, a thought arc completes in fractions of a second and another begins, many times a minute.

A process arc has no exact beginning or end. What marks a process arc is that nearly the same want keeps being raised.

### The smallest scale

A thought is best described by the passages the thought makes. A thought passes through three phases, which are the same three places on the cycle as the three orientations. A passage is the move from one phase to the next. The arising takes a process from the detached phase to the enthusiastic phase. The development takes a process from the enthusiastic phase to the cautious phase. The ending takes a process from the cautious phase to the detached phase. A completed thought makes all three passages in the forward order. So describing a thought means saying what happens at each of the thought's passages: something arises, the person works it over, and the thought ends.

When one thought ends the next arises conditioned by it, so the thought arc closes into a cycle. At this scale the cycle is not an analogy. It is a fact, completing many times an hour, in everyone — the one claim in this book you can check in the next sixty seconds.

Everyone's thoughts make all three passages; what varies is what those thoughts are about.

---

## Chapter 8: Relational Positions

The relational material is derived from the model and from watching how these pairings actually go. It is practical advice rather than a further part of the account, and it holds only so far as those two do.

Take any two people and compare them realm by realm. In the physical realm their two orientations either sit at the same place on the cycle or one is a step ahead of the other. The psychic realm gives a second comparison, made the same way. Those two answers together sort every possible pair of types into one of six positions.

Ahead here is a position on a circle, not a rank. The circle comes from the order of the orientations.

Ahead means one step in the direction of integration, behind one step the other way. Since the cycle closes, cautious is ahead of enthusiastic, detached is ahead of cautious, and enthusiastic is ahead of detached. Each of the three has another ahead of it. There is no top.

| In one realm | In the other | Position |
|---|---|---|
| ahead | ahead | **Double Ahead** |
| ahead | level | **Ahead** |
| ahead | behind | **Equal** |
| behind | level | **Behind** |
| behind | behind | **Double Behind** |
| level | level | **Identical** |

Equal has its name because neither person is ahead overall: what one gains in the physical realm they give back in the psychic. Identical is the same type twice.

A double position is one step in each realm and never two steps in one, because two steps in a single realm come out as one step the other way. The map is symmetric: where one person is Double Ahead of another, that person is Double Behind of them, and Equal and Identical are their own mirrors.

Reading a position off the grid takes two comparisons. The Five is cautious in the physical realm and detached in the psychic; the Nine is detached in both. Physically, cautious to detached is one forward step, so the Five is behind; psychically the two are level. The Five is Behind the Nine. Set the Five against the One instead — enthusiastic physically, cautious psychically — and the Five is one step ahead in both realms, so the Five is Double Ahead of the One.

The distribution is the same for every type. Of the eight others, one is Double Ahead, two are Ahead, two are Equal, two are Behind, and one is Double Behind.

Maya is a Two, detached in the physical realm and enthusiastic in the psychic. Her husband Daniel is a Five, cautious in the physical realm and detached in the psychic. Physically, Maya's detachment is one step ahead of Daniel's caution. Psychically, her enthusiasm is one step ahead of his detachment, by the same wraparound that closes the cycle. Maya is Double Ahead of Daniel, and Daniel Double Behind of Maya.

The three aligned types reach one another only through the double positions. The Three is Double Ahead of the Nine, the Nine of the Six, and the Six of the Three, each by one step in each realm. The classical system has these same three relations and no name for the double step, calling them ahead and behind like any others.

---

## Chapter 9: Relational Dynamics

A position is a fact about two types. What it is like from inside is a different matter — who looks up to whom, where the irritation comes from, and what each person has that the other needs.

Underneath all of it is one observation. In a given realm, a person is energized by someone whose orientation sits one step ahead of their own and burdened by someone one step behind.

In any real relationship, being a step ahead or a step behind is one factor among many. It may matter a great deal between two people and hardly at all between two others. Not all people experience being energized as desirable, and being burdened as undesirable.

### What passes between them

In every position except Equal and Identical, there seems to be an unevenness in perceived capability. The person ahead in a realm experiences the other as lacking something they themselves have and have already moved past. The person behind experiences the other as having something they lack and want, and reads them as stronger, more capable, further along in that realm.

Two things pass between them and they are easily confused. Appreciation is a valuing of what the other delivers: the ahead person's for the other's willingness to handle what they themselves find less interesting, the behind person's for the guidance and the example. It runs in both directions. Looking up runs in one only — the person behind sees the other as further along, and no matching perception comes back, because in that direction there is nothing further along to see.

Neither of these is respect in the ordinary sense: treating another as a person whose feelings and standing are not in question. That is not positional. It runs in no direction, and between healthy people it is simply mutual, whoever is ahead of whom. Holding it apart from the other two is what keeps an accurate reading of position from curdling into awe on one side and condescension on the other. Looking up says where someone stands on a circle. It says nothing about what they are worth.

Appreciation and looking up do not convert into each other either. Being valued for what one produces is not the same as being looked to, and being looked to is not the same as having one's work valued.

The three aligned types show the circle plainly. The Six is ahead of the Three, the Nine is ahead of the Six, and the Three is ahead of the Nine. All three statements are true at once. On a ladder that would be nonsense; on a circle it is geography.

This is checkable, and it is where the account differs sharply from most descriptions of human development, which assume that someone further along than a second person, who is further along than a third, must be further along than the third. Here three people can each sincerely, and correctly, see the next one as further along, all the way around the circle. What would count is a closed circle of three: each of the three reporting that they look to the next, and the third reporting that they look to the first.

### Position by position

**Ahead and behind, single or double.** These name relative positions on the cycle, not amounts of progress. The one behind looks up to the one ahead and values the guidance and the example; the one ahead values the other's willingness to handle what they themselves would rather not. This is the position with the clearest structure — a natural division of labor, real mentorship, room to grow — and also the one most prone to going wrong. Unappreciated, the ahead person turns impatient or dismissive, and the behind person comes to resent being cast as the lesser. What decides which way it goes is whether the division is named and valued out loud. The person behind is never lesser, only easier to overlook. Double positions carry the same dynamic across both realms at once, and the wider separation often softens the sense of better and worse: two people that far apart read each other less as versions of one thing and more as genuinely complementary.

**Equal.** Neither person is subordinate overall. Each is ahead where the other is behind, so each has something real to teach and something real to learn. These relationships tend to be the easiest of all — no gradient to manage, no competition, each strong where the other is weak.

**Identical.** Two people who speak the same language, share the same assumptions, and never have to explain themselves. The trouble is the echo: little the other does not already have, the same blind spots doubled, and the standing risk that neither ever challenges the other. Identical pairs do best by looking for their diversity elsewhere.

One rule holds across all three. A position is a liability only when it goes unrecognized. Named and understood, ahead and behind becomes mentorship rather than hierarchy, equal becomes acknowledged complementarity, and identical prompts a deliberate search for what the pair lacks. Left unnamed, the same positions curdle — into resentment, into competition, into staleness.

### Equal positions, and the mirror pairs

Being ahead in one realm and behind in the other puts the nine types into three groups of three, each holding one aligned type and two mixed types, everyone within a group Equal to everyone else: the Three with the Four and the Five, the Six with the Two and the Seven, the Nine with the One and the Eight.

The two mixed types in each group are a mirror pair — the same two orientations, one realm each way round. A mirror pair understands each other deeply while being fundamentally different, since each meets their own two orientations in the other realm. Between them they hold two orientations twice over and the third not at all, so neither has much familiarity with it, and neither has much familiarity with the aligned types.

### In everyday life

Four sketches, and the same handful of people recur, because real lives contain several positions at once.

**Maya and Daniel — Double Ahead and Double Behind.** In both realms Maya inhabits the orientation Daniel is growing toward. Daniel would tell you, matter-of-factly, that Maya is better at life than he is: she moves easily where he weighs out every effort, and she long ago set down the guardedness he still calls realism. He studies her with genuine admiration and assumes he could never do what she does. Maya does not experience herself as ahead of anyone, but Daniel's carefulness feels familiar to her, like a country she once lived in, and her guidance comes out sounding like *it's really not as bad as you think.* The shadow side arrives on bad days: Daniel can feel permanently junior in his own marriage, and Maya can mistake his position for his worth, forgetting that her husband's psychic detachment takes the whole realm in, and she relies on that more than she notices.

**Marcus and Daniel — Ahead and Behind.** Marcus is an Eight, and he and Daniel work at the same engineering firm. In the physical realm they are level: two habitually careful minds who respect each other's rigor and never have to justify a safety margin to one another. The difference is confined to the psychic realm, where Marcus is a step ahead — his emotional life is engaged, immediate and out loud, while Daniel's is something he mostly observes through glass. Daniel finds Marcus a little loud and entirely magnetic; when something needs saying in a meeting with force behind it, he routes it through Marcus. Marcus is oddly protective of Daniel in return, and appreciates that Daniel gladly does the solitary analytical work Marcus finds airless. Because they differ in exactly one place, the relationship is legible to both of them: each knows precisely what the other has that he lacks.

**Elena and Marcus — Equal, and mirrors.** Elena is a One, and she and Marcus co-own the firm. Everyone assumes two such forceful people must collide. Instead the partnership works, and their position is the reason: each is ahead in exactly one realm. Marcus is ahead in the physical, where his caution tempers Elena's build-it-now enthusiasm with *what's our downside?* Elena is ahead in the psychic, where her inner discipline tempers Marcus's emotional broadsides with *what are we actually trying to say?* Neither is subordinate; each privately rates the other an equal, a status both extend to very few. They are also mirrors, the same two orientations distributed oppositely, so each recognizes the other from the inside while being fluent exactly where the other is effortful. They share the mirror pair's blind spot too: between them they hold enthusiasm and caution twice over and detachment not at all, so when either meets genuine stillness in someone, both read it as something being wrong.

**Priya and Tom — Identical.** Both are Sixes, and they met on the school safety committee, which is a joke they make about themselves. The friendship is effortless: each has found the one person who never needs the worrying explained. Plans are checked twice and nothing is left to luck, and both feel, correctly, deeply understood. The trouble is the echo. When Priya brings Tom a worry he does not weigh it, he adds to it, and two vigilances pointed at the same object confirm each other. The best gift each could give the other is the one thing neither naturally supplies: the voice that says *this one is not worth watching.*

### Aligned and mixed

Two aligned types together have each only ever noticed in one way. They do not discount either realm or argue over which one is real. Each takes their own way of noticing to be how things are, so each finds their own orientation harder to see as an orientation.

Two mixed types together both live with an internal division between the realms. They may or may not take both realms to be real, and may or may not be comfortable with the reality the other sees. But each has watched themselves notice in two different ways, which an aligned type never has. So each can see an orientation as an orientation more easily than an aligned type can.

An aligned type with a mixed type is the widest difference of the three. One brings coherence and a unified view, the other an awareness of complexity and of the tension between the realms. This can be enriching and difficult in the same measure.

### Friction from the detached realm

Everything above comes from where two people's orientations sit on the cycle. A second source of friction comes from the realms themselves. A person detached in a realm tends to be unaware of that realm and to undervalue it, and so to undervalue another person's competence in it, dismissing as trivial or misguided the very thing the other does well. Where two people are detached in opposite realms, each can insist on false ideas in the realm the other understands. This friction is independent of relational position, and it can sharpen or soften any of the dynamics above.

Maya and Daniel show both mechanisms at once. Maya is detached in the physical realm and Daniel in the psychic. So Daniel privately regards much of what Maya does all day — the tending of feelings, hers and everyone's — as noise management, and Maya privately regards Daniel's systems and provisioning as a fussy hobby that mistakes itself for life. Each undervalues exactly the realm where the other's competence lives. On good days this is a running joke between them; under strain it hardens, each briefly certain the other is giving their life to what does not matter. None of it has anything to do with Maya being Double Ahead, which is what made Daniel admire her. Position and realm friction are separate mechanisms, and in this marriage they pull in opposite directions.

### Diversity

Two people who cover all three orientations between them differ more widely than two who cover two, and an aligned type with a mixed type differs more widely than two of a kind. Difference of that sort favors expansion, growth and dynamism; sameness favors comfort, focus and depth, and complacency along with them. How many of the three orientations a pair covers between them follows from their two types.

---

## Chapter 10: The Figure's Own Lines

The classical Enneagram draws two shapes inside its circle: a triangle joining 3, 6 and 9, and a six-pointed figure joining the other six. Arrows run along both, marking the directions a person is said to move under growth and under stress. Which type connects to which is simply given. No reason has ever been offered for that particular order.

Both shapes fall out of the grid.

### The types ahead

Integration is the forward direction around the cycle of orientations, and one step forward in a realm is what ahead means. The types a person integrates toward are therefore the types ahead of them.

Every type has three types ahead of it. Two lie a single step ahead, each one place further round the cycle in one realm only. One lies a double step ahead, one place further round in both realms. A step ahead is a relation between two types. A step ahead is not a move a person makes.

The Nine is detached in both realms. The orientation one place ahead of detachment is enthusiasm. So the type a single step ahead of the Nine in the physical realm is the Seven, and the type a single step ahead in the psychic realm is the Two. The type a double step ahead is the Three, who is enthusiastic in both realms. So a Nine integrates toward the Seven or the Two by a single step, and toward the Three by a double one.

### Why the two shapes close

Take the aligned types first. A single step in one realm leaves the other where it was, so it breaks the alignment; only the double step preserves it. The three aligned types reach one another by exactly that step, each one double ahead of the next, and the path through the three comes back to where it started. That closed path corresponds to the classical triangle.

The mixed types hold two different orientations, and there the single step does the work. Advance one realm and one of two things happens: either the advancing realm arrives where the other already stands, and the type becomes aligned, or it does not, and the type stays mixed. With three orientations and the two realms already differing, exactly one of them is the realm that would arrive. So of the two types a single step ahead of any mixed type, one sits on the diagonal and one does not.

Follow the one that does not. The One is enthusiastic physically and cautious psychically; advancing the physical realm would make it cautious in both, so it is the psychic realm that steps, from caution to detachment, and the One arrives at the Seven. Now the realm that has just moved is the one that would arrive if it moved again — the Seven's psychic orientation is detachment, which is one step from enthusiasm, and enthusiasm is already the Seven's physical orientation. So the other realm takes the next step. The two realms alternate, strictly, and never advance twice in a row.

![The hexad as a chain of single steps: 1, 7, 5, 8, 2, 4 and back to 1, each arrow colored by which realm advances — teal for the physical, purple for the psychic — alternating strictly.](hexad-cycle.svg)

Each step advances one realm by one place on a cycle of three, and the realms take turns. After six steps each realm has gone once around its own cycle and every type is back where it began: 1, 7, 5, 8, 2, 4, and back to the One. Six is not a number chosen to fit. It is what the alternation forces, and the order of the six is forced with it.

![Integration in the two families, side by side: the triad's every step advances both realms at once — paired arrows — while the hexad advances one realm at a time, alternating.](triad-hexad-cycles.svg)

Those two closed paths correspond to the two shapes the classical figure draws, and they were arrived at from three orientations in two realms with nothing borrowed from the figure itself.

![The classical nine-pointed figure redrawn: the hexad as a hexagon of the six mixed types with the aligned triangle inside, and dashed lines for the twelve single-ahead relations that cross between the two groups.](enneagram-hexagon.svg)

### The relations the figure does not draw

Every type has two types a single step ahead of it, so there are eighteen single-ahead relations among the nine. Six run between mixed types. Those are the hexad, and the figure draws them. The other twelve cross between the mixed types and the diagonal — each mixed type has one aligned type a step ahead of it, and each aligned type has two mixed types a step ahead of it. They are the dashed lines above, and the classical figure draws none of them.

A crossing relation is the same move as a hexad step: one realm advancing a single place, the other held. It differs only in where it lands.

Position was given earlier as a fact about two people, something felt from one side or the other. A relation running forward is also the direction along which one of the two stands to the other as the next orientation stands to the one before it. Nothing about a person changes type; the pair a person holds is what they are. What the types ahead mark is where that person's own two orientations hold them fast, and as that grip loosens they come to resemble those types more closely. That is what the classical arrows have always described.

If that is what an arrow reports, then it should hold wherever the relation holds. A One has the Six a single step ahead in the physical realm as surely as the Seven a single step ahead in the psychic, and integrates toward the one as toward the other. A Six has the Four and the Five ahead as well as the Nine. The classical system cannot say this, having no relation at all between a type and the diagonal. It is set down here to be tested. It accords with observation, and observation is not yet evidence.

### As the grip loosens

Being less caught in a realm means holding the orientation in that realm less strongly. Becoming less caught shows up the same way in either realm.

The orientation a person holds in a realm has a center. A person who is deeply caught stays at the center, because a deeply caught person cannot easily move off the center.

Health makes the center easier to leave. A person who can leave the center is found a little behind the center at some times, and a little ahead of the center at others. Such a person moves either way, as the matter at hand calls for. A person who can leave the center goes ahead of the center more often than behind it, because ahead is the direction of the step. Being less caught does not move the center. What being less caught changes is how easily a person leaves the center and returns.

Ahead of the center, some of the orientation ahead is available. The orientation ahead, paired with the orientation the person holds in their other realm, gives the type ahead in the realm where the person is less caught. So a person becoming less caught comes to resemble the type ahead, while still holding the same two orientations.

A One less caught in the physical realm can weigh how hard a thing will actually be before deciding what ought to be done about it. The type ahead of a One in that realm is the Six. A One less caught in the psychic realm can take a report about their own standards as news rather than dismissing it. The type ahead there is the Seven.

A Two less caught in the physical realm notices what is there, and can then act on what a situation requires. The type ahead of a Two in that realm is the Three. A Two less caught in the psychic realm can notice how worn down the giving leaves them, rather than moving on to the next person who needs something. The type ahead there is the Four.

A Four less caught in the physical realm notices the demands of physical life, and can then take them up. The type ahead of a Four in that realm is the One. A Four less caught in the psychic realm can let the analysis come to an end. The type ahead there is the Nine.

A Five less caught in the physical realm can tell when enough has been understood. The type ahead of a Five in that realm is the Nine. A Five less caught in the psychic realm can stop rationing feeling and involvement as though feeling and involvement would run out. The type ahead there is the Eight.

A Seven less caught in the physical realm can stay with what has gone wrong long enough to understand it. The type ahead of a Seven in that realm is the Five. A Seven less caught in the psychic realm can undergo a feeling rather than turn it into the next arrangement. The type ahead there is the Three.

An Eight less caught in the physical realm can take a report that the directness landed as domination as news rather than dismissing it. The type ahead of an Eight in that realm is the Two. An Eight less caught in the psychic realm can take the time to understand a person before engaging them wholeheartedly. The type ahead there is the Six.

### Reading it from either end

Disintegration is the same lines read backward. Behind replaces ahead throughout, each realm pulled toward the orientation behind it rather than the one ahead, and the two shapes close in the reverse order. The classical figure marks both directions on the same lines, for the same reason.

The correspondence can be read from either end. Taken with the classical figure as primary, the two-realm model recovers its two cycles, and their order, out of five elements — two realms and three orientations — none of which came from the figure. Taken with the model as primary, the hexad that the older system asserts is what a single forward step looks like when the realms take turns, and the triangle is what it looks like when they move together.

---

## Chapter 11: Leans, and the Classical Wings

Nobody holds an orientation purely. A person cautious in the physical realm is usually cautious shaded toward detachment, or shaded toward enthusiasm, and the shading is a matter of degree rather than a second category. A person may lean in one realm, in both, or in neither. A lean never changes the type; it shades it. A Six leaning hard toward Four is still a Six.

Each orientation can be written with three positions: a backward lean toward the previous orientation, marked −; the pure position, marked 0; and a forward lean toward the next, marked +. For enthusiasm this gives A−, A0 and A+, and the same for the other two. These positions are instances of the orientation they belong to. B− is a way of being cautious, not a fourth thing standing beside caution.

### The eight wings

The classical Enneagram records leans too, and calls them wings — but allows each type only two, toward the neighboring numbers, so that a Five may lean toward Four or toward Six and nowhere else. Read as leans in two realms, there are eight.

Take the Six, HB;SB. Each realm may lean forward, backward, or not at all, and the two realms are independent, so the combinations run:

| Lean | Lands on | Wing |
|---|---|---|
| HB+ | HZ;SB | 4 |
| SB+ | HB;SZ | 5 |
| HB+ and SB+ | HZ;SZ | 9 |
| HB− | HA;SB | 1 |
| SB− | HB;SA | 8 |
| HB− and SB− | HA;SA | 3 |
| HB+ and SB− | HZ;SA | 2 |
| HB− and SB+ | HA;SZ | 7 |

Eight neighbors, not two. Types carrying a wing the classical system does not allow can be called extended Enneatypes.

The strength of a lean and its direction are separate questions, and the strength in one realm says nothing about the strength in the other. A Six at HB0;SB0 is pure. At HB+;SB0 the physical realm leans toward detachment while the psychic stays where it is — a Six with a Four wing in practical matters and no wing at all inwardly.

### Reading a person either way

A lean stated in orientations and a wing stated in type numbers are two descriptions of one movement, so either gives the other. Someone at home with the orientations can work from the shading directly; someone at home with the classical descriptions can work from the wing. Both arrive at the same place.

Read the same person both ways and each reading checks the other. Where they agree, the reading is firmer than either alone. Where they disagree, one of two things is true: either one of the readings is wrong, or the lean runs toward a type the classical system does not permit — which is the one case its vocabulary has no way to report.

### Where the two systems disagree

Two wings per type against eight, and both cannot be right. The rules overlap rather than conflict everywhere: every wing the classical system permits is among the eight. What is asserted here is that the wings it forbids are real.

The existing observations give slight support to both and settle nothing. They do confirm that many people show a stable lean toward another type, which both accounts predict. But nearly all of them were gathered through tests and teachings offering only the two adjacent wings, so a lean toward any other type had no way of being recorded. The evidence fits the classical rule in large part because it was gathered with the classical ruler.

### Fractional leans

A lean has a strength, and the strength can be written as a fraction: HB+0.2 is a fifth of the way from caution toward detachment. The fraction runs only as far as a half, because past halfway the other orientation is the nearer one and the position takes its name from that side instead — what would be HB+0.7 is written HZ−0.3. A position is named from the orientation it is closest to.

When the two realms carry leans of different strengths, the resulting wing does not land squarely on a single type number, and falls partly between two of them.

### Opposite

Six positional relationships have already been set out — Double Ahead, Ahead, Equal, Behind, Double Behind and Identical. There is a seventh arrangement that belongs to none of them.

Exact opposition is something pure orientations can never reach. Enthusiasm, caution and detachment stand a third of the circle apart, so no two of them are diametrically opposed. Only a fractional lean, sitting between two orientations, can land exactly opposite another — which is why this relation, alone among them, needs fractional leans to be stated exactly.

![In each realm the two positions sit diametrically opposite on the orientation circle, shown for a 4 with a 5 wing (HZ−;SB+) and a 3 with a 5 wing (HA+;SA−).](opposite-relationship.svg)

Opposition can arise between any two people who differ in both realms, whatever class they otherwise stand in, provided the lean in each realm lands diametrically across. What every opposite pair shares is a symmetry: at half a circle neither is ahead of the other, since each is equally far forward and equally far back in both realms.

That symmetry matters for the asymmetry set out earlier. Equal and Identical were the two arrangements in which neither person holds the forward position, and opposite is a third — balanced not because opposition is a kind of equality, but because the symmetry cancels the ahead and behind of whatever class it arises from.

### The lean in detachment is not like the others

The eight combinations are read the same way whichever orientation a person rests at, and for enthusiasm and caution that is right: a lean shades the orientation without altering what it does. A lean in detachment alters what it does. Leaning back toward caution, detachment keeps the realm in view. Leaning forward toward enthusiasm, detachment has already turned toward what attracts, and anything that would disturb the attraction is not noticed. Which face appears is set by the direction of the lean.

The two are not conditions with a boundary between them. They are one range with two directions, and what varies along it is how much of a realm a person knows.

A Nine is the one type detached in both realms, so a Nine is the one person whose two leans in detachment can run opposite ways. A Nine leaning toward caution in the physical realm and toward enthusiasm in the psychic attends to what needs doing, and does not notice the resentment gathering underneath. A Nine leaning toward enthusiasm in the physical realm and toward caution in the psychic lets the leak go unnoticed, and notices a conflict clearly enough to enter it.

### What the leans do with what a person notices

What becomes of whatever a person would rather not look at also depends on the lean. A person can notice something and then decline to look at it any further. Or the noticing can be stopped, without the person having decided anything. Or, where the noticing has been stopped, there is nothing left to decline. A person leaning toward caution is more likely to notice and decline. A person leaning toward enthusiasm is more likely to have the noticing stopped.

---

# Part 3 — The Depth of Fixation

In each realm one of the three orientations settles and hardens into habit. A hardened orientation is what this book calls a **fixation**. A person holds one fixation in each realm.

This is what Parts 1 and 2 have been describing throughout. A realm was called detached, or enthusiastic, or cautious, and what that named was the fixation a person holds in the realm. A person was called more or less caught, and what varied was how strongly a person holds the fixation.

Readers who know the classical Enneagram will have met the word there. Oscar Ichazo set nine ego fixations on the figure, and Claudio Naranjo developed them into the enneatypes in use today. The claim in both is that a type is a fixation. This book keeps that claim. What this book adds is that a person holds two fixations, one in each realm, and that the nine types are the nine ways two fixations can be paired.

The word carries a judgment, and the judgment is meant. To call a habit a fixation is to say that the alternatives are gone. A person cautious in a realm does not choose caution over enthusiasm when something happens there; caution is what they have, and enthusiasm and detachment are not available to them.

Every orientation comes with something a person cannot easily bear, and detachment does too. A detached person minds being disturbed, even a detached person with no lean either way. So detachment is not the absence of caring. A person who has given up all attraction and all aversion would mind nothing at all. Buddhism calls such a person an arhat. An arhat is not the same as a detached person with no lean.

Parts 1 and 2 described the orientations, the nine types they make, and how people of different types meet one another. None of that needed the word fixation.

Every thought a person has runs through three phases. In each realm, a person's attention is usually concentrated at one of the three phases. Where the attention is concentrated shows the person's fixation in that realm. So the characteristics of each fixation, and so of each type, show in how the fixation runs a thought.

People also differ in how deeply they are caught in their fixations. Riso and Hudson's Levels of Development serve as a measure of that depth. What moves a person down or up the Levels happens where a thought finishes. A person falls when a fear is turned away from there, and rises when a fear that was blocked is faced there.

## Chapter 13: Where the Inner World Came From

### A part of the world that contains the rest

The physical realm does not refer to itself. A falling stone holds no picture of falling stones; the weather contains no forecast. Physical processes run, and running is all they do.

That changed when animals developed brains.

A nervous system joining what senses to what moves kept an animal alive better than none. Sensing at a distance came after it, and later still the ability to hold what happened before and act on it now. Past a certain point what a brain does is carry a picture of its surroundings — where the water is, where the ground drops away, what happened here last time — and act on the picture rather than only on what is in front of it. The picture is itself a physical arrangement, describable in the language of neurons and nothing else. Nothing was added to the world.

Something new was there all the same. A part of the world now contained a version of the rest of it.

### The turn inward

Then the pressure that mattered stopped being the terrain. For an animal living among others of its kind, and for anything hunted by something clever, the most important features of the surroundings are other animals — and what makes one dangerous or useful is not where it is but what it is about to do.

Predicting that means carrying a picture of another animal's picture.

There is a shortcut, and the shortcut is what makes the whole thing possible. The other animal's mind works much as one's own does. So rather than build a model of it from outside, an animal can consult the machinery it already has and ask what it would do in that position. People plainly do this. Predators very likely do. The shortcut would help the hunted as well, and a way of working that helps an animal survive is a way of working that tends to be found.

The shortcut requires turning the picturing capacity inward — on oneself, as a way of reaching outward, toward someone else.

And there something unusual begins, because what comes out contains itself: a picture of the world that includes, inside it, the one holding the picture.

### The imaginary self

One of the things in that picture is a self.

It was not discovered by looking inward, and it is not an error. The self seems to be what a capacity built for tracking other minds produces when the capacity is directed at the mind doing the tracking. V. S. Ramachandran and Uta Frith have each suggested something close to this. Other researchers hold the reverse view, that self-awareness came first and was then used to understand other people. It feels solid because it is genuinely there, in the only sense anything inner is ever there. What it is not is an object.

Which is why looking for it does not work. Look inward and hunt for the self, and what turns up is more content — sensations, thoughts, the sense of being here — never the one they are supposed to belong to. It is not well hidden. It is not among the things that could be found there, because everything found there is arranged around it.

The capacity for tracking other minds began in animals, as a way of guessing what another animal will do while the other animal is guessing back.

A person also turns the capacity on themselves, and something is added when they do. A guesser needs a piece to play, with a position, with some moves open and some closed, and with a chance to win or lose. A person sees their own self as though it were a fixed object, in the way a person sees an opponent. The self is the piece a person plays. Taking the self to be fixed as a piece in the competitive game closes off the option of playing a different game. The game is also why the self seems so real: the opponent plays a piece too, and for most of a life the game never stops.

### What self-reference does

Directing a mind at itself, as in making a self, is also the property that divides the two realms most sharply. Nothing in the physical realm takes itself as its subject; every part of it simply is what it is. A person can take their own body as a self, but that is a different kind of self. The psychic realm does little else — thoughts about thoughts, feelings about feelings, wanting not to want. That is self-reference: a picture of the picturing, and then a picture of that. Self-reference is why whatever a person thinks or feels becomes part of what the person is thinking or feeling about.

Correction does reach that realm, but only the long way round: a person finds out they were wrong once the error has worked its way out into conduct and something in the world goes badly, indirectly and long after. Everything there is built on what is already there, and self-reference is what allows that. So an error goes on being built on for as long as it goes uncorrected.

### A slant on everything rendered

A fixation does not turn up in the picture, because it is not one of the things pictured. It is a slant on how everything gets rendered: present in every scene and one of the objects in none of them. Someone hunting inward for their own is looking through the thing they are looking for.

It is read off what it produces instead. The slant shows in what a person does and in what everyone around them has already noticed, which is what makes a description of a type recognizable to the person it describes.

### Why detachment is the odd one

Enthusiasm and caution are directed at things — go at it, or watch it carefully. Detachment is not a third of that kind. What it addresses is not the thing but one's own reaction to the thing. It is the picturing capacity turned back on its owner: the same turn that produced the inner world in the first place, made for its own sake.

That is why detachment is the only orientation with two faces. Detachment can be taken with something in view, or taken automatically with nothing in view. Detaching gives the same thing either way. What differs is whether the person looks at what disturbs them or turns away from it, and those are the two directions the range of detachment runs between. The other two orientations have nothing to make such a difference with. There is one way to reach for a thing and one way to watch it.

It is also why any way out runs through detachment. Getting out means working on the apparatus rather than on what the apparatus is aimed at, and detachment is the only orientation that addresses the apparatus at all.

### The same capacity, turned the other way

The same capacity turned outward instead of inward is language: words inside words, meanings referring to meanings, a picture that can be handed to someone else and rebuilt there. That is what lets what one person works out survive them, and it is why there are contemplative traditions at all. Nobody could find these things alone in a single lifetime.

So the capacity that makes a way out transmissible is the same capacity that builds what has to be got out of.

Which rules out the solution that suggests itself first. The way out cannot be a shutting down of self-reference — quieting the mind until it stops. Noticing one's own fixation is itself an act of self-reference: a fixation is a slant on the picturing, so catching it means picturing the picturing, which is what produced the self. Stop it and nothing is left that could catch anything. The capacity is both what goes wrong and the only thing that could notice that it had.

And there is no fault here to correct. Nothing went wrong and no wrong turn was taken. The self is a by-product of something working exactly as it should.

## Chapter 14: Underneath the Cycle

Until now the cycle has been used to put the three orientations in order: enthusiasm, then caution, then detachment, then enthusiasm again. Each orientation, when fully lived, leads toward the next one in that order. The order is what gives a person's orientation its place on the cycle. The order is also what a lean is measured against. A lean is a pull toward one of the two orientations on either side of the person's own.

Underneath the ordering are three passages. A passage is the move from one phase to the next. The arising goes from the detached phase to the enthusiastic phase. The development goes from the enthusiastic phase to the cautious phase. The ending goes from the cautious phase to the detached phase. A process arises, is worked over, and ends, so every process makes all three passages.

Of orientations and passages, the orientations are the more apparent. An orientation shows in how a person behaves. The passages are harder to see, but the passages are more basic. Every thought makes all three passages. What hardens into a fixation is a habit of noticing, and noticing is done in thoughts. So a fixation acts through the passages of each thought.

### The phases and their names

Every process runs a beginning, a middle and an end. The beginning, the middle and the end are the three passages: the arising, the development and the ending. The three phases are named after the three orientations.

The phases and the orientations share names because they are related. An orientation is not a separate scheme that happens to resemble a phase. An orientation is the phase a person is most comfortable in, and the phase the person prefers to be in. A person tends to prolong that phase, because they cannot easily bear what the next phase would bring.

Settling into a phase does not mean being stuck in one process. A cautious person is not stuck in the middle of anything. Every process runs through all three phases, whoever is running the process. An enthusiastic person's processes are weighed, and they do end. A cautious person's processes do arise. An orientation is a lasting thing about a person. A phase is where one particular process has got to, and the process will move on from the phase.

The letters `A`, `B` and `Z` name only where a person stands: the orientation the person holds in a realm, with its lean. The letters are never used for a phase. So a letter always means a person.

### The caution end and the enthusiasm end

Each phase lies between two passages. The enthusiastic phase begins at the arising and ends at the development. The cautious phase begins at the development and ends at the ending. The detached phase begins at the ending and ends at the arising.

So every phase is split into two halves. One half overlaps the passage that begins the phase. The other half overlaps the passage that ends the phase.

The split matters most in the detached phase. The half that overlaps the ending lies next to the cautious phase, and is the caution end of the detached phase. The half that overlaps the arising lies next to the enthusiastic phase, and is the enthusiasm end of the detached phase. A detached person leaning toward caution, written Z−, is at home in the caution end. A detached person leaning toward enthusiasm, written Z+, is at home in the enthusiasm end.

### Where a fear meets its fate

A thought finishes in the detached phase. A fear the thought is still carrying meets its fate in the detached phase. A fear that is settled is settled at the caution end of the detached phase. A fear that is not settled meets its fate at the enthusiasm end.

Four things can become of a fear in the detached phase. The fear can be worked through, which means the thought finds what to do about the fear. The fear can be given up on, and sometimes a regret or a disappointment is left behind. The fear can be ignored, which settles nothing, so the fear returns with the problem. Or the fear can be blocked, which means the fear is turned away from until the fear is no longer noticed. A fear can be blocked all at once, in panic, or gradually, through discomfort. Only blocking leaves a person noticing less than before.

### One thought, step by step

A single thought takes about a second. A thought is the one size of process at which the three passages are actually made, so a single thought is the place to watch them.

Suppose a person notices his shoelace is undone.

The thought begins with the arising, the move from the detached phase to the enthusiastic phase. At the arising a want appears: the want to tie the lace. A thought can also start with a pain or a pleasure instead of a want. A pain usually raises the want to be rid of the pain. A pleasure arrives on its own, or arrives when a want is met. A pleasure often raises the want for more of the pleasure.

A want is what motivates a person to bring something about: to have something, to keep it, or to be rid of it.

Next comes the development, the move from the enthusiastic phase to the cautious phase. At the development the person examines the want. Examining a want means looking at what could go wrong with it. The person is holding a full cup of coffee, and bending down with the cup could spill it.

When the examining finds something that could go wrong, the examining raises a fear. A fear is one kind of aversion. Here the fear is of spilling the coffee.

Last comes the ending, the move from the cautious phase to the detached phase. At the ending the fear meets one of the four fates: the fear is worked through, given up on, ignored, or blocked. Suppose the person decides to put the cup down on a wall first. Deciding on a next step is one way of working a fear through. The fear is settled, and the next thought raises a new want, the want to put the cup down.

If the person's hands had been empty, the examining would have found nothing that could go wrong. No fear would have been raised. So nothing would meet its fate at the ending, and the thought would simply close.

### What a thought leaves

When a thought ends, the next thought is a separate thought. What the ended thought was still carrying is laid down. The next thought arises out of what earlier thoughts have laid down. So a thought does shape the thoughts after it, but only through what the thought laid down.

Take the person with the coffee again. The thought that decided to put the cup down ends, and the decision is laid down. The next thought arises out of what was laid down, so the next thought is the want to put the cup down.

### A want that lasts, and a fear that comes back

A want can seem to last a long time. Suppose a person looks for a new job for a month. The want for a new job seems to last the whole month.

But a thought takes about a second, and each thought ends. When a thought ends, the want the thought carried is laid down. The next thought arises out of what was laid down, and raises nearly the same want again. So a person looking for a job for a month raises the want for a job many times a minute, thought after thought.

The month of looking ends when the want stops being raised. The want stops being raised when the person gets a job, or when the person gives up looking.

A fear also lasts only one thought. Suppose the person fears that no job will turn up. The fear ends with the thought that raised the fear. When the fear comes back an hour later, the fear has been raised again. The fear is raised out of what earlier thoughts laid down, and out of the problem, which still stands: the person still has no job. No fear is kept somewhere and brought back.

A fear that was ignored comes back because the problem still stands. The problem raises the fear again.

A fear that was blocked is different. The person turns away from noticing the fear, and the turning away is what blocks the fear. Later thoughts then raise fears shaped by the blocked fear, even though the person can no longer notice the problem.

### Disappointment

A disappointment arises when the outcome is settled and the want cannot be satisfied. Where an aversion about the outcome had been raised, the disappointment is what is left when the aversion is given up on. A disappointment can be worked through, given up on, ignored, or blocked.

Suppose a person bends to tie a shoelace and finds that the lace is broken. The want was to tie the shoe. Finding the lace broken settles the outcome, and the want cannot be satisfied, because a broken lace cannot be tied. The want to tie the shoe is given up, and the thought ends.

The broken lace starts a second thought. The second thought raises a want to fix the lace. Examining the want raises an aversion about the broken lace. When the aversion is given up on, what is left is a disappointment. The disappointment then meets its fate. If the person decides to tie the broken pieces together, the disappointment is worked through. If the person drops the want to fix the lace and wears other shoes, the disappointment is given up on.

### Gratification

Whatever gratifies a person becomes expected when the gratification is repeated, and then the gratification stops. The same thing day after day no longer makes a person feel better than before. What gratifies changes as it is repeated, so no way of seeking gratification keeps working. Constant gratification is impossible.

A person who expects a gratification to last is disappointed when the gratification ends. The outcome is settled, and the want not to lose the gratification cannot be satisfied.

As the endings repeat, a fear of losing the gratification develops along with the expectation. The fear can be felt even while the gratification lasts.

When a gratification wears off, the person feels worse than before. A person who does not know that gratification wears off blames circumstances for feeling worse. The person believes some different behavior will bring relief.

A different behavior does bring relief for a while. After a gratification has worn off, the person expects less, so almost any new behavior makes the person feel better than before. The person believes the new behavior brought the relief. But the relief came from expecting less, and not from the behavior. The new behavior then wears off in its turn.

So the drawback of seeking gratification is constant useless behavior.

### Action without a full thought

An action can come with no thought before it, after a thought that is cut short, or after a thought that is fully lived.

Sometimes no thought comes before an action. A hand comes off a hot pan before anything is thought. The movement is a reflex.

Sometimes a thought comes before the action, but the examining in the thought is cut short. Suppose a person has been holding back their temper. In one thought, the person concludes that holding back hurts too much. The next thought raises the want to end the hurt, and the person snaps at someone.

Where an action comes in a thought depends on the motive behind the action. An action that goes toward something comes at the enthusiastic phase. An action that fends something off comes at the cautious phase. Snapping is done to fend off the hurt, so the snap comes at the cautious phase. The examining would have happened at the cautious phase, and the snap cuts the examining short.

Panic is also a thought whose examining is cut short. Panic is a thought and not a reflex, because a judgment is made in panic.

A thought whose examining is cut short still makes all three passages. A thought like that raises little, so little meets its fate at the ending.

Sometimes the thought before an action is fully lived. The person with the coffee examined the want to tie the lace in full, and decided at the ending to put the cup down first.

### Where a fixation acts

The orientation a person holds in a realm, once hardened into habit, is called a fixation. In each realm, a person's attention is usually concentrated at one phase. The phase shows which orientation is the person's fixation in that realm. Every thought passes through all three phases, so a fixation acts in every thought. A larger process is a long run of thoughts, so a fixation acts at every size of process too.

A person has a fixation in each realm. The fixation that acts in a thought is the one the person holds in the realm the thought is about. The coffee and the shoelace belong to the physical realm.

A person whose fixation is enthusiastic gives most attention to the arising. The examining is cursory, and the person bends down with the cup without much thought. Little is raised, so little reaches the ending. The fears that are raised reach the ending with little understood about them. A fear examined so little may seem less urgent.

A person whose fixation is cautious examines heavily. The person sees many things that could go wrong: the coffee could spill, the wall could be wet, someone could knock the cup off the wall. Many fears are raised, and most of them reach the ending with the trouble understood. Each fear meets its fate at the ending.

A person whose fixation is detached gives little attention to the arising and little to the examining. A detached person still raises wants and fears, like anyone. A detached person raises them less intensively, because little attention goes to the arising and the examining. What a detached person wants is peace.

Fears still arrive at the ending of a detached person's thoughts. An arriving fear can be settled, or the fear can be ignored. Settling happens at the caution end of the detached phase. Ignoring happens at the enthusiasm end of the detached phase. Both can happen to any detached person. Which way the person leans, and how far, influences which one happens. A person leaning toward caution is more likely to put the cup down first. A person leaning toward enthusiasm is more likely to ignore the fear of spilling and bend down with the cup.

## Chapter 15: What Becomes of a Fear

### Disregarding, and not seeing at all

Three things are easy to run together and are not the same. A person can notice something and then decline to look at it any further. Or the noticing can be stopped, without the person having decided anything. Or, where the noticing has been stopped, there is nothing left to decline. All three take the material in; what differs is what happens after. Only declining to look further is chosen.

The leans are what make the difference in how a fear is left unsettled. A person leaning back toward caution stays watchful, and often works a fear through. A fear such a person leaves unsettled was noticed and let alone. A person leaning forward toward enthusiasm turns away from noticing. A fear such a person leaves unsettled is usually ignored, and then forgotten. A fear that is uncomfortable to look at is noticed less each time the fear comes near. A fear that keeps coming back can grow until panic turns the person away from the fear.

The three are not two kinds of thing with a line between them. What a person does about what they take in runs from the involuntary to the chosen, and a choice repeated often enough stops being made and sinks back toward the involuntary end.

So asking whether a lean is something a person does or something they are is asking where on that run it has settled, not which of two kinds it belongs to.

Take one fear at a time. A fear can be worked through, which means the thought finds what to do about the fear. In that case the fear is dissolved. Or a fear can be given up on — surrendered to — and no fear is left afterwards. Either way the person is finished with the fear. The matter the fear was about may still be waiting.

Or a fear can be blocked. In a burial, the fear grows until panic turns the person away from the fear, and after that nothing about the fear has to be faced. None of that is decided, because panic does the turning away, not the person. A later threat about the same matter is taken in like everything else, but is turned away from before the threat is noticed. What the burial laid down stays unchanged, and a person cannot reach what was buried by deliberately looking for it. A fear blocked by discomfort is different. The person does the turning away, not panic, and at first the turning away feels like a choice.

Or a fear can be seen and then left alone — noticed, not settled, not gone back to. Nothing is finished here either, but nothing is being held off. A person who leaves a fear alone is ignoring the fear. Ignoring leaves a tension in the body, and the tension lasts a while. Once the tension has subsided, the fear is forgotten. Forgetting is a later stage of ignoring. Ignoring can be done on purpose or by habit. A person who has ignored fears often enough no longer ignores them on purpose. The problem the fear was about is still standing whether the fear is ignored or forgotten, so the fear can be raised again.

Only a blocked fear is a failure of noticing.

### The four fates

A fear that reaches the detached phase meets one of four fates, and only one of them leaves a person noticing less than before. The same four fates meet every aversion, not only a fear.

A process reaches the detached phase at the caution end, where fears are still noticed, and leaves by the enthusiasm end, where the turning away has gone furthest. So a fear that is settled at all is settled while the fear is still in view. A fear not settled by then reaches the enthusiasm end.

*Worked through* — the thought has found what to do about the fear, so the fear is settled. Nothing has been turned away from. What the thought finds may be as small as a decision to try again. If the want behind the fear is still unmet, the want is laid down, and the next thought raises the want again.

*Given up on* — the want behind the fear is dropped, and with the want gone the fear is gone with it. Giving up a want sometimes leaves something behind. Where what remains is a regret, the want was to change an outcome the person could have avoided by acting otherwise. Where what remains is a disappointment, the person could not have acted otherwise.

*Ignored* — the fear is noticed and let alone, on purpose or by habit. The problem still stands, so the next time the problem is met the want is raised again, and the fear is raised with the want.

*Blocked* — the aversion is turned away from until it is no longer noticed. There are two kinds of blocking.

Blind blocking happens in panic, to a fear the person cannot bear. The turning away is automatic and happens all at once. A fear blocked blindly is a buried fear. Denial is the effect of a burial: from then on, fears about the same matter are turned away from automatically. A fear is usually buried only after it has come up repeatedly and grown, until one time it is more than the person can bear. Panic then turns the person away from the fear, and the fear is buried. A small child can be brought to panic by very little, the first time. The blindness loop keeps the buried fear in place. Anything that would lead toward the buried fear is turned away from as well.

Discomfort blocking happens to a fear the person can bear but finds uncomfortable. It begins with a fear that is noticed. What the person turns away from is the feeling of the fear, because looking at the fear is uncomfortable. Looking at the fear is found uncomfortable at the caution end of the detached phase, where the fear is still in view. The turning away happens at the enthusiasm end. At first the turning away feels like a choice. Each time the fear comes near, the discomfort of the fear turns the person's attention elsewhere, and the turning away becomes more automatic. A habit of turning away builds until the fear is no longer noticed.

No blindness loop forms. A later fear that matches the blocked fear is turned away from by habit, but the later fear can still be noticed, and the person can then choose whether to look at it.

Discomfort blocking differs from ignoring. When a fear is ignored, the person lets the problem alone, and the fear is noticed as fully each time the problem comes back.

Fears differ in strength. A fear of spilling a cup of coffee is weak. A fear of losing one's job can be strong enough to be more than a person can bear.

A fear worked through is settled, and a fear given up on is settled. A fear that is ignored or blocked is not settled. The matter the fear was about is left unresolved, and a fear that meets either of these two fates is called **unattended**. So every fear meets one of the four fates, and only some fears are settled.

Ignoring and blocking each lay something down. Ignoring does not leave the fear, and it does not leave the want behind the fear. Ignoring lays down the habit of ignoring, a little stronger each time. Ignoring also lays down the knowledge that a problem was left unfinished. And ignoring leaves a **bodily tension** — the feeling of being afraid, held in the body, with nothing it is about. The tension lasts hours rather than days, and a person can let it go by breathing or by exercise. Every fate leaves some bodily tension. A fear worked through or given up on leaves less bodily tension than an ignored or blocked fear does. A burial leaves bodily tension too, at full strength at the moment of the burial, and what the person feels then is panic or a sharp upset. A burial also lays something down. The buried fear itself ends with its thought, like any fear. What the burial laid down stays, hidden and stable. Later thoughts raise fears out of what the burial laid down. So a buried fear is what the burial laid down. Blocking is the only fate after which fears go on being raised about a problem the person can no longer notice.

Two questions sort the four fates: whether the fear stays in view, and whether the fear is settled. A fear worked through or given up on stays in view and is settled. An ignored fear stays in view and is not settled. A blocked fear does not stay in view, and it is not settled. A buried fear is out of view from the moment panic turns the person away from the fear. A fear blocked by discomfort is noticed at first, and is noticed less each time until it is no longer noticed. No fear is settled once it is out of view, because settling a fear needs the fear to be noticed.

The two questions do not separate worked through from given up on: both happen in view and both settle the fear. A fear worked through ends because the thought found what to do about the fear. A fear given up on ends because the want behind the fear was dropped.

### How a fear comes to be buried

A detached person leaning toward enthusiasm wants peace. Such a person gives way to easy wanting, and turns away from whatever would interrupt their peace. Giving way to easy wanting sounds slack, and it is not — it holds a person in place. Suppose a detached person leaning toward enthusiasm hears that their job may be at risk. A fear about the job is raised in the cautious phase, and the discomfort the fear leaves behind disturbs the peace the person wants.

Being afraid is itself uncomfortable, so the person now fears the fear as well. Two fears pull on the person at once: a fear about the job, and the fear of the fear. When the fear of the fear wins, the person is unable to bear knowing about the job.

The person does not decide this. The fear has grown more painful than the person can hold, and what gives way is the person's capacity, not the person's preference. How painful the fear is depends on how strongly the person holds the fixation in the realm the fear is about. The stronger the fixation, the more deeply caught the person is. Deeply caught, the same fear is more painful.

The news about the job is an incident, and an incident is not a single fear. In the thoughts that follow, the news raises several fears about the job. Some of the fears are noticed and let alone, and those fears are ignored. Some of the fears are noticed, and the person turns away from them because looking at them is uncomfortable. Those fears are blocked by discomfort. Some of the fears are ignored or blocked by discomfort several times, and come back stronger each time. In the end, one of these fears is more than the person can bear, and panic turns the person away from the fear. That fear is buried.

What varies from person to person is how far the turning away has developed over the person's history. Suppose the person had news of a threat to their work years before, and a fear about losing work was buried then. The new incident sets off an automatic turning away from noticing, before anything about the job has been noticed.

A burial crosses the detached phase. At the caution end, the fear is still in view, and the caution end is where the fear is found to be more than the person can bear. Panic raises a want to be rid of the fear, and the want carries the person toward the enthusiasm end. There the turning away is completed, and the fear is no longer noticed. The person has turned away from the fear and toward what they are drawn to.

A burial is not one event. Suppose an incident raises a fear about a matter. The fear comes up repeatedly and grows, until one time the fear is more than the person can bear, and panic turns the person away from the fear. Before the panic, the fear has usually been ignored, or blocked by discomfort, as the problem went on. Each time the fear came back stronger. What turning away in panic leaves behind is that certain thoughts are painful. The turning away also leaves behind the habit of turning away from noticing those painful thoughts. How painful those thoughts are depends on how much has been buried about the same matter. The matter is unresolved, so fears about it are raised again, whether by the same incident coming back or by a fresh incident of the same kind. Each time, more of the fears are turned away from before they are noticed. Once the person has panicked, the main burial of a matter happens quickly, perhaps within a week. Afterward, layers of fear of the fear build up, possibly without end. Each layer is buried too, and each layer means the turning away comes sooner. As the turning away comes sooner, it also reaches further: fears that only lead toward the matter are turned away from as well. So what is blindly blocked can keep growing. Burying can begin before a person has words. After a burial before words, layers of fear of the fear build up in the same way.

### Burial is not a decision

Once a fear has been buried, a later threat about the same matter is still taken in, like everything else. But the threat is turned away from before the threat is noticed. The failure to notice is automatic rather than chosen.

The turning away stops the noticing, but the threat still raises a feeling of fear. So the later threat is felt even though the threat is not noticed. The person cannot say what the feeling of fear is about, because the threat never came into view.

A feeling of fear arrives along with what a person takes in. The thing taken in becomes the thing feared, because the feeling came with it. The strength of the feeling is a fact about the person rather than about the thing.

The anxiety that caused the turning away is taken in, and so is the turning away itself, and neither of them is ever noticed. Both leave something behind all the same. A person who has made the move before makes it more readily the next time.

Each burial lays something down. A burial lays down that certain thoughts are painful. A burial also lays down the habit of turning away from noticing those painful thoughts, so the turning away happens automatically. A later incident like the incident that caused the burial sets off the turning away again. No choice is repeated here, because nothing was noticed to choose about.

This is why a decision not to look is not what happens in a burial. When the fear is buried, panic does the turning away, not the person. After the burial, a later threat is turned away from before the threat is noticed. A decision not to look at the later threat would require noticing the threat first. What happens instead is that the taking in goes on exactly as it always does, and the noticing is stopped.

Discomfort blocking is different, because the person does the turning away, not panic. At first the turning away feels like a choice.

### The blindness loop

Once a fear has been buried, the blindness does not fade. A person turns away even from recognizing what happened, because recognizing the burial would require facing the buried fear. So the recognition is itself a threat. Each time the recognition comes near, a fresh anxiety arises, real and present. Turning away relieves the anxiety, and the turning away is what keeps the blindness in place. So the blindness produces the thing that maintains it. That makes the blindness a feedback loop rather than a habit. Being a feedback loop is what separates the blindness from ordinary not-looking. A person does not drift through the blindness and out again. The person is strongly pulled to stay in it. The blindness comes about when a fear becomes more than the person can bear, and panic buries the fear.

A conversation, a place, a question somebody asks — anything that would bring the buried material to mind raises a fresh anxiety, real and present. The fresh anxiety is the fear of looking at the buried fear. The person turns away from each fresh anxiety automatically. A person can give no reason for the avoiding, because what is being avoided is no longer noticed. So the number of things a person turns away from grows over time.

What happens to a fear after the burial does not depend on the lean. The blindness loop runs on the turning away from recognizing what happened, and would run the same way in anybody.

### The unease loop

A fear can be worked through and still leave a person uneasy. Suppose a person is waiting to hear whether the sale of their house will go through. A thought raises a fear that the sale will fall apart. The thought finds what to do about the fear: the person decides to call the agent in the morning. The fear is worked through, and the fear leaves some bodily tension.

The bodily tension is uncomfortable. So a later thought raises a want to be rid of the tension. Examining the want finds that the want cannot be met, because the sale is still undecided. So the examining raises a new fear. The person works the new fear through as well, perhaps by deciding to wait and see. The new fear also leaves some bodily tension.

Each turn is a whole thought, with all three passages, and each turn is worked through. The turns go on because the matter does not resolve, and no decision can make the matter resolve. The unease loop is the round of a fear, then bodily tension, then a want to be rid of the tension, then a new fear.

After a few turns, while the matter stays unresolved, the want is to be rid of the tension, and the fear is of failing to be rid of the tension. The discomfort is more basic than any one problem, because solving one problem usually leads to finding another.

Nothing is turned away from in the unease loop. So the unease loop buries nothing, and the unease loop takes nothing from what a person notices.

What the person feels through the unease loop is unease. Unease and bodily tension refer to the same thing. Unease is the discomfort as the person feels it, and bodily tension is the discomfort held in the body.

Any one bodily tension lasts hours rather than days. Every turn of the unease loop leaves a little bodily tension. While the matter stays unresolved, the turns keep coming, and the tension is kept up. When the turns come close together, the tension can build. So the unease lasts as long as the matter stays unresolved.

A person runs the unease loop whatever orientation the person holds in the realm of the matter. What differs is what the person wants on each turn.

An enthusiastic person tries something else on each turn. What stays the same from turn to turn is the unease, not the matter.

A cautious person goes on trying to solve the existing problem.

A detached person wants the unease gone, either by a distraction or by finding a potentially unconventional solution.

A person at any orientation also has a way out of the unease loop, using the competence of the orientation. A cautious person can come to understand the matter. An enthusiastic person can act on the matter. A detached person at the caution end of the detached phase can settle the fear.

A person near the enthusiasm end of the detached phase runs the unease loop in a different way. Suppose the person waiting on the house sale leans toward the enthusiasm end. A thought raises the fear that the sale will fall apart, and the person changes the subject. The fear is noticed and let alone, so the fear is ignored, and the fear drops out of mind.

The ignored fear leaves some bodily tension, which fades. The fear is raised again when the person next meets the problem of the sale.

A buried fear does not fade in this way.

It would be reasonable to expect the harm the unease loop can do to a person to have a limit. The harm the blindness loop can do has no limit.

Nothing in the unease loop is buried, so the unease is felt. A way out of the unease loop is always open. What motivates a person to take a way out is a comparison of two pains: the pain of staying as the person is, and the pain of doing what the way out requires. When staying becomes the worse pain, the person takes the way out.

A person can also turn a matter over while an outcome may still be changed. Suppose a person has had a bad job interview, and the employer has not yet decided. What the person raises again and again is a general want: the want for the outcome to go differently.

If the person reaches a different plan each time, each turn is worked through. One time the plan is to write to the interviewer, and another time the plan is to ask a friend for a reference. The turning over is then the unease loop.

If the person repeats one plan every time, the fear of the plan failing again is noticed and let alone each time. The fear is ignored, and the turning over is ignoring.

The turning over ends when the person gives up the want. Where the person could have acted otherwise, a regret is left behind. The turning over also ends when a want about the future replaces the old want, for instance the want to prepare better next time.

The unease loop is ordinary. A person can run the unease loop many times without thinking of themselves as troubled. From inside, a person in the unease loop feels they are making an effort, not that they are stuck.

### Lasting unease

Three things about unease are separate: the unease being present, the unease being noticed, and the person acting on the unease. A person has to notice the unease before acting on the unease. But noticing the unease does not by itself bring the acting.

The health axis reflects how much a person notices, not how comfortable the person is. A person higher on the health axis notices more, and so may notice more unease than a person lower down. The person higher up is also better able to do something about the unease.

Two kinds of help with unease work in different ways. By breathing or by exercise, a person can let go of a bodily tension already present, a tension with nothing it is about. A skill for handling fear raises how much a person can bear while a feeling is arriving. Only a skill for handling fear can change whether a fear is blocked. A fear is blindly blocked when the fear is more than the person can bear, and blocked by discomfort when looking at the fear is uncomfortable. A skill for handling fear makes both kinds of blocking less likely.

Most people feel uncomfortable when they are completely idle. The discomfort is unease. The unease comes from blocked aversions, from ignored aversions, and from being less able to handle life than others are. A burial is felt even though the buried fear is no longer noticed. An ignored aversion is noticed and let alone. The matter behind the ignored aversion can still be noticed, though the matter is not necessarily in view.

So an idle person seeks a distraction: something the person expects will make them feel better. For an enthusiastic person the distraction is something pleasant. For a cautious person the distraction is a problem to solve. For a detached person the distraction is some activity, or contact with someone else.

A distraction is a gratification, so a distraction wears off as well. Constant distraction is impossible. A disappointment at a gratification ending may be ignored. An ignored disappointment leaves the matter unresolved and leaves some bodily tension. When the matter comes up again, the matter raises an aversion, and the aversion adds to the unease.

Lasting unease has three sources: ignored aversions, blocked aversions, and being less able to handle life than others are because of aversions that were blocked. The three differ in what ends them. An ignored aversion can later be given up on. An aversion blocked by discomfort can be noticed and looked at. A buried aversion can only be faced. A person stays less able to handle life than others are for as long as the blocked aversions remain. The person perceives being less able as a threat for that whole time, so being less able keeps adding to the unease.

The unease from a buried fear does not wear off the way a gratification does. Each time the buried material comes near, a fresh anxiety arises. The fresh anxiety is the fear of looking at the buried fear. So the person feels the anxiety again and again, and needs a distraction again and again.

Where a person has no ignored aversions and no blocked aversions, there is no chronic unease. Ordinary pain still comes and goes. But no distraction is needed to cover the pain.

Lasting unease also produces fears. The unease loop keeps raising fears, and the fears attach to whatever matter keeps coming up. A fear that a matter raises every time the matter comes up is a habitual fear. With buried material, the buried fear is no longer noticed. A habitual fear is noticed every time, and worked through every time, as each turn of the unease loop is.

The blindness loop keeps buried material in place. A habitual fear is kept going by blocked aversions or ignored aversions, and by the unease loop. The matter is only what the fear attaches to each time the matter comes up.

A habitual fear usually eases when the source of the lasting unease ends. Other things affect a habitual fear as well.

## Chapter 16: The Fixations Themselves

### The range of detachment

For enthusiasm and caution a lean shades the orientation without altering what it does. Detachment is different.

In detached people, the competence seems to be the ability to notice more, and the characteristic failure seems to be not noticing whatever would disturb a person's peace. The competence and the failure are opposite functions. Both belong to detachment, which is the only one of the three orientations with a contradiction inside it.

One reason accounts for both the competence and the failure. The whole realm is open to noticing when nothing pulls a person's noticing toward what a want or a fear is about. But a want or a fear has to pull a person's noticing before any noticing happens. What a detached person wants is peace. While nothing is disturbing the person, wanting peace pulls the noticing nowhere. So a detached person has the most open to noticing of any of the three, and may notice the least.

How much of a realm a person knows depends on which orientation their fixation is at in the realm. A realm can go little known for reasons other than detachment. An enthusiastic person never stays with a realm long enough to examine it. A cautious person notices a realm piece by piece, assembling the pieces, and never has the whole realm in view at once. So knowing little of a realm is not by itself evidence of detachment in it. In detachment, while nothing disturbs a person, the whole realm is open to noticing at once, with nothing to assemble.

A disturbance changes what wanting peace does. When something does disturb a detached person, wanting peace pulls the noticing — toward what is disturbing the person, or toward getting away from it. Everyone meets conflict; what differs is the method their orientation makes available for settling it. Disturbed, an enthusiastic person acts and a cautious person manages, and acting and managing are what those orientations are, so settling the conflict exercises the competence. A detached person wants the disturbance quieted instead. A disturbance can be quieted by solving what is disturbing the person, and solving uses the competence. A disturbance can also be quieted by no longer noticing it. Turning away means the disturbing thing goes unnoticed. For a detached person, noticing was already what happened least.

Which face appears is set by the direction of the lean, because the two orientations either side of detachment are what produce them.

A person still has motivation in a detached realm, and the motivation comes two ways.

A person raises wants about matters in a detached realm too, and examining a want raises a fear about the want. A detached person gives little attention to the arising and the examining, so fewer wants and fears are raised about matters in a detached realm. A person examines most in the realm where they are cautious, so most of a person's fears are raised about matters there. A fear that is left unattended at the ending can be raised again later, out of the matter that is still unresolved.

An enthusiastic or cautious realm also supplies motivation the person can direct at their other realm, when the other realm is detached. What crosses is the motivation and not anything it is about, so the person can direct it at whatever the detached realm has taken in. A person with one detached realm has both kinds of motivation. A Nine, detached in both realms, has only the wants and fears a Nine raises.

A pain or a pleasure starts a process. A pain starts a process when the pain is felt, and so does anything that brings a past pain to mind. A process started by a pain raises the want to be rid of the pain. A pleasure arrives on its own, or arrives when a want is met. A process started by a pleasure raises the want for more of the pleasure. Such a process raises fears as well as wants. Examining a want raises a fear the same way, because what the examining finds is a pain that would follow if the want went wrong.

The lean changes how much a detached person is moved to notice. The further the lean is from caution, the less the person notices. A detached person leaning back toward caution has arrived at detachment by way of understanding. The understanding gained on the way stays with the person. A detached person leaning forward toward enthusiasm is giving way to easy wanting. Such a person turns away from whatever would interrupt the return to peace, and so notices less and less of what would interrupt the peace.

The lean has a different effect from the blindness loop. Every process passes through the enthusiasm end of the detached phase, whatever fixation a person holds. The lean changes how likely a fear is to be settled before the fear reaches the enthusiasm end.

The two leans in detachment differ far more than the two leans in caution, where a lean only shades what the orientation already does. What varies between the two leans in detachment is how much of the detached realm a person notices. A person leaning toward caution still notices fears. The further the lean is toward enthusiasm, the further the turning away goes, and the less a person notices of what they take in. How much is noticed is one quantity running along the whole range, with no boundary between two conditions. A Nine leaning toward caution notices what is in a realm, clearly and with concern. The same Nine leaning toward enthusiasm does not notice exactly what would be uncomfortable to know. The failures at the enthusiasm end show. The competence at the caution end stays quiet.

At either end of the range a person still wants something. What differs is whether the want has anything in the realm to fasten on.

Near the caution end what a person wants is to be rid of the discomfort that fears leave behind. The want is for the discomfort to be gone in general, rather than for one particular fear to be settled. A want for the discomfort to be gone is about nothing in particular, so while nothing is disturbing the person, the whole realm stays open to their noticing.

When something does disturb a person near the caution end, peace means the trouble in front of them settled — a practical difficulty reduced in the physical realm, a distressing situation eased in the psychic one. The person looks at the trouble and wants to solve it. A great deal stays open to their noticing while they work at the trouble, and the noticing can be deep. What the person wants as a standing matter is still to be rid of the discomfort that fears leave behind.

Near the enthusiasm end what a person reaches for is a distraction from what is uncomfortable. Any distraction will serve, which is why the person has no one particular thing in view. A want to get away from discomfort is about nothing in particular, so while nothing is disturbing the person, the whole realm stays open to their noticing.

When something does disturb a person near the enthusiasm end, peace means being rid of the disturbance — an uncomfortable thought or feeling of their own, in either realm. The person wants the disturbance gone rather than solved. Wanting one thing gone leaves very little open to noticing, so a person near the enthusiasm end notices less at such a moment than anyone else does. What the person wants as a standing matter is still to get away from what is uncomfortable.

Turning away from a fear that cannot be borne is automatic. A reflex and an automatic turning away are both unchosen, and they differ in what brings them on. A reflex answers nothing — no thought raised anything, and the body moves. A turning away answers a fear that a thought raised. Nothing about the turning away is decided, which is why a person cannot find the moment they chose not to notice. And taking in needs no thinking, so what a person turns away from was taken in before the turning away happened.

**Pure detachment.** For enthusiasm and caution, having no lean is simply the orientation at full strength, because their leans only shade intensity. Detachment is different, because its two leans are opposite functions rather than two degrees of one. Pure detachment is no lean either way. A person with no lean does not go looking, which would be a lean toward caution. The person does not look away either, which would be a lean toward enthusiasm. Where a person with no lean fails to notice something, nothing was defended. There was simply no motive to notice the thing.

When something does disturb a person with no lean, peace means not being drawn into what troubles other people — their practical worries in the physical realm, their emotions in the psychic one.

Pure detachment is a real position, and nobody is ever found exactly at it. What you see when you look at a person is where they habitually lean, plus whatever the day has added. So even a person who habitually leans neither way will look, at any given moment, like they lean a little one way or the other.

### Which fixation handles a fear

The fixation that handles a fear is the one a person holds in the realm of the matter the fear is about, and not the person's type. A person has two fixations, and a fear about a matter in one realm goes to the fixation held in that realm.

Some matters lie on both sides. A fear about a matter on both sides is one fear and arrives once, and both of the person's fixations act on the fear as the thought crosses the detached phase.

Before the detached phase, a fixation changes how much examining is done. An enthusiastic person cuts the examining short, passing over the suspicion that more is going on here than they want to look into. So few fears are raised. A cautious person examines heavily, so many fears are raised, and most of what might go wrong is understood before the detached phase is reached. The cautious failure is overload rather than omission.

Everybody handles fears in the detached phase, and what differs is how much attention a person gives the detached phase. A person whose fixation in the realm of the fear is detached gives the detached phase the most attention. A person whose fixation in the realm of the fear is enthusiastic or cautious gives the detached phase little attention, so the handling in the detached phase is shallow rather than absent.

Every process passes through the whole range of the detached phase, whatever fixation a person holds. A process reaches the caution end first and the enthusiasm end after. The caution end is where a fear is settled, by being worked through or given up on. A fear not settled at the caution end goes on to the enthusiasm end. At the enthusiasm end the fear is ignored or blocked. What separates people is how much attention a person gives each end.

A person whose fixation is enthusiastic gives little attention to either end. Few fears reach the detached phase, because the examining was cut short. Little is understood about the fears that do reach the detached phase. At the caution end an enthusiastic person often gives up on a fear by dropping the endeavor. A fear that passes the caution end unsettled meets its fate at the enthusiasm end, and a new want arises at once.

A person whose fixation is cautious also gives little attention to either end. Many fears reach the detached phase, already understood. The fears reach the detached phase late, when need or exhaustion forces the ending. At the caution end a cautious person may work a fear through, give the fear up, or let the fear pass. A fear that passes meets its fate at the enthusiasm end, and the person starts another endeavor.

A detached person leaning toward caution gives the caution end the most attention, so a fear is more likely to be settled. Often the settling is a real decision: to act, or that acting is not worth the trouble. The less cautious the lean, the more fears go on to the enthusiasm end, where the fears are ignored.

A detached person leaning toward enthusiasm gives the caution end little attention, so a fear is less likely to be settled. A fear that is settled is more often given up on than worked through. Most of the person's attention goes to the enthusiasm end. There the person usually drops everything for something more pleasant, and the fear is forgotten. A fear that is uncomfortable to look at is blocked by discomfort, and a fear the person cannot bear is buried.

### The four sketches

The difference between the fixations shows plainly if the same endeavor is walked through in each. The sketches are loose by intention — they describe a person, not a rule — but the shape of each is exact.

An enthusiastic person's (A) attention is concentrated at the enthusiastic phase: an impulse arises the moment the previous pursuit ends. The detached phase gets very little attention, so little is settled before the next want is raised. Enthusiasm is that person's place of comfort. When the endeavor runs into trouble, whether when being thought through or in execution, in the cautious phase they tend to judge that it is too difficult, and at the caution end of the detached phase they often drop it completely. Once past that end they are free to start another endeavor, unless the fear went by the caution end without being settled.

A cautious person's (B) attention is concentrated at the cautious phase: an impulse arises, is recognized as attractive and is quickly examined for threats. The motion toward it is eager — examining is the cautious person's place of comfort. They generate alternatives, see the flaw in each and generate more. The detached phase often comes late and under duress: forced by need or exhaustion, the worry or fear moves into the caution end of the detached phase. There the person may resolve it, or drop it, or let it pass on. If it reaches the enthusiasm end of the detached phase, they leave it unattended and start another endeavor.

A person detached on the caution side (Z−) runs through a process quickly and at low amplitude. What arises is mild — a small disturbance, noticed. The person is moved to consider addressing it, weighs what that would take, and decides: sometimes that it is not worth the trouble, sometimes to act. Often the detached phase brings a genuine decision, because the disturbance stayed in view — and if they act, the action begins a new arc inside the decision. But the less cautious the lean, the more likely the fear is to pass on to the enthusiasm end of the detached phase. There the person leaves it unattended and starts another endeavor.

A person detached on the enthusiasm side (Z+) starts from boredom. The boredom is unease felt while the person is idle, and the unease comes from blocked aversions, ignored aversions, and being less able to handle life than others are. An impulse toward something enjoyable arises and goes straight to action. The person stays in action only while it is comfortable. When the comfort thins, sooner than for the (A) fixation, the person usually just forgets what they were doing and looks for something more pleasurable. Sometimes the weighing does happen instead. It is brief and it is unpleasant, and what the person decides is to abandon rather than to resolve: a small discomfort now against the larger discomfort that staying would bring. The person gives the caution end of the detached phase little attention, and settles little there. Before long a new impulse arises, usually for a related alternative: the same fun by another route. Each drop seems to be a clean ending and each new pursuit a fresh start. What the drop does not do is answer anything, so the boredom comes back unchanged. The drop, however, is not always clean. A fear that is given up on ends with the want it belonged to. A fear that is ignored comes back with the next occasion, because the problem it was about still stands. A fear that is uncomfortable to look at is turned away from, and is noticed less each time it comes near. A fear that is more than the person can bear is turned away from in panic and buried. What the burials lay down accumulates: buried anxiety continues to cause stress even though the fear behind it is no longer noticed.

Two things repeat across the four. What arises differs — a fresh impulse for the enthusiastic person, an attraction for the cautious one, a mild disturbance on the caution side, boredom on the enthusiasm side. Where the arising is the same, the difference falls later: the enthusiastic person is at home in the enthusiastic phase and the cautious person is at home in the cautious phase, and each endeavor rests longest where its person is comfortable. Either way the fixation is at work before anything in the endeavor itself would produce the difference.

In each of the four, the fixation is already in place and simply running. Where a fixation came from is a separate question. Two things bear on it: a person's constitution, and what happened in their earliest years. How much each of the two contributes is not known.

### Two channels

A newborn arrives with its reactions already installed. They were selected over a very long time because they kept infants alive, and they contain no understanding of anything.

Two channels run from the start: wanting and hurting. Each has its innate twin in the parent. The infant's delight is pleasant to the parent and its distress is painful, so the parent acts to relieve their own state and relieves the child's in doing it. The signal works by producing its copy in whoever is near. All of this is automatic, and none of it is a fault.

Two channels do not make three orientations, and the third does not come from a third channel. The three are relations to the two: react to the feeling, weigh it and respond, or watch it without doing either. Feelings run through the whole of a life. What develops is the relation taken toward them.

In an infant that differentiation cannot fail to happen. Some things lead to pleasure and some to pain, and those contingencies are the first wantings and the first fearings. The three orientations appear in their rawest form — going toward what is pleasant, trying to avoid what is painful, and watching without doing either — and one of them comes to predominate. First by constitution, and then by how the people around the child respond. It settles separately in each realm, which is why a person can be one thing about the world and another about their own inner life.

### The hinge

The hinge is anticipation. Once a child can foresee pleasure and pain, behavior that was merely emitted begins to be deployed. The cry that happened becomes the cry that is used. Nothing dramatic marks the moment; the same behavior continues, with intention now behind it.

And the reactions fitted to helplessness do not retire when helplessness ends. A fixation seems to be a strategy that outlived its problem.

This is also the second reason a person cannot find their own fixation by looking for it. The first was that a fixation is a slant on what gets pictured rather than one of the things pictured; this one is that a strategy laid down before understanding existed was never held as a belief. There is no proposition in it to doubt, and no memory of having adopted it. Someone searching inward for their own fixation is searching for something they once decided, and there is nothing of that kind to find.

Which is not to say it cannot be seen. It is recognized all the time — in what a person does, in what other people say about them, in a description that fits uncomfortably well. What fails is the direct look. A fixation is known by what it produces.

When the parents are gone, the infant's strategy stays, and the person takes the parents' place. A person then uses the strategy on themselves. A feeling arises, and an automatic response follows that uses the feeling the way the infant's cry was once used on a parent. The conscious person then seems to be pressed to give the feeling what it demands, just as the parent once was. Naval Ravikant describes desire in a similar way, as a contract a person makes with themselves to be unhappy until they get what they want.

### Habit carries it

All of it runs on habit, and habit has one decisive property: nothing has to be believed for it to keep running. So nothing is lost when belief changes, or collapses, or was never there in the first place. The infant's strategies persist for exactly that reason. So do the attainments of someone trained — a discipline practiced until it maintains itself outlasts the reasoning that began it. The same faculty does both, and what it carries makes no difference to it.

Something about a person's orientation is a choice and something about it is not, and habit is what moves it from the one to the other. Something is taken in; it carries a feeling; the feeling pulls one way or another; and only then does the person do anything about it. Doing something about it is a choice. But repeat a choice often enough and it stops being made — it sinks back below the level where anything is decided and runs by itself.

A fixation runs below the level where anything is decided. Some of what makes a fixation may come from biological tendency. The rest was a choice, repeated until the choice sank below deciding. The chosen part is strategic in what it contains, because it was aimed at something when it was adopted. The chosen part is automatic in how it runs, because repetition took it below the level where aiming happens. So a person never finds a moment when they chose their fixation, because nothing is being decided while the fixation runs. And the chosen part outlives the problem it was aimed at, because it was aimed once and runs unaimed now.

Since a fixation is a choice that sank below deciding, undoing a fixation means something other than what is usually attempted. Bringing a fixation back up does not mean replacing it with a better orientation; that would be another orientation, sinking in its turn. It means restoring the original to the level where it can be declined. Not eliminating it. Making it available again.

### What previous thoughts have laid down

Everything else in a person turns over by the hour. Wanting and fearing arrive, run, and are gone. Why should one particular way of noticing stay put for fifty years? A strategy is laid down before a person can understand it, and the same question can be asked about the strategy. Why should the strategy go on producing itself for the rest of their life?

Every thought that finishes leaves something behind. When a thought ends, the next thought is a separate thought, so whatever a thought was still carrying does not travel forward into the next thought. What the thought was carrying is laid down instead. The next thought arises out of what previous thoughts have laid down. Some of what was laid down is noticed again and meets a fate of its own. What a burial laid down is not noticed again, because the turning away comes before the noticing.

Call what they have laid down the **mental deposits**.

The mental deposits are what a thought arises out of, so they set what arises and how it feels. A fixation strongly influences their content: fifty years of making the same move lays down the same kind of thing, over and over, and what arises next is drawn from that. But the mental deposits carry other influences too — what the senses have just delivered, what was being thought about a minute ago, what the day has been like. Which is why a cautious person's thought can arrive carrying anything at all, and why two people holding the same pair of fixations are not the same person.

A fixation seems to be a habit, a shape the mental deposits have taken. Habits are part of the mental deposits.

That is an answer to why a fixation holds, and it is not an answer to what a person is. Mental deposits that have laid down the same move for decades go on laying it down, and a person who has been doing one thing for decades is, for all ordinary purposes, someone who does that thing. The fixed type is not a simplification being tolerated here. It is what this mechanism produces.

## Chapter 17: The Health Axis

Two things have to be put together. The orientations are in hand already: the orientation a person holds toward each of the two realms, which is what fixes their type and shades it with a lean. The second is an axis of health, running from clearest functioning down to breakdown.

The scale itself is not this book's. It is the Levels of Development described by Don Riso and Russ Hudson, borrowed here and used as a measure of depth. Depth of fixation was matched to their levels by reading their descriptions of each level, not by watching people. Their scale runs from 1 to 9 in three bands of three: healthy, average, unhealthy. Each level carries a fear and a want of its own, and each of the nine types has its own description at every level. Those descriptions are the substance of their work and are not reproduced here. They are published in *Personality Types: Using the Enneagram for Self-Discovery* and in *The Wisdom of the Enneagram*. What is used is the shape of the scale and the names of its rungs.

Two things should therefore be read differently. The scale is theirs and can be checked against their own descriptions. What follows about what moves a person along it is this book's, and stands or falls on its own.

Riso and Hudson call the fear at the head of the chain the basic fear. Every fear further down is a fear of failing at the strategy taken up to cope with the fear one level above. The fear at the head is the one with no fear above it and no strategy to fail at. What makes it basic is that position and nothing more. Each of the nine types has a basic fear of its own, and which fear belongs to which type is part of the description not reproduced here.

### The nine rungs

| Level | Name | What holds at it |
|---|---|---|
| 1 | Liberation | The basic fear has been seen through. What want remains is the want to be free of beliefs already recognized as illusory. |
| 2 | Psychological capacity | The want has quietly substituted itself — no longer freedom, but whatever the person believes will bring it. A solid sense of self forms around it. |
| 3 | Social value | What were aspirations set into rules, and new aspirations form on top of them. Others now meet a persona. |
| 4 | Imbalance | The sense of self is solid enough to be defended by overriding others, and it is rarely questioned. This is the entry to the descending slope. |
| 5 | Interpersonal control | In a world no longer questioned, other people appear as means to the person's needs. Interactions visibly begin to fail. |
| 6 | Overcompensation | As those failures harden, blame and resentment take over, and self-centeredness stops being a trait and becomes a justification. |
| 7 | Violation | The survival of the self-image is under threat and its protection becomes paramount. Behavior turns reckless. |
| 8 | Delusion and compulsion | Anxiety forces the denial of reality. The effort shifts from coping with what is there to replacing it. |
| 9 | Pathological destructiveness | Even threats to the delusion are intolerable. Defence of the self-image outweighs any concern for the future. |

### The process that produces the levels

Riso and Hudson also describe the process that produces the levels, which they call the core dynamics. A fear that is not settled leads to a want for whatever the person believes would secure what the fear anticipates losing. Riso and Hudson call this want a desire. The want is taken up as an attitude, the attitude produces behavior, and the behavior brings a fear of its own: the fear of failing at the strategy.

At first the person knows what the new want is for. Suppose a person who fears not being safe comes to believe that money will make them safe. The person wants money, and knows the money is for safety. But every thought of what the money is for brings the fear about safety with it. The discomfort of that fear turns the person's attention away from the connection. Over time the connection stops being noticed, and the person wants money for its own sake. The fear about safety has been blocked, and the want for money now covers the fear.

That is how a person goes down a level. The fear above is blocked, and what is wanted below is taken as wanted for its own sake. Ignoring does not move a person down, because an ignored fear stays in view.

Descent is fear turned into want, over and over, each level a strategy for coping with the one above it. Descent is seeded at the top by the basic fear. Like every fear, the basic fear has a want behind it. Descent ends at the bottom when the basic fear is finally realized.

The basic fear behaves like any other fear. What a basic fear is about is the person themselves, rather than a matter in the physical realm or the psychic one. An ordinary fear takes the realm of the matter the fear is about, and a fear about oneself takes no realm. A basic fear reaches the detached phase like any fear, and meets one of the same four fates. Seeing through the basic fear, which is what holds at Level 1, is that fear noticed and looked into.

In the healthy and average bands, Levels 1 to 6, the blocking is mostly discomfort blocking. A fear that matches the blocked fear can still be noticed there, and the person can choose to look at it. Material blindly blocked in childhood is carried at every level, and anything leading toward that material is turned away from blindly, at whatever level the person stands on. Fresh blind blocking is possible at any level but less likely in Levels 1 to 6, and it is most likely where something touches material blindly blocked in childhood. Fresh blind blocking belongs mostly to the unhealthy band, Levels 7 to 9.

Panic can happen at any level, and it can happen very early in life. A small child can be brought to panic by very little, and what is buried then stays buried until it is faced, like any buried fear.

The process fixes which fears and wants sit at which levels, and in what order. The process does not fix how a person moves between the levels. Whether a person goes down, stays or climbs, and how fast, is set by other things, just as the direction of movement around the cycle is.

Two properties of the process matter most.

It conserves the original want. Each new want is a means to the want before it, with the connection out of view. What the person aims at changes at every level. What the aiming serves does not. The deeper the level, the more connections are out of view, and the less of the original want is visible. Near the bottom, the want of an early level can come back as a fear that the thing wanted is now out of reach. In the example, a person far down may come to fear that they will never be safe.

The process also hides its own working. At each level down, one more connection between wants goes out of view, so the person sees less of what their wants are for. That is what makes a deeper level less healthy.

Climbing requires seeing the present want as a covering over an earlier one. Where the connection went out of view through discomfort blocking, a matching fear can bring it back into view. At the lowest levels, connections go out of view through blind blocking, and the blindness loop keeps them out of view. So a climb depends on seeing, and the descent wears seeing away.

### The correspondence

Now set the two side by side. Take the nine named positions of the orientations — each at its pure point and leaning each way — and read the Levels from the top down, watching what a person is like at each. It falls from full sight, through wariness, through recklessness, to blindness. That is a walk through the orientations, from the caution end of detachment, through caution, through appetite, to the enthusiasm end.

| Riso and Hudson's Level | What a person is like | Orientation |
|---|---|---|
| 1 — Liberation | full sight | ≈ Z− — detachment that still sees |
| 2 — Psychological capacity |  |  |
| 3 — Social value | wariness | ≈ B — caution |
| 4 — Imbalance |  |  |
| 5 — Interpersonal control |  |  |
| 6 — Overcompensation |  |  |
| 7 — Violation | recklessness | ≈ A — appetite, unqualified |
| 8 — Delusion and compulsion |  |  |
| 9 — Pathological destructiveness | blindness | ≈ Z+ — detachment as refusal |

Those four are landmarks and not a rung-by-rung key. All four are approximate, and the levels between them shade from one to the next, so there is nothing to gain by fixing an orientation to every level. The claim is that health and orientation run in the same direction, from the caution end to the enthusiasm end — not that each Level is a particular orientation.

This is an observation. Two nine-point descents, drawn independently, fall in step. It is recorded because it is there, and everything offered below about why it should be there is interpretation held to a lower weight than the observation it explains.

One thing the correspondence does not say. It does not say that a healthy person is detached, or that a person fixed at appetite is thereby unhealthy. What corresponds appears to be how much of what is there a person actually notices. On the cycle, what goes unnoticed is what the pull of a want or a fear leaves out. On the health axis, what goes unnoticed is what blocking has taken. Both scales take away from the same whole, and both run in the same direction.

### The same nine names, two different shapes

The nine labels now name two structures, and the structures are not alike.

For the orientations the sequence lies on a cycle. Every position has two neighbors, there are no ends, and the cycle closes: from the enthusiasm end of detachment the next step is appetite again. For the Levels the same names mark a bounded range. Level 1 is a genuine top and Level 9 a genuine bottom, and there is no step from the bottom back to the top. Pathological destructiveness does not sit one step away from liberation. On this axis the positions do not wrap.

The positions on the cycle can be treated precisely. The Levels have the same order and cannot — no level can be assigned a definite orientation. That looseness holds of every statement about the Levels.

The rungs are also not units. What the axis measures varies continuously, and a rung is a stretch of it wide enough to recognize. A person is usually between rungs rather than on one, and moves by amounts far smaller than a rung.

### What the axis is toward

The correspondence stands on its own. Why the levels should follow the orientations at all is a harder question.

Follow the object of the wants down. At Levels 1 and 2, the want relates to the person themselves, and the basic fear is a fear about oneself. At Levels 3 to 6, the want relates to the world: to other people, and to physical matters such as money. At Levels 7 to 9, the want relates to the person again, but now to the person's self-image, which is defended against reality. Near the bottom the world has almost gone, and the person is shut inside their own condition.

That is the axis's object: not the realms but oneself. A person holds an orientation toward the physical realm and an orientation toward the psychic realm, and those two fix the type. Separately, a person has their own two fixations to deal with — the chain of fears and wants their type runs on, met as their own case. How that goes is what the axis tracks. So the same nine-position pattern appears three times: toward the physical realm, toward the psychic realm, and, loosely, in how well a person deals with their fixations.

The third is not a third orientation standing beside the other two, and it is a different sort of quantity. The two realm orientations are alike — two relatively free ways of facing the world. Where a person sits on the health axis is not an orientation freely taken but a place arrived at, the settled result of how the fixations have been handled over a long time.

Read this way, the independence of depth and direction stops being a rule laid down and becomes a result. They differ because they are about different things. A Six's caution toward the world says nothing about how well that person handles their own Sixness.

### The two ends, and what lies between them

Both ends of this axis are detachment. The person who notices most and the carefree person who notices least are both Z. From outside the two can look similar — both untroubled — so the two are often mistaken for each other. In how much a person notices, the two ends could hardly be further apart. What separates the two ends is the range between possible leans: one detachment with two directions of lean, and how much of a realm a person notices varying along the range. Noticing most and noticing least are the two extremes of the range of detachment.

### Where a level change can happen

A person's place on the health axis does not drift. It changes in one phase of a process — the detached phase. In the detached phase a fear meets its fate, and the fate is what changes the level.

Three of the four fates leave the level where it was. A fear worked through, a fear given up on and a fear ignored are all in view, and none of the three takes anything from what a person notices. Most of a person's life is lived this way. The unease loop is lived this way too. Every turn of the unease loop is worked through and nothing is blocked, so the unease loop can keep a person uneasy without moving the person down the health axis.

A person falls when fears are blocked. A person rises when blocked fears come back into view and are faced. One fear blocked or faced is a small change, and a full level takes many.

A fear blocked by discomfort can come back into view when a matching fear is noticed, and the person can then choose to look at it. A buried fear is harder. Before a buried fear can be seen, the person has to bear the fear of looking at the buried fear. The blindness loop keeps a buried fear out of view, and the person turns away as if the pain associated with the fear that arises when facing buried material would be unbearable. So a climb through buried material is rare.

### What a level is made of

Blocked fears accrue one crossing of the detached phase at a time. A level is not the work of one crossing. A level takes many crossings, and what stands at a level is all of them together.

In Levels 1 to 6 most of the blocking is discomfort blocking. A fear blocked by discomfort is no longer noticed, but it leaves no blindness. A later fear like it can still be noticed. In Levels 7 to 9 more of the blocking is burial. Each burial puts one thing out of reach, and anything that would lead to the buried thing goes out of reach as well. So the part of a person's world that can still be approached shrinks with every burial.

Blindness comes only from burial. But blindness left by earlier burials, including burials in early childhood, operates at every level.

The order of the levels is fixed. What was laid down at one level was laid down before anything at the level below it, because the level below was reached by covering what was already there. The oldest material a person carries is from the highest they have been, and the newest from the lowest they have reached.

What is covered is not gone. A level a person has stood on stays available to them as memory — they can bring back what they saw from there, and how the same matter looked at the time. What they cannot do is work from there. How a person functions is set by the level they are standing on, and a clear recollection of a higher one supplies nothing to act with.

A climb of any real distance through buried material is measured in years. Each level is healed on its own, and the only one available to be worked on is the one a person is standing on. What lies above it is reached through it, in order, so a long climb takes the time and work of every level between, one at a time.

## Chapter 18: Falling and Rising

### What actually descends

One thing moves on this axis, and it is not how much a person suffers or how hard they are trying. It is how much of their own condition they notice.

It moves in fractions of a rung, one crossing of the detached phase at a time. Each fear turned away from until it is no longer noticed takes a little of the noticing with it, and the amount is small — far smaller than a level. **There is no event of collapsing.** A person at the bottom did not fall; they crossed the detached phase some thousands of times, and each time was unremarkable. This is why nobody can name the moment. There was no moment.

Three things set the rate, and they are independent of each other.

Where the person's fixation sits in the realm the fear came from is one. A detached person leaning toward caution gives the caution end the most attention, and an arriving fear is more likely to be settled before the fear reaches the enthusiasm end. A detached person leaning toward enthusiasm gives the caution end little attention.

How much the earlier part of the process left standing is another. What arrives unprocessed is what there is to turn away from.

What a person has learned about handling fear is the last, and that was learned from other people.

So the fall cannot be read off a person's position alone. Someone can sit where the falling is easiest and fall slowly, because little is reaching the detached phase to be turned away from.

Where the fixation sits and what the process left standing are both facts about the person alone. What a person has learned about handling fear came from somewhere else — from parents, from teachers, from friends, from anybody who was good at it and close enough to be copied.

What is learned is a skill rather than a motive. A motive is what makes a person notice one part of a realm. A skill is what a person can do with the part once the part has been noticed.

At the caution end a person is already willing to look at an arriving fear, and the skill is knowing how to settle it. At the enthusiasm end a person is turning away from the fear, and the skill is knowing that turning away from a pain does not produce the pleasure they are turning toward.

The skill at the enthusiasm end is the harder of the two to use, because turning away is automatic and the relief it brings is real every time. But a skill laid down as a habit can act as fast as the turning away does. A habit is laid down beneath understanding, so it keeps running without anything having to be believed at the moment it is wanted. So a skill for handling fear has to be installed long before the moment it is needed. Urging a person at depth to face what they have buried does nothing.

None of this puts anything new on the health axis. The level a person stands on is still a running total of what happened each time the person crossed the detached phase, and depth is still reached by handling fear over time rather than directly. What was learned from outside changes how often a fear gets handled instead of being blocked, and so how fast a person sinks. It acts on the rate and leaves the measure alone.

### Leaving fears unweighed

A fear can also be noticed and admitted, and then left unweighed. Nothing is turned away from and nothing is hidden. Each time the fear is raised, the fear is noticed and its pull is felt, and what stops is the weighing. The person is not blind. They know it is there.

Done once, that is a problem left for later. The fear itself does not wait — it comes back when the problem is met again. Done enough times it stops being about any particular fear and becomes a general habit of not taking the question up, and then it runs on whatever arrives.

What decides whether it can continue is urgency, and urgency is not a line with ignoring on one side of it. It is a slope. A problem with no consequences attached can be left indefinitely. As consequences gather, each time the problem is met it raises a stronger fear. At some point the fear can no longer be left. The fear has to be weighed or turned away from, and which happens depends on how much sight is left by then. The habit of not taking things up is therefore not a way of avoiding the detached phase. It is a way of arriving at the detached phase with more to lose.

### Discomfort blocking and the fall

A fear can also be blocked without panic. The fear can be borne, but facing it is uncomfortable. Each time the fear comes near, the discomfort of the fear turns the person's attention elsewhere. A habit of turning away builds until the fear is no longer noticed. This is discomfort blocking. A fear blocked in panic, all at once, is blindly blocked.

Discomfort blocking takes a person down, a little at a time, as blind blocking does. In Levels 1 to 6 it is the usual way down.

Discomfort blocking forms no blindness loop. A later fear that matches the blocked fear is turned away from by habit, but the later fear can still be noticed, and the person can then choose whether to look at it. Looking is uncomfortable, but the discomfort can be borne. So a person can rise through material blocked by discomfort alone, one fear at a time.

A fear blocked blindly is a buried fear. A buried fear is faced alone only when staying has become unbearable. Help from outside can bring the facing sooner.

### What falling takes from capacity

Falling lowers how much a person can bear, and falling does so by adding stress. Three things produce the stress.

The first is that what is not seen is not taken into account. A person acts on the part of their situation they noticed, and makes no allowance for the part they turned away from. So things go wrong in ways they had no way to expect, and each of those is one more thing to handle.

The second is that what is buried goes on producing anxiety. The anxiety is felt without being understood, and an anxiety that cannot be traced to anything cannot be addressed. What it forces instead is a reaction that has not been thought out: something has to be done, there is nothing to aim at, and whatever is nearest gets done.

The third is that a person who is less able to handle life than others are perceives being less able as a threat. Blocked aversions lead to things going wrong unexpectedly, and to reactions that have not been thought out. Together, the two can leave a person less able to handle life than others are. The person goes on perceiving the threat as long as the situation persists.

All three lower how much a person can bear. When a person can bear less, the discomfort of a fear is larger against what the person can bear. The next fear is then more likely to be turned away from, by either kind of blocking. So the descent feeds itself: each fear turned away from leaves a person readier to turn away from the next.

Under stress, a person looks more like the orientation behind their own. A cautious person under stress panics, and acts without weighing. Acting without weighing looks like enthusiasm.

Stress cuts short the work of a person's own phase, and the person acts on what is in hand unworked.

A cautious person's work is the examining. A cautious person under stress stops weighing and acts on a fear that was raised and never weighed. Acting on an unweighed fear is the panic.

A detached person under stress seems to stop settling the fears that arrive. The problems behind the fears are left standing, so the same fears are raised again and again, and a person whose fears keep being raised worries.

An enthusiastic person under stress seems to stop short of acting, so nothing new arises. What shows is a detached phase with nothing arising out of the detached phase, and the person looks detached.

### Spoiled arrivals

An arrival reached without living the passage that leads to it is spoiled: anxiety in the place of alertness, brittle energy in the place of appetite. A spoiled arrival is a quality of that one arrival. It passes, and nothing of it stays. Blindness is not like that — it accrues, it happens in the detached phase and nowhere else, and it locks. The two coincide at the arrival into detachment, which is what makes them easy to run together.

### Two things that cannot happen

**Nobody watches themselves go down.** A person may feel the discomfort of a fear, or the panic, at the moment of turning away. What the person does not notice is the going down itself. Each step is small, and what each step takes away is noticing. So the loss cannot be seen from where the person ends up.

**A fall cannot bring insight.** Insight adds to what a person notices, and every step of a fall takes something away from it.

### The last stretch

The bottom rungs are one goal reached three ways, and the goal is not to know.

First it is reached by acting — action fast enough and reckless enough to drown out the knowing, which works while the action lasts. Then by remaking the world, so that the delusion has somewhere to stand and nothing arriving can contradict it. Then by exhaustion: the organized effort that held the first two together runs out, and what is left is destruction with nothing to aim at, including oneself.

### Why this does not take everyone to the bottom

Set out so far, the mechanism has a hole in it. The lower a person is, the less able they are to dissolve a fear; and the disturbance that needs dissolving is produced by the same act that must not be examined. Nothing in that turns around. Everyone should end at the bottom.

They plainly do not. Most people sit somewhere in the middle of the range and stay there for decades. Two things gather people in the middle. The fall is slow, and something pushes back.

**Consequences do.** People struggle harder when things go badly. The trigger for that is not any recognition of one's own state — it is the job lost, the money gone, the person who left. Blindness destroys the ability to see one's own condition. It does not reach the job. So this keeps working all the way down, and a person can be driven to struggle without any idea what they are struggling about.

So blindness does not weaken a person's response to consequences. **Blindness decides where the response goes.** A person struggling against consequences can put the effort into fixing what is failing, or into hiding the failure from themselves. Both take real work. So a person far down can be making an enormous effort and still be falling. The effort is real, and some of the effort is going into the hiding. What blindness takes away is aim, and the energy is still there.

The routing is not a choice. What decides is which is more painful for a person: staying as they are, or facing what they avoid. The pain on either side can be physical or psychic. Before a dentist was within reach, a person with a bad enough toothache would pull the tooth out themselves. The person took on the pain of pulling once the toothache had become worse than the pulling would be. The comparison is made below consciousness in every case, the toothache included. With a toothache both pains are in view, so the person can say afterwards what was weighed.

With a buried fear, the two pains a person weighs are very different. The person reacts as if the pain associated with the fear that arises when facing buried material would be unbearable, without being aware of the reaction. The pain of staying as the person is, by contrast, is felt now, and keeps rising. The person cannot compare the pain of staying with the imagined pain associated with facing buried material, so the comparison does not settle. What settles the comparison in the end is desperation. The pain of staying rises until staying is unbearable too. Only then is the person open to trying something new. Facing the buried fear is one thing the person might try, and nothing makes facing the first thing the person tries. When a person does face a buried fear, the pain of staying is what drove the facing. To the person, facing seems to be what causes the pain, though the pain came first.

Most people carry material buried in early childhood, whatever level they stand on. So facing buried material is painful at every level.

The comparison also gives the pushback its shape. As consequences accumulate, the pain of staying rises, and at some point staying becomes unbearable. The person is then open to trying something new. The force grows with the distance fallen. So the force is one of the two things that gather people in the middle rather than at the bottom.

Consequences do not arrive and then pass. A lost job stays lost and a person who has left stays gone, so the pain of a fall keeps building rather than arriving as a series of separate blows. So the pain of staying is present the whole time, and the pain of staying is greater the further down a person has come.

That raises a question. Against a force like that, nobody should go on falling at all. A rising pain of staying does not stop a fall until staying becomes unbearable. Short of that point the pain of staying adds stress, and stress lowers what a person can bear, so the fall can speed up. The pain of staying slows the fall only sometimes. It can make a person more careful about relieving discomfort with automatic reactions, but only if the person has some understanding that their own blindness is part of the problem. The fall is slow for other reasons. A level is made of many blocked fears. A fear is blindly blocked when it is more than the person can bear, and blocked by discomfort when looking at it is uncomfortable. Few people reach the bottom, because getting there takes many years of blocked fears.

The pain of staying grows for the same reason the fall does. What is not seen is not allowed for, so the further a person has fallen the more goes wrong in their life. Every one of those lowers how much they can bear, which is what carries the fall. Every one of them also raises the pain of staying, which is what pushes back.

The same comparison sets where a person stops rising through buried material. New consequences stop arriving, and the pain of old consequences fades — slowly, because the same persistence that built it holds it in place. So the pain of staying falls as a person climbs, and falls gradually.

That slowness is what makes a climb through buried material possible. If the pain of staying dropped away as soon as a person stopped generating new damage, the comparison would flip straight back and they would settle again at once. Because it drains slowly, the pain of staying is still high for a long while after the damage has stopped, and that is the stretch in which the climb happens.

The imagined pain associated with facing buried material does not fall along with the pain of staying. However high or low a person stands, the person reacts as if the pain associated with the fear that arises when facing buried material would be unbearable. So a climb through buried material ends when staying stops being unbearable, and that is the middle.

How the comparison ever gets made is a harder question than the comparison itself. Sitting down and weighing the two is precisely what the blindness has made unavailable — one of the terms is not there to be weighed. So the comparison is not made deliberately at all, at least not at first.

What blocking stops is the noticing, and it never stops the taking in. A person who turns away from their own condition has taken that condition in all the same, and the turning away is taken in with it. Both are laid down. So a moment of clarity that the person turns away from is not lost — it was taken in, and what is taken in is laid down.

That is how the recognition builds. A person goes on taking in the damage the blindness is doing, moment after moment, without noticing it in any of them, and all of it is laid down. Some of it a person half knows. What raises the rest into view is the pain: consequences accumulate over the same years, and under enough of them the recognition can finally be noticed.

That is also why leaving a rung through buried material takes so many turns. The turns are not repeated attempts at one thing. They are the time it takes for enough to be laid down.

The recognition still depends on what happens in the person's life. The recognition comes into view under painful consequences. Far down, a person feels the consequences but cannot connect them to their own condition, so the recognition rarely comes without help.

### What reaches someone who cannot see their own condition

A person feels a consequence whether or not they understand where it came from. The job is gone, and that hurts. All of the felt pain counts toward the pain of staying, whether or not the person connects the pain to their own condition. So the pain of staying goes on rising however far down a person is.

Far down, the pain of staying still rises until staying is unbearable. At that point the person is open to trying something new. But a person far down cannot see their own condition, so facing the buried fear is unlikely to be the first thing the person tries. The person may still come to facing the buried fear alone. Someone who can see the person's condition makes facing more likely, and some help of that kind is common, because friends keep trying to help.

What reaches a person who cannot see their own condition is another person, an intervener, working by opposite means. Consequences work as force and bypass sight entirely. An intervener works through sight, and works on what the person can bear.

A fear is blindly blocked when it is more painful than the person can bear at the time. Two things decide whether it is. One is how much they can bear, which stress has already lowered by the time anyone arrives. The other is how much of the fear comes at them at once. An intervener can change both.

An intervener who steadies someone has changed the first: a person who is calm bears more than the same person alarmed. An intervener who gives the truth a little at a time changes the second. Blind blocking happens when something is detected as a threat. In small enough amounts, no part of the truth is a threat by itself. So no part of the truth is blindly blocked, and what arrives can be looked at. Steadying and small amounts also make discomfort blocking less likely, because each makes a fear's discomfort smaller against what the person can bear.

Sizing the amounts takes sight of the truth being given, so an intervener has to be able to look at it themselves — which is usually why it is someone who has been where the person is. That sight stays the intervener's own. Nothing is handed over. What the person is given is an amount small enough to look at, and the looking is theirs.

Recognition has been the exit throughout, and the person furthest from it is least able to reach it. Intervention is how recognition reaches someone who cannot reach it themselves.

A person further down is harder to help, and two things make it so. Stress has already taken more of what they can bear, so the same steadying leaves them able to bear less than it would leave someone higher up. And more has been buried, so there is more of it still to work through.

What a person can be given at one time is limited by what they can bear at that time. Every small part of it that gets worked through leaves a little less buried, and a person with a little less buried can bear the next part. So the work goes in small amounts, and what sets the size of each is the person's own condition rather than what the intervener is willing to give.

One thing follows for anybody trying to help. Whether a person faces a fear or turns away from the fear depends a great deal on how much the person can bear at the time. Intending to face it does not make them able to, so urging asks for something a person cannot produce by deciding. Urging does worse than fail. Urging is pressure, pressure is one more thing to bear, and pressure lowers what a person can bear — so urging lowers what the person can bear, at the moment it is already lowest. What helps is steadying, and a little at a time.

### Rising

A climb happens in the same place as a fall: in the detached phase, one crossing at a time. What differs is what happens to a fear. In a fall, a fear is turned away from. In a climb, a fear that was blocked comes back into view and is faced.

The climb through buried material at any rung has the same shape as the whole ascent has at the end. A buried fear can come back into view by itself. What arrives first is not the buried fear but the fear of looking at it. The person has to bear a great deal of the fear of looking before any content of the buried fear comes into view. When the buried fear does come into view, the person faces it instead of turning away again. The gain does not arrive at the moment of seeing. It arrives on re-engagement, when the thing that was seen has to hold up against something. Whatever method a person takes up, the work is the same: one buried fear faced in one crossing of the detached phase, one rung at a time. Reaching the top means no blocked fear is left, whether buried or blocked by discomfort.

### The oldest material

Two things about the material change what the climb can be directed at. The middle of the range was laid down as ideas, so it can be met as ideas — a thing held as a fact can be given back its status as a question. The oldest material was never ideas at all. What hardens in an infant is an expectation that begins provisional, gets confirmed, and stops being tested, and it has the same structure without ever having been a proposition. There is nothing there to bring to mind and examine. The only handle is the felt quality itself.

Where fear was present, the blindness loop runs on the oldest material in the same way as on later material. Otherwise the oldest material can still reach a person through intuition: something taken in long ago is noticed later. Blocking stops the noticing. So where fear was present, intuition cannot reach the oldest material either.

That the oldest material sits deepest is not a coincidence, and not an identity either. A person who falls loses the highest reaches of thinking first, and those are the last a person learns, so falling runs roughly backward through a life. The correspondence is as loose as the one between the Levels and the orientations — near enough to be worth having, not close enough to count on.

One difference matters more than the looseness. What a person loses in a descent is distressing to lose, and the distress is part of what it is to have fallen. What a child cannot yet do distresses nobody and is no sign of ill health.

The method does not change; only what it is directed at. Seeing is what reopens a hardened thing at any depth, and seeing requires quiet, because what is to be found in the oldest material is subtle and has never been anything but background. **Calm is not the goal.** It is the condition under which anything at all is visible.

### A skill for handling fear

Facing a buried fear takes the capacity to bear discomfort. The first discomfort to be borne is the fear of looking at the buried fear. The capacity to bear discomfort can be built, and it can be built on any kind of pain, because pain is pain. A capacity built on one kind of discomfort can carry over to another.

One person described how she built the capacity. She had suffered repeated, extreme migraine pain. She learned to stop resisting the pain, and she found she could stay with the pain. The extreme pain was what pushed her to learn.

Afterwards she could also notice when she was resisting an uncomfortable feeling, and stop resisting the feeling. She had not been working on such feelings. The capacity she had built with the pain applied to the feelings as well.

Later she went further. She already understood that buried material has to be faced. What she had learned with the pain was to stop an automatic resistance. The same capacity let her bear the fear of looking, and stop the automatic turning away that kept her fears buried. With the capacity to bear uncomfortable feelings, she was able to face buried fears and release them. Both the understanding and the capacity contributed.

She could stop turning away because her fears were not too deeply buried. Her buried fears were no longer noticed. But she felt the anxiety that came when the buried fears came near, and she could stay with the anxiety instead of turning away. Other people may differ. A person whose turning away comes before the noticing has nothing to notice and stop.

Fear and pain are tightly coupled. A person fears pain, and being afraid is itself painful. So each one feeds the other. A person reacts to the two together, as one thing, without being aware of the reaction. Taken together, the two cannot be approached.

But the two can be taken one at a time. A pain can be borne. A pain that can be borne takes away what the fear was about. A fear can be borne too. A fear that is borne stays in view, and a fear in view can be given up on. Taking the pain and the fear one at a time breaks the coupling.

Not all of the work has to be done by the person who needs it. A skill for handling fear can be copied from a person who has it, and can be taught to a person who does not.

Given to a child, the skill goes in the way a habit goes in — practiced before there is any occasion for it, and running beneath understanding when the occasion comes. Nothing has to be believed at the moment the skill is wanted, and that matters, because at that moment the person is frightened and belief is not available.

A person can train to abide in the detached phase. Trained abiding acts directly on the feeling of fear, so trained abiding should make buried fears easier to approach. The feeling of a buried fear is felt even though the content is not, and the feeling is what trained abiding acts on.

Giving up on ignored aversions is the way out of lasting unease most within a person's reach. The matter behind an ignored aversion can still be noticed. The matter is available, though not necessarily in view. So the person can give up the want behind the aversion. Each ignored aversion given up on takes away some of the unease that sends a person looking for distraction. A better distraction is never a way out, because every distraction wears off.

Blocked aversions can leave a person less able to handle life than others are. For the person, the practical details of life do not work the way they work for others. Being less able to handle life is painful. That pain is called the pain of life not working. The person can see that others manage. The person might understand that something is causing the difference, and that the cause is the person's own fears.

What motivates a person to take up a skill for handling fear is the same comparison that decides a fear's fate in the detached phase: the pain of life not working against the imagined pain associated with facing buried material. Whether the material was buried before the person had words or later, a person reacts as if the pain associated with the fear that arises when facing buried material would be unbearable, without being aware of the reaction. On their own, people face buried material only once staying has become unbearable. Help can make a person face buried material sooner. An intervener who gives a person a small piece at a time, and trained abiding in the detached phase, each make facing seem bearable before staying has become unbearable. All of the pain of life not working counts, whether or not the person connects the failures to fears left unfaced. Without the connection, a person in pain is still open to trying something new. What the person tries may be anything that promises relief.

With the oldest material the connection is especially hard to make. What would come up is a feeling with no story attached. So the person cannot tell how much of the pain of life not working comes from the oldest material. So the person has little reason to think that facing the oldest material is what would help.

An adult taking up a skill for handling fear has to displace the habit of turning away, which is already running. Displacing a habit that is already running is slower, and practice is what does it, not conviction. Being convinced that turning away from a pain does not produce the pleasure changes nothing on its own. What helps is no longer being able to turn away from a pain without noticing, and practice is what brings that about.

A skill for handling fear does not put a person further up the axis. It changes how often a fear gets handled instead of being blocked. Over years, how often a fear gets handled is what decides where a person ends up.

The time such work takes is almost none of it in the change. If a thing can harden in a moment, its undoing can happen in a moment too, and what people describe is long stretches followed by a sudden shift. The years go into becoming quiet enough and practiced enough to meet a feeling as a feeling.

This is worth knowing in advance, because the wrong expectation does its own damage. Someone expecting steady progress reads a long flat stretch as failure — and that reading is itself a question closing, at an ordinary low moment, in the ordinary way. The flat stretch is not the practice failing. It is what the preparation looks like from inside. That is not a license to continue indefinitely on faith: the shift is discontinuous but the preparation is not, and the preparation can be checked on a long enough timescale. The unit is the year. Is quiet easier to come by than a year ago? Is what can be noticed finer? Those move gradually and are visible at that range. What proves nothing either way is the absence of the shift, which does not arrive on a schedule.

### What is actually being undone

All of that is method. What it is for can now be said, and it has been at stake since the first fear was turned away from.

Accepting what one is does not do it. Acceptance leaves the arrangement intact and makes peace with it, and the arrangement goes on running.

What undoes it is conscious recognition of the blocked fears — bringing back into view what was kept out of view, one at a time. A fear blocked by discomfort can be recognized when a matching fear is noticed and the person chooses to look at it. Each buried fear can be recognized only after the fear of looking at the buried fear has been borne. Recognition works, and it is local: each fear faced is one fear, in one realm, and there are a great many.

Recognition works one kind of painful thought at a time. A climb needs a person to face a particular painful thought, so recognizing something more general cannot do the work of a climb.

The capacity to turn away is not what gets recognized. Nobody learned the capacity to turn away, and everyone has it.

A person can also understand, in general, that they turn away from noticing. The general understanding is real, and it retires nothing. What the general understanding does is let a person take seriously that something is there when nothing seems to be: a reaction that does not fit, or a subject the person never arrives at. The general understanding does not do the work of recognizing one particular painful thought, and it is not a way out by itself. Understanding that gratification always wears off works in a similar way. The understanding ends the search for the behavior that would finally bring relief. The person can then take seriously that the discomfort has another source.

### The summit, and what counterfeits it

At the top there is nothing above to arrive at, so what happens there is not residence. The last crossing of the detached phase lands back in engagement, and then again, and the state is renewed rather than held.

It could not be held in any case, and the reason is the same one that runs the whole book. A state maintained is maintained by a habit of maintaining it, and that habit would need its own maintaining, and there is no floor to that. Habit is what carries a fixation and habit is what carries an attainment; it does not become a different faculty at the top of the ladder.

There is also something that looks like the summit and is not. Every thought passes through the detached phase, whatever a person's fixation. A person can train themselves to abide in the detached phase, giving the detached phase more attention than their fixation would give it. The training can be done for thoughts about one realm and not the other. No orientation is trained, and the person's type does not change.

Take a person trained to work on a bleeding body, or to keep moving under fire. At such a moment the person abides in the detached phase of thoughts about physical matters, and does not flinch or look away. The training is real, and so is the steadiness. The person reaches for the training when fear would get in the way, and uses the training as a tool at those moments. Nothing about the person's type has changed.

Take a person trained to sit with someone in the worst hour of their life and stay level, hearing what is said without being pulled into it. At such a moment the person abides in the detached phase of thoughts about psychic matters. Again the training is real, and again it is a tool used at moments. Nothing about the person's type has changed here either.

Observers see the marks of the training in one realm and take the person to be like that throughout. What observers recognize as holiness is mostly these marks — austerity, fearlessness, unconcern with comfort and pain, a steadiness nothing seems to shake. The marks are real, and the mistake is the observers'. So the attainment behind the counterfeit summit is not faked. The counterfeit summit is a genuine, hard-won attainment in one realm, wearing the visible marks of the whole one, with the person's other realm running entirely unchecked behind the attainment.

In every case the attainment is real. What can differ is whether the person makes use of how others read the attainment. Suppose a person has trained to abide in the detached phase of thoughts about physical matters. Pain, hardship and danger no longer move the person, and the person shows no fear of harm or of death. Observers take that fearlessness as a sign of clarity about the inner life as well. The training has not touched the person's psychic realm. The person still has the wants they had before about psychic matters, such as wanting to be admired or to be seen as righteous. The person may then present the fearlessness as the summit on purpose, because being taken for someone at the summit brings admiration and followers. Presenting the fearlessness that way is a fraud.

A person who has trained to abide in the detached phase of thoughts about psychic matters is no longer moved by praise, blame or other people's feelings. The person still wants money and comfort as before. The steadiness lets the person pursue those wants among other people without being moved by what those people feel. Others take the steadiness for the summit. Presenting the steadiness that way on purpose is a fraud as well. Nothing in the person checks what the attainment is used for.

Conscience is caution in the psychic realm: understanding the disadvantages of hurting others. For a person cautious in the psychic realm, conscience is their own fixation at work. While the person abides in the detached phase of thoughts about psychic matters, conscience is not raised. When the person stops abiding, conscience is there as before. A person enthusiastic in the psychic realm examines little of what their wants would do to others, so whatever conscience the person has was learned as a rule. A person who works for long without the rule may stop invoking the rule, and then stop having it. If that happens, the long working without the rule is the cause, and the training is not.

It would be reasonable to expect that training to abide in the detached phase weakens the person's fixation in the trained realm, when the fixation is enthusiastic or cautious. An enthusiastic fixation and a cautious fixation are both ways of engaging with a realm, and abiding in the detached phase works against engaging.

### Why trying harder does not change a person

Whatever a person does about their own condition, the person does it as they already are. The person can work only on what they notice, and what needs to change is what they do not notice. So the effort goes into the parts of their condition the person can already notice. That is why a person who resolves to be different so often ends up doing what they already did, just trying harder, and still failing to change.

It is also why the climb is hard. Going up means bringing into view something the person does not notice. Trying harder at what the person already notices does not bring it into view.

Help from outside works well at changing a person, in children who grow up in healthy families and in the people twelve-step programs help. In each of those, someone else helps the person see what trying harder could not bring into view.
