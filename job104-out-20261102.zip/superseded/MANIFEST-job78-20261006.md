# SET MANIFEST - job78-20261006

| File | md5 | words | bytes | scope |
|---|---|---|---|---|
| `ARC-ACCOUNT-from-job75-20261005.md` | `9d1c561d1fb4892907fe708ccefb0e68` | 1760 | 10254 | set |
| `AUTHOR-RECORD.md` | `4e784447fd40dd568605b969b297a5d7` | 77107 | 455556 | set |
| `BOOK1-INDEX-20260815.md` | `719fa862523aff52c19dd9b37738b5c1` | 4249 | 25822 | set |
| `BOOK2-20261005.md` | `d50bf9bb513b2381d319a77a60138b37` | 39839 | 225443 | set |
| `BOOK2-ARCHITECTURE-20260815b.md` | `9c693a2dcb1a8fa31ca48b983fd527a6` | 3246 | 19379 | set |
| `BOOK2-PART34-ARCHITECTURE-20260902e.md` | `f9be55105696382edc1798bb5356c218` | 14292 | 85964 | set |
| `CENSUS-book1-into-book2-20260901.md` | `24b6e82532742076ae2ef8626747b6b7` | 3394 | 19476 | set |
| `CLAIM-INVENTORY-book2-20260902.md` | `7e8210c142ee83e7b3176755548b1a58` | 31434 | 185231 | set |
| `DEFECTS-carried-forward-20260825b.md` | `af744e04643e4929290c348027dbdb17` | 1166 | 7223 | set |
| `DOCTRINE-BRIEF-arcs-and-position-20260816.md` | `e444468895e9dfec4c3baeeade579e2c` | 1310 | 7977 | set |
| `FINDINGS-job72-20260915.md` | `d673c04d75e13b6581dd6342460acf80` | 6259 | 37176 | set |
| `FINDINGS-job75-20261005.md` | `6ab61a2f53fd59cec31ca4d30e2cdcd0` | 5176 | 31166 | set |
| `FINDINGS-job77-20261006.md` | `113cce6b9ca6879f736f5ed6021a8fb4` | 4500 | 26464 | set |
| `HANDOFF-20261005b.md` | `c26f97019e530f3c47c68f70003b4e46` | 5988 | 36374 | set |
| `NOTE-doctrine-from-job61-20260909.md` | `9f131b1723c95616fe8e8b4ff125e7b0` | 3697 | 22122 | set |
| `NOTE-doctrine-from-job62-20260910.md` | `c155ecb9b2f9a6f7473b596e2589fbbf` | 1456 | 8478 | set |
| `NOTE-doctrine-from-job66-20260912.md` | `d677f57643fc7f4eb867b197f8a51289` | 1371 | 7913 | set |
| `NOTE-drafting-8-15-findings-20260816.md` | `e7bcf2b812bee733e2ce430f2ec05f5d` | 3086 | 18425 | set |
| `NOTE-fixations-arcs-and-the-two-scales-20260821.md` | `e425e1808824c9f2482080503dd66459` | 5221 | 31477 | set |
| `NOTE-level-1-and-the-summit-20260821b.md` | `ec72a16767bca3ffd9abff8e4f7cc4e4` | 2317 | 13179 | set |
| `NOTE-overlap-and-truthfulness-20260815b.md` | `afc61dc77941637d226a73e70314ec6d` | 2212 | 13109 | set |
| `NOTE-resolution-rate-and-the-descent-20260825.md` | `62f276661993f73b3e6c9c82a523608d` | 4318 | 26030 | set |
| `NOTE-small-arcs-and-the-step-20260815.md` | `f6684a123e8ed0c8ab7cf554bb1b0630` | 1110 | 6763 | set |
| `NOTE-the-dwell-and-the-brake-20260901c.md` | `de3b9ec3af662df99d714b423c91d6ce` | 3544 | 21212 | set |
| `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md` | `8afee78bf93d3c4ab2aa2f8d89b70f21` | 5238 | 31028 | set |
| `NOTE-the-two-pressures-and-misattribution-20260902.md` | `190a9583013697ff52c7f1076f25fc0e` | 1320 | 7994 | set |
| `NOTE-the-two-stacks-20260904.md` | `9a8c3a87ccbda7ea4b3e931aa139d8a0` | 971 | 6079 | set |
| `NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` | `43a176e6906332c28798838adbc5ddf0` | 6374 | 38329 | set |
| `NOTE-the-want-behind-the-fear-20260903.md` | `ab5d37fab6608acafab7708d93710189` | 6835 | 39838 | set |
| `NOTE-two-sources-of-motivation-20260908.md` | `2253d3f4d98ed5c1584bd4e2d1e8c663` | 2292 | 13082 | set |
| `OPEN-from-job25-20260829b.md` | `03d985f7338b955542f5c2419633f816` | 1696 | 10287 | set |
| `RECOVERY-NOTE-20260825b-procedural-changes.md` | `d490518f83398f9b0bc66fb958fb2a32` | 1470 | 9059 | set |
| `REPAIRS-job16-book1-defects-20260825g.md` | `76869bd3ec343428e3679f8e21f80670` | 12435 | 73559 | set |
| `RULE-referring-words-20260908b.md` | `8b3ef2778ec4d9329a31b85103feb42a` | 741 | 4344 | set |
| `SET-NOTE-from-job77-20261006.md` | `cf793c9788ba3c2865104924f9cd5402` | 754 | 5051 | set |
| `SKETCHES-rewrite-by-author-20260901b.md` | `0648673d716ae313e6526579c989a669` | 1740 | 10591 | set |
| `STYLE-GUIDE-20261005b.md` | `f958f760c312d337a07632d15ec0512c` | 3599 | 21311 | set |
| `TODO-additions-20260814.md` | `bc3813437ff4870f361b1503e28fd9cc` | 863 | 5633 | set |
| `TODO.md` | `103fb3d9114a8e7717f0d84e974d4ef8` | 2023 | 12763 | set |
| `VERIFY-20260815.md` | `508793976b3c24ee40b03a300b6e21d1` | 3375 | 20752 | set |
| `VOCABULARY-INSTRUCTION-from-job67-20260912.md` | `cfc6eedd2cfc78b923b847ee0981fd2b` | 1716 | 9786 | set |
| `WORD-RULINGS-book2-20261006.md` | `cb4dfc1e13f958342ac422bd3d62b25e` | 5449 | 34457 | set |
| `double-ahead-triangles.svg` | `82f055888144272795ac4054122e95c8` | 369 | 4875 | set |
| `enneagram-hexagon.svg` | `6c07c187d003a8b36d929b7eda57ec24` | 3044 | 22022 | set |
| `hexad-cycle.svg` | `22732ed8c2d838d692db87fea52e7e97` | 305 | 4307 | set |
| `opposite-relationship.svg` | `72171004dc26e1c7ea1f7f09811fb1ca` | 299 | 3577 | set |
| `orientation-cycles.svg` | `45a0d59bca5197f925666206eb5c20fb` | 304 | 4167 | set |
| `quotecheck.py` | `5376c1ff0aa6823dabf9baa42f5173c9` | 1391 | 11238 | set |
| `refcount.py` | `0c4eb45c3e75f1450392b755b338a4ac` | 239 | 2232 | set |
| `rev2-0814t.md` | `a6d71b1e66b2b32600aea48234c1bf2a` | 57115 | 349797 | set |
| `setcheck.py` | `657396ae74870b1a86ae6fa8c9e2614a` | 2588 | 22147 | set |
| `triad-hexad-cycles.svg` | `9025e3fe408d4a7a3140a19c37f76252` | 484 | 6783 | set |
| `two-realm-grid.svg` | `6cb3d2f61c9cdaec64e3d27a9bd6ad56` | 373 | 5055 | set |
| `wordcheck.py` | `fca4a2115167e4bb12637acfc0394865` | 356 | 3129 | set |
| `wraparound-grid.svg` | `2f4e8623cb42a6281763e7739cda0277` | 428 | 5688 | set |

**Counts are `LC_ALL=C wc -w`.** In the C locale wc does not count a token holding
no ASCII printable character, so a standalone em dash is not a word; under `C.UTF-8`
it is, and the figure runs higher. Verify md5 after copying, not before.
