# WORD RULINGS — book 2

**Letter `n`, cut 2026-10-26 by `job88 drafting 20261023`.** Supersedes `WORD-RULINGS-book2-20261019.md` (letter `m`);
quarantine the parent. Carries the rulings applied from `FINDINGS-job87-20261019.md` and from six relays of `Job81 doctrine
20261013` (`RELAY-from-job81-20261019.md`, `-20261023.md`, `-20261026.md` to `-20261026f.md`), and those `[A]` gave in
`Job88`, each with his words: **blind blocking** and **discomfort blocking**, with *buried* kept for the blind kind only;
**ignoring** does not move a person down; **the fear of looking**, restored as `[A]`'s own; **reacts as if facing would be
unbearable**, in place of *imagined to be unbearable*; the lever entry's wording replaced; *issues in* and *the rule* (for
the core dynamics) out. Section 5 gets two entries and an amended one; section 5a gets a `Job88` block; section 7's lever
entry is amended. Two patterns are added. The sites are in `CHANGES-job88-20261026.md`.

*What letter `m` said of itself, retained:* **Letter `m`, cut 2026-10-19 by `job86 drafting 20261017`.** Supersedes `WORD-RULINGS-book2-20261018.md` (letter `l`);
quarantine the parent. Carries the wording rulings `[A]` gave in `Job86`, each with his words: **perceives the
inability as a threat**, not *the perception is a threat*; the **lever figure** is out of the book (*levered*, *the
problem of leverage*); *waits on the world* is out; the book does not comment on its own account. Section 5a gets a
`Job86` block; section 7 gets an entry for the lever figure. The `consequences-unreach` pattern is widened to catch
*consequences no longer can*; two patterns are added (`lever`, `book-comment`). The sites are in
`CHANGES-job86-20261018.md`.

*What letter `l` said of itself, retained:* **Letter `l`, cut 2026-10-18 by `Job85 coherence 20261017`.** Supersedes `WORD-RULINGS-book2-20261017b.md`
(letter `k`); quarantine the parent. Carries the rulings `[A]` gave in `Job85`, several through relays from
`Job81 doctrine 20261013`, each with his words: **consequences reach a person at every depth**; **a habitual fear is
caused by unease**, not a source of it; **the inability to handle life** is perceived, not blocked, and is a **third
source of stress** in the fall; **given up on** for a fear or an aversion meeting the fate, **given up** for a want.
Section 5a gets a `Job85` block. The entry *capacity to bear discomfort* no longer calls it the way out at the
enthusiasm end, since that paragraph is cut. Four patterns are added, each firing on `BOOK2-20261017b.md`. The sites
are in `FINDINGS-job85-20261018.md`.

*What letter `k` said of itself, retained:* **Letter `k`, cut 2026-10-17 by `job84 drafting 20261017`.** Supersedes `WORD-RULINGS-book2-20261017.md`
(letter `j`); quarantine the parent. Carries the wording rulings `[A]` gave in `Job84`, several through relays from
`Job81 doctrine 20261013`, each with his words: **the pain of staying slows a fall only sometimes**; **the thin tail**
is out; **facing is not the first thing tried**, and a person may still come to it alone; **the health axis reflects
how much a person notices**. Section 5a gets a `Job84` block. The `unease-synonym` pattern is narrowed so that
`[A]`'s own sentence *there is no chronic unease* is allowed. The sites are in `CHANGES-job84-20261017.md`.

*What letter `j` said of itself, retained:* **Letter `j`, cut 2026-10-17 by `Job83 coherence 20261016`.** Supersedes `WORD-RULINGS-book2-20261016.md`
(letter `i`); quarantine the parent. Carries the rulings `[A]` gave in `Job83`, each with his words, for the vocabulary
they govern: **the pain of facing** is imagined to be unbearable at every depth; **the pain of staying** is the whole
felt pain, and at unbearable a person is **open to trying something new**; the matter behind **an ignored aversion**
is available, not necessarily in view; **chronic** unease needs buried fears or ignored aversions; **the unease loop**
names only the worked-through round. Section 5a is amended; two patterns are added. The sites are in
`FINDINGS-job83-20261017.md`.

*What letter `i` said of itself, retained:* **Letter `i`, cut 2026-10-16 by `Job82 drafting 20261015`.** Supersedes `WORD-RULINGS-book2-20261013.md`
(letter `h`); quarantine the parent. Carries the rulings applied from `CLOSURES-SITED-job81-20261014d.md` and those
`[A]` gave in `Job82`, directly or through relays from `Job81`, each with his words: **worked through** re-cut
(the thought finds what to do about the fear; the 09-03 want-ending ruling withdrawn); **a disappointment meets
four fates**, reversing letter `h`; **every fate leaves bodily tension**; **`unease`** and **the unease loop**, the
third permitted use of `loop`; **gratification**; **a habitual fear**; **the pain of facing buried material is
imagined to be unbearable**; and smaller wording rulings. Two patterns are rewritten, one removed, two added. The
sites are in `CHANGES-job82-20261016.md`.

*What letter `h` said of itself, retained:* **Letter `h`, cut 2026-10-13 by `Job80 drafting 20261012`.** Supersedes `WORD-RULINGS-book2-20261012.md`
(letter `g`); quarantine the parent. Carries the rulings `[A]` gave in `Job80`, each with his words:
**a disappointment meets three fates**, not four, reversing letter `g`'s *(stays)*; the definition of a
disappointment and the **worked through** entry, both in his wording; and **most and least** for the two
extremes of how much a person notices, in place of *top* and *bottom*. Two patterns are added. The
sites are in `CHANGES-job80-20261013.md`.

*What letter `g` said of itself, retained:* **Letter `g`, cut 2026-10-12 by `Job79 coherence 20261010`.** Supersedes `WORD-RULINGS-book2-20261009.md`
(letter `f`); quarantine the parent. Carries the word rulings `[A]` gave in `Job79`, each with his words:
**`pulls`** replaces `draws` everywhere, reversing letter `f`'s `draws` entry; **`range`** may carry two
senses where context makes clear which; **disappointment** is not an aversion and not a pain. It also
records `Job70`'s account of **regret** and **disappointment** from
`ANSWERS-for-coherence-from-job70-20261012.md`, marked as that file marks it, and marks letter `f`'s
`range` entry superseded by the flexibility ruling. Two patterns are rewritten and three added. The
sites are in `FINDINGS-job79-20261012.md`.

*What letter `f` said of itself, retained:* **Letter `f`, cut 2026-10-09 by `Job78 drafting 20261007`.** Supersedes `WORD-RULINGS-book2-20261006.md`
(letter `e`); quarantine the parent. Carries the word rulings of `ADDENDUM-job77-20261007.md` and
`CLOSURES-SITED-job70-20261009c.md`, each with `[A]`'s words: **`aversion`** is no longer reserved to
the cautious phase, and **attraction** and **aversion** are the two most general kinds of motivation;
**a pleasure** is never what a want is for; **`desire`** takes no technical sense; **`brake`** is not
used in the book; **the grab** leaves the book; **capacity to bear pain** is one capacity for the whole
person. Two entries are `Job70` workings that the closures file recorded without his words, confirmed by
`[A]` to `Job78` (*all ok.*): **`draws`** for the relation between motivation and noticing, and how much
pain an event produces as what differs between the realms. Four patterns are added and one is
rewritten for `wordcheck.py`.

*What letter `e` said of itself, retained:* **Letter `e`, cut 2026-10-06 by `Job77 coherence 20261006`.** Supersedes `WORD-RULINGS-book2-20261005b.md`
(letter `d`); quarantine the parent. Seven entries are added from rulings `[A]` gave in this session, most
by accepting an answer of `Job70 doctrine 09152026` that he carried in: **`reflex`** is only the defined
reflex, and the turning away is **automatic**; **`decision`** is the conscious kind only; the act that
blocks is **turning away from noticing**, superseding letter `d`'s *turning away from looking*; a fear is
not itself the **disturbance**; what a detached person wants is **peace**, and the enthusiasm end's want
is getting away from discomfort; a **fixation** is the hardened orientation, and concentrated attention
is its result; and **what a burial lays down**. The sites are in `FINDINGS-job77-20261006.md`. Four
patterns are added for `wordcheck.py`.

*What letter `d` said of itself, retained:* **Letter `d`, cut 2026-10-05 by `Job76 drafting 20261005`.** Supersedes `WORD-RULINGS-book2-20261005.md`
(letter `c`); quarantine the parent. One ruling added, given by `[A]` in this session on a
recommendation from `Job70 doctrine 09152026`: **`settled`** keeps its ordinary sense and belongs only
to the two fates that end a fear, and **`meets its fate`** is the wording for reaching any of the four.
The `settled` entry in section 1 is rewritten, and one pattern is added for `wordcheck.py`.

*What letter `c` said of itself, retained:* **Letter `c`, cut 2026-10-05 by `Job75 coherence 09232026`.** Supersedes `WORD-RULINGS-book2-20260923.md`
(letter `b`); quarantine the parent. Merged into letter `b`, in date order, from nine `Job70`
doctrine files — `CLOSURES-SITED-job70-20260923c.md`, `CORRECTION-to-job70-closures-20260923.md`,
and `ANSWERS-for-job75-from-job70-20260923.md` and its letters `b` to `g` — and from `[A]`'s rulings
in `Job75` itself. **Where those files proposed an entry and a later one, or `[A]` in `Job75`,
overrode it, only the survivor is here.** `Job70`'s files speak of merging into *the 09-16
register*; that was the copy `Job70` held, and letter `b` was the live one. Every change in this
letter is listed in `FINDINGS-job75-20261005.md`, which is the authority for its sites.

*What letter `b` said of itself, retained:* **Letter `b`, cut 2026-09-23 by `job74-drafting-20260919`.** Five rulings of 2026-09-21 to 09-23 are
added: `crossing` retired, `how far` for the size of a lean, what a climb is, `aversion` reserved to
the cautious phase, and what an orientation is.

*What the 09-16 cut said of itself, retained:* **Cut 2026-09-16 by `Job72 coherence 09152026`, at `[A]`'s request.** One place for every ruling
about which word book 2 uses for what. It sits beside `STYLE-GUIDE-20260908b.md` and does not
replace it: the style guide says how to write a sentence, this file says which word names which
thing.

## How a drafting session uses this file

1. Read it before writing any prose, together with the style guide.
2. Every sentence written or changed is checked against it.
3. **Only entries marked RULED are applied.** An entry marked `[C]` is a Claude reading that `[A]`
   has not ruled on. Do not act on it without asking him. *This rule exists because Job71 applied
   Job70's unruled reading on `attention`, and that reversed his 09-12 ruling.*
4. At the end of the session, run `python3 wordcheck.py BOOK2-<date>.md` and read every hit. The
   script flags words; it does not decide. A hit on an ordinary-English use is fine and is left.
5. **A new ruling on a word goes into this file in the same session**, with his words, and the file
   takes a letter. A word ruling that lives only in a repairs or closures file gets lost — that is
   how the `dwell` reversal happened.

Each entry: the word · what it names or what replaces it · date · his words where recorded.

---

## 1. The process and its parts

- **passage** — RULED 09-15/09-16. The move from one phase to the next. *What I call a passage.*
  Three passages, and only these names: **the arising** (detached phase to enthusiastic phase),
  **the development** (enthusiastic phase to cautious phase), **the ending** (cautious phase to
  detached phase). `[A]` 09-16: *ch14 should say phase, not orientation*; *"arising, the
  development and the ending" are good.* A passage is described in terms of phases, never
  orientations and never letters.
- **phase** — RULED 09-13, 09-16. The three phases are **the enthusiastic phase**, **the cautious
  phase**, **the detached phase**, and have no other names. `[A]` 09-16: *the detached phase should
  be called detached phase.* The adjectives are shared with the orientations on purpose; never let
  a bare adjective or bare orientation noun stand where a phase is meant (09-13: *Enthusiasm that
  cut the examination short…* was the caught case).
- **impulse, examination, resolution** — RULED 09-16: not names for anything. `[A]`: *these are
  transition names, not phases. and examination isn't right*; *resolution is another name for
  ending.* Rewrite to the passage or phase name. *An impulse arises*, meaning the thing that
  arises, is ordinary English and stays.
- **ending** — the passage only (RULED 09-16). Where a sentence means the place a process comes to
  rest, the word is *the detached phase*.
- **crossing** — **RETIRED 2026-09-23.** `[A]`: *crossing refers to the whole detached phase and
  from Z- to Z+ in particular. but it doesn't have a sharp placement. it would be better to use
  detached phase than crossing.* So the noun is not used for a place; the word is **the detached
  phase**. The verb form stays, for one pass through: `[A]` *you could say crossing the detached
  phase*, and a countable use is *one crossing of the detached phase*. Applied at every site in
  Ch 15, Ch 16 and Ch 17 by `job74`. Two other senses are untouched: things crossing between a
  person's two realms, and a crossing relation on the figure.
- **the phases are split by the passages** — RULED 2026-09-22. Each phase lies between two passages
  and has two halves, one overlapping the passage that begins the phase and one overlapping the
  passage that ends it. `[A]`: *all phases are split - enthusiasm starts with arising and ends with
  development - in particular detachment starts with ending and ends with arising and that is the
  Z-/Z+ split of detachment.* The **caution end** of the detached phase is the half overlapping the
  ending, and the **enthusiasm end** is the half overlapping the arising. Written at Ch 14's
  opening.
- **process arc** — a single run through the passages; **cycle** — the closed round of the three
  orientations (style guide §8). RULED 09-15: `loop` is not used for the cycle or the triangle.
- **scale** — the size of a process (a thought, an undertaking, a character). RULED 09-13: defined
  at first use in Ch 7. `recursion` is out of the book (09-13: *why even mention it?*).
- **Thoughts** are best described by the passages they make (RULED 09-16, Ch 7).
- **where action comes** — placed by the motive behind it: going toward at the enthusiastic phase,
  fending off at the cautious phase, and the same outward act can be either (RULED 09-16). **A
  detached person's actions are placed the same way** (RULED 09-23, `[A]`: *Z- fixing is fending off
  and Z+ changing the subject/distraction/ignoring is a want*). Never write that a detached realm
  releases no action, or that every detached action comes at the cautious phase — `Job70` recorded
  that as ruled and `[A]` never said it.
- **grab** — **out of the book** (RULED 2026-10-09 in `Job70`, recorded in `CLOSURES-SITED-job70-20261009c.md`
  C2: `[A]` ruled after asking whether the book needs it; panic stays). Both uses were in the extremes
  paragraphs of *The range of detachment*, removed by `Job78`. The entry below is history for the grab.
- **reflex, panic, grab** — a **reflex** raises no want (a hand off a hot pan, catching a falling
  glass, a flinch). **Panic** and a **grab** are both thoughts whose examining is cut short, never
  reflexes (RULED 09-16 for panic; RULED 2026-10-05 for the grab, `[A]`: *i agree*). Panic acts on a
  fear (09-23, *on fear*) and its action comes at the cautious phase; a grab goes toward and its
  action comes at the enthusiastic phase.
- **reflex** and **automatic** — RULED 2026-10-06 in `Job77`, `[A]` accepting `Job70`'s answer: *go
  with doctrine's answer.* A reflex is an act no thought produced, even when a thought is in
  progress. **The turning away answers a fear a thought raised, so it is automatic, never a
  reflex.** `Job70`'s sentences, accepted with the answer, go where the reflex is defined: *A reflex
  and an automatic turning away are both unchosen, and they differ in what brings them on. A reflex
  answers nothing — no thought raised anything, and the body moves. A turning away answers a fear
  that a thought raised.* Where the book means the learned pattern, as in *displace a reflex that is
  already running*, the words are **the habit of turning away**.
- **settled** — **RULED 2026-10-05 in `Job76`: `settled` keeps its ordinary sense, and is used of a
  fear only for the two fates that end it — worked through and given up on.** Where the book means a
  fear reaching any of the four fates without naming which, the wording is **meets its fate**. `[A]`,
  on why: *settled wrongly implies ending in a healthy way*; and to the recommendation to keep
  `settled` for the two fates that end a fear and say *meets its fate* for all four, *yes, the
  second.* An ignored or blocked fear is never called settled. The names of the four fates do not
  change.
- **only at the ending** — a fear meets its fate only at the ending (RULED 2026-10-05 in `Job75`,
  `[A]`: *what's wrong with "settled only at the ending"?*, now read under the entry above). **Do not
  write *worked out before the ending*** (`[A]`: *i don't like "worked out before the ending"*), and do
  not move it inside the cautious phase as *worked out during the examining* (`Job70`'s draft in
  `Job76`, withdrawn by `Job70`). A cautious person *examines* heavily before the ending. `Job70`'s answer,
  relayed by `[A]` in `Job76`: *the examining only looks at the fear. The settling comes at the ending,
  always.* What heavy examining changes is the state the fear reaches the ending in (`[A]`'s ruling of
  the same day, recorded in `CHANGES-job76-20261005.md`), never whether the fear is settled.

## 2. Orientation, fixation, position

- **orientation** — the class word, in all parts. RULED 09-12. An orientation is close to a place a
  person stays at (RULED 09-14); *where they live* and *home* stay.
- **fixation** — a person's hardened orientation. RULED 09-12: **appears nowhere before Part 3.**
  *fixation has a negative connotation and orientation is neutral.* Introduced at the opening of
  Part 3, naming Ichazo and Naranjo both (corrected at this letter; `Job69` already corrected the
  book on `[A]`'s instruction). In Parts 1 and 2 the instance is described (*a One's detached psychic
  realm*), not named. `wordcheck.py` enforces the zero count.
  - **A fixation is the hardened orientation, a habit, held in a realm; concentrated attention is what
    it produces** (RULED 2026-10-06 in `Job77`). `[A]`: *attention in a phase is a result of fixation,
    not a cause*; of *A fixation is attention concentrated at one phase*, *it's not identity*; and,
    accepting `Job70`'s answer that the book keeps the hardened orientation, *job70 agrees with you. i
    accept it.* **Never write that a fixation *is* attention concentrated at a phase, and never write
    *fixation in a phase*** (`[A]` 09-23: *fixations and phases are separate things*). The two-sentence
    form for *Where a fixation acts* is in the findings.
- **A, B, Z** — name where a person stands, always with a realm prefix in the pair notation; never
  a phase (RULED 09-13; style guide §8).
- **A fixation sits only at an orientation** (RULED 09-09: *fixations can sit only at
  orientations*). Where the text means an offset, the word is **lean**. Leans are developed at
  Ch 11; Ch 4 names detachment's lean once (09-16).
- **lean** — the offset of the fixation's center on the cycle (09-15). **The lean sets how much
  attention reaches each phase and is not itself a source of wants or of fears** (RULED 09-23,
  through `CORRECTION-to-job70-closures-20260923.md`, **superseding `[A]`'s own 09-16 entry** that
  made the lean a source of a detached realm's wants). A center nearer the arising raises more
  wants; a center nearer the examining weighs more fears; whether a detached person processes or
  ignores an arriving fear (09-16) follows from where the center sits. **The 09-16 licence to name
  detachment's lean at Ch 4 for that purpose has lapsed with it; do not add it.** **Strength** (how caught) is
  a separate quantity (09-15: *you are conflating how far a lean is … with strength of fixation*).
- **range** — **RULED 2026-10-11 in `Job79`**, asked whether `range` should be kept for the range of
  detachment only: *i don't mind if range is used in two different senses as long as it's clear in
  context.* So **the range of detachment** (the span between its two ends) and the health axis's
  **range** both stand; a sentence where context does not settle which is a fault (`FINDINGS-job79`,
  item 3).
  - *Superseded 2026-10-09, kept for its words:* range around the center, widened by health, **on both
    sides** (RULED 09-15). The 10-08 flexibility ruling (`[A]`: *the result of higher levels may be
    flexibility rather than width*, `CLOSURES-SITED-job70-20261009c.md` C5) replaced it, and `Job78` took
    `range` out of the chapter on how the grip loosens.
- **how far** — the words for the size of a lean (RULED 2026-09-21, `[A]`: *"how far" is ok*).
  `strength` stays reserved for how caught a person is, so *strength of the lean* is not written.
  Both the lean and how far it goes influence whether an arriving fear is processed or ignored, and
  **both processing and ignoring can happen to any detached person** (`[A]` 09-21).
- **an orientation** — RULED 2026-09-22, for Ch 14: *the phase a person is most comfortable in, and
  the phase the person prefers to be in.* Written where the phases and the orientations are said to
  share names.
- **caught** — how strongly the fixation is held. Restate its meaning at the first use after a long
  gap (RULED 09-10).
- **wants and fears come from the mental deposits** (RULED 09-23: *it depends on mental deposits
  which were determined by fixations and history*; *the cycles apply to the whole, not by realm*).
  **A want or a fear is never described as raised by a realm, and a process is never described as
  running in a realm** — a process arc has no realm (09-12), and a want or fear takes the realm of
  the matter it is about. A detached person raises wants and fears like anyone, less intensively
  (RULED 09-23 in `Job75`: *wants and fears are processed in the enthusiastic and cautions phases
  even for a detached fixation, just less intensively*). Never count *sources* of a detached realm's
  wants.
- **a detached realm** — short for a realm where the person's orientation is detachment. Defined at
  Ch 5's opening; use the long form or the person form at distant sites (RULED 09-10).
- **stance** — not used; `framework` not used, `model` instead (style guide §8).

## 3. Taking in, noticing, attention

- **take in** — the only word for the first stage; everything is taken in, whole (RULED 09-07,
  09-09). **The taking in itself is not limited** (his wording, 09-10).
- **notice** — the second stage only (RULED 09-07).
- **open to noticing** — the range between the two, narrowed by how hard a want or fear pulls
  (RULED 09-09: *it's good*). Used fixed, not varied.
- **see** — ordinary meaning only; never the first stage (RULED 09-07). **sight / seeing** as nouns
  name the capacity to notice, the health axis's quantity.
- **register, surface** — never for either stage (style guide §8). Ordinary uses elsewhere (*what
  surfaces*) are left.
- **attention** — RULED 09-12, re-affirmed 09-16. At the sites about how much of a fear a person
  gets to, the word is `attention`. `[A]` 09-12: *i think time means attention. attention is
  probably more accurate and time a poorer metaphor*; 09-16: *dwell isn't good. attention is
  better.*
  - **Not ruled** (`[C]`, 09-15, closure 5 of Job70): whether `attention` should be removed
    elsewhere. `[A]` said only: *if you want to insist that attention is not zero sum, that's ok.*
  - **Cut on his word 09-14:** *There is one attention and two realms, so what goes to one is not
    going to the other.* Do not restore the idea of one attention divided between the realms.
- **dwell, how long, stays longer, passes quickly** — RULED OUT 09-12 and 09-16 at the fear sites.
  *dwell is just a synonym for time.* Ordinary uses in Ch 2's self-descriptions stay.
- **being able to notice more** — detachment's competence (RULED 09-09: the capacity, not the
  performance).
- **trying to avoid** — for caution's side of Ch 4's Z entry; `bracing` and `keeping off` rejected
  there (09-09: *"keeping off" isn't very good either. what about "trying to avoid"?*). Ch 15's
  *Two channels* takes the same wording for the infant (RULED 09-16: *trying to avoid what is
  painful*).
- **part of the realm** — `[A]` 09-10: *i don't like 'part of the realm' why do we need to say
  where.*

## 4. Detachment's two ends

- **two faces** — the name before leans exist (RULED 09-07); must be described, not only named.
- **the caution end / the enthusiasm end** — the two ends from Ch 11 on (RULED 09-07). Attach
  *of the detached phase* at the first mention in each section, then the bare form runs (RULED
  09-13).
- **clear, blind** as names for the ends — retired (RULED 09-07). **blind / blindness** belongs to
  the health axis alone.
- **the seeing end / the seeing side** — retired with them.

## 4a. Aversion, fear, want (RULED 09-16, narrowed 09-23)

- **aversion** and **attraction** — **RULED 2026-10-09 in `Job70` (`CLOSURES-SITED-job70-20261009c.md`
  A1, A2), WITHDRAWING the 09-23 reservation below.** `[A]`: *attraction and aversion go together in
  the sense that they are the most general words for two opposite type of motivation. pain isn't a
  type of aversion, pain is the object of aversion as pleasure is to attraction*; and *i agree to remove
  the reservation rule.* A want is an attraction when it is for something to arrive, and an aversion
  when it is for something to go or to stay away. The want to be rid of a pain is an aversion, raised
  at the arising. A fear is one kind of aversion. Written at Ch 14's *One thought, step by step*.
- **pleasure** — RULED 2026-10-09 (A3, A4), `[A]`: *i meant pleasure happens without any want or when
  a want is satisfied.* A pleasure arrives on its own or when a want is met; no want is a want to get a
  pleasure. Three wants: for something to arrive, for a pain to stay away, for a present pain to go.
  The want to keep is not a fourth.
- **desire** — RULED 2026-10-09 (A5), `[A]`: *desire is a type of want, the type on the attraction side,
  we don't have a word for the want to eliminate something.* Not given a technical sense; `want` does
  the job. The uses in the health axis chapter, from the borrowed Levels, stay.
- **pulls** — **RULED 2026-10-12 in `Job79`**, asked what replacing `draws` with `pulls` everywhere would
  involve, then: *ok to replacing draws with pulls everywhere.* A want or a fear **pulls** a person's
  noticing toward what it is about, and *the harder* says how hard. **`draws` and `point` are not used for
  this relation** (`[A]` 10-11, *yes*, to bringing the Five's and Six's `point` into line). Other senses of
  `draw` and `drawn` stay (the figure; *drawn toward what attracts*; *draws the person back into wanting*).
  - *Superseded 2026-10-12, kept for its words:* **draws** — `[A]` ACCEPTED 2026-10-09 per
    `CLOSURES-SITED-job70-20261009c.md` C4, confirmed to `Job78`: *all ok.*: a want or a fear **draws** a
    person's noticing toward what it is about; **pulls** is kept for how hard.
- *Superseded 2026-10-09, kept for its words:* **aversion** was **reserved to the cautious phase**
  (RULED 2026-09-23): *i question my use of the
  word aversion - i think it should be reserved to cautious phase.* Fear and disappointment are the
  two aversions, both raised in the cautious phase by examining, and both meet a fate at the
  ending. `Job75`'s census of every use is in `FINDINGS-job75-20261005.md`. **`fear of looking` is withdrawn (2026-10-05, `Job76`) — restored 2026-10-26 for one use, see section 5a, `Job88` block:** it was `Job70`'s choice on
  09-23, never `[A]`'s, and `Job70` withdrew it. Where a blocked fear is turned away from, or a person
  avoids recognizing a burial, **name the act** — *turning away from looking*, *turns away even from
  recognizing* — and use neither *aversion* nor *fear*. `[A]` on the substitution of *fear*: *i'm
  concerned because the word aversion works so much better than fear*; to naming the act at all four
  sites, *yes*.
- **turning away from noticing** — RULED 2026-10-06 in `Job77`, **superseding *turning away from
  looking* in the entry above.** `[A]`, agreeing with `Job70`: *i think noticing is what is avoided.*
  One form wherever the act that blocks is named. *Turns away even from recognizing* is a different
  act (the conscious way back) and stays. **`look at` stays as ordinary English** for attending to
  something already noticed; where a sentence is about the second stage, the word is `notice`. Sort
  by what the sentence is about, never by substitution.
- **what each orientation cannot easily bear** — every orientation has one (RULED 09-23, `[A]`: *all
  have a standing dislike*): enthusiasm, disappointment; caution, losing control; detachment,
  disturbance (Ch 4 gives it as *suffering with nothing softening it*). None is raised in a thought
  and none meets a fate. **No term names it, general or particular** (RULED 09-23, `[A]`: *no need for
  the general term*). Ch 4 says it in its own plain words, *cannot easily bear*, never *averse to*.
  **The coinage *standing dislike of disturbance* is retired and is not written anywhere.** A
  detached person minds disturbance at zero lean; the dislike does not come from the lean.
- **disturbance** and **the discomfort that fear leaves behind** — RULED 2026-10-05 in `Job76`. What a
  detached person cannot easily bear is *the discomfort that fear leaves behind* (`[A]`'s sentence for
  the orientations chapter, replacing *suffering with nothing softening it*). `[A]`: *disturbances is a
  superset of discomfort caused by aversion, the discomfort is a strong disturbance.* So `disturbance`
  stays as the wider word. **Sorted 2026-10-06 in `Job77`:** asked whether, where the book makes a fear
  itself the disturbance, the disturbance should be *the discomfort a fear leaves behind*, `[A]`: *yes.
  everywhere.* **A fear is never itself the disturbance.** The verb, and a disturbance as a trouble in
  the world, stay.
- **why an orientation is preferred** — `[A]` 2026-10-05: *A person holding one of the three stops
  where they do because they cannot easily bear what would come next.* Placed in Ch 14 after the
  definition of an orientation, as *A person prefers that phase because they cannot easily bear what
  the next phase would bring* (placement `[C]`'s). `[A]` then gave *A person tends to prolong that
  phase*, and kept *prolong* when `[C]` raised the attention ruling: *i think prolong is better.* So
  *prolong* is allowed at this site, about a phase a person prefers; the attention ruling still
  governs the fear sites.
- **peace**, and the enthusiasm end's want — RULED 2026-10-06 in `Job77`, `[A]`: *i agree with job70's
  response.* **What a detached person wants, at any lean, is peace**: not to be disturbed. **`comfort`
  is not a detached person's want in general**, and is not given to every Nine. **The enthusiasm end
  does not want pleasure for its own sake**: a person there reaches for a pleasure that takes them
  away from the discomfort a fear leaves, and any pleasure serves. Both ends serve the dislike of
  disturbance, the caution end by fixing, the enthusiasm end by getting away.
- **fear** and **want** are the working words through Part 3, as now.
- **disappointment** — **not an aversion, and not a pain.** RULED 2026-10-11 in `Job79`, `[A]`:
  *disappointment is neither.* **What it is, in `[A]`'s wording of 2026-10-13 in `Job80`:** *A disappointment
  arises when the outcome is settled and the want cannot be satisfied.* This replaces `Job70`'s wording
  (*a want has been met by an outcome that cannot satisfy it*), which `[A]` had accepted on 10-11.
  `settled` here is of an outcome, ordinary English, outside the `settled` ruling for fears. **A
  disappointment meets all four fates** — RULED 2026-10-14 in `Job81`, `[A]`: *not if you see the fourth.* … *yes*,
  **reversing** the 10-13 *three fates - yes*. Working a disappointment through is finding what to do now the outcome
  is settled (tying the broken pieces together); giving up on it is dropping the want (wearing other shoes). The
  book says *A disappointment can be worked through, given up on, ignored, or blocked* and gives no reason; `[A]`
  10-13: *it's just an explanation of your logic.* In the shoelace, the first thought's giving up also leaves a disappointment
  (`[A]`: *yes. and you wrote it so.*).
  Where an aversion about the outcome had been raised, the disappointment is what is left when that
  aversion is given up (`[A]`'s idea, agreed, answers file item 1). `[A]`'s first wording, *an acceptance
  that what was desired cannot be had*, is superseded by his own *acceptance is one possible fate of
  disappointment* — the fate called **given up on**. **Fear and disappointment meet the
  same four fates** — true again from 2026-10-14 (superseded 10-13, restored by the reversal above). The shoelace is **two thoughts** (RULED 2026-10-11, `[A]`: *two thought cycles. first is
  attempting to tie and discovery of broken lace. fate is giving up - the shoe cannot be tied. second is
  dealing with broken lace…*).
  - *Superseded 2026-10-11:* **aversion** as the class word for fear and disappointment together
    (*Fear and disappointment are both aversions*). A fear is one kind of aversion; a disappointment is
    not.
- **regret** — `Job70`'s `[C]` wording, `[A]` accepted (answers file item 2): giving up a want sometimes
  leaves something behind; **a regret** where the person could have acted otherwise, **a disappointment**
  where they could not. Not every giving up leaves a regret. The criterion is whether the person could
  have acted otherwise, never whether their own doing was in the failure (withdrawn by `Job70`).
- **attraction** keeps its present few uses; `want` gets no second name.
- *Superseded 2026-10-11:* **disappointment** belongs to the cautious phase, in both of its two cases
  (examination judging a desire cannot be met; a failure met, which starts a new cycle). The first case
  is two thoughts (above). Ch 4's *what an enthusiastic person cannot easily bear is disappointment*
  stays (09-23).

## 5. Fates, burying, stores

- **retired**, of a fear — RULED 2026-09-23. A climb is the retiring of buried fears: `[A]`
  *fears need to be retired to climb. and that is rare because it requires facing what previously
  the person chose not to face.* Written at Ch 16 as: a buried fear comes back into view, the person
  faces the fear, and **the fear has been released** (his wording), and a climb is rare because
  facing a buried fear means facing **what the person earlier felt they could not bear** (his
  wording, with `felt` chosen over `thought` because a burial is never noticed or decided).
  One fear retired is a small change, and a full level takes many; the same holds for the fall.
- **the four fates** — **worked through, given up on, ignored, blocked** (ruled names, 08-31).
  **The worked through entry — RULED 2026-10-14/15 (`Job81` closures A1, `[A]`: *i withdraw the 09-03 ruling.*),
  wording approved by `[A]` to `Job82` 2026-10-15 (*yes*):** *the thought has found what to do about the fear, so
  the fear is settled. Nothing has been turned away from. What the thought finds may be as small as a decision to
  try again. If the want behind the fear is still unmet, the want is laid down, and the next thought raises the
  want again.* The matter the fear was about may still be waiting. **Withdrawn:** `[A]`'s 10-13 wording (*the want
  behind the fear is met, and the fear ends with the want. Nothing about the matter is left waiting*) and the 09-03
  ruling that a fear ends only when the want behind it ends. Never write that working through leaves nothing over:
  every thought lays something down.
  - **Every fate leaves bodily tension** — RULED 2026-10-14, `[A]`: *yes. probably less than the other fates. and
    everything leaves deposits.* In the book, to `Job82` 2026-10-15, `[A]`: *drop probably.* So: *A fear worked
    through or given up on leaves less bodily tension than an ignored or blocked fear does.*
  **unattended** is the name for ignored and blocked together. The fates are stated in full in
  Ch 15 only (RULED 09-09).
- **forgotten** — the same fate as ignored (RULED 09-12: *i think forgotten is the same as
  ignored*).
- **burying / buried** — **the blind kind of blocking only (2026-10-19, below).** The blocked fate: a fear turned away from before it is noticed, and only
  when the fear is more than the person can bear (09-10). Not automatic at the enthusiasm end.
- **blind blocking / discomfort blocking** — RULED 2026-10-19 in `Job81`, relayed (`RELAY-from-job81-20261019.md`).
  Blocking has two kinds. **Blind blocking** happens in panic, all at once, to a fear the person cannot bear; it is
  denial, it forms the blindness loop, and only a fear blocked this way is **buried**. **Discomfort blocking** happens to a
  fear the person can bear but finds uncomfortable: aversion turns attention elsewhere each time the fear comes near,
  until a habit of turning away means the fear is no longer noticed. No blindness loop forms; a later matching fear can
  still be noticed and the person can choose to look at it. `[A]`: *it seems like there is absolute blocking that involves
  panic and graduated blocking that builds as a habit*; *should we say blind blocked?*; *good* for *blind blocking*; for the
  other kind he offered *partial blocking? semiconscious blocking? habitual blocking? discomfort blocking?*, `Job81` chose
  *discomfort blocking*, `[A]`: *ok*. *Buried stays with blind blocking only.* In Levels 1 to 6 the blocking is mostly
  discomfort blocking; **fresh blind blocking** is possible at any level, less likely in Levels 1 to 6, most likely where
  something touches material blindly blocked in childhood, and belongs mostly to Levels 7 to 9 (`[A]`: *The thing that
  belongs only to the lowest levels is fresh burial - yes*; of panic in the upper bands, *i think possible but less
  likely. but more likely in relation to absolutely blocked material*). **Never write that blocking happens only to a fear
  the person cannot bear**, and never call a fear blocked by discomfort buried. Approved to `Job88` 2026-10-23
  (`[A]`: *good*) as the *Blocked* entry in the four fates.
- **ignoring and going down** — an ignored fear stays in view, so **ignoring does not move a person down** (Job81's
  chain wording, `[A]`: *yes*). A fear weighed and judged unimportant is worked through; a fear called unimportant without
  being weighed is ignored (`[A]`: *ok*). The habit of leaving fears unweighed does not lower the level by itself, but makes
  a later blocking more likely (`[A]`: *yes*). `[A]` withdrew his question whether ignoring is the mildest form of
  discomfort blocking: *it think my proposal was wrong.* The *Blocked* entry no longer says ignoring and blocking begin as
  the same turning away (`[A]` cut it: ignoring *now doesn't imply discomfort*).
- **denial** — turning away become automatic when the thing is very unpleasant (09-10); *denial is
  an act even though it is not conscious.*
- **decision** — RULED 2026-10-06 in `Job77`, `[A]`: *take job70's answer.* **`decision` is the
  conscious kind only**, which needs a prior noticing; the book's proof that blocking is not a
  decision runs on that. The automatic case is **an automatic turning away from noticing**. **Never
  write *automatic decision*** in the book, though `[A]`'s own sentence below uses it.
- **what a burial lays down** — RULED 2026-10-06 in `Job77`. `[A]`: *what is learned, the deposits,
  is that certain thoughts, triggered by certain incidents, are painful, along with an automatic
  decision to avert noticing those thoughts.* In the book's words: certain thoughts are painful,
  together with an automatic turning away from noticing them. It develops over a history of
  incidents; an incident raises several fears, some ignored and some blocked, each meeting one fate.
  `[A]`: *"nothing is blocked the first time" is wrong.*
- **recognition** — the conscious way back only; **detect** for the below-noticing sense (RULED
  09-09).
- **bodily tension** — the short-term holder of a feeling of fear with no object (RULED 09-12,
  the name chosen over any name containing *fear* or *physical*).
- **mental deposits** — the long-term store (ruled 09-02); *what previous thoughts have laid
  down* is its plain description.
- **a buried fear is mental deposits** (RULED 2026-10-05, `[A]`: *buried fear is mental deposits*).
  The fear that was buried ended with its thought, like any fear; what a burial leaves is a deposit,
  and later thoughts raise fears out of it. Never write a buried fear as a fear kept somewhere. The
  climb wording above stands whole on this reading.
- **what crosses between thoughts** — only the **bodily tension** and the **content** of the
  unresolved matter (RULED 09-23, `[A]`: *the want becomes a fear, the tension and the content cross
  and that creates the next want*). A want and a fear are one thing at two moments of one thought;
  neither crosses. A fear lasts one thought (RULED 09-16, re-affirmed 09-23 in `Job75`).
- **what ignoring leaves** — the bodily tension, the unresolved matter, and the habit of ignoring a
  little stronger; never the fear and never the want. Write *ignoring leaves tension behind*, never
  *an ignored fear keeps its feeling* (`Job70`'s phrase, corrected by `Job70`).
- **forgotten** — ignored after the tension has subsided (RULED 09-23, `[A]`: *i think forgetting is
  a later stage of ignoring when the feeling has subsided*), which gives the 09-12 entry above its
  mechanism.
- **burying and ignoring** — one turning away at two strengths of feeling; the fear-of-fear loop
  produces every later difference (RULED 09-23, `[A]`: *that is the only difference at first, but the
  fear of fear feedback loop leads to more differences*).
- **the blindness loop, a feedback loop, the unease loop** — the only uses of `loop` (RULED 09-15: *the proper
  use is feedback loop and blindness loop*; **the unease loop** added RULED 10-04, `[A]`: *unease loop is ok.*).
  - **The verb *loops* is not used for self-reference either** (RULED 09-16). With the person as
    subject: *whatever a person thinks or feels becomes part of what the person is thinking or
    feeling about*; for a type, *a Four's watching becomes part of what the Four is watching*.

## 5a. Unease, gratification (2026-10-15/16)

- **unease** — RULED 10-04 (`[A]`: *ok. bare unease for now.*). The felt discomfort; **bodily tension** is the same
  thing held in the body. `[A]` to `Job82` 10-15: *"Unease and bodily tension are one thing." -> "Unease and bodily
  tension refer to the same thing."* No synonym (*disquiet*, *restlessness*, *malaise*). Do not say *two faces* (the
  book's name for detachment's two ends). Nothing names both. **chronic** is allowed as an ordinary adjective
  (`[A]`: *chronic seems okay*), never *chronic unease* as a term.
- **the unease loop** — a fear, then bodily tension, then a want to be rid of the tension, then a new fear; each
  turn worked through; buries nothing (RULED 10-04, 10-14). **No ranking by orientation** (RULED 10-12). What stays
  the same from turn to turn for an enthusiastic person is **the unease, not the matter**, and a detached person's
  solution is **potentially unconventional** (`[A]`, relayed 10-15), never *creative* alone.
- **idle discomfort** — is unease, and **buried fears and ignored aversions are behind the unease** (`[A]` to `Job82`
  10-16: *buried fears and ignored aversions are behind the unease.*). Not a third source.
- **capacity to bear discomfort** — what facing a buried fear takes; it can be built on any kind of pain (letter `l`: no longer *the way out at the enthusiasm end*, which `Job84` cut with `[A]`'s approval) (`[A]`: *the word capacity by itself is
  unclear. i think it means capacity to tolerate discomfort.*). The book keeps `bear` (the one capacity), never
  bare *capacity* there.
- **gratification** — RULED 10-15: *gratification always wares off.* Stated generally in its own section in the
  thought-cycle chapter (placement `Job81`, `[A]` 02:39 *stand on its own*); the unease-loop section applies it to
  distraction. *Happiness* is not used for it. The plain sentence *What gratifies changes as it is repeated, so no
  way of seeking gratification keeps working* is ruled in; the game image and the filter analogy stay out.
- **a habitual fear** — `[C]` name, approved in its passage (`[A]`: *yes*): a fear a matter raises every time the
  matter comes up. Defined at first use.
- **the pain of facing buried material** — **superseded in wording 2026-10-26, see the `Job88` block: a person *reacts as if* facing a buried fear would be unbearable.** Kept for its words: imagined to be unbearable (`[A]` 10-16: *it is misleading to say it's
  only imagined because it's imagined to be unbearable.*), for all buried pain, before words or later. So **on
  their own** people face buried material only once staying is unbearable, and help or trained abiding can bring
  facing sooner (`[A]`: *both true*).
- **Job83 amendments, 2026-10-16/17** (`FINDINGS-job83-20261017.md` items 1 to 5):
  - **the pain of facing** — imagined to be unbearable **at every depth**, so it is not an amount that grows with
    depth and a person does not settle where two amounts cross; only the pain of staying sets where a fall stops and a
    climb ends (RULED 10-16, to that question: *yes*).
  - **the pain of staying** — the whole felt pain counts, not only the part a person connects to their own condition.
    `[A]` 10-17: *the felt pain rises until staying is unbearable. at that point the person is open to trying something
    new.* and *desperation is no guarantee that facing their fears is the first thing they try.* Never write that
    desperation brings facing. **Minor intervention is common** (*people have friends and friends will constantly try
    to help*).
  - **an ignored aversion** — the aversion is not kept; *the matter behind an ignored aversion can still be noticed.
    it's available, not necessarily in view.* Never write that an ignored aversion **stays in view**, or that an
    ignored disappointment **leaves an aversion behind** (10-17, *yes*): it leaves the matter unresolved and some
    bodily tension, and the matter raises the aversion again.
  - **chronic** — `[A]` 10-17: *Where a person has neither buried fears nor ignored aversions there is no chronic
    unease.* A worked-through unease loop leaves unease while the matter is live; never write that the loop alone makes
    unease chronic.
  - **the unease loop** — the name belongs only to the worked-through round the book defines. **No *unease loop about
    the unease*** (10-17, *yes* to the cut; relay from `Job81`). At the enthusiasm end an ignored fear drops out of
    mind, leaves some bodily tension, which fades, and is raised again when the person next meets the problem.
- **Job84 amendments, 2026-10-17** (`CHANGES-job84-20261017.md`):
  - **the pain of staying, short of unbearable** — does not stop a fall; it adds stress, stress lowers what a person can
    bear, and the fall can speed up. It slows the fall only sometimes. Relayed from `Job81`, `[A]`: *it would sometimes
    make the person more cautious about behaving badly and that would work only if they had some understanding that
    their blindness was part of the problem*; and on the wording, *instead of "behaving badly", "allowing automatic
    reactions as a way to relieve discomfort " or something like that.* Book wording: *more careful about relieving
    discomfort with automatic reactions*. Never write that the pain of staying opposes a fall continuously, or that it
    works the whole time.
  - **the thin tail** — out (`[A]`, relayed: *thin tail is too technical*). The book says *Few people reach the bottom*.
  - **facing, at unbearable** — never the guaranteed first try. Relayed from `Job81`, `[A]`: *the person is unlikely to
    try facing the buried fear at first but they could possibly do it without help from someone else*. So help is never
    written as a condition; it makes facing more likely.
  - **the health axis, where first named** — `[A]` 10-17: *how about "The health axis reflects how much a person
    notices"*. Used at the unease-loop section, ahead of the chapter that introduces the axis.
  - **chronic unease** — `[A]`'s sentence *Where a person has neither buried fears nor ignored aversions, there is no
    chronic unease* stands in the book; the adjective use is allowed there, and *chronic unease* is still not a term.
  - **given up on**, of an ignored aversion at the comparison with a buried fear (relayed `Job81` repair, ruled name of
    the fate).
- **Job85 amendments, 2026-10-18** (`FINDINGS-job85-20261018.md`):
  - **consequences** — reach a person at every depth; what a person far down lacks is the connection between the pain
    and their own condition. Relayed from `Job81`, then `[A]`, asked whether he agreed: *i agree*. Never write that
    consequences **no longer reach** a person. The heading becomes *What reaches someone who cannot see their own
    condition* (`Job81`'s wording).
  - **a habitual fear** — caused by unease, never a source of it. `[A]`: *no. Ignored aversions and buried fears are two
    sources of unease and habitual fear is caused by unease itself.* On what ends it, `[A]` (in relay): *they are
    correlated but there are other factors.* So a habitual fear **usually eases** when the source of the lasting unease
    ends; the other factors stay unnamed. It is kept going by buried fears or ignored aversions, and by the unease loop;
    the matter is only what it attaches to (`[A]`, in relay: *ok*).
  - **unable to handle life** — `[A]` (in relay): *they feel like they can't handle life which is a threat. that's more
    like perceived material. and that situation persists.* and *it stays perceived.* The inability is **perceived**,
    never blocked; use *perceives*, not *sees* (`Job81`). It is the **third source of stress** in the fall (`[A]`, in
    relay: *yes*; here: *i agree with job81's opinion*). Never write that a habitual fear grows past bearing and is
    blocked; `[A]` did not write that claim.
  - **given up on / given up** — a fear or an aversion that meets the fate is **given up on**; a want is **given up**.
    `[A]`: *i agree with job81's opinion and also your given up on changes.* *A person who has given up all attraction
    and all aversion* (the Part 3 opening) is a standing motivation, not a fate, and stays.
- **Job86 amendments, 2026-10-18/19** (`CHANGES-job86-20261018.md`):
  - **unable to handle life** — the person **perceives the inability as a threat**. Never *the perception is a
    threat*. `[A]`: *"is" doesn't feel right. "creates"? "feels like"? "is interpreted as"? can you find a better
    verb?*; to `[C]`'s *perceives the inability as a threat*: *your proposal is good.* The same words are used at the
    unease-loop section and at the third source of stress. What can leave a person unable to handle life: buried
    material; in the falling section, things going wrong unexpectedly and reactions not thought out, together
    (`Job81`'s sentence, relayed; `[A]`: *yes.*).
  - **consequences**, at the leverage paragraph — an intervener supplies **the sight that consequences cannot**, never
    *what consequences no longer can* (`[A]`: *yes.*), under the 10-18 ruling.
  - **the intervener** — defined at first use: *another person, an intervener, working by opposite means* (`[A]`:
    *changes are ok*).
- **Job88 amendments, 2026-10-23 to 10-26** (`CHANGES-job88-20261026.md`):
  - **reacts as if facing would be unbearable** — replaces *imagines that facing … would be unbearable* and *imagined to
    be unbearable* at every site. Relayed from `Job81`: `[A]` proposed *means facing what they stops themself from seeing,
    and then the person reacts as if the pain of facing it would be unbearable*, then *good* to *The blindness loop keeps a
    buried fear out of view, and the person turns away as if facing it would be unbearable.* To `Job88`: *"The person
    reacts as if facing the buried fear would be unbearable, without awareness of this happening."? might need better
    wording.*, then *good* to *…without being aware of the reaction.* Say once per stretch that the person is not aware of
    the reaction; restate it where the last statement is far back (`[A]`: *is "without being aware of the reaction" still
    nearby?*).
  - **the fear of looking** — restored, in `[A]`'s own words, for one thing: the fear that arrives first when a buried fear
    comes back into view, and that has to be borne before the buried fear can be seen. Relayed from `Job81`, `[A]`: *it
    seems to me that a buried fear isn't faced at first - rather the fear of looking would be.* To `Job88`, confirming the
    register entry: *yes. and look for other instances that fail to mention that in the case of buried fears, the fear of
    looking needs to be faced before the fear can be seen.* The **fresh anxiety** that arises when buried material comes
    near is the fear of looking (`[A]`'s own sentence, to `Job88`: *The fresh anxiety is the fear of looking at the buried
    fear.*). The act of blocking keeps its name, **turning away from noticing**. Restate the fear of looking where the
    nearest mention is far back (`[A]`: *if it's not close to a preceding place where the book says it.*).
  - **through buried material** — every statement of how hard it is to rise is limited to buried material (`[A]`, relayed:
    *there is a lot (probably later) about how very difficult it is to rise that was written when we thought all blocking
    was blind*; asked whether the difficulty applies only to buried material, *as it was written, yes.*). **Reaching the
    top means no blocked fear is left, of either kind** (`Job81`'s decision, `[A]`: *yes to the whole paragraph*).
  - **the process**, for the core dynamics — the levels chapter's heading is *The process that produces the levels*
    (`Job81`, `[A]`: *yes*); *the rule* is not used for it (`Job88`'s decision, shown, `[A]`: *yes*). The process
    **conserves the original want** (`[A]` found *It conserves what is wanted* ambiguous; *that's good to* the new form).
  - **issues in** — out. `[A]`: *"issues in" unfamiliar use of verb.* The book says *the attitude produces behavior*.
- **migraine** — may be named (`[A]`: *can we say extreme migraine pain?*); method detail stays out.

## 6. Realms and motivation

- **realm** — a kind of subject matter. A process arc has no realm; a want or fear takes the realm
  of the matter it is about (RULED 09-12).
- **supplies motivation** — what a non-detached realm does for a detached one; what crosses is the
  motivation, not anything it is about (RULED 09-12, the wording approved verbatim).
  - **`lent` / `lend` are not used for this** (RULED 09-16, *ok*): *the supplied motivation*, *to
    supply them motivation*.
- **wanting and fearing** — both belong to enthusiastic and cautious realms: write *and*, not *or*
  (09-09).

## 6a. The health axis

- **most and least** — RULED 2026-10-12 in `Job80`. For the two extremes of how much a person notices,
  `[A]`: *top and bottom refer to how much a person notices but top and bottom don't fit well with an
  amount. how about least and most?* The extreme of noticing least is **carefree**, not burnt out or blind
  (`[A]`: *burnt out and blind are only the extreme case. carefree and maybe frivolous are more
  accurate.*). *Top* and *bottom* stay for the Levels, which are an ordered series. The point of no lean
  is not *nearly unoccupied*; `[A]`: *it's no less occupied than any particular exact point in the range,
  it is unoccupied because it has no width.*

- **what the axis measures** — how much a person notices (RULED 2026-10-05, `[A]`: *The health axis
  runs from not noticing to noticing, not from uncomfortable to comfortable.*). Never describe a
  level, in the book's own voice, by how a person feels. Calm may be written as an outcome of
  noticing, never as what the axis measures.
- **abiding in the detached phase** — what can be trained (RULED 09-23, `[A]`: *fixations and phases
  are separate things. every fixation orientation has a detached phase. abiding in the detached
  phase can be trained.*). No orientation is trained. Trained detachment is a tool used at moments,
  not a state.

## 7. Register and voice

- **Economic words** — RULED 08-29, 09-14, 09-15: `cost`, `pay`, `afford`, `spend`, `spent`,
  `price`, `arithmetic`, `invest`, `stock`, `budget`, `expense`, `expensive`, `scarce`,
  `resources`, `finite` are out. *cost … normally only applies to money.* Replace with what is used
  up: time, effort, strength, pain. **`ration`** is the only survivor, at the Five's rationing
  paragraph and the two loosening lines (09-15: *can you use the verb "ration" instead?*).
- **bear** — capacity, never load (style guide §8).
- **capacity to bear pain** — one capacity for the whole person (RULED 2026-10-09, B1, `[A]`: *it feels
  to me that capacity to bear is one thing overall*). How deeply caught a person is in a realm sets how
  much pain an event in that realm produces, never the capacity (B2, confirmed by `[A]` to `Job78` on
  2026-10-09: *all ok.*). Never write that caughtness sets what a person can
  bear in a realm.
- **brake** — not used in the book (RULED 2026-10-07 in `Job77`, `ADDENDUM-job77-20261007.md`, `[A]`
  to *Shall the book drop `brake`, as Job70 recommends?*: *yes.*). Say what happens — the pain of
  staying. The general mechanism, avoiding the greater pain, gets no name. The Three's *without brakes*
  is ordinary English and stays.
- **allowed to notice / allowed to know** — not used of a person where nothing does the allowing
  (`Job70` re-cut items 8 and 12 and closure for Ch 11, `[C]` wording, applied by `Job78`).
- **The author's voice** — RULED 09-15. The forms he chose, each for a kind of claim, are not
  collapsed into one: *My proposal is that*, *I propose that*, *What I call*, *I suspect*, *I
  assume that*, *What I have seen is*, *corresponds to*, *If the nine pairs are the nine types*.
  Where a session cannot tell which a claim is, it leaves the sentence and lists it for him.
- **The lever figure** — out of the book (`[A]` 2026-10-19: *"nothing is levered" - i don't understand levered.*).
  The section *The problem of leverage* is now *Why trying harder does not change a person*, and the chapter is
  *Falling and Rising* (`[A]`: *go ahead.*). Say what happens. **Superseded 2026-10-19 in `Job87`, applied by `Job88`:** *the person is moved by someone else, not
  by their own effort* is gone, since own effort helps a climb when it goes into practice and looking (`[A]`: *your reading is
  right.*). The section now says *Whatever a person does about their own condition, the person does it as they already
  are* (`[A]`: *"as they already are." is good.*) and *someone else helps the person see what trying harder could not bring
  into view*; a person who resolves to be different ends up doing what they already did, just trying harder. The Eight's
  *force, position, and leverage* is literal and stays.
- **waits on the world** — out (`[A]`: *is too terse - what does it mean?*). The book says *The recognition still
  depends on what happens in the person's life.*
- **The author's voice, at the leverage section** — *What I have seen is how well help from outside works* became
  *Help from outside works well* at `[A]`'s request (*can you remove the reference to the author?*). His choice of
  claim strength at that one site; the forms above stand everywhere else.
- **Comments on the book's own account** — out (`[A]`, of the two-ways-out paragraph: *the paragraph is the book
  introspecting about itself. is it unnecessary?*; of *What the account does not give is a way to do it alone*:
  *remove it.*). See style guide §1.
- **US spelling** (style guide §8).
- **arhat** (was **buddha**) — RULED 2026-10-05 in `Job76`. `[A]`: *actually Buddhism calls such a person
  an arhat. a buddha has the additional quality of deep understanding. should we leave it as
  "buddha"?*, and to `[C]`'s and `Job70`'s answer that `arhat` names exactly the quality the sentence
  describes and that the entry changes rather than gaining a second term, *yes. go on.* The 09-23 ruling otherwise stands with `arhat` in place of
  `buddha`: lower case, **the class defined in the sentence before the word appears** — a person who
  has given up all attraction and aversion, outside this model — used once, at the opening of Part 3,
  and nothing said about how anyone gets there. The 09-23 wording, kept for its words: `[A]` *using the
  class rather than the particular man is better*; *a detached person is still averse to disturbances
  while a buddha is indifferent to them*. `buddha` is not used.
- **indifference** — never used of a person or of detachment (RULED 09-23: detachment is not
  indifference; *a detached person is still averse to disturbances while a buddha is indifferent to
  them*). The arhat sentence takes *the absence of caring* (`[A]`). **The Four's sketch keeps *the
  physical world … is indifferent to how truthful an inner life is***, ordinary English about the
  world.
- **equanimity** — not used (RULED 09-23, `[A]`: *ok to omit equanimity*). It names the buddha's
  state, outside the model; the boundary runs between pure detachment, which still minds
  disturbance, and equanimity.

---

```patterns
# name | regex (case-insensitive) | scope | what to do with a hit
crossing | \bcrossings?\b | all | RETIRED 09-23 as a place: use the detached phase. Allowed: crossing the detached phase; crossings between the two realms; a crossing relation
dwell | \bdwell\w* | not-ch2 | RULED OUT at fear sites: use attention
how-long | \bhow long\b|\bstays? longer\b|\bpasses? quickly\b | all | time wording; check against the attention ruling
fixation-early | \bfixat\w* | before-part3 | RULED: fixation appears nowhere before Part 3
impulse-name | \bthe impulse\b | all | not a name; use the arising or the enthusiastic phase
examination | \bexamination\b | all | not a name; use the development or the cautious phase
resolution | \bresolution\w* | all | not a name; the ending (passage) or the detached phase
plain-ending | \bthe ending\b | all | passage only; if a place is meant, the detached phase
loop | \bloop\w* | all | only feedback loop / blindness loop / unease loop (RULED 09-15, 09-16, 10-04)
economic | \bcosts?\b|\bcostly\b|\bpa(y|ys|id|ying)\b|\baffor\w*|\bspen[dt]\w*|\bprices?\b|\barithmetic\b|\binvest(s|ed|ing|ments?)?\b|\bbudget\w*|\bexpens\w*|\bscarc\w*|\bresources?\b|\bfinite\b|\bstock\b | not-ch2 | RULED OUT: name what is used up
ration | \bration\w* | all | allowed only at the Five's rationing paragraph and the two loosening lines
register | \bregister\w* | all | not for either stage of noticing
old-ends | \bclear[- ]sight\w*|\bclear face\b|\bseeing (end|side)\b|\bblind (end|side|face)\b | all | retired names for the two ends
stance | \bstance\b|\bframework\b | all | orientation / model
bracing | \bbracing\b|\bkeeping off\b | all | RULED OUT 09-09 and 09-16: trying to avoid
part-of-realm | \bpart of the realm\b | all | [A] disliked it
recursion | \brecursi\w* | all | cut from the book
lent | \blent\b|\blend\w* | all | RULED 09-16: use supplied / supply
taken-same | same at either end of the range | all | deleted sentence; do not restore
one-attention | \bone attention\b | all | cut idea; do not restore
buddha | \bbuddh\w*|\barhat\w* | all | arhat, not buddha (RULED 10-05); lower case, class defined first, Part 3 opening only
aversion-scope | \baver(sion|se)\w* | all | RULED 10-09: the general word for motivation against something (reservation to the cautious phase withdrawn); Ch 4 says cannot easily bear. RULED 10-11: a disappointment is not an aversion
pulls | \bdraws?\b|\bdrawn\b|\bpoint(s|ed)? at\b|\bfears? point\b | all | RULED 10-12: pulls, not draws or point, for what a want or fear does to noticing; other senses (the figure, drawn toward what attracts) stay
disappointment-kind | \bdisappointment is (another|a) kind\b|\bboth aversions\b | all | RULED 10-11: disappointment is not an aversion
regret-always | \bregret is left\b|\bwhat remains is a regret\b|\bregret is the mark\b | all | answers item 2: giving up sometimes leaves a regret, sometimes a disappointment; state once at given up on
brake | \bbrakes?\b | all | RULED 10-07: not used in the book; say what happens. The Three's "without brakes" is ordinary English and stays
grab | \bgrabs?\b | all | RULED 10-09: the grab is out of the book
allowed | \ballowed to (notice|know)\b | all | nothing does the allowing; say how much a person notices or knows
desire | \bdesir\w* | all | RULED 10-09: no technical sense; the health axis chapter's uses stay
indifference | \bindifferen\w* | all | never of a person or of detachment; the Four's sentence about the physical world stays (RULED 09-23)
equanimity | \bequanimi\w* | all | not used (RULED 09-23)
unease-synonym | \bdisquiet\w*|\brestless\w*|\bmalaise\b|(?<!no )\bchronic unease\b | all | unease is the only name; chronic only as an ordinary adjective (RULED 10-04, 10-15); [A]'s 'there is no chronic unease' allowed (10-17)
standing-dislike | \bstanding dislike\b | all | retired coinage; say what the orientation cannot easily bear (RULED 09-23)
settled | \bsettl\w*|\bunsettl\w* | all | RULED 10-05: of a fear, only for worked through or given up on; reaching any fate is 'meets its fate'. Ordinary uses (a person settles near a Nine; an orientation settles) stay
worked-out-before | \bworked out before\b | all | rejected by [A] 10-05; a fear meets its fate only at the ending, and nothing is settled in the examining
realm-raises | \brealms? (raises?|generates?)\b|\bprocess(es)? running in\b|\barises? in (the|a|their|its) (detached |own )?realms?\b | all | a realm raises nothing; a process has no realm (RULED 09-12, 09-23)
reflex | \breflex\w* | all | RULED 10-06: only an act no thought produced; the turning away is automatic; a learned pattern is the habit of turning away
turning-looking | \bturn\w* away from looking\b | all | RULED 10-06: turning away from noticing
auto-decision | \bautomatic decisions?\b | all | RULED 10-06: decision is conscious only; say an automatic turning away from noticing
fixation-identity | \bfixation is attention\b|\bfixations? in (a|the|that|one|each) phase | all | RULED 10-06: a fixation is the hardened orientation; attention is its result; never fixation in a phase
three-fates-disappointment | \bdisappointments?\b[^.]*\bcan be given up on, ignored, or blocked\b|\bdisappointments?\b[^.]*\bthree fates\b | all | RULED 10-14: a disappointment meets all four fates (reversing 10-13)
left-over | \bnothing is left over\b|\bnothing about the matter is left\b | all | every thought lays something down; worked through may leave the matter waiting (RULED 10-14, the 10-13 wording withdrawn)
want-met | \bwant behind the fear is met\b|\bthe fear ends with the want\b|\bmet in the one case\b | all | RULED 10-14: worked through is the thought finding what to do; the want need not be met. A fear given up on still goes with its dropped want
thin-tail | \bthin tail\b | all | RULED 10-17 (relayed): too technical; say few people reach the bottom
staying-brake | \bworking the whole time\b|\bopposes it continuously\b | all | RULED 10-17 (relayed): the pain of staying slows a fall only sometimes; it can speed the fall through stress
unease-about-unease | \bunease loop about the unease\b | all | RULED 10-17: the unease loop names only the worked-through round
aversion-in-view | \bignored aversions?\b[^.]*\b(stays?|still) in view\b|\bleaves an aversion behind\b | all | RULED 10-17: the matter behind an ignored aversion is available, not necessarily in view; ignoring leaves no aversion
consequences-unreach | \bconsequences no longer reach\b|\bthe consequences no longer reach\b|\bconsequences no longer can\b | all | RULED 10-18: consequences reach a person at every depth; what is lacking is the connection to one's own condition
habitual-source | \bunease from a habitual fear\b|\bhabitual fear can grow past\b|\bhabitual fear ends when the matter resolves\b | all | RULED 10-18: a habitual fear is caused by unease, not a source; it usually eases when the source ends
stress-count | \bTwo things produce it\b|\bBoth lower how much a person can bear\b | all | RULED 10-18 (relayed): three things add stress in the fall; the third is perceiving the inability to handle life
aversion-given-up | \baversions?\b[^.]*\bgiven up\b(?! on)|\bgiving up ignored aversions\b | all | RULED 10-18: an aversion meeting the fate is given up on; a want is given up
lever | \blever(s|ed|age)?\b | all | RULED 10-19: the lever figure is out; say what happens. The Eight's literal 'force, position, and leverage' stays
book-comment | \bthis account produces\b|\bwhat the account does not give\b|\bleft unsolved\b|\bwaits on the world\b | all | RULED 10-19: the book does not comment on its own account; say the thing
uk-spelling | \b\w*(recognis|realis(e|ed|es|ing|ation)|organis|generalis|summaris|categoris|prioritis|minimis|maximis|apologis)\w*|\b\w*(characteris|criticis)(e|ed|es|ing|ation)\b|\b\w*analys(e|ed|es|ing)\b|\bjudgement\w*|\bneighbour\w*|\bcolour\w*|\bbehaviour\w*|\bcentre\w*|\bfavour\w*|\bhonour\w*|\blabour\w* | all | US spelling
imagined-unbearable | \bimagine[sd]? (that )?facing\b|\bimagined to be unbearable\b|\bpain imagined\b | all | RULED 10-26: the person reacts as if facing a buried fear would be unbearable, without being aware of the reaction
blocking-unbearable-only | \bblocking happens only\b|\bonly to a fear the person cannot bear\b|\bthe rule beneath\b|\bissues in\b | all | RULED 10-19/10-26: two kinds of blocking; only blind blocking needs a fear the person cannot bear. The core dynamics are the process, not the rule. 'issues in' out
```
