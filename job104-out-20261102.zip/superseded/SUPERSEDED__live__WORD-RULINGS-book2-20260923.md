# WORD RULINGS — book 2

**Letter `b`, cut 2026-09-23 by `job74-drafting-20260919`.** Five rulings of 2026-09-21 to 09-23 are
added: `crossing` retired, `how far` for the size of a lean, what a climb is, `aversion` reserved to
the cautious phase, and what an orientation is. Supersedes `WORD-RULINGS-book2-20260916.md`;
quarantine the parent.

*What the 09-16 cut said of itself, retained:* **Cut 2026-09-16 by `Job72 coherence 09152026`, at `[A]`'s request.** One place for every ruling
about which word book 2 uses for what. It sits beside `STYLE-GUIDE-20260908b.md` and does not
replace it: the style guide says how to write a sentence, this file says which word names which
thing.

## How a drafting session uses this file

1. Read it before writing any prose, together with the style guide.
2. Every sentence written or changed is checked against it.
3. **Only entries marked RULED are applied.** An entry marked `[C]` is a Claude reading that `[A]`
   has not ruled on. Do not act on it without asking him. *This rule exists because Job71 applied
   Job70's unruled reading on `attention`, and that reversed his 09-12 ruling.*
4. At the end of the session, run `python3 wordcheck.py BOOK2-<date>.md` and read every hit. The
   script flags words; it does not decide. A hit on an ordinary-English use is fine and is left.
5. **A new ruling on a word goes into this file in the same session**, with his words, and the file
   takes a letter. A word ruling that lives only in a repairs or closures file gets lost — that is
   how the `dwell` reversal happened.

Each entry: the word · what it names or what replaces it · date · his words where recorded.

---

## 1. The process and its parts

- **passage** — RULED 09-15/09-16. The move from one phase to the next. *What I call a passage.*
  Three passages, and only these names: **the arising** (detached phase to enthusiastic phase),
  **the development** (enthusiastic phase to cautious phase), **the ending** (cautious phase to
  detached phase). `[A]` 09-16: *ch14 should say phase, not orientation*; *"arising, the
  development and the ending" are good.* A passage is described in terms of phases, never
  orientations and never letters.
- **phase** — RULED 09-13, 09-16. The three phases are **the enthusiastic phase**, **the cautious
  phase**, **the detached phase**, and have no other names. `[A]` 09-16: *the detached phase should
  be called detached phase.* The adjectives are shared with the orientations on purpose; never let
  a bare adjective or bare orientation noun stand where a phase is meant (09-13: *Enthusiasm that
  cut the examination short…* was the caught case).
- **impulse, examination, resolution** — RULED 09-16: not names for anything. `[A]`: *these are
  transition names, not phases. and examination isn't right*; *resolution is another name for
  ending.* Rewrite to the passage or phase name. *An impulse arises*, meaning the thing that
  arises, is ordinary English and stays.
- **ending** — the passage only (RULED 09-16). Where a sentence means the place a process comes to
  rest, the word is *the detached phase*.
- **crossing** — **RETIRED 2026-09-23.** `[A]`: *crossing refers to the whole detached phase and
  from Z- to Z+ in particular. but it doesn't have a sharp placement. it would be better to use
  detached phase than crossing.* So the noun is not used for a place; the word is **the detached
  phase**. The verb form stays, for one pass through: `[A]` *you could say crossing the detached
  phase*, and a countable use is *one crossing of the detached phase*. Applied at every site in
  Ch 15, Ch 16 and Ch 17 by `job74`. Two other senses are untouched: things crossing between a
  person's two realms, and a crossing relation on the figure.
- **the phases are split by the passages** — RULED 2026-09-22. Each phase lies between two passages
  and has two halves, one overlapping the passage that begins the phase and one overlapping the
  passage that ends it. `[A]`: *all phases are split - enthusiasm starts with arising and ends with
  development - in particular detachment starts with ending and ends with arising and that is the
  Z-/Z+ split of detachment.* The **caution end** of the detached phase is the half overlapping the
  ending, and the **enthusiasm end** is the half overlapping the arising. Written at Ch 14's
  opening.
- **process arc** — a single run through the passages; **cycle** — the closed round of the three
  orientations (style guide §8). RULED 09-15: `loop` is not used for the cycle or the triangle.
- **scale** — the size of a process (a thought, an undertaking, a character). RULED 09-13: defined
  at first use in Ch 7. `recursion` is out of the book (09-13: *why even mention it?*).
- **Thoughts** are best described by the passages they make (RULED 09-16, Ch 7).

## 2. Orientation, fixation, position

- **orientation** — the class word, in all parts. RULED 09-12. An orientation is close to a place a
  person stays at (RULED 09-14); *where they live* and *home* stay.
- **fixation** — a person's hardened orientation. RULED 09-12: **appears nowhere before Part 3.**
  *fixation has a negative connotation and orientation is neutral.* Introduced at the opening of
  Part 3 with Naranjo's claim. In Parts 1 and 2 the instance is described (*a One's detached psychic
  realm*), not named. `wordcheck.py` enforces the zero count.
- **A, B, Z** — name where a person stands, always with a realm prefix in the pair notation; never
  a phase (RULED 09-13; style guide §8).
- **A fixation sits only at an orientation** (RULED 09-09: *fixations can sit only at
  orientations*). Where the text means an offset, the word is **lean**. Leans are developed at
  Ch 11; Ch 4 names detachment's lean once (09-16).
- **lean** — the offset of the fixation's center on the cycle (09-15). **Detachment's lean is a
  source of a detached realm's own wants** (RULED 09-16: *2 is true because detachment has a lean*),
  and the word may be named and defined at Ch 4 for that purpose (RULED 09-16: *ok to mention
  lean*). **Strength** (how caught) is
  a separate quantity (09-15: *you are conflating how far a lean is … with strength of fixation*).
- **range** — around the center, widened by health, **on both sides** (RULED 09-15); a person with
  a wider range generally prefers the side ahead.
- **how far** — the words for the size of a lean (RULED 2026-09-21, `[A]`: *"how far" is ok*).
  `strength` stays reserved for how caught a person is, so *strength of the lean* is not written.
  Both the lean and how far it goes influence whether an arriving fear is processed or ignored, and
  **both processing and ignoring can happen to any detached person** (`[A]` 09-21).
- **an orientation** — RULED 2026-09-22, for Ch 14: *the phase a person is most comfortable in, and
  the phase the person prefers to be in.* Written where the phases and the orientations are said to
  share names.
- **caught** — how strongly the fixation is held. Restate its meaning at the first use after a long
  gap (RULED 09-10).
- **a detached realm** — short for a realm where the person's orientation is detachment. Defined at
  Ch 5's opening; use the long form or the person form at distant sites (RULED 09-10).
- **stance** — not used; `framework` not used, `model` instead (style guide §8).

## 3. Taking in, noticing, attention

- **take in** — the only word for the first stage; everything is taken in, whole (RULED 09-07,
  09-09). **The taking in itself is not limited** (his wording, 09-10).
- **notice** — the second stage only (RULED 09-07).
- **open to noticing** — the range between the two, narrowed by how hard a want or fear pulls
  (RULED 09-09: *it's good*). Used fixed, not varied.
- **see** — ordinary meaning only; never the first stage (RULED 09-07). **sight / seeing** as nouns
  name the capacity to notice, the health axis's quantity.
- **register, surface** — never for either stage (style guide §8). Ordinary uses elsewhere (*what
  surfaces*) are left.
- **attention** — RULED 09-12, re-affirmed 09-16. At the sites about how much of a fear a person
  gets to, the word is `attention`. `[A]` 09-12: *i think time means attention. attention is
  probably more accurate and time a poorer metaphor*; 09-16: *dwell isn't good. attention is
  better.*
  - **Not ruled** (`[C]`, 09-15, closure 5 of Job70): whether `attention` should be removed
    elsewhere. `[A]` said only: *if you want to insist that attention is not zero sum, that's ok.*
  - **Cut on his word 09-14:** *There is one attention and two realms, so what goes to one is not
    going to the other.* Do not restore the idea of one attention divided between the realms.
- **dwell, how long, stays longer, passes quickly** — RULED OUT 09-12 and 09-16 at the fear sites.
  *dwell is just a synonym for time.* Ordinary uses in Ch 2's self-descriptions stay.
- **being able to notice more** — detachment's competence (RULED 09-09: the capacity, not the
  performance).
- **trying to avoid** — for caution's side of Ch 4's Z entry; `bracing` and `keeping off` rejected
  there (09-09: *"keeping off" isn't very good either. what about "trying to avoid"?*). Ch 15's
  *Two channels* takes the same wording for the infant (RULED 09-16: *trying to avoid what is
  painful*).
- **part of the realm** — `[A]` 09-10: *i don't like 'part of the realm' why do we need to say
  where.*

## 4. Detachment's two ends

- **two faces** — the name before leans exist (RULED 09-07); must be described, not only named.
- **the caution end / the enthusiasm end** — the two ends from Ch 11 on (RULED 09-07). Attach
  *of the detached phase* at the first mention in each section, then the bare form runs (RULED
  09-13).
- **clear, blind** as names for the ends — retired (RULED 09-07). **blind / blindness** belongs to
  the health axis alone.
- **the seeing end / the seeing side** — retired with them.

## 4a. Aversion, fear, want (RULED 09-16, narrowed 09-23)

- **aversion** is **reserved to the cautious phase** (RULED 2026-09-23, carried by
  `NOTE-for-job74-from-job70-20260923.md`): *i question my use of the word aversion - i think it
  should be reserved to cautious phase.* Fear and disappointment are the two aversions, both raised
  in the cautious phase by examining, and both meet a fate at the ending. **What a detached person
  has is a standing dislike of disturbance, and that is never called an aversion** (`[A]`: *detached
  always wants to avoid disturbance whether or not the disturbance is the same or different*); `[A]`
  called the name *a little clumsy* and it is not to be replaced silently. Every existing use is for
  the coherence run's census; `job74` added none.
- **fear** and **want** are the working words through Part 3, as now.
- **aversion** is the class word, used only where the class is needed — where disappointment is
  introduced and where the four fates are stated (about six sites). Fear and disappointment are
  both aversions and meet the same fates.
- **attraction** keeps its present few uses; `want` gets no second name.
- **disappointment** belongs to the cautious phase, in both of its two cases (examination judging a
  desire cannot be met; a failure met, which starts a new cycle). Ch 4's *what an enthusiastic
  person is averse to is disappointment* and Ch 7's *a resolution that both satisfies and
  disappoints* both stay.

## 5. Fates, burying, stores

- **retired**, of a fear — RULED 2026-09-23. A climb is the retiring of buried fears: `[A]`
  *fears need to be retired to climb. and that is rare because it requires facing what previously
  the person chose not to face.* Written at Ch 16 as: a buried fear comes back into view, the person
  faces the fear, and **the fear has been released** (his wording), and a climb is rare because
  facing a buried fear means facing **what the person earlier felt they could not bear** (his
  wording, with `felt` chosen over `thought` because a burial is never noticed or decided).
  One fear retired is a small change, and a full level takes many; the same holds for the fall.
- **the four fates** — **worked through, given up on, ignored, blocked** (ruled names, 08-31).
  **unattended** is the name for ignored and blocked together. The fates are stated in full in
  Ch 15 only (RULED 09-09).
- **forgotten** — the same fate as ignored (RULED 09-12: *i think forgotten is the same as
  ignored*).
- **burying / buried** — the blocked fate: a fear turned away from before it is noticed, and only
  when the fear is more than the person can bear (09-10). Not automatic at the enthusiasm end.
- **denial** — turning away become automatic when the thing is very unpleasant (09-10); *denial is
  an act even though it is not conscious.*
- **recognition** — the conscious way back only; **detect** for the below-noticing sense (RULED
  09-09).
- **bodily tension** — the short-term holder of a feeling of fear with no object (RULED 09-12,
  the name chosen over any name containing *fear* or *physical*).
- **mental deposits** — the long-term store (ruled 09-02); *what previous thoughts have laid
  down* is its plain description.
- **the blindness loop, a feedback loop** — the only uses of `loop` (RULED 09-15: *the proper use
  is feedback loop and blindness loop*).
  - **The verb *loops* is not used for self-reference either** (RULED 09-16). With the person as
    subject: *whatever a person thinks or feels becomes part of what the person is thinking or
    feeling about*; for a type, *a Four's watching becomes part of what the Four is watching*.

## 6. Realms and motivation

- **realm** — a kind of subject matter. A process arc has no realm; a want or fear takes the realm
  of the matter it is about (RULED 09-12).
- **supplies motivation** — what a non-detached realm does for a detached one; what crosses is the
  motivation, not anything it is about (RULED 09-12, the wording approved verbatim).
  - **`lent` / `lend` are not used for this** (RULED 09-16, *ok*): *the supplied motivation*, *to
    supply them motivation*.
- **wanting and fearing** — both belong to enthusiastic and cautious realms: write *and*, not *or*
  (09-09).

## 7. Register and voice

- **Economic words** — RULED 08-29, 09-14, 09-15: `cost`, `pay`, `afford`, `spend`, `spent`,
  `price`, `arithmetic`, `invest`, `stock`, `budget`, `expense`, `expensive`, `scarce`,
  `resources`, `finite` are out. *cost … normally only applies to money.* Replace with what is used
  up: time, effort, strength, pain. **`ration`** is the only survivor, at the Five's rationing
  paragraph and the two loosening lines (09-15: *can you use the verb "ration" instead?*).
- **bear** — capacity, never load (style guide §8).
- **The author's voice** — RULED 09-15. The forms he chose, each for a kind of claim, are not
  collapsed into one: *My proposal is that*, *I propose that*, *What I call*, *I suspect*, *I
  assume that*, *What I have seen is*, *corresponds to*, *If the nine pairs are the nine types*.
  Where a session cannot tell which a claim is, it leaves the sentence and lists it for him.
- **US spelling** (style guide §8).

---

```patterns
# name | regex (case-insensitive) | scope | what to do with a hit
crossing | \bcrossings?\b | all | RETIRED 09-23 as a place: use the detached phase. Allowed: crossing the detached phase; crossings between the two realms; a crossing relation
dwell | \bdwell\w* | not-ch2 | RULED OUT at fear sites: use attention
how-long | \bhow long\b|\bstays? longer\b|\bpasses? quickly\b | all | time wording; check against the attention ruling
fixation-early | \bfixat\w* | before-part3 | RULED: fixation appears nowhere before Part 3
impulse-name | \bthe impulse\b | all | not a name; use the arising or the enthusiastic phase
examination | \bexamination\b | all | not a name; use the development or the cautious phase
resolution | \bresolution\w* | all | not a name; the ending (passage) or the detached phase
plain-ending | \bthe ending\b | all | passage only; if a place is meant, the detached phase
loop | \bloop\w* | all | only feedback loop / blindness loop (RULED 09-15, 09-16)
economic | \bcosts?\b|\bcostly\b|\bpa(y|ys|id|ying)\b|\baffor\w*|\bspen[dt]\w*|\bprices?\b|\barithmetic\b|\binvest(s|ed|ing|ments?)?\b|\bbudget\w*|\bexpens\w*|\bscarc\w*|\bresources?\b|\bfinite\b|\bstock\b | not-ch2 | RULED OUT: name what is used up
ration | \bration\w* | all | allowed only at the Five's rationing paragraph and the two loosening lines
register | \bregister\w* | all | not for either stage of noticing
old-ends | \bclear[- ]sight\w*|\bclear face\b|\bseeing (end|side)\b|\bblind (end|side|face)\b | all | retired names for the two ends
stance | \bstance\b|\bframework\b | all | orientation / model
bracing | \bbracing\b|\bkeeping off\b | all | RULED OUT 09-09 and 09-16: trying to avoid
part-of-realm | \bpart of the realm\b | all | [A] disliked it
recursion | \brecursi\w* | all | cut from the book
lent | \blent\b|\blend\w* | all | RULED 09-16: use supplied / supply
taken-same | same at either end of the range | all | deleted sentence; do not restore
one-attention | \bone attention\b | all | cut idea; do not restore
uk-spelling | \b\w*(recognis|realis(e|ed|es|ing|ation)|organis|generalis|summaris|categoris|prioritis|minimis|maximis|apologis)\w*|\b\w*(characteris|criticis)(e|ed|es|ing|ation)\b|\b\w*analys(e|ed|es|ing)\b|\bjudgement\w*|\bneighbour\w*|\bcolour\w*|\bbehaviour\w*|\bcentre\w*|\bfavour\w*|\bhonour\w*|\blabour\w* | all | US spelling
```
