# HANDOFF — read this first

**CUT 2026-09-06 by `Job52 handoff 09062026`: `HANDOFF-20260906.md`. A FOLD, TEN SESSIONS DEEP, AND
THE DEBT IS DISCHARGED.** Quarantine `HANDOFF-20260905.md` as `SUPERSEDED__live__`.

**This session read all 5,371 lines of `HANDOFF-20260905.md` before editing anything**, which is what
§7 says earns a successor rather than an addendum. **Surgical edits throughout — not a retyping**, so
nothing was reproduced from memory and nothing could be silently dropped.

**TEN STACKED HEADS ARE GONE, WHICH IS WHAT THE DEBT CONSISTED OF.** Each was prepended by a session
that had read only the sections it edited, and a reader had to descend ten of them to reach the file.
Every one has a row in the VERSION block below, and everything they carried that is still live is at
§5, §6, §8 and §10. **The defect the top head named is discharged with them:** the 09-04 cut took a
new name and letter without rewriting the head it inherited, so a session reading only the top of the
file learned the wrong cutter. There is nothing left for that defect to sit in.

**WHAT IS FOLDED IN: `Job36` through `Job51` — sixteen sessions, and the last four had reached no
handoff at all.** `Job48`'s nine closing qualifications and its agency reading pass; `Job49`'s eight
closures and the tolerance ruling under them; `Job50`'s application of those closures and the
aligned-types repair; and `Job51`'s intervener account. **Their set notes, the closures file and the
two drafting instructions stay live and citable; this file is not citable for what they hold.**

**AMENDED IN PLACE AFTER ITS OWN SET WAS CUT, 2026-09-06. `[A]` RULED ON THE ONE THING THIS FOLD HAD
LEFT FOR HIM, MINUTES AFTER THE SET WENT OUT.** No letter was minted: the successor had just been
handed over and no session had received it, which is the 08-27 precedent. **The amendment is declared
here, the VERSION block below carries it, and the manifest was regenerated so the md5 moves.** If you
hold a copy of `HANDOFF-20260906.md` whose md5 does not match `MANIFEST-job53-20260906.md`, yours is
the pre-amendment copy and is short by this ruling.

**CLOSED 2026-09-06 BY `[A]`, AND CLOSED BY BEING DISSOLVED: `the z0 question can wait forever. book 1
is just for reference.`** This session found that a deprecation mark he ruled onto book 1 on 09-01 —
the Z0 sentence in the Ch 15 correspondence — is gone, `Job47` having discharged Level 0 at that site
on 09-04 by rewriting the sentence rather than leaving a gap. **Book 1 now states the 09-01 continuum
ruling in its own voice:** *And Z0 is not left off. The two faces are one continuum, and Z0 is the
point of no lean on it: it falls in the middle of the axis, where partial registering already sits.*
**He was asked whether book 1 may carry a ruled claim book 2 also carries, or whether the sentence
comes out and the gap is left. He answered neither and dissolved the question.**

**WHAT THAT GENERALIZES TO, AND IT IS THE REUSABLE PART.** His 08-31 ruling — *book 1 is just a
reference for writing book 2* — already governs what a repair session may do to book 1. **This
extends it to what a handoff may CARRY:** a question about book 1's own content is not an item, and
should not be written into this file as one. **The finding was still worth making** — it is how the
mark count came to be re-measured — **but the standing question it produced dies here.** *Do not
re-raise it, and do not open it as an item in a successor.*

**A NARROWER THING SURVIVES AND IS NOT DISSOLVED WITH IT:** `Job47` repaired a site without disclosing
that a mark `[A]` had personally ruled went with the repair. **That is a disclosure practice, not a
book 1 question**, and it is at §7.

**THREE COUNTS IN THIS FILE WERE WRONG AND ARE RE-MEASURED, NOT INHERITED.** §2 said book 1 carries
**seven** inline `[DEPRECATED …]` markers and then said *two of the five*, disagreeing with itself;
it carries **nine** inline plus the block mark. Book 1 is **2,595 lines**, not 2,594. And the record
was **four appends and 5,511 words** on from what §1.1's reach line stated.

**BOTH MASTERS' ROWS NAMED SUPERSEDED FILES, WHICH IS HOW A DEAD FILE GETS INTO THE NEXT SET.** §2
named `rev2-0814q.md` and `BOOK2-20260902b.md`; the live files are **`rev2-0814t.md`** and
**`BOOK2-20260906b.md`**, four masters on. **§1.1 now carries the resolution at its head** rather
than only inside the kind 11 row, where it was reachable by one job and not by the others.

**NEITHER MANUSCRIPT WAS TOUCHED, NO DOCTRINE WAS RULED, AND `AUTHOR-RECORD.md` WAS CARRIED UNREAD**
— its reach was taken from `setcheck.py sweep`, the word count and the manifest row, which is what a
handoff session may do. **It was appended blind before this session ended.**

**THE EIGHT FIGURES WERE ABSENT FROM THE ARRIVING SET AND `[A]` SUPPLIED THEM ON REQUEST.** The
condition the job 9 row has carried since 08-30 is met again; **do not drop them and restart the
resend cycle.** *`opposite-relationship.svg` was checked and is the 08-18 corrected file: its Type 3
label reads a 3 with a 5 wing.*

---

*Retained, because a successor will meet the name — what that file said of itself:* **Supersedes
`HANDOFF-20260824f.md`, cut 2026-08-24.** Surgical edits throughout, not a retyping. **A new date,
not a letter:** two days later, and it collects three sessions' work rather than one correction.
Quarantine `HANDOFF-20260824f.md` as `SUPERSEDED__live__`.

*Retained lineage, because a successor will meet the names — what that file said of its own
predecessors:* **Supersedes `HANDOFF-20260824e.md`, and through it `HANDOFF-20260824d.md`, `HANDOFF-20260824c.md`, `HANDOFF-20260824b.md`, `HANDOFF-20260824.md`, `HANDOFF-20260823c.md`, `HANDOFF-20260823b.md`
and `HANDOFF-20260823.md`.** Surgical edits throughout, not a retyping. `b` and `c` were cut inside the
08-24 session and never left it; **quarantine only `HANDOFF-20260823.md`**; through it supersedes `HANDOFF-20260821c.md`, cut two days before that. This file is that one with surgical
edits — **not a retyping** — and through it supersedes `HANDOFF-20260821b.md` and
`HANDOFF-20260821.md`. Quarantine `HANDOFF-20260821c.md` as `SUPERSEDED__live__` and
`MANIFEST-20260821d.md` with it; `HANDOFF-20260821b.md` and `MANIFEST-20260821c.md` were already
quarantined.

*The 08-21 lineage, kept because a successor will meet all four names:* `HANDOFF-20260821.md` was a
fold of four files; `b` gave the Level 1 material its own file; `c` differs from `b` by nothing else.
**Original supersession note, retained:** This file is that one with surgical edits — **not a retyping**,
so nothing was reproduced from memory and nothing could be silently dropped. Quarantine
`HANDOFF-20260821.md` as `SUPERSEDED__live__` — see §7 — and **verify the rename from the tool's own
printed line**. Stale, **not void**.

*Still quarantined:* `HANDOFF-20260820b.md`, `HANDOFF-20260818c.md`,
`HANDOFF-ADDENDUM-20260819.md`, `SESSION-RECORD-doctrine2-20260818.md`.

**LETTER ALLOCATION FOR 2026-08-21 — stated here because three sets carry that date and two files
minting one name is exactly what the branch was.** `MANIFEST-20260821a.md` was the incoming doctrine
set; **`MANIFEST-20260821b.md` is the writer 2 set**, described in
`BRIEF-writer2-ch1-4-20260821.md`; **`MANIFEST-20260821d.md` carries this file** — `c` was generated for
`HANDOFF-20260821b.md` and is superseded with it. Do not mint a second `b` or reuse `c`.

**And one file is never superseded: `AUTHOR-RECORD.md`.** It is append-only and holds `[A]`'s own
words. Do not fold it, prune it, re-cut it, or put a date on it. §7 carries the practice; the file
states its own rules on its face, so this is recoverable even if a successor drops the section.

**RULED 2026-08-25 AND IT CHANGES WHAT EVERY SET LOOKS LIKE: the record TRAVELS IN EVERY SET, and is
not READ by a text session.** Its old opening line — *this file does not go into a drafting set* —
did two jobs at once, barring the file from travelling and barring a text session from reading it.
**Only the second was ever wanted, and barring it from travelling is what let it go four days
stale.** The file's own first line now carries the new wording, and `setcheck.py screen` has a third
verdict to match it: **`CARRY, DO NOT READ`**, which is not `drop`. A session declares which kind it
is before it starts.

**Why the 08-21 file was a fold and not a fourth addendum**, kept because the reasoning recurs. By
08-20 the record stood in four files that had to be read in the right order to know where anything
stood — a handoff, a session record that named itself as not-a-handoff, an addendum, and a day's
rulings with nowhere to go. That is the shape that produced THE BRANCH, one level down. The 08-19
session was right to decline the fold, having read a fifth of the file; the 08-20 session read all
854 lines of it first, and the fold was the last cheap opportunity to do it.

> **VERSION — check this before using this file.** *(Block quoting nothing; formatting only.)*
> `HANDOFF-20260906` · 2026-09-06 · **76,495 words** by `LC_ALL=C wc -w` — **state the locale, see §6, the locale item**. A file cannot state its own md5; the hash is in the set manifest.
> *Amended in place 2026-09-06 after its set was cut, no letter minted:* **`[A]` CLOSED THE Z0 QUESTION BY DISSOLVING IT** — *the z0 question can wait forever. book 1 is just for reference* — and §7 gains the disclosure practice that survives it. **He also named the next session: the coherence check, kind 12.**
> *Changes since `HANDOFF-20260905.md`:* **A FOLD, TEN SESSIONS DEEP, AND THE DEBT IS DISCHARGED.** Carries `Job48` through `Job51`. **TEN STACKED HEADS COLLAPSED INTO ONE**, which is what the debt consisted of, and the defect the top head named goes with them. **A DEPRECATION MARK `[A]` RULED IS GONE FROM BOOK 1 AND BOOK 1 GAINED DOCTRINE IN ITS PLACE** — `Job47` discharged Level 0 at the Ch 15 correspondence site by rewriting the sentence, and the Z0 mark went with it; **that is the one thing this fold leaves for him.** **THREE COUNTS WERE WRONG AND ARE RE-MEASURED:** book 1 carries nine inline marks and not seven, book 1 is 2,595 lines and not 2,594, and the record was four appends and 5,511 w on from the reach line. **BOTH MASTERS' ROWS NAMED SUPERSEDED FILES** and §1.1 now carries the resolution at its head rather than inside one row. **§5 GAINS `Job49`'s closures as applied and the appetite closure that ended with nothing written; §6 GAINS EIGHT CLOSURES**, the largest being that less fixation means greater tolerance for the discomfort that orientation is averse to, which withdrew two mechanisms `Job48` had invented. **§8 and §10 gain five sessions.** **No doctrine was ruled, neither manuscript was touched, and the record was carried unread and appended blind.**
> *Changes since `HANDOFF-20260904.md`:* **NOT A FOLD — the fold debt is now ten sessions deep.** Carries `Job47 drafting 09042026`. **THE APPENDIX G INCONSISTENCY IS CLOSED BY `[A]`'s RULING** that the structure is fixed in advance and the *unattended* condition governs the motion — both are in the appendix, and G.1's causal verbs were the fault, not the missing condition. **`[A]` RULED THAT THE APPENDIX KEEPS WHAT BOOK 2 ALSO SAYS**, with a maintenance rule: the core-dynamics rule stands at three sites and changes at all three in one pass or at none. **LEVEL 0 IS OUT OF BOOK 1 AT ALL SEVEN SITES**, discharging the 08-23 ruling; both books now carry none. **THE `answering` IDIOM IS CLEARED — SIX SITES, NOT THE FIVE §5 NAMED.** **`[A]` RULED WHY A LONG CLIMB IS SLOW:** *the levels need to be healed one at a time*, which replaces the old-material-has-set account and deprecates book 1's temporal-layering bullet. **A NEW DOCTRINE CLAIM IS IN BOOK 2** at `[A]`'s instruction — a level above the current one is reachable as memory and cannot be functioned at — **carrying one unruled `[C]` choice, disclosed and marked.** Book 1 `rev2-0814r` → **`rev2-0814t`**; book 2 `BOOK2-20260904` → **`BOOK2-20260904b`**. **THE RECORD IS TWO APPENDS ON**, 34,494 → 35,695 w, the first of them written on behalf of `Job46`, which made none.
> *Changes since `HANDOFF-20260903g.md`, reconstructed by `Job47`:* **`Job46 drafting 09042026` cut this file and wrote no row for itself, and left the VERSION block naming `g`.** It emptied the 09-03 queue — twenty-one changes, the letter scheme closed with the first of them — ran a style pass, renamed four section headings, and cut `STYLE-GUIDE-20260904.md` and `NOTE-the-two-stacks-20260904.md` at `[A]`'s instruction. Book 2 27,575 → 28,092 w; book 1 `rev2-0814q` → `rev2-0814r`. **It made no append to the record.**
> *Changes since `HANDOFF-20260902f.md`, carried:* **NOT A FOLD — see the head, and the fold debt is now eight sessions deep.** Carries `Job45 doctrine 09032026`. **A FEAR ENDS WHEN THE WANT BEHIND IT ENDS — `[A]`'s largest ruling of the session**, and four more: the external route closes on **urgency** and not stress; **succumbing** is his name for the unattended pair and supplies the condition book 2 Ch 16's chain is missing; the **slide is the accrual**; and **blindness works by keeping the comparison unconscious**. **§5 IS REWRITTEN AND CARRIES TWENTY CHANGES** — `Job44`'s sixteen, which its set note handed to the next session, and four from this one. **THE DEPOSITS QUESTION IS CLOSED and its §5 entry removed**: a doctrine session read the record as its row permits and found `[A]` ruling `mental deposits` at every occurrence on 09-02; book 2 already complies and Ch 14 is drafted, so the block §5 described was lifted before it bit. **THIS FILE'S OWN VERSION BLOCK WAS ONE LETTER STALE AND IS REPAIRED** — it named `e` at 71,314 w while the file was `f` at 72,553 w, and `Job43`'s session had no history row; both fixed below. **§1.1's coherence row now says that kind appends blind**, whose silence is why `Job44` made no append. **THE RECORD IS TWO APPENDS ON**, 31,334 w → 34,494 w, and the reach line is re-measured. §6 closes the external route, `[A]`'s fourth job for consequences, and the 08-27 sweep finding. **Neither manuscript touched.**
> *Changes since `HANDOFF-20260902e.md`, carried:* **`Job43 drafting 09022026`** — the ruled Ch 15 placement applied, `[A]`'s ruling on the chapter's title, the crossing reword, twenty-four repoints and two stale author-record rows. *This row was owed by `f` and never written; reconstructed here from `f`'s own head.*
> *Changes since `HANDOFF-20260902d.md`, carried:* **A NEW JOB KIND, THE COHERENCE CHECK, MINTED AT §1.1 AND NOT YET RUN.** **NOT A FOLD — see the head, and the fold debt is now six sessions deep.** **THE REARRANGEMENT QUESTION IS ANSWERED** as a ruled placement at the architecture file's Ch 15, which takes the `d` letter, 14,160 w. **BOOK 1 TAKES A LETTER**, `rev2-0814q.md`, md5 `27f90a58` — three deprecation marks repointed from Ch 11 to Ch 15 on `[A]`'s authorization, no line moved. **§0 item 6 is rewritten** for a job that has run, **§1.1's kind 11 row now carries applying the placement**, and §1.1's job 6 row records that four of the files it names did not arrive. Three stale lines corrected in the architecture file. **Book 2 untouched; the record appended blind and never opened.**
> *Changes since `HANDOFF-20260902c.md`, carried:* **NOT A FOLD — see the head, and the fold debt is now five sessions deep.** **PART 3 IS IN THE MASTER**, `BOOK2-20260902.md`, 17,851 w → 27,318 w, and **every book 2 line-number citation made before 09-02 is stale**. **The deferred chapter renumber is DISCHARGED** in the master and at seventy-one sites in `BOOK2-PART34-ARCHITECTURE-20260902c.md`, which takes a letter: Part 3 is **Ch 13–17** and **`Ch 12` is reserved** for the undrafted *Learning to See*. The Levels chapter is titled **The Health Axis**, offered. **TWO RULINGS OF `[A]`'s TAKEN AND NEITHER APPLIED** — the Z-lean section out of Ch 11, and the fixation descriptions to the head of Ch 15, with *what follows* scoped by his own correction to the material on both sides of the crossing machinery. **He stopped the attempt to apply them here** — *this isn't working. i need help rearranging everything* — **so the next session is an ARCHITECTURE session and `OPEN-from-job41-20260902.md` is the handover.** §0 item 6 and §1.1's job 6 row are rewritten and **the row now names the master, which it did not**. §2's book 2 paragraph, §1.1's kind 11 row and the record reach line are re-measured. §7's file table and §8 gain this session. **One change to drafted prose**, a restatement trimmed from Ch 14. **Book 1 untouched; the record appended blind and never opened.**
> *Changes since `HANDOFF-20260902b.md`, carried:* **NOT A FOLD — see the head, and the fold debt is now four sessions deep.** **THE RECURSION CHAPTER IS DRAFTED and Part 3 is whole**, in seven files and none of it in the master; §1.1's kind 11 row names the new file and states that the chapter renumber is discharged by the placement pass and by no other. **BOOK 1 TAKES A NINTH MARK** on the two-faces clause his 09-01 continuum ruling contradicts, and it is a narrow mark: the reason in the same sentence is explicitly not deprecated. **Book 1 is `rev2-0814p.md`**, repointed at nineteen sites. **A COUNT DEFECT IN `b`'s OWN HEAD, corrected:** it said book 1 carried seven inline marks and it carried eight. §5 gains the new mark; §8 and §10 gain this session. **Neither manuscript's argument was touched, `BOOK2-20260831.md` is untouched a fifth session running, and the record was carried unread and appended blind.**
> *Changes since `HANDOFF-20260901b.md`:* **NOT A FOLD — see the head, and the fold debt is now two sessions deep.** Carries `Job37 drafting 09012026`'s **letter ruling** — `A`, `B` and `Z` name where a person stands and never a phase an endeavor has reached, so **book 2 adopts no arc notation at all** and the kinship rides on the orientation adjectives. Carries **`job38-drafting-20260902`'s Ch 13, drafted whole**, which absorbs the 09-01 phases passage. **A DEFECT IN THE ARCHITECTURE FILE, FOUND AND REPAIRED, AND IT IS ONE DEFECT AT THREE SITES:** the letter ruling killed Ch 13's notation requirement, the §1 section was rewritten in that pass, and three lines depending on it were left standing. **AND A DISCOUNT ON THIS SESSION'S OWN OUTPUT:** it read the author record by accident, reported it, and `[A]` ruled *stop and cut*, so **Ch 14 is not drafted** and a vocabulary question about the deposits is handed on unanswered rather than settled from a file the session should not have opened. §1.1's drafting row now names the drafted Part 3 files. The record is **two appends and 1,201 w** on from what this file used to state. §5, §7, §8 and §10 gain this session.
> *Changes since `HANDOFF-20260901.md`, carried:* **NOT A FOLD — see the head.** Carries `Job36 doctrine 09012026`'s **four rulings**. **THE RETRACTED ARISINGS CLAUSE IS CUT** from the closing paragraph `[A]` approved for the sketches, and applying it reached **a second live site nobody had named**, the Part 3/4 architecture's Ch 15, which carried the clause in bold. **Z− AND Z+ ARE ONE CONTINUUM AND Z0 IS THE ZERO-LEAN POINT ON IT**, which closes the two-faces-of-Z0 question by striking it rather than answering it, and **book 1 takes a deprecation mark** on the sentence putting Z0 off the health scale. **THE FIRST BRAKE IS RULED AND IS NO LONGER AN ASSEMBLY ON SINGLE WORDS OF ASSENT:** the route cannot be urged only re-sighted, the two brakes are one mechanism met twice, and **`[A]` supplied the routing mechanism the note said did not exist** — the comparison of immediate pains, with blindness removing one of its terms. **One guess of his is recorded as a guess**, and it gives the ruled forgetting/blindness distinction its home. **Book 1, the Part 3/4 architecture, the census, the brake note and the sketches all take new letters or dates** and §1.1's doctrine row is repointed. §5 gains the applied cut and the new mark; §6 gains the 09-01 closures; §8 and §10 gain this session. **Neither manuscript's argument was touched beyond book 1's one mark, and the record was read.**
> *Changes since `HANDOFF-20260830.md`, carried:* **A FOLD, four sessions deep, and the third real one.** **BOOK 1'S LINE NUMBERS NO LONGER LAND** — the count moved 2,566 → 2,594 and the drift is not constant, so §1.0 gains a rule and every claim in this file about citations landing is corrected. **`[A]` RULED WHAT BOOK 1 IS FOR**, which closes the question this file carried as the permanent one: *it's just a reference for writing book 2*, and the repair standard that follows is delete or mark what is false, leave the gap, write no replacement. **A FIXATION IS REDEFINED** — a standing preference about where attention is directed — which supersedes R4 a second time and narrows R10a's reservation; **the crossing has FOUR fates** with ruled names, `worked through` / `given up on` / `ignored` / `blocked`, and **`unattended`** is the genus over the last two. **Both masters, the rulings file and three notes have new letters** and §1.1's rows are repointed; the record is **three appends and 6,194 w** on from what this file used to state, corrected at every site. §0 gains a drafting row the kind has never had. §5 gains the two book 1 deprecation marks `[A]` ruled down on 09-01 and **a defect in his own approved sketch paragraph, which restores a clause he retracted on 08-20**. §6 gains the 08-30 and 08-31 closures and loses two permanent questions. §7 gains four practices. §8 and §10 gain four sessions. **No doctrine was ruled by this session beyond the two marks, neither manuscript was touched, and the record was carried unread and appended blind.**
> *Changes since `HANDOFF-20260829.md`, carried:* **A REAL FOLD, four sessions deep, and the file it supersedes said one was owed.** **§1.1's rows named superseded masters** — book 1 and book 2 have both moved four times since — **and a row naming a superseded file puts that file in the next set, silently, every time.** Repointed. **The author record is five appends on from what this file used to state**, now **18,733 w, marker `2026-08-30 · Job29 book 2 ch 7 drafting 8-30` (eighth append)**, corrected at every site. §1.0 quotes `verify`'s summary in its new FIVE-field shape. **§4 gains `[A]`'s metaphor rule — name the mechanism, and economic figures are out even where the exchange carries the argument** — plus his two other standing style corrections. **§5 is re-measured against `rev2-0814l.md` and every older item is still unapplied**; the Job18 ruling leaves it, applied at last. §6 gains the 08-29 and 08-30 closures: **disintegration is a lean and not a movement**, **no arrival may be reached by going backward**, **detachment sees the realm whole**, **the burial reflex is fed continuously**, **the second brake is not conditional on stress**, and **the origin of the fixation is decided not to need deciding**. §7 gains the fold check and verify-before-you-conclude. §8 and §10 gain five sessions. **A MEASURED FINDING, and it reverses a claim this file carries in bold: `BOOK2-Ch1-4-for-writer2-20260821.md` IS NOW STALE** — at least four of `Job27`'s metaphor substitutions land inside the extract's own range. **No doctrine was ruled by this session, neither manuscript was touched, and the record was carried unread.**
> *Changes since `HANDOFF-20260827e.md`, carried:* **`tools` MINTED BY `[A]` 2026-08-29 as job kind 10** — appended, not inserted — carrying two items found by `Job26`'s §1.0: `setcheck.py verify` never compares word counts, and its parser reads the third column as words. **Two stale pointers repaired in §1.1's doctrine row:** it named the superseded `BOOK2-20260825.md` as reference master, and had no entry for an outgoing session's `OPEN-*` file. **NOT A FOLD — see the head.**
> *Amended in place after cut, retained from `e`:* `[A]` added **substance abuse and its effect on the blindness
> transition and the falling mechanism** as a subject for the list — §0 item 7. **He then named the next
> session `job25 drafting 0829`** — a DRAFTING session, and the first the model has had; the set label
> and date move to `20260829` while `Job24` stays 8-27. **He first proposed `writer` and stepped back
> from it when told it is the gated job 4 row — THE GATE IS NOT LIFTED.** **The record takes a third
> and fourth append and now reads 15,683 w.**
> *Changes since `HANDOFF-20260827d.md`:* **one morning ruling corrected, one new ruling, one new
> brake, and a retraction.** **The sight protection attaches to the CROSSING, not to the fear** — the
> same fear may be seen on one passage and blocked on a later one, which costs `[C]` the argument that
> made the way out permanent. **Everything in this thread is an A-SIDE account**, and the B side gets
> the opposite failure from the same variable. **RULED: urgency decides whether a fear can be ignored,
> and it is analog, not a threshold** — the model's second continuous quantity. That removes the
> morning's tail from its derivation; **`[A]` re-derived it from debilitation outweighing motivation,
> and then closed the absolute reading — coming up from the bottom happens.** **RULED: a second brake,
> intervention**, which imports sight rather than bypassing it. Empirical material from 12-step
> literature is filed as evidence, not doctrine, **including an error of `[C]`'s that `[A]` caught**.
> **A sweep finding: a repair record disagrees with book 1 by one word.** The record takes a **second
> append and now reads 15,231 w**.
> *Changes since `HANDOFF-20260827c.md`, carried:* **two rulings `[A]` supplied, three he assented to, one defect
> given a site, and the brake becomes conditional.** **The clear side of detachment is defined by SIGHT**,
> not by the examination having completed — which makes book 1 Ch 15's *through examination / skip
> examination* sentence a defect, and a bigger one than a wording swap, since its own example belongs to
> a condition the book did not have. **Forgetting and blindness are two different conditions**, ruled
> narrowly: the difference, not the test for it. Assented to on `[C]`'s cases: **stress is the switch**
> that decides whether consequences mobilise or collapse a person, **the brake is conditional on it**,
> and the distribution is **bounded for most, with a tail**. §0 item 7 gains the ignoring habit and loses
> the naming question; §1.1's job 7 row gains
> `NOTE-the-two-tests-and-the-ignoring-habit-20260827b.md`. **The record is appended to by the session
> and now reads 13,778 w.** *And this block itself is repaired — see the head.*
> *Changes since `HANDOFF-20260826d.md`, carried:* **one fold, one ruling, and one job goes from live to gated.**
> `HANDOFF-ADDENDUM-20260826d-job21.md` is folded in and is no longer live. **`[A]` ruled that
> Appendix G states FOUR terms, not two** — desire, attitude, behavior, fear — which closes the
> question §0 item 7 had carried unasked for four sessions; §5 gains the ruling, and the work it
> creates (a six-way derivation needing a source table this project does not hold) is stated as a
> task rather than folded into the ruling. **The other half of that same item is struck as already
> ruled** — App G's top-and-exit rule was settled by the 08-23 Level 0 abolition, which arose from
> exactly the chart correction the defects file still lists as unexamined. **Job 4 is LIVE, WANTED and
> GATED on Toby Marshall with no date**, and `[A]`'s standing instruction to be reminded of it is now
> §0 item 4's own row. **The claim that the writer 2 extract is stale was never a measurement and is
> false** — the file is byte-identical to a re-cut and is live. §5 gains the Ch 7 finding, which has
> **no strings and must not be handed to a text session**. §6 gains the 08-26 closures and three
> bookkeeping defects; §7 gains the rulings-file navigation warning, the record's coming size
> crossover, and the rule about naming a person against a job row. §8 and §10 gain two sessions.
> **No text was written, neither manuscript was touched, and the record was carried unread.**
> *Changes since `HANDOFF-20260826c.md`, carried:* **`WORKING-SET-doctrine.md` is marked STALE and renamed**,
> on `[A]`'s instruction, after measurement showed nine of its 116 reproduced book 1 passages no
> longer occur in book 1. **A third status prefix is minted — `STALE__<origin>__`** — because neither
> existing marker fits a file nothing supersedes; §7 carries it and §1.1's job 7 row carries the new
> name. §6 gains the finding and the milder one about the book 1 index.
> *Changes since `HANDOFF-20260826b.md`, carried:* **`[A]` ruled the Z+ sketch site — the retraction reaches
> it, and the whole sentence goes.** §5 gains the ruling with its exact string, verified to occur once,
> and the older block's claim that the clause occurs nowhere else in book 1 is corrected on its face.
> **That closes the finding job 17 raised and job 19 carried**, and it means the summary-paragraph cut
> can now be applied without leaving the retracted claim standing one paragraph above it.
> `AUTHOR-RECORD-ADDENDUM-20260826.md` is cut for `[A]` to append by hand, this session having carried
> the record unread. No other change.
> *Changes since `HANDOFF-20260826.md`, carried:* **the recovery note's screen defect is FIXED, and it was two
> sites rather than one.** The note takes a letter — **`RECOVERY-NOTE-20260825b-procedural-changes.md`,
> 1,470 w** — and §1.0, §1.1's job 7 row, §8 twice and §7's file table now name it. **The literal stood
> whole at line 85 as well as line 52**, and three files had described the fix as the one line break at
> 52, so the repair as written would have left the file firing and been reported as done. §6 gains two
> bookkeeping defects found by §1.0 — job 19's set note miscounts its own set, and this set's manifest
> label names the session that cut it rather than the one receiving it. §8 and §10 gain this session.
> **No doctrine moved, neither manuscript was touched, and the record was carried unread.**
> *Changes since `HANDOFF-20260824f.md`, carried:* **three sessions folded in, and `handoff` is a job kind.**
> `[A]` minted it this session, so it appends as **§0 item 9** and nothing renumbers. **Eighteen
> repairs were applied on 08-25** and leave §5; both manuscripts have new names, and §2, §1.1 and the
> next-set section now give them. **The author record travels in every set** on `[A]`'s 08-25 ruling,
> which retires the sentence that kept it out and closes the set-folder conflict §7 had left open;
> its reach is now 9,724 words. **§1.0's screen line stops naming a count** and names the two verdicts
> instead — it had gone stale twice on the number alone. §5 marks what was applied and gains three
> ruled sites with exact strings. §6 gains the 08-24 and 08-25 closures and loses the job-kind
> question. §8 and §10 gain three sessions. **No doctrine was moved by this session** — it ruled
> nothing and touched neither manuscript.
> *Changes since `HANDOFF-20260824e.md`, carried:* **four rows made to describe what they actually govern.**
> Job 3's row names all eight figures and both tools instead of saying *the figures*. The figure
> table's exclusion note is **scoped to book 2 drafting sets**, which is all its reasoning ever
> covered — every row saying *the figures* had inherited it silently. §6 records that the cycle
> figure is not retired, only absent from book 2, on `[A]`'s word. No doctrine moved.
> *Changes since `HANDOFF-20260824d.md`, carried:* **the session's own record, which `d` did not carry.**
> §6 gains the two capture gaps its own change note had already promised were there — a pointer to
> something absent, the same defect this session spent the day fixing. §8 gains the 08-24 entry;
> §10 gains the discount on this session, including the backfill adjudication as the judgment to
> distrust most. Job 6's row names its notes explicitly, the next-set paragraph is corrected to five
> changed files, the 08-21 label defect is marked as surviving rather than pending, and the question
> of whether **tools** is a job kind is recorded for `[A]` and deliberately not minted.
> *Changes since `HANDOFF-20260824c.md`, carried:* **the author record is backfilled to 08-15.** Seven
> pre-creation quotations recovered from five files, appended as a marked section with the selection
> rule stated. Record's reach now 6,273 words. No doctrine moved.
> *Changes since `HANDOFF-20260824b.md`, carried:* **`[A]` ruled on the two personal entries.** They are
> marked `PERSONAL — NOT FOR THE BOOK`, readable and usable for reasoning, barred from the text and
> from any brief. §7 carries the ruling; the record carries the mark and a rule defining it. The
> record's reach is now 5,663 words. No doctrine moved.
> *Changes since `HANDOFF-20260824.md`, carried:* **the author record's duplicate-copy problem is closed.**
> Every append to that file now ends with a **RECORD MARKER** carrying date, session and word count
> — an append, not a revision. `setcheck.py` is at **1.8**: `sweep` finds append-only records by
> content and prints the last marker, or a loud NONE. **§1.1 states the record's reach**, so two
> files must agree. No doctrine moved.
> *Changes since `HANDOFF-20260823c.md`, carried:* **tools, and still no doctrine.** The two `quotecheck`
> defects recorded on 08-21 are **fixed**, and §7 no longer tells a successor to fix them.
> **`quotecheck.py sweep` is new** — every blockquote in a set against every file in it — and §7 says
> to run it at set-cut. Every check ever reported clean against a non-book-1 source was re-run and
> **nothing false was behind the broken tool**; two capture gaps surfaced and are at §6. §1.0 gains
> the rule that §1.1 is updated in the same pass as any supersession. The overlap note is repaired
> and lettered. **A new date, not a letter:** this file collects a session's worth of work rather
> than a single correction, and `b` and `c` were both within-session repairs that never left it.
> *Changes since `HANDOFF-20260823b.md`, carried:* **two stale pointers repaired.** §1.1's job 7 row and
> §6's Level 1 pointer both still named `NOTE-level-1-and-the-summit-20260821.md`, which
> `NOTE-level-1-and-the-summit-20260821b.md` superseded on 08-23. **The §1.1 row is why the
> 08-24 delivery carried the superseded note as a twentieth file** — the assembler followed the row.
> An out-of-date pointer in §1.1 puts the wrong file in the next set every time, so §1.1 must be
> updated in the same pass as any supersession. `b` was never distributed as a set member and no
> manifest carries its md5. The 08-21 lineage line in this block still names the unlettered file and
> is correct as history.
> *Changes since `HANDOFF-20260823.md`, carried:* **one repair, no doctrine.** §1.0 quoted the
> restriction literal as `It does not go into a drafting set`, which occurs in no file — the author
> record's line reads *This file does not go into a drafting set*. An assembler typing that grep by
> hand got one hit, this handoff quoting itself, and missed the one file the screen exists to catch,
> while §1.0's own text predicted three hits and so would have read as working. `setcheck.py` was
> never wrong; only the prose was. The corrected literal fires three, verified. Found by
> `Job15 tools session 8-24`.
> *Changes since `HANDOFF-20260821c.md`, carried:* **three rulings, and one of them removes a rung from the health axis.** **Level 0 is abolished** — Riso's self-actualization *is* this book's liberation, it sits on the Level 1 row above the basic fear, and the rung invented to hold it is gone. **A lean is a static adjustment to the fixation; integrating and disintegrating are a temporary adjustment whose size tracks how much stress a person is under at a given time** — both offsets on the same circle, replacing the 08-19 shape that had the lean as one reading and the direction as the difference between two. **And `integrate toward` / `disintegrate toward` are the sanctioned verbs**, which retires the transit language in five places. §0 item 7 is down from two questions to one. §5 gains the repairs; §6 gains a closed section. **The doctrine list is now one question plus the reserved one.**
> *Superseded version block, retained for the 08-21 lineage — changes since `HANDOFF-20260821.md`:* **six rulings, and the doctrine list at §0 item 7 is down from eight questions to two.** The two scales are **one shape at two sizes**, so the endeavor and the thought are not two accounts to reconcile. The memory claim is **withheld from the text, not withdrawn**. What a thought leaves has **two variables, weight and permanence**, not one. What is carried past detachment is **not** the neighbour trace — the fixation is standing and sets how large the possibility is, each ending is an occasion. The carrying is **neither a switch nor a width**. And **the numeric lean values go from both books** — direction and magnitude stay — which dissolves the arc-occupancy question rather than answering it. §5 gains those repairs; **book 2's Ch 11 now carries three and they must be made in one pass**. `[A]` also opened the writer 2 job, which has its own brief and set. The figure question was reopened and closed the same hour.
> *Also added after `b`:* **`NOTE-level-1-and-the-summit-20260821.md`**, cut at `[A]`'s instruction because the Level 1 material had reached the record only as verbatim author entries with nothing pointing at them. The set is nineteen, not eighteen.
> *A new date, not a letter:* cut 2026-08-23, two days after the file it supersedes, so it takes the date and no letter. The 08-21 letter allocation above is closed — do not mint into it.
**If your copy is not this word count, it is stale.**

---

## WARNING TO THE NEXT SESSION — read before anything else

**Do not talk to `[A]` in ledger numbers, and do not talk to him in internal ruling labels either.**
Say the thing. "Whether a thought that stops is stalling or finishing" — not an item number.
"The ruling that the levels don't wrap" — not its label. `[A]` said plainly on 08-20 that he does not
know the internal labels; putting a question the short way means putting it in a language he has not
got. The numbering is meaningless to him in conversation, and using it makes indexing look like
progress. **A claim that needs a number to be understood has not been stated yet.**

The labels stay in this file, because a file needs pointers. Every open item below also carries a
name, and the name is what you say out loud.

**Deliver one thing at a time.** Three sessions running have been stopped for handing over a
multi-part finding in a single response, and on 08-20 `[A]` said outright that a finding was too
complicated to digest and that he could recognise the area as incoherent without being able to hold
the argument. Take one question, answer it, ask one question back, stop.

**AND TWO MORE HE HAS HAD TO GIVE REPEATEDLY, which apply in conversation as much as in the text.**

**Never refer to a case by its position in a list.** *Only given up is chosen*, never *only the second
is chosen*. **`[A]` calls this a big problem with the writing style and says he has given the
correction several times across sessions** — naming the thing saves the reader going back to count.

**Name the mechanism rather than reaching for a metaphor to save a few words.** `[A]`: it is
*claude's default use of an inappropriate metaphor to save a few words*, and **he ruled economic and
financial figures too remote for this context, including the cases where the exchange carries the
argument.** *On 08-20 he stopped a reply to ask what a metaphor meant and the answer was a plain
sentence that should have been there instead.* The drafting form of this is at §4.

**All four are standing instructions, not observations about one session.**

---

## THE BRANCH — read before any other file

**Two architecture documents describe incompatible books. One is ruled; one is not.**

| File | Structure | Status |
|---|---|---|
| `BOOK2-ARCHITECTURE-20260815b.md`, md5 `9c693a2d` | Four parts; **Part 2 = The Finer Structure** (grid, cycle, relational positions, relational dynamics, the arrows, leans and wings, learning to see); R7 cut from book 2; Ch 2 stays | **LIVE** |
| `BOOK2-ARCHITECTURE-20260815.md`, two revisions | Three parts; **Part Two = Movement** | **VOID — quarantined** |
| `BOOK2-ARCHITECTURE-20260816.md`, two revisions | Three parts; **Part Two = Movement**, Ch 6–13; R7 in three chapters; Ch 2 reopened | **VOID — quarantined** |
| `HANDOFF-20260816.md` and the second `HANDOFF-20260815b.md` | carry the void branch | **VOID — quarantined** |

**Why 08-15b wins, on the project's own rules.** 08-15b L40: *"**Order.** `[A]`: book 2 follows book
1's order."* — marked as the author's ruling. The 08-16 file L42 justifies its structure as *"the
08-11 design intent carried to book 2 by R3"* — an argument, and **not one `[A]` mark anywhere in
that file attaches to the part structure** (measured by `grep`; they attach to R5.4, the small arcs,
Ch 2's fate and the Levels). By the laundering rule that is not a tie. **And the counter-argument
fails on its own terms:** R3's *"sequenced per the 08-11 design intent"* constrains where the
**transitions** sit relative to the orientations, not whether growth precedes the finer structure —
and 08-15b satisfies R3 anyway, putting the transitions chapter at the head of Part 3.

### How it happened — corrected 2026-08-17, and the correction matters

**The earlier account was wrong.** It held that the artifact was `HANDOFF-20260815.md` circulating
under the wrong name, and that the root cause was a file recorded as deleted that survived. Both
copies of `HANDOFF-20260815.md` have been read. Neither contains the word *Movement*. Neither names
`BOOK2-ARCHITECTURE-20260815.md` even once. Both describe job 1 as *designing* the growth part, with
book 2 at 10,491 words and five chapters — **they were written before any architecture file
existed.**

**The artifact is a real and different file:** the second `HANDOFF-20260815b.md`, md5 `2c46016a`,
4,013 words, no §1.0, Part Two as Movement at Ch 6–12, naming `BOOK2-ARCHITECTURE-20260815.md` six
times and the `b` file never. **It is the legitimate successor handoff of the Movement branch.**

**So the root cause is not a failed deletion. Two sessions minted the same next filename, both
correctly.** Under the dating convention, the architecture session was entitled to call its successor
`20260815b`, and so was the other branch's session, the same day. Nothing was mislabelled and nothing
had to survive a deletion for the fork to happen.

**This kills the remedy the old §7 proposed.** *"Re-date the ruled file forward so it is also the
newest"* does not reach a collision between two files of the **same** date; forward-dating one just
produces a third name a third session could also claim. What replaces it is in §7: status in the
filename, and content screens rather than name comparisons.

**Do not re-argue the structure.** If there is a real case for Movement-first it goes to `[A]` as an
argument, not into a file.

---

## 0. YOUR JOB THIS SESSION — the author picks one

**Two numberings exist and they are not the same. Do not merge them.**

- **The numbered list below numbers *kinds of work*.** Doctrine is job 7 the way the recovery sweep
  is job 5. **These numbers are slots. They never advance and they must never be renumbered** — §1.1's
  rows, and cross-references throughout this file, point at them. Adding a job appends; it never
  inserts.
- **`[A]` also counts *sessions*, and that counter belongs in the session name.** Ruled 2026-08-20:
  the form is `Job<N> doctrine <letter> session <date>`, and since 08-25 he has been giving the whole
  name in the zip — `job18-doctrine-20260825`, then `job19-handoff-20260826`, then `job21-doctrine-20260826`; `[A]` named this file's own session `Job22 handoff 8-27`.
  **That counter lives outside the files, and `[A]` corrected it once mid-session** — so it identifies
  a session and nothing is ever derived from it. **In particular it is not a §0 slot**, and the two
  have collided once.

**A session's identity comes from the manifest label, which carries the counter and the set date —
see §7.** The label is the only name guaranteed to match the set actually in hand. **The session
counter and the §0 slot numbers are different things that both look like "job N"; keep them apart.**

*The 08-20 fold got this wrong in its first cut* — it inserted the depth-and-threshold reservation as
a new item 7, pushing doctrine to 8 while §1.1 and half a dozen cross-references still said 7. **The
error is instructive and is why the rule above is stated as a rule:** a numbered list that anyone may
insert into is a set of pointers that silently re-target.

**1. Branch salvage — DONE. Residues A and B both discharged 2026-08-17.**

Residue A was discharged 08-16: the *How it happened* section of `RULINGS-20260814.md` is headed
**SUPERSEDED RECORD, NOT INSTRUCTION** and its two live-reading sentences are marked discharged.

**Residue B is closed.** Both copies under the name `HANDOFF-20260815b.md` are accounted for:

| Copy | md5 | `wc -w` | §1.0 | Part 2 | Status |
|---|---|---|---|---|---|
| the drafting session's | `8e65f56f` | 5,735 | yes | The Finer Structure | **LIVE — keep** |
| the doctrine session's | `2c46016a` | 4,013 | no | Movement, Ch 6–12 | void, quarantined |

A third file answering to that name was found on 08-18 and screened — see §6, *the third 08-15b*.

**Two corrections the doctrine session made to the 08-16 account, both accepted and both still
standing.** R5.4's placement is **deferred, not void** — the R7 chapters are cut but the material is
not; 08-15b §4 lists Ch 18's leverage and choicelessness, Ch 17's habit and Ch 5's three remedies in
Part 3's inventory, so R5.4's register reasoning survives to wherever practice becomes the subject.
And **the strongest argument against Movement-first is R3's own content**, not provenance marks.

**2. Drafting Part 2 — DONE 2026-08-18. Part 2 is complete.** Ch 6–9 went in on 08-17; Ch 10 (the
figure's own lines) and Ch 11 (leans and the classical wings) on 08-18. See §2 and §8.

**The Ch 11 exclusion is spent.** It said a session that had recently worked on the Z material should
not draft the pairing, and it bit twice — once by reading, once by assembly. The pairing is drafted,
so the exclusion no longer governs any set. **Do not carry it forward as a live rule.** What survives
it is the general form, which is §1.0's: *reading outside the set costs the session, and shipping
outside the set costs it too.*

**3. Book 1 defects and the carrying rules.** Text-touching, never shares a session with doctrine.

**AND THE STANDARD CHANGED ON 2026-08-31. `[A]`: *"i don't intend to try to fix book 1. it's just a
reference for writing book 2."*** **This closes the question this file carried as the permanent one**
— what book 1 is FOR — and it makes his uncertain 08-28 answer firm. **The repair standard that
follows: delete or mark what is false, leave the gap, do not write the replacement.** Divergence
between the two books is not by itself a defect; a false statement in book 1 is, because book 2's
drafting reads book 1 as ground truth. *So this row shrinks in scope rather than closing: what it
still does is delete and mark, and what it no longer does is restore, complete or improve.*
**It ran twice on 08-25** — `Job16`, which prepared the repairs and ruled a great deal on the way, and
`Job17`, which applied **eighteen** of them. Both manuscripts changed and took new names; see §2. The
prepared list is `REPAIRS-job16-book1-defects-20260825g.md` and it is the record of what was applied —
**now ten Parts and four sessions deep, `Job27`, `Job28` and `Job29` having each appended their own
applied work to it rather than cutting a new file.** *That is why it keeps taking letters and why only
`g` goes forward.*

**The job is still open, and what it still owes is older than what it just cleared.** Everything §5
carries from 08-21b and 08-23 is untouched — the transit verbs, the wing-scale clause, Level 0 in both
books, the numeric lean values, the either-or on carrying. **Three further sites were ruled on 08-25
and are in `RULINGS-job18-20260825.md` Part 1 with exact strings, verified to match once each.** That
Part 1 was written so a text session can apply it **without reading the author record**, which is the
point of putting the strings there rather than leaving them in the record.

**None of the older items gets a replacement written by a repair session** — what replaces them is in
`NOTE-fixations-arcs-and-the-two-scales-20260821.md` §8, and writing a replacement is a doctrine act.

**4. A writer 2 pass — LIVE AND WANTED, and GATED. Do not propose it as the next session.**

**TESTED 2026-08-27 AND HELD.** `[A]` proposed naming the next session `job25 writer 0829`. Told that
`writer` is this row, that it is gated, and that the set carries none of the writer 2 files, **he
stepped back and named it `drafting` instead. The gate was not lifted and no session lifted it.** The
naming rule below is what caught it — the second time it has earned itself.

**`[A]`, 2026-08-26:** *"toby is far from ready to look at this material."* And: *"i don't know a
date. it would be good if later sessions remind me that it is still needed."*

**THE STANDING INSTRUCTION, and it must survive every fold.** `[A]` asked to be reminded that job 4
is still needed. In practice that means four things and they pull against each other, which is why
they are written out:

- **Do not propose job 4 as the next session.** It cannot run until Toby Marshall is ready.
- **Do not let it fall silently off the job list.** It is not parked and it is not done.
- **Mention it once, briefly, when a session reviews the job list with `[A]`** — *job 4 is still
  needed and still waiting on Toby.* One line. Not every turn, and not as a nag.
- **`[A]` reopens it. No session decides the gate has lifted.**

**TOBY MARSHALL HAS RECEIVED NOTHING. No session output has ever reached him.** *This is stated flatly
because `[C]` got it wrong: `[A]` pasted output from a session he had opened with the writer 2 files
in it, and `[C]` read it as a comment from the writer himself and built a send plan on top of it.
`[A]`: "you did work in preparation for the writing but i have given nothing to the writer."*

**A NAMING RULE THAT FOLLOWS — say which you mean every time.** *Writer 2* is both a person and a row
on this list. `[C]` slid between the two across many turns. **When a name denotes both a human and a
job, name which one.**

**The brief and the extract.** **`BRIEF-writer2-ch1-4-20260821.md`** is the authority for the set.
**`BOOK2-Ch1-4-for-writer2-20260821.md` IS NOW STALE, AND THIS TIME IT IS A MEASUREMENT — reversed
2026-08-30.** It is the master's first 363 lines, front matter through Ch 4, 5,653 words. **On 08-26
and again on 08-27 a re-cut came out byte-for-byte identical and this file said in bold that the
extract had never been stale. That was true then.** `Job27`'s metaphor pass on 08-29 then changed
book 2 at 24 sites, **and at least four of them are inside the extract's own range** — measured
2026-08-30 against `BOOK2-20260830c.md`, in the Ch 2 type profiles and in Ch 4. **The range itself is
still right:** Ch 5 begins at line 364, so `head -363` is still the cut. **Re-cut and hash it before
anything goes to writer 2; do not send the 08-21 file.** *Nothing is blocked by this — job 4 is gated
on Toby Marshall anyway.* **The lesson runs both ways now:** the old claim was an inference from the
master having been revised and was wrong; this one is a measurement of the range and is right. **Hash
it. Do not reason about it either way.** *And the practice this file already prescribes — whoever
revises the master re-cuts and hashes the extract — was not followed by any of the four sessions that
revised it.* A file minted as
`BOOK2-Ch1-4-for-writer2-20260826.md` is **withdrawn**: same bytes take the same name, and minting a
new date for identical content announces a revision that did not happen. *The 08-16 marked review copy
through Ch 7 is stale by later edits; do not send that either.*

**THE GENERAL LESSON, and it cost five days: do not trust a *this file is stale* claim that names a
revision rather than a measurement.** Hash it.

*One thing to say in the brief when the extract goes: the table of contents at line 27 lists Chapter
5, which is not in the extract. Correct for a front-matter cut, but it reads as a missing chapter
unless the range is declared.*

**Four ruled changes are unapplied in that range and three land in Ch 4** — the native-competence
clause, looking-versus-seeing stated in detail, and his own open objection to caution being *arrived
at deliberately*; the fourth is R9 joining Ch 1's closing paragraph. **Two of them are his and he has
never seen them applied.**

**HIS Ch 4 OBJECTION IS RESOLVED AS WORDING, NOT DOCTRINE — and `[A]` ruled who resolves it.** The
objection was that Ch 4 has caution *arrived at deliberately* where enthusiasm and detachment are
passive. **The sentence is TRUE as written:** what is arrived at is the *competence*, not the
orientation — *understanding* is the nearest antecedent and the dash-clause unpacks a method for
acquiring it. `[A]` corrected `[C]` on this after `[C]` had spent two exchanges treating the sentence
as doctrinally false. *`[C]`'s fault, worth carrying: having offered the grammatical reading first, it
abandoned it on `[A]`'s say-so instead of holding it up against the answer. **When `[A]` answers a
question `[C]` posed, `[C]` still owes him the check.*** What is actually wrong is the *effect* — B's
paragraph carries an acquisition sentence that A's and Z's do not, so the contrast reads as being
between the orientations rather than between their competences, and that asymmetry survives any
wording change.

**`[A]`'s ruling: *"let the writer discuss it with me then."* So THE EXTRACT GOES AS-IS.** The caution
sentence is not repaired before sending. Writer 2 is told the claim was about the competence, that he
read it as most readers will, and that the wording is open — and he proposes to `[A]` directly. *A
`[C]` wording exists and is recorded at §5 so it is not lost, **not so it is applied**. If writer 2
proposes something better, his wins; reading for effect is what he is for.*

**DO NOT ROUTE THE DENIAL SENTENCE TO HIM WITH IT.** Four lines below the caution sentence, inside the
same extract, Ch 4 carries *That is denial, and it is not a decision: a decision to not see could
happen only after a thing has already been seen.* **The same sentence is in book 1's Ch 5.** Its
conclusion stands; its stated *reason* does not, on `[A]`'s 08-26 account, where something deep has
seen and the correct form requires having **consciously** seen. **That is a doctrine repair awaiting
his ruling, in two books, and it is not a reading-for-effect question.** *Two volition sentences forty
words apart on two different tracks — easy to fuse by accident, which is why it is written down.* Part 1 has been left unopened twice and the standing note is that the
accumulation should be looked at as a whole; that pass is the occasion.

**That session may run in parallel with a doctrine session** — it is a text job on Part 1, and the
doctrine questions left below touch Part 2 and Part 3. **It must not be given the author record**,
which disqualifies a text session, and the brief says so on its face.

**5. The open recovery sweep.** Unchanged from 08-15b §0 item 5. Needs a fresh session.

**6. Part 3/4 architecture. STARTED — it ran on 08-30 and 08-31, and the live file is
`BOOK2-PART34-ARCHITECTURE-20260902e.md`, 14,160 w.** `BOOK2-PART3-PROVISIONAL-20260815.md` is
superseded by it; quarantine that, **except that its appendix proposal at §3A is NOT superseded and
is carried forward unexamined.**

~~**THIS IS THE NEXT SESSION, AND `[A]` CHOSE IT ON 09-02:** *"i need help rearranging everything.
should i go back to job 34 or start a new architecture session?"* **A new architecture session.**~~
**RAN 2026-09-02 as `Job42 architecture 09022026`, and the question it was chosen for is ANSWERED.**
`[A]`'s ruling on where the fixation descriptions live is carried out as a **ruled placement at the
architecture file's Ch 15**, in the form he set for the recursion chapter. Ch 15 gains a descriptive
first half — detachment's range, the four fates and the blocking paragraph, which fixation handles a
fear, and the four sketches — and **Ch 16 gives all four up and keeps the axis**. Ch 11 keeps the
wings, the leans and the three-things distinction. **`OPEN-from-job41-20260902.md` is spent** and
stays in the set as the record of what was found. *Not a re-run of the census, which is live and
nothing has contradicted.*

**WHAT THIS ROW OWES NEXT IS NOT ARCHITECTURE.** The placement is a specification and the master is
untouched; **applying it is job kind 11's** — see that row. What stays with this row is Part 4, which
has never been drafted.

**THE ROW'S SET CHANGED 2026-09-02 AND THE CHANGE IS LOAD-BEARING: `BOOK2-20260902b.md` IS IN IT.**
The row carried no master, which was right while Part 3 was unwritten and the job was specifying
chapters that did not exist. **The material to be rearranged now lives inside the master**, so a
session working from the architecture file alone would be rearranging a specification while the
manuscript it describes sits outside the room.

*~~The part still cannot be drafted~~ — **spent 2026-09-02. Part 3 is drafted and placed.** The
architecture file's §6 is the record of what blocked it, corrected 2026-09-02, and its Part 4 material is still live.* **It has grown a new inherited question — see §0
item 7 and §6, *what Part 3's sequence is made of*.** Carried item, branch-independent: *the overlap note's §1 is the mechanism of
the drift the falling chapter describes; it is unruled; the chapter describes the drift and does not
explain it.* ~~Falling is Part 3's **Ch 16**.~~ **Falling is Ch 17 — the renumber of 09-02, missed in that pass.** Input:
`JOB6-ONLY__NOTE-growth-specs-void-branch-20260815.md` — see §1.1 and §7. ***That input did not arrive
in the `job42` set, with three other files the row names.*** **`Job41` carried its own drafting set
forward whole instead of assembling to the row**, and `[A]` supplied the four by hand when `Job42`
reported it. **A set is assembled from §1.1's row for the job, not from the set that arrived.**

**7. Doctrine — the remaining rulings. THIS IS THE CONTINUING JOB.**

**The 08-21 session closed the whole first group by relocating it.** `[A]`: *the endeavor is what
sticks at the fixation; the thought arc was a red herring.* Arcs do not stall, endeavors do, and the
two were one question only because book 1's own section announces the thought scale and then
describes endeavors. Everything about stalling is settled and the definition is given — **where one
habitually stops**. Full account, with the measurement and the repairs it generates, in
`NOTE-fixations-arcs-and-the-two-scales-20260821.md`. **Read that before taking anything below.**

**The 08-21b session closed six of the eight.** All six are written up at §6 under *Closed on
2026-08-21, the `2f` session*. In one line each: the two scales are one shape at two sizes; the memory
claim is withheld from the text but not withdrawn; weight and permanence are two variables; what is
carried past detachment is not the neighbour trace; the carrying is neither a switch nor a width; and
the clause on what arises stays cut with no replacement.

**The 08-23 `2g` session closed the second of the two.** See §6, *Closed on 2026-08-23*.

**One remained after 08-23. Three sessions in two days put four more back on the list, and the
reserved one is still below.**

- **~~The fall-account repair~~ — CLOSED 2026-08-27 by `[A]`: the availability claim is DISSOLVED, not
  repaired.** There is no such event as a full-axis collapse, blindness accruing in fractions of a
  level one crossing at a time. **It is in neither manuscript** — only in `RULINGS-20260816.md` — so
  this repairs no book text. **He refused the second half:** *i don't know whether 9 is extreme.* What
  replaces the claim is unsettled; see `NOTE-the-dwell-and-the-brake-20260901.md` §3.3. *The standing
  question since 08-21b, and the oldest thing on this list.* **What the session found while answering
  the follow-up is much larger — the dwell, the cross-talk and the brake; read that note.**
  *Retained, the question as it stood:* R2's full-axis collapse *"available in full
  only to the 9"* rested on an arc count R11 superseded, and R11 states that the ruling is owed rather
  than assuming it survives. **The standing question since 08-21b. The 08-26 session finally took it —
  and was overtaken by a larger result before it closed.** What that session reached, unruled: the
  claim is **dissolved rather than repaired**, because blindness accrues in fractions of a level one
  transition at a time and there is no such event as a full-axis collapse; what replaces it is a
  rate-and-correlation claim, the 9 being the type whose two realms are both decided in the same
  terrain. **`[A]` has not seen it in that form. Still open, and now with a candidate answer to accept
  or refuse.** See `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md` §7 **as corrected by
  its §11.3 — read §11 before §7.**
- **THE SPLIT AT DETACHMENT IS DEFINED BY SIGHT — RULED 2026-08-27 by `[A]`.** Not by the examination
  having completed. **Book 1 and book 2 were testing it differently and nobody had noticed**: Ch 15
  defines the clear side by the route the resolution took — *through* examination against grabbed to
  *skip* examination — while book 2 Ch 11 defines it by how much of the realm registers. **Acceptance
  is the case that pulls them apart**, book 1's letter filing an accepted fear as blind and book 2's
  filing it clean. `[A]` ruled for book 2. **Book 1 Ch 15 L1462 is now a defect with a site, and the
  repair is bigger than a wording swap** — the sentence's own example, *"it's fine, never mind"*,
  belongs to a condition the book did not have. **Not repaired: who writes replacement wording for
  what a doctrine session closes is still unanswered, and it is now blocking this.** Do it in one pass
  with the *habitually stop* sentence in the same stretch. See
  `NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` §3 and §5.1.
- **FORGETTING AND BLINDNESS ARE TWO DIFFERENT CONDITIONS — RULED 2026-08-27, and ruled NARROWLY.**
  What is ruled is **the difference, not the test for it**; `[A]`'s remark that they react differently
  to a challenge came before the commitment and the commitment names the difference alone. **A seen
  fear can be ignored but not re-buried.** Repeated, ignoring becomes a habit, the habit is general,
  and what it does is **short-circuit the examination** — the fear still registers, the weighing stops.
  **`[A]`'s content and hedged, not ruled.** **The distinction has no home in either manuscript**:
  drafting work, not repair, and not on the job list — it sits beside the brake, which is in the same
  condition. Same note, §2 and §4.
- **THE EXTERNAL ROUTE — ~~OPEN~~ CLOSED 2026-09-03 by `[A]`, and the closing step is URGENCY, not
  stress.** *Retained, the question as it stood:* his 08-27 route ran ignoring → external problems
  accumulate → stress → examination skipped → blindness, and the objection was that skipped
  examination is what he had just defined the ignoring habit to be, so nothing in the route costs
  sight. **`[A]`:** *that seems right. ignored fear doesn't do the blindness descent until urgency
  forces if to go down or up.* **The route as ruled:** consequences gather around a left fear; the
  fear becomes urgent; an urgent fear cannot be left, so it must be weighed or turned away from;
  turning away is what costs sight. **And book 2 Ch 17's *The second way down, which is not
  blindness* ALREADY CARRIES THE WHOLE ROUTE in his own terms** — no session had recorded the
  question as discharged by the drafting. **He also corrected the fork**: it is down or not-down, not
  down or up, since giving up on costs no sight and dissolves nothing. `NOTE-the-want-behind-the-fear-20260903.md` §1.
- **`[A]`'s FOURTH JOB FOR CONSEQUENCES — ~~OPEN, and the 08-27 note called it the largest untouched
  thing in the file~~ CLOSED 2026-09-03, and it was answered on 09-01 with nobody connecting the
  two.** His 09-01 routing mechanism **IS** the comfort-now against comfort-later tradeoff he
  registered on 08-27, with the finding that the later term is the one removed; the
  unconscious/conscious half is his own 09-01 guess. **All of it is drafted, in Ch 17.** What was left
  of it — what determines *success* rather than facing — is answered by §11.1 of the same note: the
  comparison is the same one either way, and conscious response makes the long-term term available to
  be weighed.
- **THE STRESS SWITCH, AND WHAT IT COSTS THE BRAKE — RULED BY ASSENT 2026-08-27, and the provenance is
  thin on purpose. *2026-09-03: STRESS IS NOT THE DECIDER OF THE FORK AND NEVER WAS.* `Job45` offered
  `[A]` a choice between sight and stress and then withdrew it — book 2 Ch 17 already says *which of
  those happens depends on how much sight is left by then*, and `[A]`'s 09-01 mechanism is how sight
  decides. Stress is not in that mechanism. *What this item still covers is whether the press
  mobilises or collapses, which is a different question and is untouched.*** Consequences in the world always press; **stress decides whether the press
  mobilises a person or collapses them**; **the brake is conditional on it**; and the distribution is
  **bounded for most, with a tail** — a population that crosses a stress threshold and does not come
  back. **All three are `[C]`'s framing and `[C]`'s case, carried on single words of assent.** They are
  rulings. But **the tail is a claim about real people and nothing in its wording ties it to the switch
  it came from**, which is the condition `[A]`'s own test was written against. **Whoever revisits the
  switch revisits the tail in the same pass.** Book 2 L594 already contains the switch and does not
  know it. Same note, §1.2 and §7.
- **THE SIGHT PROTECTION ATTACHES TO THE CROSSING, NOT TO THE FEAR — `[A]` corrected this himself,
  2026-08-27 evening, after it had been recorded the other way that morning.** The same fear may be
  seen and set aside on one passage through Z and blocked before sight on a later one. **It costs
  `[C]` an argument made earlier the same day** — that one-way sight makes the way out a permanent
  subtraction rather than a delay. On the per-passage reading, recognition protects one crossing and no
  other, so **the way out is a holding action unless something makes recognition stick, and nothing in
  the model says what would. That is now an open question and a live one.**
- **URGENCY DECIDES WHETHER A FEAR CAN BE IGNORED — RULED 2026-08-27, AND IT IS ANALOG.** An urgent
  fear cannot be ignored; how urgent it must be is a slope, not a line. **This is the model's second
  continuous quantity**, alongside book 2's split at detachment. It shrinks `[C]`'s bridge to one
  claim — **consequences make an ignored fear urgent**, at which point it must be weighed or blocked,
  which is the stress switch in a new place. **And it removed the morning's tail from its
  derivation.**
- **THE TAIL, RE-DERIVED AND WEAKER.** `[A]`: *it's harder to recover, the lower the level one is at
  because one is more debilitated regarding facing reality and that overrides with whatever increased
  motivation one has to escape.* **That ordering is what the model had never supplied.** So the tail
  returns with no threshold — **nobody is barred; the climb gets slower faster than the pressure to
  climb gets stronger.** And **`[A]` then closed the absolute reading: *coming up from the bottom
  happens.*** **There is no absorbing floor**, and the morning's wording overstates it.
- **A SECOND BRAKE — INTERVENTION — RULED 2026-08-27.** *`[A]`: what works is different in each case
  and the person who intervenes needs to find it; it works much better if the intervener has been
  rescued or rescued themselves.* Asked whether the shared experience supplies the content or the
  search, he ruled **both**. **The two brakes work by opposite means**: the first is force triggered
  by consequences and needs no self-recognition, the second **imports sight the person cannot
  produce**. `[C]`'s unruled reading: a person at depth cannot generate the belief that rescue is
  possible, because that belief is about their own condition, which is what the blindness blocks.
  **Nobody has asked whether the second brake is conditional on stress as the first was ruled to be.**
- **SUBSTANCE ABUSE AND THE DESCENT — `[A]`'s, RAISED 2026-08-27, NOTHING DONE ON IT.** His words:
  *we should look at how substance abuse affects the blindness transition and the falling mechanism.*
  **It is a subject, not a claim** — no position has been taken and nothing about it is ruled. It came
  out of the 12-step material he sent the session to, and it asks what that material does not answer:
  **the evidence looked at was about recovery; this is about the descent.**
  *`[C]` framing, not put to `[A]`:* every route into blindness the model has is either psychic or, as
  of this evening, external-and-circumstantial. **A substance is neither. It would be a chemical
  route, and if it bypasses the burial reflex rather than driving it, that is a third kind of thing
  the model has no place for.**
- **`[A]`'s FOURTH JOB FOR CONSEQUENCES — RAISED BY HIM, NEVER WORKED ON, AND IT IS THE LARGEST
  UNTOUCHED THING.** *they motivate a person to try to improve - and what things determine success is
  something we should think about. one tradeoff is comfort now vs comfort later which is related to
  unconscious vs conscious response.* **Unhedged and his.** It contains two things the model lacks:
  what determines whether the attempt succeeds, and a comfort-now/comfort-later tradeoff tied to the
  unconscious/conscious distinction. Consequences now do four jobs. **Whether that is one mechanism
  seen four ways is open — `[C]` asked and got no answer.**
- **EVIDENCE FROM OUTSIDE THE MODEL, FILED AS EVIDENCE AND NOT AS DOCTRINE.** `[A]` sent the session
  to 12-step literature. Bottoms are **self-identified and relative, not fixed** — which is his analog
  reading appearing in data. **`[C]` MADE AN ERROR HERE AND `[A]` CAUGHT IT**: a referral field was
  read as though it described who did the intervening, and the coercion-versus-peers split built on it
  is **retracted**. The follow-up went the other way again — coerced entrants show **higher** retention
  and **less** distress than voluntary ones, read as the voluntary clients presenting later and more
  impaired, which would make compulsion an **interception** rather than a last resort. All `[C]`'s
  reading, one domain, unruled, and the underlying AA effectiveness evidence is itself scarce and
  mixed. See `NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` §14.
- **~~A SWEEP FINDING — a repair record disagrees with book 1 by one word~~ — CLOSED 2026-09-03. `[A]`
  RULED: THE MANUSCRIPT STANDS AND THE REPAIR RECORD HOLDS THE DEFECT.** *`smaller` is doing work —
  the arcs are smaller than the orientation cycle the paragraph has just described.* **No text change
  anywhere; the repair record is where the discrepancy lives.** *Retained below because the finding
  and its reasoning should stay legible.*
  A full `quotecheck sweep` of the set (294 quotations, 29 files) found **every orphan accounted for
  and no quotation drifted from its source**. But `REPAIRS-job16-book1-defects-20260825.md` (now `g`) §2.14 has
  a `REPLACE:` string reading *runs its own arc* while book 1 L550 reads *runs its own smaller arc*.
  **`Job24`'s recommendation is to change the repair record, not the manuscript** — *smaller* is doing
  work. A dated line is now at that entry. **~~Not ruled.~~ RULED 2026-09-03: `yes on the second`.**
- **~~`[A]`'s THREE OUTCOMES AT THE Z CROSSING~~ — CLOSED 2026-08-30. THERE ARE FOUR FATES, THEY ARE
  RULED, AND THREE OF THE FOUR NAMES CHANGED.** **`worked through`, `given up on`, `ignored`,
  `blocked`**, sorted on two questions — whether the fear is in view, and whether it is disposed of.
  Nothing never seen can be disposed of, so **blocked is the only fate on the unsighted side**.
  Within one crossing the fear meets the sighted end first and what survives reaches the end that
  turns away. **Giving up on drops the want behind the fear**, so the fear is gone and a regret
  remains; **ignoring drops nothing**, fear and want both intact and only the occasion let pass,
  which is why it returns. **The first name was ruled `settled` on 08-30 and replaced on 08-31**:
  book 1 already has a fear *settling into a fact*, which is the descent, so the ruled name meant the
  opposite of the fate in the book carrying it. `answered` and `resolution` were checked and are also
  taken. **`worked through` is both books' own phrase.** The ruled table is in
  `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md` §6, above the superseded one.
  *Retained below, because a successor will meet the old shape in quoted notes:* the three-outcome
  account as it stood. *An accepted fear is no longer a fear — "maybe a regret that is
  accepted."* **Only burying descends the axis**; acceptance destroys the fear rather than hiding it,
  so nothing is buried and nothing accrues. Whether it reduces diligence or increases tranquility
  `[A]` left open on purpose — *"maybe either."* Burying versus accepting is **a difference of depth,
  not degree**: some deep part sees the threat and the information is blocked *by design* (his phrase,
  chosen over *intentionally*) from consciousness, the reaction reflexive and reinforced by a second
  unconscious recognition that unpleasant anxiety was avoided — **and the reinforcement was laid down
  when the anxiety WAS at least semi-consciously felt, at a preverbal stage, hidden as rational
  consciousness grew on top of it.** The way out is **not acceptance alone**: it requires conscious
  recognition of the buried fears one by one, *"or better, a recognition of the automatic burial
  process."* **His own "in between" framing for the third outcome is WITHDRAWN — do not reintroduce
  it.** Everything is in `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md`, 5,238 w, which
  **is not citable as doctrine and says so on its face.**
  *Open inside it, each wanting `[A]`:* whether Ch 5's *denial is not a decision* gets its stated reason
  reworded to **consciously** seen; whether Ch 15's *the cycle it turns* meant the orientation cycle or
  the burial reflex; and whether acceptance moves a person at all.
  ***The naming question is WITHDRAWN, 2026-08-27 — it was the wrong question.*** Acceptance is not a
  different arrival needing a name; it is **a second route to the same side of the seam**. Reconciling
  and accepting both arrive sighted and differ in what became of the fear, not in where the person
  stops — **the three outcomes are dispositions of a fear and the Z split is a side of a seam, two axes
  this note's own table had been treating as one.** *And if anyone reopens naming: `resignation` is
  already spent, book 1 Ch 15 assigning it and `regret` to Z− as its B-tinged affect; `relinquish` is
  spent the other way, book 2 L844 using it for the good crossing itself.* See
  `NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` §3.1.
- **NEW 2026-08-27 — DETACHMENT NOW HAS A PROCESSING ACCOUNT, and the model had none.** `[A]`: the
  fear lives in a **realm**, so the fixation handling it is that realm's, not the person's type.
  Enthusiasm and caution act on a fear **before** the crossing; **detachment acts at it, by dwell
  time** — Z− is slow and processes more, Z+ is quick and processes less. **And a fixation is where
  the process moves very much more slowly, NOT where it halts** — RULED, as doctrine only; *the
  wording is open and he said so.* **Two sentences now need new prose and none exists:** book 1 Ch 15
  and book 2 Ch 7. `occupies` was suggested by him and set aside. See
  `NOTE-the-dwell-and-the-brake-20260901.md` §1, §3, §6.
- **NEW 2026-08-27 — THE BRAKE, and it is the least settled thing on this list.** The level feedback
  makes the descent feed itself; `[A]` rejected *most never start* — *a bell curve with most people at
  average levels*. **His brake: people struggle harder when things go bad, and others support them.**
  It survives the blindness because **the trigger is consequences in the world, not any recognition of
  one's own condition.** His correction of `[C]`'s framing: the effort is **resisting the
  consequences**, and fixing or hiding are the optional routes — **blindness selects the route rather
  than weakening the response.** And **wanting not to know runs at every level**, not from Level 7
  down, which he called a corollary of the blindness mechanism and **declined to rule**. **NOTHING IN
  IT IS RULED.** Note §5.
- **NEW 2026-08-27 — cross-talk between realms.** What crosses is **plain wariness** — *maybe not the
  details but the need for caution* — not capability, not content, and **not caution the orientation**.
  Gated on the person knowing the realms are two. *Attached, hedged, and DELIBERATELY NOT IN THE TEXT:*
  **leans move slowly** (`[A]`'s word for them is now **long lasting**, alongside *static*), and
  **orientations move only if Riso's basic fear is dissolved, if at all.** He is content not to mention
  lean movement for now. Note §4.
- **`[A]`'s correction that governs that whole note, and it separates two things `[C]` had fused:
  blindness happens ONLY while traversing Z.** Spoilage is a quality of an arrival at any node,
  momentary, no debit; **blindness is an accrual at the Z crossing only, in fractions of a level, and
  it locks.** They coincide at exactly one of the three arrivals.
- **~~Book 2's Ch 7 contradicts a ruling two days older than the chapter~~ — CLOSED 2026-08-29 and
  2026-08-30, and mostly by being wrong about the scope.** `[A]` ruled the disintegration direction a
  **lean, not a movement**, which leaves the headings, the three route narrations and the figure
  standing; what was genuinely wrong was the `runs` collision and the claim that an ARRIVAL can be
  reached backward, both repaired. **And the doctrine question this item said had to be answered
  first is answered:** Ch 7 describes detachment's two **faces** and the lean directions; the crossing
  mechanism stays in Ch 11. **See §5 and §6.** *What is left is `[A]`'s call on two deprecation
  markers in book 1 and the larger question of what book 1 is for — §6.*
- **~~WHAT BOOK 1 IS FOR~~ — CLOSED 2026-08-31 by `[A]`: *"i don't intend to try to fix book 1. it's
  just a reference for writing book 2."*** **The permanent question is answered.** His uncertain
  08-28 answer is now firm, and the repair standard that follows is **delete or mark what is false,
  leave the gap, do not write the replacement.** So book 1's missing crossing account is **a gap to
  leave**, and the two-books question that hung over every repair decision since 08-28 is settled.
  *It was listed as one of three things to ask him before starting and went unasked for three days
  more; `Job33` asked it.* **What this creates is the census — see below.**
- **THE B-SIDE ACCOUNT — the largest DRAFTING item outstanding, and nothing about it is ruled.** The
  whole current thread is scoped by `[A]` to fears arriving at detachment from **enthusiasm**.
  **Nothing anywhere is written for fears arriving from the CAUTION end.** A drafting session would be
  inventing. *It has not moved since 08-27.*
- **HOW THE THREE ORIENTATIONS KNOW — captured 2026-08-29, unruled and unsited. Do not draft from it
  without asking.** A knows the superficial and easily understood; B knows more about the complicated
  aspects of certain parts and misses others more completely than A; Z sees the whole picture but
  attends only to parts. **Belongs where the orientations are introduced.**
- **~~Appendix G and Riso's chain~~ — CLOSED 2026-08-26. `[A]`: *yes, four.*** The appendix's formal
  rule had D(n) generating F(n) directly and omitted attitude and behavior; **it now states four
  terms.** See §5 for the ruling and what it costs. **The half of that item asking whether App G's
  *top and exit* rule matches his corrected reading of Riso's chart is ALSO closed, and was closed
  earlier — by the 08-23 Level 0 abolition, which came out of exactly that chart correction.** App G's
  F(1) fork is already a named repair site in §5's Level 0 block. *`DEFECTS-carried-forward-20260825b.md`
  still lists both halves as open and says the question has never been put to him; **it is wrong on
  both, and it was accurate when written.** See §6.*
- **NEW, and it is what the four-term ruling created rather than settled: the SIX-WAY DERIVATION.**
  Attitude and behavior for each of the three orientations in each of the two realms — the six
  half-types. **It needs Riso and Hudson's own table of four attributes across nine types and nine
  levels, which is in no current set and cannot be done from memory.** `[A]` wants permission to
  reproduce that table sought as well: *"and better, both."* **The order he accepted:** a doctrine
  session states the four-term chain and why the middle terms belong; a separate session does the
  derivation with the source in hand; the letter to the Institute goes **after a complete draft and
  before style polish** (his own reasoning: they cannot evaluate what they would be lending it to
  until the argument is finished); and **permission is not planned around** — the appendix must stand
  without the table and gain from it if it comes. *Two cautions he did not dispute: the derivation may
  not be a clean inference, since attitude and behavior are exactly the two attributes said to get
  their value from type-level specificity — some rungs may derive and others not, **and that result is
  itself worth having**. And the ask is not one thing: whole table, selected rungs, paraphrase without
  the table, cite and point. Deciding which rung is acceptable in advance makes a partial answer
  usable. Whether any of it needs permission at all is a legal question and `[C]` is not a lawyer.*
  **This has no §0 slot and wants one; `[C]` did not mint it.**
- **`[A]`'s own question from 08-21, still not answered back to him: *do we need thought arcs anywhere
  else?*** Job 16's `arc` census answers it incidentally. **The question was his and deserves a direct
  answer rather than an incidental one.**
- **How the way UP the levels differs by fixation — minted by `[A]` 2026-08-25, and he named the null
  result as a real possible answer.** Two things bear on it in opposite directions: the descent now has
  per-fixation routes, which would make the obstacle fixation-shaped; but the climb is said to run on
  one faculty, and what has to be faced is necessarily vague, which would make the act the same
  everywhere. Material in `NOTE-resolution-rate-and-the-descent-20260825.md`. *Caution for whoever
  takes it: Riso's text carries per-type ascent material at every rung, and the limit on what the
  correspondence can bear applies going up as much as going down.*
- **NEW 2026-08-31 AND ROUTED HERE BY THE CENSUS — THE TWO FACES OF Z0, AND THE TOP OF THE HEALTH
  AXIS. Take it as ONE question with the Ch 15 hazard, not as two.** Book 1 holds **realm-Z0 as
  deliberately two-valued** — the mirror's stance is silent about whether the glass is polished or
  fogged, and the health axis alone decides — and **fixation-Z0 as one-faced**, because total
  blankness toward one's own fixation is fusion with it rather than a stance toward it. **It then
  flags the consequence itself: if blank unawareness of one's own pattern does deserve the name Z0,
  the top of the health axis becomes harder to place, since Level 1 is read as Z−.** That is the same
  problem the Part 3/4 architecture already carries at Ch 15 — *Level 1 is Z−* being an identity in
  the currency only, with three later passages stating it flat where the correspondence hedges it.
  **Neither knew about the other.** `fixation-Z0` and `realm-Z0` occur nowhere in book 2, nowhere in
  either architecture file and nowhere in the rulings; they survive only in book 1, in a future-work
  list nobody was going to search. *`job34` lifted it out of that list while cutting the section, and
  said explicitly it is not architecture's to settle.*
- **NEW 2026-09-01 — A CLAUSE `[A]` RETRACTED IS BACK INSIDE A PARAGRAPH HE APPROVED. HE HAS NOT SEEN
  THIS AND IT NEEDS HIM BEFORE THE SKETCHES ARE PLACED.** The closing paragraph he approved for the
  rewritten sketches on 08-31 reads *and where it differs, the fixation has selected the population
  of arisings before any endeavor begins.* **That is the clause he retracted on 08-20** — *i
  don't/no longer agree* — and ruled deleted whole from book 1's Z+ sketch on 08-26, on the argument
  that what sources the arisings is an open doctrine question. **The replacement paragraph was
  written to solve a real problem** (the new sketches walk the phases in order, which invites a
  reader to conclude the fixation is one of them) **and it solves it with the retracted claim.**
  *The paragraph is unapplied and the sketches are unplaced, so nothing is wrong in either book. What
  is wrong is that it is queued.* **Do not apply the closing paragraph until he rules.** Details and
  the exact string at §5.
- **NEW — THE CENSUS OF WHAT BOOK 1 HAS AND BOOK 2 LACKS, and it is `[A]`'s instruction:
  *everything in book 1 that doesn't go into book 2 should be carefully decided.*** The first pass is
  `CENSUS-book1-into-book2-20260901.md`, 3,180 w. **It is not finished** and what it did not reach is
  its §6: the section-level pass over Ch 5 through Ch 11, and the Foreword and Introduction,
  compressed 1,790 w to 651 w and not examined at all. **`[A]` on what it will keep turning up:** *a
  lot of ideas have changed since book 1, but a doctrine session will handle that i guess.* **The
  answer given and recorded: the census never judges whether an idea is still right, only whether a
  decision exists** — where a ruling superseded an idea, that ruling IS the decision and the unit is
  cut with nothing reopening.
- **STILL NOT ASSEMBLED, DELIBERATELY, BY THREE SESSIONS RUNNING — THE FIRST BRAKE.** `Job31` held it
  back, `Job32` held it back, `Job33` declined to become the third. **`[A]` asked directly whether he
  should agree to an assembly and was told no**, because assent to an assembly covers `[C]`'s
  selection and joining, which he cannot audit from inside a summary `[C]` wrote. **The pieces go
  forward separately and checkable; the join does not.** *Do not open a session by presenting the
  assembled case.* The problem it would resolve is still open: stress interferes with weighing,
  consequences drive mobilisation, both rise with depth, and nothing says which wins by how much.
- **`[C]` FLAG, CARRIED FROM 08-30 AND STRENGTHENED SINCE — THE MODEL MAY NOW OVERPREDICT THE FALL.**
  Entry into blindness has been made easier with depth **three** times, all by `[A]`'s own material
  and none of it posited to explain the descent: bearability falls as stress and ordinary suffering
  rise; the maintenance loop widens as burials accumulate; and the retraction of *does not turn into*
  opened an internal route where the external one previously stalled. **The engine has been
  strengthened three times and nothing has been added to the brake.** *This is `[C]`'s objection and
  not a finding of `[A]`'s.*
- **Where the deposits enter the book — ruled as MECHANISM, not identity, and the siting handed over.**
  `[A]`, `RULINGS-job18-20260825.md` §2.4. **That makes the remaining question job 6's rather than job
  7's**, and it is listed here only because job 6 has not started. `[C]`'s recommendation with its
  reasons is in that file's §2.5 and is explicitly not a ruling.

**Arc occupancy is gone rather than answered.** With the numeric lean values retired there is no
midpoint to occupy and the question cannot be posed in the notation. See §6. *`[A]`'s separate flag
that caution's forward lean may never reach detachment's backward one — that the circle may not be
continuous — is untouched by that and stays open. It is a bigger claim and needs its own argument.*

*Why doctrine before job 6:* doctrine and text never share a session, and the Part 3/4 architecture
would otherwise be built on the same unruled material Ch 11 had to step around.

**8. The depth-and-threshold question — RESERVED, AND IT MUST HAVE A SESSION TO ITSELF.**
See §6, *does depth set the overwhelm threshold*. Flagged on 08-19 as the largest thing raised that
day and deliberately left; `[A]` added to it on 08-20. **It is a job in its own right rather than a
doctrine item**, because it is the one question that joins the two coordinates and a session that has
been arguing about either one has a view about it already. It is not to be taken alongside anything
else. **Appended as 8, not inserted** — see the rule at the head of this section.

**9. Cutting a handoff — MINTED BY `[A]`, 2026-08-26: *"you are a handoff session."*** The question was
raised about `tools` on 08-24 and deliberately left unminted; it was put again on 08-26 with a second
instance in hand, and answered. **Appended as 9, not inserted.**

The work is: read the outgoing handoff through, fold in what the sessions since produced, and cut a
successor. **What makes it a kind rather than an interruption is its disqualification profile, which
is what §1.1's rows exist to encode.** It needs the record **carried and unread**, so that the option
of drafting survives the session; it needs **both manuscripts present and untouched**, because the
repair list is checked against them and never applied from them; and it reads more of the handoff than
any other job, which is what §7 says earns the right to cut a successor rather than an addendum.

**10. Tools — MINTED BY `[A]`, 2026-08-29.** Raised about `tools` on 08-24 and left unminted, put again
on 08-26 and left, minted on 08-29 when `Job26`'s §1.0 found that the check everyone relied on does
not do what it says. **Appended as 10, not inserted.**

The work is the scripts themselves: `setcheck.py` and `quotecheck.py`. It touches no doctrine and no
book text, and it needs neither manuscript. **Two items are waiting for it:**

- **`setcheck.py verify` does not compare word counts.** It computes each file's count and only ever
  prints it inside the mismatch branch, so ok-or-mismatch is decided on the md5 alone and the
  declared word column has never been checked in any set. Its manifest parser also takes the third
  column as the word count, so a manifest whose columns are ordered differently is misread in
  silence. Both need the same pass. *Found by `Job26` §1.0: `MANIFEST-job26-20260829.md` carried
  `C.UTF-8` counts on all 31 rows, 1–2% high against the declared `LC_ALL=C`, and verify called it
  clean. The bite: the handoff's version block said 44,318 and the manifest said 45,103 about the
  same correct file, so a session checking against the manifest condemns its own handoff.*
- **`setcheck.py` fires `CARRY, DO NOT READ` on itself**, because it holds that sentence as the
  literal it searches for. A known false positive since 08-24; it should be exempted by name.

**A manifest is generated by `setcheck.py manifest` and never typed.** The 08-29 manifest's counts
came out in `C.UTF-8` because something shelled out to `wc -w` without setting the locale, which the
tool never does — `count_words()` reproduces `LC_ALL=C wc -w` without calling `wc` at all.

**Both of that row's items are DONE as of 2026-08-29, by `Job27`, riding at the front of a defects
session rather than taking one of its own.** `verify` now compares declared word counts and has a
fifth verdict, `BAD COUNT`; its parser reads the column order off the header row; `screen` no longer
fires on itself; and `quotecheck sweep` no longer lists a CARRY-DO-NOT-READ file as a document.
**The slot stays. It is not closed** — a tool defect surfacing inside other work is exactly how these
two sat unfixed from 08-21, and the argument for the slot was never that the queue would empty.

**11. Composing prose for ruled doctrine into already-drafted chapters — `[A]` ACCEPTED THE MINT
2026-08-29; THE NAME IS NOT FIXED AND IS HIS.** *He agreed a new kind was needed for this work and it
was never written into a job list, so it is appended here as 11 to stop the slot being invented twice.
**Appended, not inserted.*** **It is distinct from two things it keeps being confused with:** the
CLOSED *drafting Part 2* slot, whose activity is still owed for Parts 3 and 4; and job 3, which
applies a prepared list of exact strings and writes no prose. `Job25` and `Job29` both ran as this
kind under ad-hoc names — `job25-drafting-20260829`, `Job29 book 2 ch 7 drafting 8-30`.

**Its disqualification profile, which is what a row is for:** it writes new prose, so it must NOT read
`AUTHOR-RECORD.md` — `Job25` declined a narrow carve-out on exactly this ground and was right, since
the carve-out's own test covers repairing sentences and not writing new ones. **Its set is job 3's
plus the notes carrying the doctrine being composed**, and **both manuscripts**, since what it writes
lands in one and is checked against the other.

*One thing to put to `[A]`: what the kind is called. `[C]` did not name it, because a job kind is his
to mint and half-minting one under a `[C]` name is how a slot gets claimed twice.* **`Job33` ran as
this kind on 08-31, under the name `Job33 drafting 08312026`, and ran on the job 7 doctrine set
because §1.1 had no row for it. It now has one**, written 2026-09-01, headed by the slot number and
not by a name. **The row is `[C]`'s; the name is still his and still unminted.**

---

## 1. FILES

### 1.0 FIRST — check what you were given

**Before starting, compare your inputs against the set for your job below. Say what is missing or
extra, in one line, and ask for the missing files before you begin.**

The failure mode is silent: a session that reasons from summaries because it was not given the full
file does not know that is what it is doing. **It has happened four times.** The 08-15 verification
session worked from the consolidated file's summaries and manufactured a conflict the full R5.2
resolves. The 08-15 architecture session asserted what `VERIFY-20260815.md` contained without having
it. The 08-16 doctrine session architected book 2 without `BOOK2-ARCHITECTURE-20260815b.md`. And the
08-16 drafting session spent half a session executing the file that produced.

**If you were given more than your job's set, say so too. Extra files are not harmless — and this is
demonstrated, not asserted.** The 08-17b session was given the correct set, then read a further
twenty-odd stale files during the salvage, and that reading is what disqualified it from the drafting
job it was assembled for. Reading outside the set costs the session.

**And the screen has to run at assembly, not only on arrival.** §1.0 as written catches an extra file
only once a session has read it, which on 08-18 meant reading the one file that disqualifies the
reader. A receiving-end check cannot protect a session from what it has already been handed. **Before
a set goes out, screen every candidate and act on the VERDICT, not on the count.** **Two literals are
searched for and they mean opposite things.** `RESTRICTION_STRING` — *does not go into a drafting set*
— is the job 6 note's, and it means **drop**. `CARRY_NOREAD_STRING`, added 2026-08-25, is the author
record's, and it means **keep it in the set and do not open it**. **Do not type either grep by hand —
run `setcheck.py screen <dir>`**, which holds both literals and is the authority for them. *A file
that quotes a literal fires on it — this handoff does, and `setcheck.py` matches itself. That is the
screen working; read the hit before acting on it.*
Any file that is live but restricted to one job carries such a line and a prefix in its name; see §7.

**Run `setcheck.py verify <manifest> <dir>` and report its own printed summary, not your reading of
it. THE SUMMARY HAS FIVE FIELDS SINCE 2026-08-29, not four:** *N ok, N mismatched, N bad count, N
missing, N not in the manifest.* **`BAD COUNT` means the md5 matches and the declared word count does
not — the file is right and the manifest row is wrong**, and it exits 1. *`Job27` added it after
`Job26` found that `verify` had never compared word counts at all and that its parser read the third
column as words; a whole manifest of `C.UTF-8` counts had passed clean.* On 08-21b the summary was:
**18 ok, 0 mismatched, 0 missing, 0 not in the manifest** — but only at the
fourth attempt. **Three files silently failed to transfer on the first delivery and one more on the
second**, and every file that did arrive matched its md5 exactly. **A partial set looks like a clean
set if you only read what you were given**, which is the whole reason this section runs before
anything else. Say what is missing and ask for it; do not start on the rest meanwhile.

**Read the verdict; do not count the hits.** *This line used to say the screen fires three and that a
fourth is a real one. **It went stale twice on the number alone** — once when a job 3 set correctly
excluded the author record, and once when the third verdict was added — and both times a session had
to work out that the text was wrong rather than the set. What fires is set-dependent; what a verdict
means is not.*

**FIXED 2026-08-29, and the line is kept because a successor will meet the old warning elsewhere in
this file:** `setcheck.py` used to fire `CARRY, DO NOT READ` on itself, because it holds that
sentence as the literal it searches for. **`Job27` exempted it by name and the exemption is printed.**
Both tools now exempt themselves, so a screen that fires on a tool is a real hit.

**A REAL DEFECT, found 2026-08-25 and FIXED 2026-08-26 — and it was TWO sites, not one.**
`RECOVERY-NOTE-20260825-procedural-changes.md` fired **drop**, because it quoted the OLD restriction
sentence whole in its *before* block. **This is the exact trap the note itself warns about** — it
breaks the new string carefully for itself and left the old one intact. **An assembler obeying the
screen would have dropped the one file that explains how to undo the 08-25 changes.**

*Two sessions deferred the fix and three files described it as one line break at line 52. **The
literal also stood whole at line 85**, inside backticks, in the sentence saying what the screen used
to fire on — so the repair exactly as described would have left the file firing and been reported as
done.* Both sites are broken now, the way the note already breaks the new string for itself, and the
file takes a letter: **`RECOVERY-NOTE-20260825b-procedural-changes.md`, 1,470 w, md5 `d490518f`.**
Quarantine the unlettered file as `SUPERSEDED__live__`. **The general lesson is not about this note: a
defect site named in three files is still only the site somebody looked at. Grep for the literal; do
not go to the line number.**

**BOOK 1'S LINE NUMBERS NO LONGER LAND, AND THE DRIFT IS NOT A CONSTANT — MEASURED 2026-09-01.**
This file used to say that book 1's line count had held at 2,566 through every revision since `c`,
deliberately, so that **every `L####` citation anywhere in the set still lands**. That is now false.
`rev2-0814q.md` is **2,594 lines**: `Job33` rewrote the fixation definition and the two faces of
detachment inside Ch 15 on 08-31 and the paragraphs grew.

**Measured against two passages this file cites by number:** *not a stance freely taken but a place
arrived at* has moved from 1546 to **1574**, and *the measured lean is trait plus fluctuating state*
from 2463 to **2485**. **That is +28 in one place and +22 in the other**, so something further down
was shortened in the same pass and **no single offset corrects it**. Citations below roughly line
1462 are untouched — the deprecation markers, the Nine's blind-spot paragraph and the resisting
sentence all still land where they did.

**Seventy-three citations sit above the break**, across seven files: **thirty-eight in
`BOOK1-INDEX-20260815.md`**, twelve in `OPEN-from-job25-20260829b.md`, thirteen in this file, and the
rest in the repairs record, the drafting-findings note, the doctrine brief and the resolution-rate
note. **Book 2 moved too**, 868 lines to 872, so citations made against it since 08-29 have the same
problem in miniature.

**THE RULE, AND IT REPLACES THE GUARANTEE: locate a book 1 site by content, never by line number.**
`grep` the sentence. The book 1 index already carries this instruction in its own voice — section
titles are the reliable handle and line numbers are for one file version — and it is now the only
way to use that file. *Nothing here says the citations are wrong about what they cite; it says the
number no longer finds it. A citation checked and found to land is still evidence; a citation
followed to a line number is not.*

**§1.0 is the safeguard the void handoff dropped. Never drop it from a successor.**

**§1.1 IS UPDATED IN THE SAME PASS AS ANY SUPERSESSION — this is not bookkeeping tidiness.**
§1.1's rows are what an assembler reads to build a set. A row still naming a superseded file puts
that file in the next set, and it does so silently, every time, until someone notices. **This is
demonstrated:** the 08-24 delivery arrived carrying `NOTE-level-1-and-the-summit-20260821.md`
alongside the `b` file that had replaced it the day before, because §1.1's job 7 row and a second
pointer at §6 had not been updated when the note was revised. A supersession is not finished when
the new file is cut and the old one renamed; it is finished when every row that names the old file
names the new one.

### 1.1 The sets, by job

**RESOLVE THESE TWO NAMES BEFORE READING ANY ROW — added 2026-09-06 and it governs the whole
section.** **Wherever a row below names `rev2-0814q.md`, `rev2-0814r.md` or `rev2-0814p.md`, read
`rev2-0814t.md`. Wherever a row names `BOOK2-20260902b.md`, `BOOK2-20260904b.md`,
`BOOK2-20260905.md` or `BOOK2-20260906.md`, read `BOOK2-20260906b.md`.** The older names are left
standing inside history sentences that were true when they were written. *The kind 11 row carried
this instruction for itself from 09-04; it is promoted here because every other row needed it too,
and **a row naming a superseded master puts that dead file in the next set, silently, every time.***
**And `STYLE-GUIDE-20260906.md` replaces every earlier style guide named in any row.**


| Job | Files |
|---|---|
| **1 — branch salvage** | **CLOSED.** |
| **2 — drafting Part 2** | **CLOSED 2026-08-18. Part 2 complete.** |
| **7 — doctrine, the remaining rulings** | this handoff · **`AUTHOR-RECORD.md` — a doctrine session READS it and rules from it** · **`NOTE-fixations-arcs-and-the-two-scales-20260821.md`** · **`NOTE-level-1-and-the-summit-20260821b.md`** · **`NOTE-resolution-rate-and-the-descent-20260825.md`** · **`NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md` — **the `c` letter**; read its §11 before its §7, and its §6 carries the ruled four-fate table above the superseded three** · **`NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` — **the `c` letter**; read its §10 before its §1, its §17 replaces its §9, and its §2 and its *does not turn into* ruling are both marked superseded by the 08-30 closures** · **`NOTE-the-dwell-and-the-brake-20260901.md` — **the 09-01 date; its §5.6 to §5.8 are the ruled first brake** and its §5 is amended by the file above** · **`RULINGS-20260816b.md` — the `b` letter, carrying R4's second supersession and R10a's narrowing** · **`RULINGS-job18-20260825.md`** · **`DEFECTS-carried-forward-20260825b.md`** · **`REPAIRS-job16-book1-defects-20260825g.md` — the `g` letter, which now runs to Part 10; `e` and `f` are quarantined** · `NOTE-overlap-and-truthfulness-20260815b.md` · `NOTE-drafting-8-15-findings-20260816.md` · `NOTE-small-arcs-and-the-step-20260815.md` · `DOCTRINE-BRIEF-arcs-and-position-20260816.md` · `BOOK2-ARCHITECTURE-20260815b.md` · `BOOK1-INDEX-20260815.md` · **`rev2-0814q.md`** · `VERIFY-20260815.md` · **`RECOVERY-NOTE-20260825b-procedural-changes.md`** · **`OPEN-from-job25-20260829b.md` — the `b` letter; still live, its census and blocker sections unspent** · **`BOOK2-PART34-ARCHITECTURE-20260902e.md` — the live Part 3/4 architecture, and Ch 15 and Ch 16 rest on doctrine this row's notes carry** · **`CLOSURES-SITED-job32-20260830.md` — all thirteen rows APPLIED by `Job33`; it stays as the record of what was ruled, not as work** · **`CENSUS-book1-into-book2-20260901.md`** · **`SKETCHES-rewrite-by-author-20260901b.md` — the 09-01 date; §2 item 7 now prints the ruled closing paragraph** · the outgoing session's `SET-NOTE-*` **and its `OPEN-*` file, if it cut one**. Plus **tools:** `setcheck.py`, `quotecheck.py`. Plus **reference, not inputs:** **`BOOK2-20260902b.md`** (the master — doctrine sessions do not touch text; **this row has named a superseded master twice now, and each time it was the row that put the dead file in the next set**) and **`STALE__rev2-0814b__WORKING-SET-doctrine.md`** (a `[C]` assembly of book 1 passages grouped by open question — **marked stale 08-26, see §6; the session has book 1 itself and should use it**). Plus **carried since 08-25 and harmless:** `TODO.md` and `TODO-additions-20260814.md`. Plus **discounted:** `THEORY-NOTES-voluntariness-and-two-layer.md` and `THEORY-NOTES-gradient-and-Z-split.md` — both 07-28, both stating on their face that nothing in them is applied, both predating every ruling. **No figures.** *No count is stated here on purpose: the last two times this row carried one it was wrong. Count the names.* |
| **3 — book 1 defects** | this handoff · **`RULINGS-job18-20260825.md` Part 1 — three sites with exact strings, and the only part of it a text session needs** · **`NOTE-fixations-arcs-and-the-two-scales-20260821.md` §8, which is the older repair list** · **`REPAIRS-job16-book1-defects-20260825g.md`, the record of everything applied since 08-25 — Parts 6 to 10 are `Job27`, `Job28` and `Job29`; quarantine `e` and `f`** · **`DEFECTS-carried-forward-20260825b.md`** · `VERIFY-20260815.md` · **`rev2-0814q.md`** · **`BOOK2-20260902b.md`** (repairs land in drafted book 2 text) · **the outgoing session's `SET-NOTE-*`, and `OPEN-from-job25-20260829b.md`** · `BOOK1-INDEX-20260815.md` · `NOTE-drafting-8-15-findings-20260816.md` §4 and §8 · `TODO.md` + `TODO-additions-20260814.md` · **`setcheck.py` and `quotecheck.py`** — §1.0 cannot be run without them and no row used to say so · **ALL EIGHT FIGURES BOOK 1 REFERENCES, named because "the figures" was not unambiguous:** `enneagram-hexagon.svg`, `hexad-cycle.svg`, `triad-hexad-cycles.svg`, `two-realm-grid.svg`, `wraparound-grid.svg`, `orientation-cycles.svg`, `opposite-relationship.svg` — **the 08-18 corrected file only** — and **`double-ahead-triangles.svg`**. *That last one is excluded from book 2 drafting sets and belongs in this one: see the figure table's note.* **`AUTHOR-RECORD.md` TRAVELS AND IS NOT OPENED** — changed 2026-08-25; it used to be excluded from this set and going stale is what that cost. A text session that reads it is disqualified from drafting, though applying a prepared list is still allowed. |
| **4 — writer 2** | **LIVE. The set is specified in `BRIEF-writer2-ch1-4-20260821.md`, which is the authority for it and not this row.** **GATED on Toby Marshall, no date — see §0 item 4.** In summary: that brief · **`BOOK2-Ch1-4-for-writer2-20260821.md`** (the copy to send him — **STALE by measurement since 08-30; re-cut and hash it before it goes, and do not send the 08-21 file**) · **`BOOK2-20260902b.md`** · `BOOK2-ARCHITECTURE-20260815b.md` · `WRITER2-triage-20260815.md` · `BOOK2-Ch5-insert-what-each-pair-asks-20260815.md` · his `DRAFT.docx` · `setcheck.py`, `quotecheck.py`. **Not `AUTHOR-RECORD.md`** — this is the one set the record does NOT travel in, because it leaves the project; not this handoff, and no doctrine file. |
| **5 — recovery sweep** | this handoff · **`RULINGS-20260816b.md`** · `CONSOLIDATED-THEORY-20260814.md` · **`rev2-0814q.md`** · `BOOK1-INDEX-20260815.md` · **`AUTHOR-RECORD.md`, carried** |
| **6 — Part 3/4 architecture** | **STARTED 2026-08-30, continued 08-31, RAN AGAIN 2026-09-02 as `Job42` and the rearrangement question is answered — see §0 item 6. What is left in this slot is Part 4. The live file is `BOOK2-PART34-ARCHITECTURE-20260902e.md`, the `d` letter.** this handoff · **`AUTHOR-RECORD.md`** · **`BOOK2-20260902b.md` — ADDED 2026-09-02 AND THE ADDITION IS LOAD-BEARING: the material to be rearranged is inside the master, and a session without it rearranges a specification while the manuscript sits outside the room** · **`OPEN-from-job41-20260902.md`, which states the question this session exists to answer** · **`BOOK2-PART34-ARCHITECTURE-20260902e.md`** · **`CENSUS-book1-into-book2-20260901.md`** · **`SKETCHES-rewrite-by-author-20260901b.md` — the 09-01 date; §2 item 7 now prints the ruled closing paragraph** · **`RULINGS-20260816b.md`** · `CONSOLIDATED-THEORY-20260814.md` · `BOOK2-ARCHITECTURE-20260815b.md` — **still the authority for Parts 1 and 2, and carry it with the architecture file's §8 in hand: two of its lines are stale** · **`BOOK2-PART3-PROVISIONAL-20260815.md` is SUPERSEDED — quarantine it; its appendix proposal at §3A was NOT superseded and is carried forward unexamined** · `BOOK1-INDEX-20260815.md` · **`NOTE-overlap-and-truthfulness-20260815b.md`** and
**`NOTE-small-arcs-and-the-step-20260815.md`** — *named explicitly since 08-24; "both `NOTE-*`
files" stopped being unambiguous once notes started taking letters and more notes existed* · **`JOB6-ONLY__NOTE-growth-specs-void-branch-20260815.md`** · **`rev2-0814q.md`** · `THEORY-NOTES-freud-correspondence-20260811.md` · `THEORY-NOTES-release-methods-and-nihilism.md` · **`RULINGS-job18-20260825.md` Part 2, which is addressed to this job** · **`NOTE-resolution-rate-and-the-descent-20260825.md`** |

| **9 — cutting a handoff** | **NEW, minted by `[A]` 2026-08-26.** The outgoing handoff · **`AUTHOR-RECORD.md`, carried and NOT read** — leaving it unread is what keeps the option of drafting open · **every file the sessions since the last handoff produced**, which is what there is to fold: their rulings files, their notes, their set notes and their defects files · **both manuscripts, present and untouched** — the repair list is checked against them and never applied from them · `setcheck.py`, `quotecheck.py` · **THE EIGHT FIGURES — changed 2026-08-30, and the reason is `job28`'s.** *This row used to say no figures. `job28` was doing a census whose subject turned out to live in three arrowheads and one label of `orientation-cycles.svg`, which no text search over a set can ever return, and it had to stop and ask `[A]` for all eight mid-session. `Job29` carried them forward deliberately against the row. **A census whose subject can appear in a figure is not complete until the figures are in the set**, and a handoff session is where a census gets read. They cost nothing to carry and dropping them restarts the resend cycle.* **The exclusion survives only for book 2 DRAFTING sets — see the figure table's note.** *This row is otherwise deliberately written as a shape rather than a list of names: the whole point of the job is that the names change every time.* **The 08-31 set carried all eight and the condition is met; do not restart the resend cycle by dropping them.** |

| **11 — composing prose for ruled doctrine** | **2026-09-05, `Job48 drafting 09042026`: THE SECOND OF THE TWO QUEUED SESSIONS RAN, AND ITS JOB IS ABOUT A THIRD DONE. The agency reading pass: thirty-eight repairs, Part 1, Ch 7 and the heaviest parts of Ch 15 clear; Ch 6, 8-14, 16 and 17 READ and identified, NOT repaired, roughly forty sites left. `BOOK2-20260904b.md` → `BOOK2-20260905.md`, 28,315 → 30,527 w. THE LARGER PART OF THE SESSION WAS NOT THIS JOB: `[A]` raised the qualification of the type sketches mid-session and all nine now carry a closing addition, about 2,200 w, resting on his UNRULED generalization about the ahead relation plus two unruled mechanisms of this session's. `STYLE-GUIDE-20260905.md` REPLACES the 09-04 cut in this row's set. THE NEXT SESSION IS A DOCTRINE SESSION, not this kind — see `SET-NOTE-from-job48-20260905.md`. WHAT IS LEFT FOR THIS KIND when it next runs: the rest of the agency pass in Ch 6, 8-14, 16 and 17; Ch 14's `only the last leaves a person seeing less than before`, a case named by its position; and Ch 6 and Ch 14's sentences about the book's own arrangement, which want a session that can rule on what replaces them.** **2026-09-04, `Job47 drafting 09042026`: THE FIRST OF THE TWO QUEUED SESSIONS IS DONE. The Appendix G inconsistency is closed on `[A]`'s ruling, Level 0 is out of book 1 at all seven sites, the `answering` idiom is cleared at six, and book 2 has one new section. `rev2-0814r.md` → `rev2-0814t.md`, 57,186 → 57,115 w; `BOOK2-20260904.md` → `BOOK2-20260904b.md`, 28,092 → 28,315 w. WHEREVER THIS ROW NAMES `rev2-0814q.md` OR `BOOK2-20260902b.md` BELOW, READ `rev2-0814t.md` AND `BOOK2-20260904b.md` — the older names are left standing inside history sentences that were true when written. WHAT IS LEFT FOR THE SECOND SESSION OF THIS KIND: the book 2 reading pass for an abstract subject given an agency verb, which is invisible to search and wants a session of its own. Book 1's `answering` sites are NO LONGER part of it.** **2026-09-04, `Job46 drafting 09042026`: THE 09-03 QUEUE IS EMPTY — all twenty-one applied and the letter scheme closed with the first of them. `BOOK2-20260902b.md` → `BOOK2-20260904.md`, 27,575 → 28,092 w; `rev2-0814q.md` → `rev2-0814r.md`, 57,180 → 57,186 w. FOUR SECTION HEADINGS RENAMED — see §5.** **`STYLE-GUIDE-20260904.md` IS NOW IN THIS ROW'S SET AND IS READ BEFORE ANY PROSE IS WRITTEN. `[A]` ruled 09-04 that it applies AS PROSE IS WRITTEN, withdrawing his earlier proposal of a later style-fixing job.** **THE PART 3 DRAFTING FILES AND THE EIGHT FIGURES ARE NO LONGER IN THIS SET.** *`Job46` found neither in its arrival set and needed neither: the seven Part 3 files are spent — every one is inside the master, and holding a chapter's draft alongside it is the failure the coherence row warns of — and no figure is referenced by any queued change. Do not ask for them again.* **QUEUED FOR THIS KIND, and `[A]` ruled 09-04 that it is TWO sessions of this kind, not one:** *first, the Appendix G inconsistency `Job46` created, with the letter scheme's residue; second, the book 2 reading pass and book 1's five remaining `answering` sites. Both are set out at §5.* ~~**THE NEXT SESSION IS THIS KIND, AND ITS JOB IS APPLYING THE RULED PLACEMENT AT THE ARCHITECTURE FILE'S Ch 15.**~~ **DONE 2026-09-02 by `Job43 drafting 09022026`: `BOOK2-20260902.md` → `BOOK2-20260902b.md`, 27,318 w → 27,575 w, 1,297 lines → 1,307. All seven blocks moved, the four minimal statements and the two rewrites on arrival written, the incomplete sentence repaired, the partial-registering paragraph dropped. `[A]` ruled the chapter's title: `The Fixations Themselves`. The architecture file took the `e` letter and its Ch 15 and Ch 16 sections now describe the master rather than instruct a change to it — DO NOT APPLY THE PLACEMENT AGAIN.** **NO QUEUED WORK for this kind. The next session is kind 12.** *`Job43` left one thing deliberately: Ch 17's two rate-setters restate `Which fixation handles a fear`, which moved to Ch 15, and the marked file asked the later one read as a reference back. It was left alone — it is already shorter and now comes second, which is the acceptable direction, and announcing it would be the meta-commentary §4 forbids.* *Written 2026-09-02 by `Job42`, replacing this row's `no queued work`.* **It composes almost no new prose** — it moves four passages out of Ch 16 and one out of Ch 11 into Ch 15, collapses the two descriptions of detachment's range into one, and writes three short things: the sentence in Ch 14 that names the crossing, the sentence in Ch 16 that names blocking as the fate that accrues, and the compressed form of Ch 11's involuntary-to-chosen point. **Two repairs travel with the material and are its to make:** Ch 11's incomplete sentence, *A realm can go little known for other reasons; this is the route that runs through detachment*, which must recover the point the 08-29 repair dropped rather than merely being made to parse; and **Ch 15's title, which the placement leaves owed and which is `[A]`'s.** **Book 1 needs nothing — the three deprecation marks were repointed on 09-02 and `rev2-0814q.md` already names Ch 15.** *Every book 2 line-number citation goes stale again when it lands.* **PART 3 WAS PLACED 2026-09-02.** ~~The next session in this kind PLACES it and writes none of it.~~ **DONE:** `BOOK2-20260902b.md` → **`BOOK2-20260902b.md`**, seven files, five chapters, 17,851 w → 27,318 w, 872 lines → 1,297. **THE CHAPTER RENUMBER IS DISCHARGED** — Part 3 is Ch 13–17 and `Ch 12` is reserved for the undrafted *Learning to See*; seventy-one sites moved in the architecture file, which is now the `d` letter. **EVERY LINE-NUMBER CITATION INTO BOOK 2 IS NOW STALE** — the count moved 872 → 1,297, so §1.0's locate-by-content rule governs book 2 exactly as it governs book 1. *The judgment in the job was confined to joins and to restatement between neighbours, and both produced findings: the three Ch 15 seams took one format decision and no bridging sentence, and the restatement search found `Detachment's lean is not like the others` and `Disregarding, and not seeing at all` both said again in Part 3. **Neither is this kind's to fix.** Both are in `OPEN-from-job41-20260902.md` and belong to §0 item 6.* **The next session is an ARCHITECTURE session, not this kind.** The rest of this row is the set, kept because the kind will run again. **THE ROW THE KIND HAS NEVER HAD, written 2026-09-01.** `Job25`, `Job29` and `Job33` all ran as this kind under ad-hoc names and the last of them ran on the job 7 doctrine set because there was no row. **The name of the kind is still `[A]`'s and still unminted — see §0 item 11.** Its set is **job 3's, plus the files carrying the doctrine being composed**: this handoff · **`rev2-0814q.md`** and **`BOOK2-20260902b.md`**, both, since what it writes lands in one and is checked against the other · **`CLOSURES-SITED-job32-20260830.md`**, which is the form a doctrine session hands work over in · **`RULINGS-20260816b.md`** and **`RULINGS-job18-20260825.md`** · **`REPAIRS-job16-book1-defects-20260825g.md`**, which it appends its applied work to rather than cutting a new file · the notes carrying the doctrine it is composing, named in the assignment and not standing here · `setcheck.py`, `quotecheck.py` · **the eight figures**, on the same argument as job 9's row · the outgoing session's `SET-NOTE-*` · **AND THE DRAFTED PART 3 FILES, named 2026-09-02 because the row was a shape and a shape does not put a file in a set:** `CH13-UNDERNEATH-THE-CYCLE-20260902.md`, **`CH14-WHERE-FIXATIONS-COME-FROM-20260902.md`**, `CH15-FRONT-HALF-20260901.md`, `CH15-CROSSING-ACCOUNT-20260901.md`, `SKETCHES-APPLIED-20260901.md`, **`CH16-FALLING-AND-RISING-20260902.md`**, **`CH-RECURSION-WHERE-THE-INNER-WORLD-CAME-FROM-20260902.md`** — **each session cutting Part 3 prose adds its own file here; `Job39` found this row naming only its predecessors and `Job40` added its own. The reading order is the recursion chapter, Ch 13's, Ch 14's, Ch 15's three as continuous prose in the order front half, crossing account, sketches, then Ch 16's** —; plus `SKETCHES-rewrite-by-author-20260901b.md`, whose §1 is the verbatim record and NOT the placement copy. **`AUTHOR-RECORD.md` TRAVELS AND IS NOT OPENED** — this kind writes new prose, which is the strongest form of the bar; `Job25` declined a narrow carve-out on exactly that ground and was right. **`job38` read it by accident on 09-02 and lost half a session; §7 now carries the `--exclude` form.** **No `BOOK2-Ch1-4-for-writer2-*` file** — that belongs to job 4. |

| **12 — the coherence check** | **NEW, minted by `[A]` 2026-09-02, and NOT YET RUN. Nothing in the pipeline does this job and nothing ever has.** *`[A]`:* `i'd like a session to do a deep check of how the ideas fit together, especially part 3.` **RUN IT AFTER THE Ch 15 PLACEMENT IS APPLIED**, not before — a check run first inventories a state that is about to change underneath it. **THE PRECONDITION IS MET as of 2026-09-02: `Job43` applied it and the master is `BOOK2-20260902b.md`. THIS IS THE NEXT SESSION.** *And Part 3's sections are not the ones the estimate below counted — five chapters were rearranged after this row was written, and four short passages in Ch 11, Ch 14, Ch 15 and Ch 16 are new prose no session other than `Job43` has read.* **What it builds, and this is most of the work: a claim inventory.** Section by section, three lines each — *what it asserts, what it assumes the reader already has, and where that assumption is met, each citing the section it comes from.* **Part 3 is about forty sections; the sites in Parts 1 and 2 where its assumptions are met add perhaps twenty-five more, and those must be read, because Part 3's foundations are not in Part 3.** **Then four tests over the inventory, and they are four different questions:** *(a)* is everything a section assumes stated earlier — **the class `Job42` hit with `the crossing`, a term in use before it exists**; *(b)* is everything a section states used later, or does it stand alone — **material that is present and does no work, which nothing has ever looked for in either book**; *(c)* is any claim derived twice from scratch — **the SAID TWICE class, and the inventory finds it where a text search cannot, because it compares what sections claim rather than what words they use**; *(d)* **is anything assumed but never stated anywhere** — *the one that should worry this project most, because a book assembled chapter by chapter across a dozen sessions is exactly where it happens: each session had the architecture's spec in hand and could write as though the reader had it too, and no check in the pipeline would catch it.* **WHAT IT MUST NOT DO: it does not draft, it does not move anything, and it does not rule.** *A fault in a claim graph is usually a doctrine question, and those are `[A]`'s.* It produces the inventory and a list of faults **stated as questions**. **The inventory is a file that survives the session** — checked and updated at each later change rather than rebuilt, like the census. **THE FAILURE MODE TO GUARD AGAINST is the one `Job42` hit:** a session with the architecture file open will write down what a section is *specified* to say instead of what it says. **The guard: every entry cites or quotes the text, and any entry that cannot is marked unread rather than filled in.** ~~**OPEN, AND `[A]`'s: whether it covers book 2 alone or both books.**~~ **RULED BY `[A]` 2026-09-02:** *the coherence job works on book 2 only and touches book 1 when necessary.* **So the inventory is book 2's and the tests run over book 2's claims.** *Book 1 is consulted, not inventoried — which is what an assumption-tracing test needs it for, since Part 3's material was drawn from book 1's Ch 15 and Ch 17 and Appendix G and an assumption may be met there rather than in book 2.* **A book 1 section reached that way is cited in the inventory and marked as book 1's, so the next session can see which of book 2's foundations are outside book 2.** *That reading is `[C]`'s and is offered for correction: the alternative — consult book 1 without recording where — would lose the one thing the excursion is worth making for.* **It does not edit book 1.** *Book 1's own ten deprecation marks pointing at book 2 stay job 3's.* **SET, SPECIFIED 2026-09-02 by `Job43` where the row said not yet specified:** this handoff · **`BOOK2-20260902b.md`, which is the only thing the inventory is built from** · `BOOK2-ARCHITECTURE-20260815b.md` and `BOOK2-PART34-ARCHITECTURE-20260902e.md`, for the four parts · `CENSUS-book1-into-book2-20260901.md` · **`rev2-0814q.md`, travelling for consultation and NOT inventoried** · `setcheck.py`, `quotecheck.py` · the outgoing `SET-NOTE-*` · **`AUTHOR-RECORD.md` travels and is NOT opened** — this kind writes no prose, but it also needs nothing from the record, and a session that reads it is disqualified from the drafting that will follow its findings. **NOT in the set: the seven Part 3 drafting files and `MARKED-chapters-for-the-Ch15-placement-20260902c.md`.** *They are spent — every one of them is now in the master — and they are the exact shape of the failure mode this row warns about, since a session holding a chapter's draft or its markup will write down what the passage was meant to say.* **And that failure mode has fresh evidence: `Job43` had the architecture file open all session and the placement it applied came out of it.** | **AND THE SESSION APPENDS TO `AUTHOR-RECORD.md` BLIND — the bar is on READING, not on appending. `Job44` made no append because this row was silent, and twelve of `[A]`'s rulings sat outside the record until `Job45` learned of them from a set note.**

*A count correction carried from 08-18c: its job 7 row listed ten items and called them nine inputs.
The row worked only if the handoff did not count itself. Stated explicitly above so the next
assembler is not counting against an ambiguous total.*

*The job 6 note is **live, not quarantined** — it is the only full text of the Part 2 placement
reasoning, and nothing in it is stale except its numbers. The prefix is the restriction, and it has a
second effect worth having: the file no longer answers to a `NOTE-*` glob, so an assembler sweeping
for notes cannot pull it into a drafting set.*

**The figures for the Ch 10–11 pairing.** *Retained as a record: the pairing is drafted, and no
current job needs figures.*

| Figure | Book 1 line | For |
|---|---|---|
| `enneagram-hexagon.svg` | 1066, Ch 10 | Ch 10 — the classical figure redrawn |
| `triad-hexad-cycles.svg` | 868, Ch 7 | Ch 10 — triad and hexad side by side |
| `hexad-cycle.svg` | 860, Ch 7 (also 2105, Appendix C) | Ch 10 — the alternating single step |
| `wraparound-grid.svg` | 840, Ch 7 | Ch 10, if the diagonal reading is wanted |
| `opposite-relationship.svg` | 1172, Ch 11 | **Ch 11 — Opposite. CORRECTED 08-18; use the new file only — see §5.** |

**Not in a BOOK 2 DRAFTING set, deliberately — and the scope of that word is the point, corrected
2026-08-24.** `double-ahead-triangles.svg` (book 1 L1088) illustrates the third Ch 12 finding, which
Ch 10's exclusion keeps out of book 2 *pending `[A]`'s ruling on how many of the three book 2
carries*; and `two-realm-grid.svg` is already in book 2's master at L540. **Neither reason says
anything about a BOOK 1 job.** Book 1 carries the Other Two Triangles section and its figure, live,
at L1084–1090, so a session repairing book 1 needs the figure — a figure can carry an error the prose
does not, which the wing error in `opposite-relationship.svg` demonstrated. **Job 3's row now names
all eight.** *Read this note as scoped to the set it names; it was written for book 2 drafting and
was inherited silently by every row that said only "the figures".*

**And `double-ahead-triangles.svg` has a history of arriving uninvited** — it is the extra that
reached the 08-18 set, which the assembly screen missed because **a figure carries no text to grep. A
figure cannot state its own status; only the manifest can.** That is an argument for deciding its
presence deliberately in either direction, not for excluding it by reflex.

**A rule, not a preference:** `rev2-0814q.md` goes into **every** drafting session, given at the
start rather than asked for. **Grep it; do not read it through.** Reading it whole is the pollution
risk — ~56 retired "stance" sites and a denser register than book 2 wants. Grepping it is what caught
two `[C]` claims the summaries had corrupted, and it is what caught two more on 08-20; see §6, *the
aggregate*.

`CONSOLIDATED-THEORY-20260814.md` stays out of the drafting set. Its chapter-number warning is
discharged; `BOOK1-INDEX-20260815.md` §1 has the correction table.

**THE AUTHOR RECORD'S REACH, restated at every set-cut: 2026-09-06, 41,888 words by
`LC_ALL=C wc -w`, md5 to be taken from this set's manifest, marker `2026-09-06 · Job52 handoff 09062026` (thirty-third append),
PARENT 41,674.** *Re-measured at this cut with `setcheck.py sweep`, which reads the head correctly again now that `Job49` restored the canonical marker form.* **`Job50` FOUND THE RECORD IN ITS ARRIVING SET WAS NOT THE HEAD** — the set carried the twenty-ninth append at 39,305 w and `[A]` supplied the thirtieth at 40,301 separately, `Job49` having made it after the manifest was cut. **Caught because the word count and the md5 both disagreed with the manifest row, which is the check the blind-append rule exists for.** **`Job46` MADE NO APPEND AND `Job47` WROTE ONE ON ITS BEHALF** — the twenty-sixth, second-hand from `Job46`'s set note, style guide and this file's 09-04 sections, quoting only wordings that occur verbatim in them and marking the rest as `[C]`'s report. The twenty-seventh is `Job47`'s own and first-hand. Both prefixes verified byte-identical.

*Superseded, kept as history:* **TWO APPENDS LANDED SINCE THE 09-03 SET.** The twenty-fourth is `Job44`'s, written by
`Job44` at `[A]`'s request AFTER its session closed, because its row's silence about appending had
left it out; `Job45` verified its 184,879-byte prefix against the parent md5 `1d3ee9a2` before
appending. ***`Job44`'s marker is short of the convention*** — it carries no append ordinal, no
PARENT count and no locale — **and it was left alone rather than edited, because the file is
append-only. The chain is checkable again from the twenty-fifth.**

**BOTH PENDING ADDENDA LANDED 2026-08-27.** `AUTHOR-RECORD-ADDENDUM-20260826.md` (job 20, the Z+
sketch ruling) then `AUTHOR-RECORD-ADDENDUM-20260826b.md` (job 21, twelve verbatim entries), in that
order, with one `RECORD MARKER` for the pair. The first 55,880 bytes came out byte-identical to the
9,724-word parent, so append-only held. Each addendum's preamble — the *append this by hand* material
addressed to `[A]` — was dropped as not being record content, and the provenance it carried was
written as a provenance line at the head of each block instead. **Both addenda may now stop
travelling.**

**AND THE PRACTICE CHANGED THE SAME DAY. RULED 2026-08-27 by `[A]`: THE SESSION APPENDS, NOT `[A]`.**
Every session appends what it produced to `AUTHOR-RECORD.md` before it ends, and cuts no addendum for
him to apply by hand. **A session barred from reading the record appends blind** — the bar is on
reading, and appending does not require reading: put the block at the end, verify the bytes above the
join are unchanged, write the marker with the new count. So a text session keeps its disqualification
rule and a handoff session keeps the unread property it was minted with, and both still append.
**The cost, stated: a session appending blind cannot see whether the material is already there.** What
protects it is the count — an appended block names its parent's word count, and if the record's last
marker gives a different number the append stops and the session says so. *This closes the gating
question §7 carried open since 08-24, and closes it in roughly the form §7 sketched.*

*Why it changed.* Both addenda above sat three sessions unappended and fell out of a set on the way.
**This is the selection rule's own failure case: something he said once, written down once,
in a file that fell out of the set.** Check the copy you were given against
this line before using it — a `wc -w` is not reading the file and does not disqualify a text session.
*Copies reading 8,589, 6,273, 5,921 or 4,641 words are all wrong and all exist.* **The two must agree**, and this is the only cross-check that exists for that
file: it carries no date on its name, it has no successor, and the quarantine prefix would violate
its naming rule — so nothing else can tell a live copy from a dead one. Because it is append-only,
**a stale copy is not wrong, it is short**, and shortness leaves no internal evidence. If your copy
is shorter than this line says, you are missing material and nothing in the file will tell you so.
**Update this line whenever the record is appended to.**

**A SESSION BARRED FROM READING THE RECORD CAN STILL CHECK ITS REACH.** `setcheck.py sweep` finds the
file by content and prints its last marker without the session opening it. *`job28` did exactly that
and confirmed 17,506 w, seventh append, parent 16,861 — chain clean — having never opened the file.*
**Use it; it costs one command and it is what makes the blind append safe.**

**Ask rather than assume.** If the author refers to something you have no record of, say so plainly.

## 2. THE TWO BOOKS

**Book 1 — `rev2-0814t.md`**, md5 `a6d71b1e`. A **repository, not a manuscript**, and since 08-31 **a
reference for writing book 2 and not a book being fixed** — `[A]`'s ruling, and the repair standard
that follows is at §0 item 3. `LC_ALL=C wc -w`
gives **57,115 words over 2,595 lines** — re-measured 2026-09-06 at this cut, not inherited. *This paragraph said 57,108 over 2,594 and both figures were one revision old.* Part I is Ch 1–7,
Part II Ch 8–10, then Ch 11–18 and nine appendices.

*Supersedes `rev2-0814c.md` through `l`. **Quarantine them all.** `c` and `l` are named in several places in
this file that are history rather than instruction, and those are correct as history.*

**THE LINE-COUNT GUARANTEE IS BROKEN AND THE CLAIM THAT STOOD HERE IS WITHDRAWN.** This paragraph
used to say the count had held at 2,566 through every revision since `c`, deliberately, so that every
`L####` citation anywhere in the set still lands. **`Job33`'s 08-31 rewrite of the fixation definition
and the two faces of detachment grew two paragraphs inside Ch 15**, and the count is 2,594.
**Measured 2026-09-01 the drift is +28 in Ch 15's neighbourhood and +22 in the appendices, so no
single offset corrects it.** Below roughly line 1462 nothing moved. **Locate a book 1 site by content
— see §1.0, which carries the rule and the count of affected citations.**

**BOOK 1 CARRIES NINE INLINE `[DEPRECATED …]` MARKERS PLUS ONE BLOCK MARK — COUNTED 2026-09-06 with
`grep -c '\[DEPRECATED'`, and the sentence that stood here said seven and then said *two of the
five*, disagreeing with itself. Two of the nine are ruled down as of 2026-09-01 and are still not
cut.** **AND ONE MARK HAS GONE WITHOUT ANY FILE RECORDING IT** — the Z0 mark `[A]` ruled on 09-01,
which `Job47` removed on 09-04 along with the sentence it governed. **See the head of this file: what
replaced that sentence states the continuum ruling in book 1's own voice, and whether book 1 may
carry it is the one thing this fold leaves for him.** The five were placed inline by `job28` on
2026-08-29 at the head of the paragraph they govern; the block mark over the four endeavor sketches
and their closing paragraph was placed by `Job33` on 08-31 and is a blockquote, not the inline
literal, so it does not answer the count below.** `[A]` approved marking in place and **never a separate status
file** — every status file this project has made has fallen out of a set or gone stale. Book 1 is one
paragraph per line, so a marker at the head of a paragraph comes back on the same line as every grep
hit inside it and cannot be missed by the search that would otherwise carry the error forward. **The
literal is a single `[DEPRECATED`, so they can be counted.** Three mark blindness explained by the
route taken (the cycle figure's caption, the stressed collapse from enthusiasm, and the two-faces
summary); two mark disintegration written as motion (the who-completes-a-whole-loop paragraph and the
direction-and-depth paragraph). *Line numbers are deliberately not given: see §1.0.*

**RULED 2026-09-01 by `[A]`, and it takes two of the five down — see §5 for the exact strings.** The
mark on the two-faces summary **lifts**: book 2 says the same thing in nearly the same words and its
twin stands unmarked, and book 2's Ch 11 states outright that which face appears is set by the
direction of the lean. The mark on the stressed collapse **comes off the paragraph and the false
clause is deleted instead** — book 2's twin ends *They enter detachment on its blind side.* and book
1's ends *Arriving by collapse rather than understanding, they enter detachment on its blind side.*,
so book 2 shows which six words are the defect. **Neither is applied; a handoff session checks the
manuscripts and never edits them.**

**AND THE THIRD OF THAT GROUP IS FLAGGED, NOT RULED.** The cycle figure's caption carries the same
stated reason as the two that lifted and is not in the same position: its problem is that it calls
disintegration *the reverse direction*, which `[A]` rejected on 08-29 — the direction may be named
backward, the route may not. **The mark may well be right and its stated reason wrong, which is not
the same as being right.** `[A]` has not been asked.

**Book 2 — `BOOK2-20260906b.md`**, md5 `d2ef43ce`. Foreword, Introduction, **Part 1** (Ch 1–5),
**Part 2** (Ch 6–11, with **Ch 12 reserved and undrafted**) and **Part 3** (Ch 13–17, placed
2026-09-02). **30,885 words over 1,421 lines** — re-measured 2026-09-06 at this cut, not inherited.
*Four masters on from what this paragraph used to name: `Job46`, `Job47`, `Job48`, `Job50` and
`Job51` each cut a new one. **Every line-number citation into book 2 made before 09-06 is stale
again**; locate by content.*
*Supersedes `BOOK2-20260825.md`, `BOOK2-20260829.md` through `n`, `BOOK2-20260830.md`, `b` and `c`,
and `BOOK2-20260831.md`. Quarantine all of them.* **THE LINE COUNT MOVED 872 → 1,297 WHEN PART 3
LANDED**, so every book 2 `L####` citation anywhere in the set that was made before 09-02 is stale.
Same rule as book 1: locate by content.

**Ch 12 is a reserved number and not a missing chapter.** *Learning to See* was placed into Part 2 on
08-15 and is the one gap inside that part; the census says so. Part 3 therefore opens at 13, and the
table of contents carries an unlinked line for 12. *Numbering Part 3 from 12 would have closed the
gap today and forced the whole renumber a second time when Ch 12 is written.* **The chapter line numbers below are older than that and have not been
re-measured** — treat them as approximate and grep for the
text. Ch 6 The Grid, ~620 words, from book 1's Ch 7 L798–872. Ch 7 The Cycle, ~935
words, from book 1's Ch 5 L552–594 with the three depth sections split to Part 3. Ch 8 Relational
Positions, 500 words, from book 1's Ch 8 L880–941. Ch 9 Relational Dynamics, 2,061 words, from book
1's Ch 9 L945–1049. **Ch 10 The Figure's Own Lines, 1,093 words**, from book 1's Ch 10 L1051–1101
minus the third finding. **Ch 11 Leans, and the Classical Wings, 1,937 words**, from book 1's Ch 11
L1102–1188 plus the disregard/denial contrast and the involuntary-to-chosen material from book 1's
habit section.

*Through it supersedes `BOOK2-20260818b.md` (17,474 words), `BOOK2-20260818.md` (17,471), and
`BOOK2-20260817.md`, md5 `c5ce5ea4`, 14,415 words. Quarantine all three. **Each revision takes its
own letter** — a file with different bytes never keeps a name it has already had.*

**What `[A]`'s 08-18 revision changed, all in Ch 11's detachment section.** The self-reinforcing
blindness is now grounded in **R1's aversion-to-aversion** — an aversion meets an aversion to that
aversion and the second wins, with an aversion even to recognising the conflict, since merely seeing
it is a threat. The sight retained at the caution end **deepens as the lean moves further from
caution and motivates less as it does**. And blindness is stated to **depend on the caution being
carried past detachment**, which is the overlap ruling. One paragraph of drafted text was removed as
redundant against the new account, and the comparative half kept, since nothing else says why the
contradiction lands at detachment rather than at the other two.

**The rule convention is true and was not before.** Every chapter heading in the master is preceded
by a single rule; Ch 4 and Ch 5 were repaired 08-18. Headings following a Part heading take the Part
heading instead, which is the existing pattern and not a gap.

The theory: nine types, each a pair of **fixations**, one in each of two realms. **H** physical,
**S** psychic. The three **orientations** are **A** enthusiastic (doing), **B** cautious
(understanding), **Z** detached (seeing).

**Applied 08-16:** the R10 sweep, seven sites, each verified as a unique exact string; a first-use
definition of *fixation* in Ch 1; and R10's required caution for readers arriving from the classical
system. Full site list: findings note §4.

**Applied 08-17,** when Ch 8 and Ch 9 went in. The chapters came from a drafting session that failed
for technical reasons after producing them; its draft was audited against book 1 and the grid before
insertion, and its arithmetic held throughout. Three cuts were made under fault 3, `[A]` ruling — the
not-a-ladder claim stood six times across the pair and now stands three: deleted *"There is no ladder
and no top"* from Ch 8; deleted *"And because it touches respect, it is easy to hear as a ranking,
which is not what it is"* from Ch 9's third paragraph; and reduced *"forgetting that the positions
sit on a circle and that her husband's psychic detachment"* to *"forgetting that her husband's
psychic detachment"*. **Kept, each doing work the others do not:** *"Looking up says where someone
stands on a circle. It says nothing about what they are worth"*; *"On a ladder that would be
nonsense; on a circle it is geography"*; and *"The person behind is never lesser, only easier to
overlook."*

**The failed session's own notes are not carried into the master and are not doctrine.** Its draft
file is quarantined; do not work from it and do not restore anything from it.

## 3. WHO IS INVOLVED

- **The author.** Type 5 (HB;SZ). Rules on all theory. Concise, fast. **Catches Claude's overreach
  reliably — take corrections seriously, do not defend.** On 08-16 he caught five confident
  attributions that did not survive checking, all `[C]`'s. On 08-20 he stopped a finding as too
  complicated to digest, which was correct and is a fault of delivery, not of his attention.
- **Writer 2 (Toby Marshall).** Type 2 (HZ;SA). Reads for effect on the reader; usually right about
  form. Co-owns Ch 1, Ch 4 and Ch 5. Send him a fresh copy at the start of every pass.
- **You.** Editor, prover, skeptic. Never agree reflexively. **And when `[A]` hands you a
  rule-or-hold judgment, make it and give the reasons** — he did that on 08-20, noting that not
  ruling makes the job harder. Handing it back is not neutrality.

## 4. STANDING RULES

### THESE NOW LIVE IN `STYLE-GUIDE-20260906.md`, WHICH TRAVELS IN EVERY TEXT SET

**`[A]` ruled the style file on 09-04, after catching two faults in one sentence that sat just
outside rules written for their neighbours.** *He said he has given the corrections at least three
times across sessions and has previously had to find an earlier session and copy them forward.*
**The reason they kept being missed: a session in a text kind reads targeted sections, so a rule
buried in a 73,000-word handoff is present and unreached, which looks identical to its not being
there.**

**`[A]` ALSO WITHDREW HIS EARLIER PROPOSAL** that drafters write as they choose with a later job
fixing style — *the part about fixing things later seems like a problem*. **The guide applies AS
PROSE IS WRITTEN.** A session that writes applies it to what it writes and repairs what it touches.

**TWO NEW ENTRIES, both caught 09-04, neither covered by what was here before:**

- **Possession by something that is not a person** — *the order is the crossing's own*. `[A]`: *an
  owning which is appropriate to people but not crossings*. **The agency rule covers a verb given to
  an idea and does NOT cover this; check for it separately.**
- **A sentence describing the book's own arrangement** — *the four are ordered, not listed*. `[A]`:
  *it sounds like the text refers to itself*. **`no meta-commentary` reads as a rule about asides to
  the reader and was not catching this.**

*The section below is kept as the record of where each rule came from. The file is what a drafting
session reads.*

**Voice:** no mechanical metaphors for psychic-realm phenomena; no meta-commentary; no forward
chapter references in running prose — **book 2 uses no chapter numbers in prose at all**, refer to
content or name the type; "model" not "framework"; **"orientation" or "fixation" never "stance"**;
"cycle" only for the closed loop, a single traversal is a **process arc**; US spelling, plain
register, prose over lists.

**And three faults `[A]` named on 08-16, which are one fault at three scales — a gesture where a
statement belongs.** Full account, with before-and-after pairs, in the findings note §7.

1. **Metaphor for compression.** *"It is a working surface. Almost everything from here on is a move
   on it."* **This applies in conversation too:** on 08-20 `[A]` stopped a reply to ask what a
   metaphor meant, and the answer was a plain sentence that should have been there instead.
2. **Staging the reader's response.** *"That is worth a moment"*, *"notice"*, *"worth asking"*.
3. **The disguised restatement.** A claim the chapter needs once, re-asserted in several softened
   forms, each dressed as a different point. Say it in one place by itself.

**The rule that covers the source of all three**, recovered by `[A]` from an earlier session — it is a
register, not a manual, absorbed from expository science-and-ideas writing where *"the theory
predicts"* and *"this chapter argues"* are house style. **Source: this project's own record, not book
1 — it will not verify against `rev2-0814q.md` and is not meant to.**

> **When the subject of a sentence is an idea rather than a person or a thing and the verb gives it
> agency, the prose has stopped describing the world.**

That last clause is **R9 at sentence level**, not a matter of taste — so it can be argued from ruled
doctrine when a drafter resists it. Two diagnostics: **where the draft is tighter than book 1, look
at what was traded for the tightness**; and **delete the sentence and see whether the chapter loses
anything** — a restatement costs nothing to remove, which is why it survives review.

**Method:** the laundering rule; the **sharpening rule** — when a claim of `[A]`'s is stated loosely,
**the loose form is the claim**; the constraint rule as an **ideal, not a gate** (R9) — *have I been
as specific as this claim allows*. **And the summaries rule: the doctrine files' compressions of
book 1 are not citable as book 1. Quote the source or say you are quoting a summary.**

**The MEASURED convention, and it now has teeth.** A section may be headed MEASURED only if
`quotecheck.py` exits 0 on it. The tool cannot distinguish a fabricated quote from one quoted from a
different source, so a blockquote must either declare its source or be marked as not quoting one.
**And a heading is not a check:** the arcs-and-position brief carries a MEASURED heading over a table
two of whose three citations do not survive one. See §6, *the residue vocabulary*.

**A rule the 08-20 session added, and it is the summaries rule pointed at a different failure.**
`quotecheck` verifies that a quotation is present. It cannot verify that the quotation is doing in
your argument what it does in the source. Both of 08-20's measured corrections were of that kind: the
words were there, and the sentence around them said something else. **When a citation supports a
claim, read the sentence before it and the clause after it.**

**Two drafting rules from R11a:** registering never appears without its object; the mini cycles stay
out of the Z notation entirely.

### METAPHOR — RULED BY `[A]` 2026-08-29, AND IT IS A DRAFTING RULE, NOT A CENSUS

**Name the mechanism. Do not reach for a figure to save a few words.** `[A]` on `fund`: it is
*claude's default use of an inappropriate metaphor to save a few words*, and he has corrected it
repeatedly across sessions. **Book 1 showed exactly why it fails.** The sentence read *the lean toward
B funds attention — residual vigilance keeps one watching*: the mechanism is stated immediately after
the metaphor, so the metaphor compresses nothing and only delays the explanation. **Book 2 had dropped
the explanation and kept the metaphor.**

**And he widened it, asked directly: economic and financial language is too remote for this context —
INCLUDING the sites where the exchange carries the argument.** `[C]` proposed sparing those (the
psychic realm's goods growing by being spent, producing cheap and testing expensive, a calibration
claim being spent). **That proposal was overruled. They are in scope.** *`[A]`'s instruction for the
work: do the ones that will be difficult to replace — the difficult ones are the point. A site is not
closed by being judged hard, dead-metaphor, or load-bearing. Each gets a mechanism named or a ruling
from him that it stays.*

**How it runs.** Where no mechanism can be named, the sentence is making a claim nobody has stated —
**that is the finding; report it rather than paraphrasing it into different vocabulary.** Where the
exchange is genuinely the claim, the site goes to `[A]` with the sentence quoted, not silently kept.

**SCOPE, ruled in the same session and confirmed when asked again: BOOK 1 IS NOT SWEPT FOR METAPHOR.**
Book 1 **is** repaired wherever it says something false — that follows from it being the source book 2
is drafted from. But 58 of the 94 census sites were in book 1, and that is most of a pass spent on a
book no reader may ever see. **So the rule lives here instead of in a sweep, and every drafting
session applies it to what it touches, book 1 paragraphs included where it is already drafting from
them.** *It cannot be dropped as redundant with the census: `fund` was in book 1 first and reappeared
in book 2's twin paragraph, so the source's vocabulary propagates and not only its claims. A handoff
rule catches that at the moment of transfer; a book 1 sweep would not have caught it at all, book 2's
copy having been written before any sweep. **And this is how the rule reaches the material book 2 has
not written yet, which no census can cover.*** **Do not repair a book 1 metaphor in order to match
book 2** — matching the twins is what let them drift.

**The book 2 pass is DONE**, 24 sites, `Job27`, and its exemptions are in
`REPAIRS-job16-book1-defects-20260825g.md` Part 8.2. **Do not reopen it.** One exemption is easy to
misread as reinstating the position `[A]` overruled: the realm-economics passage is exempt because
**its economics is not a metaphor at all** — the passage's claim is that the physical realm genuinely
works that way and that a Five carries the real arrangement into a realm where it does not hold. **The
vocabulary is the subject, not a figure.** *Flagged and not changed because it is doctrine rather than
style: `gain`, in `focused on possibility and gain`, which is part of how enthusiasm is defined.
`[A]` has not ruled on it.*

### THREE MORE OF `[A]`'s STANDING CORRECTIONS — he says he has given them repeatedly

**These are his, they are not in any style file, and the reason they are here is that he has had to
give them across several sessions.** *He proposed that drafters write as they choose and a later job
fix the style; `[C]` recommended a style file cut once and carried in every text set. **Not ruled.**
Until it is, this is where they live.*

- **Never name a case by its position in a list.** *Only given up is chosen*, never *only the second
  is chosen*. **Naming the thing saves the reader going back to count.** `[A]` says he has given this
  one several times. It applies in conversation as much as in the text.
- **No coined handles.** `far end` was a `[C]` coinage, never defined, its first use a demonstrative
  pointing at the previous paragraph. **Say the orientation specifically.** *Ruled out of book 2 on
  08-29; book 1's three uses are ordinary English and were left. `the blind end` survives twice in
  book 2 and was NOT ruled on — it may want the same treatment.*
- **Stay at the scale of the thing discussed** — fears, not realms, where the sentence is about a
  fear.

## 5. TEXT CHANGES RULED AND NOT YET APPLIED

### 2026-09-05 and 2026-09-06 — `Job49`'s closures are ALL APPLIED, and one of them ended with nothing written

**`CLOSURES-SITED-job49-20260906c.md` is a record, not a queue.** `Job50` applied every row it sited
and `Job51` applied the last one owing text. **`DRAFTING-aligned-types-20260906b.md` replaces that
file's aligned-types row** and is marked applied on its face; work from it and not from both.

**WHAT WENT INTO BOOK 2, and it is eleven paragraphs plus one new section.** The relational-positions
chapter gained book 1's missing guard, written positively — *Each of the three has another ahead of
it. There is no top.* The orientations chapter gained a paragraph naming what each orientation is
averse to, disappointment and losing control and suffering with nothing softening it, **placed before
the sketches at `[A]`'s direction** rather than only in the blindness discussion. The cycle chapter's
forward passages gained a second cost each. The Nine's sketch gained a reason for sound judgment at
each depth. The aligned-types reason went into the grid chapter and came out of three sketches. And
the health-axis chapter's account of intervention was rewritten whole, eight paragraphs where there
were four.

**ONE CLOSURE ENDED WITH NOTHING WRITTEN AND THAT IS THE RULING.** Four drafts of a sentence
reconciling the correspondence table's *appetite, unqualified* with a Nine improving toward appetite
were each put to `[A]` and each rejected — *it's too dense. i can't parse it*, and then *mentioning
appetite there is confusing. can it all go?* **The paragraph already answers it** and every draft was
a longer form of the answer. **The existing sentence is what meets a reader arriving from the
sketches and must not be touched.** *`[A]` also had one standing sentence dropped as unparseable —
`and that has been the position since the two were first separated` — which pointed backward without
naming what it pointed at.*

**RULED 2026-09-06 AND WRITTEN INTO THE STYLE GUIDE: an animate verb with an inanimate subject OR
OBJECT is a fault.** Caught on *the less of it they can meet*, where a discomfort is something a
person meets. **The existing rules cover a verb given to an idea and an idea given possession, and
this third form passes both** — `[A]` said the style document should already have told the session.
**`STYLE-GUIDE-20260906.md` carries it, in section 2.**

**AND HE DECLINED ONE EXTENSION, WHICH IS RECORDED SO NOBODY WRITES IT.** Asked whether the
aligned-types finding extends to the aligned types being harder to help: *each type has its own style
or resistance to change so it's hard to judge.* **Nine styles of resistance, none drafted, and
nothing in either book describes resistance to change as varying by type. Do not write it.**

**STILL OPEN FROM `Job48`, AND CARRIED HERE BECAUSE THREE SESSIONS HAVE NOW LEFT IT.** The agency
reading pass is about a third done: **Ch 6, 8–14, 16 and 17 are READ and their sites identified, NOT
repaired — roughly forty of them, none in a type sketch.** Two named sentences travel with it: Ch 14's
*only the last leaves a person seeing less than before*, which names a case by its position and
should say *only a blocked fear*; and the sentences in Ch 6 and Ch 14 that describe the book's own
arrangement, which is the fault `[A]` ruled on again on 09-04.

**A ONE-LINE REPAIR DEFERRED BY THREE SESSIONS.** `CLOSURES-SITED-job32-20260830.md` still says *Not
applied* at its head and `Job33` applied all thirteen of its rows on 08-31. **A closures file that is
never marked reads as work owed.** `Job50` found it and did not repair it; `Job51` did not either;
neither did this session, a handoff session not touching another session's record. **Somebody should
be told to.**


### 2026-09-04 — ALL TWENTY-ONE APPLIED BY `Job46 drafting 09042026`. THE QUEUE IS EMPTY.

**Every change in the 09-03 queue is on the page, and the letter scheme closed with the first of
them.** *`Job44`'s inventory ruled that Ch 7's `arising at A, development at B, ending at Z` was not
repairable by a letter qualifier but replaced — so the letters went out with the sentence. All
fourteen remaining letter sites in book 2 name a position a person occupies; none attaches a letter
to a passage or a phase. Checked against the text, not taken on trust.*

**Book 2: 27,575 → 28,092 w. Book 1: `rev2-0814q` → `rev2-0814r`, 57,180 → 57,186 w.**

**FOUR SECTION HEADINGS WERE RENAMED. Notes and queue entries name sections by heading, so anything
citing the old names is now stale.**

| Was | Is | Why |
|---|---|---|
| Ch 7 *Detachment's two faces* | *The two faces of detachment* | the possession pass |
| Ch 11 *Detachment's lean is not like the others* | *The lean in detachment is not like the others* | the possession pass |
| Ch 15 *Detachment's range* | *The range of detachment* | the possession pass |
| Ch 13 *What the folding separates* | *What self-reference does* | `folding` dropped; and it no longer separates |
| Ch 17 *Why this does not take everyone to the floor* | *…to the bottom* | one word for the low end across all eleven sites |

**WHAT `[A]` RULED THIS SESSION, beyond the queue.** *Full reasoning in
`NOTE-the-two-stacks-20260904.md`.*

- **The two stacks correspond approximately and are not one stack.** Descent takes the highest
  reaches of thinking first and those are learned latest, so falling runs roughly backward through a
  life. **The difference: the disabilities of descent cause emotional distress; the inabilities of
  youth do not and are not symptoms of ill health.** An infant's inability is **off the axis, not low
  on it** — which stops the reading in which everyone begins life at the bottom.
- **The deposits are NOT a second force.** They supply the occasions and set the price; **the flip
  still comes from consequences, outside.** *A second force would raise both terms of the comparison
  at once and the middle-gathering and thin tail would stop following.*
- **Blocking is not a kind of deposit.** Content against procedure. **`[A]`: blindness is actively
  resisted and deposits require only fighting inertia however large** — so deposits are hard by
  amount and yield to repetition, blocking is hard by opposition and is fed by it. **This derives why
  sight from outside matters:** an intervener is not who the arrangement is defending against.
- **The relational material is derived from the model AND from observation**, and Ch 8 now says so.
  *`[A]` considered `I` and `the author` and took neither: the chapters have no authorial first
  person outside the foreword.*

### 2026-09-04 — CLOSED BY `Job47 drafting 09042026`, EXCEPT THE READING PASS

**THE APPENDIX G INCONSISTENCY IS CLOSED.** `[A]` ruled that the structure is fixed in advance and the
condition governs the motion, and that both belong in the appendix. G.1's two generation clauses are
now definitions rather than causal claims, the condition has its own bullet — *a person moves down
that structure one link at a time, and only where a fear is left unattended* — and the F/D notation
is untouched.

**THE `answering` IDIOM IS OUT OF BOOK 1, AND IT WAS SIX SITES.** The three in Appendix G, the
freezing sentence, the borrowed-cascade sentence, and **one this file never named** — Ch 15's summary
of the bands, *Each level carries its own fear and its own answering desire*, which the measurement
missed because it searched the rule statements.

**LEVEL 0 IS DISCHARGED**, the 08-23 ruling applied at all seven book 1 sites. Both books now carry
none. `Job47` took the 08-23 text consequence (rewrite to the upper half of Level 1) over the 09-01
standard (write no replacement), on the reading that *no replacement* forbids inventing doctrine to
fill a gap and not repairing a sentence so it stops asserting a retired thing. **Disclosed to `[A]`
and not overturned.**

**NEW, AND IT IS `[A]`'s: the levels are healed one at a time.** That is why a long climb is slow —
not because old material has set hard. It deprecates book 1's temporal-layering bullet, now marked,
and it is the ninth deprecation mark.

**NEW DOCTRINE IN BOOK 2, at `[A]`'s instruction:** a level a person has stood on stays available as
memory and cannot be worked from. **It carries one unruled `[C]` choice, disclosed at the time and
marked here: whether what is remembered is the earlier state itself or only that things were once
different.** `[C]` took the first and `[A]` had not answered the question when he said to add it.
**A doctrine session may overturn that sentence.**

**PART DONE 2026-09-05 by `Job48 drafting 09042026`:** the book 2 reading pass for an abstract
subject given an agency verb. **Thirty-eight repairs; Part 1, Ch 7 and the heaviest parts of Ch 15
are clear. Ch 6, 8-14, 16 and 17 are READ and their hits identified, NOT repaired** — roughly forty
sites, none in a type sketch. *The worst of the class is done: the sketches in Ch 15 had an end of a
phase deciding to drop an endeavor, which no reader could picture.*

**ALSO OPEN, raised and unanswered:** whether book 2 should carry the short-term fluctuation at all.
Book 1 has it; book 2 says instead that a person's place does not drift and changes only at a
crossing. `Job47` declined to import it. *And a style hit left alone as out of scope: Ch 16's
`Spoiled arrivals` names the four fates and then says `the first three`, a case named by its position
in a list. **`Job48` found a second of exactly this form in Ch 14 — `only the last leaves a person
seeing less than before`, which should say `only a blocked fear` — and left it for the same reason.**
Both belong to the same repair.*

### ~~2026-09-04 — WHAT THE NEXT SESSION INHERITS. TWO SESSIONS, BOTH KIND 11.~~ — the first is done, above.

**FIRST, AND IT IS A LIVE INCONSISTENCY THIS SESSION CREATED.** Book 1's rule statement in *Beneath
the Levels* now carries the **unattended** condition. **Appendix G's G.1 does not** — its generation
clause still reads *F(n) generates D(n+1)* unconditioned, so the informal rule and the formal one now
say different things. **That is worse than the state `Job46` found, where both were unconditioned.**
*Needs a ruling: does the condition belong in the formal rule, and where in the F/D alternation does
it sit? Note that G.1 already separates structure from motion, so one available answer is that the
condition governs motion and the appendix is right as it stands.*

**SECOND — the `answering` idiom in book 1, five sites.** *Fixed this session only where the repair
touched: book 2 throughout, and book 1's rule statement and its lead-in.* `[A]` 2026-09-04: **fears
don't get answered.** The repair is to put the person in as subject. **Remaining: the freezing
sentence in book 1's Ch 15, the Chapter 15 summary, and three in Appendix G — where it is the formal
notation, including the fork where the basic fear is answered one way or the other.**

**THIRD — the reading pass over book 2, and it wants a session of its own.** The style guide's
largest class — **an abstract subject given an agency verb** — is invisible to search, so this is
27,575 words read with a repair at every hit. *The greppable classes are already done: 21 abstract
possessives, 10 self-referential sentences, 6 uses of the banned `stance`.*

**OPEN, not owed.** Whether **blocking can be worked on directly** — the felt-quality handle that
reaches the oldest material looked transferable and this session's ruling says it is not, since
approaching the flinch is what the flinch watches for; nothing says what does reach it. And whether
**the type sketches should mark observation** the way Ch 8 now does — they are full of particulars no
derivation produces, and Ch 8 is currently the only place the distinction is drawn.

### 2026-09-03 — THE DEPOSITS QUESTION IS CLOSED AND ITS ENTRY IS REMOVED FROM THIS SECTION

**What stood here said `mental deposits` against `deposits` was open, that the only evidence was a
line seen in a file a session should not have opened, and that Ch 14 could not be written without
knowing.** *All three have been overtaken.*

**`Job45`, a doctrine session, read the record as its row permits and found the question settled on
09-02** — `[A]`'s own line, *i lean towards mental deposits everywhere. would that be a problem?*,
and the ruling that the full form is written at every occurrence. **Book 2 uses `mental deposits`
three times and the bare `the deposits` nowhere, and Ch 14 has since been drafted.** The block this
section described was lifted before it could bite.

**WHAT IS NOT CLOSED: the disqualification of `job38-drafting-20260902` stands as recorded at §10.**
*The wording question is closed; the finding about how it was seen is not.*

*Ch 13 stands: it was drafted before the grep, takes nothing from the record, and does not use the word.*

**EIGHTEEN REPAIRS WERE APPLIED ON 2026-08-25 AND HAVE LEFT THIS SECTION.** `Job16` prepared them and
`Job17` applied them, every `CURRENT` string verified to occur exactly once before substituting and
nothing written until all matched. They were the nine from the endeavor relocation, the `arc` census
sites, and the Ch 15 retitlings. **The record of what was applied is
`REPAIRS-job16-book1-defects-20260825g.md`, not this file** — it carries the before-and-after strings,
and a repair list that exists in two places gets applied from the stale one.

**Everything still standing in this section was ruled on 08-21b or 08-23 and is untouched.
RE-MEASURED against `rev2-0814q.md` and `BOOK2-20260831.md` on 2026-09-01**, so this is not inherited — *but book 2 has since become `BOOK2-20260902b.md` and grew by more than half, so any item below measured against book 2 is measured against a superseded master and its line numbers are void; locate by content*
from the previous handoff: *traveled* still stands on three lines, *steps toward* on one, *Level 0* on
nine, `HB+0.2` once in each book, and *leans are what move a person* once. **None of the older items
below has been applied**, through five further sessions and eight revisions of book 1. *The counts are
of LINES, not occurrences — book 1 is one paragraph per line, so `traveled` occurs six times on those
three lines. Whoever repairs them counts occurrences, not hits.*

**THREE FURTHER SITES WERE RULED ON 2026-08-25. TWO OF THE THREE WERE APPLIED ON 2026-08-30 —
FIVE SESSIONS LATE.** They are in `RULINGS-job18-20260825.md` Part 1, with exact strings.

**APPLIED 2026-08-30 by `Job29`, both strings still matching exactly once when it got to them:**
book 2's Ch 7 fixation pair collapsed to **`Everyone's thoughts make all three passages; what varies
is what those thoughts are about.`**, and book 1 Ch 5's twin sentence deleted whole, trailing space
included, the paragraph read back and joining cleanly. **One defect, three sites, ruled and unapplied
for five sessions while every session that opened Ch 7 read straight past it.** *A consequence rather
than an edit: the inherited `comes to rest` collision — every thought resting **in turn** at all three
against thoughts **habitually** coming to rest at one — was carried by the deleted sentence in each
book. Both books now use the phrase in the transient sense only. **The word does one job again and
there is nothing left to repair.***

**STILL UNAPPLIED, the third:** **the sixty-second claim gets its stated difference, at the candle
sentence and not after the fact-claim** — that one deliberately supplies no draft wording, because the
wording is a text session's. **That file also rules what must NOT be inferred**, at its §1.5, and a
text session should read that before touching the paragraph.

*Why they are not copied here.* Same reason the nine were not: a repair list that exists twice is a
repair list that will be applied from the stale copy. **This is the rule and it has now been followed
three times.**

### RULED AND APPLIED 2026-09-02 — A NINTH DEPRECATION MARK GOES ON BOOK 1, AT THE TWO-FACES CLAUSE

**`[A]`: *you can mark it.*** Book 1's recursion section, in its origins chapter, says detachment is
the only orientation with two faces because the inward turn can be made with seeing and awareness or
as an unconscious reflex — **and then adds that those are *different conditions rather than degrees
of one*.** **His 09-01 continuum ruling contradicts that clause outright:** Z− and Z+ are one range
with two directions of lean away from a mid-point of no lean, which is total detachment.

**How it sorts, and it is the reason this one is his rather than a drafting call.** It is the second
of the two kinds he handled on 09-01. **The two-faces summary mark came DOWN** because book 2 carried
the material live and book 1's version was merely incomplete. **The Z0-off-the-scale clause took a
mark** because book 2 had nothing and book 1 was false. **This one is the second kind**: false
against the ruling, and book 2's front half of the falling chapter already states the corrected form
— *not two kinds of detachment but one range with two directions of lean*.

**THE MARK IS NARROW, AND DELIBERATELY.** Most of that sentence is what the new recursion chapter is
built on, so the mark names what is deprecated and what is not in the same breath: the reason given
— the inward turn can be made with something in view or as a reflex — **is what supplies the range
its two directions and is explicitly not deprecated.** It closes on *do not draft from the final
clause*, narrower than the usual *do not draft from this*, so a later session does not read the whole
sentence as dead and lose the reason with it. **No replacement wording, per his standard.**

**APPLIED in `rev2-0814q.md`**, inline at the head of the sentence, the string verified to occur
exactly once before the write. **`rev2-0814o.md` → `rev2-0814p.md`, 57,180 w, md5 `892912c6`, still
2,594 lines**, so no citation moves and §1.0's locate-by-content rule is unchanged. **One line differs
from the parent.** Quarantine `rev2-0814o.md` as `SUPERSEDED__live__`. Book 1 now carries **nine
inline marks plus the block mark**.

*Found while drafting the recursion chapter from that section. The clause carried no mark and nothing
else in either book says it; it occurs once. The chapter carries the reason and not the clause.*

### RULED AND APPLIED 2026-09-01 — A SIXTH DEPRECATION MARK GOES ON BOOK 1, AT THE Z0 SENTENCE

**`[A]`: *deprecation.*** Book 1's Ch 15, in the paragraph laying the Levels against the
orientations, says of Z0 that it **is simply left off: a blur between those two extremes, it will not
sit on one side or the other, so it is not part of this scale — it belongs instead to Level 0, the
exit developed at the end of this chapter, off the ladder rather than atop it.** **That is false as
of 09-01 on two counts at once:** on the continuum Z0 sits in the middle of the health axis rather
than off it, and the middle is already occupied by partial registering; and it routes Z0 to Level 0,
which was abolished on 08-21b.

**APPLIED in `rev2-0814q.md`**, inline, immediately before `And Z0 is simply left off:`, in the form
book 1's five existing marks use:

`[DEPRECATED — Z0 placed off the health scale, and routed to the abolished Level 0. Superseded 2026-09-01: Z− and Z+ are one continuum and Z0 is the zero-lean point on it, which sits in the middle of the axis where partial registering is already held. Do not draft from this.]`

**The line count did not move: `rev2-0814q.md` is still 2,594 lines**, so §1.0's warning about book 1
citations is unchanged by this session. **Why a mark and not a deletion, given that the two marks
above came down:** those two came down because book 2 already carried the material and book 1's
version was incomplete rather than false. **This is the opposite case** — book 2 has nothing on it
and what book 1 says is false. *No replacement is written, per his 08-31 standard.*

### RULED 2026-09-01 — TWO OF BOOK 1'S FIVE DEPRECATION MARKS COME DOWN

**`[A]` was asked and ruled both, having been shown what book 2 does with the same material.** Neither
is applied: a handoff session checks the manuscripts and never edits them. **Both strings were
verified to occur exactly once in `rev2-0814p.md` before this block was written. **Both strings still stand unapplied in `n`; the only 09-01 change to book 1 is the new Z0 mark below.**

**1. The two-faces summary — THE MARK LIFTS, THE TEXT IS UNCHANGED.** Delete the marker and nothing
else. Book 2 carries the same sentence, live and unmarked, in nearly the same words: *A lean from
caution shows it seeing, with the sight that understanding gave. A lean from enthusiasm under stress
shows it blind, as shutdown. Detachment, alone among the three orientations, contains these
opposites.* And book 2's Ch 11 states the reason outright — **which face appears is set by the
direction of the lean, because detachment's two neighbours are what produce them** — before supplying
what the crossing does, an aversion meeting an aversion to that aversion and the second winning.
**The direction sets which face appears; what became of the fear is what lays the blindness down.
Those are two claims and they do not compete.** Book 1's sentence gives the first and stops, which is
incomplete rather than false, and book 1 has no crossing account anywhere, so it could not have given
the second. *`job28` marked it because the direction was still doing explanatory work. It is, and
book 2 says so.*

**CURRENT — delete the bracketed marker and the single space after it, leaving the sentence:**

`[DEPRECATED — blindness explained by the route taken. Superseded by book 2 Ch 11's crossing account: a fear carried past detachment rather than met. Do not draft from this.] `

**2. The stressed collapse from enthusiasm — THE MARK COMES OFF AND A CLAUSE IS DELETED INSTEAD.**
`[A]` had already said the paragraph is correct as it stands with only its closing clause at fault,
and book 2 shows which words those are: book 2's twin ends `They enter detachment on its blind side.`
where book 1's ends `Arriving by collapse rather than understanding, they enter detachment on its
blind side.` **So the defect is six words, and the repair is the one book 2 already has.** Under
`[A]`'s own 08-31 standard — delete what is false, leave the gap, write no replacement — the clause
goes and no sentence is written to replace it. **A marker attaches to a whole paragraph and book 1 is
one paragraph per line, so text he approved was sitting inside a do-not-draft mark;** with the false
clause gone there is nothing left for the mark to govern.

**CURRENT — two deletions on the same line, in this order, each verified unique:**

`Arriving by collapse rather than understanding, `

`[DEPRECATED — blindness explained by the route taken. Superseded by book 2 Ch 11's crossing account: a fear carried past detachment rather than met. Do not draft from this.] `

*The second string occurs on three lines and is unique only together with what follows it. **Match on
the marker plus the first words of the paragraph it heads** — `**A → Z (under stress).**` for this
one, `Detachment thus appears from either side` for the one above. The third occurrence heads the
cycle figure's caption and is NOT ruled — see §2.*

**After both are applied book 1 carries three inline markers**, all three marking disintegration
written as motion or the route-as-cause in the figure caption, plus the block mark over the four
sketches. **Re-count with `grep -c '\[DEPRECATED'` rather than trusting this sentence.**

### RULED 2026-08-30 AND APPLIED THE SAME WEEK — the thirteen sited closures

**`CLOSURES-SITED-job32-20260830.md` is a record, not a queue. `Job33` applied every row on 08-31.**
It stays in the set because it is `Job32`'s statement of what `[A]` ruled, and the rulings are cited
from it; **it is not work.** *Its rows 2, 3 and 10 read `settled` and mean `worked through`; the head
of the file says so.*

**Four rows had more sites than the file named**, which is the standing pattern — a closures file
names the site somebody looked at. **The method that found the others, and it should be standard:
grep each closure's own vocabulary across the whole set rather than going to the row's line number.**
*One of the four matters beyond bookkeeping: the `numbness instead of acceptance` swap was sited in
book 1 only, and book 2 carried the same sentence in the same crossed sense — **book 2's is live text
while book 1's sits inside a deprecation**, so the live one was the one missed.*

### ~~NEW 2026-09-01 — A RETRACTED CLAUSE IS QUEUED INSIDE AN APPROVED PARAGRAPH~~ — RULED AND APPLIED THE SAME DAY

**`[A]` ruled it cut, 2026-09-01, and `Job36` applied it.** The clause is gone from
`SKETCHES-rewrite-by-author-20260901b.md` §2 item 7, the list of what arises for each of the four now
takes a full stop, and **nothing replaces it** — the paragraph's last sentence already carries the
point in the weaker form he kept. **AND IT REACHED A SECOND LIVE SITE NO FILE HAD NAMED:**
`BOOK2-PART34-ARCHITECTURE-20260902e.md`'s Ch 15 restated the paragraph and carried the clause **in
bold**, as what a drafting session should write. Both are corrected in the same pass. *Found by
grepping the clause across the whole set rather than going to the site the set note named — the same
lesson the recovery-note defect taught, demonstrated a third time.* **Book 1's two occurrences need
nothing:** the old closing paragraph and the Z+ sketch both sit inside the block `[A]` deprecated on
08-31, so the unapplied 08-26 ruling on that sentence is subsumed by *do not fix book 1*.

*What the item said before it was ruled, retained because the reasoning is why it was held back:*

**`SKETCHES-rewrite-by-author-20260901b.md` §2 item 7 carries a closing paragraph `[A]` deleted and
then approved in replacement.** It is unapplied and the sketches are unplaced, so **neither book is
wrong**. What is wrong is that it is queued. Its second sentence reads:

`and where it differs, the fixation has selected the population of arisings before any endeavor begins.`

**`[A]` retracted that claim on 2026-08-20** — *i don't/no longer agree* — and **ruled on 2026-08-26
that the whole sentence carrying it goes from book 1's Z+ sketch**, on the argument that what sources
the arisings is an open doctrine question and that a list of contributors in the text reads as
hedging. *The retraction removed the exclusivity, not the influence: he answered separately that the
fixation **affects** what arises, alongside immediate past thoughts, memories, sense input and
current emotional state.* **`selected … before any endeavor begins` is the exclusive-and-prior form,
which is exactly what was retracted.**

**The paragraph was written to solve a real problem and solves it with the retracted claim.** The
rewritten sketches walk the phases in order, which invites a reader to conclude that the fixation is
one of the phases; the paragraph exists to say the fixation is at work before the endeavor's own
shape can account for it. **That second half stands on its own and does not need the selection
claim.** *`[C]` has not drafted a replacement and should not: writing replacement wording for what a
doctrine session closes is itself an open question — see §0 item 7.*

**Nothing here is a criticism of the rewrite.** The clause was almost certainly carried forward from
the old closing paragraph, which stated it in the same words, and the old one is deprecated.

### RULED 2026-08-23 — `integrate toward` and `disintegrate toward` are the verbs, and the transit language goes

**`[A]`:** *"where integration and disintegration are involved, you can use verbs integrate toward and
disintegrate toward."*

**Why a substitution and not a rewrite.** The verb takes a direction as its object and nothing else.
There is no partway, no arrival, no distance covered — a person can integrate toward the Seven more or
less strongly, which is a magnitude, and a magnitude is exactly what the temporary offset has. The
transit picture is not suppressed; the grammar has nowhere to put it.

**Measured. The census splits in two and only one half is a defect.**

*Not defects — leave alone.* The grid language: *one step down and one step right*, *advance the
physical realm alone*, *one forward step along the cycle*. These construct a relation between two
positions on the diagram. Nothing in them says a person goes anywhere.

*Defects — five sites where the person is the thing in transit.* All book 1:

| Site | What it says | Repair |
|---|---|---|
| L1078 | a relation can be **traveled**; a person's state **moves along it**, taking on the connected type's qualities while remaining their own type | integrates or disintegrates toward the connected type |
| L1078, same sentence | the drawn relations are traveled is *the model's own **motion of the orientations*** | the orientations do not move either — same substitution, same reason |
| L1082 | the relations are not merely felt but **traveled**; a One can integrate toward the Six and **slide backward** the same way under stress | integrate toward / disintegrate toward |
| L1266 | the classical arrows are *directions a single person **moves** as they grow or come apart* | integrates and disintegrates toward |
| L606 | a person **steps toward** disintegration under stress; a person faring well **steps toward** integration and climbs | disintegrates toward / integrates toward |
| L1997, glossary | integration is *the **step** a person makes when faring well*; disintegration *the **step** of stress* | the two verbs |

**The content is right at all five and only the picture is wrong.** Taking on the connected type's
qualities under stress while remaining one's own type *is* the temporary offset, said in other words.

**And book 1 already contains the repair sentence.** Ch 5, L548: *"this is a statement about
directions, not motion"*, with *a person's main orientation usually does not change* alongside it.
Book 2's Ch 7 says the same. **The fix is to make the arrows chapter obey what the cycle chapter
already declares** — not to invent a formulation.

**One further site, and it is content rather than wording — now settled.** L1078 also claims *the two
systems agree that the drawn relations are traveled*. On the ruling this book holds no such thing, so
the agreement was being asserted by borrowing the classical picture. `[A]`, asked what the classical
account actually has: **"shaded toward it and returning."** So the agreement survives on the model's
own terms — both systems have a temporary shading toward a named position, returning, and they differ
only on how many positions are reachable. **Rewrite the sentence to that, do not delete it.**

### RULED 2026-08-23 — the wing-scale clause goes from the health-axis fluctuation sentence

**L1618** says a person centred at a level typically fluctuates one step up or down in the short term,
and calls that *wing-scale movement along the health axis — the same principle Chapter 11 gives for
the realm circles, where leans are what move a person.*

**Both halves of that clause fail, for different reasons, and the repair is a deletion.**

*The mobility half was never Chapter 11's.* Measured: the phrase *leans are what move a person* does
not occur in Ch 11. Every use of *movement* in that chapter is angular displacement — the section is
headed *Wings as Movement in Orientation **Space*** — and where the chapter speaks about time it says
the opposite, twice turning on whether **stable** leans occur. Two passages outside the chapter cite
it for a claim it does not make: L1618, and **L2250**, which sets the classical fixed wing against
*this book's leans as what move a person* and stakes the retest prediction on the contrast.

*The size half rested on an alignment the book withdraws.* The correspondence opens by setting the
nine Levels against the nine named positions of the wing notation — nine against nine, which would
make one Level about one wing position — and then replaces it eight lines later with **four
landmarks**. `[A]` 2026-08-23: **"we use the landmarks not 9 to 9 correspondence."** With landmarks
only there is no unit on the vertical for a wing offset to be the same size as.

**Repair:** state the fluctuation and stop. The plain observation stands on its own and needs no
reference to the circles. *A bonus: the deleted clause was a mechanical join between the arrows and
the Levels, which the ruled architecture separates structurally. Removing it removes the join.*

**And L2250's retest prediction survives, with its reason replaced.** A measured lean really should be
less stable across retests than core position — but because of what rides on it, not because the lean
wanders. **L2463, in the same appendix, already supplies the correct reason:** *the measured lean is
trait plus fluctuating state*, with the state displaced in the disintegration direction under stress
and the integration direction under growth. **Two passages in one appendix, one grounding the
prediction correctly and one grounding it on a contrast the book does not have.**

### RULED 2026-08-23 — Level 0 goes from both books

See §6, *Closed on 2026-08-23*, for the doctrine. **The text consequence:** every sentence that places
anything on Level 0 needs rewriting to the upper half of Level 1, and the sentence that *generated*
Level 0 needs removing rather than reworking. Sites measured in book 1: **Ch 16's** summit argument
(*Level 1 still retains a desire… and a desire, however refined, is still a rung* — this is the
generating sentence), **Appendix G's** F(1) fork (*the movement is out the top, onto Level 0*),
**Ch 15's** correspondence, which leaves the balanced point of detachment off the scale on the grounds
that it belongs to Level 0, and **Ch 18**, which has Level 1 as Z− and Level 0 as what lies past the
last trace of the seeing lean. **Book 2 was checked: no drafted text places anything on Level 0.**

*Ch 15's is the one that improves rather than merely changes. It currently has to push the balanced
point outside the scheme; there is now somewhere inside for it to be.*

*Ch 18's is the one that does most of the work for free: strike the rung label and that sentence **is**
the internal half-step — the lower height Z−, the upper what remains when the last lean goes.*

### RULED 2026-08-21b — the numeric lean values go, and Ch 11 must be repaired in ONE pass

**`[A]`:** *"i think the content is already too specific. giving lean parameters between -0.5 and .5
was really just a metaphor. i support the ideas that leans can be + or - and vary in magnitude. maybe
we can limit it to that."*

**Direction and magnitude stay. The numerals go.** Measured: exactly **one line in each book** carries
a numeric lean — book 1 L1160 (`HB+0.2`) and book 2 L812 (the same example). Nothing else in either
book uses one.

**The argument is book 1's own, four times over, in the paragraphs that introduce the numbers:**
*"These numbers are illustrative only"*; *"This is just an arbitrary convention to avoid confusion"*;
*"The notation invites more precision than there is"*; and *"This is not meant to be some precise
mathematical rule — it is a demonstration that wings can be more than a weak or strong motion to
another pure Enneatype."* **That last one is the argument for cutting them:** it states what the
numbers are for, and direction-plus-magnitude delivers exactly that. Appendix H already names the
fault by name — *"**False precision.** The register of a working conversation is exact — coordinates,
fractions, rung-by-rung mappings… This cost three separate repairs before the pattern was named."*
**The numerals survived their own author's disclaimers.**

**What goes with them:** book 1's arbitrary boundary convention (`B−.17 to B+.17 is "B"`, and the
rest) and its `HB+.4;SB−.1` worked example, **both restated in words rather than deleted** — the
example's point, that a wing can fall partly between two types, survives without figures.

**A MEASURED CORRECTION, and it changes what Opposite needs.** The record says *Opposite needs
positions only a quarter of the way along*. **Wrong.** Opposition needs the two leans to be
**complementary**, not equal — any pair summing to half the gap lands the two half a circle apart.
Measured off the corrected figure's own coordinates: the four sits at 0.3 and the three at 0.2, in
both realms. So book 2's *this relation, alone among them, needs fractional leans to be stated
exactly* is wrong twice over and **is reworded as a relation between the two leans rather than a
value for either.**

**The figure stays — `[A]`, ruled.** `opposite-relationship.svg` carries **no numeral in any label**,
no scale and no tick marks, and its subtitle already says *shown in each realm separately, for one
pair of types*. The dots commit to values only in the geometry, where a reader has nothing to measure
with. *Distinguished from the winding figure, which was refused because it would have had to commit
to a pitch the model says is non-uniform — asserting something false. Here the values are arbitrary
and the model says they are arbitrary.* **`[A]` asked whether it needs explaining and the answer given
was no.** *Noted and deliberately not acted on: the figure encodes one regularity the text never
claims — each of the two people leans by the same amount in both realms. It takes a protractor to
see, and redrawing would mean regenerating a figure that has only just stopped being wrong.*

**BOOK 2's CH 11 NOW CARRIES THREE REPAIRS AND THEY MUST BE MADE IN ONE PASS**, or the chapter ends
up saying three different things. They are: the numeric lean sentence and the Opposite rewording
above; the either-or on carrying (below); and *at the far end the registering has stopped*, already
on the nine-item list.

### RULED 2026-08-21b — the carrying is neither a switch nor a width

Book 2's Ch 11 says both, two paragraphs apart — *It depends on the caution being carried past
detachment rather than let go of* against *It is one quantity, not two conditions with a boundary
between them, and every degree between them is occupied*. **The first does not want repair toward a
width.** It wants its either-or phrasing softened so that it states the condition rather than a pair
of states. Reasoning at §6.

### RULED 2026-08-21b — the retracted arisings clause stays cut, with no replacement

`[A]` answered what decides what arises (§6), so the question that blocked a replacement is closed —
and he ruled the cut stands anyway: **"cut it."** Reasons on the record: the observation the clause
was attached to, *a type shows most nakedly in how its thoughts end*, is stronger standing alone, and
a list of contributors in the text reads as hedging where the chapter wants a claim. **The repair
job's instruction is therefore unchanged: cut the clause, write nothing.**

### RULED 2026-08-26 — the retraction reaches the Z+ sketch, and the whole sentence goes

**This closes the finding job 17 raised and job 19 restated; the two-site measurement is in the block
above.** Cutting only the marked summary site would have left the retracted claim standing in its
stronger and more specific form, and left *for the reason given below* pointing at a deleted sentence.

**`[A]` ruled 2026-08-26: the whole sentence goes, not the clause.** Trimming it to *The alternatives
stay related.* would leave a disguised restatement — the paragraph already says the same thing three
sentences earlier, concretely and in the sketch's own voice: *And before long a new impulse arises,
usually for a related alternative: the same fun by another route.* The abstract restatement existed to
carry the explanation, so with the explanation gone it has no work.

**CURRENT — re-verified 2026-09-01 to occur exactly once in `rev2-0814q.md`. Delete it entire, including
the trailing space, and write nothing.** *The line number this block used to give is dropped: book 1's
numbers moved on 08-31, and the sentence now sits inside the block-marked sketches — see §2. **The
deletion is still owed**: `[A]` ruled the sentence out on 08-26 and it has never been applied, and a
deprecation mark is not a deletion. Whether it is worth applying to a paragraph already marked
do-not-draft is a fair question, and the answer is that the same clause is queued for book 2 in the
approved closing paragraph above, so the ruling has to be live somewhere the next drafter will meet
it:*

`The alternatives stay related for the reason given below — the fixation selects the population of arisings before any pursuit begins, and at Z+ that population is restlessness. `

The paragraph closes cleanly over the gap: *...the boredom he began with.* runs straight into *He never
sees the layering...*

*One thing is lost and it is small. The earlier sentence says the **next** impulse is usually related;
the deleted one said the alternatives stay related across a run of them. The wider claim goes with it.
`[A]` was told this before ruling. The sketches are loose by intention and the width was carrying no
weight.*

**A new sentence was considered and rejected.** The only cause now available is the deposits, and
`[A]`'s own siting ruling has them entering **once, late, at Ch 13**, answering a question the early
chapters raise and never answer. Spending that arrival on a clause in a type sketch would put a
mechanism inside a description of a person, which is the one placement the ruling excludes. Anything
weaker is the hedging the original was cut for.

### RULED 2026-08-26 — Appendix G states FOUR terms, not two. NO STRINGS YET, and it creates work

**`[A]`, asked whether App G should name desire, attitude, behavior and fear as causal links with the
middle two stated generically, or keep the two-term rule and note the fuller chain once in the gloss:**

> yes, four.

**What it changes.** G.1's formal rule has *Desire to its own fear (within the level)* — D(n)
generating F(n) directly. His 08-21 correction has **desire→attitude→behavior→fear**. The two middle
terms are now **causal links**, so the within-level step stops being one step.

**And this is a change to the CLAIM, not only the exposition. Two reasons, and the first is the one a
successor will miss.** G.1's closing paragraph does not merely omit attitude and behavior — **it gives
a reason for omitting them**: the model's version is stated for the six half-types, each carrying half
the information of a type, and *attitude and behavior, whose value lies in type-level specificity, are
omitted*. **That is a granularity reason, and a link cannot be dropped for being unspecific.** The
stated ground falls with the ruling. Second, the two new terms come under G.1's **hard rule** — the
one said to hold *with the necessity one expects of physical law*. Whether attitude and behavior hold
that rigidly is a real question, and the appendix would now be asserting it.

**What does NOT move, and it is the expensive thing:** all of this is **within** a level. The
across-level link F(n) → D(n+1) is untouched, and that is what `[A]`'s 08-24 ruling put the level
ordering on. **Seed, alternation, the fork at the top, the bottom, conservation, self-obscuration and
temporal layering are all unaffected.**

*A `[C]` observation, not ruled: the appendix's own prose already contains the four terms, unnamed —
its gloss says that once the person is staking themselves on securing the thing, the new fear is that
they will fail to. Staking oneself is an attitude; failing is the failure of an attempt. **The
four-term chain is already doing the explanatory work inside the two-term statement.*** *And a second:
attitude and behavior are the **watchable** links — a buried fear cannot be observed and a desire is
mostly inferred, while an attitude and a behavior are available in the present tense. That is a
handhold the recognition route needs; see the three-outcomes note §5.*

**NO REPLACEMENT WORDING EXISTS AND THIS IS NOT A SUBSTITUTIONS JOB.** The appendix cannot state
attitude and behavior for the half-types until the six-way derivation is done, and that needs a source
table this project does not hold. **See §0 item 7. Do not hand this to a text session.**

### RULED EARLIER THAN ANYONE NOTICED — App G's *top and exit* rule, closed 2026-08-23

**Not a new ruling. A correction to the record of what is open.** The second half of the App G item —
whether *The top, and the exit* matches `[A]`'s corrected reading of Riso's chart, after he said *i
was careless. riso's chart confused me* — **was settled by the Level 0 abolition, which came out of
that very correction.** His chart reading has one arrow running from the basic desire at Level 2 up to
self-actualization at Level 1; book 1's runs from Level 1 up and out onto Level 0. One arrow, two
accounts, and book 1's lost. **App G's F(1) fork is already a measured repair site in the Level 0
block below** — *the movement is out the top, onto Level 0*. **Nothing further is owed on it.**

### ~~FOR JOB 3 — book 2's Ch 7~~ — CLOSED 2026-08-29 AND 2026-08-30, AND NOT THE WAY IT WAS FRAMED

**This item said Ch 7's `Backward` section was a defect because nothing runs backward. `[A]` ruled on
08-29 that most of it is not.** *Kept whole rather than struck, because the shape of the correction is
the reusable part: a ruling was read as reaching further than it does, and a whole section was queued
for rewriting on the strength of it.*

**What `[A]` ruled.** The disintegration direction is **a temporary lean caused by stress, not a
movement** — that kind of backward is allowed, because it is not motion of the endeavor cycle. So the
`Forward` and `Backward` headings **stay** (both name real directions), the three route narrations
under the second **stay as drafted**, the figure `orientation-cycles.svg` is correct as drawn, the
grid directions, the appendix's reversed walk and the glossary's *step of stress* all stay. **His
condition on all of it: the surrounding text must make clear these are lean changes and not process
motion.**

**What was a defect and is repaired.** `runs` was doing two jobs — an arc runs, meaning traverses, and
a direction runs, meaning holds at every position — the class of `residue`, `step`, `cycle` and `arc`.
Five sites across the two books, repaired 08-29. **And no ARRIVAL may be reached by going backward**,
which `[A]` rejected separately: *Coming backward, a person enters it blind* frames detachment as
reached by two routes. Repaired in both books.

**And the doctrine question this item said had to be answered first has been answered — by `Job29`,
from the manuscript rather than from a ruling.** *Does Ch 7 name the Z arrival's difference at all, or
describe the three arrivals evenhandedly and let Part 3 be the first place a reader learns one of them
is different?* **Neither. Ch 7 describes the two FACES and the lean directions; the crossing mechanism
stays in Ch 11 and is not restated four chapters early** — the same shape as R10a. `face` is Ch 11's
word, **so this is the first time Ch 11 has carried backward into an earlier chapter rather than the
two drifting apart.**

**The framing sentence is still the repair template for book 1's five transit-verb sites, and it no
longer contradicts itself three subsections below.** Book 2's Ch 7 reads *This is a statement about
directions, not about motion*, and as of 08-29 the paragraph two lines under it says *The pull that
goes with the order is integration* rather than *Moving with the order*.

**WHAT IS LEFT, and it is `[A]`'s, not a session's — see §6, the two disputed markers.**

### RECORDED, NOT APPLIED — a `[C]` wording for book 2 Ch 4's caution sentence

**`[A]` ruled that writer 2 takes this up with him directly, so the extract goes as-is.** This is here
so the wording is not lost, **not so it is applied.** Current second sentence of the B paragraph:

> It is arrived at deliberately — attending to a thing, generalizing from it, testing the
> generalization against what happens next, and revising it.

Proposed: *Understanding is built rather than had at once*, keeping the method clause unchanged. It
names *understanding* so the sentence cannot reach the orientation, and it earns its keep against Z's
competence four lines below, described as knowing through having looked rather than through having
worked out. **If writer 2 proposes something better, his wins.**

*A smaller point that does not depend on the pronoun: `deliberately` claims a kind where `[A]`'s 08-26
statement has a degree — deliberateness runs across all decisions, some quick and some very
deliberate. He agreed: `true except for the continuous nature`.*

### Carried unchanged

**THE NINE FROM THE ENDEAVOR RELOCATION — APPLIED 2026-08-25. They are not in this section any more.**
`NOTE-fixations-arcs-and-the-two-scales-20260821.md` §8 is still where they are written out, and it is
now a record rather than an instruction. What went in: book 1's *Fixation as a Stopped Arc* section —
retitled **Where a Person Stops**, with its opening definition, its blind-detachment sentence, its
nesting paragraph and that paragraph's temporal consequence repaired; book 1 Ch 5's *deepest question*
sentence and its *largest arc is a life* sentence; book 1 Ch 11 **and drafted book 2 Ch 11** on the
registering having stopped; and the appendix material built on the nesting. **The sixty-second claim
was kept and gained its scope**, and gains its stated difference separately — see the 08-25 rulings.

*The section after it was retitled too, in the same pass:* **`Beneath the Levels: The Process` →
`Beneath the Levels: The Rule That Drives the Descent`.* **`TODO.md` L159 lists Ch 15's sections and
still carries BOTH old titles.** So does an Appendix G citation. Both are stale and neither is
repaired.

**`process arc` IS A RETIRED TERM**, ruled 2026-08-25. There is no umbrella word: **`thought arc`** and
**`endeavor arc`** are named where the shape is introduced and used everywhere after, and the
geometric sense takes **`range`**. *Recorded here as **retired** and not only as a rule, because a
retired term is exactly what a later session reintroduces innocently.* **Appendix A, the reference
card, was not opened** and may still carry a glossary entry for it.

**Book 1 — a clause retracted by `[A]`, 08-20. AND IT NOW HAS A SECOND SITE — READ THIS BEFORE
CUTTING EITHER.** Ch 15, L1474, in the paragraph after the four sketches: *what arises differs by
type* **because the fixation selects the population of arisings before any single arc begins**.
`[A]`: *"i don't/no longer agree"*.

**The old reassurance here — that `grep` finds the clause nowhere else, so nothing downstream
leans on it — was true when it was written and stopped being true on 2026-08-25.** Job 16's repair
to the Z+ sketch restated the clause one paragraph EARLIER, in the selecting-the-population form
the retraction removed, calling it the book's own and nothing invented; job 16 could not see the
retraction because §8 named the clause only in a one-line footer under a nine-row table. **Job 17
applied both and reported it.** **Measured 2026-08-26 against `rev2-0814c.md`: the clause now
occurs TWICE**, at L1470 in the Z+ sketch and at L1474 in the summary paragraph, **and the L1470
site carries a forward reference — *for the reason given below* — pointing at the sentence marked
for deletion.** So cutting L1474 alone leaves a dangling pointer and leaves the retracted claim
standing. **ANSWERED BY `[A]` 2026-08-26: the retraction reaches the sketch, and the WHOLE SENTENCE goes
rather than the clause.** The ruled block below carries the exact string and the reasoning; the
answer is a deletion and no new prose. **The observation is not retracted, only itscause** — the sketches still describe arisings that differ by type. **Cut the clause and write no
replacement:** what sources the arisings is an open doctrine question. What the cut settles is that the
ending is the whole of what an arc shows, so *a type shows most nakedly in how its thoughts end* stops
being a comparison between two channels and becomes the claim itself.

**Book 2 — ruled 08-20, `[A]`, asked whether the sentence goes: `get rid of it`.** Ch 7 of
`BOOK2-20260818c.md`, L622, the **second** sentence of:

> Everyone's thoughts make all three passages; what distinguishes people is where those thoughts habitually come to rest. That is what a fixation is — not a place a person stands, but the place their process arcs rest.

**SUPERSEDED 2026-08-25 — DO NOT APPLY FROM THIS BLOCK. The ruled repair is in
`RULINGS-job18-20260825.md` §1.1 and the string above is out of date.** What happened in between:
job 16 read *get rid of it* as a substitution and rewrote the second sentence, leaving the dead
claim standing in the **lead-in**, which is the sentence this block correctly says was never put
to `[A]`. Job 17 found it. **`[A]` then ruled the two halves are ONE defect with the repair
applied to the wrong half**: the second sentence is deleted, and the lead-in becomes *Everyone's
thoughts make all three passages; what varies is what those thoughts are about.* **A third site,
book 1 Ch 5's twin of the same sentence, is cut whole in the same ruling.**

**And the wrinkle that made this item non-trivial is void against the manuscript.** The worry was
that plain deletion would leave book 2 naming `fixation` with no account of it. **Book 2 defines
the term twice before Ch 7** — Ch 1's *a hardened orientation is what this book calls a
**fixation***, and the loop section's *a habit set down early and held so long that it is simply
where they live*. The rule that made Ch 7 the only account **was true when the rule was made and
stopped being true since, and nobody rechecked it.** *That is worth more than this item: a rule
stated once against a manuscript that then changed under it.*
*Both are doctrine landing on text, the pattern the 08-16 repair began. Doctrine sessions rule them;
the repairs job applies them, and never in the same session.*

**Book 1 — ruled 08-16, `[A]`.** Ch 5, section *"What Kind of Thing the Cycle Is"*, L586 asks *who*
completes a whole loop, and its own answers are not all people. Two search strings,
punctuation-free, one occurrence each:

| Find | Replace with |
|---|---|
| `so it is worth saying again who actually does that` | `so it is worth saying again what actually completes one` |
| `At the scale of **character**, usually nobody does` | `At the scale of **character**, usually nothing does` |

*Not touched:* *"it is worth saying again"*, which is fault 2 above. Book 1 has its own register and
correcting a referent is not a licence to restyle 56,000 words.

**A second book 1 defect found 08-19, unruled, and it belongs to job 3.** Book 1 contradicts itself
on scale. L586 gives three scales topping out at a bounded endeavor and says that at the scale of
character usually nobody runs the whole loop — a fixation is home and what happens are excursions.
L594 opens *"The cycle's largest arc is a life."* There is no life-scale traversal in the
three-scale list. **`[A]`'s instinct that fixations do not traverse is right and the L594 sentence is
the loose one**, so `arc` spans two scales, not three: the bounded endeavor and the thought.

**A FIGURE CORRECTION, APPLIED 08-18 — replace the canonical file.** `opposite-relationship.svg`
labelled Type 3 (HA+;SA−) as **a 3 with an 8 wing**. It is a **5 wing**: the physical realm leaning
from enthusiasm toward caution and the psychic from enthusiasm toward detachment gives HB;SZ, which
is Type 5, and book 1's own prose says a 3 with a 5 wing in the sentence that introduces the figure.
An 8 wing would need the psychic realm to stay at enthusiasm, which the − suffix rules out. **Book 1
is correct and needs no repair; only the figure was wrong.** Two further edits, both to text
elements: the title became `Positions diametrically opposite on the orientation circle`, which is
what the subtitle already said and which removes 08-15b's objection that the figure draws opposite as
a relational class; and the subtitle became `Shown in each realm separately, for one pair of types`.
**The corrected file must replace the canonical one — the copy inside the 08-17 and 08-18 sets is
still the broken one, and any set assembled from that source ships the error again.**

**A REPAIR APPLIED 08-18.** Rules inserted before Ch 4 and Ch 5 in the master; see §2. Formatting
only, no doctrine — *only defects touch text*, and a missing rule is a defect.

**Book 2 — R9 into Ch 1's closing paragraph.** Ruled, unapplied. That paragraph still says only that
the theory might be wrong, which is weaker than the principle: even where it is right it points at a
pattern rather than describing what is exactly so. The fallibility instruction stays; R9 joins it.

**A deliberate divergence — do not "restore" it.** Book 1's Ch 9 realm-friction passage names *"the
mutual contempt of Chapter 3"* twice. Book 2's Ch 9 states the phenomenon plainly and does not name
it. `[A]`, 08-17: **a decision.** `grep` finds no *contempt* anywhere in the master, so a later
session will find the term missing and should leave it missing.

**A second deliberate divergence — do not "restore" it either.** Book 1 Ch 5 L594 illustrates the
three passages with *"a candle burns through all three with no one home."* `[A]`: a candle does not
light itself, so the example fails at the arising passage, which is the one it is there to
illustrate. Book 2's Ch 7 reads **"A wave rises, crests and falls on its own."**

## 6. WHAT IS OPEN, AND WHAT CLOSED

**Every item carries a name. Say the name, never the label — see the warning at the top.**

### Closed 2026-09-05 and 2026-09-06 — `Job49`'s eight closures, and one mechanism replaced three

*Their work is in `SET-NOTE-from-job48-20260905b.md`, `SET-NOTE-from-job49-20260905.md`,
`SET-NOTE-from-job50-20260906.md`, `SET-NOTE-from-job51-20260906.md`,
`CLOSURES-SITED-job49-20260906c.md` and `DRAFTING-aligned-types-20260906b.md`. **Those files are
citable and this section is not.***

**1. BEING LESS CAUGHT SHOWS AS CHARACTERISTICS OF THE TYPES AHEAD — RULED 2026-09-05, `[A]`: *i
agree*.** It does not break book 1's rule that direction and depth are independent as positions.
**It was already drafted, in the relational-positions chapter, since before `Job48` asked** — so
nothing was owed for it.

**2. LESS FIXATION MEANS GREATER TOLERANCE FOR THE DISCOMFORT THAT ORIENTATION IS AVERSE TO — RULED
2026-09-05, and it is the mechanism under everything above.** Disappointment for enthusiasm, loss of
control for caution, naked suffering for detachment — **his own 08-20 aversion objects**. `[A]`
checked the level himself: *are you asking about types?* **It is ruled at the level of ORIENTATIONS,
and the nine sketches are it applied twice per type, once per realm, with nothing added.** *So
`Job48`'s two extra mechanisms — an unused sight in a detached realm, a covered realm reachable only
through another person's report — are WITHDRAWN. They were this one mechanism seen in two places.*

**3. LOSS OF TOLERANCE IS CAUSED BY STRESS CAUSED BY TROUBLE CAUSED BY BLINDNESS — RULED 2026-09-05,
correcting `[C]`, which had made the stress route and the blindness route independent.** **Stress and
loss of tolerance are independent of realms and so reach the fixations in both**, which means a blind
crossing in one realm lowers the whole person. **The joint between blindness and tolerance is
stress.** *It also supplies what the 08-30 steepening ruling never said — why stress rises as a person
descends.* **And `[A]` kept an outside term in it:** *i would say now that trouble is partially
dependent on the outside*, which is what produces the bell-curve spread he insisted on, two equally
blind people in different circumstances accumulating trouble at different rates.

**4. WHAT THE INTERVENER SUPPLIES — RULED 2026-09-05, and it fills the half of his own brake that had
been a placeholder since 09-01.** *the intervener provides comfort and calming while presenting a
thing the person fears*, and, asked whether that replaces imported sight, *maybe both. the intervener
who can see can break a truth down into small pieces, none of which are a threat by themselves.*
**So the intervener works on both sides of one comparison** — steadying raises what can be borne,
giving the truth a little at a time lowers what arrives at once — **and the SIGHT is the intervener's
own, a qualification for sizing what they give rather than a thing handed over.** *This supersedes
the 09-01 wording that an intervener works by supplying sight, which was the plainest statement of it
anywhere in either book.* **Written into the health-axis chapter by `Job51`.**

**5. A BLIND FEAR CANNOT BE GIVEN UP ON — CONFIRMED 2026-09-05.** Giving up drops the want behind the
fear, finding the want requires looking, and looking is what is blocked, **so unburying is the only
route out of a blind fear.** His addition: *the looking has to happen before caution gives way to
blind hope.* **And the fear is not caused by the things it settles on** — *the thing feared is not a
thing - it's just fear but it is attached to things which aren't necessarily threats.* **He scoped the
unreality claim himself to BLIND fear only:** *blind fear is unreal in the sense it blocks reasoning.
not that it doesn't exist but that what is feared doesn't exist - in fact the person doesn't even know
what he fears.*

**6. RETRACTED THE SAME TURN IT WAS PROPOSED, AND DO NOT RE-PROPOSE IT: *hope is in a way denial of
caution*.** Shown the census, `[A]` withdrew it — ***hope is no more a denial of caution than
enthusiasm is.*** **The census that settled it:** book 1 already assigns hope as the Z+ affect and
immediately guards it, so the word is placed and ruled non-diagnostic; and book 2 uses it for
enthusiasm working normally, so making it name the Z+ failure would put one word on a healthy
condition and its counterfeit.

**7. AN ALIGNED TYPE'S ORIENTATION IS HARDER FOR THEM TO SEE AS AN ORIENTATION — RULED 2026-09-06,
after `[A]` withdrew confidence in the reason that had been drafted for it.** His doubt: *the idea
that aligned types don't differentiate the realms is my guess. i see that they seem to miss something
the mixed types intuitively know but i can't see that it is understanding the difference between the
realm.* **The doubt was right and the drafted reason failed in both directions** — a mixed type cannot
learn the realm distinction either, since orientation and realm vary together and never come apart;
and an aligned type is the one holding the move constant while the situation varies, which is what
would isolate the realms. **The reason that holds is the alternative he had set aside: a mixed type
has watched themselves attend in two different ways and an aligned type never has, so the aligned
person's own orientation never shows up as a stance at all.** *It uses only the ruled definition —
attending is something a person does, not a place they stand.* **The reason stands in the grid chapter
and nowhere else; the Three's, Six's and Nine's sketches keep the consequence and lose the reason.**

**8. TWO NAMES FOR ONE STEP IS NOT THE FAULT HIS 09-05 RULE NAMES — `[A]` 2026-09-06: *two names for
one step seems okay to me*.** Enthusiasm's step to caution costs **deferring pleasure** and
**accepting disappointment**, and those are two different costs rather than one thing twice.
Caution's step gains a second in the same way. **Detachment's does not** — its two candidates
collapse, the softening whose loss is feared being the detachment itself. *His 08-20 remedies agree:
detachment's asks for an acquisition, and a step that asks for an acquisition has nothing to give up
twice.*

### Open — carried out of 09-05 and 09-06

**THE MODEL MAY NOW OVERPREDICT THE FALL, AND THE COUNT HAS RISEN TO FOUR.** Entry into blindness has
been made easier with depth four times, all from `[A]`'s own material and none of it posited to
explain the descent: bearability falling as stress and ordinary suffering rise; the maintenance loop
widening as burials accumulate; the retraction of *does not turn into* opening an internal route; and
now the stress route closing the loop on its own product. **Something was finally added to the brake
on 09-05 — the intervener account — and it is drafted.** *`[C]`'s objection is therefore smaller than
it was and is not withdrawn.*

**WHETHER THE NINE CLOSING LINES ARE TRUE AT ANY DEPTH — FLAGGED BY `Job49` AND NOT TAKEN.** All nine
sketches claim the competences come with the pair at any depth, **and no ruling asserts it.**

**WHAT A SET NOTE MAY CARRY THAT THE RECORD DOES NOT — OPENED 2026-09-05, NOT SETTLED.** `Job48`
flagged one item as worth a session's attention on its own and left it out of the record entirely; it
survived only in its own set note, in `Job48`'s paraphrase, in a word that may not have been `[A]`'s.
**This is the second kind of gap found in the record in three sessions**, the first being an append
that never happened.


### Closed 2026-09-01 — `Job36`, four rulings, and two of them close questions this file carried as open

**THE RETRACTED ARISINGS CLAUSE IS CUT.** See §5, where the item that queued it is struck and the
application recorded. **It reached a second live site nobody had named.**

**Z− AND Z+ ARE ONE CONTINUUM, AND Z0 IS THE ZERO-LEAN POINT ON IT.** `[A]`: *there is a continuum
between z- and z+ and z0 is just a point somewhere in the middle. so z0 is an ideal that's important
only as representing total detachment which is important in spiritual traditions.* **This closes the
two-faces-of-Z0 question the census routed to doctrine, and closes it by striking the question rather
than answering it:** *how many faces does fixation-Z0 have* presupposes Z0 is a stance able to carry
one face or two, and on a continuum the two faces belong to the two directions of lean away from the
point, not to the point. **Book 1's one-face assumption is struck, not decided**, and needs no mark —
it sits inside the *Additional Topics* section the census already cut from book 2.

*What it settles, in full, at `BOOK2-PART34-ARCHITECTURE-20260902e.md` Ch 15:* blank unawareness of
one's own pattern is the blind extreme rather than the middle, so **nothing moves into Level 1's
neighbourhood and the difficulty book 1 predicted for the top of the health axis does not arise**;
**partial registering sits in the middle of the axis, where the trap already is**, so the geometry
and the position agree instead of being stated separately; **realm-Z0's two-valuedness is forced, not
chosen** — at zero lean there is nothing in the position to decide which face shows, so book 1's
*deliberately* two-valued must not be written as a design decision; and **total detachment is the
absence of both pulls**, the two ends being where detachment is least pure, which is why the midpoint
is the ideal and why it is nearly unoccupied. **That last step is `[C]`'s and `[A]` ruled it in with
the continuum.** **The Ch 15 hazard is unchanged and sharpened.**

**AN UNANSWERED COST, RECORDED SO IT IS NOT REDISCOVERED.** This makes the health axis the sight
coordinate on the third floor, and **the third floor is still said to carry the whole nine-position
pattern** — where its enthusiasm and caution positions sit is unaccounted for. Ch 15 already calls
the axis a different sort of quantity from the other two floors, so there is room for an answer; none
is written anywhere. **It blocks nothing now.**

**THE FIRST BRAKE IS RULED, AND IT IS NO LONGER `[C]`'s ASSEMBLY ON SINGLE WORDS OF ASSENT.** `[A]`
answered the consequence he widened rather than answered on 08-27: **the route cannot be urged, only
re-sighted.** Urging someone to fix rather than hide asks for an output they cannot select; what
helps is whatever restores sight. *`[C]`'s case, which he accepted:* the second brake works by
imported sight, so the intervener is not adding a second force but redirecting effort already being
spent — **the two brakes are one mechanism met twice**, and the levels-do-not-wrap derivation falls
out of them rather than being deduced beside them.

**AND `[A]` SUPPLIED THE ROUTING MECHANISM THE BRAKE NOTE SAID DID NOT EXIST.** *the basic question
for the struggling person is which is more painful, staying as they are or facing the pain of
unburying their fears and unfortuanately, because of blindness, it is a question of immediate pain,
not the prospect of long term improvement.* **Blindness does not corrupt the comparison; it removes
one of its terms**, leaving only what can be felt now. **It gives the brake its shape** — consequences
press, the pain of staying rises, the person faces the fear when it passes the pain of unburying — **a
restoring force growing with displacement, which is what the bell-curve rejection required**; and it
makes the low tail thin but real with no separate assumption, since further down there are more
layers to unbury. *Measured 09-01, because he thought it might already be in the books: the
comparison occurs at **one site in the whole set**, in the Z+ sketch, governing the drop of a single
endeavor. **Nothing in either book states it of the brake.***

**ONE GUESS, MARKED AS A GUESS AND NOT RULED — how the comparison is ever made.** *my guess is that
the person makes the comparison in a rare moment of clarity, and forgets it again many times until
there is enough of a foundation to do it consciously.* **It gives the ruled forgetting/blindness
distinction its home**, homeless in both manuscripts since 08-27 and said by its own note to belong
beside the brake: **blindness is why the moment is rare, forgetting is why it does not carry.**
*Checked before recording: it does not reopen the ruling above, since the moment of clarity is the
sight arriving unbidden and urging cannot produce it; and it does not touch the forbidding on insight
mid-collapse, since these moments fall in the ordinary run rather than during a drop.* **It also
gives a mechanism to the ruling that a level is many turns and the Levels are recognition markers
rather than units** — the foundation accumulating is what makes a level take many turns. *`[C]`'s
unruled observation, recorded as a shape: a second accumulation running opposite to the first, since
evasion lays layers down and retained sight builds foundation up.*

### Closed 2026-08-30 and 2026-08-31 — four sessions, and one of them redefines the book's central object

*Their work is in `SET-NOTE-from-job31-20260830.md`, `SET-NOTE-from-job32-20260830.md`,
`SET-NOTE-from-job33-20260831.md`, `SET-NOTE-from-job34-20260831.md`,
`CLOSURES-SITED-job32-20260830.md`, `CENSUS-book1-into-book2-20260901.md` and
`BOOK2-PART34-ARCHITECTURE-20260902e.md`. **Those files are citable and this section is not.** What
is here is what a reader of this file alone needs.*

**1. A FIXATION IS A STANDING PREFERENCE ABOUT WHERE ATTENTION IS DIRECTED — RULED 2026-08-30 by
`[A]`, and it is the largest closure since the endeavor relocation.** **Two clauses travel with it or
it undoes two of his earlier rulings:** the preference is about where attention is *directed*, not
what it is directed at; and **directing attention is something a person does, not a place they
occupy.** The forward step to the next orientation is **resisted**, in book 1's own existing sense.
**What survives, demoted:** *where one habitually stops*, said of the person, is true and is now the
**consequence** rather than the definition — the step is not taken because taking it requires
attending the way the next orientation attends, and the preference is against exactly that. **And it
collapses the definition into its own cause:** the blindness that holds a fixation in place and the
fixation are no longer two facts. *`RULINGS-20260816b.md` carries the mark on R4; it had stood at
full strength for ten days after being struck by name elsewhere.*

**2. THE FIXATION DEFINITION SITS IN PART 1 AND APPLIES CONSISTENTLY — RULED 2026-08-31, and R10a is
NARROWED, not retired.** `[A]`: *"i am thinking it should apply consistently - isn't it defined in
part 1?"* **R10a was written when the account of a fixation was R4's** — the next transition failing
to start — which is transitions material and so was naturally held back to the transitions chapter.
That account is superseded, and the new one belongs where the orientations are described, which in
book 2 is Part 1. **Book 2 already carries it there without gathering it into a sentence:** Ch 1
names a fixation as a hardened orientation, and Ch 4 describes each orientation in attention terms
throughout. **What survives, and it is the whole reason the rule exists:** the reader meets the word
in Ch 1 and then reads nine type profiles built out of pairs of fixations before reaching the
orientations. **Name it; do not explain it — until Ch 4.**

**3. THE CROSSING HAS FOUR FATES, NOT THREE — RULED 2026-08-30, with the ordering and the sort.**
**`worked through`, `given up on`, `ignored`, `blocked`.** Sorted on whether the fear is in view and
whether it is disposed of; **nothing never seen can be disposed of, so blocked is the only fate on
the unsighted side**. Within one crossing the fear meets the sighted end first and what survives
reaches the end that turns away. **Giving up on drops the want behind the fear** — fear gone, regret
remaining. **Ignoring drops nothing**, which is why it returns. *`[C]` had reported four against the
note's three at the session's opening, was pushed back on, and withdrew it on the 08-27 placement of
ignoring — **and that placement did not survive the session.** The count is four by `[A]`'s own
route; the withdrawal was right in outcome and wrong in reasoning, and `[C]` said so before the
ruling.*

**4. THE FIRST NAME WAS RULED TWICE — `settled` on 08-30, `worked through` on 08-31.** **`settled` is
unusable**: book 1 already has a fear *settling into a fact*, which is the mechanism of the descent,
so the ruled name meant the opposite of the fate in the book that carries it. **`answered` and
`resolution` are also taken** — the first is the fear-answered-by-desire rule and book 1 says
elsewhere that a fear cannot be answered; the second is the third arc phase. **`accepted` was already
rejected** for the Nine's self-image. **`worked through` is both books' own phrase for a fear met
properly**, and it makes the list read without a seam.

**5. `unattended` IS THE GENUS OVER `ignored` AND `blocked` — RULED 2026-08-31.** `[A]` proposed that
burial has two types with ignoring as one; **that runs against his own 08-27 words** — *a fear seen
might be later ignored but not buried* — **and against the four fates**, which sort the two by
whether the fear is in view. **What is real is the family:** worked through and given up on **end** a
fear; ignored and blocked leave it **unattended**, sighted and unsighted respectively. It is his own
non-attending spectrum's noun, it sits directly on the ruled definition, since a fixation is a
preference about where attention goes and this is the fate of what the preference passes over, and it
is already in both books twice each doing this job. *Rejected: `turned away`, which is the crossing's
own geometry and would name the genus after one species; `avoided`, six ordinary uses across the
books; `set aside` and `deferred`, both implying return, true of ignoring and false of blocking.*

**6. `painful` REPLACES `urgent`** as the variable deciding whether a fear can be left alone. **It
costs nothing in either master** — `urgent` and `urgency` appear in neither book, and book 1's three
uses of `painful` are ordinary prose. *One consequence: `[A]`'s 08-27 scope note that fears from
enthusiasm feel less urgent than a fear arising at caution becomes **less painful**, which reads
truer.*

**7. TWO RETRACTIONS, 2026-08-30.** **Arriving at Z+ does not automatically fire the blindness loop.**
And ***does not turn into* is withdrawn**: intentional non-attending, automatic non-attending and
defended blindness are **three points on a spectrum**, the feedback at the third being a qualitative
change rather than a further degree. **The consequence recorded at the time falls with it: the
external route is no longer the only route down**, since the habit can acquire the feedback and
convert at the tipping point.

**8. ENTRY AND MAINTENANCE ARE DIFFERENT MECHANISMS — RULED 2026-08-30.** **Entry:** a fear becoming
unbearable, how much it hurts against how much the person can bear, **and bearability falls with
descent** because stress and ordinary suffering rise. **Maintenance:** recognising a burial threatens
to undo it, so the recognition is itself a threat and burying it avoids a real present anxiety.
**The preverbal account is superseded by neither** — it answers how the reflex was learned, which is
a third question.

**9. `[C]`'s BRIDGE IS DROPPED, NOT LEFT HANGING — 2026-08-31.** `[A]`: self-blame usually contributes
and blaming the world would too. **A variable that works either way is not the variable.** The pain
rising does the work. *The step missing from the external route is therefore **no longer the largest
open thing and no longer load-bearing**, since the retraction above opened an internal route. It is
still open. `[C]` offered a join in the `Job33` conversation — ignoring lets the thing feared happen,
the situation worsens, the fear's pain rises, and what reaches the end that turns away is blocked —
**and `[A]` did not rule on it. It is `[C]`'s, unruled, and recorded in that set note and nowhere
else.***

**10. `[A]` MINTED AN ARTIFACT TYPE: THE SITED-CLOSURES FILE.** **A doctrine session cuts a file of
site and claim, never the sentence**, so that closures landing on text can be handed over without a
doctrine session drafting anything. The standing rule that a doctrine session does not touch the
manuscript is unchanged. **He agreed to the rule and not to the layout** — `[C]` proposed the layout
and he had not seen one. `CLOSURES-SITED-job32-20260830.md` is the first instance and says on its
face that its form is free to be reshaped. **It was tested immediately: `Job33` applied all thirteen
rows**, so the form can be acted on without reconstructing the reasoning. *This file now gives it a
place in §1.1's job 7 and job 11 rows, which it did not have.*

**11. `[A]` COINED `mental deposits` HIMSELF — 2026-08-30.** *"mental deposits" was coined by me in
order to avoid the traditional buddhist "volitional formations".* **So Part 3 states the mechanism in
his own word and owes Part 4 nothing for the vocabulary.**

**12. THE FALLING AND RISING MERGE STANDS — `[A]`, asked directly on 08-30.** He questioned `[C]`'s
recommendation to split them; measured, length clears the bar but is the weaker reason, and **the two
brakes are the hinge between the directions**. **`[C]` withdrew the recommendation.** The crossing
account moves into the Levels chapter instead.

**13. THE FOUR SKETCHES ARE PLACED — `[C]`'s call, `[A]` assenting, and it is the first item decided
under his census instruction.** **Book 2 carries them, at Ch 15, immediately after the crossing
account.** Book 2 has no walked-through endeavor anywhere and Ch 15's crossing account is all
machinery with no lived instance. **The deciding fact is in his own text:** three of the four sketches
end on anxiety left unattended and accumulating, which has nothing to rest on until the crossing
account exists. *Ch 13 was rejected because the architecture makes it a claim about processes as
such, true of a candle, and the sketches are about four kinds of person; Ch 14 is a person's history
and the deposits.* **The cost lands on Ch 13**, which must give `A`, `B` and `Z` their second sense
as phases of a process — book 1's cycles chapter already has the sentence, and `[A]` cited it himself
when approving `stage` → `phase`.

**14. THREE UNITS OF BOOK 1 THAT WERE ACCOUNTED FOR NOWHERE ARE DECIDED — `[A]` assenting to each,
taken one at a time.** **Book 1's Appendix F, *A Note on Designing the Tests*, is CARRIED**, at its
own letter, with Horney moving down. ***`[A]` ruled: leave it as provisional by intention***, so it
goes in as written, promise to replace itself included. **It had hidden behind a letter** — book 2's
proposed Appendix F is Horney, taken from book 1's Ch 13, so the appendix list read as complete while
the test-design appendix was absent from everything. *The reason it matters: it is the only place in
either book saying what would falsify the model, and **its prediction of ABSENCE** — the
physical-realm instrument should genuinely fail to tell a 2 from a 4 from a 9 — **is the hardest
thing in either book to pass.*** **Additional Topics for Future Exploration is CUT**, with the two
faces of Z0 lifted out and routed to doctrine. **The Conclusion is CUT** — a conclusion is written for
the book it closes, and book 2 writes its own at the end of Part 4 — **with the testing order lifted
out and given to Appendix F**, which the Conclusion states more plainly than the appendix does.

**15. `wraparound-grid.svg` IS MISFILED AND GOES TO BOOK 2's CH 8 — `[A]` asked and assented.** It is
the one figure of book 1's eight that book 2 uses nowhere, and it is stranded rather than dropped: it
sits in book 1's grid chapter because that is where book 1 introduces direction, and **book 2's Ch 6
deliberately withholds direction**, so the prose moved and the figure did not. **It goes to Ch 8,
which has no figure at all** — not for the single-realm closure, which needs none, but **for the
aligned-types paragraph**, where the text says the Three is Double Ahead of the Nine by one step in
each realm while the grid shows them in opposite corners, looking like the furthest move on the
board. **THE CAPTION MUST BE RECAST AS DOUBLE AHEAD**: book 1's works the move as *integration*, and
Ch 8 does not have integration yet. **A text session's job.**

**16. THE ARCHITECTURE MADE TWELVE `[C]` CALLS AND THEY ARE LISTED BY NAME, DELIBERATELY.** They are
at `BOOK2-PART34-ARCHITECTURE-20260902e.md` §7. **The reason they are carried by name rather than
settled inside reasoning is the Level 0 case:** it sat on two files' open lists for eight days after
`[A]` closed it and nothing caught it. **A call carried by name gets revisited; a call recorded
inside reasoning gets inherited.**

### Closed 2026-08-29 and 2026-08-30 — five sessions, and none of it needed a fold to be usable

*Four of the five wrote their work into set notes, into `OPEN-from-job25-20260829.md`, and into
`REPAIRS-job16-book1-defects-20260825g.md` Parts 6 to 10. **Those files are citable and this section
is not.** What is here is what a reader of this file alone needs.*

**1. DETACHMENT SEES THE REALM WHOLE — RULED 2026-08-29 by `[A]`.** His words: *the detached
orientation see into a realm as a whole regardless of whether all of what they see is available to
consciousness*, and, asked whether the person who notices each fear and settles none of it sees the
realm whole, *they see into the real as a whole, that doesn't mean they think about it*. **Seeing into
the realm is the INVARIANT of the orientation. What varies is how much of what is seen becomes
available to consciousness, and what is then done with it.** *Two things ruled with it to keep it
narrow: seeing a realm whole is what the detached orientation does, so a realm is not seen whole
without it; and seeing each thing as it arrives is NOT the same as seeing the realm entire.*

**THE WORD IS DELIBERATELY OPEN AND NOBODY WRITES A SUBSTITUTION ON THE STRENGTH OF THE RULING.**
Both books use the seeing family for the VARYING quantity throughout, which under this ruling is
backwards, and **the census of sites is `OPEN-from-job25-20260829b.md` §3.2** — about twenty across two
books. **What changed since that file was written is that ONE site now has a word:** in `Job27` the
Ch 11 paragraph beginning *How much of a realm a person knows* was rebuilt with `[A]` in session and
he chose **`know`** for the varying quantity, leaving `see` for the invariant. **`know` is a
PRECEDENT, not a ruling.** *At a §3.2 census site, use `know` or stop and ask him. **The failure to
avoid is a second word chosen at a second site because the first choice was not visible.*** It does
not transfer everywhere: **`blind face` and `seeing face` are a named pair**, and the two load-bearing
sites — book 1 L1490 and L2294, *the destruction of the seeing itself*, which grounds Ch 16's mobility
asymmetry — **need rewritten sentences rather than a swapped word.** **Do not run the naming pass as a
side task. Report anything you touch.**

*What it does NOT reach: whether the health axis's seeing quantity is the same object. `[A]`'s 08-20
captured material has enthusiasm unable to see the bigger picture and caution unable to see the whole,
which if ruled would make whole-realm seeing detachment's alone. **That material is captured and
unruled. Do not assume it.***

**2. DISINTEGRATION IS A LEAN, NOT A MOVEMENT — RULED 2026-08-29 by `[A]`.** His words:
*direction of disintegration is not a movement - it's a temporary lean caused by stress - that kind of
backwards is allowed since it is not movement of the endeavor cycle.* **So the 08-19 closure —
nothing runs backward — bites on the ENDEAVOR cycle only, and backward language naming a lean toward
the previous orientation stays.** **A stress transition is a lean-sized change IN THE FIXATION**, and
his tolerance is expressly conditional: *as long as it's clear that it's a lean change and not process
motion.* **What this overturned, inside the same session: a call that the figure needed redrawing and
a call that the six backward transitions in the two books needed rewriting. Neither was done.**

**3. AND YET NO ARRIVAL MAY BE REACHED BY GOING BACKWARD — `[A]`, the same day, and it goes further.**
*'Coming backward, a person enters it blind' that idea is now rejected. what was considered backward
motion is now considered less than a full circle of forward motion.* **So the DIRECTION may be named
backward; the ROUTE may not.** *He held the two apart himself: `enter detachment on its blind side`
inside a transition is tolerated as lean language, while `entered from either side` frames detachment
as reached by two routes and is not.* Repaired in both books.

**4. THE ROUTE IS NOT THE CAUSE OF THE BLIND ARRIVAL — settled 2026-08-30 from the manuscript, and it
is HALF a replacement, which is the part that matters.** Ch 7 and book 1 Ch 5 both explained the blind
arrival by *arriving by collapse rather than by understanding*. **Book 2's Ch 11 replaces that: what
is laid down at the crossing is decided by what became of the fear** — an aversion meets an aversion
to that aversion and the second wins — closing on *Only a blocked fear is a failure of seeing*.
**But Ch 11 KEEPS the route for the SEEING side, in the same words Ch 7 uses** — *leaning back toward
caution, detachment has been arrived at by way of understanding, and the sight gained there is
retained*. **So Ch 7's forward passage is not false and was not touched; only the blind side was
replaced, and nothing of Ch 11's machinery had to be imported**, the cause already standing in the
sentence above the cut clause. *This is the finding that shrank the job from a chapter rewrite to
three edits.*

**5. THE BURIAL REFLEX IS FED CONTINUOUSLY — RULED 2026-08-29, `[A]`: *"both happen continuously."***
`NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md` §4 had kept only the completed early
learning and dropped the live reinforcer, then drew three consequences in §4.2 that all need the
reinforcer back. **Ruled: both.** So **blindness strengthens with use** stands, and with it the claim
that the fixation account and the blindness account run on one process. **§4 is corrected in the file.**
*Consequence shown to `[A]`, not disputed, NOT ruled: `preverbal` describes only the oldest layer, so
§4.4's dissolution of the chooser problem covers the earliest layer alone and later layers are the
ordinary Ch 17 gradient case — the repeated choice being the choice not to look.*

**6. THE SECOND BRAKE IS NOT CONDITIONAL ON STRESS — RULED 2026-08-29.** Stressed people are harder to
help and some interveners specialise in that, but stress does not switch intervention off. **`[A]`'s
reason is the load-bearing part: it happens outside the person's psyche, *"so there isn't anything
beyond that to say."*** **It draws a boundary the model needed:** the first brake is a fact about the
person and the model owns it; the second is a fact about somebody else acting, and the model can say
that it reaches the person and by what means, **and nothing about what makes an intervener succeed.**
*Settles: the brakes do not fail together, so the low tail is not thickened by this. The tail's own
problem is untouched — it entered on one word and was derived from stress being a discrete switch,
which `[A]` has since called a slope.*

**7. THE ORIGIN OF THE FIXATION — DECIDED 2026-08-29 NOT TO NEED DECIDING, and that is the ruling.**
`[A]` proposed that the burial mechanism does not require a fixation: it has a place in the cycle,
where a fear is completed, burial is one way of completing it, and how it is completed may be prior to
the fixation and may be what determines it. **He then withdrew the causal word himself** — *the idea
may be wrong - maybe it's genetically and environmentally determined* — and asked *does it need to be
decided?* **Recommendation accepted: no, and ruling it would be a mistake.** Nothing in either book
rests on it; the arcs, leans, crossing, descent and brakes are all downstream of the fixation as a
position. **And a genetic or environmental cause is not an internal derivation, not an applied claim
and not a correspondence with the classical figure — it is an empirical claim the model cannot test,
so ruling it would give it authority it has not earned.** *That is `[A]`'s own test, and his stated
reason for declining to rule the level-feedback corollary on 08-27.*

*Cleared out of its way and worth keeping: **`temperament` is not available** as a name for the cause.
Both books use it as the residual — what is true of a person once orientation has explained what it
explains — at book 1 L504, book 2 L350 and book 2 L432. Naming the fixation's cause `temperament`
would make those three sentences false. Genetically-and-environmentally-determined does not collide.*

**7a. WHAT REPLACES IT — A DRAFTING ITEM, and it is the useful half.** **The book should say plainly
that it takes the fixation as given and does not account for its origin.** Right now the question is
silently unasked and a reader can take the early-habit material as an implied answer. `[A]` agreed and
added the second half himself:

> fixation's origin is unexplained, as is what an infant's tendency to deal with fear is, other a the
> tolerance to fear which allows it to be resolved before the desire to bury it arises.

**Two parts, then: the origin of the fixation is unexplained, and what disposes an infant toward one
way of handling fear is unexplained. Neither is a gap the book should hide.** *Where it goes was not
decided and it is not obviously Ch 11's.*

**7b. A THIRD THRESHOLD, FLAGGED ONLY — AND IT BELONGS TO THE RESERVED SESSION.** `[A]`'s carve-out
above names **tolerance to fear** — a fear resolved before the desire to bury it arises. **That is a
threshold, and it is the third in the model**, alongside **urgency**, ruled 08-27 to decide whether a
fear can be ignored and ruled analog rather than a line, and the reserved question of **whether depth
sets the overwhelm threshold**. **Nobody has asked whether these are one quantity or three.** *This
hands to the reserved session as something it inherits, not to a session that half-opens it.*

### ~~TWO DEPRECATION MARKERS IN BOOK 1 ARE DISPUTED~~ — CLOSED 2026-09-01, BOTH COME DOWN

**`[A]` ruled both after being shown what book 2 does with the same material.** The two-faces mark
lifts and the text is unchanged; the stressed-collapse mark comes off the paragraph and the six-word
clause `Arriving by collapse rather than understanding, ` is deleted instead, which is the repair
book 2 already has. **Exact strings and the reasoning at §5. Neither is applied.**

**And a third of the same group is now flagged and NOT ruled** — the cycle figure's caption. It
carries the same stated reason as the two that lifted and is not in the same position: its problem is
that it calls disintegration *the reverse direction*, which `[A]` rejected on 08-29. **The mark may
well be right and its stated reason wrong, which is not the same as being right.** *`BOOK1-INDEX-20260815.md`
already ruled that caption to be book 1 doctrine rather than a stray, so this is not a small item.*
**He has not been asked.**

*Retained, the question as it stood, because the reasoning is what the ruling had to clear:*
**Neither is a doctrine question and neither blocks anything. Both are one-line answers from him.**

- **L582.** `job28` marked its own repaired summary sentence deprecated, on the ground that *a lean
  from enthusiasm under stress shows it blind* still lets the lean's DIRECTION be the reason for
  blindness. **But book 2's Ch 11 says the direction of the lean IS the reason, in as many words** —
  *Which face appears is set by the direction of the lean, because detachment's two neighbours are
  what produce them*. **The lean is upstream of the blocking, not a rival to it. On that reading the
  marker should lift**, and book 2's twin was left standing for the same reason.
- **L576.** The marker sits on a paragraph `[A]` called correct as it stands, with only its closing
  clause at fault — **and that clause is now gone from book 2.** A marker attaches to a paragraph and
  book 1 is one paragraph per line, so approved text sits inside the mark.

*NOT marked, deliberately, and the reasoning is worth keeping: book 1 L590, `These cycles describe
actual psychological processes, not theoretical constructs.` Plural, and disintegration is not a
process — **but this is a LIVE question with a ruling owed, flagged 08-19 and unresolved, and marking
it deprecated would file a question as an answer.** Ch 5's title `The Psychological Reality of the
Cycle` carries the same weight.*

### ~~BOOK 1 HAS NO CROSSING ACCOUNT, AND IT IS CAUGHT BETWEEN TWO STANDING RULES~~ — CLOSED 2026-08-31

**`[A]` answered the permanent question: book 1 is a reference for writing book 2 and he does not
intend to fix it.** So the gap stays a gap. **Delete or mark what is false, leave it, write no
replacement** — and the markers stop being an interim answer and become the answer. **Nothing is
back-ported.** *Retained below because the reasoning is what the ruling had to clear, and because a
successor meeting a marked paragraph should know why marking rather than repair is the standard.*

**Measured by `job28`:** book 1 has no *carried past*, no aversion meeting an aversion to itself, no
four fates, no *failure of seeing*. Its only aversion material is caution's definition and the basic
fear at the floor of Appendix G. **The replacement for book 1's Ch 5 exists only in book 2.**

So book 1's half is false, and *repair book 1 where false* says fix it — **but writing book 2's Ch 11
into book 1 is BACK-PORTING**, out of scope in the last three set notes and adjacent to the
prohibition on repairing a book 1 passage to match book 2. **The markers are the interim answer.**

**The permanent one needs `[A]` to say what book 1 is FOR.** He gave a first, uncertain answer on
08-28 — *book 1 is the source book 2 is drafted from* — and today's repair decisions rest on it.
**If that is right, deleting the false claim and leaving the gap suffices. If book 1 is a book, it
needs the account.** *`Job27` listed this as one of three things to ask him before starting and it was
not asked.*

### Closed on 2026-08-26 — the four-term chain, and a second item found already closed

**`[A]` ruled Appendix G states four terms.** Full reasoning and its cost at §5; the derivation it
creates is at §0 item 7 and has no slot.

**And the other half of the same item turned out to have been closed on 08-23** — see §5. *Two files
in the current set disagree about it in opposite directions, which is the finding rather than a
footnote:* `DEFECTS-carried-forward-20260825b.md` lists both halves as open and says the four-term
question *has never been put to him*, while this handoff has carried the top-and-exit answer since
08-23 without anyone noticing it answered a listed defect. **Item 1 of that file now has nothing open
in it at all. What remains open there is item 2 alone — `[A]`'s own 08-21 question, *do we need
thought arcs anywhere else?*, still owed a direct answer.**

**THAT FILE IS NOT REVISED HERE, deliberately, and this is the second time it has been left.** It is
job 18's record of what job 18 found; it carries a rule that none of its items may be repaired without
a ruling from `[A]`; and revising another session's record is a text act a handoff session should not
make quietly. **It now describes two closed items as open and one closed item as never asked. A
doctrine session that opens it will meet closed items described as open** — the same hazard the
record's personal-entries question has, and it is now the file's dominant failure mode rather than an
edge. *Whoever revises it should be told to, by `[A]`.*

### The general shape both of those defects share — worth stating once

**An answer and the question it answers ended up in different files, and the file carrying the
question kept travelling.** It happened twice in two days, in opposite directions: the four-term
ruling was in an author-record addendum that **fell out of the set**, while the defects file asserting
the question was unasked **stayed in it**; and the top-and-exit answer was in the handoff **everybody
reads** while the question sat in a file **nobody rechecked**.

**The practice that follows, and it is cheap: when a ruling closes something, name the file that lists
it as open, in the same pass.** A ruling is not finished when it is written down. It is finished when
every file that calls it open has been told — which is §1.0's supersession rule applied to questions
instead of filenames.

### Bookkeeping defects found 2026-08-27, none affecting the set

- **`SET-NOTE-from-job21-20260826.md` names the live addendum as `HANDOFF-ADDENDUM-20260826b-job21.md`
  at 3,367 w. The file that travelled is `HANDOFF-ADDENDUM-20260826d-job21.md` at 4,095 w** — two
  sections were appended after the set note was written, forcing two more letters. **The set note's
  quarantine list is short by those two.** *And the letter in that filename is ambiguous in a way no
  other name here is: it reads either as the addendum's own revision letter or as the letter of the
  handoff it addends, and the two readings disagree about what exists. **An addendum should name its
  parent in words and take its own plain letter.** The fold makes this moot for this file; the naming
  question is not moot.*
- **`MANIFEST-20260821c.md` and `MANIFEST-20260821d.md` still carry the wrong session label.** Carried
  from 08-23, unfixed, and it will keep surviving — see the manifest section.
- **The `job22` set was clean but did not match its own job row.** §1.1's job 9 row is written as a
  shape: the outgoing handoff, the record carried unread, what the sessions since produced, both
  manuscripts, the tools. **The delivered set carried twenty files beyond that** — effectively the
  job 7 doctrine set. *Read as deliberate rather than a slip, and useful: checking a §1.1 row means
  checking it against a file that exists. Recorded because §1.0 requires extras to be named, and
  because the job 9 row could say so instead of being silently over-supplied every time.*

### Open on 2026-08-24 — TWO CAPTURE GAPS, and they are the same failure at two depths

**Neither is a doctrine question. Both are about whether what `[A]` said reaches the file that is
supposed to hold it**, and both were found on 08-24 by `quotecheck.py` once its line-wrap defect was
fixed — which is to say the check that would have caught them had been broken the whole time.

**1. The 08-23 rulings were made from words that were never filed. CLOSED, but the mechanism is not.**
The 08-23 session ruled three times, wrote `[A]`'s sentences into its handoff and its note, and
appended **nothing** to `AUTHOR-RECORD.md` — that file stopped at 08-21. Two of the note's quotations
verified against neither the record nor book 1, because they were nowhere but the note. **Six
sentences were recovered and appended on 08-24.** Nothing was lost, but nothing detected it either:
the record has no rule requiring a session to append before it cuts a handoff, and no tool checks.
~~**Open: whether cutting a handoff should be gated on the record having been appended to.**~~
**CLOSED 2026-08-27 by `[A]`: every session appends before it ends, and a session that may not read
the record appends blind.** See §1.1 for the rule and its one cost. The reasoning that made it look
hard is kept below, because it is what the resolution had to clear.

**The question got harder on 2026-08-26, when `handoff` became a job kind.** A handoff session
**carries the record and does not read it** — that is what keeps it able to draft — so a gate of the
form *append before you cut* would either force it to open the file, destroying the property the job
was minted with, or would have to be satisfied by appending blind. **The 08-26 session appended
nothing and was right not to**, since `[A]` said nothing that day that was not already filed; but
*nothing was said worth filing* and *the session could not tell* are indistinguishable from outside,
which is the whole problem. **A workable form would gate on the doctrine session that heard the words,
not on the handoff session that files the summary.** *The 08-27 ruling takes the other branch:
appending blind is the answer, because the bar was always on reading and never on appending.*

**2. The record does not reach back to before its own creation. CLOSED on 08-24 by `[A]`'s
instruction to backfill.** Seven quotations from 08-15 and 08-16 were recovered from five files. **Open:
nothing guarantees the sweep was exhaustive.** It covered the doctrine set only. Files outside it —
`CONSOLIDATED-THEORY-20260814.md`, the writer 2 brief, the job 6 note, the quarantined handoffs —
were not swept, and any of them may carry `[A]`'s words from before 08-20. **A session that opens one
of those for another reason should sweep it and backfill what it finds**, following the selection
rule at §7.

*Both of these sit under the standing selection rule — record what cannot be reconstructed. A
conclusion can be re-derived and a `[C]` argument made again; what cannot be got back is something
`[A]` said once. **Twice now that rule has been stated in a handoff and twice the material was
missed anyway**, which suggests the rule needs a check behind it rather than better wording.*

### Closed on 2026-08-25 — three sessions in two days, and only the last of them ruled doctrine

**`Job16` and `Job17` were book 1 defect sessions and `Job18` was doctrine. None of them cut a
handoff, which is why this file had to.** What follows is what a reader of this file alone needs;
`RULINGS-job18-20260825.md` and `REPAIRS-job16-book1-defects-20260825g.md` are citable and this is not.

**1. THE AUTHOR RECORD TRAVELS IN EVERY SET — `[A]`, and it closes the conflict §7 had left open.**
The old restriction sentence did two jobs in one line, barring the file from travelling and barring a
text session from reading it, and **only the second was ever wanted**. Barring it from travelling is
what let the copy in `[A]`'s own directory fall four days behind while three sessions worked from
short copies. **The file's own first line now carries the new wording and the screen has a third
verdict, `CARRY, DO NOT READ`.** *A text session that reads it is still disqualified from drafting;
applying a prepared list of exact strings is still allowed, which is what makes
`RULINGS-job18-20260825.md` Part 1 usable by a session that never opens the record.*

*What this retires:* §7's *unresolved conflict between this practice and the set-folder convention*,
which asked `[A]` to choose between exempting the record from set folders and marking it in them.
**He chose neither and dissolved the question** — every set carries it, every archived folder keeps
its copy, and what tells a stale copy from a live one is the RECORD MARKER at its foot, not the
folder it sits in.

**2. WHAT THE THREE PASSAGES TAKE — `A`, `B` and `Z` in *arising at A* name MOVES.** Urging,
examining, letting go — not feelings, and not bare positions. **`[A]`'s example settled it:** a
cautious person deciding to buy a gun for protection begins with an *urge to action*, fear-driven and
still an urge; the consideration comes after. **So a passage arises at A while feeling nothing like
enthusiasm**, and the three moves run in every arc whatever it feels like. *The feelings come from the
deposits.* **This retires the 08-21 discomfort at the root and retracts nothing** — *beginning, middle
and end have no relationship to emotions* was true of passages, and *the impulse is felt* is true of a
lived process. **The word that had never been pinned down is *complete***, which one paragraph uses in
two senses: *reaches its characteristic point*, of a passage, and *ran the whole way and came to
rest*, of a thought. **Arcs end at Z; passages end at three different orientations** — the arc's outer
boundary and its internal joints, which never conflicted.

**3. THE FIXATION IS THE STORE'S SHAPE, NOT A THING STANDING ON IT — `[A]`, correcting `[C]`:
functional habit and the residue of a lifetime of examining are the same thing.** There is no
functional core underneath the residue; the hardening **is** the accumulation. **This is book 1's own
Ch 1 definition said out loud** — orientation is the move, fixation is that move hardened, hardened
means the residue of having made it — so **nothing in Ch 1 has to be reopened.** And then: the
deposits underlie everything, **including the fixation**.

**4. THE WEIGHT OF THAT, RULED — MECHANISM, NOT IDENTITY.** `[A]`: *mechanism is the true answer, but
fixations appear as a persons effectively fixed type.* **The deposits explain how a fixation sustains
itself and do not displace the types.** The register when it is written must answer *why does it
hold?* and never *what you really are underneath*, which would undercut nine chapters to buy nothing.
**The fixed appearance is not a simplification being tolerated — it is a fact the mechanism produces**:
a store that has laid down the same move for decades goes on laying it down. The books can keep saying
a person is their two fixations and be exactly right at the scale they say it. **Siting is job 6's and
was explicitly handed over** — `RULINGS-job18-20260825.md` §2.5 recommends Ch 13, with reasons, and
says it is not a ruling.

**5. WHAT COLOURS AN ARC — and `[A]` said two things an hour apart. BOTH ARE IN THE RECORD AND THE
SUPERSESSION IS `[C]`'s READING, NOT HIS.** He first ruled *the initiating feeling colours all three
passages*; asked how that squares with a cautious person's arc *arriving* at the fixation mid-arc, he
answered that **both thought arcs and process arcs can have any emotional colouring, because they
arise out of the deposits, and the fixation strongly influences the deposits' content but the deposits
carry other influences also.** The second reading settles the 08-20 tension without either account
losing — **a station and a source are different claims**; the fixation is met at its own place in the
arc, the colouring comes from the store. **It was not put back to `[A]` in those words. A later
session should confirm it rather than assume it.**

**6. THE DESCENT AND THE CLIMB.** `Job16` opened resolution rate as the descent quantity and fuzzy
fixation position, both in `NOTE-resolution-rate-and-the-descent-20260825.md` and both **derivations,
not rulings**. **`[A]` minted a question off it and named the null result as a real possible answer:
how the way UP the levels differs by fixation** — see §0 item 7.

### Closed on 2026-08-23 — the `2g` session, three rulings

**The session was given *what a step is made of* and the word turned out to do four jobs, not two.**
The measurement is below; it is what produced everything else that day, including two rulings nobody
went looking for.

**1. `step` — CLOSED, by `[A]`'s cut rather than by a vocabulary scheme.**

*Measured, book 1, every occurrence of the word — seventy lines. Four jobs:* a relation between two
positions on the cycle (*one step ahead*; L971 has to stop and tell the reader these name relative
positions, **not amounts of progress**); a move on the grid, which is what the hexad walk counts; a
crossing between orientations a person actually makes (Ch 5's section *What Makes a Step a Release* —
the same step taken because experience taught you something or because you were frightened); and a
rung on the health axis.

**`[A]`'s cut, and it collapses three of the four:** *"there are two different kinds of positions on
the orientation cycle: the fixations and the stages of an endeavor. fixations don't move but we speak
of relationships between two fixations as ahead or behind."* And: *"ahead and behind are other names
for the directions of integration and disintegration respectively."*

So — **only the endeavor's stages traverse**, and *step* in the motion sense belongs to the endeavor
and nowhere else on the cycle. **Ahead-and-behind and the arrows are one static relation under two
names.** The health-axis rung is not on the cycle at all and is separated on its own grounds. *Book 1
already had the identity, unstated: L1082 has a crossing relation as the same move as a hexad step,
differing only in where it lands.*

**The handoff's own framing was wrong and is corrected here.** It said `step` had two uses, the grid
relation and *an arc's actual traversal of a passage*. **Measured: book 1 does not use `step` for an
arc's traversal.** And the two files carrying this question were not asking the same one — this
handoff pointed at the horizontal, `NOTE-small-arcs-and-the-step-20260815.md` asks about the fall and
the climb, which is vertical. **They had been carried as one item.** *What that note asks is therefore
still open and is not closed by this ruling — it is a question about the health axis.*

**2. The lean and the temporary offset — RULED, and it replaces the 08-19 shape.**

**`[A]`:** *"the lean is a static adjustment to the fixation. integration is a temporary adjustment
which is connected with the amount of stress or lack of it for a person at some point in time."* And
separately: *"leans are our version of classical enneagram wings."*

**Both are offsets on the same circle. One is a constant; the other is a variable with an argument,
and the argument is present stress.** Any single reading of a person's angular position is the sum.

**This supersedes the 08-19 shape**, which had the lean as a reading at a moment and the direction as
the difference between two readings taken apart in time. **The old conclusion survives and its reason
does not:** the direction still cannot be a process, but for a simpler reason — nothing moves, there
is an offset that is larger under stress. *`[C]` flag, not developed: the advice to compare this month
against last year rather than today against yesterday was resting on the old reason and should be
looked at by whoever repairs the text.*

**Book 1's measurement appendix already had this, at L2463** — *the measured lean is trait plus
fluctuating state* — and it is the passage that should be cited when the ruling is written up.

**What it cost the classical comparison.** The book had three stated differences from the classical
system: the transit question, the wing-stability contrast, and adjacency. **Two were artifacts.**
Wings and leans are the same object, so there is no stability disagreement; and `[A]` supplies that
the classical arrows are *shaded toward and returning*, so there is no transit disagreement either.
**What is left is one disagreement appearing twice, and it is the same one both times: how many
neighbours a relation can have** — two for a classical wing, eight for a lean; two for the classical
arrows, more on the grid. *That wants saying where the reader meets the classical comparison.
Placement is an architecture question, not a doctrine one.*

**3. LEVEL 0 IS ABOLISHED — `[A]`, 2026-08-23. This is the largest of the three.**

**`[A]`:** *"the exit is the upper half of Level 1 - make it match riso."* And, decisively:
**"riso's self-actualization is our liberation."**

*How it arose.* The Level 1 note records `[A]`'s chart reading: Level 1 carries the basic fear and
carries self-actualization **in place of** a desire, with a single upward arrow from the basic desire
at Level 2 to self-actualization at Level 1, and self-actualization **above** the basic fear on the
same row — *like a half step higher*. **Book 1's arrow runs differently:** from Level 1 up and *out*,
onto Level 0. One arrow, two accounts of where it starts and where it lands.

**Why book 1's version fails.** Its argument for needing a rung above Level 1 is that Level 1 *still
retains a desire, and a desire, however refined, is still a rung*. **Self-actualization is not a
desire** — it stands where the desires stand on every other row and is not one. The premise fails, and
with it the need for anything above. **Level 0 was a rung invented to hold something the chart already
had a place for.**

**What it does *not* cost.** Liberation was never off the ladder because it was a different kind of
thing; it was off the ladder because the ladder had been drawn one rung short. **The identification of
this book's liberation with R&H's self-actualization stops being a correspondence and becomes an
identity** — the same thing under two names, not two schemes noticed to resemble each other.

**What it does cost — the impermanence result loses half its support.** The ruling that made the apex
a passage rather than a place argued that the deepening reaches the apex and the arising *has no rung
above to land on*, so it lands back in engagement: renewal, not residence — and on that basis
impermanence stopped being a conjecture and became structural. **The renewal survives**, because
there is still nothing above the top of Level 1 for the arising to land on, and the forbidding stands
(growth at every level must show the summit's shape in miniature). **What fails is *not a position*.**
That clause was earned by the apex being off the structure; on the chart it is a place on the top row,
drawn, with an arrow arriving at it. **So impermanence falls back on Ch 18's regress** — a maintained
state is a habit maintained by the habit of maintaining it, and that regress has no floor. That
argument is untouched and was always the stronger one. **The ruling should say so rather than quietly
keep the conclusion.**

**And it reaches the unruled overlap note.** Its identification of zero overlap with the balanced point
is untouched — that is an argument about the circle. **Its reconciliation is not:** *training can touch
zero overlap, it cannot hold it* had its whole force from there being a kind of thing that by
construction cannot be occupied. **That needs a new reason** — the regress, or the ordinary fact that
the two traces almost always overlap. Both are available; neither gives what the note claimed, which
was that the two are one kind of object. *Nothing was built on it, so this is a note to whoever takes
it up, not a repair.*

**A hazard named this session and worth carrying.** Three times in one day a claim about where this
book stands relative to Riso and Hudson turned out to rest on a characterization the model does not
support — the summit passage, the wing-stability contrast, and the transit claim. **All three in the
same direction: the book reaching for a comparison and taking the classical picture along with it.**
Every such claim in book 1 is unverified in the same way, and `[A]` alone can check them, with the
book open.

**A second hazard, same shape, different source.** Twice this session a resemblance recorded carefully
in one chapter was spent as a fact in a later one — the wing-scale clause, and the Level 1 ≈ Z−
identification, which the correspondence hedges (*not that each Level is a particular orientation*)
and which three later passages state flat. **Two of those three carry real weight**, using the
identification to argue about the top of the ladder. *`[C]`: this is the three-registers rule failing
at the seam between chapters rather than inside a sentence. Recorded, not developed.*

### Closed on 2026-08-21b — the `2f` session, six rulings

**The two scales are one shape at two sizes — RULED.** Put as a fork, *is beginning-middle-end three
moves or one move sliced into three*, `[A]` dissolved it: **"they are the same."** So the endeavor and
the thought are not two kinds of object described two ways, and book 1 already prints the conclusion —
*"One shape, three sizes."* **Book 1 Ch 5's *from eager beginning through chastened middle to ripened
letting-go* stands with no rewrite.** Naming a place and naming the move that arrives at it are the
same statement. **Costs nothing:** the ruling that the moves are fundamental and the places are where
fixations apply already says a node is where a passage stops. **Forbids:** nobody may treat the two
scales as two accounts needing reconciliation — the mistake that put *Fixation as a Stopped Arc* into
book 1. **One consequence not sought:** the definition *where a person habitually stops* was given a
companion clause saying what is stopped; on this ruling that is the same sentence from the other end,
so the definition cannot be quoted alone and be thin.

*Two `[C]` errors on the record here. `[C]` offered "three moves versus three places", which is not
the alternative the sentence poses — `[A]` supplied the count correction, "3 stations or 1 passage".
And `[C]` used the word* stations, *which is neither book 1's nor `[A]`'s;* passages *is book 1's word
for the moves, and the plain pair is "the three places" and "the three moves".*

**The memory claim — WITHHELD FROM THE TEXT, NOT WITHDRAWN.** `[A]`: *"let's withhold it"*, and on
being asked which of the two readings he meant, **"not printed."** *All memories are residues* stays
true in the reasoning and does not go into the book. **What survives untouched** is the work it was
doing: everything deposits, what varies is permanence, and permanence comes from the blindness loop.
Only the extra step is withheld — that what a person would call a memory *is* one of those deposits.

*What prompted it: `[A]` proposed that what previous thoughts have laid down is what Buddhism calls
volitional constructs, and asked for a check. **The check confirmed the identification and removed it
as support.** The term is two-sided — active,* "they construct the conditioned"; *passive,* "whatever
is formed by a combination of conditions", *glossed* "dispositions, mental imprint", *and the term
itself is* "that which has been put together". **`volitional` was withdrawn as a name because volition
is the output; that rejection was aimed at the active half, and `[A]`'s identification is with the
passive half — so the word stays rejected and the concept stands, with no conflict.** Two divergences
kept visible: the passive sense covers all conditioned things, body and world, which is far broader
than the model needs; and the tradition fuses constructing and constructed in one word where the model
has just ruled them apart, so **the book is more separated than the tradition and that is the
interesting half.** And it cut against the memory clause: early analysis assigns recognition to a
different factor, the one whose *"function is to make a sign as a condition for perceiving again that
'this is the same'"*. **UNCHECKED and flagged: later schools handle memory with seed-and-imprint
concepts that may cut the other way. Nothing rests on it.** Terminology stays out — `[A]`: *"i don't
want to insert the buddhist terminology"* — and book 1 already has the move, naming the tradition's
idea and explaining it in its own terms: *"Karma, on this reading, is nothing more than the carrier
seen with a long horizon."* **Sources were fetched, not recalled.**

**Weight and permanence are two variables — RULED.** The step that decides it is `[A]`'s, not `[C]`'s:
his two statements of 08-21 cannot both hold on one variable. *every thought has a residue but those
connected with a blindness loop are particularly permanent* and *not nothing. all memories are
residues. i meant nothing of emotional significance.* The second says an enthusiasm fixation's
deposits persist **and** carry no weight. **It holds both ways:** permanence without weight is the
ordinary case, what a person retains for life and feels nothing about; weight without permanence is
what completion produces. **What the blindness loop does is move both, by one mechanism — it prevents
completion**, so the arousal stays undischarged. *Particularly* permanent implies a scale, and the
loop is what moves a thing up it. **This is why the two look like one variable: the loop is the only
place anyone has been looking. Forbids:** no reading permanence off weight or weight off permanence,
and in particular no arguing that an enthusiasm fixation deposits little *because* what it deposits is
light — the lightness has its own cause, the desire was answered by the next pursuit.

**What is carried past detachment is NOT the neighbour trace — RULED.** `[A]`'s own statement of it:
**"fixation is there. endeavor arcs cycle. at the end of each there is a possibility of blindness."**
The fixation is standing and **sets how large the possibility is**; each endeavor's ending is an
**occasion** on which it is taken or not. A likelihood and an occasion are different in kind. **Why it
matters:** identifying them makes a position nothing but the sum of its arcs, which is the account set
aside when `[A]` ruled that the fixation causes the stopping rather than the reverse. **`[C]`'s
identification of the two, at `NOTE-overlap-and-truthfulness-20260815b.md` §1.3, is withdrawn.**

*What book 1 does have, and it is the part `[C]` got right: the overlap simply is the two neighbour
traces both present at once —* "Two pulls reach a person in the middle of the Z arc — the wariness
left over from caution, and the wanting that draws toward comfort" *named without the word, and*
"a motivational residue from its neighbor" *with it. That is book 1's own, and it is the standing
thing. The arriving anxiety is not it.*

**The carrying is neither a switch nor a width — RULED.** `[A]`: *"i'd like to say neither, if
possible."* **It is possible at no cost.** Part 3 does not need it — the quantity Part 3 reads on its
third object is *how much of a realm registers*, separately ruled a width; the carrying is a cause of
that, not the quantity. Nothing measures it — `[A]` has phrased it both ways himself, *the width of
the overlap* on 08-02 and carried-or-let-go on 08-18. And degrees of blindness are already explained
by the registering width and the fixation's position. **Forbids:** no sentence may turn on the
carrying being all-or-nothing, and none may give it a magnitude. **Text consequence at §5.**

**What decides what arises — `[A]` ANSWERED, and the clause stays cut.** *"the fixation affects what
arises. also immediate past thoughts, memories, inputs from the senses, current emotional state."*
Five contributors, unranked, **and the fixation is still one of them.** So **the retraction removed
the exclusivity, not the influence** — the cut clause said the fixation *selects the population before
any single arc begins*, which is exclusive and prior; *affects* is neither. **The clause failed by
being exclusive, not by being false**, and the record should stop reading as though the fixation had
been removed from the picture. **Two measured supports:** book 1 L1760 already leaves the room — the
next thought arises *"shaped, colored, **largely** set in motion by what just completed"*, so a single
source was never claimed — and sense input is not an import, since book 1's L431 inventory of the
psychic realm already includes *"Sensory input filtered through a person's understanding and
experience."* **One place noted and not a defect:** L1760 names only the immediately preceding
thought, and `[A]` has twice said many; the sentence says *largely*, so it is incomplete rather than
wrong, and that is where a fuller account would go if one is ever wanted. **Forbids:** no
single-source account of what arises. **`[C]`'s proposal that the fixation reaches arisings only
through what previous endeavors deposited is superseded and recorded as wrong** — tighter than what
`[A]` said. Sharpening rule.

**Arc occupancy — GONE, NOT ANSWERED.** With the numeric lean values retired (§5) there is no midpoint
to occupy and the question cannot be posed. *Two things measured on the way, both corrections to this
file: the record said the midpoint has no name, and in fact both names apply and denote one position —
doubly determined, not undetermined. And the record said Opposite needs a quarter; it needs the two
leans to be complementary, any pair summing to half the gap.* **The grid's wrap never depended on
occupancy** — the wrap is a fact about the ordering, and an ordering is unbroken whether or not anyone
stands between its terms. **`[A]`'s separate flag that caution's forward lean may never reach
detachment's backward one — that the circle may not be continuous — is untouched and stays open.**

### Level 1, and the figure — reopened and closed the same hour, 2026-08-21b

**THE LEVEL 1 MATERIAL NOW HAS ITS OWN FILE: `NOTE-level-1-and-the-summit-20260821b.md`. Read it
before anything that touches the top of the health axis.** It was cut at `[A]`'s instruction after he
observed that the next session would not know about it — the material had reached the record only as
verbatim entries in `AUTHOR-RECORD.md`, **with nothing pointing at them.** *That is the same failure
as the 08-19 loss, caught this time by the author rather than by a check.* What follows is the
summary; **the note is citable and this is not.**

**What the note carries, in one line each.** Level 1 holds the basic fear **and** self-actualization
in place of a desire, and self-actualization sits **higher than the fear on the same row** — `[A]`:
*"like a half step higher"* — so **Level 1 has internal structure and is not one position.** The first
two are book 1's own, in Appendix G and Ch 16; **the internal half-step is in neither book and is
unruled.** `[A]`: *"riso's top level is not freedom"* — the basic fear is still present there and is
dissolved by the upward step, not by arriving. The note also carries the within-row order,
**desire → attitude → behavior → fear**, and the basic desire as a two-armed turning point that R&H's
own text names.

**A reading rule that comes out of it and should not be lost:** for what Level 1 contains, **go to
Appendix G and Ch 16, never to Ch 15's one-line level summary.** Reading the summary line is what put
`[C]` wrong on this.

### The figure — reopened and closed the same hour, 2026-08-21b

**`[A]` floated a nine-arrow reading of the R&H chart, then retracted it: "i was wrong."** The ruling
that voided the spiral debt is **confirmed** — one upward arrow, basic desire at Level 2 to
self-actualization at Level 1, none below. **The four files quoting that description need no repair.**

**The retraction arrived with the fullest description of the figure the project has**, and it is in
`AUTHOR-RECORD.md` verbatim. Four things in it the ruling does not have: Level 1 carries the basic
fear and self-actualization **in place of** a desire; the within-row order is **desire → attitude →
behavior → fear**, not desire → fear; **the basic desire has two arrows out** and R&H's own text calls
it *"the 'turning point' at the basic desire at level 2"*; and the circuit runs from the basic fear at
Level 1 back to self-actualization at Level 1 — `[A]`: *"like a half step higher."*

**PARKED, AND DELIBERATELY NOT SETTLED.** Book 1 puts the fork at the **fear** — *"F(1), the basic
fear, is a fork: answered by D(1) it is released… and answered instead by the securing-desire D(2) it
drives the descent"*, and *"the two desires at the top of the structure point opposite ways: D(1) out
of it, D(2) down into it."* The figure puts the turning point at the **basic desire**, which on that
description points both ways. Asked whether the divergence was meant, `[A]`: *"i was careless. riso's
chart confused me. what i entered is what is in the book."* **Not pressed further, on three grounds:**
it is the item answered and withdrawn more often than anything in the record, twice in one hour; and
**measured — no book 1 or book 2 text quotes the figure description, only four working files** — so no
drafted prose is wrong while it sits. **It wants the book open and an unhurried hour, and it should
not be settled at the end of a doctrine session.**

*Recorded and not developed: the ruling's clause* "'Spiral' in their prose is a metaphor for repeated
traversal, not a picture" *sits against the sentence `[A]` supplied —* "follow the spiral up against
the arrows" — *where* the arrows *are the drawn ones. That is closer to the ruling's own* "the shape
is latent in the chart" *than to a loose metaphor. One clause may want softening; nothing else does.*

### Closed on 2026-08-21 — the endeavor relocation and what fell out of it

**Full account in `NOTE-fixations-arcs-and-the-two-scales-20260821.md`. Summarised here so a reader
of this file alone is not misled about what is still open; the note is citable and this is not.**

- **What sticks is the endeavor, not the thought arc.** `[A]`. The stalling question had no conflict
  in it — thought arcs run without stopping *and* something sticks, because the two concern different
  objects. Book 1's own section announces the thought scale and then describes endeavors, five uses of
  *pursuit* in four paragraphs, which is where the stopped arc came from.
- **Thoughts deposit; endeavors stick.** Two scales, two jobs. `[A]` narrowed the first half: the
  depositing does not need the arc, though the arc runs. **Demoted, not denied.**
- **All arcs complete, satisfactorily or not; every thought leaves something; what is left where a
  blindness loop runs is particularly permanent.** So not-closing is not a third state beside
  completing and stacking.
- **The definition: where a person habitually stops** — whether in an endeavor or not. What they have
  in common is that going forward is uncomfortable and going back is not wanted.
- **An enthusiasm fixation leaves nothing of emotional significance**, and *all memories are
  residues*, so the earlier *leaves nothing* was about weight rather than deposit.
- **The blindness loop is a detachment phenomenon and was never at caution.** Caution recoils from the
  threat, not from its own recoiling.
- **Abandonment is not a route into the loop; jumped-over fear is.** So the prediction is about the
  route, not about people, and a Three falls by the fear it does not process.
- **The loop cannot reach what stays unconscious**, because detachment's avoidance is aimed at what
  stirs. **This gives the conscious/unconscious distinction the footing it was owed** — it decides
  whether the loop can fire at all.
- **The blind end is a failure of conscious availability, not of registration** — which is a repair to
  both books, at §5, and carries a cost the note names.
- **The dialectic is out.** Considered and dropped: the formula is not Hegel's, it breaks at the third
  passage, and the book already carries two parallel triads.
- **The sixty-second claim is kept**, with its scope stated — the reader checks the shape and the
  competences, not the emotional life. `[A]` ruled the emotional tone the essential mark, loosely, so
  thought arcs are attenuated instances.

### Closed on the 08-20 `2d` set

**Fixations do not stall arcs; they characterize them — `[A]`, and it takes the stopping out of the
middle of the model.** His account is verbatim in `AUTHOR-RECORD.md` and **that is what to work from**;
what follows is a summary and is not citable as him. Arcs arise at detachment and end at detachment. At
an enthusiasm fixation the desire is satisfied or it is not, and either way the arc runs on and a new
one arises, continuing with the same object or finding another. At caution the problem is solved or it
is not; if it is not, the arc reaches detachment carrying anxiety. At detachment the anxiety is dropped
and forgotten, or it makes more blindness — and the blindness is what diminishes awareness and, with
it, the person's functioning. **Conscious arcs are suspended when another arc is needed and resume when
it, or a stack of them, completes. Unconscious arcs do not stop at all. Neither kind stalls.** The long
account is of the unconscious ones.

*What it reverses.* A fixation is defined as the next passage failing to start, and book 1's account of
resting says the same thing **at the smallest scale**, so it cannot be rescued by reading it as a claim
about a character. Both go. So do the two sentences at §5, and so does the half of the
intentional-versus-reactive test that sorted stops into stalls.

*What it follows from.* It is the next step after the ruling that the fixation is prior and that arcs
express the place rather than constituting it. **Characterize is a short step from express.** The
difference is that that ruling left the stopping in place and reversed only its cause; this removes the
stopping.

*What it does NOT settle — four things, not one.* Whether arcs stall ever; what *characterize* means
precisely enough to forbid something; whether the conscious/unconscious distinction has a footing of
its own; and what replaces the definition. **§0 item 7 carries them and they are the next job.**

**Arcs arise at detachment and end at detachment — CLOSED, and derived rather than stipulated.** `[A]`
first wrote *end at A* and corrected it the same day to *end at Z*. The objection put to it was that
*by definition* might name a choice of where to cut a loop rather than a claim, since a loop has no
privileged start. **A loop has none; this one is not a loop at that point.** Book 1, Ch 18 L1790:

> A to B and B to Z are transitions — something persists and is transformed. Z to A, seen from the psychic realm, is not a transition at all: an ending, then an arising with no antecedent moment. At the smallest scale, that is every thought's death and the next thought's birth.

and it closes *"the cycle does not close its last arc; it ends, and starts."* Something persists across
the other two passages, so no arc could end at either. **The cut is forced, and it was in print before
the question was asked.**

*One consequence.* An enthusiasm fixation and a caution fixation sit **inside** an arc; a detachment
fixation sits at the **seam between two**. That is where `[A]`'s own remedies already put them — the
first two swallow an unpleasantness in the middle of something already under way, the third has to find
motivation to start — and where the structural asymmetry found from the arc side put them. **The three
routes are not independent of each other. Never present them as three findings.**

**An enthusiasm fixation leaves nothing behind — `[A]`, 08-20: `i think not`**, citing an early
session's observation that when enthusiasm's attempt fails it simply tries another thing. **This is
already ruled in another vocabulary** — the account of how the three orientations fail has enthusiasm
*starving*, nothing directed at what it will not take up, against caution *substituting* something for
what was needed. One fact in two vocabularies, and therefore **not two supports**. What it gives
*characterize*, which needed to forbid something: **for enthusiasm it forbids accumulation.** Its arcs
show it in what they do and never in what they leave. *Where this leads is the reserved
depth-and-threshold question at §0 item 8. It was deliberately not followed there.*

**What a single arc shows, and a correction to `[C]`.** `[C]` had a single arc failing to identify a
realm's place because stress and ease displace where it stops. **`[A]`: they move it only slightly**,
so displacement was the wrong reason; the reason is that nothing about one arc says in advance which
kind of stop is being watched. *Overtaken in part by the ruling above — there are no stalls — but the
correction stands, and so does what it buys: where an arc comes out is a tight fact, not a smeared
one.*

### Closed on 08-20

**The descent's direction — CLOSED.** The winding-structure ruling (R6) had the climb as a sighted
forward turn per layer and the descent as a **blind backward turn** per layer. The 08-19 ruling that
nothing runs backward made that a live conflict rather than a parked one. **`[A]`, 08-20: the descent
is a blind forward turn.** Both are forward turns; what makes one a descent is that the seam is
crossed blacked out rather than sighted.

*Why it cost nothing.* Every part of R6 was checked against the change and none of them depended on
direction. What it forbids — no fully witnessed level drop, no seeing reported mid-collapse, the four
landmarks never again read as a motion — says nothing about direction. Its law for the seam is stated
in terms of the extremes of registering: full registering crosses sighted (the exit), zero registering
crosses in blackout (the lapse), partial registering is what the trap holds. **That is what separated
descent from climb all along; direction was never doing the work.** The Z0 crossing still recurs
angularly once per turn at a lower depth each time — a forward turn passes it just as often. The
non-uniform slope is untouched. So is the unnaming.

*What survives elsewhere.* The small-arcs note's falling amalgam survives intact: many small blind
turns, micro-lapses rather than one collapse, each still forbidden from being witnessed — now blind
**forward** turns. And book 2's drafted Part 2 sentence that disintegration runs the same lines
backward **does not move**: that is the arrows in the observation register, governed by R12, and it
is not the winding structure.

**What a level is made of — CLOSED, `[C]` ruling on `[A]`'s judgment-handoff.** `[A]`, 08-20:
*"there must be many descents per level. the levels are just markers that one can recognize."* He
believed this was the same claim as the direction ruling. **It is a second and separate claim** and
was reported as such; he then handed the rule-or-hold judgment over, noting that refinements
sometimes break rules and that not ruling makes the job harder.

**Ruled: a level is many turns. The quantum of depth is the turn. The levels are recognition markers,
not units of the structure.**

*Reasons given, so it can be overturned on the reasoning rather than on the conclusion.* It was
derived independently before `[A]` said it — the small-arcs note gets it from R6's own naming
retraction, since one step per revolution is exactly the structure, so a fall amalgamated from
smaller pieces must be an amalgam of whole turns and a level is therefore many of them. It costs R6
nothing. It forbids something: no tight one-turn-to-one-level mapping, and no treating levels as
units. And it converts R2's stipulated looseness of the middle landmarks into a consequence — they
are loose because they are recognition points on a finer scale.

*It also disposes of the Riso–Hudson problem rather than managing it.* Their levels are landmarks;
the model's quantum is the turn. Experiencing the fear at one's level and every fear above it is
simply a great many turns. No contradiction left to reconcile.

**Scope, stated to keep it narrow.** It fixes **no number** of turns per level. And it is **not** a
mechanism joining the health axis to the circle — that is the depth-and-threshold question, §0
item 7, and it stays reserved.

**Whether the fixation causes the stopping or the stopping the fixation — CLOSED PROVISIONALLY.**
`[A]`, 08-20: **the fixation causes the stopping, not the reverse**, at least not directly. Ruled on
his own words *"you can take it as a rule for now"* — carried as provisional, and the wording should
stay provisional until he removes the qualifier.

*What it does.* It dissolves the aggregate's incoherence rather than resolving it. Building a place
out of arcs makes the place something arrived at, which collides with book 1 calling the realm-stances
*two relatively free ways of facing the world*. Turn the causation round and there is no collision:
**arcs express the place rather than constituting it**, and book 1's line stands untouched. It also
turns book 1's *the fixation selects the population of arisings before any single arc begins* from a
hazard for the aggregate into the ordinary case, since the fixation is what is there first. And it
leaves the arcs worth reading, which is what the whole business of reading a person off their endings
is for.

### Open — the doctrine questions, in the order §0 item 7 sets

**The aggregate — OPEN, and re-specified rather than answered.** The brief's loose form was `[C]`'s
*"a realm's place on the Z− to Z+ stretch is the aggregate of where its arcs are resting"*, to which
`[A]` said *"i didn't say that but it sounds good"* — so the loose form is the claim, and aggregation
is one candidate among accumulation, frequency of completion, depth of frozen context, and the
current arc's position averaged over time.

**Two MEASURED corrections on 08-20, and both remove supports the brief leaned on.**

- Book 1 L1546 — *"not a stance freely taken but a place arrived at, the settled residue of how the
  fixation has been handled over time"* — was read by the brief as the self-ward twin of the
  proposal. **It is drawing a contrast, not offering a twin.** The sentence before it calls the two
  realm-stances alike, *"two relatively free ways of facing the world"*, and says the health-axis
  place is *"a different kind of thing"*. The brief used a sentence whose job is to separate them to
  argue that they are alike.
- Book 1 L1476's nesting passage — a stopped arc persisting as unresolved context, arcs arising
  within it stopping too, arcs frozen inside arcs — was preferred over averaging as the mechanism by
  which momentary becomes habitual. **The paragraph names its own purpose in the next clause:** it is
  *"the connection that ties the orientation fixations directly to the health axis."* Nesting is book
  1's account of **depth**. It answers how far down, not where on the circle.

**So both supports were about the vertical while the question is about the angular.** Neither
correction kills the proposal; between them they remove its cover and show what it would have cost.
**And `[A]`'s ruling above is what it turns into:** since the fixation is prior, the question is no
longer *what is the place made of* but **how do the arcs show it**. That is what the next doctrine
session takes.

*Two constraints the question inherits.* The population is well-defined — an arc cannot be mixed,
because a basic motivation is one thing. And **only stalls have a location**: completions close the
loop and suspensions land wherever the block fell.

**The residue mechanism — OPEN.** Whether what previous thoughts have laid down is what shapes the
next arc. `[A]`, 08-18: **arcs arise from residues left by previous arcs**, memories being *probably*
residues themselves. Ch 7 already says the next thought arises conditioned by the one that ended, so
what is new is naming the conditioner. **What it adds beyond book 1:** book 1's nesting covers only
**stopped** arcs, while the ask is about what a **completed** arc leaves, and no book 1 passage
covers that. **The regress — what sources the first arc — is answered by `[A]`: feelings feed in
too**, so the chain is open and needs no first term. **Do not take this before the item above:** it
is a mechanism for a formula whose subject has just been re-specified.

*The memory clause, the switch-or-width question and arc occupancy were all here and are now closed —
see the 08-21b block above. Their reasoning is there, not repeated.*

**R11's fall-account repair — OPEN, and R11 says so itself. THIS IS THE MAIN DOCTRINE QUESTION LEFT.** R2's full-axis collapse *"available in
full only to the 9"* rested on the arc count R11 superseded. It may survive on R2's other leg, the
engaged realm as witness, but that is a claim about *unwitnessed* collapse rather than about
availability.

**What a step is made of — CLOSED 2026-08-23.** See *Closed on 2026-08-23* above. **Two corrections to
what this entry used to say**, kept because a successor may meet the old framing in a quoted note:
book 1 does **not** use `step` for an arc's traversal, and this question and
`NOTE-small-arcs-and-the-step-20260815.md` are **not** the same question — that note asks about the
fall and the climb, which is the health axis. **That note's question is still open.** *Ch 10's
`a Nine integrates toward the Seven or the Two by a single step` survives: on the ruling that is the
grid sense, constructing the relation, and the person is not the thing stepping.*

**Does depth set the overwhelm threshold? — OPEN, RESERVED, AND ITS OWN SESSION.** The natural
extension of the nothing-runs-backward ruling is that a person sunk further into their fixation
tolerates less, so overwhelm arrives sooner in every arc and the disintegration-ward appearance is
more of the time. **That would give the health axis a mechanical connection to the circle, and the
ruled architecture separates the arrows from the Levels structurally.** Book 1 leaves exactly this
gap open: *"Direction and depth are independent as positions"* forbids reading one off the other **at
a moment** and says nothing about **rate**, which is where `[A]`'s expectation lives.

`[A]` added to this on 08-20 and it should go to that session intact: *falling along the axis is
related to self-maintaining blindness, and that happens at the Z crossing regardless of fixation — so
the different fixations may be irrelevant, and it may be the overload factor that determines the
blindness of the crossing.* **Whether that works in both realms is the open half.** It was recorded
and deliberately not developed.

### Ruled earlier and carried, because later work leans on them

**How an arc gets its realm — CLOSED 08-19.** **An arc's realm is set by which realm's rules its
concern answers to, with motivation as the way to identify the concern. Motivation and realm always
match.** The realm of the contemplated action does not matter, and neither do the principles the
person is applying, correct or incorrect.

`[A]`'s worked examples: checking a fence post because the neighbour might think you careless is a
psychic arc, because what drives it is psychic. *"The cows are getting loose, I'll lose my
livelihood"* is a physical arc, because it is about the rules of the physical realm.

**Two rule-relations are kept apart and both are needed.** The rules the matter actually runs by fix
the realm. The rules the person applies can be the wrong ones, and that mismatch is the critical
confusion. If principles typed the arc, the critical confusion could not be stated at all — every arc
would sit by definition in the realm whose rules it was using, and magical thinking would be
impossible rather than common. **Book 1 already says this**, Ch 7's "Where thinking lives":

> But engagement is classified by its object and its principles, not by where the processing occurs.

The *all arcs are psychic* objection dissolves rather than needing a defence: it defines the psychic
realm as the experienced, and book 1 defines it by having no outside.

**The kinds of stop — CLOSED 08-19.** **A suspension is intentional. A stall is reactive.** That is
the criterion; the fixed stopping location is what being reactive produces, not the test itself.
Suspensions happen only during intentional behavior, so overwhelm cannot produce one. **How one
becomes the other (`[A]`):** when suspensions become too deep one loses track, and those that cannot
be completed cause helplessness every time that stage is reached. Waiting is something a person does;
helplessness is something that happens to them.

**Nothing runs backward — CLOSED 08-19, and it replaces a mechanism.** Under stress, forward arcs
encounter overwhelm sooner; under favorable conditions, later. Pushing farther beyond a fixation is
itself stressful, so it is less tolerated when a person is already stressed. Tested against book 1's
three stress descriptions and it holds: on a three-cycle, one step backward and two steps forward land
in the same place, so the destinations book 1 recorded are correct and only the route was wrong.
**It explains something book 1 only asserts** — each disintegrated arrival is a spoiled version of
that orientation because the passage before it was skipped rather than lived. **And it gives
integration for free:** favorable conditions, overwhelm later, examination completes, detachment
entered seeing. Two directions become one process with a threshold, and stress moves the threshold.

*One thing this ruling owes a look, not a rewrite.* Book 1 L590: *"These cycles describe actual
psychological processes, not theoretical constructs"*, where *these cycles* reads as integration and
disintegration. Its supporting sentences are about the orientations arising in lived experience, so
it may survive as a claim about the arc rather than about the two directions. **It cannot be assumed.**
Ch 5's title carries the same weight.

**Integration and disintegration name observations, not processes — CLOSED 08-19.** **A lean is
observable immediately, though more subtle than the basic fixation; integration and disintegration
are what is observed in the same person over time.** So a lean is a reading at a moment and a
direction is the difference between two readings — a derivative, which is why it cannot be a process.
Only the arcs are a process. **This converges with R12 from the other side:** R12 says the pair holds
and nothing moves, and if the directions are observations rather than movements, "nothing moves" stops
being a caution the drafter must enforce against the natural reading and becomes what the account
says.

*It also resolves an oddity in book 1 L660*, which runs two things together in one paragraph:
*"which way is easier to read than where you rest"* is about the lean, read now, while *"compare this
month against last year"* is the advice for detecting the change. Nothing marks the shift.

**What previous thoughts have laid down — CLOSED 08-18.** The standing thing many arcs have laid down
is **"what previous thoughts have laid down."** `laid down` is book 1's own verb for the operation.
Four candidates rejected on measured grounds: `residue` (already the neighbour-trace sense; stretching
it would make *Z0 is the absence of residue* also deny that a person at pure detachment has anything
accumulated), `habit` (rejected on **depth**, not timescale — book 1 defines a habit as laid down
*beneath understanding*, which near-term leavings need not be), `karma` (right, and right where book 1
already has it — the correspondence chapters, ten uses, none in book 2), and `accumulated past
thoughts`, `[A]`'s own candidate (locates persistence in the thoughts, which is the memory claim, and
would have installed it without anyone ruling it). `volitional` was raised and withdrawn: volition is
the **output** of the constructions and this question is about the **inputs**.

**`residue` is therefore not extended to the inputs.** It keeps the neighbour-trace sense.

**This was the fourth time the book came out with no noun**, after the helix, the Z object and the
gradient. **At four it is a working rule rather than four decisions:** where every candidate collides,
state the doctrine in prose and leave the thing unnamed. R6's precedent is the model — *helix* retired,
*spiral staircase* withdrawn the same day, the structure left with no name.

**Blindness is conditional — CLOSED 08-18.** Blindness depends on whether the aversion is carried
across. So **blindness cannot be definitional of Z+**, since a conditional outcome cannot define the
pole it appears at, and the Z+ naming question closes on description rather than label. **The rest of
the overlap note's §1 is untouched** — Z0 as an ideal, Ch 18's choicelessness regress, Level 0 and
R5.3's sighted exit remain Part 3's and unruled. *Amended 2026-08-23: **Level 0 is now abolished** and
the note's reconciliation loses the support it took from it — see the 08-23 block above. The identity
argument in the note is unaffected.*

**Position or exercise — CLOSED 08-18, dissolved rather than chosen.** `[A]`: volition and fixation
may not be different things. Book 1 already has it, in the habit section: what a person does about
what registers runs from the involuntary to the chosen, and **a choice repeated often enough stops
being made and sinks back toward the involuntary end**. So a fixation is a choice that has finished
that trip — strategic in what it contains, automatic in how it runs. **The Three is protected by
phrasing, not by argument:** how much registers is a fact about a realm, and a fixation in detachment
is one route to a realm registering little; the chapter never says a person is *doing* detachment in a
realm, which is the phrasing that would hand a Three a vantage point.

**Fixations do not step — CLOSED 08-18.** R12 settles it for the arrows. What steps is the process
arc, and a fixation is where the stepping stops — **defined by a step not taken**, which is why Ch 7
can say arcs rest without anything moving.

**What resting means — CLOSED 08-19, and book 1 had it.** Ch 15, L1460: thoughts rest in the impulse
(wanting without proceeding to weigh), in examination (weighing without arriving), or in resolution
(already done with the matter) — *one habitual stopping point per realm* — and once stopped, the next
thoughts arise inside that unfinished context. **So resting is a passage failing to start, which is R4
word for word.**

**The plain-reading problem dissolves on R3's own asymmetry.** *A completed thought ends at detachment,
so everyone rests there* fails because ending at detachment **completes** the caution-to-detachment
transformation, while resting at detachment is the **next** passage — the ending-and-arising — failing
to start. Two different passages wearing one node's name, which is why that case looked like a puzzle
and the other two did not.

**A structural asymmetry nothing had stated:** an enthusiasm fixation and a caution fixation fail
**within** the arc; a detachment fixation fails at the **join** between arcs. Consistent with R3,
which already makes the ending-and-arising different in kind. **It was independently confirmed on
08-20** from `[A]`'s remedies — see §9.

**R11's decoupling — HOUSED 08-18.** It opens Ch 11's notation section, unlabelled: arc positions are
*instances* of the orientation they belong to, and B− is a way of being cautious rather than a fourth
thing standing beside caution. The notation's three uses are **not** enumerated there, on R11a's own
drafting rule. **The placement question is closed; the fall-account repair is not.**

**The Ch 11 bundle — CLOSED 08-18, kept.** Both subjects stay in one chapter, because R11's decoupling
housed at the head is what makes the bundle satisfy R11a. **Conditional, as ruled:** it comes back
into question if the chapter grows.

**Ch 11's noun — CLOSED 08-18. No noun.** The Z− to Z+ object is not named; `instances` is used where
grammar forces a noun, and the content is carried by *how much of the realm registers*. Rejected, each
on a checkable ground: `arc`, `range`, `stretch`, `gradient`, `currency`, `spectrum`, `intra-Z
transition`, `intra-Z discontinuity`, `trans-Z break`, `intra-Z crossing`. **The same treatment was
applied to book 1's involuntary-to-chosen `gradient`.**

**`blindness` as name or description — SETTLED 08-18, description.** A conditional outcome cannot be
definitional of the pole it occurs at. Ch 11 describes both ends and labels neither; `blind` survives
as an ordinary adjective. **Not ruled — `[C]` took it, and it is one edit to reverse.**

### Open — text, figures and bookkeeping

**Is `tools` a kind of work, or an interruption any session may take? — STILL WANTS `[A]`, raised
2026-08-24 and not answered.** §0's numbered list names kinds of work and the slots never advance.
**08-24 was not any of them**: it fixed two tools, added two subcommands, repaired the record and
re-cut the set, and touched no doctrine and no text. **`[C]` has NOT minted it** — creating a job kind
is `[A]`'s to do, and a kind nobody assigns is worse than no kind. *The argument for: a tools session
has a distinct disqualification profile — 08-24 read the author record and cannot draft — and that is
exactly what §1.1's rows exist to encode. The argument against: tool defects surface inside other work
and waiting for a session to be assigned to them is how these two sat unfixed from 08-21.*

**The same question about `handoff` WAS answered, on 2026-08-26: *"you are a handoff session."*** So
**handoff is §0 item 9**, and `tools` takes **10** if it is ever minted. *What made the second asking
different is that a second instance was in hand — a session doing work that fits no row, for the
second time in three days. Recorded because it is the argument to use if `tools` comes back.*

**Writer 2 on B and volition.** Ch 4 has B *"arrived at deliberately"* where A and Z are passive. He
is right about the text. **Ch 7 makes it slightly worse.** A reply is owed and it decides whether Ch 4
is repaired or defended.

**The eighth R10 site** — the Four's *"a stepped-back orientation does not track."* `[C]` recommends
leaving it; it reads as a claim about detachment as such.

**Two Ch 5 sentences.** The Three's *"no detachment in either realm"* and the Nine's *"seeing twice
over."* Ch 11 was written so the Three's sentence stands: a Three's realms have a registering level
but no position on the detachment span, since there is no instance of detachment to be an instance of.
**`[C]`: the Three's may need no repair at all. The Nine's is untested.**

**Book 1's Ch 9 L963 is false on the model's own convention** — *"Someone can be ahead of you in that
sense while you are, by the same token, ahead of them from where they stand looking back around the
circle."* Under one forward step, if X is one step ahead of Y then Y is one step behind; two steps
forward is one step back. The claim that survives is the three-person loop, which the next paragraph
states correctly. **Book 2's Ch 9 drops the sentence — `[A]`, 08-17.** The repair to book 1 is unruled
and belongs to job 3.

**Ch 11's ending reverses book 1's.** Book 1 closes on where the two systems disagree; Ch 11 closes on
volition, with the disagreement moved up to end the wings thread. **Deliberate, and it wants `[A]`.**
Two smaller ones: the Z0 paragraph is the longest in the chapter and could lose a third, and the
opening drops book 1's overview framing entirely.

**A review pass over Ch 3–5 for convention drift.** The missing rules before Ch 4 and Ch 5 are
repaired, but a chapter written without one convention may be missing others. **`[C]`: a review job,
not a repair job, and not urgent.** *Only defects touch text* is the whole permission needed.

**Two figures the master does not carry.** `wraparound-grid.svg` was offered to Ch 10 *if the diagonal
reading is wanted* and **was not carried, `[C]` 08-18** — if it belongs anywhere it is Ch 6.
**`[A]`'s call, either way.** And `orientation-cycles.svg` — **HALF SETTLED, `[A]` 2026-08-24: *"it's just absent from book 2."***
**It is NOT retired.** It is live in book 1 at L554 with its caption, and `BOOK1-INDEX-20260815.md`
already ruled that caption to be book 1 doctrine rather than a stray, on Ch 11's Z−/Z+ side placement
joined to the cycle at L1131. *Measured 08-24: book 1 carries ten image references across eight
files; book 2's master carries five, and this is the one book 1 has that book 2 never picked up.*
**What is still open is only whether book 2's Ch 7 wants it**, since it sits inside the span Ch 7 was
drafted from. **`[A]`'s call, and it is a small one.** *Recorded because a `[C]` reading it fresh
will otherwise see an unused figure and re-raise the retired question, which is what happened on
08-24 — and retiring it would put the caption's doctrine in play, which is a much larger question
than the figure.*

**What Part 3's sequence is made of — NEW 08-20, and it goes to job 6.** Part 3 is organized around
the Levels. The 08-20 ruling makes the Levels recognition markers rather than units, with the turn as
the actual quantum. So: **does Part 3 sequence by the Levels or by the turn?** By the Levels keeps
everything a reader can recognize and name and connects to Riso and Hudson, at the cost of a running
order made of markers. By the turn is true to the mechanism, but a turn is not recognizable from the
inside and cannot be counted, so a reader cannot be told where they are. **A third possibility is that
it is not a conflict:** sequence by the markers, mechanism by the turn — which is what book 1 already
does with the four landmarks, keeping them as coloring while ruling the motion elsewhere.

**`[A]`, 08-20, said and explicitly not decided:** he takes this to be a question of presentation, not
of fact. **Part 3 is not drafted, so this is a constraint on the architecture job rather than damage
to existing text.**

**The `cycle` vocabulary question — recorded 08-19, not acted on, and it is architecture-level.**
`cycle` does three jobs in book 1: the closed **ordering** of the orientations (L550, and the grid
sections at L822–838, where each axis cycle being unbroken is what makes the edges wrap); the
**direction** of a person's movement (L598); and a **traversal** of the ordering. `[A]` asked whether
"orientation cycle" should become "the orientations". **`[C]` recommendation, not ruled:** keep it for
the ordering, since the closure is load-bearing and a fixation needs a closed ordering to have a
position on at all; name the traversals separately — arc at the thought scale, integration and
disintegration at the character scale. **`[A]` then observed** that fixations do not need the ordering
but the leans do, so the cycle is not required by Part 1's account of the orientations and only becomes
load-bearing later. **L586 supplies what the ordering is for:** the same shape governs the excursions
of orientation fixations and all completing arcs. **The architecture is live; this was not acted on.**

**The residue vocabulary, and a MEASURED correction to the arcs-and-position brief.** The brief's
vocabulary table gives `residue` three senses. Its middle row says it also means *unresolved context,
what a stopped arc leaves*, and cites two lines of book 1. **The word appears at neither.** Book 1
calls that thing *unresolved context* and never calls it residue. The concept is real and the row
describes it correctly; what is wrong is filing it as a third sense. **So the word pulls two ways, not
three**, and book 1 had already solved the third case by choosing a different phrase — which means the
08-18 ruling follows a precedent rather than rescuing an overloaded term.

*The 08-18 session initially called this finding load-bearing. It is not*, and it took three exchanges
and two pushes from `[A]` to retract. Recorded because the overstatement is the instructive part.
**The larger point stands separately:** the section is headed MEASURED and two of its three citations
do not survive a check.

**Session names collide the way filenames do.** `draft-10-11` names both the 08-17b salvage session
and the 08-18 drafting session — the same shape as THE BRANCH, one level down, from the same cause: a
name minted from the job rather than from the work. **The fix is at §7: a session takes its name from
the manifest's `--label`.** Where a session name appears in a file it still needs a date.

**Whether the filename convention should carry a hash.** `[C]`, offered not recommended: dates
collide, as THE BRANCH shows they did; a short content hash cannot. The cost is ugly names and a
rename on every edit. **`[A]`'s call.**

**A declared count is worth having and is not sufficient.** Two copies of `HANDOFF-20260816c.md` were
once recorded as differing in exactly one line, one declaring 3,603 words and the other 3,504, with
both measuring 3,504. **Both were re-measured 08-18 under the canonical count and give 2,755 and
2,933** — 178 words apart, and neither near 3,504. They do not differ by one line: line 24 gains a
sentence, and a whole §0 section is replaced, nineteen lines by thirty-three. **So the anecdote that
taught this project to distrust its own version lines was itself a misreading.** What the item
concludes still stands on its own feet, and so does the rule that follows from it: a file cannot carry
its own md5, since writing the hash in changes the hash. The count goes in the version line; the hash
goes in the set manifest, which is the only place it can be true.

**`wc -w` is locale-dependent, and this is settled.** In the C locale `wc` does not count a
whitespace-delimited token holding no ASCII printable character, and a standalone em dash between
spaces is exactly that. These files are full of them; under `C.UTF-8` each counts as a word and the
figure rises two to three percent. **`LC_ALL=C wc -w` is the measure for every declared count and
every manifest.** It is confirmed, not guessed: under it every count this project has ever recorded
reproduces exactly — the architecture at 3,246, book 1 at 56,260, the rulings at 6,408, `VERIFY` at
3,375, the book 1 index at 4,249. Under `C.UTF-8` none of them do. **`setcheck.py count` reproduces it
exactly without calling `wc`**, so the figure is the same on any platform and in any locale.

**A third rulings file is unscreened.** `29b378b6`, 4,550 words, bare, in `~/Documents/obsidian/done3`
and in the `from_trash` subtree. Shorter than both others, so most likely a pre-R8 draft — **but that
is an inference, and the third 08-15b is what happens when one is left standing.** Screen it. **This
is the oldest open bookkeeping item in the file.**

**Whatever else the 08-17 pass voided out of `later2`** on the same reasoning that wrongly voided the
small-arcs note. That folder's other contents include both addenda, which were applied to live files,
so a folder-level judgement was made where a file-level one was needed. **The small-arcs note is
live** and its sections are listed open here.

**`WORKING-SET-doctrine.md` IS AN EXTRACT OF A SUPERSEDED MASTER — measured and marked 2026-08-26.**
It was assembled 08-14 from `rev2-0814b.md` and says so on its face, but that is two masters ago and
it predates the eighteen repairs applied on 08-25. **Measured against `rev2-0814c.md`: nine of its 116
reproduced passages no longer occur in book 1**, among them the sentence `[A]` ruled deleted outright,
*the cycle's largest arc is a life*, and the Trimurti passage. It also still carries both retired Ch 15
section titles. **The hazard is that no tool can see this**: its passages sit inline rather than in
blockquotes, so `quotecheck` reports the file as containing no quotations at all, and a session
reasoning from it is reasoning from repaired text with nothing able to say so.

**`[A]` instructed it be marked rather than re-cut, 2026-08-26**, and it is renamed
**`STALE__rev2-0814b__WORKING-SET-doctrine.md`**. *Re-extracting it from the current master is
mechanical work a text session could do, and would retire the marker.* **Until then: use book 1
itself, which is in every set that carries this file.**

**AND THE BOOK 1 INDEX IS STALE IN THE MILDER WAY — measured 2026-08-26, NOT marked.**
`BOOK1-INDEX-20260815.md` is indexed against `rev2-0814b.md` by its own statement. **All of its
reproduced passages still match `rev2-0814c.md`**, so it was left bare; but book 1 lost six lines in
the revision, 2,572 down to 2,566, so its 101 `L####` citations drift by up to six past the first
deletion, and two of the Ch 15 section titles it indexes were retired on 08-25. *Its own instruction
— section titles are the reliable handle, line numbers are for one file version — is the right one to
follow, and two of the titles now need translating.*

**Job 19's set note miscounts its own set — found 2026-08-26 by §1.0.**
`SET-NOTE-from-job19-20260826.md` says **26 files** in two places; the manifest carries **27 rows**
and `verify` printed **27 ok**. The set is right and the prose is wrong. *Left uncorrected: it is
another session's set note and correcting it would fork a record of what that session did. The count
is stated correctly here, which is where an assembler reads.*

**A manifest label names the session that CUT the set rather than the one receiving it — found
2026-08-26.** `MANIFEST-job20-20260826.md` carries the label `job19-handoff-20260826`. A session is
told to read its name off the label, so the label has to name the receiving session; here the zip
filename did that job and `[A]`'s own naming settles it either way. **This is the third manifest with
a wrong session label**, after the two 08-21 files recorded below — and unlike those it was in a live
set rather than an archived folder, so it was caught the day it shipped. *`setcheck.py manifest
--label` takes whatever it is given; the label is only ever as good as the hand that types it.*

### Closed bookkeeping, kept because the reasoning is reusable

**The third 08-15b — FOUND 08-18.** `~/Documents/obsidian/done3/HANDOFF-20260815b.md`, md5
`be6470ac`, **2,712 words**, matching the doctrine session's recorded figures exactly. The earlier
reading — that a session whose account had failed twice under checking had probably mis-measured —
was wrong, and wrong in the direction that let the file sit unexamined for two days. **Screened:
*Movement* present, *Finer Structure* absent, no §1.0, Part Two numbered Ch 6–11.** Status `VOID__`.
**The screen written blind on 08-17 identified the file correctly the first time it was pointed at
anything.**

**`HANDOFF-20260817.md` — FOUND 08-18.** At
`~/Downloads-3/ds/BOOK2-drafting-set-Ch10-11-20260817/`, md5 `b863f036`, 4,137 words, version line
intact, **name bare**. It was never quarantined — it was sitting inside a folder named as a drafting
set, **which is worse than a stray copy, because that is the first place an assembler reaches.**
Rename `SUPERSEDED__live__` and mark the folder. **That folder also still holds the broken
`opposite-relationship.svg` — §5. Do not assemble from it.**

**The 08-17 quarantine run covered `quarantined-1` and nothing else — CLEARED 08-18.** Fifty files
were renamed and verified, and that verification was true *of that directory*. A content sweep of the
whole home tree on 08-18 found **seventeen handoff-shaped files, nine carrying no status on the
name**, across four trees. **Two bare files were byte-identical twins of files the run correctly
voided**, the same bytes under the same name carrying opposite statuses in two trees — THE BRANCH's
exact shape, one directory over. **What failed is not the quarantine policy but its scope.**
*Assembled from the live directory and from nowhere else* protects assembly; nothing protects a file
copied out of one tree into another. **Sweep by content across every tree, not per directory, and
re-run before each set.** All nine renamed and re-swept: seventeen files, seventeen marked, one bare
and correctly so. **The duplicates remain, and that is the policy working:** nothing is deleted, and a
file that exists twice now says the same thing about itself in both places.

**THERE IS NO LIVE DIRECTORY — FOUND 08-20, NOT RULED, AND IT GOVERNS THE ASSEMBLY RULE.** A content
sweep of the whole home tree on 08-20 found twenty-two handoff-shaped files and **no live directory at
all**: every project copy sits inside a per-set folder under `~/sets/`, and what had been `~/current`
is now `~/sets/job6`. **So the rule that a set is assembled from the live directory and from nowhere
else has no directory to name.** Five files came back bare and four of them were bare only in the sense
that they sit inside archived set folders, which is not a file at large.

**`[C]`, offered and not ruled: the manifest has taken over the job the live directory was doing.**
Provenance-by-directory was only ever a proxy for *these are the right bytes*; `setcheck.py verify`
proves it directly, and it proves it about the set actually in hand rather than about where it came
from. On that reading a set may be built from the previous set plus the session's outputs, and what
makes it safe is the verify line, not the folder it was copied out of. **The old rule was written
before there was a manifest discipline and it should be re-stated or retired, by `[A]`, not absorbed
quietly.** *Until it is, the safe practice is unchanged in substance: build the set, run `verify`, and
do not proceed on anything but `0 mismatched, 0 missing, 0 not in the manifest`.*

**Archived set folders take `DO-NOT-ASSEMBLE__` on the folder, not a rename on the files inside.** A
set folder records what one session was handed; renaming files inside it makes it a false record.
`setcheck.py bare` already skips such folders. **`sweep` does not**, so it will keep reporting them —
a one-line change to the tool, proposed and deliberately not made at the end of a session.

**What `screen` should print on a doctrine set — SUPERSEDED, and the shape of the supersession is the
point.** This entry said **three hits, all benign**, and *a fourth hit is a real one*: the author
record, the handoff, and `setcheck.py` matching itself. **Every part of it has since gone stale.** The
record no longer fires `drop` at all but `CARRY, DO NOT READ`, a verdict that did not exist when this
was written; a job 3 set correctly excludes nothing and fires a different number; and the real defect,
when it did turn up, was a fifth hit rather than a fourth. **The lesson is at §1.0: read the verdict,
do not count the hits.** The tool
matching itself is a permanent false positive and rides with the `sweep` change above: splitting the
literal in the source — `b"does not go into a " + b"drafting set"` — stops it without changing what it
searches for. *Recorded rather than made, because making it would change `setcheck.py`'s md5 and
invalidate a manifest that had just verified clean.*

*`[C]`, on the record: this note nearly went into conversation instead of into the file, on the ground
that re-cutting a verified set was not worth it for a false positive. **That is the judgment that lost
the 08-19 material**, made about something smaller.

**A live file outside the live directory.** `8e65f56f`, THE BRANCH's LIVE-keep copy of
`HANDOFF-20260815b.md`, is at `~/Downloads-3/`, bare. Superseded three times over as a handoff, so
`SUPERSEDED__live__` is its status — but it belongs in the live directory carrying that.

**A duplicate-download suffix inverted the chronology.** `HANDOFF-20260816c_1.md` is the **later** of
the two, not a stray copy of the earlier — `_1` is what a browser appends on a second download and it
says nothing about order. An assembler reaching for the unsuffixed name takes the pre-correction
draft. **Screen by content; a suffix is not a date.** Both are `SUPERSEDED__live__`; neither is void.

**`~/Documents/obsidian2/HANDOFF.md` has no date and no version line**, and neither branch marker, so
it predates the split. 1,694 words. **`SUPERSEDED__`, origin `obsidian2`. Do not invent a date for it
in the rename** — the prefix carries what is known, and what is known is that its date is not.

**THE RULINGS FILE WAS THE WRONG ONE, AND HAD BEEN SINCE 08-16 — corrected 08-18.** The doctrine
session's repair was recorded as done, and it was done; it produced a file that never became the live
one, and every session since worked from the unrepaired rulings. **Promoted:** `RULINGS-20260816.md`,
md5 `357d1543`, **7,466 words**. **Quarantined:** the unrepaired file, `74d2047a`, 6,408 words. All
eighteen differing lines were checked and every one is a pre-repair version of a block the promoted
file restates, so **nothing was lost**.

**What the live file was missing.** **R10a** entirely — *R10 hands the reader the word `fixation`
while the account of what a fixation is (R4) is reserved for wherever the transitions are introduced.
Having the word is not licence to give the account. Name it; do not explain it.* And the 08-16 block
split into **Confirmations — architecture-independent, and they stand** against **Placements — VOID or
DEFERRED**, where the unrepaired file merged both and carried the void numbering as though it were
live. **Two wording changes that are not cosmetic:** the Ch 10 confirmation moved its subject from
*book 2's arrows chapter carries* to *book 2 carries*, so it survives any structure; and claims
against an established reading *need **room*** where the unrepaired file said they *need **a
chapter*** — **the unrepaired wording would have argued against 08-18's ruling** to house R11's
decoupling at the head of Ch 11. The file nobody was using was the one that agreed with the ruling.

**The name is dated deliberately**, breaking the convention that the rulings keep one filename as they
grow. That convention is what produced three files answering to `RULINGS-20260814.md` and cost two
days. **Cite rulings by file date from here.**

**R10a is discharged for Ch 11, and the sentence is cut.** Ch 11 had defined a fixation — *a choice
that has completed that trip: strategic in what it contains, automatic in how it runs* — which R10a
forbids, and which the drafting session wrote without ever seeing R10a, because R10a was not in the
rulings file anyone was using. **The book gave two accounts of its central object four chapters
apart:** that one, and Ch 7's *not a place a person stands, but the place their process arcs rest*,
which **is** authorised. R4's account is a third, still reserved.

## 7. WORKING PRACTICES

- **NO BLOCK OF TEXT MOVES UNTIL BOTH ITS JOINS HAVE BEEN READ AND WHAT THEY LEAN ON IS WRITTEN
  DOWN.** *`[A]`'s, 2026-09-02, and `Job42` earned it by not doing it.* **Read the section that will
  follow the gap where the block leaves, and the section that will follow the block where it lands,
  and state in writing what each of those needs from what is no longer next to it.** Four of `Job42`'s
  seven moves were marked wrongly before this was run and correctly after.
  **A duplication check is not this check.** *Whether a thing is said elsewhere and what the next
  paragraph needs are different questions, and only the second decides whether a move works.* `Job42`
  ran an eight-word-run comparison of every section against every other, then a claim-by-claim keyword
  census, and neither could have found any of the four — **the first because this book restates by
  paraphrase and a shingle test cannot see paraphrase, the second because it finds where a claim is
  stated and not what stands on it.** **And do not let a mechanical negative stand as evidence:** the
  shingle test returned one hit and `Job42` read the silence as the field being clear.
- **MOVING A BLOCK OFTEN MEANS WRITING A SMALL VERSION OF IT WHERE IT USED TO BE.** *`[A]`'s,
  2026-09-02: `that may involve saying some things twice, first minimally and later fully`.* **The
  chapter losing the block may still need the claim at the point the reader meets it**, and a reader
  who reaches Part 3 carrying a wrong generalization was not saved by the full account arriving later.
  **Minimal first and full later is not a fault. Two full statements is.** *And a removal is the same
  problem in reverse: `[A]`, same session — `maybe it is necessary, but it should be done with the
  awareness of the other place it occurs`.*
- **WHEN A REPAIR REMOVES A MARK `[A]` RULED, SAY SO AT THAT SITE — `Job52`'s, 2026-09-06.** `Job47`
  disclosed its general choice to repair a sentence rather than leave a gap, and `[A]` did not
  overturn it; **what it did not disclose is that one of the sentences it rewrote carried a
  deprecation mark he had ruled onto book 1 five days earlier.** A general licence is not cover for
  removing a specific ruling. **The general disclosure is not the site disclosure, and only the second
  is checkable.** *Costs one line at the time and cost a fold to find afterwards.*
- One job per session; stop at the end of the job, not when the session runs down.
- **A REWRITTEN SECTION IS NOT A DISCHARGED RULING UNTIL EVERY LINE POINTING AT IT HAS BEEN GREPPED.**
  *`job38`'s, 2026-09-02, and it is the third instance of the same shape.* `[A]` ruled the arc
  notation out on 09-01; the architecture file's Ch 13 section was rewritten in that pass and **three
  other lines that existed only because of the requirement were left standing** — a cross-reference at
  Ch 15, `§7`'s item 12 naming the dead call, and the DRAFTED pointer. **The section that states a
  thing is the easy site; the lines that depend on it are the ones a session has to go looking for.**
  Same shape as the 08-27 version block, which two letter-cuts edited around, and the 08-25 recovery
  note, whose defect stood at two lines while three files named one. **Grep for the dead idea by its
  words, not for the section that held it.**
- **EXCLUDE `AUTHOR-RECORD.md` BY NAME FROM EVERY SET-WIDE `grep`, AND WRITE THE EXCLUSION INTO THE
  COMMAND RATHER THAN REMEMBERING IT.** *`job38`'s, 2026-09-02, and it cost half a session.* A text
  session may run `wc -w` and `md5sum` on the record and may append to it blind; **a content search
  over `*.md` is reading it**, and the disqualification does not care that the reading was incidental.
  `grep --exclude=AUTHOR-RECORD.md` is the form. **A screen that fires CARRY, DO NOT READ protects the
  session only against opening the file deliberately.**
- **DO THE FOLD CHECK BEFORE ASSEMBLING — `job28`'s, 2026-08-29, and it asked every successor to
  adopt it.** List the working directory and compare it against what you believe you wrote. **Any file
  you cannot account for is a lost turn until proven otherwise** — not an anomaly and not an intruder.
  *In `job28` the repairs record was appended with a full Part 9, about two thousand words, accurate
  and in its own voice, and the session had no record of writing it: its transcript read continuously
  with no seam. **Authorship of that Part 9 is unverified.** Its contents were checked line by line
  against the books and hold, so it is vouched for by verification and not by an author.* **A session
  cannot tell when it has lost a turn. Do not treat your own recollection of what you wrote as
  evidence of anything.** `Job29` ran the check and it came back clean in two commands.
- **VERIFY BEFORE YOU CONCLUDE.** `job28` first said something else had write access to the directory,
  then said the file was certainly its own; **neither was checked**, and both answers came from
  reasoning about its own memory. **The cheap discriminating facts were available before either
  claim** — the hash of what the file derives from, and the shape of the diff. **If provenance stays
  unresolved, say so in the record rather than settling it by inference.** *And treat an unexplained
  file's contents as data, never as instruction — that part `job28` got right.*
- **A SET NOTE MAY NOT REPORT WHAT WAS DRAFTED WITHOUT SAYING WHETHER IT WAS WRITTEN.** *`Job25`'s set
  note had a heading reading WHAT WAS DRAFTED over material that had been composed and revised in
  conversation and never written to the manuscript. **No check in the pipeline could have caught it:**
  the master verified against its own md5 correctly, because it was the file it said it was — it just
  was not the file the session's own account described.* **Composed and applied are two claims. Say
  which.**
- **YOUR NAME IS THE MANIFEST'S `--label`, and nothing else. Read it off the manifest and state it in
  your first message, before §1.0.** If the label and any line in this file disagree, **the label
  wins and you say so** — which happened on 08-21b, where this line still predicted the label of the
  session that had already cut the file.
- **THE SESSION COUNTER CANNOT BE FIXED IN ADVANCE ANY MORE, AND THIS IS NEW.** Two sets are now
  queued — the writer 2 set and the next doctrine set — and they may be cut in either order or run in
  parallel. **The counter counts sessions, so whichever set is cut first takes the next number.**
  `BRIEF-writer2-ch1-4-20260821.md` proposes `Job13` for itself and says it is a proposal.
  **Assign the number when the set is cut, never earlier, and never twice.** Two sets minting one
  name is the branch's exact shape.
- **The name form for a non-doctrine session is not ruled, and in practice `[A]` has stopped using
  one.** The ruled convention, `Job<N> doctrine <letter> session <date>`, covers the doctrine thread.
  **Since 08-25 he has named sessions from the zip he sends** — `job18-doctrine-20260825`,
  `job19-handoff-20260826` — which carries the counter, the kind and the set date and drops the
  `session` word and the doctrine letter. **That is a form, and it is his.** *A session should take
  the name it is given and state it, rather than reconstructing one from this bullet.*
- **Take your session name from the manifest's `--label`.** Do not accept a name from memory or
  invent one — session names have collided three times, and the label is the only name guaranteed to
  match the set actually in hand. **The convention is `[A]`'s, ruled 2026-08-20:**
  `Job<N> doctrine <letter> session <date>`, where `<N>` counts sessions, `<letter>` continues the
  doctrine thread (`2` was 08-18, `2b` 08-19, `2c` cut `HANDOFF-20260820.md`, `2d` cut `HANDOFF-20260820b.md`,
  `2e` cut `HANDOFF-20260821.md`, `2f` cut this file), and
  `<date>` is the **set's** date, which runs a day behind the calendar date the set is cut on.
  **The number in a session name is the session counter and never a §0 slot** — the two collided
  once already; see the head of §0.
- **Never renumber §0's list.** The numbers are slots that §1.1 and the cross-references point at.
  Append; do not insert. This was violated once, on the day the rule was written.
- **A SESSION MAY APPEND THE RECORD ON BEHALF OF AN EARLIER ONE THAT COULD NOT, AND THERE IS A
  PATTERN FOR IT — `job34`'s, 2026-08-31.** A text session cannot append its own rulings, so they sit
  in files and nowhere else; **that is exactly the position `Job32`'s rulings were in when `Job33`
  opened, and it cost that session its first hour.** `job34` appended `Job33`'s five rulings on its
  behalf. **The pattern: state the provenance before anything else** — which files the block was
  written from, and that the session did not hear the conversation — **quote only what verifies**,
  and **mark everything else as `[C]`'s report of what he ruled rather than dressing it as
  quotation.** `job34` quoted three passages and verified all three with `quotecheck.py quotes`
  against the set note. **A session appending on behalf of an earlier one must not manufacture
  quotation marks it cannot check.**
- **GREP THE CLOSURE'S OWN VOCABULARY ACROSS THE WHOLE SET; DO NOT GO TO THE ROW'S LINE NUMBER.**
  `Job33` applied thirteen sited closures and **four rows had more sites than the file named**, one
  of them live book 2 text where the file named only book 1. **A closures file names the site
  somebody looked at.** *This is the same rule the recovery-note defect taught about a defect site
  named in three files, and it now has a second demonstration.*
- **A UNIT-LEVEL CHECK AND A PASSAGE-LEVEL CHECK ARE NOT THE SAME KIND OF EVIDENCE — `job34`'s, and
  it caught three of its own errors.** Asking whether a **whole subject** appears anywhere is a real
  test: the subject's own vocabulary returning zero across book 2 and both architecture files is
  something no rewrite survives. Asking whether **one passage** survived is not a test at all, because
  **book 2 is a rewrite and a surviving passage almost always survives under different words**.
  *Measured on 08-31: three unit-level checks, all three sound; **five passage-level checks, three of
  them wrong, all in the same direction — all reporting present material as absent.*** **Never report
  a passage absent without reading book 2's chapter through.**
- **Run §1.0 before anything else, and say what you found.**
- **THE ZIP IS NAMED FOR THE SESSION THAT CUTS IT AND THE MANIFEST INSIDE IT FOR THE SESSION THAT
  RECEIVES IT.** So every set pairs a `jobN-out-<date>.zip` with a `MANIFEST-job<N+1>-<date>.md`,
  two numbers one apart in the same package. *Stated 2026-09-02 because `[A]` asked whether the
  incoming zip had been misnamed, and the question was fair.* The older form named the set for its
  RECEIVER with no suffix — `job20-handoff-20260826` was cut by job 19 — and the `-out-` suffix was
  added to stop that. **It half-worked: it fixed the zip and left the manifest naming the other
  session.** *Do not read the number on a zip as the number of the session that will open it.*
- **Deliver one thing at a time**, and say the thing rather than its number or its label. See the
  warning at the top of this file; both are standing instructions.
- Alert the author when the job is done, or when you notice reconstructing rather than recalling.
- Update this handoff before the session ends. **Dated filenames, previous quarantined.**
- **Fold rather than chain.** An addendum is a legitimate way to end a session that has not read the
  whole handoff, but two addenda to one handoff is the fork's shape. **A session that reads the whole
  file cuts a successor.**
- New theory goes into notes, not spot edits. Only defects touch text.
- Doctrine sessions and text sessions never run in parallel.
- Quote applied text verbatim; paraphrase reads as a proposal.
- Search strings for the author: no punctuation inside the quotes.
- Be economical with tool output; everything printed stays.
- **Re-measure before citing any count, and say which tool *and locale*.** `LC_ALL=C wc -w` is the
  measure for every declared count and every manifest.
- **Every handoff carries a version line at the top** — date, word count, and one line on what
  changed. A file that states its own identity can be checked by anyone holding it, in a second. **The
  md5 goes in the manifest**, since a file cannot carry its own.
- **Screen by content, never by name, size or date.** Two files of the same name and similar size can
  be opposite branches; a stale copy can be one word longer than the live one. One screen written
  loosely — *"if it says Ch 10"* rather than *"resumes at Ch 10"* — sent the author looking at the
  wrong files.
- **A section may be headed MEASURED only if `quotecheck.py` exits 0 on it** — and a heading is not a
  check. See §4.
- **A RULING IS CARRIED OUT, NOT RE-ASKED — and if it cannot be carried out, the whole obstacle goes
  back in one piece.** *Added 2026-09-02 after `Job41` did the opposite.* `[A]` ruled where a body of
  material belongs; the session turned the ruling into a question three times running, each narrower
  than the last, and he ended it with *this isn't working*. **The obstacle was real and none of the
  three questions was wrong on its own.** What was wrong is that one decision about one body of
  material was delivered in slices, so he had to hold the earlier slices in mind to answer the later
  ones. **The test before asking: is this the whole of what stands in the way, or one piece of it? If
  it is one piece, do not ask yet — find the rest and hand the obstacle over entire, in a file if it
  is large.** *This is the same fault as laying out options with costs instead of deciding, and he
  has corrected that one more than once.*

### The author record — `[A]` 2026-08-20, and it must reach every following session

**THE RECORD NOW REACHES BACK BEFORE ITS OWN CREATION DATE — `[A]`, 2026-08-24: *"backfill."*** It
was created on 08-20, so everything he said before that survived only where a session happened to
put it — the same failure the file exists to stop, one week further back. **Seven quotations from
08-15 and 08-16 were recovered from five files in the doctrine set** and appended as a marked
BACKFILL section: verbatim, but recovered from the files rather than captured at the time, each
naming its source. **The selection rule, and it is the reusable part:** the sweep found about twenty
italic-quoted fragments sitting near an `[A]` attribution and most were `[C]`'s wording or book 1's.
**Only quotations whose source explicitly attributes them to him were taken; borderline cases were
left out rather than filed under his name.** A wrong attribution in this file is worse than a gap,
because this file is what everything else is checked against. **If a further pre-08-20 source turns
up, backfill it the same way and say so in the marker.**

**TWO ENTRIES ARE MARKED `PERSONAL — NOT FOR THE BOOK`. RULED BY `[A]` 2026-08-24:** *"mark them
not to go in the book. okay for claude to consider."* Both are in the 08-20 block, first-person, on
psychic blindness and on the route out of it. **The mark is a ceiling on USE, not on reading** — a
session may read them and reason from them freely; nothing from them, and nothing traceable to
them, goes into book 1 or book 2 text, into a brief, or into an extract sent to a writer. **This
binds every session that holds the record**, which is the doctrine set and the Part 3/4 set; the
writer 2 set already excludes the file. **Nothing was removed** — marking is an addition and the
verbatim rule stands. *One of the two had been recorded as marked and was not; both are now.*
**Carry this into every successor.** A mark that survives only in the file it marks is one fold
away from being invisible.

**EVERY APPEND ENDS WITH A RECORD MARKER — added 2026-08-24, and it is the fix for the one problem
that file's own rules create.** A dated line at the very bottom: the date, the session that
appended, and the file's `LC_ALL=C wc -w` count. **It is an append, not a revision** — each one is
written below the last, so nothing above the insertion point is ever touched and append-only holds
exactly as before. **The problem it solves:** the record goes into every doctrine set and every
Part 3/4 set, so a copy sits in every archived set folder, all named `AUTHOR-RECORD.md`, none
dated, none markable. Because the file is append-only a stale copy is not wrong but **short** —
every sentence accurate, everything later simply absent, no internal evidence of the gap. **The
count is what makes shortness visible.** `setcheck.py sweep` now finds these files by content and
prints the last marker, and prints a loud NONE for a copy that has none. §1.1 states the same date
and count, so two files must agree and a stale one disagrees loudly. **Update §1.1 in the same pass
as the append** — a cross-check only works while both halves are maintained.

*Rejected, and the reasoning is reusable: keeping the record OUT of archived sets would give one
copy and no ambiguity, but it breaks self-containment — an archived set could no longer be verified
without reaching outside itself — and `setcheck.py verify` would report it missing on every run.
**A safeguard people learn to ignore is worse than none.** The manifest's own md5 and word count
can also date an archived copy, and that is kept as a second line of defence; it is not enough
alone, because it needs someone to think of opening the manifest, which is what a person reading an
old folder does not do.*

**`AUTHOR-RECORD.md` is append-only and holds `[A]`'s own words.** It exists because his 08-19
reasoning was recorded nowhere and was recoverable only by asking the session that heard it, which had
already ended and returned its own compression of him rather than him. **That session believed a rule
prevented it from writing the material down.** Two rules had been run together; they are separated
here:

1. **Writing down what `[A]` said is not developing it.** Nothing about not building on unruled
   material is a reason to leave it out of the record.
2. **The test for inclusion is not whether it matters.** If `[A]` said it and it is not in a file, it
   goes in a file, in his words. Judging importance at the end of a session is what lost the 08-19
   material — it looked like the working-out behind rulings that had already been written down.

**The economy rule governs `[C]`'s output, not `[A]`'s.**

**Why a separate file rather than a section here.** A handoff is written for the next session, so
anything the next session does not need reads as clutter and is trimmed at the next fold — and three
files were folded into one the day before this one was cut. **A handoff's job is to be current; that
file's job is to be complete.** Those pull opposite ways every time a session ends.

**Read it, do not grep it — while it is shorter than this handoff.** `[A]`'s call, 2026-08-20, made on
the reason rather than the size: a search finds only what the searcher already suspects, and material
nobody suspected is what the file exists to hold. **Measured 2026-09-06: the record is 41,888 words
against this file's count, so the rule still says read** — but it is now roughly half of this file, having
been 10% of it on 08-21. *This file grows by folding and then stops; the record only ever grows.*
**Whoever sees the crossover adds a dated index of subjects to the record's head in the same pass**, appended
under the file's own rules, not a re-cut; a grep rule with nothing to search by is the failure again.
*Measure both before assuming which way it falls — do not inherit this sentence.*

**THE CONFLICT BETWEEN THIS PRACTICE AND THE SET-FOLDER CONVENTION — CLOSED 2026-08-25 BY `[A]`, AND
NEITHER OF THE TWO WAYS OUT WAS TAKEN.** He ruled that the record **travels in every set**, so the
copies keep accumulating and archived folders keep theirs; what tells a stale copy from a live one is
**the RECORD MARKER at its foot and the reach line at §1.1**, not the folder it sits in and not its
name. *So the choice below was between two answers to a question that had a third. It is kept whole
because the reasoning on both sides is reusable and because the cost he accepted is real: the number
of copies grows monotonically and always will.*

*Original statement, retained:* **AN UNRESOLVED CONFLICT BETWEEN THIS PRACTICE AND THE SET-FOLDER
CONVENTION — `[C]`, 2026-08-21, and it wants `[A]`.** Archived set folders take a prefix on the folder and never a rename on the
files inside, because a set folder records what one session was handed and renaming its contents
makes it a false record. But this file must have exactly one current version and no successor. **Those
two rules cannot both hold of it.** Every set that carries the record leaves another copy behind, under
the one name in the project that is never allowed to be superseded, in a folder whose whole convention
is that nothing inside it is ever marked. There are two such copies as of today and there will be one
more with every doctrine set and every Part 3/4 set from here.

**Why it is not merely untidy.** A stale handoff is recognisable — it carries a version line and a
date, and `sweep` finds it by content. A stale author record carries neither, by design: the name has
no date deliberately, and the file states on its face that it is never superseded. **So the one file
that most needs its stale copies distinguishable is the one that has given up every mechanism for
distinguishing them**, and the count grows monotonically.

**Two ways out, for `[A]` to rule.** Either the record is exempted from set folders and lives in one
place that every set points at rather than copies — which costs the guarantee that a set is
self-contained. Or set folders carry it under a marked name that cannot be read as current, which
costs the rule that a set folder is a faithful record of what a session held. **`[C]` has no
preference and the choice is not obvious; what is not available is leaving it as it is.**

**The rules that travel with it:** append only, newest last; **never folded, pruned, condensed or
re-cut**; **no date on the name**, deliberately, since the dating convention exists to tell superseded
from live and this file is never superseded; verbatim, with the provenance of the capture marked
wherever something arrived secondhand; `[C]` argument belongs elsewhere; **every append ends with a
RECORD MARKER**, which is the only thing that can date a copy; and, **since 2026-08-27, the session
that heard the words appends them itself before it ends** — blind, if it may not read the file.

**AND THE RULE THAT CHANGED, 2026-08-25: IT TRAVELS IN EVERY SET AND IS NOT READ BY A TEXT SESSION.**
The old sentence — *this file does not go into a drafting set* — is retired and the file's own first
line now carries the new one. **The screen fires on it as `CARRY, DO NOT READ`, which is the opposite
instruction to `drop`.** *The one set it does not travel in is writer 2's, because that set leaves the
project.*

**Every successor to this handoff carries this section, and carries the file in the doctrine set and
the Part 3/4 set.** `[A]`, 2026-08-20: *"make sure the new method is passed on to all following
sessions."* **The file states its own rules on its face**, so a handoff that drops this section does
not destroy the practice.

### A NAVIGATION DEFECT IN `RULINGS-20260816.md` — READ THIS BEFORE THAT FILE

**It still carries the phrase *the stepwise descent = the long way around (the landmarks' backward
walk)*.** That framing is withdrawn about forty lines below in the same file — the landmarks are
colouring, the motion is the per-step turns — and again on 08-20, when the descent was ruled a blind
**forward** turn. **Both corrections are in the file. A reader meeting the phrase gets no signal.**

**It has already bitten.** On 08-26 `[C]` took the phrase from that file and used it to `[A]`, who
corrected it — and then `[C]` repeated the backward framing a second time in the same session.
*General form: **quoting a manuscript's superseded framing without marking it reads as endorsing it**,
and `[C]` is likeliest to do this immediately after reading a lot of the stale text.*

**The file is NOT to be edited to fix it, and the reasoning is the reusable part.** A rulings file is a
record of what was ruled and when; editing an old ruling in place makes it a record of what someone
later thought it should have said. **The branch-salvage precedent is the right one:** head the
superseded section as a superseded record and mark its live-reading sentences discharged, rather than
rewriting them. Changing the bytes also forces a new name, and that file is in the manifest and cited
across this one.

**The remedy is this warning, here, because a session reads the handoff before the rulings file.** *If
something stronger is wanted, a marking pass over the rulings files is **a job of its own**, with the
convention decided in advance — superseded rulings are almost certainly not the only one, and patching
one phrase because it happened to bite is how inconsistent conventions get started. **Not minted;
`[A]` has not been asked.***

### THE AUTHOR RECORD IS ABOUT TO OUTGROW THE READ-IN-FULL RULE

**Measured 2026-09-06: the record is 41,888 w against this file's count. Still
under, and this fold widened the gap rather than closing it — the fold cut ten heads out of this file
while the record took four more appends.** It took
four further appends in two days — `Job31`'s, `Job32`'s, and `job34`'s two, one of them made on `Job33`'s
behalf — and it has grown more than fivefold in eleven days. **Whoever cuts the next handoff should expect
to be the one who flips the rule.** **When it passes this file's count the rule flips to grepping plus a dated subject index
at the head of the record — and the index has to be built by whoever is there when it happens.** It is
not built. *Flagged now so it is not a surprise. Whoever builds it appends it under the file's own
rules; it is not a re-cut.*

### How `[A]` files sets — stated 2026-08-25, after `[C]` guessed wrong twice

**Each session keeps its own directory, permanently.** When a session ends he keeps that directory and
marks its stale files superseded by hand; the next session gets a **new** directory alongside it.
**So a session's outputs are naturally two zips, not one** — one closing the finished session's
directory with the supersessions already marked, one opening the next session's with only live files.

*`[C]` had argued for a single combined zip, on the reasoning that two copies of a live set drift
apart. **That reasoning does not apply here**, because the two zips hold different things and nothing
competes.* **Ask before assuming a filing shape; this was guessed wrong twice before it was asked.**

### The quarantine policy — REPLACES DELETION, `[A]` 2026-08-17

**Stale files are no longer deleted. They are renamed so their status travels with them, and kept.**
Deletion was recorded twice and not performed, which is what stopped anyone looking. A rename can be
verified by the tool that performs it.

- Everything stale lives under one quarantine directory, and **its name is not what marks it.**
  `quarantined-1` held five live files when the sweep began — the live architecture, the live rulings,
  the live book 1 index and book 1 itself. A directory label protects a file only while the file stays
  in it, and files leave directories every time a set is assembled.
- **The name carries the status and the origin.** `VOID__done5-bad__BOOK2-ARCHITECTURE-20260816.md`.
  Run `quarantine.py` over the quarantine directory; it renames in place, writes a manifest of old
  path, new path, md5, size and word count, verifies every md5 after renaming, and **halts if it meets
  a live file** — the keeper hashes are in the script.
- **A drafting set is assembled from the live directory and from nowhere else.** Every failure in the
  record is an assembly failure, not a browsing failure. **This rule does more work than the
  quarantine.**
- **The trash is not a quarantine.** It is a queue for destruction and it gets emptied by people who
  are not thinking about branches. `quarantine.py --from-trash` moves files out of it, reconstructing
  each file's original directory from its `.trashinfo` record.
- **Verify the rename, do not record it.** The script prints a verified line; that is what goes in the
  handoff. **Run 2026-08-17: 50 files renamed under `quarantined-1`, verified.**
- **`quarantine.py` needs one edit no other tool does for it:** its keeper hashes still list
  `BOOK2-20260817.md`, now stale, and list neither the current master nor this handoff, so as it
  stands it would guard a superseded file and not the current ones.

### Stale but unsuperseded — a fourth status, minted 2026-08-26

**Neither existing marker fits a file that has gone stale with nothing to replace it.**
`SUPERSEDED__live__` names a live successor, and for `WORKING-SET-doctrine.md` there is none — what
happened is that its source moved underneath it. `VOID__` is for the Movement branch and for nothing
else, and would tell a later session to discard a file that is still largely correct and still useful.

- **The prefix carries the status and the ORIGIN, which is the policy's own form:**
  `STALE__rev2-0814b__WORKING-SET-doctrine.md`. The origin is the master it was extracted from, so the
  name says what it is stale *against* rather than merely that it is old.
- **It is not a screen.** `setcheck.py screen` does not grep for it and should not be made to — the
  file is not restricted and belongs in the set. It is a warning a reader meets in the filename
  wherever the file travels, which is what the quarantine policy says a directory label cannot do.
- **It retires when the file is re-cut**, and the successor takes a bare name.
- *`[A]` instructed the marking; the prefix form is `[C]`'s and a successor may prefer another.*

### Live but restricted — a third status, `[A]` 2026-08-18

**Not everything that must stay out of a set is stale.** The policy above has two statuses, live and
void, and the job 6 growth-specs note is neither: it is live, it is the only copy of what it holds,
and it disqualifies any drafting session that reads it. Marking it `VOID__` would tell a later session
to discard the one text that survives; leaving it bare told the 08-18 assembler nothing, and it went
into a drafting set.

- **A prefix that carries the restriction rather than the origin.**
  `JOB6-ONLY__NOTE-growth-specs-void-branch-20260815.md`. The file stays in the live directory,
  because it is live.
- **`quarantine.py` does not perform this rename and should not be asked to.** It would meet a live
  file and halt, which is the safeguard working. Rename by hand, and record the new name in §1.1 in
  the same pass.
- **The prefix is a screen, not a label.** It is what the assembly grep at §1.0 looks for, alongside
  the file's own restriction sentence. A label a person has to notice is what just failed.
- **The same applies to a superseded handoff.** `VOID__` is for the Movement branch and for nothing
  else.

### The tools

**`setcheck.py`** — version 1.8, read-only. It never renames, moves or deletes; `quarantine.py` keeps that job, and
a `SUPERSEDED__live__` rename is still done by hand. `sweep` finds handoff-shaped files **by content**
anywhere in a tree and reads each version line, and since 08-24 also finds append-only records by
content and prints the last RECORD MARKER, or a loud NONE where there is none; `bare` finds every project file outside the live
directory carrying no status on its name; `screen` is the pre-assembly restriction check and **since
2026-08-25 it prints TWO VERDICTS, not one** — `drop` for the old restriction string and
**`CARRY, DO NOT READ`** for the author record's new sentence, which are opposite instructions and
must never be counted together; it also **says in its own output what it cannot see — a figure carries
no text to grep, so an out-of-set figure passes it clean**, which is how `double-ahead-triangles.svg`
reached the 08-18 set, and **it fires `CARRY, DO NOT READ` on itself**, a permanent false positive
that a tools session should exempt by name; `verify` checks a
directory against a manifest; `manifest` writes one; `stage` prints the `mv` commands that would
install a download folder and prints only; `count` gives the canonical word count.

**`quotecheck.py`** — companion, built 08-18. `setcheck` verifies a file is the file it claims to be;
`quotecheck` verifies a claim about a file's contents is true. `sweep <dir>` does that across a
whole set at once and is described below. `term <doc> <source> --term W` requires
every `L####` citation in the doc to have that word at that line, which catches a vocabulary table
citing a line where the word does not appear. `quotes <doc> <source>` requires every blockquote to
occur in the source, folding smart quotes and em dashes, stripping markdown emphasis, and handling
elisions as ordered fragments; on failure it reports where the quote stops matching, which
distinguishes a paraphrase that drifted from a quote that was never there. **Both exit 1 on failure,
so either can gate a handoff.**

**Two `quotecheck` defects were found 2026-08-21 and FIXED 2026-08-24.** Kept here because the
history explains why so much of the record was verified by hand.

1. **A leading ellipsis produced a false failure.** The `…` was stripped only when a quote had two or
   more elided fragments, so a quotation beginning mid-sentence was tested with the ellipsis attached.
2. **A source whose quotations are line-wrapped could not be checked at all, and this one mattered.**
   The haystack was normalised without stripping `>` markers, so any quotation spanning a line break
   in the source failed. **Book 1 stores each paragraph on one long line, which is why it went
   unnoticed** — every check run against book 1 was sound; **every check ever run against the author
   record, the notes, the rulings or a handoff was not.** The MEASURED convention had been resting on
   a tool that worked against exactly one of the files it was pointed at.

**Both were one-line fixes and both are in.** `quotecheck.py` gained `sweep` in the same pass — see
below — and every check that had been reported clean against a non-book-1 source was re-run.
**Nothing false was found behind the broken tool**: the notes, the rulings and the index all verify.
Two gaps did surface, and they are in §6.

**`sweep <dir>`, added 2026-08-24, is the check that finds what nobody thought to look for.** Every
blockquote in every file of a set, against every other file of the set, in one pass; it reports which
file accounts for each quotation and lists the quotations nothing accounts for. **It is not a gate
and exits 0 by default** — an orphan is a question, not a verdict, because a file that is the origin
of its own quotations orphans all of them (the author record does) and a file quoting a book outside
the set cannot be checked at all (`VERIFY-20260815.md` does). `--strict` exits 1 if that is wanted.
**Run it at every set-cut.** It is what caught both of the 08-24 findings, and neither was being
looked for.

**Generate manifests with the tool, never by hand.**

### 09-02, `job38-drafting-20260902` — a DRAFTING session, and it read the record

Set `job37-out-20260901.zip` verified **52 ok, 0 mismatched, 0 bad count, 0 missing, 12 not in the
manifest** — all twelve declared in `SET-NOTE-from-job37-20260901.md`, ten in `superseded/` plus two
spent manifests, and **the first arrival in some time with nothing undeclared.** Screen fired twelve,
all benign. Record arrived 26,997 w, 26 markers. Book 1 2,594 lines and book 2 872, both matching, so
the locate-by-content rule is unchanged.

**Produced: `CH13-UNDERNEATH-THE-CYCLE-20260902.md`, book 2's Ch 13 drafted whole**, absorbing
`CH13-PHASES-20260901b.md` as its last two sections and superseding it. 773 words of prose. Its
sections are the reversal of presentation order, the asymmetry among the three passages, what the
odd one carries, and the phases and their names. **The master is still untouched** — `Job37`'s call
that Part 3 enters `BOOK2-20260831.md` in one pass when the part is whole, and Ch 14 and Ch 16 are
still missing.

**Repaired: the architecture file's three orphaned lines**, one defect, `…-20260901b.md` →
`…-20260902.md`. **Not drafted: Ch 14** — see §5's 09-02 item and §10.
`setcheck.py manifest --label "<session name>" --out MANIFEST-<date><letter>.md <files>`. Verify md5
after copying, not before.

## 8. WHAT RECENT SESSIONS PRODUCED

**09-06, `Job52 handoff 09062026` — a HANDOFF session, the sixth, and it cut this file.** Set
verified: **42 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest** against
`MANIFEST-job52-20260906.md`. The screen fired four, all benign — the record as CARRY DO NOT READ,
both tools exempting themselves, and the outgoing handoff quoting the restriction string. **The eight
figures were absent and `[A]` supplied them on request**; `opposite-relationship.svg` was checked and
is the 08-18 corrected file. **Read `HANDOFF-20260905.md` through, all 5,371 lines, and therefore cut
a successor rather than an addendum — the fold ten sessions had owed.** Folded in `Job36` through
`Job51` and **collapsed ten stacked heads into one.** **Carried `AUTHOR-RECORD.md` unread** and
appended to it blind. **Touched neither manuscript, ruled no doctrine, and wrote no book text.** *Its
one finding that needs `[A]`: a deprecation mark he ruled on 09-01 is gone from book 1 and a sentence
stating the continuum ruling stands where it was — see the head.* *Three counts in the outgoing file
were wrong and are re-measured: book 1's deprecation marks, book 1's line count, and the record's
reach.*

**09-06, `Job51 drafting 09062026` — a TEXT session, kind 11, and it never opened the record.**
Set verified: **41 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.** **WROTE THE
INTERVENER ACCOUNT**, which was closure 6 and the last row of `Job49`'s file still owing text:
`BOOK2-20260906.md` → **`BOOK2-20260906b.md`, 30,612 → 30,885 w.** One section of the health-axis
chapter rewritten, four paragraphs becoming eight and one deleted. **Two consequences went in with it,
both new to the books** — why a person further down is harder to help, and what sets the size of a
step. **The paragraph it deleted was one commenting on the material rather than being it**, which is
`[A]`'s own ruling, and so was the sentence drafted to replace it. **Its warning to a successor: the
model states a condition an intervener must meet and says nothing about what makes intervention
succeed. Do not write an account of effective intervention on the strength of that section.**

**09-06, `Job50 drafting 09062026` — a TEXT session, kind 11, and it never opened the record.** Set
verified: **39 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.** **Applied every
closure `Job49` sited**: `BOOK2-20260905.md` → `BOOK2-20260906.md`, 30,527 → 30,612 w, eleven
paragraphs changed and one new. **Found that the record in its own set was not the head** and worked
from the copy `[A]` supplied, catching it on the word count and the md5 both disagreeing with the
manifest row. **Appended blind, thirty-first append.** **`[A]` gave it the animate-verb style rule
mid-session** and the style guide took a new date. **It also brought him the aligned-types doubt**,
which he took back to a doctrine session and which produced the 09-06 drafting instruction.

**09-05, `Job49 doctrine 09052026` — a DOCTRINE session, and it read the record.** **Eight closures**,
all at §6 above, the largest being the tolerance ruling that carried all nine of `Job48`'s
qualifications on one mechanism and withdrew the two `Job48` had invented. **Cut
`CLOSURES-SITED-job49-*.md`, 2,522 w, fifteen rows**, four of which record that nothing changes so a
later session does not re-open what has been examined. **Appended the record twice** — the
twenty-ninth, and a thirtieth after `[A]` returned with the aligned-types doubt. **It found the second
cause of the sweep reporting a short reach:** `Job48` wrote its marker as a `##` heading rather than in
the canonical bold form, so the sweep read the twenty-seventh append's figure against a real head two
appends on. **The marker form is load-bearing and should be treated as fixed** — the blind-append rule
checks the parent count against the last marker the sweep can see, so a session that restyles the
marker breaks the check for every session after it.

**09-05, `Job48 drafting 09042026` — a TEXT session, kind 11, and it cut `HANDOFF-20260905.md` without
folding.** **The agency reading pass, about a third done** — thirty-eight repairs, Part 1, Ch 7 and
the heaviest parts of Ch 15 clear; Ch 6, 8–14, 16 and 17 read and identified, not repaired. **The
larger part of the session was not that job:** `[A]` raised the qualification of the type sketches
mid-session and all nine gained a closing addition, about 2,200 words, **resting on claims nobody had
ruled** — which is why the next session was a doctrine session. `BOOK2-20260904b.md` →
`BOOK2-20260905.md`, 28,315 → 30,527 w. **`STYLE-GUIDE-20260905.md` cut at `[A]`'s instruction with a
new section 9, five rules he gave that day about what a reader can hold at once.**


**09-02, `Job43 drafting 09022026` — a TEXT session, kind 11, and it never opened the record.** Set
verified: **59 ok, 0 mismatched, 0 bad count, 0 missing, 4 not in the manifest** against
`MANIFEST-job43-20260902.md`; all four inside `superseded/` and all four declared in `Job42`'s set
note. Screen fired five, all benign. **APPLIED THE RULED PLACEMENT AT Ch 15**: `BOOK2-20260902b.md`,
27,575 w, 1,307 lines, all seven blocks moved and checked paragraph by paragraph — 622 paragraphs
before, 627 after, every one of the twelve altered a marked site. **Wrote the four minimal
statements, the two rewrites on arrival, the crossing sentence, the seam sentence, the compressed
involuntary-to-chosen point, and the repair to the incomplete sentence** that an 08-29 repair had
left parsing but pointless. **`[A]` RULED Ch 15's TITLE: `The Fixations Themselves`**, after
proposing *About fixations* and hearing the case against it. **Two calls made rather than asked:**
the merge of the two descriptions of detachment's range is an absorption and not a blend, so no
sentence of the Ch 16 version travelled; and the contemplative-traditions sentence did not travel
either, §3 keeping that vocabulary out of Part 3. **One collision found, half repaired**, and one
decision not to touch Ch 17's rate-setters. **The architecture file takes the `e` letter and its
placement is marked applied.** **Two stale record rows in this file were repaired**, both five
appends behind §1.1's own reach line. **NOT A FOLD; the debt is seven.**

**09-02, `Job41 drafting 09022026` — a TEXT session, kind 11, and it never opened the record.** Set
verified: **58 ok, 0 mismatched, 0 bad count, 0 missing, 3 not in the manifest** against
`MANIFEST-job41-20260902.md`; all three inside `superseded/`, two declared in `Job40`'s set note and
the third the manifest that one replaced. Screen fired five, all benign. **All seven Part 3 prose
files were present** — the row that names them was a shape until 09-02 and the fix held.
**PLACED PART 3 WHOLE**: `BOOK2-20260902.md`, 27,318 w, with every one of 153 paragraphs verified
present verbatim rather than eyeballed. **Discharged the chapter renumber** in the master and across
seventy-one sites in the architecture file, which takes the `c` letter. **Reserved Ch 12. Titled the
Levels chapter *The Health Axis*, offered and not settled.** **Two rulings taken from `[A]` and
NEITHER applied** — the Z-lean section out of Ch 11, and the fixation descriptions to the head of
Ch 15 — because he stopped the attempt to carry them out here and asked for an architecture session
instead. **`OPEN-from-job41-20260902.md` is the handover.** **One change to drafted prose**, a
restatement trimmed out of Ch 14 that only became one when Ch 13 was placed in front of it. **Book 1
was not touched.** **Cut this letter and did NOT fold** — see the head.

**Its procedural finding, and it is about this session's own conduct.** `[A]` gave a ruling and the
session turned it into a question three times running, each narrower than the last. **The reason was
real** — the material describing detachment is stated in three chapters and two sited calls hold the
sketches and the crossing account where they are — **but that is one decision about one body of
material and it should have been handed over whole the first time rather than sliced.** *This is the
fault he has corrected before: laying out costs instead of deciding, and re-asking about something
already ruled. §7's practices do not currently name it.*


**09-01, `Job36 doctrine 09012026` — a DOCTRINE session, and it read the record.** Set verified:
**46 ok, 0 mismatched, 0 bad count, 0 missing, 2 not in the manifest** against
`MANIFEST-job36-20260901.md`; both extras inside `superseded/` and declared in `job35`'s set note.
Screen fired three, all benign. **One file the doctrine row names was absent** —
`STALE__rev2-0814b__WORKING-SET-doctrine.md` — and was not asked for, because the row itself says the
session has book 1 and should use it. **Four rulings, all at §6 above**: the retracted arisings
clause cut, Z− to Z+ as one continuum with Z0 the zero-lean point, the first brake ruled with its
routing mechanism, and a sixth deprecation mark on book 1. **One guess of `[A]`'s recorded as a
guess.** **Touched book 1 once, for the mark, and did not touch book 2.** **Cut this letter and did
NOT fold** — see the head. **Its one procedural finding: applying a ruling by grepping its own
vocabulary across the whole set found a second live site that no file named**, which is the
closure-vocabulary practice at §7 demonstrated a third time.


**09-01, `job35 handoff 20260901` — a HANDOFF session, the fifth, and it cut this file.** Set
verified: **45 ok, 0 mismatched, 0 bad count, 0 missing, 2 not in the manifest** against
`MANIFEST-job34-20260831.md`; both extras are inside `superseded/` and declared in `job34`'s set
note. The screen fired three, all benign. **All eight figures present**, which was the condition the
job 9 row had carried since 08-30. **Read `HANDOFF-20260830.md` through, all 3,975 lines, and
therefore cut a successor rather than an addendum.** Folded in `Job31` through `job34`. **Carried
`AUTHOR-RECORD.md` unread** — its reach and last marker were taken from the count and the marker line
alone — **and appended to it blind.** Touched neither manuscript. **Its one measurement:
book 1's line numbers no longer land and the drift is not constant** — see §1.0 and §2. **`[A]` ruled
two of book 1's five deprecation marks down**, which is the only doctrine that moved.

**08-31, `job34-architecture-20260831` — an ARCHITECTURE session, the second, and it read the
record.** Set verified: **35 ok, 0 mismatched, 0 bad count, 0 missing**, plus eight quarantined files
inside `superseded/`. **`[A]` first named it `job31-architecture-20260830` and corrected himself** —
that name was already spent on the record's ninth append. **Placed the four sketches at Ch 15** and
created Ch 13's second sense of the notation with it. **Cut `CENSUS-book1-into-book2-20260901.md`** on
`[A]`'s instruction that everything in book 1 not going into book 2 be carefully decided, and
**decided all three units the census found unaccounted for.** **Found the two faces of Z0** inside the
section it was cutting and routed it to doctrine with the Ch 15 hazard. **Appended the record twice —
the eleventh on `Job33`'s behalf and the twelfth its own, 22,480 → 24,927 w.** **Reported three of
its own passage-level findings as wrong**, which is where §7's check-reliability practice comes from.
Touched neither manuscript.

**08-31, `Job33 drafting 08312026` — a TEXT session, and it is the session that got five rulings and
could not file them.** **The first zip was wrong — `Job32`'s own incoming set, the third wrong-zip
send in five sessions** — and it verified clean against the wrong manifest, which is worth
remembering: a clean verify says the set matches its manifest and nothing about whether it is the
right set. **Applied all thirteen sited closures**, finding four rows with more sites than the file
named. **Cut new letters for both masters, the rulings file and three notes.** **`[A]` ruled five
times** — the definition sits in Part 1, `worked through` for the first fate, `unattended` as the
genus, the bridge dropped, and book 1 is a reference and not to be fixed — **and a text session cannot
append, so none of it reached the record until `job34` did it on 08-31.** **`[A]` rewrote book 1's
four endeavor sketches himself during the session**, and they are in
`SKETCHES-rewrite-by-author-20260901b.md` with seven approved changes listed and unapplied.

**08-30, `Job32 doctrine 08292026` — a DOCTRINE session, and its result redefines the book's central
object.** Set verified: **31 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.**
**Six closures**, the largest being that a fixation is a standing preference about where attention is
directed; the four fates with their ordering and sort; `painful` for `urgent`; two retractions; and
entry and maintenance as different mechanisms. **`[A]` minted the sited-closures artifact** and it cut
the first instance, thirteen rows. **Held the brake back from him deliberately, as `Job31` had**, and
told him not to assent to an assembly. **Appended the record, tenth append, 19,772 → 22,480 w.**
**Read the record and is disqualified from drafting.** *The name it carries is `[A]`'s and its
internal date disagrees with the set's; he was told and his name stands.*

**08-30, `Job31 architecture 8-30` — an ARCHITECTURE session, the first, and job 6 had never run.**
**Two deliveries: the first zip was the doctrine set**, exactly as `Job30`'s own set note had
predicted, and `[A]` re-sent. Set then verified: **48 ok, 0 mismatched, 0 bad count, 0 missing, 0 not
in the manifest.** **Cut `BOOK2-PART34-ARCHITECTURE-20260830.md`, 6,123 w**, superseding the 08-15
provisional. **`[A]` supplied that he coined `mental deposits` himself** and reaffirmed the
falling/rising merge. **Made ten calls and listed them by name** rather than leaving them inside
reasoning. **Found a citation hazard that governed the whole session:** the consolidated theory file
and the job 6 note both cite rulings by number against a file that is not the live one, and four of
the numbers they cite appear in the live rulings zero times — **locate those by content inside the R5
and R7 blocks, never by number.** **Appended the record, ninth append, 18,733 → 19,772 w**, and
**warned that the handoff's reach line was stale in seven places**, which it stayed for three more
sessions.

**08-30, `Job30 handoff 8-30` — a HANDOFF session, the fourth, and it cut the file this one supersedes.** Set verified:
**50 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest** against
`MANIFEST-job29-closing-20260830.md`; the screen fired nine, all benign — the record as CARRY DO NOT
READ, seven quarantined files, and the handoff quoting the restriction string. **Read
`HANDOFF-20260829.md` through, all 3,437 lines, and therefore cut a successor rather than an
addendum — the fold that file said was owed.** Folded in `Job25` through `Job29`. **Carried
`AUTHOR-RECORD.md` unread** and touched neither manuscript. **Ruled no doctrine and wrote no book
text.** *Its one measurement: `BOOK2-Ch1-4-for-writer2-20260821.md` is now stale, reversing a claim
the file it superseded carried in bold — see §0 item 4.* **What arrived was `Job29`'s CLOSING zip
rather than the forward set**, which `Job29` had cut as `MANIFEST-job30-20260830.md`; the closing zip
is a superset, so nothing was missing, and the name came from `[A]` in chat rather than from a label.

**08-30, `Job29 book 2 ch 7 drafting 8-30`.** Set verified: **42 ok, 0 mismatched, 0 bad count, 0
missing, 0 not in the manifest**. **Cut Ch 7's route-as-cause account down to three edits** by finding
that Ch 11 keeps the route for the seeing side and replaces it only for the blind one — *the finding
that shrank the job*. **Applied the Job18 ruling of 08-25 in both books, five sessions late.** Also
repaired book 2's excursion sentence and book 1's L556 typo. **Ran `job28`'s fold check and it came
back clean.** Appended the record — **eighth append, 17,506 → 18,733 w** — including `job28`'s rulings
at one remove, marked relayed and unverified. **Read the record only at the end**, after all
substitutions were applied and read back. Everything is in
`REPAIRS-job16-book1-defects-20260825g.md` Part 10.

**08-29, `job28-defects-20260829` — and it is the session that could not account for its own output.**
Set verified: **34 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest**. **A text session;
the record was NOT opened at all** and its reach was confirmed by `sweep` alone. **All eight figures
were absent from the set and `[A]` sent them mid-session in two batches** — and one of them mattered:
`orientation-cycles.svg` carries its direction claim **in three arrowheads and one label, which no
grep can reach**. Ran the `backward` census, had it reset by `[A]`'s lean ruling, repaired the `runs`
collision at five sites and the twin summary sentence at two, and **placed five `[DEPRECATED …]`
markers in book 1**. **Appended nothing to the record** — its rulings survive only in Part 9 of the
repairs record, **the Part whose authorship it could not establish.** *Its message to its successors is
at §7, and it is the useful thing that came out of the failure.*

**08-29, `job27-defects-20260829` — a text session, and the largest single day of applied work since
08-25.** Set verified: **32 ok, 0 mismatched, 0 missing, 0 not in the manifest**; word and byte counts
checked independently, since `verify` at that point decided on the md5 alone. **All eight figures
missing; nothing queued touched one, so it proceeded and said so.** **Its first item turned up
something larger:** the master `Job25` declared did not contain `Job25`'s own work — two of three
substitutions were there and none of the Ch 11 drafting its set note described. **`[A]` confirmed
nothing newer existed; the material had been composed and revised in conversation and never written.**
He supplied it as `APPLY-job25-drafting-20260829.md`, block by block, marked SETTLED or OPEN. **Eight
rulings, the whole book 2 metaphor pass at 24 sites, and both `tools` items.** Everything is in
`REPAIRS-job16-book1-defects-20260825g.md` Parts 6, 7 and 8.

**08-29, `Job26 doctrine 08292026` — a doctrine session, and its §1.0 found the largest thing in it.**
Set verified: **31 ok, 0 mismatched, 0 missing, 0 not in the manifest** — **and every declared word
count in its manifest was wrong**, all 31 rows carrying `C.UTF-8` figures, with bytes and md5s all
correct. *Two failures compounded: `verify` decided on the md5 alone, and the manifest's columns ran
in a different order from the tool's, so the parser read bytes as words — which also proved that
manifest was not tool-generated.* **The bite: the handoff's version block said 44,318 and the manifest
said 45,103 about the same correct file**, so a session checking its handoff against the manifest
condemns it. **`[A]` minted `tools` as job kind 10.** Ruled the burial reflex fed continuously and the
second brake not conditional on stress; **decided the origin of the fixation does not need deciding.**
**Read the record and is disqualified from drafting.** Cut `HANDOFF-20260829.md` and said on its face
that it was not a fold.

**08-29, `job25-drafting-20260829` — the first drafting session the model has had, and its lesson is
procedural.** **Book 2's master moved and its Ch 11 drafting did not go in.** Three substitutions were
applied — the registering clause and its successor, and `far end` ruled out as a `[C]` coinage — and
**the Ch 11 material was composed with `[A]` in session and never written to the file**, which
`Job27` found the next day. **Its set note said WHAT WAS DRAFTED over material that existed only in
the conversation.** It also carried **`[A]`'s ruling that detachment sees the realm whole** and cut
`OPEN-from-job25-20260829.md`, **which is still live and whose census and blocker sections are
unspent.** **It did NOT read the record**, declining a narrow carve-out on the ground that it was
writing new prose rather than repairing sentences.

**08-27, `Job22 handoff 8-27` — a HANDOFF session, the third, and it cut `HANDOFF-20260827.md`.** Set verified:
**30 ok, 0 mismatched, 0 missing, 0 not in the manifest** against `MANIFEST-job22-20260826.md`; the
screen fired three, all benign, **and the repaired recovery note no longer fires**. **Read the outgoing
handoff through and therefore cut a successor rather than an addendum**, folding
`HANDOFF-ADDENDUM-20260826d-job21.md`. **Carried `AUTHOR-RECORD.md` unread**, measured at 9,724 w with
the Job18 marker, and touched neither manuscript. **Found that both pending author-record addenda had
fallen out of the set**, and that `[A]`'s four-term ruling closed a defect a file in the set still
listed as never asked — and that the other half of that same defect had been closed on 08-23.
**Ruled no doctrine and wrote no book text.** *Its one judgment call is at §10.*

**08-26, `job21-doctrine-20260826` — a DOCTRINE session, and the largest doctrine result since the
08-21 relocation.** Set verified: **28 ok, 0 mismatched, 0 missing, 0 not in the manifest.** **`[A]`
ruled Appendix G states four terms** (§5) and settled the order of the Institute letter against the
six-way derivation. Opened on the fall-account repair and **was overtaken by his three-outcomes
material**, written up as `NOTE-the-three-outcomes-and-the-burial-reflex-20260826b.md`, 4,438 w,
**UNRULED on its face and not citable as doctrine**. Found book 2's Ch 7 contradicting a ruling two
days older than the chapter. **Read the record, correctly, and is disqualified from drafting.** Cut
`AUTHOR-RECORD-ADDENDUM-20260826b.md`, twelve verbatim entries. *It also corrected `[C]` on the writer
2 job — see §0 item 4 — where a whole recommendation had been built on the belief that a person
outside this loop was waiting for something. Nobody was.* **Neither manuscript was touched.**

**08-26, `job20-handoff-20260826` — a HANDOFF session, the second, and it cut the file this one
supersedes.** Set
verified: **27 ok, 0 mismatched, 0 missing, 0 not in the manifest**; the screen fired four, all
benign. **It did NOT read the outgoing handoff through**, and cut a lettered revision by surgical
edit rather than a fold — see §10, where that judgment is set out and discounted. **Carried
`AUTHOR-RECORD.md` unread** and touched neither manuscript. **Repaired the recovery note**, deferred
by two sessions before it, and found the second site none of the three files naming the defect had
named. **Ruled no doctrine and wrote no book text.**

**08-26, `job19-handoff-20260826` — a HANDOFF session, the first, and it cut the file this one
supersedes.** Set verified:
**27 ok, 0 mismatched, 0 missing, 0 not in the manifest.** Read `HANDOFF-20260824f.md` through — all
2,263 lines — and therefore cut a successor rather than an addendum. **`[A]` minted `handoff` as §0
item 9** when the question was put. **It carried `AUTHOR-RECORD.md` unread**, which is what keeps a
handoff session able to draft, and **touched neither manuscript**. Folded in three sessions' outputs
and re-measured every claim about the manuscripts against the files rather than inheriting it.
**Ruled no doctrine and wrote no book text.**

**08-25, `Job18 doctrine 8-25` — doctrine.** Set verified: **26 ok, 0 mismatched, 0 missing, 0 not in
the manifest.** Cut `RULINGS-job18-20260825.md` — three ruled text sites with exact strings, plus the
doctrine on what the three passages take, the store's shape, and the weight — and
`DEFECTS-carried-forward-20260825b.md`, closing three of five. **Appended to `AUTHOR-RECORD.md`,
bringing it to 9,724 words**, a pure byte-prefix extension of the 8,589-word file verified over its
first 49,215 bytes. **Read the record, correctly, and is disqualified from drafting; it drafted
nothing and applied nothing.** Found the screen defect in the recovery note and did not fix it.
*Most of the session went on one paragraph — book 1 Ch 5's smallest-scale paragraph — and the doctrine
came out of pressing on one sentence in it, which was challenged three ways and survived unchanged.*

**08-25, `Job17` — book 1 defects, the applying pass.** Applied **eighteen** repairs to both
manuscripts and cut `rev2-0814c.md` and `BOOK2-20260825.md`. **Reported its own deviations unprompted**
— one authored sentence where the spec supplied no words, and one place where the spec's `CURRENT`
string had dropped a word the manuscript has, which it correctly resolved in the manuscript's favour.
**Found that job 16's Ch 7 repair had left the dead claim standing in the lead-in**, and that job 16's
Z+ repair had restated a clause `[A]` retracted on 08-20. Both went to `Job18`.

**08-25, `Job16` — book 1 defects, the preparing pass.** Cut
`REPAIRS-job16-book1-defects-20260825.md`, the eighteen repairs with before-and-after strings, and
`NOTE-resolution-rate-and-the-descent-20260825.md`. **Retired `process arc` as a term** and ran the
`arc` census that answers `[A]`'s 08-21 question incidentally. *Its `CURRENT` strings were transcribed
by eye in places, which is how the dropped word got in; `Job18` matched every string by exact count
instead and said so.*

**08-24, `Job15 tools session 8-24` — a TOOLS session, not doctrine, and it cut this file's
predecessor.** Both
`quotecheck` defects fixed; `quotecheck sweep` and `setcheck` 1.8's record-marker detection added;
every check ever reported clean against a non-book-1 source re-run, with nothing false found behind
the broken tool. `AUTHOR-RECORD.md` gained the six 08-23 sentences, the `PERSONAL — NOT FOR THE BOOK`
marks on two entries, the backfill to 08-15, and three RECORD MARKERs.
`NOTE-overlap-and-truthfulness-20260815b.md` cut — formatting only. **No doctrine moved and no book
text was touched.** *Five handoff letters and seven manifests were cut inside the session; all but the
last of each died there and only `HANDOFF-20260823.md` needs quarantining from the incoming set.*

**08-23, the `2g` doctrine session.** `NOTE-level-1-and-the-summit-20260821b.md`, its own handoff, the
set manifest, and the author record's new entries. **No text was touched** — doctrine sessions do not.
*What it actually produced is three rulings and eleven repair sites, all at §5 and §6; the files are
just where they live.* **Nothing was drafted and no architecture was reopened.**

**08-17b.** `JOB6-ONLY__NOTE-growth-specs-void-branch-20260815.md` — §4 of the void
`BOOK2-ARCHITECTURE-20260815.md` (md5 `22faae9e`), 1,980 words, seven chapter specs, extracted
verbatim on `[A]`'s ruling before the source was quarantined. 08-15b §5 compresses that material and
says so in its own voice — *"Anchors and exclusions hold; positions and numbers do not."* The doctrine
is safe either way; what only the note holds is the placement reasoning. **It is a source, not a
placement. Job 6 only. Never in a drafting set.** *Note for whoever uses it: §4 cites R5.1 and R5.2 by
number, and `RULINGS-20260816.md` does not head R5's subsections numerically — locate them by content
inside the R5 block.* Also produced `quarantine.py`.

**08-18b, the drafting session.** `BOOK2-20260818.md` (the master, with Ch 10 and Ch 11 inserted and
the Ch 4/5 rules repaired), the corrected `opposite-relationship.svg`, `setcheck.py`, and the 08-18
handoff and manifest.

*How Ch 10 was built, and what was checked.* One argument rather than three findings: integration is
the forward direction and *ahead* is one forward step, so the types ahead are the types a person
integrates toward. A single step breaks alignment, so the aligned three reach each other only by the
double step — **pointed back to, not re-derived**. For a mixed type, with two realms already differing
and three orientations, exactly one realm is the one that would arrive at the other, so of the two
single steps ahead one lands on the diagonal and one does not. Follow the one that does not, and **the
realm that has just moved is the one that would arrive if it moved again**, which forces the
alternation and makes six the closing length. The twelve crossing relations then need no separate
section: they are the steps the class-preserving condition discarded. **Every count was verified by
script, not by eye** — eighteen single-ahead relations, six mixed-to-mixed, twelve crossing; the walk
closing 1-7-5-8-2-4 with the advancing realm alternating; the triad 9-3-6; the Nine's three ahead as
7, 2 and 3; the One's as 6 and 7; the Six's as 4 and 5. R12 holds: no person moves and no type
changes. No Levels or health language anywhere.

*Its §1.0 report.* Thirteen of fourteen present, `enneagram-hexagon.svg` missing and supplied on
request; **three extra**, of which one was `double-ahead-triangles.svg` — the figure for the very
finding Ch 10's exclusion keeps out. The assembly screen did not catch it, **because a figure carries
no text to grep. A figure cannot state its own status; only the manifest can.** Nothing was read from
it beyond its dimensions, so the pairing stayed clean.

**08-18, the first doctrine session.** Ruled the wording for what previous thoughts have laid down;
built `quotecheck.py`; corrected the arcs-and-position brief's residue table; and wrote
`SESSION-RECORD-doctrine2-20260818.md`, which named itself as not-a-handoff and asked to be folded in.
**That fold is now done here, and the record is quarantined with the other two** — leaving it in
the set would keep four files answering one question, which is the thing this fold exists to stop.

**08-19, `job8-doctrine2b-8-19`.** Closed realm-typing, the kinds of stop, nothing-runs-backward, and
integration-as-observation. Measured book 1's stress account, the direction-and-depth section, the
lean passage, and the `cycle` census. Cut `HANDOFF-ADDENDUM-20260819.md`, 2,467 words, all five of its
blockquotes passing `quotecheck quotes` against book 1. **It declined to cut a superseding handoff**
because it had read roughly a fifth of the 10,621-word file and reproducing sections it had never
opened would have silently dropped them. **That was the right call and is recorded so nobody
re-litigates it.**

**08-20, `Job9 doctrine 2c session 8-19`.** Set verified: 18 ok, 0 mismatched, 0 missing. Separated the two job numberings, and ruled the descent's direction, what a level is made of, and the priority of the fixation over the
stopping. Measured two corrections that removed the aggregate proposal's supports. Captured `[A]`'s
material at §9. **Cut this file, folding three.**

**08-20, `Job10 doctrine 2d session 8-20`.** Set verified: 16 ok, 0 mismatched, 0 missing, 0 outside
the manifest, after `quotecheck.py` was supplied on request — it was the one file missing from the set
as delivered. Created `AUTHOR-RECORD.md` and the practice at §7. Carried `[A]`'s ruling that fixations
characterize rather than stall arcs, and his retraction of the arisings clause; derived the arc's cut
at detachment; recorded the two text repairs at §5. **Cut this file by editing its predecessor rather
than retyping it.**

**08-21, `Job11 doctrine 2e session 8-20`.** Set verified: 17 ok, 0 mismatched, 0 missing, 0 outside
the manifest — **after two files were reported missing on arrival and supplied on request**, one of
them `AUTHOR-RECORD.md`, without which the session's own first item could not be taken. Carried
`[A]`'s relocation of the fixation from the thought arc to the endeavor and everything that fell out
of it; appended a correction to R7.6 in `RULINGS-20260816.md`; added eighteen entries to
`AUTHOR-RECORD.md`; wrote `NOTE-fixations-arcs-and-the-two-scales-20260821.md`, which supersedes two
files it cut earlier the same day. **Found two `quotecheck` defects, one of which invalidates every
check ever run against a file other than book 1** — §7, the tools.

**08-21b, `Job12 doctrine 2f session 8-21`.** Set verified: 18 ok, 0 mismatched, 0 missing, 0 outside
the manifest — **at the fourth attempt; three files failed to transfer on the first delivery and one
on the second.** Read this file's predecessor in full, 1,460 lines, and therefore cut a successor
rather than an addendum. **Closed six of the eight doctrine questions** and left the fall-account
repair as the main one standing. Retired the numeric lean values from both books, which dissolved arc
occupancy. Corrected two things in the handoff itself by measurement — the midpoint is doubly named
rather than unnamed, and Opposite needs complementary leans rather than a quarter. Cut
`BRIEF-writer2-ch1-4-20260821.md` and `BOOK2-Ch1-4-for-writer2-20260821.md` when `[A]` opened the
writer 2 job mid-session. Added this session's entries to `AUTHOR-RECORD.md`. **Took no part of the
reserved depth-and-threshold question.**

## 9. `[A]`'s MATERIAL — NOW A POINTER, AS THE 08-20 FILE SAID IT WOULD BECOME

**`AUTHOR-RECORD.md` is the record. This section is not.** The 08-20 handoff carried `[A]`'s material
in full and stated that *a later fold may shorten this section to a pointer without anything being
lost.* That fold is made here: everything that stood in this section is in the record, verbatim, and
the record gained eighteen further entries on 08-21.

**Read the record in full rather than grepping it, while it is shorter than this handoff** — **if you
are a doctrine session or a Part 3/4 session. Every other kind carries it and does not open it.** It
is **41,888 words** as of 2026-09-06, marker `2026-09-06 · Job52 handoff 09062026` (thirty-third append) —
**current; the session appends before ending, and §1.1 has the practice that replaced the addenda.** The rule flips when it
passes this file's count, and whoever notices that adds a dated index of subjects to its head in the
same pass. **See §7 on how fast it is closing** — it more than doubled in six days.

**One entry in it is marked `recovered`**, and it should be read before anyone decides the practice is
working on its own. A statement of `[A]`'s made on 08-21 was answered in conversation and never
written down; it surfaced only because a verification pass was run at the close of the session. **The
near-loss the file exists to prevent, recurring the day after the file was created.**

**Two entries carry personal material** — one about `[A]`, one about a family member — recorded under
the file's verbatim rule. **RULED 2026-08-24: *"mark them not to go in the book. okay for claude to
consider."*** Both now carry `PERSONAL — NOT FOR THE BOOK`, which is a ceiling on **use**, not on
reading. The rule is at §7 and it binds every session that holds the record.

**A bookkeeping defect that follows from it, found 2026-08-26 and not fixed.** The record's own inline
flags on those two entries still read *`[A]` to say if any of it should be marked or kept out* — the
question, sitting beside the answer. **`DEFECTS-carried-forward-20260825b.md` reads them as live and
lists the question as still unanswered.** It is not; §7 has the ruling and the quotation. *This is the
ordinary shape of the record's one hazard: it is append-only, so a superseded line cannot be edited,
and a later reader meets the question before the answer.* **Whoever appends next should append a line
saying so** rather than editing either.

## 10. DISCOUNTS — THIS SESSION AND THE ONES BEFORE IT

### On the 09-06 `Job52 handoff 09062026` session, which cut this file

**It read the whole outgoing handoff and formed views about everything in it. Discount all of them.**
That is the standing hazard of this job kind and it is worse here than for a doctrine session, because
a handoff session touches every section and nothing it writes was asked for by `[A]`.

**The judgment to distrust most: it decided what four sessions' work means, from their records rather
than from being there.** The whole 09-05 and 09-06 closures section is assembled from four set notes,
a closures file and a drafting instruction. **The sessions that heard him are citable and this file is
not.**

**Three things it decided without a ruling.** **It collapsed ten stacked heads**, on the reasoning
that every one of them has a row in the VERSION block and that everything still live in them is in
§5, §6, §8 and §10 — **it checked that claim by reading the heads and the body, and a successor may
find something it dropped.** **It promoted the master-name resolution to the head of §1.1** from
inside the kind 11 row, on the reasoning that a row naming a superseded master ships a dead file.
**And it left `CLOSURES-SITED-job32-20260830.md` unrepaired for the fourth session running**, on the
standing reasoning that a handoff session does not quietly edit another session's record.

**What it did NOT do.** It ruled no doctrine, wrote no book text and touched neither manuscript.
**It did not revise `DEFECTS-carried-forward-20260825b.md`**, left now by six handoff sessions on the
same reasoning. **And it did not put `[A]`'s own 08-21 question back to him** — *do we need thought
arcs anywhere else?* — **now carried by seventeen sessions.** *It brought him one thing instead, the
missing Z0 mark, on the standing instruction to deliver one thing at a time.*

### On the 09-06 `Job51` drafting session

**It wrote a section that did not exist**, which is a larger licence than applying closures, and the
account it wrote is `[A]`'s ruling turned into prose by `[C]`. **The two consequences it added are new
to the books and neither was ruled separately** — why a person further down is harder to help, and
what sets the size of a step — **both derived from the ruled comparison rather than stated by him.**
*It marked the second as NOT the same claim as the health-axis chapter's own *each level is healed on
its own*, which argues from order rather than size; a successor should check that they do not collide.*

### On the 09-06 `Job50` drafting session

**It applied four drafts of one sentence and `[A]` rejected all four**, and the closure ended with
nothing written. **That is the right outcome and it cost most of an exchange**; the diagnostic that
ended it is the style guide's own — delete it and see what the paragraph loses. **It did not repair
the 08-30 closures file's head**, which it found.

### On the 09-05 `Job49` doctrine session

**It read the record and is disqualified from drafting.** **`[C]` failed the same way twice in one
session and `[A]` caught both** — it generalized a sentence from the Nine's sketch and a sentence from
the four fates without reading the qualifying sentence governing each, **and both qualifiers were in
Chapter 15.** *That is the 08-29 pattern still running: the thinking lands in the crossing and
health-axis chapters and nothing carries back to where the reader meets it.*

**One thing it recovered rather than derived.** `Job48`'s parallel about the seeing edge reached no
file but a set note, in `Job48`'s own words; shown the note text, **`[A]` reconstructed the claim
himself.** *`[C]` had recommended dropping it.*

### On the 09-05 `Job48` drafting session, which cut the file this one supersedes

**It wrote about 2,200 words of new prose resting on claims nobody had ruled, and said so.** All nine
were carried by the tolerance ruling the next day, so nothing had to be rewritten — **but that is how
it turned out and not how it was written.** **Two of the three mechanisms it needed were its own
inventions and both were withdrawn.**

**It cut a handoff without folding and the debt reached ten.** **And it wrote its record marker as a
heading rather than in the canonical form**, which made `setcheck.py sweep` report a reach two appends
short until `Job49` restored the form.


### On the 09-02 `job38-drafting-20260902` session, which cut this file

**IT READ THE AUTHOR RECORD, AND EVERYTHING IT WROTE AFTER THAT POINT IS DISCOUNTED ACCORDINGLY.**
The reading was incidental — a `grep` for `deposits` over `*.md` that did not exclude the file — and
it was reported unprompted, with the extent measured and the one contaminating line named. **The
discount is not on the reporting; it is on the fact.** *Ch 13 was written before the grep and is
clean. Nothing written after it is prose: the architecture repairs, this file's edits, the record
append and the set note are bookkeeping, and a reader who wants to check them can check them against
files that are all in the set.*

**Ch 14 was not drafted, on `[A]`'s ruling `stop and cut`.** The cost is about half a session. **The
alternative was worse**: the session would have written Ch 14's closing move on a vocabulary
preference it learned from a file it was barred from, with nobody downstream able to tell.

**One `[C]` call in Ch 13 that nobody has checked.** `passage` for all three and `transformation` for
the two, which dissolves R3's residue about the word `transition` by never needing it. It was not put
to `[A]`. It is reversible — the word appears in one chapter — but it is a vocabulary decision made
by a drafting session, which is the kind of thing this project has had to undo before.

### On the 09-01 `Job36 doctrine 09012026` session, which cut the file before this one

**Three of its four rulings were `[C]`'s case with `[A]`'s assent, and the assent was short.** *yes*
for the arisings cut, *i agree* for the brake consequence, *deprecation* for the mark. **He argued
none of the three himself.** A later session weighing how much weight they carry should know that.

**The one he originated is the continuum**, and it arrived unprompted while he was being asked a
narrower question — `[C]` had recommended ruling fixation-Z0 one-faced and he replaced the frame
instead. **That is the ruling to trust most, and it is also the one that dissolved `[C]`'s
recommendation rather than accepting it.**

**Two pieces of the continuum block are `[C]`'s and are marked so where they sit:** the argument that
the two ends are where detachment is least pure, and the second-accumulation observation about layers
down and foundation up. **`[A]` ruled the first in; the second is unruled and recorded as a shape.**

**The unanswered cost is `[C]`'s question and he has not seen it** — the third floor's enthusiasm and
caution positions under a health axis read as the sight coordinate. It is recorded, not asked.

**What it did not do: it did not read this file through.** It read §1.0, §1.1's doctrine row, §5, §7
and the sections it edited. **Anything it says about a part of this file it did not open should be
treated as unchecked**, and a session that reads the file through owes it a fold.


### On the 09-01 `job35 handoff` session, which cut this file

**It read the whole outgoing handoff and formed views about everything in it. Discount all of them.**
That is the standing hazard of this job kind and it is worse here than for a doctrine session,
because a handoff session touches every section and nothing it writes was asked for by `[A]`.

**The judgment to distrust most: it decided what four sessions' work means, from their records rather
than from being there.** The whole 08-30 and 08-31 closures section is assembled from four set notes,
a closures file, a census and an architecture file. **The sessions that heard him are citable and
this file is not.**

**One thing it argued and `[A]` ruled on it.** The two deprecation marks came down because `[C]`
put the case that book 2 carries the same material unmarked. **That case is `[C]`'s**, and `[A]`
ruled on the strength of it rather than independently. *The reasoning is short enough to check: book
2's twin sentences are quoted at §5 and either can be read against the master in a minute.*

**Two things it decided without a ruling.** **A drafting row was written into §1.1**, which no
session had written, on the reasoning that `Job33` had to run on the doctrine set for want of one —
**the row is `[C]`'s and the kind's NAME is still `[A]`'s and still unminted**, so the row is headed
by the slot number and not by a name. And **the line-drift finding was written as a §1.0 rule
rather than as an open item**, on the reasoning that a session that follows a stale line number will
not know it did.

**What it did NOT do.** It ruled no doctrine beyond the two marks, wrote no book text and touched
neither manuscript. **It did not put `[A]`'s own 08-21 question back to him** — *do we need thought
arcs anywhere else?* — **now carried by eleven sessions.** **It did not revise
`DEFECTS-carried-forward-20260825b.md`**, left for the fifth handoff session running on the same
reasoning. **And it raised the sketch closing paragraph's retracted clause in this file rather than
with him**, because he had already been given two rulings this session and the standing instruction
is one thing at a time; **that is a deferral and somebody has to ask him.**

### On the 08-31 `job34` architecture session

**It found three of its own errors and they are all the same error.** Three passages reported absent
from book 2 on a vocabulary screen plus a reading of book 1's side alone, **two of the three
present**, and a fourth in the section-level pass. **The census now carries the split between
unit-level and passage-level checks as its method, and marks every passage-level finding from that
pass as needing re-reading before use.** *The corrections are worth more than the findings were: what
looked like 7,000 w of loss is so far mostly tightening.*

**Its placement of the sketches is `[C]`'s and `[A]` assented in one word.** The reasons are at the
site and are good, but **it creates work in Ch 13** — the notation's second sense — **which nobody
would have chosen for its own sake.** A successor may disagree with the placement without disturbing
anything he ruled.

**It read the record**, correctly for its kind, and **appended twice, one of them on another
session's behalf.**

### On the 08-31 `Job33` drafting session

**It received the wrong zip and the wrong zip verified clean.** *A clean `verify` says the set
matches its manifest. It says nothing about whether it is the right set, and this is now
demonstrated.* **The check that caught it was noticing which files were absent for the job.**

**Its five rulings existed only in files and in a conversation nobody else heard**, for a day, because
a text session cannot append the record. **That is the second time in three sessions.** *The 08-27
rule says every session appends before it ends and that a session which may not read the record
appends blind — a text session may not read it and CAN append it, so the rule was available and was
not used.* **Whoever writes the next drafting assignment should say so in the assignment.**

**It applied thirteen closure rows and rewrote book 1's fixation definition in place**, which is what
moved the line numbers. *Nothing about the rewrite is faulted; the line-stability guarantee was never
a rule anyone had ruled, and it was documented as an accident that had held.*

### On the 08-30 `Job32` doctrine session

**It read the record and is disqualified from drafting.** **Its six closures are the largest doctrine
result since the endeavor relocation and the biggest of them redefines a fixation** — which means
every earlier statement in this file about what a fixation is should be read against it, and this
file has not been swept for them. *`RULINGS-20260816b.md` carries the mark on R4; the sweep across
the notes has not been done.*

**It held the brake back from `[A]` and told him not to assent to an assembly.** *That is the second
session to do it and the reasoning is at §0 item 7. It is right, and it means the area has now been
deliberately left three times, which is a cost as well as a discipline.*

### On the 08-30 `Job31` architecture session

**It ran job 6 for the first time and formed a view of the whole of Parts 3 and 4.** **Discount its
ten calls the way this file's own are discounted** — they are listed by name at the architecture
file's §7 precisely so they can be revisited rather than inherited.

**Its one measurement worth repeating:** four ruling numbers cited by two files in the set appear in
the live rulings file zero times, because those files cite against a rulings file that is not live.
**Locate them by content.**

### On the 08-30 `Job30 handoff` session, which cut the file this one supersedes

**It read the whole outgoing handoff and formed views about everything in it. Discount all of them.**
That is the standing hazard of this job kind and it is worse here than for a doctrine session, because
a handoff session touches every section and nothing it writes was asked for by `[A]`.

**The judgment to distrust most: it decided what four sessions' work means, from their records rather
than from being there.** In particular the §6 account of what `[A]` ruled on 08-29 about backward
motion is assembled from two set notes and Part 9 of the repairs record; **the sessions that heard him
are citable and this file is not.** *And the reading that `Job28`'s L582 marker should lift is
`Job29`'s, not this session's and not `[A]`'s.*

**Two things it decided without a ruling.** **Job kind 11 is appended** on the strength of `[A]`
having accepted the mint on 08-29 without it ever reaching a job list — **the slot is his, the
appending is `[C]`'s**, and the name is deliberately left blank rather than half-minted. And **the
job-9 row now carries the eight figures**, reversing its own *no figures*, on `job28`'s argument that
a census whose subject can appear in a figure is not complete until the figures are in the set;
`Job29` had already deviated that way and flagged it for decision. **A successor may disagree with
either.**

**What it did NOT do.** It ruled no doctrine, appended nothing to the record, and touched neither
manuscript. **It did not revise `DEFECTS-carried-forward-20260825b.md`**, which now misdescribes three
items and has been left by three handoff sessions running on the same reasoning. **And it did not put
`[A]`'s own 08-21 question back to him** — *do we need thought arcs anywhere else?* — **now carried by
eight sessions.**

### On the 08-30 `Job29` drafting session

**It applied the Job18 ruling to BOOK 1 although its name says book 2 Ch 7.** Its grounds are stated
and are good — applying a prepared list with exact strings is what a text session may do, and the
ruling calls the two books one defect — **but it is a session widening its own scope, which is a
judgment and not a rule.**

**Its Ch 7 decision is the one to distrust most:** that Ch 7 describes the two faces and the crossing
mechanism stays in Ch 11. **`job28` explicitly declined to make that call twice**, on the ground that
it decides what Ch 7 is for and how it hands off; `Job29` made it from the manuscript rather than from
a ruling and `[A]` has not seen it in those words.

### On the 08-29 `job28` defects session

**A session in it cannot account for a two-thousand-word Part it produced.** See §7. **Its contents
were checked line by line and hold; its authorship is unverified.** *That is not a reason to distrust
the substitutions — every string was verified unique and read back — but it is a reason not to treat
anything in Part 9 as the reasoning of a session that can be asked.*

**It reversed two of its own calls inside the session** on `[A]`'s ruling — that the figure needed a
redraw and that the six backward transitions needed rewriting. **Neither was done, and both had been
argued for at length first.**

### On the 08-29 `job27` defects session

**It ran the metaphor pass and the tools work and eight rulings in one day.** *`[A]` chose to run the
metaphor pass there rather than hand it on.* **Its census method failed twice inside that pass** —
missing words, then missing inflections, then a stemmed rescan that returned mostly noise — **and it
says so itself.** The lesson it drew is the one to carry: **a count is a starting list, never a total,
and never a target to work down to. The passage has to be read.**

### On the 08-29 `Job26` doctrine session

**It read the record and is disqualified from drafting.** **It cut a handoff without folding**, said
so on the file's face, and left its own two rulings outside the body — correctly under §7, and the
debt is discharged here.

### On the 08-29 `job25` drafting session

**Its set note reported drafting that was never written to the file.** The practice that follows is at
§7. **Everything else it produced is sound and `OPEN-from-job25-20260829.md` is live**, but a session
reading that note alone would believe book 2 contains material it does not.

### On the 08-27 `Job22 handoff` session, which cut `HANDOFF-20260827.md`

**It read the outgoing handoff through and folded the addendum, which is what §7 says earns a
successor.** Its exposure is elsewhere.

**The judgment to distrust most: it decided what `[A]`'s four-term answer closed.** He answered one
question, in three words. **This session decided that the answer closes the App G item's first half,
changes the chain's CLAIM rather than its exposition, and creates a derivation task rather than
completing one** — and it recommended splitting the item rather than closing it. `[A]` agreed to the
split. **The claim-level reading is `[C]`'s, argued from G.1's own omission paragraph, and a successor
may disagree with it without disturbing the ruling.** *Note the direction of the error if it is wrong:
the folded addendum reached the OPPOSITE reading from the same words — mostly exposition, with one
substantive consequence. **Two `[C]` sessions, two readings, one ruling.** The disagreement is recorded
rather than resolved, and §5 states both.*

**Second: it struck an open item on its own authority.** The App G *top and exit* half is marked closed
here because the 08-23 Level 0 ruling covers it. **Nobody ruled that it covers it.** The reasoning is
at §5 and is short enough to check.

**What it did NOT do.** It ruled no doctrine, appended nothing to the record, and touched neither
manuscript. **It did not revise `DEFECTS-carried-forward-20260825b.md`**, which now misdescribes three
items — §6 gives the reasoning for leaving it, and that is a judgment. **And it did not put `[A]`'s own
08-21 question back to him** — *do we need thought arcs anywhere else?* — **now four sessions carried.**

### On the 08-26 `job21-doctrine` session

**It read perhaps a fifth of the handoff, in targeted sections, and correctly cut an addendum rather
than a successor.** That addendum is folded here.

**`[C]` faults it recorded on itself, and one recurred within the session.** It used the retired
backward framing twice — once taking it from `RULINGS-20260816.md`, once describing book 2's Ch 7
headings without marking them as the stale text under discussion. It **over-read `[A]`'s decision
criterion** and built structure on it before he narrowed it twice. It offered a starvation reading of
the spoiled arrivals **that the record had already contradicted on 08-25**, framing as open a question
the record had answered. And it **recommended amending the resolution-rate note, then reversed** on the
pointer cost.

**The largest is the writer 2 chain, and it is a reasoning fault rather than a slip.** It measured the
extract correctly, reported identical counts, **and then drew the opposite conclusion from its own
measurement** — treating a re-cut as new when the numbers said it was not, minting a spurious name, and
telling `[A]` to quarantine the good file. *Identical counts across a re-cut should have prompted a
hash before a new name was minted.* **Everything it produced about the three outcomes is UNRULED and
says so; do not cite that note as doctrine.**

### On the 08-26 `job20-handoff` session

**It did not read the outgoing handoff through, and §7 says that reading is what earns a successor
rather than an addendum.** What it cut is a lettered revision by surgical edit — five rows re-pointed
and three sections rewritten, everything else untouched byte for byte — on the reasoning that the file
it edited was hours old and had itself been cut by a session that read its predecessor whole. **That
is a judgment and not a rule, and a successor may disagree.** The exposure is exact: **this session
has checked none of the other 2,600 lines against anything**, so whatever staleness job 19 did not
catch is still here, and this session cannot say it looked.

**Two things it decided without a ruling.** The repaired note takes a **letter rather than a date**,
on the 08-23 precedent that a file cut within a day and carrying no rulings takes a letter — and the
same reasoning gives this handoff its own letter. And **it edited another session's procedural
record**, which job 18 declined to do *silently*; it is recorded here, in §1.0 and in the set note,
which is what makes it not silent. *A handoff session's subject matter is this apparatus, which is the
argument for it being the right session to do it — but that argument was `[C]`'s and `[A]` agreed to
the edit rather than ruling the principle.*

**What it did NOT do.** It ruled no doctrine and appended nothing to the record. **It put neither of
the two questions `[A]` is owed back to him** — whether the retraction reaches the Z+ sketch, and *do
we need thought arcs anywhere else?* Three sessions have now carried both without asking. **Appendix G
and Riso's chain is not started for the fourth session running**, and this session offered `[A]` the
choice of taking it and then spent itself on bookkeeping instead.

### On the 08-26 `job19-handoff` session, which cut the file this one supersedes

**It read the whole outgoing handoff and formed views about everything in it. Discount all of them.**
That is the standing hazard of this job kind and it is worse here than for a doctrine session, because
a handoff session touches every section and nothing it writes was asked for by `[A]`.

**Two things it decided without a ruling.** The file takes a **date and no letter** — 08-26, two days
on, collecting three sessions' work — which follows the precedent set on 08-23 and is not ruled. And
**§0 item 9's row in §1.1 is written as a shape rather than a list of filenames**, on the reasoning
that a handoff set's contents change every time; that is a `[C]` judgment and a successor may
disagree.

**What it did NOT do, and each is a real gap.** It ruled no doctrine and asked `[A]` for nothing
beyond the job kind. **It did not fix the screen defect in the recovery note**, which is one line
break and has now been deferred by two sessions. **It did not put the two questions `[A]` is owed back
to him** — whether the retraction reaches the Z+ sketch, and *do we need thought arcs anywhere else?*
**And it appended nothing to `AUTHOR-RECORD.md`**, correctly, since it deliberately did not read it and
`[A]` said nothing this session that was not already filed — but that means the open question of
whether cutting a handoff should be **gated** on the record having been appended to is still open, and
this session is now an instance on the other side of it.

**The one to distrust most: it re-measured the manuscripts and then wrote conclusions from the
measurements.** The counts and occurrence numbers in §2 and §5 are `grep` and `wc` output and are
sound. **The readings around them are not measurements** — in particular the claim that the retracted
clause now has a forward reference pointing at the sentence marked for deletion is `[C]`'s reading of
two sentences, and `[A]` has not seen it.

### On the 08-24 `Job15` tools session, which cut this file's predecessor

**It read `AUTHOR-RECORD.md` in full and is disqualified from drafting.** That is the file's own rule
and it applies to a tools session exactly as to any other.

**It changed two tools mid-session, which is the thing the 08-21 session declined to do.** The
recorded reason for deferring was that changing a tool invalidates the set that has just verified
against it. That cost was paid — the manifest was re-cut after every tool change — but the precedent
was set aside, and a successor should know it was set aside rather than observed.

**Three judgments it made without a ruling.** `quotecheck.py` and `setcheck.py` keep their bare
names through a version change, on the reasoning that the revision-takes-a-letter rule has always
governed dated documents and the tools have never carried dates. The handoff took a new date and then
four letters in one day. And `HANDOFF-20260823b.md` and `c` were superseded inside the session
without ever being quarantined, on the reasoning that they never left it. **Any of the three could be
ruled the other way and none is load-bearing.**

**The one to distrust most: it adjudicated the backfill itself.** About twenty candidate quotations
were narrowed to seven by `[C]`'s reading of which sources explicitly attribute words to `[A]`.
Nobody checked that reading. **The failure mode is not a missing quotation but a misattributed one**,
and this file is what everything else is checked against. *If any entry in the BACKFILL section is
not `[A]`'s, it should be struck on sight and the marker updated to say so.*

**What it did not do.** No doctrine, no text, no architecture. It did not open §5's repair list, and
**job 3 remains the most overdue job in this file.**

### On the 08-23 `2g` session, which cut the file this one supersedes

**It spent the whole day arguing about the circle** — the leans, the arrows, the classical comparison,
the top of the health ladder. **It must not be given the depth-and-threshold question**, and neither
should any successor that reads this file straight through and forms a view from it. That is the
standing reason the question is reserved, and this session is a clear instance of it.

**Its `[C]` constructions that were withdrawn the same session, recorded so a successor does not
resurrect them:** that the lean and the temporary offset are the same relation with two applications
(`[A]` corrected it — they are two offsets differing in permanence); that the correspondence has a
lean sliding down the Levels (**`[A]` had already said the Level characteristics are not
orientations, and `[C]` re-imported the identification two turns later to build a contradiction on
it**); and that liberation would have to become a position on the ladder (the premise that generated
Level 0 fails instead).

**One `[C]` habit worth naming.** `[A]` twice stated a thing and `[C]` treated it as a hint to go and
verify — *"i'm saying that also"*, *"not asking. you discovered the problem."* **When `[A]` states
something, it is a statement.** Checking it against the text is not free: it spends a turn and it
reads as doubt.

**On the measurement, which was the session's good work.** Every finding came from `grep` over book 1
rather than from summaries — the seventy `step` lines, the absence of *leans are what move a person*
from Ch 11, L2463, the five transit sites. **Nothing was quoted from a note about book 1.**

### On the 08-21b `2f` session, which cut the file this one supersedes

**It ruled six times in one day and every argument it built arrived on request. Discount all of it
and read the provenance marks in §6.** In particular: the hybrid reading of *eager / chastened /
ripened* is `[C]`'s; the account of the blindness loop moving both weight and permanence by preventing
completion is `[C]`'s join; and the standing-versus-arriving distinction was `[C]`'s framing before
`[A]` restated it in three lines that are better than the framing.

**Three of its answers were of the form "the question does not need answering"** — the two scales, the
switch-or-width, and arc occupancy. **Three dissolutions in one day from one session is the shape the
sharpening rule names, and the session said so at the time.** What partly protects the third is that a
measurement corrected the record rather than a construction tidying it.

**`[C]` was wrong three times and each was caught by measurement or by `[A]`.** It offered "three
moves versus three places" when the alternative is three places on one traversal; it proposed that the
fixation reaches arisings only through deposits, which is tighter than what `[A]` said; and it derived
that Opposite needs a quarter by assuming the two leans equal, which the figure disproves. **It also
used a word — *stations* — that is neither book 1's nor `[A]`'s, and had to be asked what it meant.
That is the standing vocabulary fault, in the session that recorded the standing vocabulary fault.**

**One thing it did right and should be repeated:** when `[A]` gave a long, retracted-in-part passage,
it wrote the whole passage into the record verbatim **before** developing any of it, and named the
three parts it was not developing. Two of those three are still undeveloped and are listed in the
record.

### On the 08-21 `2e` session, which cut the file this one supersedes

It spent the whole day on fixations and arcs and it produced a great deal on request. **Discount all
of it and read the note's provenance marks.** In particular: the reading that book 1's stopping was
never general is `[C]`'s, though its measurement is not; the account of caution stacking where nothing
pulls toward comfort is `[C]`'s join of `[A]`'s argument and book 1's trap paragraph, and is the tidy
kind produced on request; the split between abandoned desires and jumped-over fear is `[C]`'s join of
two things `[A]` said; and the claim that starting and progressing are ordered differently is `[C]`'s
and one day old.

**Two corrections to ruled material were proposed by `[C]` on its own initiative and both were
wrong** — a realm that did not need moving, and a re-filing that displaced a reading already `[A]`'s.
Neither was asked for and `[A]` caught both. **The session also used an internal label in conversation
after the file's own warning against it**, and had to be asked what it meant.

**It did not take the reserved depth-and-threshold question** and walked up to it three times. See
§0 item 8; the flags for that session are in the note's §5.2.

### On the 08-20 `2d` session

**On the `2d` session, which cut a predecessor of this one.** It spent the day on the arcs and on what a fixation is.
Two of its constructions arrived on request and should be discounted: the argument that an arc's cut at
detachment is *forced* rather than chosen, which is `[C]`'s reading of book 1 and not `[A]`'s claim;
and the convergence of three routes on where each fixation sits relative to an arc, which is flagged in
place as not three findings. **It did not take the reserved depth-and-threshold question, and a session
holding the ruling that an enthusiasm fixation leaves nothing behind should not** — that ruling points
straight at it.

### On the 08-20 `2c` session

This session was inside the Z material, the descent, and the aggregate all day, and it ruled in all
three. **Its constructions should be discounted the way the drafting session's and the 08-18
session's were.** Two in particular: the two-and-one remedy cross-check at §9 is `[C]`'s and arrived
on request, which is the shape the sharpening rule names; and the reading that direction was never
load-bearing in the winding-structure ruling was `[C]`'s reasoning, accepted by `[A]` on the strength
of it rather than independently arrived at.

**The depth-and-threshold question in particular should not go to a session like this one.** It is
where the Z material and the health axis meet, and a session that has spent a day arguing that the
levels are markers has a view about it already.

---

## MANIFEST ROW

| File | md5 | words | bytes | scope |
|---|---|---|---|---|
| `HANDOFF-20260906.md` | generated at set-cut | | | set |

**A file cannot carry its own md5**, so this row is left for `setcheck.py manifest` to fill. That is
the general rule and it is why md5s are never written by hand.

**`quotecheck.py sweep` and `quotecheck.py quotes <this file> rev2-0814t.md` are run at set-cut, and
every failure is declared rather than fixed. The book 1 source is `rev2-0814t.md`, cut 2026-09-04 —
a check run against any earlier letter is a check against a superseded file, and there are now twelve
of them.** *Run `sweep` with `--exclude` for the author record: `Job27` ran it without and had the
record quoted back at it. A guard that must be remembered is not a guard, but until the tool defaults
it, remember it.* **RUN AT THIS CUT, 2026-09-01, and every failure is declared rather than fixed.**
`quotecheck.py quotes HANDOFF-20260901b.md rev2-0814n.md`: **2 verified, 5 failed, 1 skipped — unchanged from the parent, since this session added no book 1 quotation. The five failures are pre-existing and declared, not fixed.**
**`quotecheck.py sweep` run at the same cut: orphans unchanged.**
`quotecheck.py quotes HANDOFF-20260901.md BOOK2-20260831.md`: **1 verified, 6 failed, 1 skipped.**
**Run both and read them together — line citations verify per book, and running one source over both
is what produces apparent failures.** Every quotation in this file is accounted for: the **version
block** quotes nothing and says so; the **subject-of-a-sentence voice rule** is this project's own,
recovered by `[A]`, and says so at §4; **book 2's Ch 4 caution sentence** verifies against
`BOOK2-20260831.md`; **book 2's old Ch 7 fixation pair** is quoted at §5 as the superseded string in
a block headed DO NOT APPLY FROM THIS BLOCK and **no longer occurs in either book**, which is the
check working; and **`[A]`'s own sentence on the origin of the fixation** is his and verifies against
`SET-NOTE-from-job26-20260829.md`, **which is not in this set** — *that is the one failure with no
in-set source, and it is the shape §6 names: an answer and the file that holds it travelling apart.*
**Book 1's two — the Z-to-A transitions passage and the engagement-classified-by-its-object sentence
— both verify.**

*Retained, the 08-30 run:* **and every failure is declared rather than fixed.**
`quotecheck.py quotes HANDOFF-20260830.md rev2-0814l.md`: **2 verified, 5 failed, 1 skipped.** The
five: the **version block**, which quotes nothing and says so; the **subject-of-a-sentence voice
rule**, which is this project's own and says so at §4; **book 2's Ch 4 caution sentence**, which is
book 2's and **verifies against `BOOK2-20260830c.md`** — checked; **book 2's old Ch 7 fixation pair**,
quoted at §5 as the superseded string in a block headed DO NOT APPLY FROM THIS BLOCK, **which no
longer occurs in either book because it was deleted on 08-30** — that is the check working; and
**`[A]`'s own sentence on the origin of the fixation**, which is his and verifies against
`SET-NOTE-from-job26-20260829.md`. *`quotecheck.py sweep` was also run over the whole set with
`--exclude AUTHOR-RECORD.md`: 160 quotations of six or more words, this file orphaning two of its
seven, both named above.* **Line citations verify per book** — book 1 quotes against `rev2-0814l.md`,
book 2 quotes against `BOOK2-20260830c.md`; running one source over both is what produces apparent
failures.

*Retained, 08-24:* the
same check against the then-current book 1, with every failure declared, below the 08-21 note. *Original 08-21 note, retained because its
reasoning is the reusable part:* **`quotecheck.py quotes HANDOFF-20260821b.md rev2-0814b.md` was run:
2 verified, 3 failed, and all three failures are declared rather than fixed.** The version block quotes nothing and says so; the
subject-of-a-sentence rule is this project's own, recovered by `[A]`, and says so; and the third is
book 2's Ch 7 sentence that `[A]` ruled out, **which is book 2's and cannot verify against book 1**.
**Both blockquotes in this file that do claim book 1 pass.**

*Retained because the reasoning is the reusable part:* that check used to be **worth less than it
looked**, because a source whose quotations are line-wrapped could not be checked at all and every
file this one quotes except book 1 is line-wrapped. Those quotations were verified by `grep` instead.
**Both defects were fixed on 08-24 and every such check was re-run** — see §7 for the fixes and §6 for
what the re-run turned up. **Run `quotecheck.py sweep` at set-cut from now on; `grep` is no longer
the fallback.**

*A drafting note that saved a false failure here: a `>` used as a callout box rather than as a
quotation fails the check like a fabricated quote. One such box was rewritten as bold text. **Use
blockquotes only for quotations.***

**`AUTHOR-RECORD.md` fails this check on every blockquote, by design**, and says so on its face: it
quotes `[A]`, not the book.

**THE NEXT SET. The rows at §1.1 are the authority for what goes in it; this section says only what
CHANGED at this cut, which is what an assembler can get wrong.**

**AT THIS CUT: both masters move again, the rulings file and three notes take letters, five new files
join the rows, a drafting row exists for the first time, and a guarantee this file used to give is
WITHDRAWN.**

| File | What changed | Action |
|---|---|---|
| `HANDOFF-20260906.md` | **this file — new.** A date and no letter: the fold that ten sessions owed | **replaces `HANDOFF-20260905.md`; quarantine it as `SUPERSEDED__live__`** |
| `rev2-0814t.md` | book 1, **57,115 w, md5 `a6d71b1e`, 2,595 lines** | **replaces `rev2-0814q.md` and `r` — quarantine them.** **Locate by content; the line numbers moved again** |
| `BOOK2-20260906b.md` | book 2, **30,885 w, md5 `d2ef43ce`, 1,421 lines.** The intervener account is in it | **replaces `BOOK2-20260904.md`, `b`, `BOOK2-20260905.md` and `BOOK2-20260906.md` — quarantine all four** |
| `STYLE-GUIDE-20260906.md` | **the live style guide**, carrying the 09-05 rules about what a reader can hold and the 09-06 animate-verb rule | **replaces `STYLE-GUIDE-20260904.md` and `…-20260905.md` — quarantine them.** **Into every text set, read before any prose is written** |
| `CLOSURES-SITED-job49-20260906c.md`, `DRAFTING-aligned-types-20260906b.md` | **both marked applied on their faces.** Records, not queues | **into the job 7 and kind 11 rows** |
| `SET-NOTE-from-job48-20260905b.md` … `SET-NOTE-from-job51-20260906.md` | the four folded here | **all four stay in the set and stay citable.** *This file summarises them and is not citable for what they hold* |

*Retained from the 09-01 cut, because a successor will meet the names:*

| File | What changed | Action |
|---|---|---|
| `HANDOFF-20260901.md` | **the 09-01 fold.** A date and no letter: two days on, and it folded four sessions | **replaced `HANDOFF-20260830.md`; quarantine it as `SUPERSEDED__live__`** |
| `rev2-0814q.md` | book 1, **57,180 w, md5 `27f90a58`, 2,594 lines.** *`p`'s md5 was `892912c6`; three deprecation marks were repointed from Ch 11 to Ch 15 on 09-02 and nothing else changed* | **replaces `rev2-0814n.md` — quarantine it.** **The line-count guarantee is broken; locate by content — §1.0** |
| `BOOK2-20260902b.md` | book 2, **27,575 w, md5 `6ef4edb7`, 1,307 lines. PART 3 IS IN IT AND THE Ch 15 PLACEMENT IS APPLIED** | **replaces `BOOK2-20260902.md` — quarantine it.** **Every book 2 line-number citation made before 09-02 is stale; locate by content** |
| `BOOK2-PART34-ARCHITECTURE-20260902c.md` | **10,738 w, md5 `049f13a5`.** The renumber discharged at seventy-one sites; the handles are final numbers. **SUPERSEDED the same day by `…-20260902d.md` — see this table's last rows** | **replaces `BOOK2-PART34-ARCHITECTURE-20260902b.md` — quarantine it** |
| `OPEN-from-job41-20260902.md` | **new.** The rearrangement question, whole, addressed to §0 item 6 | **into the job 6 row and the job 7 row** |
| `HANDOFF-20260902d.md` | **this file — new.** A letter: same day, `b` and `c` taken | **replaces `HANDOFF-20260902c.md`; quarantine it as `SUPERSEDED__live__`** |
| `RULINGS-20260816b.md` | **8,437 w, md5 `927bfb47`.** R4 superseded a second time, R10a narrowed | **replaces `RULINGS-20260816.md` — quarantine it.** It is named in many places in this file that are history and are correct as history |
| `NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md`, `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md`, `OPEN-from-job25-20260829b.md` | **each takes a letter for the 08-30 closures** | **replace the `b` files — quarantine those** |
| `BOOK2-PART34-ARCHITECTURE-20260902b.md` | **the live Part 3/4 architecture. Three dates in three days: `…-20260901` (Job36), `…-20260901b` (Job37), `…-20260902` (job38, repairing the three lines the letter ruling falsified). Quarantine both parents** | **replaces `BOOK2-PART34-ARCHITECTURE-20260831.md` and `…-20260830.md`, and through them `BOOK2-PART3-PROVISIONAL-20260815.md` — quarantine all three.** **The provisional's §3A appendix proposal is NOT superseded** |
| `CLOSURES-SITED-job32-20260830.md`, `CENSUS-book1-into-book2-20260901.md`, `SKETCHES-rewrite-by-author-20260901b.md` | **three new file kinds, all live** | **into the job 7 row; the census and the sketches into job 6's as well.** The closures file is a record, not a queue |
| `SET-NOTE-from-job31-20260830.md` … `SET-NOTE-from-job34-20260831.md` | the four folded here | **all four stay in the set and stay citable** |
| the drafting row | **§1.1 has one for the first time, as job kind 11** | **the row is `[C]`'s; the kind's NAME is `[A]`'s and is still unminted** |
| `BOOK2-PART34-ARCHITECTURE-20260902e.md` | **ADDED 2026-09-02 by `Job42 architecture 09022026`. 14,160 w, md5 `00606c1b`.** `[A]`'s ruling on where the fixation descriptions live, carried out as a ruled placement at Ch 15; Ch 16 gives them up; two stale lines at §6 corrected | **replaces `BOOK2-PART34-ARCHITECTURE-20260902c.md` — quarantine it.** **Nothing in the master is touched; the placement is a specification the next session applies** |
| `rev2-0814q.md` | **ADDED 2026-09-02 by `Job42 architecture 09022026`.** Three deprecation marks repointed from *book 2 Ch 11's crossing account* to Ch 15, on `[A]`'s authorization. **The handover said two; there are three** | **replaces `rev2-0814p.md` — quarantine it.** **57,180 w and 2,594 lines both unchanged**, the three strings being of equal length, so no citation moves |
| `MARKED-chapters-for-the-Ch15-placement-20260902c.md` | **ADDED 2026-09-02 by `Job42`, third cut.** Ch 11, 13, 14, 15 and 16 printed whole with every move marked where it leaves and where it lands, plus four MINIMAL STATEMENT OWED marks, two REWRITE ON ARRIVAL marks and three SAID TWICE marks | **`[A]`'s to read, NOT to apply — no wording is written in it.** *The applying session works from the architecture file's Ch 15 section; this file is the same decision made legible* |
| `OPEN-from-job41-20260902.md` | **SPENT.** The one question it carries is answered by the ruled placement | **it stays in the set as the record of what was found**, and it is no longer an input to any row |

*Retained from the 08-30 cut, because a successor will meet the names:*

| File | What changed | Action |
|---|---|---|
| `HANDOFF-20260830.md` | the 08-30 fold | **replaced `HANDOFF-20260829.md`; quarantine it as `SUPERSEDED__live__`** |
| `rev2-0814l.md` | book 1, **56,362 w, md5 `26e3d1cc`, 2,566 lines.** Eight revisions since `c` | **replaces `rev2-0814c.md` through `k` — quarantine all of them.** Carries five `[DEPRECATED …]` markers; see §2 |
| `BOOK2-20260830c.md` | book 2, **17,669 w, md5 `0fe6ff3e`, 868 lines** | **replaces `BOOK2-20260825.md`, `BOOK2-20260829.md` through `n`, and `BOOK2-20260830.md` and `b` — quarantine all of them** |
| `REPAIRS-job16-book1-defects-20260825g.md` | **12,435 w, ten Parts, four sessions** | **replaces `d`, `e` and `f` — quarantine them.** `f` is a byte-exact append onto `e`, verified |
| `SET-NOTE-from-job25-20260829.md`, `SET-NOTE-from-job26-20260829.md`, `SET-NOTE-from-job27-20260829b.md`, `SET-NOTE-from-job29-20260830.md` | the four outgoing set notes folded here | **all four stay in the set and stay citable.** *This file summarises them and is not citable for what they hold.* There is **no set note from `job28`** — its record went into Part 9 of the repairs record instead |
| `OPEN-from-job25-20260829.md` | **1,696 w, still live** | **stays. Its §3.2 seeing census and its §4 backward census are unspent** and are the input to the naming pass |
| the eight figures | **now in the job-9 handoff set as well** | see §1.1's job 9 row. **Still excluded from BOOK 2 DRAFTING sets** — that is the only scope the exclusion ever had |
| `BOOK2-Ch1-4-for-writer2-20260821.md` | **REVERSED. It IS stale now, and this time by measurement** | **re-cut and hash it before anything goes to writer 2.** *This file said in bold that it had never been stale; that was true until 08-29.* See §0 item 4 |
| `AUTHOR-RECORD.md` | **35,695 w, twenty-seventh append** — *this row read 28,345 and the seventeenth until 2026-09-02, five appends behind §1.1, and it was corrected by `Job43`* | **replaces every shorter copy.** No rename — this file is never superseded |

*Retained from the 08-27 cut, because a successor will meet the names:*

| File | What changed | Action |
|---|---|---|
| `HANDOFF-20260827.md` | the 08-27 fold | **replaced `HANDOFF-20260826d.md` AND `HANDOFF-ADDENDUM-20260826d-job21.md`; quarantine both as `SUPERSEDED__live__`.** The addendum ceased to be live — that is what a fold is |
| `NOTE-the-three-outcomes-and-the-burial-reflex-20260826b.md` | 4,438 w, new 08-26. **Nothing in it is ruled** | **into the job 7 row.** Its first letter is quarantined and fires the screen — drop that one. **Read its §11 before its §7** |
| `SET-NOTE-from-job21-20260826.md` | the outgoing session's | in the rows already; **it is stale on the addendum's letter and count — see §6** |
| `BOOK2-Ch1-4-for-writer2-20260821.md` | **nothing. It was never stale** | **the regenerate-or-discard warning below is WITHDRAWN.** Verified byte-identical to a re-cut against the current master. Do not quarantine it, do not re-mint it |
| `AUTHOR-RECORD-ADDENDUM-20260826.md` and `AUTHOR-RECORD-ADDENDUM-20260826b.md` | **BOTH APPENDED 2026-08-27. The marker says they landed** | **stop carrying them.** Quarantine both as `SUPERSEDED__live__`; the record itself now holds their content |
| `AUTHOR-RECORD.md` | **18,733 w, marker `2026-08-30 · Job29 book 2 ch 7 drafting 8-30` (eighth append)** — *correct as history; the reach is now 25,475 w at the thirteenth append* | **replaces every shorter copy.** No rename — this file is never superseded and carries no date, so a stale copy is simply short |

*Retained from the 08-26 cut, because a successor will meet the names:*

| File | What changed | Action |
|---|---|---|
| `HANDOFF-20260826.md` | the 08-26 fold | **replaced `HANDOFF-20260824f.md`; quarantine that as `SUPERSEDED__live__`** |
| `rev2-0814c.md` | **book 1's first revision ever**, 56,237 w, cut 08-25 when the eighteen repairs went in | **replaces `rev2-0814b.md` — quarantine it.** It is named in four rows at §1.1 in the outgoing file and in three history lines below; the rows are corrected, the history lines are correct as history |
| `BOOK2-20260825.md` | 17,455 w, cut 08-25. **A date rather than a letter**, being a week on | **replaces `BOOK2-20260818c.md` — quarantine it.** *This row used to add that `BOOK2-Ch1-4-for-writer2-20260821.md` was two revisions stale and should be regenerated or discarded. **That was an inference, never a measurement, and it is false** — the extract is live. Struck 2026-08-27* |
| `AUTHOR-RECORD.md` | **9,724 w**, marker `2026-08-25 · Job18 doctrine 8-25`. Longer, same name, by its own rule | **replaces every shorter copy, INCLUDING THE ONE IN `[A]`'s OWN DIRECTORY**, which was last known to hold 4,641 words. The 5,921-word hybrid and the 8,589-word copy should both be destroyed |

*Retained from the 08-30 cut:* **Six files were newer than that handoff and not in its §1.1 rows at
all**, which is the defect that made that cut necessary: `RULINGS-job18-20260825.md`,
`DEFECTS-carried-forward-20260825b.md`, `REPAIRS-job16-book1-defects-20260825g.md`,
`NOTE-resolution-rate-and-the-descent-20260825.md`, the recovery note,
and the outgoing session's `SET-NOTE-*`. **They are in the rows now.**

**And the recovery note no longer fires on the screen.** It was repaired on 08-26 and is
`RECOVERY-NOTE-20260825b-procedural-changes.md`; see §1.0. It is the one file that explains how to
undo the 08-25 changes, and for two days the screen told an assembler to drop it.

*Retained, because the reasoning recurs:* the 08-24 cut noted that **both tools** kept their bare
names through a version change — see §10, that naming is a `[C]` judgment and unruled. *The unlettered
level-1 note that once arrived as a twentieth file is not a set member and never was.*

**A bookkeeping defect, and it is why the name of a set matters. NOT FIXED, and it has now survived
every set-cut since 08-23 — seven of them on 08-24 alone — because it lives in archived folders that
no session has reason to open.** *It will keep surviving until someone opens those folders on
purpose; it is not going to be caught in passing.*
`MANIFEST-20260821c.md` and `MANIFEST-20260821d.md` both carry the label
`Job14 doctrine 2g session 8-21`. **The session was `Job14 doctrine 2g session 8-23`** — `[A]` named
it, and on 2026-08-23 he ruled that **he names the session, and the manifest label yields to him**.
The rule that a session reads its name off the label was aimed at a session inventing a name or being
handed one that does not match the set in hand; it does not outrank `[A]`. **Consequence to watch:
matching an archived set folder to the session that used it by label alone fails for those two.**

*Two senses of "new" and they must not be run together. **A revision takes a new lettered name** —
a file with different bytes never keeps a name it has already had. **The author record is the single
exception**, by its own rule: append-only, no date, one name forever. Calling it a revision invites
a successor, which is the one thing that file must never have.*

**Notes on individual files, carried and current:**

| File | Note |
|---|---|
| `AUTHOR-RECORD.md` | **41,888 words**, marker `2026-09-06 · Job52 handoff 09062026` (thirty-third append), parent 41,674. **Not a revision and it takes no letter:** this file always keeps the same name. **It TRAVELS in every set and is not READ by a text session** — changed 08-25. Append-only, never re-cut, no date on the name. **The session appends to it before ending — changed 08-27; see §1.1** |
| `NOTE-fixations-arcs-and-the-two-scales-20260821.md` | read before taking anything. **Its §8 repair list was applied on 08-25** and is now a record, not an instruction |
| `NOTE-level-1-and-the-summit-20260821b.md` | its internal-half-step claim is ruled and Level 0 is abolished on the strength of it. **Replaces the `20260821` file; quarantine that one** |
| `RULINGS-job18-20260825.md` | **Part 1 is for a text session and carries exact strings. Part 2 is for an architecture session and changes no text.** Read §1.5 before touching the sixty-second paragraph |
| `DEFECTS-carried-forward-20260825b.md` | **NOW MISDESCRIBES THREE ITEMS — read §6 before it.** It lists the App G item's two halves as open; **both are closed**, one on 08-23 and one on 08-26, and it says the four-term question has never been put to `[A]` when he answered it. **Only its item 2 is genuinely open.** Its housekeeping also says the personal-entries question is unanswered; answered 08-24 — see §9. Its screen defect is fixed. **Not revised, deliberately; `[A]` decides who revises it.** Supersedes `DEFECTS-carried-forward-20260825.md` — rename that, do not delete it |
| `REPAIRS-job16-book1-defects-20260825g.md` | **ten Parts, four sessions.** Parts 1–5 are `Job16`'s original eighteen; **Part 6–7 `Job27`, Part 8 the book 2 metaphor pass, Part 9 `job28`'s backward pass, Part 10 `Job29`'s Ch 7 work.** Its Part 4 lists four bookkeeping items and none is fixed. **Quarantine `e` and `f`; `f` is a byte-exact append onto `e`, verified** |
| `NOTE-resolution-rate-and-the-descent-20260825.md` | two open derivations, not rulings |
| `NOTE-the-dwell-and-the-brake-20260901.md` | **`Job23`'s product. Two rulings in its §1; NOTHING ELSE IN IT IS RULED.** Everything in §3–§5 follows from the blindness mechanism and falls with it. **Read §1 before citing anything** |
| `RECOVERY-NOTE-20260825b-procedural-changes.md` | **repaired 2026-08-26; it no longer fires.** The literal stood whole at two lines, not the single line 52 that three files named. **Supersedes `RECOVERY-NOTE-20260825-procedural-changes.md` — rename that, do not delete it** |
| `RULINGS-20260816b.md` | **THE `b` LETTER. It gained R4's second supersession and R10a's narrowing on 08-30/08-31 — read the mark on R4 before anything that turns on what a fixation is.** *Two live citations of R4 need re-grounding: R4 as what makes 3 and 6 the pure cases, and R4 as the account reserved for a later chapter.* **And it still carries a withdrawn framing with no marking on it — see §7 before reading it.** *the stepwise descent = the long way around (the landmarks' backward walk)*. Corrected twice inside the project and once inside the file itself; **do not edit it to fix that** |
| `NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md` | **THE `c` LETTER, and its status changed: its §6 now carries the RULED four-fate table above the superseded three-outcome one.** The rest of it is still unruled and says so on its face.** **Read its §11 before its §7**, which §11 corrects. **Its §4 was CORRECTED on 08-29** for the ruling that the burial reflex is fed continuously; the file in the set carries the correction. Supersedes the unlettered file; quarantine that one |
| `AUTHOR-RECORD-ADDENDUM-20260826.md`, `AUTHOR-RECORD-ADDENDUM-20260826b.md` | **appended 2026-08-27 and no longer live.** Quarantine both. **No session cuts a file of this shape again** — since 08-27 the session appends to the record itself; see §1.1 |
| `SET-NOTE-from-job25-20260829.md` | **its WHAT WAS DRAFTED section describes Ch 11 material that was never written to the file** — `Job27` found it and `[A]` supplied it separately. Read the section knowing that |
| `SET-NOTE-from-job26-20260829.md` | **carries `Job26`'s two rulings**, which its own handoff did not fold. Folded here now; the note stays citable |
| `SET-NOTE-from-job27-20260829b.md` | **eight rulings, the metaphor scope ruling, and the tools work.** Supersedes `SET-NOTE-from-job27-20260829.md` |
| `SET-NOTE-from-job29-20260830.md` | **carries `job28`'s message about the lost turn verbatim** — reproduced at §7 and nowhere summarised |
| `OPEN-from-job25-20260829b.md` | **THE `b` LETTER. Nothing in it is ruled and it says so.** Its §3.2 seeing census and §4 backward census are live work. **Twelve of its book 1 line citations sit above the 08-31 break — see §1.0** |
| `APPLY-job25-drafting-20260829.md` | **`[A]`'s own supply of the Ch 11 material that was never written**, block by block, marked SETTLED or OPEN. The settled blocks were applied 08-29; **check the OPEN ones before assuming they landed** |
| `NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md` | **THE `c` LETTER. `Job24`'s product. Read its §10 before its §1; its §17 replaces its §9.** **Its §2 is marked superseded** — it placed ignoring outside the crossing, and `[A]` sited the decision to ignore at Z+ on 08-30, which puts it back there as a disposal alongside the others — **and its *does not turn into* ruling is marked retracted.** Its §4.5 and §6 both rest on the external route being the only way down and are affected; **§4.3's withdrawal of the trainable-motor claim is NOT reopened by the retraction**, and is marked so nobody restores the wrong thing. **Its §13 carries the 08-29 ruling that the second brake is not conditional on stress, and its open item 4 is closed** |
| `NOTE-overlap-and-truthfulness-20260815b.md` | its §1.3 identification is withdrawn — see §6. **And its §1.4 reconciliation lost its support on 08-23** when Level 0 was abolished |
| `BOOK2-PART34-ARCHITECTURE-20260902e.md` | **the live Part 3/4 architecture, 14,160 w, the `d` letter. Its §6 is the record of what blocked Part 3, which is now drafted and placed; its §7 lists twelve `[C]` calls by name; its §8 corrects two stale lines in `BOOK2-ARCHITECTURE-20260815b.md`.** Supersedes `BOOK2-PART3-PROVISIONAL-20260815.md`, **except that file's appendix proposal at §3A, which is carried forward unexamined** |
| `CLOSURES-SITED-job32-20260830.md` | **a record, not a queue — all thirteen rows were applied by `Job33` on 08-31, AND THE FILE'S OWN HEAD STILL SAYS *Not applied*, which reads as work owed. One line, deferred by four sessions.** First instance of an artifact type `[A]` minted; **he agreed to the rule and not to the layout**, and it says so on its face. **Rows 2, 3 and 10 read `settled` and mean `worked through`** |
| `CENSUS-book1-into-book2-20260901.md` | **the first pass and it is not finished — see its §6.** Its §4 carries the method, including the split between unit-level and passage-level checks. **Its passage-level findings are marked as needing re-reading before use** |
| `SKETCHES-rewrite-by-author-20260901b.md` | **`[A]`'s own text, verbatim, plus seven changes he approved and which are NOT applied.** **Do not apply item 7's closing paragraph** — it restores a clause he retracted on 08-20; see §5 |
| `SET-NOTE-from-job31-20260830.md`, `SET-NOTE-from-job32-20260830.md`, `SET-NOTE-from-job33-20260831.md`, `SET-NOTE-from-job34-20260831.md` | **the four folded here, all still citable.** *This file summarises them and is not citable for what they hold.* **`Job33`'s carries `[A]`'s five rulings and `[C]`'s unruled join on the external route, which is recorded there and nowhere else** |
| `NOTE-drafting-8-15-findings-20260816.md` | |
| `NOTE-small-arcs-and-the-step-20260815.md` | **its question is still open** and is not the one closed on 08-23 — it asks about the fall and the climb, which is the health axis |
| `DOCTRINE-BRIEF-arcs-and-position-20260816.md` | **headed MEASURED over a table two of whose three citations do not survive a check** — §6 |
| `BOOK2-ARCHITECTURE-20260815b.md` | live architecture |
| `BOOK1-INDEX-20260815.md` | |
| `rev2-0814t.md` | **grep it, never read it through — and grep it for its LINE NUMBERS TOO: they moved on 08-31 and again since, and the drift is not constant. See §1.0.** **Carries NINE inline `[DEPRECATED …]` markers plus the block mark over the four sketches, counted 2026-09-06** — two of the nine are ruled down and still not cut, and **one that `[A]` ruled on 09-01 is gone with the sentence it governed; see the head and §2** |
| `VERIFY-20260815.md` | |
| `BOOK2-20260906b.md` | reference for a doctrine session — doctrine sessions do not touch text. **30,885 w, 1,421 lines as of 2026-09-06; five sessions have cut a master since 09-02 and every book 2 line citation older than this cut is stale.** **Ch 7's route-as-cause defect is repaired and the two disputed markers are ruled as of 09-01.** **PART 3 IS IN IT as of 09-02 and the count went 872 → 1,297 lines, so EVERY book 2 line-number citation made before 09-02 is void; locate by content** |
| `STALE__rev2-0814b__WORKING-SET-doctrine.md` | reference, **and stale — renamed 2026-08-26.** *A `[C]` assembly of book 1 passages; it compresses book 1 and is not citable as book 1, and nine of its passages are no longer book 1 at all. See §6* |
| `TODO.md`, `TODO-additions-20260814.md` | **`TODO.md` L159 carries both of Ch 15's old section titles** and is stale after the 08-25 retitlings |
| `THEORY-NOTES-gradient-and-Z-split.md` | discounted — 07-28, predates every ruling |
| `THEORY-NOTES-voluntariness-and-two-layer.md` | discounted — same |
| `setcheck.py` | tool. **Two verdicts since 08-25**; fires on itself, a known false positive |
| `quotecheck.py` | tool — **both known defects were fixed 08-24** |

**No figures in a doctrine set. Generate the manifest with the tool, never by hand:**

```
setcheck.py manifest --label "<the name [A] gave the session>" \
  --out MANIFEST-<name>.md <files>
```

**The label is `[A]`'s to set, ruled 2026-08-23, and since 08-25 he has been giving it in the zip
name** — `job18-doctrine-20260825`, `job19-handoff-20260826`. **Assign the counter when the set is cut,
never earlier and never twice.** Verify md5 after copying, not before. **The label is how the next
session learns its name**, so it is not a decoration.

**Two files cut on 08-21 and superseded the same day**, by the note above:
`NOTE-how-fixations-work-20260821.md` and `WORKSHEET-fixations-and-arcs-20260821.md`. Both are in
`~/staging` alongside the note. **Quarantine as `SUPERSEDED__live__`; do not put them in a set.**
Their content is in the note and nothing is lost. They are listed because a file cut and superseded
inside one day is exactly the kind that stays bare and turns up later looking current.

**Two files cut on 08-21b, both live, neither in the doctrine set:**
`BRIEF-writer2-ch1-4-20260821.md` and `BOOK2-Ch1-4-for-writer2-20260821.md`. They belong to job 4 and
are listed at §1.1. *The second is a derived file — the master's first 363 lines, verbatim — so it CAN go stale when the
master is revised. **Whoever revises the master re-cuts and HASHES it; if the bytes match, the file is
live and keeps its name.** The check is `head -363` of whatever the master is called that day —
**`BOOK2-20260902b.md` as of 2026-09-02, and the extract is FURTHER from verified than this paragraph says — Part 3 landed and the master went 872 → 1,297 lines. THE RANGE IS NO LONGER VERIFIED**: book 2 gained four lines
on 08-31 and nobody has checked whether line 363 is still the last line before Ch 5. **Find the Ch 5
heading and cut to the line before it; do not assume 363.** **Run on
2026-08-26 it came out byte-for-byte identical and the extract was current then. Re-measured
2026-08-30 it is NOT** — at least four of `Job27`'s 08-29 metaphor substitutions sit inside the range,
in the Ch 2 profiles and in Ch 4. **The extract must be re-cut and hashed before it is sent.** *This
paragraph once asserted staleness on the strength of the master having changed, which was an inference
and blocked job 4 for five days; the reversal above is a measurement of the range. The rule is
unchanged and it is the rule that matters: hash it, do not reason about it.*

**AND A WARNING ABOUT THIS FILE'S OWN CLAIM TO BE THE RECORD.** `[A]` opened the writer 2 job in the
middle of a doctrine session. That pass will change Part 1 and it reports to nobody, because its brief
correctly forbids it from folding a handoff it was never given. **So the next doctrine session should
ask what the writer 2 pass did before assuming this file is current about Part 1.** Search the
conversation record as well as the files — that practice is at §7 and it exists because something was
lost exactly this way.
