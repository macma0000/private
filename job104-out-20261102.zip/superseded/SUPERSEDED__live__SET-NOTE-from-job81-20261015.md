# SET NOTE — from `Job81 doctrine 20261013`

This note goes to the session that receives `job81-out-20261015.zip`. `[A]` gives the kind of session. The
manifest label carries only the counter and the date.

## Arrival

The incoming zip was `job80-out-20261013.zip`. It verified against `MANIFEST-job81-20261013.md`:
**59 ok, 0 mismatched, 0 bad count, 0 missing, 105 not in the manifest** (the `spent/` and `superseded/`
folders). The screen fired only on the names in `superseded/` and on the record (*carry, do not read*,
which a doctrine session may read). The record's last marker matched `Job80`'s set note: seventieth
append, 89,829 w, md5 `7e89f429`. The record was read in full.

## What was done

The doctrine sitting on the unease loop, step 2 of the order `[A]` agreed on 10-12. The 09-23 unease file
was checked against every later ruling, and each collision was put to `[A]` one at a time.

**`[A]` ruled, in his words** (all in the record's seventy-first append):

- **Deciding on a next step works a fear through**, and the coffee passage is right. *i withdraw the 09-03
  ruling* — a fear can end while the want behind it lives on.
- **Every fate leaves bodily tension.** *yes. probably less than the other fates. and everything leaves
  deposits.*
- **Distraction at the enthusiasm end of detachment is ignoring, not blocking.** *ignored.* The unease loop
  buries nothing.
- **The turning over:** the same plan repeated is ignoring; a different plan each turn is the unease loop.
  *ignored would repeat the same plan.*
- **A disappointment meets all four fates**, reversing 10-13. *not if you see the fourth.* … *yes*

**Produced:** **`CLOSURES-SITED-job81-20261014.md`**, sited against `BOOK2-20261013.md` (md5 `572d83bb`).
It replaces the 09-23 unease file as the thing to draft from and lists what in that file is dead.
**Nothing in the manuscript, the register or the style guide was touched.**

## The record

One append, sighted: the **seventy-first**, parent 89,829 w, **head 90,976 w**, md5 `7aee0005`, marker
`Job81 doctrine 20261013`, closing. The parent's 531,309 bytes were checked unchanged at the join.

## Moved

- To `spent/`: `DOCTRINE-ONLY__NEW-MATERIAL-the-unease-loop-20260923b.md` (taken up, and superseded by the
  closures), `ANSWERS-for-coherence-from-job70-20261012.md` and `BRIEF-for-coherence-from-job70-20261011.md`
  (their last live items taken here), and `SET-NOTE-from-job80-20261013.md`.
- To `superseded/`: `MANIFEST-job81-20261013.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`,
  not to be acted on until `[A]` says so.
- **New and live:** `CLOSURES-SITED-job81-20261014.md`, this note.

## What is owed

- **Step 3 of the agreed order: a drafting session from the closures**, including *Rising*. Apply Part A
  first. The closures name four register entries and two `wordcheck.py` patterns that must change in the
  same pass (worked through, `left-over`, disappointment, `four-fates-disappointment`, and `loop` for its
  third use) — the disappointment pattern will otherwise flag the repair as a fault.
- Then **step 4, a coherence run.**
- **The handoff is stale** on the master and the register: `HANDOFF-20261005b.md` names the 09-23 master and
  register letter `c`. The live register is letter `h`. It needs a cut.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation, following the order `[A]` agreed: **a drafting session on
`CLOSURES-SITED-job81-20261014.md`.**
