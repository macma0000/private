# CHANGES — `job84 drafting 20261017`

Cut 2026-10-17. The session opened on `job83-out-20261017.zip` (manifest label `job84-20261017`) and worked from
`FINDINGS-job83-20261017.md` alone. That file is now in `spent/`. **Master in: `BOOK2-20261016.md`** (42,986 w, md5
`7612914c`). **Master out: `BOOK2-20261017.md`** (43,044 w by `LC_ALL=C wc -w`; md5 in the manifest). 26 diff hunks, all
listed below.

Every change was shown to `[A]` with the sentences around it, before and after. In Part One, "yes" means his own word
on the wording shown. During the session `[A]` carried several exchanges with `Job81 doctrine 20261013` in. **Where a
row says relayed, the wording is `Job81`'s, carried in by `[A]`.** Three rows were applied on a relay he sent without a
separate "yes" of his own. Each is marked **RELAY, NO SEPARATE YES**, and the next session should show him those three
first.

Sites are named by section and by their new text. Locate them by content.

---

## PART ONE — THE CHANGES

### Chapter 17, *Why this does not take everyone to the bottom* (findings item 1, and item 2's first site)

1. **The two-pains paragraph, last sentence.** *Only then does the person face the buried fear.* → *Only then is the
   person open to trying something new. Facing the buried fear is one thing the person might try, and nothing makes
   facing the first thing the person tries.* `[A]`: *yes*.
2. **The pushback paragraph.** The paragraph now opens *The comparison also gives the pushback its shape.* The pain of
   staying passing the pain of facing is replaced by *at some point staying becomes unbearable. The person is then open
   to trying something new.* `[A]`: *yes on 1 and 3*.
3. **The paragraph *Consequences do not arrive and then pass*, last sentence.** It now reads *So the pain of staying is
   present the whole time, and the pain of staying is greater the further down a person has come.* The sentence it
   replaces had the pain of staying working the whole time, which Job81's paragraph (row 4) contradicts. `[A]`: *yes*.
4. **The paragraph *That raises a question*.** The two crossing terms and the thin tail are gone. **`Job81`'s
   wording, relayed**, with `[A]`'s replacement for *behaving badly*:
   *A rising pain of staying does not stop a fall until staying becomes unbearable. Short of that point the pain of
   staying adds stress, and stress lowers what a person can bear, so the fall can speed up. The pain of staying slows the
   fall only sometimes. It can make a person more careful about relieving discomfort with automatic reactions, but only
   if the person has some understanding that their own blindness is part of the problem. The fall is slow for other
   reasons. A level is made of many blocked fears, and a fear is blocked only when it is more than the person can bear.
   Few people reach the bottom, because getting there takes many years of blocked fears.*
   `[A]`'s words, relayed: *it would sometimes make the person more cautious about behaving badly and that would work
   only if they had some understanding that their blindness was part of the problem*; *thin tail is too technical*;
   *instead of "behaving badly", "allowing automatic reactions as a way to relieve discomfort " or something like that.*
5. **Where the climb ends.** It now reads *The pain of facing does not fall along with the pain of staying. However high
   or low a person stands, the person imagines that facing a buried fear would be unbearable. So a climb ends when
   staying stops being unbearable, and that is the middle.* The oldest material is no longer given as the reason the
   facing side stays high. `[A]`: *yes on 1 and 3*.

### Chapter 17, *What reaches someone the consequences no longer reach* (item 2)

6. **First paragraph.** *Consequences count only as far as they are understood* is cut, and so is the counted-part
   claim. In their place: *All of the felt pain counts toward the pain of staying, whether or not the person connects the
   pain to their own condition. So the pain of staying goes on rising however far down a person is.* Shown to `[A]`.
   He replied with a relayed `Job81` revision of the second paragraph only, so this paragraph stands as shown.
7. **Second paragraph.** The paragraph *Far enough down, that stops being enough* is replaced. **`Job81`'s wording,
   relayed**, with two referring-word repairs by `Job84` (*come to it* → *come to facing the buried fear*; *makes it more
   likely* → *makes facing more likely*): *Far down, the pain of staying still rises until staying is unbearable. At that
   point the person is open to trying something new. But a person far down cannot see their own condition, so facing the
   buried fear is unlikely to be the first thing the person tries. The person may still come to facing the buried fear
   alone. Someone who can see the person's condition makes facing more likely, and some help of that kind is common,
   because friends keep trying to help.* `[A]`, relayed: *the person is unlikely to try facing the buried fear at first
   but they could possibly do it without help from someone else.* **The findings' "minor intervention is common" is
   carried by the closing clause.** No separate sentence about friends was added at the intervener passage.

### Chapter 17, *Rising* (items 2 and 3)

8. **The paragraph on what moves a person to take up a skill.** The counted-part sentence and the sentence after it
   become *All of the pain of life not working counts, whether or not the person connects the failures to fears left
   unfaced. Without the connection, a person in pain is still open to trying something new. What the person tries may be
   anything that promises relief.* `[A]` asked to see the whole paragraph; then *yes*.
9. **The oldest-material paragraph, last sentence.** *Desperation is then what is left to move the person.* → *So the
   person has little reason to think that facing the oldest material is what would help.* `[A]`: *yes*.
10. **The ignored-aversion paragraph.** *An ignored aversion is still in view, so the person can give the ignored aversion
    up.* → *The matter behind an ignored aversion can still be noticed. The matter is available, though not necessarily
    in view. So the person can give up the want behind the aversion.* `[A]`: *yes*.

### Chapter 15, *The unease loop* (items 3, 4, 5, 8, 9)

11. **After a few turns.** *After a few turns, while the matter stays unresolved, the want is to be rid of the tension …*
    The phrase was proposed by `Job81`. `Job84` said it was not needed. `[A]`: *yes. readers' attention spans are short
    especially when there are many ideas needing attention.*
12. **Chronic.** *Bodily tension is uncomfortable in itself, so the unease loop can go on after the matter … So unease
    can become chronic.* → *So the unease lasts as long as the matter stays unresolved.* Approved by relay: *job81
    approves*.
13. **The enthusiasm end** (item 5). The paragraph *The unease stays …* and the sentence *… an unease loop about the
    unease goes on* are cut (Job83's decision). In their place: *The ignored fear leaves some bodily tension, which
    fades. The fear is raised again when the person next meets the problem of the sale.*
14. **The way out at the enthusiasm end — cut.** *Near the enthusiasm end the only way out is through the person's
    capacity to bear discomfort … instead of wanting the unease gone.* The cut is **`Job81`'s, relayed**. `[A]` asked
    `Job81`: *i think with A, there isn't much discomfort to bear. or is it just not noticed?*
15. **The bridge paragraph.** It now opens *Facing a buried fear takes the capacity to bear discomfort.* Then: *The
    capacity to bear discomfort can be built, and it can be built on any kind of pain, because pain is pain.* Both
    sentences are `Job81`'s, relayed. The second answers `[A]`'s *how is unease relevant?*
16. **The migraine case** (item 8), in `[A]`'s approved wording from Job83: *Later she went further.*; after *She
    already understood that buried material has to be faced.*: *What she had learned with the pain was to stop an
    automatic resistance. The same capacity let her stop the automatic turning away that kept her fears buried.*; and
    *She could stop turning away because her fears were not too deeply buried. Her buried fears were never noticed. But
    she felt the anxiety that came when the buried fears came near, and she could stay with the anxiety instead of
    turning away.* *keep me out of it* is applied to this passage only (Job83's decision).
17. **Two pointers to the cut paragraph, removed by `Job84`:** *The capacity to bear discomfort helps with more than the
    unease loop.* is cut, and the clause *even where the only way out is bearing the unease* is cut from *A way out of the
    unease loop is always open.*
    **Rows 13 to 17 were shown to `[A]` as one passage. RELAY, NO SEPARATE YES:** he answered with `Job81`'s rewording of
    the bridge sentence (row 15) and nothing else, and the session took that as approval of the rest.
18. **For years** (item 4). *A person can run the unease loop for years* → *many times*. `[A]`: *yes*.
19. **The health axis named before it is introduced** (item 9, not ruled by Job83). The paragraph now opens *The health
    axis reflects how much a person notices, not how comfortable the person is.* That sentence was the paragraph's last
    and has moved to the front. `[A]`: *how about "The health axis reflects how much a person notices"*. **`Job84` kept
    *not how comfortable the person is* from the old sentence without asking.** Show him.
20. **Idle discomfort** (item 3). *An ignored aversion is noticed and let alone, so the ignored aversion stays in view.*
    → *An ignored aversion is noticed and let alone. The matter behind the ignored aversion can still be noticed, though
    the matter is not necessarily in view.* `[A]` asked the difference between *can be noticed* and *in view*. He was
    told: *in view* means being noticed now, which is how the fates section uses it; *can be noticed* means nothing stops
    the noticing. Then *yes*.
21. **The ignored disappointment** (item 3). **RELAY, NO SEPARATE YES.** It is `Job81`'s revision of `Job84`'s draft:
    *A disappointment at a gratification ending may be ignored. An ignored disappointment leaves the matter unresolved
    and leaves some bodily tension. When the matter comes up again, the matter raises an aversion, and the aversion adds
    to the unease.* The next paragraph gains an opening sentence and *given up on*: *Ignored aversions and buried fears
    are the two sources of lasting unease, and they differ in what ends them. An ignored aversion can later be given up
    on. A buried fear can only be faced.*
22. **The last paragraph** (item 4). *Where a person has neither buried fears nor ignored aversions, there is no chronic
    unease. Ordinary pain still comes and goes. But no distraction is needed to cover the pain.* `[A]`: *yes*.

### Chapter 16, *Where a level change can happen* (item 4)

23. *… so the unease loop can keep a person uneasy for years without moving …* → *for years* dropped. `[A]`: *yes*.

### Chapter 14, *Gratification* (item 6)

24. *But the relief came from expecting less, and not from the behavior.* `[A]`: *yes*.

### Chapter 5, *Where the Types Come From* (item 7)

25. *Book 1 calls that the critical confusion …* is dropped. The sentence before it, at `[A]`'s request, becomes *When a
    person applies one realm's standards and limits in the other realm, the outcome fails.* `[A]` asked for *something
    like "When a realm's standards and limits are applied in the other realm, the outcome fails."* `Job84` put the person
    in the subject. `[A]`: *yes*.

---

## PART TWO — CHECKS

- **Referring-word count** run on every changed paragraph before it was shown. Six sentences carry two flagged words.
  Four are a relative or complementizer *that*, a *they* standing for the sentence's own subject, or both. The other two
  are unchanged sentences inside changed paragraphs.
- **`wordcheck.py`** against letter `k`: 157 hits (164 on the old master). Every hit falling in a changed sentence was
  read: `loop` (the unease loop, the blindness loop), `aversion-scope` (ordinary use), and `unease-synonym` once on
  `[A]`'s *no chronic unease*, which the pattern now allows. `unease-about-unease` and `aversion-in-view` now count zero.
  Hits outside the changed text were not re-read.
- **The file was read back** at every site after applying. Word count 42,986 → 43,044.

## PART THREE — NOT DONE, AND FOUND

- **The claim inventory** has not been updated for these changes. That work belongs to the coherence run.
- **Not acted on:** the section heading *What reaches someone the consequences no longer reach* and the sentence at the
  end of the section before it (*… where consequences no longer reach a person, nothing raises it*) still say that
  consequences stop reaching a person. Row 6 says the felt pain of consequences counts at every depth. The heading and
  that sentence speak of recognition, so they may stand. A coherence question.
- **Not acted on:** *Rising* still has *Giving up ignored aversions* and *Each ignored aversion given up*, not *given up
  on*. `Job81` repaired the form only at row 21.
