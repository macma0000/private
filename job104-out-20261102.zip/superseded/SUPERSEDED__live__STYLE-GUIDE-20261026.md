# STYLE GUIDE — read before writing any prose for either book

**Letter `i`, 2026-10-26 by `job88 drafting 20261023` — supersedes `STYLE-GUIDE-20261019.md` (letter `h`), quarantine
the parent.** Section 8's pointer now names the register's letter `n`, `WORD-RULINGS-book2-20261026.md`. Two caught
instances added, each with `[A]`'s words: in section 1, a sentence of the writer's internal logic; in section 9, a verb in
an unfamiliar use. Nothing else changed.

*What letter `h` said of itself, retained:* **Letter `h`, 2026-10-19 by `job86 drafting 20261017` — supersedes `STYLE-GUIDE-20261018.md` (letter `g`), quarantine
the parent.** Section 8's pointer now names the register's letter `m`, `WORD-RULINGS-book2-20261019.md`. Two caught
instances added, each with `[A]`'s words: in section 1, the book commenting on its own account; in section 3, the lever
figure and *waits on the world*. Nothing else changed.

*What letter `g` said of itself, retained:* **Letter `g`, 2026-10-18 by `Job85 coherence 20261017` — supersedes `STYLE-GUIDE-20261017.md` (letter `f`),
quarantine the parent.** Section 8's pointer now names the register's letter `l`, `WORD-RULINGS-book2-20261018.md`.
Nothing else changed.

*What letter `f` said of itself, retained:* **Letter `f`, 2026-10-17 by `job84 drafting 20261017` — supersedes `STYLE-GUIDE-20261016.md` (letter `e`), quarantine
the parent.** Section 8's pointer now names the register's letter `k`, `WORD-RULINGS-book2-20261017b.md`. `Job83` found
the pointer stale (it named letter `i` while letter `j` was live). Nothing else changed.

*What letter `e` said of itself, retained:* **Letter `e`, 2026-10-16 by `Job82 drafting 20261015` — supersedes `STYLE-GUIDE-20261005b.md` (letter `d`),
quarantine the parent.** Section 3 rewritten to `[A]`'s 2026-10-15 clarification of the metaphor rule (closures
`CLOSURES-SITED-job81-20261014d.md` Part H): an explained metaphor is acceptable; economic language stays out;
mechanical metaphor is avoided, with one explained use possible. The sentence *Where the mechanism is stated right
after the figure, the figure compresses nothing and only delays the explanation* is removed, as going further than
`[A]`. `[A]` approved the new section to `Job82` on 2026-10-16: *yes*. Section 8's pointer now names the register's
letter `i`. Nothing else changed.

*What letter `d` said of itself, retained:* **Letter `d`, 2026-10-05 by `Job75 coherence 09232026` — supersedes `STYLE-GUIDE-20261005.md`
(letter `c`), quarantine the parent.** One bullet removed from section 8, *Registering never appears
without its object*, a leftover from before `register` was retired on 09-07 that contradicted the
section's own later bullet. `Job70` found it on reading letter `c`. Nothing else changed.

*What letter `c` said of itself, retained:* **Letter `c`, 2026-10-05 by `Job75 coherence 09232026`, at `[A]`'s request — supersedes
`STYLE-GUIDE-20260908b.md`, quarantine the parent.** Three things added, all `[A]`'s: his 09-09
withdrawal of the 09-04 objection to a later style job, written into the paragraph it amends;
section 10, his 09-21 correction that prose transcribes thought one for one, with the repair method
he approved and his ruling on detail that invites a literal reading; and one caught instance in
section 1, his 09-06 ruling on comments about the material. A pointer to the word register is added
to section 8. Section numbers 1 to 9 unchanged.

*What letter `b` said of itself, retained:* **Letter `b`, 2026-09-08 by `Job59 coherence 09082026` — the referring-word count amended to distinct words; supersedes `STYLE-GUIDE-20260908.md`, quarantine the parent.**

**Cut 2026-09-07 by `Job56 drafting 09072026`. Two caught instances added — a technical figure a
general reader cannot parse, under *The diagnostic that catches what the rules miss*, and a bullet in
section 8 on deciding which stage a sentence is about before changing its word. Everything else is
unchanged from the earlier 09-07 cut by `Job55 doctrine 09072026`; quarantine
`STYLE-GUIDE-20260907b.md` as `SUPERSEDED__live__`. Section numbers unchanged.**

*What the `Job55` cut said of itself, retained:* **Cut 2026-09-07 by `Job55 doctrine 09072026`. Four bullets added to section 8, all from the two
stages of seeing ruled that day: the words for the two stages, and what happens to `see`,
`register` and `surface`. Everything else is unchanged from the earlier 09-07 cut by
`Job54 drafting 09072026`; quarantine `STYLE-GUIDE-20260907.md` as `SUPERSEDED__live__`. Section
numbers unchanged.**

*What the first 09-07 cut said of itself, retained:* **Cut 2026-09-07 by `Job54 drafting 09072026`.
Two paragraphs added at the end, under *The
diagnostic that catches what the rules miss* — `[A]`'s ruling that concision is being given too much
weight against clarity, with the day's caught instance. One bullet added to section 8: `bear` always
means capacity, never load. Everything else is unchanged from the 09-06
cut by `Job50 drafting 09062026`; quarantine `STYLE-GUIDE-20260906.md` as `SUPERSEDED__live__`.
Section numbers unchanged.**

*What the 09-06 cut said of itself, retained:* **Cut 2026-09-06 by `Job50 drafting 09062026`. One
bullet added to section 2 — a verb that only a person can take. Everything else is unchanged from the
09-05 cut by `Job48 drafting 09042026`; quarantine `STYLE-GUIDE-20260905.md` as `SUPERSEDED__live__`.
Section numbers unchanged.**

*What the 09-05 cut said of itself, retained:* **Cut 2026-09-05 by `Job48 drafting 09042026`.
Section 9 added at `[A]`'s instruction; everything else is unchanged from the 09-04 cut by
`Job46 drafting 09042026`.** These are his corrections,
several of them given repeatedly across sessions. They lived in the handoff's §4 until now, where a
session reading targeted sections could pass every rule it read and still break the ones it did not
reach.

**RULED 2026-09-04 by `[A]`: these apply AS YOU WRITE.** They are not a list for a later repair pass
to work through. *He had earlier proposed that drafters write as they choose and a later job fix the
style; he withdrew that on 09-04 — `the part about fixing things later seems like a problem`.* A
session that writes prose applies this file to what it writes, and repairs what it touches.

**AMENDED 2026-09-09 by `[A]`, who withdrew the 09-04 objection:** *i withdraw "the part about fixing
things later seems like a problem" - but the writing still has to be clear enough for me to
understand it when i read it later.* So a later rewording job is allowed again. **What still applies
while drafting:** the mechanical checks — above all the referring-word count, naming a thing instead
of describing it, and everything in sections 9 and 10 — because without them `[A]` cannot read the
draft he is asked to rule on. **What may wait for the later job:** the finer choice between two
forms he would understand either way.

---

## 1. Write about the world, not about the book

The reader is being told about people, thoughts and processes. A sentence that describes the book's
own arrangement, or tells the reader what to do with a passage, has stopped doing that.

- **Caught 2026-09-04:** *The four are ordered, not listed, and the order is the crossing's own.*
  `[A]`: it *sounds like the text refers to itself*. The repair was to delete it — the two ends and
  the direction a process travels through them are what the ordering is, so saying that plainly left
  nothing for the sentence to do.
- **Staging the reader's response**, named 08-16: *that is worth a moment*, *notice*, *worth asking*.
- **No forward chapter references in running prose, and no chapter numbers in prose at all.** Refer to
  the content or name the type.
- **A comment about the material is not the material — added 2026-10-05, ruled 2026-09-06.** Of *The
  model names what an intervener has to supply*, `[A]`: *that is a comment about the material rather
  than the material itself - those should not go into the text itself.* The paragraph was deleted
  with no replacement, and what it said went into the set note instead. A sentence that tells the
  reader what the model does or does not cover belongs to the sessions, not to the book.
- **Caught 2026-10-19, at the close of the falling-and-rising chapter.** *One thing is left unsolved.*, *This account
  produces the second.* and *What the account does not give is a way to do it alone.* `[A]`, of the paragraph that held
  the last two: *the paragraph is the book introspecting about itself. is it unnecessary?* The repair kept the two
  sentences that said something about people and cut the rest. **The test: delete the sentence and ask whether a
  reader learns less about people.**
- **Caught 2026-10-26, in the levels chapter.** *People of every type are found high on the axis and low on it, so the axis
  cannot be tracking either of those orientations.* `[A]`, relayed by `Job81`: *sound like writer's internal logic. ok to
  drop it?* It was dropped. A sentence that argues the model into place, rather than saying something about people, is
  the book reasoning about itself.

## 2. Nothing that is not a person gets a person's properties

The oldest form of this is on the record as: **when the subject of a sentence is an idea rather than a
person or a thing and the verb gives it agency, the prose has stopped describing the world.** It is
`R9` at sentence level, not a matter of taste.

- **Agency:** *the lean toward B funds attention*. An idea does not fund anything.
- **Possession — added 2026-09-04.** *The order is the crossing's own.* `[A]`: this *uses an owning
  which is appropriate to people but not crossings*. A crossing owns nothing. **This form is not
  covered by the agency rule and has to be checked for separately.**
- **A verb that only a person can take, given a thing to take it — added 2026-09-06.** *The less of
  it they can meet*, of a discomfort. `[A]`: an animate verb with an inanimate subject. **The subject
  here was a person and the rule still fires**, because what the verb needs is a person at either
  end: you meet a person, you do not meet a discomfort. **This form passes both tests above and has
  to be checked for separately.** The repair is a verb that takes a thing — *bear*, *look at*,
  *accept*.
- **Asserting a property before the reader can know what it would mean.** The same sentence claimed
  the crossing has an order, which is true and unusable to a reader who does not yet know what having
  an order amounts to.
- `[A]`, on why this matters more than it looks: these are **very uncomfortable for a normal reader**.
- **The repair is usually to put the person back in the subject.** *What enthusiasm habitually
  resists* becomes *what an enthusiastic person habitually resists*; *the realm judges appropriate*
  becomes *the measure the person brought*. `Job48` made about thirty of these in book 2.
- **But an orientation is not a person, and the repair must not say it is.** `[A]`, 2026-09-05:
  *orientations are never people*. Where a sentence is defining an orientation rather than reporting
  what somebody does, putting *such a person* in the subject is an imprecision accepted for
  readability, not a correct rendering. Where the sentence is about the order of the orientations
  themselves, the person must NOT be put in — that would say a person changes orientation, which the
  ruling that the pair holds exists to prevent. Repair those by taking the person's verb off the
  orientation instead: *enthusiasm ends where limits and consequences are met, and caution begins
  there*, not *enthusiasm becomes caution*.

## 3. Name the mechanism; do not reach for a figure to save a few words

**Ruled 2026-08-29; clarified 2026-10-15 by `[A]`:** *my objection to metaphor is against single sentences where a mild
metaphor is used unexplained to save a few words where it could be said using more literal words. an explained
metaphor is okay.* So the fault is a single sentence that uses a mild metaphor, unexplained, to save a few words,
where literal words would say the same thing. **An explained metaphor is acceptable.** Where the explanation was
dropped and the figure kept, the claim has gone. Where no mechanism can be named, **that is a finding: report it
rather than paraphrasing it into different vocabulary.**

- **Economic and financial language stays out, explained or not.** Ruled 08-29 and confirmed when put again;
  confirmed 2026-10-15, `[A]`: *economic metaphors are still too remote.*
- **Mechanical metaphors for psychic-realm phenomena: avoid them.** `[A]`, 2026-10-15: *the frequency filter is an
  example of mechanical metaphor i deliberately avoided, but there might be a use for that - i don't think we have
  any now.* So one, explained, may have a use; the book has none at this cut.
- **No sweep.** Nothing removed under the old wording of this section is restored on the 10-15 clarification
  alone (`Job81`'s decision, closures Part H).
- **Caught 2026-10-18/19.** *This still waits on the world.* `[A]`: *is too terse - what does it mean?* It became *The
  recognition still depends on what happens in the person's life.* And *nothing is levered*, from a section headed *The
  problem of leverage*: `[A]`: *i don't understand levered.* A figure in a heading and a chapter title is still a
  figure; neither had ever been explained. The repair said what happens — *the person is moved by someone else, not by
  their own effort* — and the heading and title went with it.
- **Scope:** book 1 is not swept for metaphor. Every drafting session applies this to what it touches,
  book 1 paragraphs included where it is already drafting from them. Book 2's own pass is done —
  24 sites, `Job27` — and is not to be reopened.

## 4. Name the case; never its position in a list

*Only given up on is chosen*, never *only the second is chosen*. **Naming the thing saves the reader
going back to count.** `[A]` says he has given this correction several times. **It applies in
conversation as much as in the text.**

## 5. No coined handles

`far end` was a coinage that was never defined and whose first use pointed back at a paragraph. **Say
the orientation specifically.** *`the blind end` survives twice in book 2 and has not been ruled on.*

## 6. Stay at the scale of the thing discussed

Fears, not realms, where the sentence is about a fear.

## 7. Say it once

**The disguised restatement:** a claim the chapter needs once, re-asserted in several softened forms,
each dressed as a different point. Say it in one place, by itself. *Diagnostic: delete the sentence
and see whether the chapter loses anything. A restatement costs nothing to remove, which is why it
survives review.*

## 8. Vocabulary

- **`orientation`** or **`fixation`**, never `stance`.
- **`cycle`** only for the closed round of the three orientations; a single traversal is a **process
  arc** (the register's entry, RULED 09-15). The book calls one run of the three passages *a thought*;
  *thought cycle* is a working word of the sessions and does not appear on the page.
- **`A`, `B` and `Z` name where a person stands** — the orientation held in a realm, with its lean —
  and are never used of a phase. A letter always means a person.
- **`model`**, not `framework`.
- **`take in` is the only name for the first stage of seeing, and nothing else may be used for it.**
  Everything a person's realm holds is taken in, whole and at once, before anything has been picked
  out of it. **Ruled 2026-09-07.** The rule runs one way only: the first stage gets one word, and the
  second stage may be said in ordinary English.
- **`notice` always means the second stage, never the first.** Noticing is what picks something out
  of what was taken in, and it happens when motivation arrives. *Caught 2026-09-07:* the Nine's
  *nothing bends what they notice* credited a Nine with the stage they do least; the accuracy is in
  the taking in.
- **The verb `see` is kept off the first stage.** In ordinary use seeing includes noticing, which is
  why the word failed at every site where the book needed one stage and not the other. As a noun,
  **`sight` and `seeing` name a capacity** — how much a person is able to notice at all — and that is
  the quantity the health axis measures. `notice` has no noun that carries it, so the noun form
  stays.
- **`register` and `surface` are not used of either stage.** In ordinary use *it did not register*
  means it was not noticed, so the word cannot carry the first stage; and *surface* puts the material
  somewhere below and brings it up, which is the compartment the model does not have. Where the
  permission sense is wanted, *allowed to notice* carries it.
- **Which of the two stages a sentence is about is decided site by site, never by substitution.**
  Retiring a word does not tell you what replaces it. Ask what the sentence claims: if a person acted
  on the thing, or turned away from it, or judged it, they noticed it, and the word is `notice`; if
  the sentence is about what was there before anything was picked out, the word is `take in`.
  *Caught 2026-09-07:* *enough registers for a Seven to move away from a bad thing* was changed to
  *enough is taken in*, which destroyed the claim — everything is taken in whether a Seven stays or
  not, and what the sentence says is that a narrow noticing is enough to turn them and not enough to
  tell them what the thing is. **A reaction running with no noticing behind it happens only in
  blocking, where the noticing is stopped.**
- **`bear` always means capacity, never load.** *What a person can bear* is how much they are able to
  take; *what a person has to bear* is how much is pressing on them. The one verb carries both, and
  the two run opposite: capacity rising is a person doing better, load rising is a person doing worse.
  So keep the one form the chapters already use — *can bear more*, *can bear less* — and never vary
  it for a smoother sentence. *Caught 2026-09-07:* *a person deeply caught in one realm has less to
  bear with in the other* was written to mean their capacity is lower and says their burden is
  lighter, which is the opposite claim, inside a sentence that then argues for the intended one. For
  a load, use a different verb — *one more thing to handle*.
- US spelling. Plain register. Prose over lists.
- **Which word names which thing is settled in the word register, not here** —
  `WORD-RULINGS-book2-20261026.md`, letter `n`, at this cut. Apply only its entries marked RULED.
  This section keeps the rules that are about how a word behaves in a sentence.

## 9. Write for what a reader can actually hold

**Ruled 2026-09-05 by `[A]`**, after a stretch of drafting that he could not untangle: *you don't
understand how limited human concept handling ability is - at least for someone as old as i am - and
probably most unsophisticated readers.* These five came out of repairing that stretch. They are not
about elegance; each one names a way a sentence makes the reader do work the writer should have done.

- **Say the thing, not the absence of the other thing.** *A One's looking is in the physical realm,
  and the standards are in the psychic* — not *and the standards are not*. A negation makes the reader
  hold the first half and subtract; naming the realm hands them the fact.
- **One idea per sentence.** Where two ideas both need saying, write two sentences, even when a clause
  would join them.
- **No second name for something that already has one.** *The measure* for *the standards* cost a
  whole exchange. This is `5` again, arriving from a different direction: a coinage and a synonym do
  the same damage.
- **No sentence whose sense depends on holding an earlier phrase in mind while parsing a later one.**
  Caught: *because they are what the looking is done by rather than something it falls on*. The repair
  said the same thing straight — *because a One judges everything by them and so never has occasion to
  judge them*.
- **Where a reader must carry a fact across a paragraph, restate the fact rather than pointing back at
  it.** *The question of their worth*, not *a question that stays open*. `[A]` had to ask what
  question was meant, which is the diagnostic: if he asks, the reference did not carry.
  **RULED 2026-09-08: this is a count, not a judgement, and it is set out in full in
  `RULE-referring-words-20260908b.md`.** `[A]`: *claude is far better at holding what a word refers
  back to than a reader is. for a reader the limit is one or two.* A drafter resolves a reference
  without effort and so cannot feel its cost, and reading the sentence back does not help, because
  reading it back is the thing that is too easy. **So the bullet above cannot be applied by
  judgement, and the count replaces it.** Run on every sentence written: at most one DISTINCT referring
  word (*it, its, that, this, those, these, them, they, the other, there, the same, such, the
  former, the latter, in those respects, the first, the second*); each pointing no further back than
  the previous sentence; one thing given one name across a passage. **Amended 2026-09-08 by `[A]`:
  two occurrences of one word count once, and a third-person plural pronoun repeating the subject of
  its own sentence is not counted.** Rewriting means naming the thing. A
  paragraph boundary does not extend the reach, and a repair made to satisfy the count is new prose
  and gets counted like any other.

- **A verb in an unfamiliar use — caught 2026-10-26.** *The attitude issues in behavior.* `[A]`: *"issues in" unfamiliar
  use of verb.* It became *the attitude produces behavior*. A verb a reader knows only in another sense makes them stop and
  work out the sentence.

**The general form**, and the reason to apply these before a reader complains: the writer has the
whole structure in mind and the reader has one sentence at a time. Every one of these faults is
readable to somebody who already knows what it says.

## 10. Do not transcribe a thought one for one

**`[A]`, 2026-09-21:** *claude tends to transcribe its thought one for one in the text which is often
too terse for readers.* He asked for the whole text to be checked for it, and for a question to be put
to him wherever a session is unsure.

What happens: the drafter has the whole argument in mind, and writes down one sentence per step of it.
Each sentence is correct. The reader, who does not have the argument, gets the steps without what
joins them, and without the cases that would let them see what a step means.

**The repair method `[A]` approved:**

- **Carry one plain example through a passage.** One case, introduced once and returned to at each
  step, so the reader watches the claim happen to something. `[A]`'s own example for a single thought:
  *Suppose a person notices his shoelace is undone.* A train was rejected for it as needing too much
  planning. **The example should be small enough that every step of it is obvious.**
- **Restate a name where it is used**, rather than relying on the reader to carry it from where it was
  introduced. This is section 9's restating rule applied to terms.
- **Define a word before using it.** A term that arrives before its definition is read as ordinary
  English and then has to be unlearned.

**Detail that invites a literal reading is cut** (`[A]`, during `job74-drafting-20260919`, between 09-21 and 09-23): *the whole
story is somewhat a metaphor for what i see.* Where a sentence gives the model a precision the
model does not claim — an exact point, an exact sequence, a mechanism the book declines to specify —
the reader takes it literally and the account becomes wrong. `Job74` made two cuts in the climb
for this.

**This section and section 9 come from the same fault**, and the diagnostic below is its general
form. A terse transcription passes the referring-word count and still fails the reader.

---

## The diagnostic that catches what the rules miss

**Where the draft is tighter than book 1, look at what was traded for the tightness.** Compression is
where all of these come from: the figure that saves a few words, the restatement that softens a claim,
the handle coined so a thing need not be named again, the position in a list standing in for the case.

**And the reason the trade keeps getting made.** `[A]`, 2026-09-07: *claude gives too much weight to
concision over clarity — again readers are less able to parse complexity than claude is.* This is the
single fault behind every rule above, and it is not a matter of taste. A drafter parses a dense
sentence without effort and therefore cannot feel the cost of it, so the judgement of whether a
sentence is clear enough cannot be made by reading it back. **When a shorter form and a plainer form
compete, take the plainer one.** Extra words are cheap. A sentence a reader has to read twice is not.

*Caught 2026-09-07:* **a technical figure a general reader cannot parse.** *The position is real and
it has no width*, of the 0 lean. `[A]`: *a good metaphor but a general reader won't understand it.*
The geometry was doing the work of an explanation, which is section 3 arriving in mathematical
clothes rather than economic ones. The repair said it in the terms a reader already has: *nobody is
ever found exactly at it*, followed by why — what you see is where a person habitually leans plus
whatever the day has added. **A figure earned earlier in a passage may be used later in that passage;
one that arrives cold has to be replaced by the thing it stood for.**

*Caught on the day it was written:* **a concessive folded into the sentence it qualifies** — *a
consequence is felt whatever a person understands about it*. The reader must hold the first half
while parsing the second to learn which way it cuts. The repair split it and put the person in the
subject: *a person feels a consequence whether or not they understand where it came from. The job is
gone, and that hurts.* Three words longer and read once.
