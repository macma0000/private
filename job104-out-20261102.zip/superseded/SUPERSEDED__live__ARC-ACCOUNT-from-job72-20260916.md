# THE ARC ACCOUNT — `[A]`'s new material, 2026-09-16

Cut by `Job72 coherence 09152026`. Everything here was settled with `[A]` in that session and is
his, except where a line says `[C]`. It is not drafted anywhere. A drafting session taking this
needs a whole sitting for it: the account touches Ch 7, Ch 14 and Ch 15, and it changes how the
book describes a desire's life, a fear's life, disappointment and reactive action.

Read with `WORD-RULINGS-book2-20260916.md` §4a, which carries the vocabulary ruling that goes with
this account.

## 1. The two sizes

- A **thought cycle** is one run of the three passages and takes about a second. This is the only
  size at which the passages are literally made — Ch 7 already says the cycle is not an analogy at
  the scale of a single thought.
- A **process arc** at any larger size is a long run of thought cycles.
- Ch 7's three sizes (a thought, an undertaking, a life) all stand. So do Ch 16's descent and
  Ch 15's fifty years of making the same move.

## 2. What holds a long arc together, and what does not

Ch 14 stands unchanged: *A resolution finishes a process; what follows is not that process carried
further but another one, beginning. Nothing crosses.* And: *The arising hands nothing on.*

So a long desire is **not one desire lasting**. Each thought ends and lays down what it was
carrying. The next thought arises out of what previous thoughts have laid down, so nearly the same
desire is raised again. A person pursuing something for a month raises that desire many times a
minute, each time out of what the last one left. The arc ends when the desire stops being raised —
the thing was got, or the desire was given up.

The bodily tension works the same way. It holds a feeling for hours and acts by shaping what the
next cycle raises, never by crossing into it.

**An arc has no sharp edge.** A cycle belongs to an arc when the desire it raises is nearly the
desire the arc is about, and the mental deposits carry other influences too, so each cycle's
desire is a near copy rather than a repeat. `[A]` 09-16: his *less real* meant exactly this — *the
lack of a clear boundary about which thought cycles would belong to a particular process arc*.
`[C]` placement recommendation: two sentences in Ch 7 where the sizes are introduced, so a reader
does not expect sharp edges.

## 3. A fear lasts one cycle

A fear is raised in one cycle and meets its fate at that cycle's ending. A fear that **returns** is
raised again out of the deposits and out of the problem, which still stands. Nothing is stored and
brought back.

- **Ignored**: the problem is unsolved, so the next cycle raises the fear from the problem again.
- **Blocked**: the deposits are shaped by the burial, so later cycles raise fears shaped by it even
  after the problem is gone.

Ch 14's list keeps its wording (*ignored, which settles nothing, so the fear returns with the
problem*). Ch 15 says once, where the mental deposits are explained, that a fear that returns is
raised again rather than stored.

## 4. One cycle, step by step

1. **The arising.** A desire appears. A pain or a pleasure can start the cycle instead, and then
   the desire is to be rid of the pain or to have more of the pleasure. `[A]` 09-16: pain and
   pleasure start a process, and *how is up to wording since we decline to specify the method*.
2. **The development.** The person examines the desire. Examining raises an aversion when the
   examination finds trouble — this is the book's existing rule that examining a want raises a fear
   about it.
3. **The ending.** The aversion meets one of the four fates. Deciding that another step is needed
   is one way of working it through, and then the next cycle's desire is the desire to take that
   step.

If the desire is met and the examination finds nothing, the ending has nothing to dispose of and
the cycle closes.

## 5. Disappointment, and where it sits

A desire disappoints in two ways:

- the **examination judges** that the desire cannot be met; or
- the person **meets an outcome** that did not meet the desire, which is a pain, so a new cycle
  starts.

`[A]` 09-16: *in the case of the world, a new cycle starts with failure. there could be denial in
Z+, a new plan in A or disappointment in B. that keeps disappointment in B for both.* **So
disappointment belongs to the cautious phase in both cases**, and what becomes of a failure depends
on where the person's attention is concentrated.

`[C]`: those three responses are Ch 4's existing paragraph on what people do when something goes
wrong, now sited in the arc — an enthusiastic person turns toward the next positive, a cautious
person engages and the trouble is looked at, a detached person steps back and lets the difficulty
go or does not look at it at all.

Ch 7's *a resolution that both satisfies and disappoints* is a different use — the feel of any
ending — and stays.

## 6. Reactive action, truncated cycles, and panic

`[A]` 09-16, three cases:

1. **No thought cycle.** A reflex: the hand comes off the hot pan. No thought preceded the action.
2. **A truncated cycle.** One cycle concludes something (that restraint is too painful, say); the
   next cycle raises the desire to end the pain, the examining is cut short, and the action happens
   at the ending. `[A]`: *the snapping would be another thought cycle where the desire to end the
   pain was decided, with the snapping occurring at the end of a truncated cycle.*
3. **A cycle fully lived.**

**Panic is a truncated cycle, not a reflex** — `[A]`: *panic must involve some sort of judgement and
so a thought cycle so it's separate from a reflex.*

**Nothing is skipped.** Ch 14's *every process runs a beginning, a middle and an end* stands, and
the book does not say a phase is skipped. A truncated cycle raises little, so its ending has little
to dispose of; Ch 16's spoiled arrival (*an arrival reached without living the passage that leads to
it*) is the same case. The 09-15 stress hypothesis (a cautious person acting on an unexamined want)
is consistent with this and keeps its *I suspect* marking.

## 7. Where the fixations act

A fixation is attention concentrated at one phase (`[A]` 09-12), so a fixation acts in every cycle
and therefore at every size.

- **Enthusiastic**: much attention at the arising, cursory examining, so little is raised and little
  is settled.
- **Cautious**: heavy examining, so many aversions are raised, and most are settled before the
  ending.
- **Detached**: little at either. What arrives at the ending is processed at the caution end and
  ignored at the enthusiasm end, and the lean sets which. A detached realm generates nothing of its
  own; its person wants peace.

## 8. What a drafting session must not do with this

- Do not write the phase mapping (which realm is busy in which phase) as doctrine. It is `[A]`'s
  and is carried unruled from 09-12.
- Do not introduce `aversion` beyond the sites named in the word register.
- Do not write *skipping a phase* anywhere.
