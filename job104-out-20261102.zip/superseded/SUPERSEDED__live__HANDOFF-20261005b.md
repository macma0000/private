# HANDOFF — read this first

**Cut 2026-10-05 by `Job75 coherence 09232026`, at `[A]`'s request: `HANDOFF-20261005b.md`.** It
replaces `HANDOFF-20260919.md`, which travels in `superseded/` as
`SUPERSEDED__live__HANDOFF-20260919.md`. **Letter `b` repairs three faults `Job70` found in the first
10-05 cut** — the manifest row named the superseded parent, §9 stated the record's reach twice with
two figures, and the drafting row did not say why a discharged doctrine note stays barred — and
names style guide letter `d`. The first 10-05 cut travels in `superseded/` as
`SUPERSEDED__live__HANDOFF-20261005.md`. The older `HANDOFF-20260906.md` stays in `superseded/` too.
Both are history and are not read as instruction.

**VERSION.** `HANDOFF-20261005b` · 2026-10-05 · 5,988 words by `LC_ALL=C wc -w`. A file cannot
state its own md5, so the md5 is in the set manifest. If your copy has a different word count, it
is not this file.

## What kind of file this is

**This file describes the current state only.** It says what the books are, what each kind of
session reads, what is owed, what is open, and how to work. Where history matters, it names the
file that holds it. The 09-19 cut by `Job73` set this shape, and `[A]` did not reverse it.

**How this cut was made.** It is the 09-19 handoff brought up to date by the session that had just
run, not a fresh read of everything. `Job75` changed §0's *What comes next*, §1.1's file names, §2,
§4, §5, §6, §8, §9 and §10, and added one warning. Every other paragraph is the 09-19 text. **A
handoff cut by a coherence session at the end of its own job is a departure from the one-job rule,
made because `[A]` asked for it.** `Job75` did not open `AUTHOR-RECORD.md`.

---

## WARNING — how to talk to `[A]`

These are standing instructions from `[A]`. Each one has been given more than once.

- **Deliver one thing at a time.** Take one question, answer it, ask one question back, and stop.
- **Say the thing, not its number or its label.** He does not know the ruling labels or the job
  slot numbers. Say "whether a thought that stops is stalling or finishing", not an item number.
- **Name a case; never refer to it by its position in a list.** Write *only given up is chosen*,
  never *only the second is chosen*.
- **Name the mechanism instead of reaching for a metaphor.** Economic and financial words are out,
  including where the exchange carries the argument.
- **When a decision is yours to make, make it and report it.** Do not lay out options with costs.
  Ask him only when an important decision is unclear to you.
- **When he rules, carry the ruling out.** If something blocks it, find the whole obstacle and hand
  it over in one piece.
- **Quote the book's own sentence when you ask him about a claim.** Two sessions showed him a
  `[C]` paraphrase as though it were the book's text.
- **Show a change with the sentences around it, before and after.** He rewords much of it himself.
  That is the form he can work with.
- **Your own reading of a sentence is not a check.** You parse density without effort, so you
  cannot feel what it costs a reader. Run the mechanical checks in the style guide instead.
- **Never record a ruling without his words beside it.** On 09-23 a doctrine session recorded its
  own reading as ruled for the third time, and a coherence session found it only by collision. If a
  file marks something RULED and carries no words of `[A]`'s, put it to him in one line before acting
  on it. He has answered every such check in one word.

---

## 0. KINDS OF WORK

The numbers below are slots for kinds of work. They never change and are never renumbered. A new
kind is appended at the end. **The session counter in a name like `Job73` is a different number**
and is never a slot.

| Slot | Kind | Status |
|---|---|---|
| 1 | branch salvage | closed |
| 2 | drafting Part 2 | closed 08-18 |
| 3 | book 1 defects | open, rarely needed — see below |
| 4 | writer 2 pass | **live, wanted, and gated on Toby Marshall** — see below |
| 5 | recovery sweep | open, never run |
| 6 | Part 3/4 architecture | Part 3 is done; **Part 4 is still a sketch** |
| 7 | doctrine | the continuing job; `[A]` names it `doctrine` |
| 8 | depth and threshold | reserved; it must have a session to itself |
| 9 | cutting a handoff | last cut 2026-10-05, by `Job75` at `[A]`'s request |
| 10 | tools | open; no work waiting |
| 11 | composing prose for ruled doctrine | `[A]` names it `drafting` |
| 12 | coherence check | `[A]` names it `coherence` |

**Book 1 defects.** `[A]` ruled on 08-31 that book 1 is a reference for writing book 2 and that he
does not intend to fix it. So the repair standard for book 1 is: delete or mark what is false,
leave the gap, and write no replacement. On 09-06 he extended this: a question about book 1's own
content is not an open item for a handoff to carry. Book 1 defects noticed since then are listed
at §6 so they are not lost.

**Writer 2.** `[A]` 08-26: *toby is far from ready to look at this material* and *it would be good
if later sessions remind me that it is still needed.* So:

- Do not propose the writer 2 pass as the next session.
- Do not let it fall off the list.
- When you review the job list with `[A]`, say once, in one line, that the writer 2 pass is still
  needed and still waiting on Toby.
- Only `[A]` lifts the gate.
- Toby Marshall has received nothing from any session.

The writer 2 brief and the chapters 1–4 extract are **not in the current set**. The extract is
stale by measurement. Re-cut it from the current master and hash it before anything is sent.

**Part 4.** The live architecture for Parts 1, 2 and 4 is `BOOK2-ARCHITECTURE-20260815b.md`. Part 4,
*Parallels*, is a sketch there. Two of `[A]`'s rulings from 09-15 go into it: **the three poisons
correspond to the fixations**, and **the Trimurti corresponds to the three passages, not to the
orientations** — Brahma the arising, Vishnu the development, Shiva the ending. Part 4 needs an
architecture session before any drafting.

**Chapter 12, *Learning to See*,** is a reserved number in Part 2 and has never been drafted.

**Depth and threshold.** This is the question of whether how deep a person has fallen sets how
soon a process is overwhelmed. It would join the health axis to the circle, which the architecture
keeps apart. It must not be taken alongside anything else. The 09-06 handoff's §6 carries its
history.

### What comes next

**`[C]`'s recommendation, carried from `Job75` and `[A]`'s to assert:** a drafting session on
`FINDINGS-job75-20261005.md`. It is set out at §5. A coherence run should follow it. **The unease
material is a separate job** — see §6.1.

---

## 1. FILES

### 1.0 First — check what you were given

Do these before any other work, and report what they print.

1. **State your session name in your first message.** The counter and set date come from the
   manifest's `--label`. `[A]` gives the kind, usually in his first message. If his counter and the
   label's counter disagree, say so. The zip is named for the session that cut it, and the manifest
   inside it for the session that receives it, so `job73-out` carries `MANIFEST-job74`.
2. **Run `python3 setcheck.py verify <manifest> <dir>`** and quote its five-field summary: *N ok,
   N mismatched, N bad count, N missing, N not in the manifest*. `bad count` means the md5 matched
   and the declared word count did not.
3. **Run `python3 setcheck.py screen <dir>`** and act on each verdict, not on the number of hits.
   The verdict `CARRY, DO NOT READ` means keep the file and do not open it. The verdict `drop`
   means the file carries the old restriction string. A file that quotes either string fires on
   it, so read each hit before acting.
4. **Run `python3 setcheck.py sweep <dir>`** and check that the record's last marker and word count
   match §9 of this file.
5. **Say what is missing or extra, in one line.** Ask for missing files before starting.

**A set that verifies clean can still be the wrong set.** Verification checks a set against its own
manifest. It cannot tell you that the manifest belongs to an earlier session. `Job62` opened on the
previous session's set, which verified clean. Check that the set note inside is from the session
immediately before yours.

**Locate every book 1 and book 2 site by content, never by line number.** Both books have changed
line count many times. `grep` the sentence.

### 1.1 What travels, and what each kind reads

**THIS REPLACES THE OLD PER-KIND FILE ROWS.** For eight sessions running, set notes reported that
the rows did not match the sets. `[A]` sends the whole live set to every session. So the rule is
now: **the whole live set travels to every session, and this table says what each kind reads and
what it must not open.** An assembler does not choose files by kind. It carries the live set.

**The live set** is every file in the manifest. The two folders `spent/` and `superseded/` travel
beside it, outside the manifest, and are declared in the set note. A session does not read `spent/`
or `superseded/` unless a specific question sends it there.

**Every session reads:** this handoff, the incoming set note, and whatever §1.0 needs.

| Kind | Reads | Must not open |
|---|---|---|
| 11 drafting | `STYLE-GUIDE-20261005b.md`, `WORD-RULINGS-book2-20261005.md` and `RULE-referring-words-20260908b.md`, all three **before writing any prose**; the files it is applying (§5); the book 2 master. It greps book 1. Tools: `wordcheck.py`, `refcount.py`. | `AUTHOR-RECORD.md`; the three `NOTE-doctrine-from-job*` files, including `NOTE-doctrine-from-job66-20260912.md`, which is discharged and stays barred because it still holds unruled material; `spent/` |
| 12 coherence | the book 2 master; `CLAIM-INVENTORY-book2-20260902.md`; the word register and style guide, for their checks; the last drafting session's changes file (in `spent/` once a coherence run has read it); both architecture files; the census. It consults book 1. | `AUTHOR-RECORD.md` |
| 7 doctrine | `AUTHOR-RECORD.md`, in full — see §9; the three `NOTE-doctrine-from-job*` files; `ARC-ACCOUNT-from-job75-20261005.md`; `FINDINGS-job75-20261005.md` Part Four; the open items at §6; the book 2 master for reference; older `NOTE-*` files as a question needs them. | nothing |
| 6 architecture | both architecture files; the master; the census; `AUTHOR-RECORD.md`; book 1. | nothing |
| 9 handoff | everything except the record. | `AUTHOR-RECORD.md` |
| 3 book 1 defects | `rev2-0814t.md`, `DEFECTS-carried-forward-20260825b.md`, `REPAIRS-job16-book1-defects-20260825g.md`, `VERIFY-20260815.md`, `BOOK1-INDEX-20260815.md`, the eight figures. | `AUTHOR-RECORD.md` |
| 10 tools | the scripts. | `AUTHOR-RECORD.md` |

**Every session appends to the record before it ends**, including the kinds that may not read it.
See §9.

**Why a drafting session may not open the record or the doctrine notes.** A session that writes
prose from unruled material puts unruled claims into the book. The doctrine notes say on their face
that no drafting session writes from them. The record holds unruled material mixed with rulings.

**Exclude the record by name from every set-wide `grep`,** and write the exclusion into the command:
`grep --exclude=AUTHOR-RECORD.md`. A content search over `*.md` reads the record. `job38` lost half a
session to this.

**The eight figures travel in every set:** `enneagram-hexagon.svg`, `hexad-cycle.svg`,
`triad-hexad-cycles.svg`, `two-realm-grid.svg`, `wraparound-grid.svg`, `orientation-cycles.svg`,
`opposite-relationship.svg` and `double-ahead-triangles.svg`. Dropping them has twice started a
cycle of asking `[A]` to resend them. `opposite-relationship.svg` must be the 08-18 corrected file,
whose Type 3 label reads a 3 with a 5 wing.

**Files in the live set that are history, not work.** They travel because other files cite them.
`DOCTRINE-BRIEF-arcs-and-position-20260816.md`, `NOTE-drafting-8-15-findings-20260816.md`,
`NOTE-overlap-and-truthfulness-20260815b.md`, `NOTE-small-arcs-and-the-step-20260815.md`,
`NOTE-fixations-arcs-and-the-two-scales-20260821.md`, `NOTE-level-1-and-the-summit-20260821b.md`,
`NOTE-resolution-rate-and-the-descent-20260825.md`,
`NOTE-the-three-outcomes-and-the-burial-reflex-20260826c.md`,
`NOTE-the-two-tests-and-the-ignoring-habit-20260827c.md`, `NOTE-the-dwell-and-the-brake-20260901c.md`,
`NOTE-the-two-pressures-and-misattribution-20260902.md`, `NOTE-the-want-behind-the-fear-20260903.md`,
`NOTE-the-two-stacks-20260904.md`, `NOTE-two-sources-of-motivation-20260908.md`,
`OPEN-from-job25-20260829b.md`, `RECOVERY-NOTE-20260825b-procedural-changes.md`,
`SKETCHES-rewrite-by-author-20260901b.md`, `TODO.md`, `TODO-additions-20260814.md`. **Most of their
doctrine is now in book 2, and some of it has since been overruled.** A session that cites one checks
the book and the word register first.

**`VOCABULARY-INSTRUCTION-from-job67-20260912.md` is discharged.** `Job69` applied all of it. It is
kept as the authority for what was done at those sites. **Do not run it again.**

---

## 2. THE TWO BOOKS

**Book 2 — `BOOK2-20260923.md`**, md5 `40eb4fb3`, **38,752 words, 1,697 lines**, cut by `Job74` and
unchanged by `Job75`. It is the only manuscript being written. Parts:

- the Foreword and the Introduction
- **Part 1, The Model** — Ch 1–5
- **Part 2, The Finer Structure** — Ch 6–11. Ch 12 is reserved and undrafted.
- **Part 3, The Depth of Fixation** — Ch 13–17
- **Part 4, Parallels** — not drafted

Every master since 09-06 is in an earlier set's `superseded/` folder. `BOOK2-20260914.md` and
`BOOK2-20260915.md` travel in this one.

**Book 1 — `rev2-0814t.md`**, md5 `a6d71b1e`, **57,115 words, 2,595 lines**, unchanged since 09-04.
It is a reference. **Grep it; do not read it through.** It carries nine inline `[DEPRECATED …]`
marks and one block mark. Count them with `grep -c '\[DEPRECATED'`.

**The theory in one paragraph.** Nine types, each a pair of orientations, one in each of two realms:
**H** physical, **S** psychic. The three orientations are **A** enthusiastic, **B** cautious and
**Z** detached. A type is written as a pair, such as HB;SZ for a Five. The word `fixation` means a
person's hardened orientation, and the book uses it only from Part 3 on.

**Where the vocabulary lives.** `WORD-RULINGS-book2-20261005.md`, letter `c`, is the register of every standing
word ruling. `wordcheck.py BOOK2-<date>.md` lists every sentence that uses a word the register
governs. The register is the authority on vocabulary; this file does not repeat it.

---

## 3. WHO IS INVOLVED

- **The author, `[A]`.** He rules on all theory. He catches Claude's overreach reliably, so take a
  correction seriously and do not defend. He chooses the strength of each claim in the book himself,
  and the register lists the forms: *My proposal is that*, *I propose that*, *What I call*, *I
  suspect*, *I assume that*, *I take it that*, *What I have seen is*, *corresponds to*, *If the nine
  pairs are the nine types*. Do not collapse these into one form.
- **Writer 2, Toby Marshall.** Type 2. He reads for the effect on a reader. See §0.
- **You, `[C]`.** Editor, prover and skeptic. Do not agree by reflex. When `[A]` hands you a
  judgment, make it and give the reasons.

---

## 4. STANDING RULES FOR PROSE

**The rules are in three files, and a drafting session reads all three before writing.**

- `STYLE-GUIDE-20261005b.md`, letter `d` — how to write a sentence. Its sections cover writing about
  the world and not the book, giving nothing a person's properties unless it is a person, naming the
  mechanism, naming a case, no coined handles, staying at the scale of the thing, saying a thing once,
  vocabulary, what a reader can hold, and not transcribing a thought one for one.
- `RULE-referring-words-20260908b.md` — the referring-word count. It is a count, not a judgment.
  Every sentence may carry at most one distinct referring word. Each referring word points no
  further back than the previous sentence. One thing keeps one name across a passage. **A repair
  made to satisfy the count is new prose, and it is counted too.** `refcount.py` does the first step.
  It flags relative *that*, complementizer *that* and expletive *there* falsely, so a reader sorts
  those. It writes to a hard-coded path, `/home/claude/job59/refrows.json`; create that directory
  before running it.
- `WORD-RULINGS-book2-20261005.md` — which word names which thing. **Apply only entries marked
  RULED.** An entry marked `[C]` is a Claude reading, and `[A]` must be asked before it is acted on.
  **A new word ruling goes into the register in the same session, with his words,** and the file
  takes a letter. The register exists because `Job71` applied an unruled reading and reversed one
  of his rulings.

**The style guide is current.** Letter `d` carries `[A]`'s 09-09 withdrawal of his objection to a
later style job, with its condition — *the writing still has to be clear enough for me to understand
it when i read it later* — and his 09-21 correction about transcribing a thought one for one.

**Other standing rules that are not in the three files:**

- **Plainer beats shorter.** `[A]` 09-07: *claude gives too much weight to concision over clarity -
  again readers are less able to parse complexity than claude is.*
- **Read the file back before reporting an edit.** `Job54` reported four edits that were never
  written. Composed and applied are two different claims; say which one you are making.
- **Run the referring-word count before you show prose to `[A]`, not after.** `Job64` showed him two
  sentences that failed it.
- **State the scope of a proposed account before proposing it,** and name the types it covers.
  `Job70` was corrected four times for reaching for a general account first.
- **Decide which stage a sentence is about before changing its word.** Taking in and noticing are
  two different stages; see the register.
- **Book 2 uses no chapter numbers in prose.** Refer to the content or name the type.

**A later style job has a list waiting.** Three names for one act: `denial`, `blocked`, `buried`.
Ch 11's forward reference to Part 3. Ch 17's heading *The second way down, which is not blindness*,
which names a case by its position. In Ch 15, *that was the point of separating the three passages*
and *One question has been left open since the beginning* describe the book's own arrangement, and
*It also says what undoing one would involve* has an *It* pointing at nothing named nearby.

---

## 5. WORK OWED TO A DRAFTING SESSION

**One body of ruled work is waiting: `FINDINGS-job75-20261005.md`.** `Job74` applied the arc
account and `Job72`'s findings on 09-23, all but one item, which the new findings carry. `Job75`
then ran the coherence check and, with `[A]` and `Job70 doctrine 09152026`, settled what it found.

**The findings file is the one file to work from.** Nine `Job70` doctrine files fed it and are in
`spent/`. **Where any of them disagrees with a row of the findings, the row wins.** Do not reconcile
the doctrine files; read the rows.

In brief, and the file is the authority:

- **What moves a detached person.** A detached person raises wants and fears like anyone, less
  intensively. Wants come from the mental deposits. A realm raises nothing, and a process does not run
  in a realm. The lean is a source of nothing; it sets how much attention reaches each phase.
- **Action** is placed by motive for everyone. Panic and a grab are thoughts whose examining is cut
  short, never reflexes.
- **A fear lasts one thought and is settled only at the ending.** Only the bodily tension and the
  content of the unresolved matter cross to the next thought. Ignoring leaves those two and the habit;
  forgetting is ignoring after the tension subsides; burying is the same turning away at a feeling
  the person cannot bear. **A buried fear is mental deposits.**
- **`aversion`** is the cautious phase's word only. What each orientation cannot easily bear has no
  term.
- **The health axis measures noticing, not comfort.** **Detachment is not indifference**, and a person
  with no attraction and no aversion at all — what buddhism calls a buddha — is outside the model.
- **The counterfeit summit** is abiding in the detached phase, trained, which anyone can do.
- Six further faults, each under a ruling already in force.

**Read the findings file's header before anything else**: it says how its rows are marked, and which
lines are `[C]`'s and must be put to `[A]` first. Show `[A]` every change with the sentences around
it, before and after. Run `wordcheck.py` against letter `c` of the register before closing; its new
patterns catch the retired words.

**After the drafting, the claim inventory needs entries for Ch 14's eight sections**, which it has
never had, and Ch 15 and Ch 17 re-read entry by entry.

---

## 6. WHAT IS OPEN

Every item carries a name. Say the name to `[A]`.

### 6.1 For a doctrine session

- **The unease material — a job of its own.** `NEW-MATERIAL-the-unease-loop-20260923b.md`, cut by
  `Job70` on 09-23: fear, then tension, then a desire for relief, then a new fear. **It is not in the
  set**; `[A]` holds it. It is undrafted and needs its own sitting. Nothing in the manuscript is to be
  checked against it.
- **Four items from `Job75`**, at the end of `FINDINGS-job75-20261005.md`: whether a want is laid down
  when a thought ends; each end of detachment's own want; whether disliking disturbance is why a
  disturbance gets noticed; and a rule followed by rote, which `[A]` called *not in the model*.

- **Everything in `NOTE-doctrine-from-job61-20260909.md`.** Not one item has been taken since 09-09:
  the three wants behind the basic fears; the nine basic fears decoded; the basic desire; the
  inversion for a detached realm meeting a want; the third route; the contentless feeling; contagion;
  the caution lean and the larger peace; bodhicitta. It is `[A]`'s own material and a large part of
  the backlog.
- **`NOTE-doctrine-from-job62-20260910.md`.** `Job63` ruled its first three items. Its last item — a
  short section making explicit how fixations, the phases of a process and single thoughts relate — is
  still owed, and the arc account now bears on it. Its items on a biological share in fixations and on
  free choice are not recorded as ruled in any set note. One hedged sentence on the biological share
  is in Ch 15.
- **`NOTE-doctrine-from-job66-20260912.md` is discharged.** `Job67` closed all four of its items.
- **What settles a fear when a person's two fixations pull opposite ways in one detached phase.**
  Carried since 09-12.
- **`[A]`'s observation of his own cautious realm**, 09-08. A fear of his passes through detachment
  ignored, through enthusiasm as something he wants to think about, and back to caution, often losing
  its object. It is in `spent/RULINGS-job59-20260908.md` §9 and in the record. The arc account may now
  explain it; nobody has checked.
- **The vulnerability ordering.** Whether enthusiastic and cautious fixations are less vulnerable to
  burial than detached ones. `[A]` declined to rule it on 09-08. The book says the burial happens less
  often for them.
- **His phase mapping**, which realm is busy at which phase, and his definition of *noisy* applied in
  the detached phase. Both 09-12, both unruled. Do not draft them.
- **Whether blindness is a separate input to capacity or the realm-specific part of being caught.**
  Carried since 09-06.
- **Whether health widens the range in both realms together.** A `[C]` derivation, unruled.
- **Whether the nine closing lines of the type sketches hold at any depth.** No ruling asserts it.
- **Whether book 2 should carry the short-term fluctuation** that book 1 has.
- **Substance abuse and the descent.** `[A]` raised it on 08-27 as a subject. Nothing has been done.
- **How the way up the levels differs by fixation.** `[A]` named the null result as a possible answer.
- **The six-way derivation for Appendix G.** It needs Riso and Hudson's table of four attributes, which
  no set holds. No slot exists for it.
- **`[A]`'s own question from 08-21: *do we need thought arcs anywhere else?*** Carried by more than
  twenty sessions and never answered to him directly. `[C]` reading: the arc account answers it,
  since a thought cycle runs inside every size of process. Tell him so in one line and let him rule.

### 6.2 Bookkeeping

- **The dated subject index for the record is owed.** See §9. Only a session that may read the
  record can build it.
- **The claim inventory keeps one name.** It has been updated in place under one name since 09-06,
  like the record, against the rule that different bytes take a different name. `[C]` records this as
  the practice. `[A]` has not ruled on it and may reverse it.
- **Book 1 defects noticed and not queued.** In `rev2-0814t.md`'s Buddhist section, the sentence
  beginning *The model makes the same claim about the orientation cycle* ties the Trimurti to the
  orientations. That is against book 1's own Trimurti section and against the 09-15 ruling. The older
  list is `DEFECTS-carried-forward-20260825b.md`, which describes several closed items as open.
- **The claim inventory has no entries for Ch 14's eight sections**, which `Job74` wrote. Its 10-05
  section says what else is stale.
- **Do not nest the previous set inside an outgoing zip.** `job74-out-20260923.zip` carried a whole
  second copy of the set in a `job74/` folder, with an earlier cut of two files.
- **`NOTE-sections-predating-the-attention-account-20260914.md`** was named in memory of `Job69`'s
  close and never reached a set. `Job70` did the work from what `[A]` said. Nothing is known lost.

---

## 7. WORKING PRACTICES

- **One job per session.** Stop at the end of the job, not when the session runs down.
- **Doctrine and drafting never share a session.** A doctrine session does not touch the manuscript.
  A drafting session writes only from ruled material.
- **A doctrine session hands work over in a sited-closures file**: site and claim, never the finished
  sentence. `[A]` minted this form on 08-30.
- **A coherence session does not draft, move or rule.** It finds faults and states them as questions.
  Its product is the claim inventory and a findings file.
- **The tracking check belongs to coherence.** Follow one object from where it is raised, through
  what decides what becomes of it, to where it ends up. It finds disagreements whose parts are each
  correct in their own chapter, which passage-by-passage reading cannot find. It has been run on the
  fear and on motivation. Say which objects you ran it on.
- **Grep a closure's own words across the whole set; do not go to the line it names.** A closures
  file names the site somebody looked at. Nearly every closures file has had more sites than it named.
- **The sites most often missed are where a doctrine is used rather than discussed.** A fear passing
  through detachment names detachment's ends inside a sketch about caution.
- **A rewritten section is not a discharged ruling until every line pointing at it is found.** Grep
  the dead idea by its words.
- **A check that asks whether a whole subject appears anywhere is real evidence. A check that asks
  whether one passage survived is not,** because book 2 rewrites what it takes. Never report a
  passage absent without reading the chapter through.
- **Count case-insensitively and on word boundaries, and re-count before quoting a figure.** `Job69`
  miscounted three times by trusting a pattern.
- **A defect in instructions spreads into everything written under them.** Check an instruction
  against the doctrine when you write it.
- **A new ruling makes the material it does not cover easier to forget.** `Job58` reasoned from the
  absence of an older source of motivation on the day a newer one was ruled.
- **No block of text moves until both its joins are read** and what each side needs is written down.
  Moving a block often means leaving a short version of it where it was: minimal first and full later
  is allowed; two full statements is not.
- **When a repair removes a mark `[A]` ruled, say so at that site.**
- **Copy a file before renaming it.** `Job54` had to reconstruct a parent it edited in place.
- **Each revision of a file takes its own letter.** A file with different bytes never keeps a name it
  has had. The author record and the claim inventory are the two exceptions.
- **Status travels in the filename.** `SUPERSEDED__live__` names a file that has a live successor.
  `STALE__<origin>__` names a file gone stale with nothing replacing it. `VOID__` is for the old
  Movement branch alone. `JOB6-ONLY__` marks a file restricted to one job. Nothing is deleted.
- **Screen by content, never by name, size or date.**
- **Generate every manifest with `setcheck.py manifest`; never type one.** Counts use `LC_ALL=C wc -w`.
  Under `C.UTF-8` an em dash counts as a word and the figure runs two to three percent higher.
- **Run `quotecheck.py sweep --exclude AUTHOR-RECORD.md` at every set cut.** A section may be headed
  MEASURED only if `quotecheck.py` passes on it.
- **Do the fold check before assembling.** List the directory and compare it with what you believe
  you wrote. A file you cannot account for is a lost turn until proven otherwise.
- **A set note says what arrived, what was done, what is owed, and what `[C]` recommends next.** The
  next kind is `[A]`'s to assert, so the outgoing manifest label carries the counter and date and no
  kind.
- **How `[A]` files sets.** Each session keeps its own directory. He receives one zip for the next
  session. Ask before assuming a filing shape.

---

## 8. SESSIONS SINCE THE LAST HANDOFF

Each session's set note is in `spent/` and is the record of what it did. One line each here.

| Session | Kind | What it did |
|---|---|---|
| `Job53` 09-06 | coherence | second inventory pass |
| `Job54` 09-07 | drafting | twelve instances as the grip loosens; stress defined; stress realm-neutral ruled |
| `Job55` 09-07 | doctrine | two stages of seeing: taking in and noticing; motivation sets width of focus; `intuition` defined |
| `Job56` 09-07 | drafting | the two stages written; `register` and `surface` retired |
| `Job57` 09-07 | coherence | nine faults ruled; detachment's ends renamed caution end and enthusiasm end |
| `Job58` 09-08 | drafting | two sources of motivation; referring-word count ruled; when blocking happens |
| `Job59` 09-08 | coherence | motivation tracked; eight rulings; 113 referring-word sites counted |
| `Job60` 09-09 | drafting | the eight rulings written; narrow, wider, widest by strength of the want |
| `Job61` 09-09 | coherence | fear tracked; ten repairs; the job61 doctrine note cut |
| `Job62` 09-10 | drafting | the ten repairs written; thirteen rulings in session |
| `Job63` 09-12 | doctrine | forgetting is ignoring; bodily tension; burial starts around Level 7 |
| `Job64` 09-12 | drafting | the job63 closures written; ignoring lays down the habit |
| `Job65` 09-12 | coherence | childhood burial is present at the upper levels, so the brake is never idle |
| `Job66` 09-12 | coherence | tests re-run over Part 3; attention replaces time |
| `Job67` 09-12 | doctrine | a realm is a kind of subject matter; the basic fear defined by position in the chain |
| `Job68` 09-13 | drafting | nineteen sites; the naming convention for fixations and phases |
| `Job69` 09-14 | drafting | the vocabulary instruction discharged; `fixation` removed from Parts 1 and 2 |
| `Job70` 09-15 to 09-23 | doctrine | economic words ruled out; lean as offset of the center; the widened range; then, over many sittings without a manuscript, action placed by motive, the boundary of the model, `aversion` reserved, and the answers to `Job75` |
| `Job71` 09-15 | drafting | the job70 closures written; the author's voice at about twenty sites |
| `Job72` 09-16 | coherence | findings, the arc account, the word register, `spent/` created |
| `Job73` 09-19 | handoff | the 09-19 handoff, current-state shape |
| `Job74` 09-19 to 09-23 | drafting | the arc account into Ch 14; `crossing` retired; the phase split; a climb retires buried fears; `Job72`'s findings applied |
| `Job75` 09-23 to 10-05 | coherence | what moves a detached person tracked; questions settled with `[A]` and `Job70`; `FINDINGS-job75-20261005.md`; register letter `c`; style guide letters `c` and `d`; this file |

---

## 9. THE AUTHOR RECORD

**`AUTHOR-RECORD.md` holds `[A]`'s own words.** It exists because his 08-19 reasoning was recorded
nowhere and was nearly lost. Its rules are on its own face, so they survive even if a handoff drops
them:

- append only, newest last
- never folded, pruned, condensed or re-cut
- no date on the name, since it is never superseded
- verbatim, with the source marked wherever something arrived second-hand
- every append ends with a RECORD MARKER giving the date, the session, the append number, the parent
  word count and the new word count

**Every session appends what it produced before it ends.** A session barred from reading the record
appends blind. Put the block at the end, check that every byte above the join is unchanged, and
write the marker. **Check the parent count first:** if the record's last marker does not match what
the set note says, stop and say so. A stale copy is not wrong but short, and nothing inside it shows
the gap.

**A session appending for an earlier one** states the provenance first, quotes only what verifies,
and marks everything else as `[C]`'s report.

**Two entries are marked `PERSONAL — NOT FOR THE BOOK`.** `[A]` 08-24: *mark them not to go in the
book. okay for claude to consider.* The mark limits use, not reading. Nothing from those entries goes
into either book, a brief, or an extract.

**THE RECORD'S REACH, restated at this cut:** 73,080 words by `LC_ALL=C wc -w`, marker
`Job75 coherence 09232026`, handoff and style guide repaired, sixtieth append, parent 72,891. The
fifty-seventh append is `Job70`'s sittings from 09-16 on, written by `Job75` on its behalf; the
fifty-eighth is `Job75`'s own block; the fifty-ninth and sixtieth record the handoff and style guide. The md5 is in the
manifest. **Update this line in the same pass as any append** when a handoff is next cut;
`setcheck.py sweep` reads the marker without opening the file.

**Read-in-full, and the index that is owed.** On 08-20 `[A]` ruled that a doctrine session reads the
record through rather than grepping it, because a search finds only what the searcher already
suspects. The old wording tied the rule to the record staying shorter than the handoff. That
comparison means nothing now that this handoff is short. **The rule stays: a doctrine session reads
the record in full.** At the reach stated above that is a large read. **The record's own rules call for
a dated index of subjects at its head once it grows past easy reading.** That point is reached. The
index must be built by a session allowed to read the record, and it is appended under the file's own
rules, not cut in. **`[C]` recommends that the next doctrine session builds it first.**

---

## 10. DISCOUNTS — THIS CUT

**This cut was made by the coherence session that had just run, at the end of its own job.** It
knows its own session closely and the earlier ones only through the 09-19 handoff it updated. Discount
its view of what is open accordingly; the sessions that heard `[A]` are the sources.

**What it decided without a ruling:**

- updating the 09-19 file in place of reading every set note afresh
- moving all nine `Job70` doctrine files to `spent/`, with the findings file as the one place to work
  from — `Job70` asked for this
- dropping the bookkeeping line about the register's `fixation` entry, which letter `c` corrected
- the wording of the new warning about rulings recorded without `[A]`'s words

**What it did not do:** it ruled no doctrine, wrote no book text, and did not open the record. It did
not re-read the claim inventory entry by entry.

---

## MANIFEST ROW

| File | md5 | words | bytes | scope |
|---|---|---|---|---|
| `HANDOFF-20261005b.md` | generated at set-cut | | | set |

A file cannot carry its own md5, so `setcheck.py manifest` fills this row.
