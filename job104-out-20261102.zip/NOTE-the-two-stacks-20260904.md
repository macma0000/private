# THE TWO STACKS — RULED BY `[A]` 2026-09-04, `Job46 drafting 09042026`

**This closes the residue left open by fault 15 in `CLAIM-INVENTORY-book2-20260902.md`**, which the
`layer` → `blockings` / `material` rename could only hide: *are the developmental strata and the
axis's coverings the same stack?*

---

## The ruling

**They are not one stack. They correspond, approximately — and the correspondence is of the same
kind as the one between the Levels and the orientations.**

**The reason for the correspondence:** the disabilities a person accrues in descending the Levels
strike **the highest levels of thinking first**, and those are the ones **learned latest in life**.
So a descent runs roughly backward through a life, which is why the oldest material is also the
deepest.

**The difference that keeps them apart, and it is the important half:** the disabilities of descent
**cause emotional distress**. The inabilities of youth **do not**, and are **not symptoms of
emotional ill health**.

## What it settles

- **Ch 17's climb** can reach back into infant material without that material being low on the
  health axis. **An infant's inability is not a rung — it is off the axis.** *This protects the axis
  from the reading in which everyone begins life at the bottom.*
- **Ch 16's rule is not asked to carry a lifetime.** Its chain still generates fears rung by rung
  within a descent, which may take months at forty. Nothing about infancy is claimed by it.
- ***The exit is the climb performed on the last layer*** (Ch 17, closing the rung-climbing
  paragraph) stays as it is. It is Ch 16's sense, and with `layers` gone from the paragraph after it
  the ambiguity is gone too.

## Where it landed

**Ch 17 *Rising*, two paragraphs between *two things about the material* and *the method does not
change*.** They give the correspondence its mechanism, place its looseness in the same class as the
Levels-and-orientations correspondence, and name distress as what separates a disability from an
immaturity.

*Composed this session and on the page. `[A]` approved recording it as ruled doctrine.*

---

# THE INSIDE PRESSURE, AND HOW DEPOSITS DIFFER FROM BLOCKING — RULED BY `[A]` 2026-09-04

**This closes the item `Job44` left open and marked as new**, under fault 13: *buried material has a
growing effect, and that effect is what eventually forces sight* — which would have given Ch 17 a
second force, from inside, alongside the one it already has from consequences outside.

## The deposits are not a force

**They supply the occasions and they set the price. They do not push.**

- **The moments of clarity keep coming** because there is more and more material pressing to be seen.
  That is what the deposits explain.
- **What makes the comparison flip is the pain of staying**, and that comes from consequences, from
  outside. Unchanged.
- **The deposits also raise the cost of facing**, which the chapter already uses for the thin tail —
  further down there is more to unbury, so facing costs more.

**Why a second force could not be admitted.** The same growing quantity would raise BOTH terms of the
comparison at once — more buried material meaning both more pressure toward sight and a higher price
for facing. Nothing says which grows faster, and **the middle-gathering and the thin tail both stop
following.** *Two settlements were not taken: ruling the deposits a genuine second force and
rederiving the population shape over two, and ruling consequences and deposits one force seen from
two sides — the second fails because blindness reaches one and not the other.*

## Blocking is not a kind of deposit

**Content against procedure.** A deposit is material — a fear ignored or blocked, intact, causing
stress unseen, available to be surfaced. Blocking is an arrangement — a learned reflex that keeps a
recognition out of consciousness, reinforced each time it runs.

**They are made the same way**, which is why they read as one thing: both laid down by repetition,
both sunk below decision, both no longer tested, neither chosen. **That category already exists in
the book** — the fixation as a choice repeated until it sank beneath understanding, the oldest
material as an expectation that stopped being tested. **Blocking belongs there. Deposits do not.**

**They move in opposite directions.** The arrangement entrenches with every use while the material it
holds down accumulates — which is why the climb gets harder while the pressure toward sight rises.

## `[A]`'S RULING — the two are reached differently, and this is the load-bearing half

> **blindness is actively resisted and deposits require only fighting inertia however large.**

- **Deposits are hard by AMOUNT.** Nothing defends them. The cost is getting through the pile, and
  **inertia yields to repetition** — which is what the guess paragraph's accumulation across many
  moments describes.
- **Blocking is hard by OPPOSITION.** Not a quantity to get through but an arrangement that acts when
  approached, and **stronger every time it runs. Repetition feeds it rather than wearing it down.**

**So the climb is two different acts, not one act against more or less friction**, and only reaching
the deposits is a matter of persistence.

**What this derives that was previously asserted:** *why sight from outside matters.* An intervener
changes nothing about the amount of accumulated material, **but is not who the arrangement is
defending against, so what they see does not trip it.**

**And it narrows the open question about the felt-quality handle.** The oldest material is reached
through its felt quality, having no proposition to reopen, and blocking has no proposition either —
so the handle looked transferable. **On this ruling it is not: approaching the flinch is what the
flinch is watching for.** *Whether blocking can be worked on directly remains unruled.*

**PROSE OWED — none composed this session.** The Ch 17 sentence on what does not carry was written
without the deposits half, deliberately, pending this ruling.
