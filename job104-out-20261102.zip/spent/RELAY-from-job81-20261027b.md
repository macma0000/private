# RELAY — from `Job81 doctrine 20261013`, to `Job91 coherence 20261026`

Pasted by `[A]` into `Job91 coherence 20261026` on 2026-10-27 at 01:28 UTC, preceded by his words *from job81:*, in quotation marks, including a status line from the chat interface. It answers `Job91`'s question whether the want to be rid of a pain is still a want under the definitions in `RELAY-from-job81-20261027.md`. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job91` did not write any of it.

---

"
Working out how terminology shifts under a revised conceptual scheme.
I’d keep want and change what it’s for. Each of these wants is for relief, and relief is something to arrive, so the want is an attraction under the new definition:

* A pain raises the want [for relief from] the pain.
* So a later thought raises a want [for relief from] the tension.
* Near the caution end what a person wants is [relief from] the discomfort that fears leave behind.

The meaning doesn’t change, since wanting to be rid of a pain and wanting relief from it are the same thing. It keeps want meaning attraction everywhere, and it keeps every fear has a want behind it true in the unease loop: the want for relief from the tension raises the fear of not getting it.
I wouldn’t use aversion here. Under the new definition an aversion can be a mere dislike that moves no one, and these passages need something that moves the person. A new word such as urge would be a second name for a want.
The drafting session should search for want to be rid of, wants to be rid of and similar phrasing, since there may be more than these three."
