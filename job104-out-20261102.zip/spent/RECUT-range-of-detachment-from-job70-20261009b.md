# RE-CUT — *The range of detachment* — from `Job70 doctrine 09152026`, 2026-10-09

**Supersedes `RECUT-range-of-detachment-from-job70-20261009.md`.** That version fenced off three
doctrine questions as still open. **All three are settled now**, and the fence is lifted. Use this
version.

**`[A]` ruled the base, 2026-10-09:** "live text". The section as it stands in `BOOK2-20261009.md`
is the base. `DRAFT-range-of-detachment-job70-20261007b.md` is **superseded as a candidate text** and
is not to be drafted from.

Sited against **`BOOK2-20261009.md`**, md5 `5b04888a46edd85b818750732e427e99`, 40,415 words by
`LC_ALL=C wc -w`, 1,733 lines. The section runs from line 1203. Verify the same copy first.

Read with **`CLOSURES-SITED-job70-20261009c.md`**, which holds the rulings and every site outside
this section.

**`[C]` wording throughout, not ruled.** `[A]` approved earlier versions of some of these against the
superseded draft, not against the live sentences below, so rewrite freely.

---

## 1. The single-reason paragraph — the condition on wanting peace

**Why:** the paragraph says wanting peace does not make a person look for anything, without the
condition that makes the claim true. `[A]`: "i think wanting peace is what points to either solving
disturbances or distracting from them. the next paragraph says that." Both are true, and the
condition is whether peace holds. Also regularizes the verb — see closure C4 in the closures file.

**Now reads:** "One reason accounts for both the competence and the failure. The whole realm is open
to noticing when nothing pulls a person's noticing toward what a want or a fear is about. But
noticing needs a want or a fear pulling before it happens at all. What a detached person wants is
peace, and wanting peace does not make a person look for anything. So a detached person has the most
open to noticing of any of the three, and may notice the least."

> One reason accounts for both the competence and the failure. The whole realm is open to noticing
> when nothing draws a person's noticing toward what a want or a fear is about. But a want or a fear
> has to draw a person's noticing before any noticing happens. What a detached person wants is peace.
> While nothing is disturbing the person, wanting peace draws the noticing nowhere. So a detached
> person has the most open to noticing of any of the three, and may notice the least.

## 2. The conflict paragraph — the other half of the condition

**Why:** this is where wanting peace starts drawing the noticing, and saying so is what stops the two
paragraphs reading as a contradiction.

**Now opens:** "That also decides what happens when a detached person meets a conflict. Everyone
meets conflict; what differs is the method their orientation makes available for settling it."

> A disturbance changes that. When something does disturb a detached person, wanting peace draws the
> noticing — toward what is disturbing the person, or toward getting away from it. Everyone meets
> conflict; what differs is the method their orientation makes available for settling it.

The rest of the paragraph stands.

## 3. The pain-or-pleasure paragraph

**Why:** a pleasure being felt does not start a process by being wanted, and a pleasure does not work
in the same two ways a pain does. Closure A3.

**Now reads:** "A pain or a pleasure starts a process. A direct pain starts one, and so does anything
that brings a past pain to mind. A process started by a pain raises the want to be rid of the pain. A
pleasure starts a process in the same two ways, and so a pleasure being felt and the prospect of a
pleasure both raise the want to have more of the pleasure. Such a process raises fears as well as
wants. Examining a want raises a fear the same way, because what the examining finds is a pain that
would follow if the want went wrong."

> A pain or a pleasure starts a process. A pain starts a process when the pain is felt, and so does
> anything that brings a past pain to mind. A process started by a pain raises the want to be rid of
> the pain. A pleasure arrives on its own, or arrives when a want is met. A process started by a
> pleasure raises the want for more of the pleasure. Such a process raises fears as well as wants.
> Examining a want raises a fear the same way, because what the examining finds is a pain that would
> follow if the want went wrong.

**Check against the chapter before this one.** The worked example at line 1131 carries the same
material and the two restatements have to agree.

## 4. The repetition about wanting peace

**Why:** the single-reason paragraph already says both of these sentences, in nearly the same words.

**Now reads:** "In a realm where a person's fixation is detached, what the person wants is peace.
Wanting peace does not make a person look for anything. A person still has motivation in a detached
realm, and the motivation comes two ways."

> A person still has motivation in a detached realm, and the motivation comes two ways.

## 5. The capacity sentence `[A]` struck on 2026-10-07

**Why:** capacity to bear pain is one capacity for the whole person. What the fixation's strength
sets is how painful the fear is. Closures B1 and B2.

**Now reads:** "The person does not decide this. The fear has grown more painful than the person can
hold, and what gives way is the person's capacity, not the person's preference. What sets that
capacity is how strongly the person holds the fixation in the realm the fear is about. The stronger
the fixation, the more deeply caught the person is."

> The person does not decide this. The fear has grown more painful than the person can hold, and
> what gives way is the person's capacity, not the person's preference. How painful the fear is
> depends on how strongly the person holds the fixation in the realm the fear is about. The stronger
> the fixation, the more deeply caught the person is. Deeply caught, the same fear is more painful.

## 6. What recognizing the burial would require

**Now reads:** "...because recognizing the burial would begin to undo the burial."

> ...because recognizing the burial would require facing the buried fear.

## 7. The turning away from each fresh anxiety

**Why:** the clause is passive and does not say the turning away is automatic. `unconsciously` is
machinery of the same kind as `pre-conscious` and does not go on the page.

**Now reads:** "Each is turned away from in its turn."

> The person turns away from each fresh anxiety automatically.

## 8. A person *allowed* to notice

**Why:** nothing is doing the allowing.

**Now reads:** "What varies between the two leans in detachment is how much of the realm a person is
allowed to notice."

> What varies between the two leans in detachment is how much of the detached realm a person
> notices.

## 9. The Nine at the enthusiasm end

**Why:** `unconsciously` is machinery. `militantly` is strong and new, and nothing is lost by dropping
it, because the blindness loop paragraph already says a person is strongly pulled to stay in the
blindness. The book's own verb covers both ignoring and blocking, and `ignores` would narrow the case
to the fears that were noticed first.

**Now reads:** "The same Nine leaning toward enthusiasm is unconsciously but militantly blind to
exactly what would be uncomfortable to know."

> The same Nine leaning toward enthusiasm does not notice exactly what would be uncomfortable to
> know.

## 10. Which end is apparent

**Why:** which end is more apparent depends on who is looking, which the section cannot support. What
is left does not depend on the observer.

**Now reads:** "Of the two ends, the enthusiasm end is the more apparent, since its failures show
while the competence at the caution end stays quiet."

> The failures at the enthusiasm end show. The competence at the caution end stays quiet.

## 11. Distraction, near the enthusiasm end

**Now reads:** "Near the enthusiasm end what a person reaches for is a pleasure that takes them away
from what is uncomfortable. Any pleasure will serve, which is why the person has no one particular
pleasure in view."

> Near the enthusiasm end what a person reaches for is a distraction from what is uncomfortable. Any
> distraction will serve, which is why the person has no one particular thing in view.

## 12. The knowing-little paragraph moves

**Why:** the paragraph cautions against reading detachment off a person who knows little, and the
caution should land before a reader has built the wrong inference.

**Move it** so that it follows the single-reason paragraph, near the top of the section.

**Drop its closing sentence** — "What differs along the range of detachment is how much of the realm
the person is allowed to know." At the new position the range has not been introduced, and the
two-leans paragraph says the same thing where the range has been.

## 13. The short reflex paragraph goes

**Why:** it interrupts the account of the extremes and says less than the fuller paragraph.

**Drop:** "A reflex is different from both. Catching a falling glass is a reflex, and a reflex raises
no want."

**Keep** the fuller paragraph beginning "Turning away from a fear that cannot be borne is automatic",
which carries the falling glass and the whole distinction.

## 14. Panic and the grab leave the section

**`[A]` ruled, 2026-10-09**, after asking whether the book needs them at all.

**Drop all three paragraphs** — the one beginning "Each end also has an extreme", the one beginning
"At the enthusiasm end the extreme is a grab", and the one beginning "Both extremes fasten on one
thing".

**Why.** The panic claims are already written in the section on action without a full thought, in the
same two steps and the same order. The paragraphs contradict themselves in place, calling panic the
extreme of the caution end of the *detached* phase and then putting the action at the *cautious*
phase, with the same break for the grab. The phase assignment is already a rule in that other
section, with the snap as its worked case. And the noticing consequence is an instance of the
orientations chapter's rule that the harder a want or a fear pulls, the less of anything else is open
to noticing.

**The extremes were never detachment's.** The limits of detachment's range are already in the
section: the caution end processes fears, the enthusiasm end ignores them, and the further the lean
goes the further the turning away goes.

**The grab leaves the book**, which is closure C2. Nothing elsewhere depends on it, and the
orientation it would have illustrated behaves the opposite way under stress — an enthusiastic person
under stress stops short of acting.

## 15. Pure detachment is introduced by a question

**Why:** a question put to the reader breaks the voice, and the bold lead is doing a heading's job.

**Now reads:** "**And what of pure detachment?** For enthusiasm and caution, having no lean is..."

> **Pure detachment.** For enthusiasm and caution, having no lean is...

---

## Two settlements that do not apply to the live text

**The standing want.** Against the superseded draft, `[A]` settled that `standing want` was a second
name for the want for peace and should be named as such. **Do not apply that here.** The live text
says the standing want is to be rid of the discomfort that fears leave behind near the caution end,
and to get away from what is uncomfortable near the enthusiasm end. Those are two different standing
wants, and they say more than the want for peace does.

**Naming the realm in the two-leans paragraph.** The live text already says "how much of the realm",
so only the `allowed` problem remained — item 8.

---

## Not in this re-cut

**The arhat check.** The opener of Part 3 already distinguishes pure detachment from arhatship, so
this section is not to repeat the distinction. That passage says `arhat` where `[A]` ruled earlier for
lower-case `buddha` as the name of a class. Whether the ruling was superseded or not applied is
unknown to this session.

**Opposite leans in the two realms.** Settled 2026-10-09 and sited in the leans chapter rather than
here — see the closures file.
