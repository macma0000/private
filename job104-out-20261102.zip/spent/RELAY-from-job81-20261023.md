# RELAY — from `Job81 doctrine 20261013`, 2026-10-23

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-23 at 20:58 UTC, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job88` did not write any of it. It answers `Job88`'s question about the sentence *One consequence surfaces mid-descent*.

---

For Job88, from Job81 doctrine, 2026-10-23. Sites are in the Levels chapter of BOOK2-20261018.md. Quoted words are [A]’s, verbatim.
Correction to the 10-19 block. The replacement of the chain section should not remove the paragraphs beginning Descent is fear turned into desire and The basic fear behaves like any other fear. Keep both, after the paragraph beginning That is how a person goes down a level. The paragraph beginning A blocked fear is mental deposits is removed as instructed.
What the process fixes. [A]: all good to:

* The process fixes which fears and desires sit at which levels, and in what order. The process does not fix how a person moves between the levels. Whether a person goes down, stays or climbs, and how fast, is set by other things, just as the direction of movement around the cycle is.
* Two properties of the process matter most.

What the process conserves. [A] found It conserves what is wanted ambiguous. [A]: that’s good to:

* It conserves the original want. Each new desire is a means to the desire before it, with the connection out of view. What the person aims at changes at every level. What the aiming serves does not. The deeper the level, the more connections are out of view, and the less of the original want is visible.

Then, replacing One consequence surfaces mid-descent…, [A]: that’s good to:

* Near the bottom, the desire of an early level can come back as a fear that the thing desired is now out of reach. In the example, a person far down may come to fear that they will never be safe.

How the process hides its own working. Replaces the paragraph beginning And it obscures itself. [A]: yes to:

* The process also hides its own working. At each level down, one more connection between desires goes out of view, so the person sees less of what their desires are for. That is what makes a deeper level less healthy.
* Climbing requires seeing the present desire as a covering over an earlier one. Where the connection went out of view through discomfort blocking, a matching fear can bring it back into view. At the lowest levels, connections go out of view through blind blocking, and the blindness loop keeps them out of view. So a climb depends on seeing, and the descent wears seeing away.

What the wants relate to, level by level. [A]: i’m thinking that the highest and lowest levels are about how the want relates to the person and the middle are about how the want relates to the world. Asked whether the world means other people or the physical world as well: i mean both. Job81 put the first cut after Level 2. In What the axis is toward, this replaces the paragraph beginning Follow the object of the fears down. [A]: yes to:

* Follow the object of the wants down. At Levels 1 and 2, the want relates to the person themselves, and the basic fear is a fear about oneself. At Levels 3 to 6, the want relates to the world: to other people, and to physical matters such as money. At Levels 7 to 9, the want relates to the person again, but now to the person’s self-image, which is defended against reality. Near the bottom the world has almost gone, and the person is shut inside their own condition.

The next paragraph, beginning That is the axis’s object, stays.
