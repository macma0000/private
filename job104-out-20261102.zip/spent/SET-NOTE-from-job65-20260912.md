# SET NOTE — from `Job65 coherence 09122026`, 2026-09-12

## What arrived

One zip, `job64-out-20260912.zip`, directory `job65set`, verified against
`MANIFEST-job65-20260912.md`: **74 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the
manifest.** The screen fired twice and both are expected — `AUTHOR-RECORD.md` as CARRY DO NOT READ,
and `HANDOFF-20260906.md` quoting the restriction string. Both tools exempted themselves.

**This is a coherence session and the record was not opened.** `setcheck.py sweep` confirmed its
reach without opening it: 60,384 w, forty-fifth append, parent 59,528 — matching the manifest row
and Job64's set note. Chain clean.

**`[A]` named this session `Job65 coherence 09122026` and the label says `Job65 20260912`.** The
counter and the date agree and he asserted the kind himself. No collision this time.

## What this session did

**The three things Job64 handed over, in the order he set.** The first two turned out to be one
fault, not two.

**The brake and the two-phase descent are the same fault.** The falling chapter's brake runs
entirely on buried material: the struggling person settles which is more painful, staying or
unburying. Job64's two-phase paragraph says most fears above the unhealthy band are ignored rather
than buried and that the chain does the falling on its own up there. If that were right, one term
of the comparison would be missing across most of the range and the brake would be idle there.

**`[A]` ruled it and the ruling keeps the brake and the four sites that depend on it:**

> there is usually material buried in early childhood that is present in the upper levels. the
> normal riso abandonment of resolving fears leading to descent always potentially operates.

So blindness remains the only thing that moves a person on the axis. Little **new** material is
buried above the unhealthy band, which is what Job64 observed and is true. What is false is the
inference — the fall up there runs on ground already covered rather than on none.

**Nothing was added to the brake and no brake was assembled.** `Job31`, `Job32`, `Job33`, `Job49`,
`Job63` and `Job64` each declined to build one. This session found one already written and sound,
and what it needs is a join rather than a construction. **The sixth flag is discharged.**

**The claim inventory is updated.** Its last full re-read was 09-07 against a 32,533-word master,
and the master is now 35,695 — four drafting sessions on. The 09-08 and 09-09 coherence runs did
not re-read the entries; the 09-09 run followed one word through the book and appended findings
beside entries older than they were. **That gap is closed.**

## The two files cut

- **`CLAIM-INVENTORY-book2-20260902.md` — updated in place, 23,821 w → 27,339 w.** The name is
  unchanged, as it was for the 09-06, 09-07 and 09-09 passes; this file is updated rather than
  lettered, like the record. **Fifteen entries carry `RE-READ 09-12`, one section that had no entry
  has one, and fault 13 is discharged.**
- **`REPAIRS-job65-20260912.md`** — the two ruled faults with sites and proposed wordings, plus the
  two recorded as questions.

## What is owed to a drafting session

**Two repairs, both ruled, both small.** Ch 16's two-phase paragraph gives up its last two
sentences and keeps its observation. Ch 17's brake gains one sentence where the comparison is set
up, saying the second term is never empty. Proposed wordings are in the repairs file and both are
`[A]`'s to accept or change.

## What is owed to a doctrine session

- **`[A]`'s guess of 2026-09-12, and it is new:** the habit of ignoring may itself arise from
  blindness already laid down — *"i think most people have blindness from childhood and that other
  forms of neglecting fears might actually arise from it"* — and, asked whether ignoring can also
  arise on its own, *"my guess is that it can arise independently. but just a guess."* **If
  ignoring arises only from blindness, the four fates stop being four independent things.**
- **Fault 46** — Ch 16's *not laid down at all* against Ch 15's bodily tension. Possibly nothing,
  if `laid down` means the mental deposits and nothing else. Not put to him.
- **Fault 47** — the bodily tension does no work anywhere after Ch 15.
- **`NOTE-doctrine-from-job61-20260909.md` is still untouched and all of it stays owed**: the three
  wants behind the basic fears, the nine per-type derivations and the object rule, the basic
  desire, the contagion question, the cautious lean's understanding, and bodhicitta.
- **`NOTE-doctrine-from-job62-20260910.md`'s last item stays owed**: a short section on the
  relation between fixations, stages of the process arc, and single thoughts.

## What is owed to the later style job

Carried forward unchanged, plus one addition. `denial`/`blocked`/`buried` as three names for one
act; `loop` doing four jobs; Ch 11's forward reference to Part 3. **New: Ch 17's heading *The
second way down, which is not blindness* names its case by position**, which is the same fault
Job64 discharged inside that section's prose and left standing in the heading above it.

## Not covered

Parts 1 and 2 were re-read only at the entries the four drafting sessions touched. **Ch 2's nine
profiles and Ch 5's nine sketches remain inventoried in aggregate**, as since the build. **The four
tests were not re-run whole** over the amended entries — what this session found came out of the
re-read itself. A later coherence run should re-run test (d) over Part 3, which is the one nothing
has re-run since 09-02.

## Recurring defect, eighth run running

**The handoff's job-kind rows still do not match the sets.** Reported by `Job57`, `Job59`, `Job61`,
`Job62`, `Job63`, `Job64` and now this session. The kind 12 row still names `BOOK2-20260902b.md`
as the only thing the inventory is built from, and names neither the repairs file a coherence
session cuts nor the changes files it needs to target a re-read. **A handoff session should fix the
rows from the last eight set notes.**

## Record

**FORTY-SIXTH APPEND, BLIND** — the coherence kind appends without reading, as the handoff's row
says. The prefix above the join was verified byte-identical to the parent and its md5 came out
`08d122d0`, matching the arriving manifest row. Head is now **60,946 w, marker
`2026-09-12 · Job65 coherence 09122026`, parent 60,384** named in the block. The block quotes
`[A]`'s typed words and marks everything else as `[C]`'s report.

**The record has passed the handoff.** 60,946 w against the handoff's 76,495 — a gap of 15,549,
closing by roughly 700 a session. Whoever cuts the next handoff should expect to flip the
read-in-full rule and build the dated subject index the record's own rules call for.

## What comes next — `[C]`'s recommendation, `[A]`'s to assert

**Drafting**, for the two repairs, which are small enough to leave most of a session free for the
doctrine notes' backlog. **After that, a handoff session.** The live handoff is from 09-06 and the
fold debt is now eleven sessions deep.
