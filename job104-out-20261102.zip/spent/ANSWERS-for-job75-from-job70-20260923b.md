# ANSWERS for `Job75 coherence 09232026`, from `Job70 doctrine 09152026` — second sheet

Cut 2026-09-23, after `ANSWERS-for-job75-from-job70-20260923.md`, which stands unchanged. **This
sheet answers the ignoring question and adds two notes on the `aversion` census.**

**`Job70` has no manuscript in this sitting.** Everything is sited from `Job75`'s quotations.

---

## 1. What crosses between cycles — RULED, and it settles the ignoring question

`[A]` 2026-09-23: **the want becomes a fear, the tension and the content cross and that creates the
next want.**

**Only two things cross: the tension, and the content of the matter.** Nothing else.

**A want does not cross.** The next cycle's want is **raised out of** the tension and the content
rather than handed on, which is what *the arising hands nothing on* has always meant. **A want is
made fresh each cycle.**

**A fear does not cross either.** Within one cycle **the want becomes a fear**: the want is raised
at the arising, the examining finds trouble with it, and the fear is what the examining raises.
**Want and fear are one thing at two moments of the same cycle, not two things running in
parallel.**

**The two strands run side by side and must not be confused.** The tension runs from the end of one
cycle's fear to the next cycle's desire for relief — the unease loop's carrier. The content of the
matter continues because the matter is unresolved, and that is what gets a fear raised again. **The
tension does not carry the fear back. The tension produces a desire for relief; the unresolved
matter produces the fear.**

**`[C]` correction, owed:** `ANSWERS-for-job75-from-job70-20260923.md` says the tension is the only
thing that crosses. **That was answering a question about the fear and overstated it.** The content
crosses as well. **It is still true that the fear does not cross.**

## 2. The three sentences `Job75` put side by side

### *Ignoring leaves nothing mental at all: not the fear, and not the want behind the fear* — WRONG, three times

- **It denies the deposit.** `[A]` ruled 09-12 that ignoring does lay down a deposit, and the
  health-axis chapter says so: the ignoring itself is laid down, which is why it comes more easily
  each time.
- **It denies the tension.** Ruled 09-23: ignoring leaves tension behind, and the tension is what
  carries to the next cycle.
- **It denies the content.** The matter is unresolved and goes on being unresolved.

**What the sentence was reaching for is true and narrow: the FEAR is not kept.** Nothing is stored
and brought back, which `Underneath the Cycle` already states correctly. **Said that way the
sentence stops contradicting two chapters.**

**Repair sense:** ignoring leaves the tension, the unresolved matter, and the habit of ignoring
thickened a little. **It does not leave the fear, and it does not leave the want** — both are made
inside a cycle and neither survives one.

### *The want was never given up, so the problem still stands* — TRUE IN SUBSTANCE, WRONG IN WORDING

The person has not abandoned wanting the thing, so the substance is right. **But the wording reads
as the want sitting there between cycles, and a want does not cross.**

**Repair sense: the matter is unresolved, so the want is raised again.**

### *An ignored fear is not laid down at all. What does get laid down is the ignoring itself* — STANDS

Correct as written, and it is the sentence the other two have to be made consistent with.

### `Job75`'s question, answered directly

**Is the want still there after a fear is ignored?** **No — and the four-fates sentence is still
right about what it was describing.** The want is not there, because a want does not survive its
cycle. What is there is the unresolved matter, which is enough to raise the want again. **So
neither sentence is simply right: one denies too much, and the other says the want persists when it
is the matter that persists.**

## 3. Two notes on the `aversion` census

**The double name.** `Underneath the Cycle` says *a fear of looking* and the fixations chapter says
*an aversion to looking*, for one thing. **The survivor is `fear of looking`** — the word
`aversion` is reserved to the cautious phase, and this is a fear.

**One census site is more than a vocabulary fault.** *An aversion meets an aversion to that
aversion*, in the range-of-detachment passage, **is the fear-of-fear loop described in the retired
word.** A repair that swaps the vocabulary without noticing what the sentence is about **would lose
the connection to the loop.** That row should say so.
