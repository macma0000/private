# SET NOTE — from `Job58 drafting 09082026`, for the session that opens this set

**Cut 2026-09-08. Kind 11, drafting.**

**Every fault ruled for this session is written, and the paragraph owed is written.** Book 2 went
from 32,533 w to 33,402 w. Nothing else in the set was modified.

**The session ran under a correction.** `CORRECTION-job57-instructions-20260908.md` and
`NOTE-two-sources-of-motivation-20260908.md` arrived mid-session and changed the content of three
blocks that had already been drafted, two of them already written into the book. Section 6 below
records what happened and why it is worth having.

---

## 1. What arrived, and what the checks said

Incoming zip `job57-out-20260907.zip`, one directory, verified against
`MANIFEST-job58-20260907.md`: **53 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the
manifest.** Screen fired two, both benign — the record as CARRY DO NOT READ, and the handoff for
quoting the restriction string.

Record arrived **49,081 w, marker `Job57 coherence 09072026`, thirty-eighth append, parent
48,322** — matching `SET-NOTE-from-job57-20260907.md`, so the chain was clean and the record
stayed shut.

**The manifest label read `Job58 09072026` with no job kind.** The kind came from `[A]`'s naming
of the session and matched what `Job57` recommended.

---

## 2. DOCTRINE SETTLED TODAY

Four things were ruled during the session. All four are in the book or in the style guide, and all
four change how later sessions write.

### 2.1 The referring-word count — `RULE-referring-words-20260908.md`

**Ruled by `[A]` mid-session, for section 9 of the style guide.** It replaces the
restate-rather-than-point-back bullet's status: **it is not a rule of wording and it cannot be
applied by judgement.**

`[A]`'s own words, and the reason the rule takes the form it does: **`[C]` is far better at
holding what a word refers back to than a reader is. For a reader the limit is one or two.** So
`[C]` must write differently for a reader than it would for itself. He notes he has given this
correction repeatedly, that it was heard each time, and that it kept recurring.

**The recurrence has the same cause as the concision fault.** A drafter resolves a reference
without effort and cannot feel its cost, and reading the sentence back does not help, because
reading it back is the thing that is too easy. **What replaces judgement is a count**, run on
every sentence: at most one referring word; each pointing no further back than the previous
sentence; one thing, one name across the passage.

**A paragraph boundary does not extend the reach.** Settled in this session on a hit in the
paragraph owed.

**And the part a later session most needs: a repair made to satisfy the count is new prose and
gets counted like any other.** Running the count on the crossings head found three hits the
session had missed; the repair for one of them introduced two more, because the repair carried
`motivation` in as a second name for `wanting and fearing` while the drafter was attending to the
referring word. **That will keep happening. The count runs on what is written, including what is
written to satisfy the count.**

### 2.2 When blocking happens — Reading 1

**Ruled after `QUERY-when-blocking-happens-20260908.md`.** Blocking acts on a fear that arrived
and was not noticed. Not open: the block was sited at the noticing, so it cannot act before there
is anything to notice; the deposits ruling requires the fear to exist; and the maintenance loop
needs a real fear kept out of view, since something that never arrived cannot survive hidden and
stable.

**Five sites changed.** Ch 15's four-outcome expansion (*before it is noticed*), Ch 14's summary
(*before it is seen at all* → *before it is noticed*), Ch 15's two-questions paragraph (three
clauses, since *no sight to happen in* and *where sight has gone* both carried the capacity
reading), and two in Ch 16 that doctrine had not named — the descent passage and the
fractions-of-a-rung passage, both *before it arrives*.

The Eight's *before it arrives*, about ending a threat early, is unrelated and untouched.

### 2.3 The three crossings — Ch 5's head

**New passage.** A way of working crosses and holds; motivation crosses; a realm's standards and
limits cross and fail, which is book 1's critical confusion arrived at from the orientations.
**Four sketches each got one line naming which crossing is at work** — the One's, the Two's, the
Eight's for the failing kind, the Four's for the kind that holds.

**The Two's line is shaped differently on doctrine's ruling.** What crosses there is the psychic
realm's *not* having a ceiling, carried into a realm that has one, so the failure is a person
meeting a limit they did not expect rather than a thing that fails to work.

### 2.4 The paragraph owed — sited at Ch 15's empty assertion

A detached realm originates no motivation and receives it two ways: **from a process running in
that realm**, where examining a want raises a fear about it, available in every realm whatever
orientation is held there; and **from a realm held in enthusiasm or caution alongside it**. A
person with one detached realm has both. A Nine has only the first.

**Sited at *because the two orientations either side of detachment are what produce them***, which
names a means and supplies none, so the paragraph answers a question the book had already raised.

---

## 3. THE TRACKING CHECK — RECOMMENDED FOR THE HANDOFF, NOT FOR THIS NOTE

**The check:** follow one object from where it is raised, through what decides what becomes of it,
to where it ends up. This session ran it on a fear — the arc that raises it, the dwelling that
decides its fate, the outcome that keeps it — and it found the three-moments disagreement about
when blocking happens.

**Why it belongs in the handoff's account of what a coherence session does, and not here.**
Following one object across chapters is a coherence check, and coherence sessions do not read old
drafting set notes. Left here it will be lost. **Whether it goes in is not this session's to
decide.**

**The reason that makes it worth adding, and it should go in with the check:** the three-moments
disagreement survived three coherence runs, and it survived because **passage-by-passage reading
cannot find a disagreement whose parts are each correct alone.** Each of the three statements
reads correctly in its own chapter. Without that reason the check reads as one more item on a
list.

**Objects this session ran it on: the fear only.** A later session should say which ones it ran,
so the next coherence run can be asked for them by name.

---

## 4. TWO CENSUS MISSES, AND WHAT THEY HAVE IN COMMON

**The retired end names.** The census listed six sites. Three more were in the enthusiastic and
cautious sketches — *at the seeing end of the detached phase they often drop it completely*,
*unless the fear went by the seeing end*, and *the worry or fear moves into the seeing end of the
detached phase*. **A fear belonging to any fixation passes through the caution end on its way
out, so the ends get named in sketches that are not about detachment at all.** A census built by
asking where detachment is discussed cannot reach them. Found by grepping after the edit.

**The sixth `see` site, in Ch 9.** Every grep for `see` and `seeing` missed it, because the
competence was named `clear-sightedness`. **The word also carried `clear`, one of the two retired
end names, inside an adjective** — which no grep for the end names would have flagged either.
Found by searching for what the husband does rather than for the vocabulary.

**What the two have in common: the sites most likely to be missed are the ones where the doctrine
is being used rather than discussed** — which is also where a reader is most likely to be misled.

---

## 5. WHAT WAS WRITTEN

**Ch 4** — the two-faces block rewritten whole, on the corrected doctrine; the trouble sentence;
the width paragraph's ordering clause cut and one count repair. **Ch 5** — the three-crossings
head; four crossing lines; the Nine's block; the Four's and Five's obsession passages; four
competence openings and the Seven's noun. **Ch 7** — the two-faces section rewritten on the arc
source with dwelling; two retired-route sentences; `remnants` retired. **Ch 9** — the Maya and
Daniel site. **Ch 13** — the derivation, and *made deliberately* cut. **Ch 14** — the blocking
summary. **Ch 15** — the range of detachment throughout, the four sketches, the paragraph owed.
**Ch 16** — two Levels sentences, two blocking sites, one end name. **Ch 17** — the first
rate-setter.

**Vocabulary retired:** `trace` (four sites), `remnant` in the lean sense (two sites), `flavours`
(one). `shade` and `shading` were checked against the same test and kept, at four sites, because
each says what a lean does rather than where an amount came from. `remnants` in its leftover sense
was retired too, on doctrine's ruling that a phase is not an orientation and that what a process
carries gets no name.

**Left for doctrine and not written:** nothing.

---

## 6. THE CORRECTION, AND WHAT IT IS EVIDENCE FOR

`Job57` wrote in its instructions that the lean supplies the motivation noticing needs, and that a
Nine, having no other realm, gets it from the lean alone. **The defect was in the instructions
before it was in anyone's prose.** This session drafted three blocks under them — Ch 4, Ch 7 and
the Nine's — and two were in the book before the correction sheet arrived. All three were
rewritten.

**Recorded as what happened, not as an account of fault.** The three passages needed repair either
way. **The reason it is worth having is that a defect in instructions propagates into everything
written under them before anyone reads the prose.** That is an argument for checking instructions
against doctrine at the point they are written, which is what `Job57` did for itself in the
correction sheet.

**The general caution, from the note that raised it:** a new ruling makes the material it does not
cover easier to forget, not harder. The cross-realm source was a day old and vivid; the arc source
had been in the book for weeks, and the session that had just ruled the new thing reasoned from
its absence.

---

## 7. FOR THE NEXT SESSION

**A coherence run is the obvious next kind.** Everything above was written in one session against
doctrine that changed twice during it, and the referring-word rule arrived when most of the
session's prose was already in.

**Two things to ask it for by name.** The tracking check of section 3, on objects other than the
fear. And the referring-word count run across prose written before the rule existed, which is all
of book 2 apart from this session's own work.
