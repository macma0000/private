# SET NOTE — from `Job77 coherence 20261006`

This note goes to the session that receives `job77-out-20261006.zip`. `[A]` gives the kind of
session. The manifest label carries only the counter and the date.

## Arrival

The incoming zip was `job76-out-20261006.zip`. It verified against `MANIFEST-job77-20261006.md`:
**55 ok, 0 mismatched, 0 bad count, 0 missing, 82 not in the manifest.** The 82 were the `spent/`
and `superseded/` folders. The screen fired on the record as `CARRY, DO NOT READ` and on nine
`SUPERSEDED__live__` files, all expected. The record arrived at 73,632 words with the sixty-first
append marker, matching `Job76`'s set note.

**The handoff is behind.** `HANDOFF-20261005b.md` still names the 09-23 master and register letter
`c`. This session worked from `BOOK2-20261005.md` and register letter `d`. It now names letter `e`.

## What was done

A coherence run on `BOOK2-20261005.md`. Part 3 and Chapters 3 to 7 were read in full. Other chapters
were grepped where a finding sent this session. `[A]` carried questions to `Job70 doctrine 09152026`
and brought back its answers. **`[A]` ruled nine things**, mostly by accepting `Job70`'s answers, and
every ruling carries his words:

- trained detachment counters engagement, not a detached fixation;
- attention in a phase is a result of the fixation, and a fixation is the hardened orientation;
- the turning away is automatic, not a reflex;
- burying develops over a history, with what the deposit is;
- `decision` means the conscious kind only;
- recognition works one kind at a time, and the general understanding retires nothing;
- the act that blocks is *turning away from noticing*;
- a fear is not itself the disturbance;
- a detached person wants peace, and the enthusiasm end's want was inverted.

`FINDINGS-job77-20261006.md` holds every site. Its blockquotes check out:
`quotecheck.py quotes` reports 34 verified, 0 failed.

The disturbance sort that `[A]` deferred on 10-05 is done. The claim inventory now has entries for
Ch 14's current sections. Ch 15 and Ch 17 were re-read entry by entry. The tracking check was run on
one object, the turning away.

**The master was not edited.**

## What is in the set that is new

- **`FINDINGS-job77-20261006.md`**. A drafting session works from it.
- **`WORD-RULINGS-book2-20261006.md`**, letter `e`. It adds seven entries and four `wordcheck.py`
  patterns: `reflex`, `turning-looking`, `auto-decision` and `fixation-identity`. Against the
  current master the four patterns fire on exactly the sites the findings list. Run `wordcheck.py`
  against letter `e` after drafting.
- **`CLAIM-INVENTORY-book2-20260902.md`**, updated in place under its one name, as since 09-06. It has
  a 10-06 section at the end.
- **This note** and **`MANIFEST-job78-20261006.md`**.

## Moved

- To `superseded/`: `WORD-RULINGS-book2-20261005b.md`, as
  `SUPERSEDED__live__WORD-RULINGS-book2-20261005b.md`; and `MANIFEST-job77-20261006.md`.
- To `spent/`: `CHANGES-job76-20261005.md`, which this coherence run has read, and
  `SET-NOTE-from-job76-20261005.md`.
- **`FINDINGS-job75-20261005.md` stays live** for its Part Four. One item there, *each end of
  detachment's own want*, is closed by this session's findings. Its blockquotes are of the 09-23
  master and verify against `superseded/BOOK2-20260923.md`.
- **`ARC-ACCOUNT-from-job75-20261005.md` is unchanged.** The first line of its §7, *A fixation is
  attention concentrated at one phase*, is superseded by the findings' row on the definition. The
  findings say so.

## The record

One append was made, blind. Before writing, the parent's last marker matched the set note. The
parent's 435,339 bytes are byte-identical after writing, md5 `4ee0d280`. **Sixty-second append,
parent 73,632 w, head 77,107 w**, marker `Job77 coherence 20261006`. It quotes `[A]`'s messages
verbatim and every `Job70` text he pasted, marked as relayed.

## What is owed

- **A drafting session on `FINDINGS-job77-20261006.md`.** Four passages are to be rebuilt rather
  than reworded:
  - the job example and the lean paragraph in *The range of detachment*;
  - the learning paragraph of *Blocking is not a decision*;
  - the *Better is to recognize the burying itself* paragraph;
  - the account of what a burial lays down, which goes into *What previous thoughts have laid down*.
- **Open for doctrine:**
  - conscience for a person detached in the psychic realm;
  - three items carried from `FINDINGS-job75` Part Four: whether a want is laid down, whether
    disliking disturbance is why a disturbance gets noticed, and a rule followed by rote;
  - the unease material.
- **The cycle chapter's *desire for comfort*** is marked NOT RULED in the findings' last row. Show
  `[A]`.
- **The handoff** needs a cut when `[A]` wants one. Its §2, §4 and §5 are stale.
- **The writer 2 pass** is still needed, and is still waiting on Toby Marshall.

## Next

`[C]`'s recommendation, for `[A]` to decide: **a drafting session on
`FINDINGS-job77-20261006.md`**, then a coherence run on what it writes.
