# CLOSURES — SITED — `Job70 doctrine 09152026`, 2026-10-09

**Supersedes `CLOSURES-SITED-job70-20261009.md` and `CLOSURES-SITED-job70-20261009b.md`.** Use this
file. It carries the morning's vocabulary and capacity closures unchanged, adds the afternoon's four,
and holds every site outside the detachment section.

The detachment section has its own file: **`RECUT-range-of-detachment-from-job70-20261009b.md`.**

Sited against **`BOOK2-20261009.md`**, md5 `5b04888a46edd85b818750732e427e99`, 40,415 words by
`LC_ALL=C wc -w`, 1,733 lines. Verify the same copy before applying any row. Line numbers are from
that copy.

**Provenance is marked on every closure.** Where the thought is `[A]`'s, his words are quoted. Where
the working out is `[C]`'s and `[A]` accepted it, the file says so. **`[C]` wording** offered for the
page is not ruled, and a drafting session may rewrite it freely.

---

# Part A — Motivation vocabulary

## A1. Attraction and aversion are the two most general kinds of motivation

**`[A]` ruled:** "attraction and aversion go together in the sense that they are the most general
words for two opposite type of motivation. pain isn't a type of aversion, pain is the object of
aversion as pleasure is to attraction."

A want is an attraction when the want is for something to arrive. A want is an aversion when the want
is for something to go, or to stay away.

## A2. The reservation of `aversion` to the cautious phase is withdrawn

**`[A]` ruled:** "i agree to remove the reservation rule."

The want to be rid of a pain is an aversion and appears at the arising. Attraction and aversion belong
to motivation generally, raised at whichever phase raises the motivation.

**The word register entry needs re-cutting.** This session has never held the live register.

## A3. A pleasure is not what gets gotten

**`[A]` ruled:** "i meant pleasure happens without any want or when a want is satisfied."

A pleasure arrives on its own, or arrives when a want is met. So no want is a want to get a pleasure.
What gets gotten is the thing, and the pleasure is what makes the thing worth wanting.

## A4. There are three wants

**`[A]` ruled**, accepting the consequence of A3.

A want for something to arrive. A want for a pain to stay away. A want for a present pain to go.

There is no attraction-side want about something already present, because a pleasure already present
is not wanted — it is being had. **The want to keep is not a want of its own**, because keeping a
pleasure is wanting not to lose the pleasure, and losing a pleasure is a pain in prospect.

**Withdrawn:** two `[C]` constructions — a four-way classification of wants, and the want to keep as a
fourth kind. Both were built by symmetry rather than from the model. No session is to apply either.

## A5. `desire` is not taken into the register

**`[A]` ruled:** "desire is a type of want, the type on the attraction side, we don't have a word for
the want to eliminate something."

The gap on the aversion side is left unfilled and `desire` is not given a technical sense. `want`
carries the whole job, and the aversion-side want is written out as the want to be rid of a pain.

**`desire` stays where it already is.** The word is load-bearing in the health axis chapter through
the borrowed Levels — lines 1411, 1421, 1422, 1433, 1435, 1445, 1449, 1451, 1493. None of those uses
changes.

---

# Part B — Capacity, pain and what belongs to a realm

## B1. Capacity to bear pain is one capacity for the whole person

**`[A]` ruled:** "it feels to me that capacity to bear is one thing overall."

The sentence already in the orientations chapter stands: a person has one capacity to bear pain, not
one for each realm.

**Withdrawn, and it must not be picked up from anything else this session said.** `[C]` argued
earlier the same day that capacity is per realm, reasoning from the chapter's list of what each
orientation cannot easily bear, and recommended removing the one-capacity sentence. That reasoning was
wrong. The list names three different things that hurt, met by one capacity, and not three capacities.

## B2. What differs between the realms is how much pain an event produces

**`[C]` worked this out and `[A]` accepted it.**

How deeply caught a person is in a realm sets how much a given event in that realm hurts. Capacity is
what the pain is borne by, and capacity does not differ between the realms.

**Why this reads better than per-realm capacity.** A deeply caught Eight bears hardship and conflict
that would flatten most people, and cannot bear being vulnerable. One capacity says the plain thing:
hardship barely hurts them, vulnerability hurts enormously, and the capacity is the same throughout.

**The book already works this way in Part 3**, at the chapter on falling and rising: a fear gets turned
away from when the fear is more painful than the person can bear at that moment, and two things decide
whether it is — how much the person can bear, and how much of the fear comes at them at once. Capacity
and load, kept apart.

## B3. The test for whether a quantity belongs to the person or to a realm

**`[C]` worked this out and `[A]` accepted it.** It rests on two of `[A]`'s rulings: that a realm is
subject matter, and that pain is pain.

A quantity belongs to the whole person when the quantity has no subject matter. A quantity belongs to
a realm when the quantity is about a kind of matter.

- **Whole person:** capacity to bear pain; stress; depth, since the health axis has oneself as its
  object rather than a realm.
- **Per realm:** how deeply caught a person is; flexibility; the lean; how much a given event hurts.

## B4. Flexibility is per realm, and is not the same in both

**`[A]` asked and `[C]` answered, accepted.** His question: "does that mean that flexibility in the
two realms is always the same?"

No. Capacity became one by being separated from caughtness, and caughtness stayed per realm.
Flexibility is caughtness read from the other side.

This leaves the 2026-10-08 rulings standing: depth pushes both realms' flexibility the same way, each
realm's own history keeps the two apart, and that is why the two are related without being equal.

---

# Part C — The afternoon's four

## C1. Wanting peace draws the noticing nowhere only while peace holds

**`[A]` raised it and accepted the resolution.** His words: "i think wanting peace is what points to
either solving disturbances or distracting from them. the next paragraph says that. is there some way
to regularize the terminology between the previous paragraph and following paragraphs?"

Both claims are true under a condition the detachment section never states. While nothing is
disturbing the person, wanting peace draws the noticing nowhere. Once a disturbance arrives, wanting
peace draws the noticing — toward what is disturbing the person, or toward getting away from it.

**The book already states the condition** at line 381, two sentences after the unconditioned claim:
before anything disturbs a detached person, nothing in the realm is pulling at them.

## C2. Panic stays in the book and the grab leaves it

**`[A]` ruled**, having asked whether the book needs either.

**Panic stays**, and is load-bearing in four places: the disintegration mechanism for caution, where a
cautious person under stress acts on a fear that was raised and never weighed; the backward passage
from caution to enthusiasm, as panicking into recklessness; the childhood-burial claim in the health
chapter, where a small child can be brought to panic by very little; and what a person feels at the
moment of a burial. The definition in the section on action without a full thought is what makes all
four possible, by establishing panic as a thought rather than a reflex.

**The grab leaves the book.** The word appears twice in the whole manuscript, both in paragraphs now
removed, and nothing depends on either. The orientation a grab would have illustrated behaves the
opposite way under stress: an enthusiastic person under stress stops short of acting.

**Nothing is lost.** The rule assigning the phase has both halves exemplified already — the snap for
an action that fends something off, and the shoelace and the cup for actions that go toward something.

## C3. The two realms can lean to opposite sides

**`[A]` raised it and accepted the answer.** It follows from his 2026-09-15 ruling that leans are per
realm and can run either direction in each, and the eight-wings account requires it. Today's work left
that untouched, since flexibility and the lean are both per realm.

**It only matters for detachment**, because for enthusiasm and caution a lean shades the orientation
without altering what it does, while detachment's two leans are opposite functions.

**And only a Nine can have it in both realms**, since a Nine is the one type detached in both. For a
Two, a Four, a Five or a Seven there is one detachment lean, and the other realm's lean is a shading
of enthusiasm or caution.

## C4. The relation between motivation and noticing is `draws ... toward`

**`[C]` found the drift and `[A]` accepted the regularization.**

The defining sentence in the orientations chapter is that a want or a fear **draws** a person's
noticing toward what the want or fear is about, with **pulls** kept for how hard. Two later places use
a different verb for the same relation and are drift.

## C5. Health produces flexibility, and the re-cutting is small

**`[A]` ruled the flexibility account on 2026-10-08:** "i think both my fixations are strong. i propose
the idea that the result of higher levels may be flexibility rather than width and i think depth of
fall affects both realms."

**Scope settled 2026-10-09.** Two paragraphs change and nothing downstream does.

**The type-ahead account survives untouched.** It needs some of the orientation ahead to be available,
and availability survives: a flexible person reaches the orientation ahead by moving there when the
matter calls for it, rather than by standing on wider ground. The nine worked instances stay as they
are.

**What the range was is the observable consequence, not the mechanism.** A person who moves readily is
in fact found at various places over time. The places a person is found stay true as description, and
what gets replaced is the claim that health widens them.

**Job71's symmetry answer survives.** Health widening the range on both sides becomes flexibility not
favouring a direction. The preference for the side ahead stays as a separate fact, with a reason the
book already gives: ahead is the direction of the step.

**One gain.** Dropping `range` from that chapter leaves the word to the detachment section, where it
names the span between the two ends.

---

# Sites

## Chapter 4, *The Three Orientations* — the orientation definitions, lines 361 and 365

"Drawn toward what attracts" and "neither reaching for what attracts nor trying to avoid what
threatens". The pairing of what attracts with what threatens is looser than A1. Whether a Part 1
chapter needs tightening is `[A]`'s to decide. **Not ruled, and a check rather than a closure.**

## Chapter 4 — the noticing paragraph, line 369 — no change

This is the defining sentence for C4 and is already right: a want or a fear **draws** a person's
noticing toward what the want or fear is about, and the harder a want or a fear **pulls**, the less of
anything else is open to noticing.

## Chapter 4 — the moment-to-moment paragraph, line 373

**Drift, per C4.** Now reads: "Sometimes a want or a fear pulls a person's noticing toward one thing."

> Sometimes a want or a fear draws a person's noticing toward one thing.

## Chapter 4 — the detached person's own want, line 379

**C1 applies.** Now reads: "A detached person's own want is peace. Wanting peace does not make a
person look for anything."

**`[C]` wording:**

> A detached person's own want is peace. While nothing is disturbing the person, wanting peace draws
> the noticing nowhere.

## Chapter 4 — the what-cannot-be-borne paragraph, line 395

**B1 and B2 apply.** The list of what each orientation cannot easily bear stays. The sentences that
make caughtness set the capacity become sentences about how much pain is produced.

Now reads, in part: "How much of it a person can bear depends on how strongly they hold the
orientation. The more strongly a person holds the orientation, the more deeply caught they are. Deeply
caught, they can bear very little. Less caught, they can bear a good deal more."

**`[C]` wording:**

> Each of the three also comes with something a person cannot easily bear. What an enthusiastic person
> cannot easily bear is disappointment. What a cautious person cannot easily bear is losing control.
> What a detached person cannot easily bear is the discomfort that fear leaves behind.
>
> How much pain one of those produces depends on how strongly a person holds the orientation. The more
> strongly a person holds the orientation, the more deeply caught the person is. Deeply caught, a
> small disappointment produces a great deal of pain. Less caught, the same disappointment produces
> less.

## Chapter 4 — the stress-crossing paragraph, line 399

The one-capacity sentence **stays**. The sentence that makes caughtness set capacity per realm is what
changes.

**`[C]` wording:**

> Stress does not stay in the realm it came from. A person has one capacity to bear pain, not one for
> each realm, so a hard week in the physical world leaves less to face an inner fear with. What differs
> between a person's two realms is how much pain the same kind of event produces in each. Stress lowers
> the one capacity, so stress lowers what a person can face in both realms at once.

## Chapter 4 — line 401

"Whatever their separate depths" uses `depth` per realm, which collides with the health chapter's use
of the word for the axis, where depth belongs to the whole person under B3.

**`[C]` wording:**

> So the two realms are not independent, whichever one a person is more deeply caught in.

## Chapter 10, *As the grip loosens*, lines 914 and 916

**C5 applies.** Two paragraphs change, and `range` leaves the chapter.

Now reads: "The orientation a person holds in a realm has a center. Around the center is a range of
places where the person can be found. A person who is deeply caught has almost no range, and is found
at the center." / "Health widens the range, and widens it on both sides of the center. A person with a
wider range could live a little behind the center, as well as a little ahead of the center. A person
with a wider range generally prefers to live toward the side ahead. Being less caught does not move
the center."

**`[C]` wording:**

> The orientation a person holds in a realm has a center. A person who is deeply caught stays at the
> center, because a deeply caught person cannot easily move off it.
>
> Health makes the center easier to leave. A person who can leave the center is found a little behind
> the center at some times, and a little ahead of the center at others. Such a person moves either way,
> as the matter at hand calls for. A person who can leave the center goes ahead of it more often than
> behind it, because ahead is the direction of the step. Being less caught does not move the center.
> What being less caught changes is how easily a person leaves the center and returns.

## Chapter 10 — line 918, one phrase

Now opens: "On the side ahead, some of the orientation ahead is available."

> Ahead of the center, some of the orientation ahead is available.

The rest of the paragraph stands, and so do the nine type-ahead instances at lines 920 to 930.

## Chapter 11, *The lean in detachment is not like the others*, after line 1001

**C3 applies.** A new paragraph to follow the paragraph ending "What the range is made of, and what
happens at each end of it, is taken up in Part 3."

**`[C]` wording:**

> A Nine is the one type detached in both realms, so a Nine is the one person whose two leans in
> detachment can run opposite ways. A Nine leaning toward caution in the physical realm and toward
> enthusiasm in the psychic attends to what needs doing, and does not see the resentment gathering
> underneath. A Nine leaning toward enthusiasm in the physical realm and toward caution in the psychic
> lets the leak go unnoticed, and sees a conflict clearly enough to enter it.

The leak and the resentment are already the Nine's own examples at lines 659 and 661, so nothing new
is introduced.

## Chapter 11 — the same section, line 999

**A third instance of the allowing problem**, outside the detachment section. Now reads: "...and what
varies along it is how much of a realm a person is allowed to know."

> ...and what varies along it is how much of a realm a person knows.

## Chapter 14, *One thought, step by step* — the arising paragraph, line 1131

**`[A]` approved this wording verbatim:**

> A thought can also start with a pain or a pleasure instead of a want. A pain raises the want to be
> rid of the pain. A pleasure arrives on its own, or arrives when a want is met. A pleasure raises the
> want for more of the pleasure.

## Chapter 14 — a new paragraph after the one above

**`[A]` approved this wording verbatim**, and asked for a paragraph of its own rather than crowding
the paragraph above.

> A want is an attraction when the want is for something to arrive. A want is an aversion when the
> want is for something to go, or to stay away. Attraction and aversion are the two most general kinds
> of motivation.

## Chapter 14 — the examining paragraph, line 1135

The definition sentence moves out, because the definition is too narrow for A1 and sites the kind at
the examining. The examining raises a case rather than defining the kind.

**`[A]` approved this wording verbatim:**

> When the examining finds something that could go wrong, the examining raises a fear. A fear is one
> kind of aversion. Here the fear is of spilling the coffee.

## Chapter 14, *Disappointment*, line 1163 — no change

Both sentences stay true under A1.

## Chapter 14, *Action without a full thought*, line 1181 — no change

The panic paragraph stays exactly as it is. Under C2 it is the definition the book's four other uses
of panic depend on. **No grab paragraph is added here** — C2 takes the grab out of the book.

## Part 3 opener, line 1019 — no change

"A person who has given up all attraction and all aversion would mind nothing at all." This needed the
general sense of the word, and A1 supplies it.

**One check for a drafting session.** That passage says `arhat`. `[A]` ruled earlier for lower-case
`buddha` as the name of a class rather than the particular man. Whether the ruling was superseded or
simply not applied is not known to this session.

---

# Not in this file

**The detachment section**, which has its own file: `RECUT-range-of-detachment-from-job70-20261009b.md`.

**The held sentence** — "What the person can bear is set by what previous thoughts have laid down, and
most of all by what has already been buried near the same matter." Under B1 and B2 the sentence splits:
what previous thoughts have laid down sets the one capacity, and what has been buried near a particular
matter sets how much that matter hurts. Not sited, because `[A]` has not said where the sentence goes.

**The unease-loop material**, held in `NEW-MATERIAL-the-unease-loop-20260923b.md` for a drafting
sitting of its own.

**The note on what the Introduction should say about recognition**, in
`NOTE-introduction-recognition-20261007.md`, to be carried in the set and entered in the handoff's open
list, and not acted on until `[A]` says so.
