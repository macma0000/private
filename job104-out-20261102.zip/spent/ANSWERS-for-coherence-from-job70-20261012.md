# ANSWERS — for the coherence run — from `Job70 doctrine 09152026`, 2026-10-12

**Supersedes the two blocks `Job70` sent on 2026-10-11 on disappointment.** Both have been overtaken.
Use this file.

Read with **`BRIEF-for-coherence-from-job70-20261011.md`**, which holds the sweeps and the warnings
about where this session has been unreliable.

**Provenance is marked on every item.** `[A]`'s words are quoted where they are his. Where the working
out is `[C]`'s and `[A]` accepted it, the file says so. **`[C]` wording** is not ruled and may be
rewritten freely.

---

# 1. Disappointment

**Not a kind of aversion, and not a pain.** `[A]` ruled: *disappointment is neither.* An aversion is a
want for something to go or to stay away, so it points at something not yet settled, while a
disappointment arises once the outcome is known. **So *Disappointment is another kind* is at fault.**

**What it is.** `[C]`'s wording, `[A]` accepted:

> A disappointment arises when a want has been met by an outcome that cannot satisfy it.

**How it comes about, where an aversion was raised.** `[A]`'s idea, agreed:

> Where an aversion about the outcome had been raised, the disappointment is what is left when the
> aversion is given up.

**Why the definition stays broader than the mechanism.** A want can be examined with nothing found that
could go wrong, so no aversion is raised; the want is then met by an outcome that falls short. The
book allows this — *if the person's hands had been empty, the examining would have found nothing that
could go wrong.*

**Acceptance is one of disappointment's fates, not what disappointment is.** `[A]`: *acceptance is one
possible fate of disappointment.* It is the fate called *given up on*. **This supersedes `[A]`'s
earlier wording, *an acceptance that what was desired cannot be had*, which you recorded in his
words.**

**`Fear and disappointment meet the same four fates` stays.** Your objection inverts: a disappointment
sits alongside a live want, since a person turned down for the job still wants the job. **Blocked is
the least peripheral of the four here**, because the orientations chapter names disappointment as what
an enthusiastic person cannot easily bear, so a person who never lets it be felt is a case the model
has to cover.

---

# 2. Regret

**The entry that produces a regret is where a regret gets defined.** The *given up on* entry already
says what remains is a regret. It takes both products now.

**`[C]` wording, `[A]` accepted:**

> Giving up a want sometimes leaves something behind. Where what remains is a regret, the want was to
> change an outcome the person could have avoided by acting otherwise. Where what remains is a
> disappointment, the person could not have acted otherwise.

**Two things `[C]` sent you yesterday are withdrawn, and must not be applied.**

That a regret is told from a disappointment by whether the person's own doing was in the failure.
**Too coarse.** A person can do their best at a presentation, watch it fall short, and be disappointed
rather than in regret — their own doing, and no regret in it. **The criterion is whether the person
could have acted otherwise.**

That a painful outcome starts a process, asserted inside the regret account. **An overclaim.** A
painful outcome can go unfelt, and even where the pain is felt the want raised need not be the want to
change the outcome. The cycle is explained where it belongs and this entry does not restate it.

**The want to change an outcome has three fates, not four.** `[C]`'s reading, `[A]` agreed. Worked
through is unavailable, because a worked-through want ends by being met and this want cannot be met.
Of the other three, only *given up on* leaves a regret. *Ignored* leaves the person turning the matter
over, and a person can stay there indefinitely without ever reaching a regret. *Blocked* leaves the
person not knowing the thing is beyond changing, and going on trying.

**The turning over belongs with the unease-loop material, not here.** It is a fate of its own, not a
stage on the way to giving up.

**What makes the difference between something remaining and nothing remaining** is already in the
model: whether the outcome is painful to that person, which depends on what previous thoughts have
laid down.

---

# 3. What a thought leaves — `[A]`'s simplification

**`[A]` proposed it and `[C]` recommends taking it.** It replaces `[C]`'s earlier proposal, which
posited two kinds of residue and made working through an exception. Both of those come off.

**`[C]` wording:**

> Every thought lays something down, and later thoughts arise out of what earlier thoughts have laid
> down. Some of what was laid down is noticed again and meets a fate of its own. What a burial laid
> down is not noticed again, because the turning away comes before the noticing.

**Why one kind rather than two.** The decision in the coffee example is laid down and the next thought
acts on it. The tension that ignoring leaves is laid down and is felt. What a burial laid down is not
available, and the reason is the turning away rather than the deposit being a different sort of thing.

**Two `[C]` claims withdrawn.** That a deposit is never noticed — true only of buried ones. And that
working through leaves nothing of either kind — every thought lays something down, including a
worked-through one.

**What it is worth.** It covers a fear, a disappointment, a regret and the unease loop in one place,
and stops the question of whether a newly named thing meets the four fates from recurring.

**Do not add the specifics here.** The fates chapter already says what ignoring and blocking leave,
and the worked example says what a decision leaves. Repeating them would be the disguised restatement
the style guide bars.

---

# 4. Working through

**The entry is right and its wording is loose.** *Nothing is left over and nothing has to be put
anywhere* is about unfinished business — the fear and the want are gone. It is not a claim that the
thought laid nothing down, and the worked example says the decision is laid down.

**`[C]` wording for the entry:**

> The fear is gone and the want is gone, and neither is left waiting to be dealt with.

**And the climb needs no habit of working through.** `[C]` raised the worry and withdraws it. The
intervener passage already supplies the compounding: every small part worked through leaves a little
less buried, and a person with a little less buried can bear the next part. **Do not add a second
account of the same compounding.**

---

# 5. The burial paragraph — `[A]` rules burial gradual

**`[A]`'s ruling:** burial is gradual, and a single traumatic incident can bury gradually as the
incident is processed repeatedly. **He also withdrew his own 10-06 addition** that the first time a
fear is noticed, leaves a heavy deposit, and nothing is blocked in that cycle. **That addition is
dead and no session is to apply it.**

**So the blindness loop needs no beginning.** Gradualness dissolves the question rather than answering
it.

**This brings the paragraph into line with the Blocked entry, which already says it** — *Ignoring and
blocking begin as the same turning away. At first the only difference between them is whether the
person can bear the feeling of the fear. Every later difference comes from the turning away, which
feeds itself.*

**One constraint on the wording.** The gradient cannot be parts of one fear, because `[A]` ruled that
one fear meets one fate and a fear does not split between fates. What changes across the history is
which of the several fears an incident raises are blocked rather than ignored.

**`[C]` wording, `[A]` approved:**

> A burial is not one event. Suppose an incident raises fears that are more than a person can bear.
> Each fear meets one fate, and at first most of the fears are noticed before being turned away from.
> What the turning away leaves behind is that certain thoughts are painful, together with a turning
> away from noticing those thoughts. The matter is unresolved, so fears about it are raised again,
> whether by the same incident coming back or by a fresh incident of the same kind. Each time, more of
> the fears are turned away from before they are noticed. So burying develops gradually, and the
> turning away becomes automatic over that history.

**And the paragraph's old opening goes.** A burial is what a history lays down, not what one thought
does.

---

# 6. The held sentence about capacity

It splits, and each half has a place waiting.

**To the orientations chapter, immediately before the stress paragraph.** That chapter says a person
has one capacity to bear pain and says what lowers it, and never says what sets it.

> What a person can bear is set by what previous thoughts have laid down.

**To the burial account, extending a sentence already there.** The account says what a burial lays down
is that certain thoughts are painful. What is missing is the gradient.

> How painful those thoughts are depends on how much has been buried about the same matter.

**`Most of all` dissolves** rather than being lost: once one half sets capacity and the other sets how
much a matter hurts, there is no ranking left to make. **And `buried near the same matter` becomes
`about the same matter`**, since `near` makes subject matter spatial.

---

# 7. The unease loop and the three orientations

**`[A]` asked whether the loop is stronger anywhere. The answer is no, and `[C]` recommends the book
not rank them.** A ranking would need a quantity the book does not have — `[C]` had rolled together how
much of the time a person is in the loop, how hard it pulls, and how much goes unresolved.

**Each orientation has an exit through its own competence.** A cautious person can come to understand
the matter. An enthusiastic person can act on it. Detachment at the caution end disposes of the fear.

**One position has no exit through competence.** At the enthusiasm end of detachment the fear is
blocked and leaves view, and the unease does not. The want is then to make the unease go away, and
distraction does not remove unease — it occupies the person. So the want fails and is raised again,
with no object to act on. **A feeling cannot be solved.**

**`[C]` withdraws what it said earlier**, that the loop ends at the enthusiasm end of detachment. Only
the loop about the matter ends there. The loop about the unease continues, and it is the harder one.

**The only exit there is capacity rather than competence** — bearing the unease instead of wanting it
gone, which is what `[A]` ruled on 10-10 that trained abiding acts on. The book already says this is
where the least of anything is open to noticing, so nothing can arrive to end it.

**Two corrections to `[C]`'s earlier account of the orientations.** An enthusiastic person circles the
same matter by a new route each time rather than scattering across matters — `[A]`'s own 10-04 words
have the person giving up with the intention that the fear still needs dealing with. And while the loop
runs, the enthusiast is the more narrowed of the two, not the less, since the book says an
enthusiastic person's noticing is narrow and a cautious person's is wider.

---

# 8. `arhat`

**`[A]` ruled, 2026-10-11:** `arhat` in the Part 3 opener supersedes his earlier ruling for lower-case
`buddha` as the name of a class. **The word register entry changes.**

---

# 9. Censuses, all of which doctrine cannot run

**The four fates' entries appear to be written in terms of a fear** — *the want behind the fear is
dropped, and with the want gone the fear is gone with it.* Each has to work for a disappointment too,
where there is a want and no fear. **Report which need generalizing.**

**`Regret` is nowhere told apart from disappointment.** **Find every use and report whether any is
doing a disappointment's work.**

**Six uses of `looked at` remain.** `[C]` said in September that the word was wrong throughout, and
`Job77` found 36 uses, most of them ordinary English. **Judge the remaining six one at a time. Do not
sweep.**

**One use of `fire` is in the master** and `[C]` has not read it. Almost certainly ordinary English.
**Look at it rather than taking `[C]`'s word.**

---

# 10. One figure of `[C]`'s that never reached the book

`[C]` wrote *the turning away fires before noticing* in its own answers, and `[A]` ruled the figure too
metaphorical. **The word does not appear in the master**, so nothing needs repairing. The plain form is
*the turning away comes before the noticing*, which is the book's own ordering. **It does appear in the
author record, which is append-only and cannot be corrected.**
