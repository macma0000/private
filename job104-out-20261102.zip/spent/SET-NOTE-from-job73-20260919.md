# SET NOTE — from `Job73 handoff 20260919`

To the session receiving `job73-out-20260919.zip`. `[A]` names that session; the manifest label
carries the counter and date and no kind.

## Arrival

Incoming zip `job72-out-20260916.zip`, verified against `MANIFEST-job73-20260916.md`: **55 ok, 0
mismatched, 0 bad count, 0 missing, 43 not in the manifest.** The 43 were the `spent/` and
`superseded/` folders, which `Job72`'s note declared. The screen fired twice, both expected: the
record as `CARRY, DO NOT READ`, and the old handoff for quoting the restriction string. The record
arrived at 69,084 w, fifty-third append, marker `Job72 coherence 09152026`, matching `Job72`'s note.

## What was done

**`HANDOFF-20260919.md` replaces `HANDOFF-20260906.md`.** It is a current-state file of 6,176 w.
The 09-06 file is in `superseded/` as `SUPERSEDED__live__HANDOFF-20260906.md`. **Read the new
handoff first; this note only says what changed in the set.**

The largest change for an assembler: **the whole live set travels to every session**, and the new
handoff's §1.1 says what each kind reads and must not open. This replaces the per-kind rows that
eight set notes reported as not matching the sets.

## The set

- **New:** `HANDOFF-20260919.md`, this note, `MANIFEST-job74-20260919.md`.
- **Moved to `superseded/`:** the old handoff and the incoming manifest.
- **Moved to `spent/`:** `SET-NOTE-from-job71-20260915.md`, `CHANGES-job71-20260915.md`,
  `SET-NOTE-from-job72-20260916.md`. `spent/SPENT-NOTE-20260916.md` gained a section saying so.
- **Unchanged:** both manuscripts, every note, the claim inventory, the word register, the style
  guide, the figures and the scripts.
- **`superseded/` and `spent/` travel outside the manifest.** `setcheck.py verify` reports their
  files as not in the manifest. That is expected, and this note declares them.
- **The screen fires twice, and both hits are expected.** The record fires `CARRY, DO NOT READ`.
  The old handoff in `superseded/` fires `drop`, because it quotes the restriction string. The new
  handoff does not fire.

## The record

**Fifty-fourth append, blind.** The first 407,247 bytes were verified byte-identical to the parent,
md5 `cff12d1a`. Head is now **69,240 w**, marker `Job73 handoff 20260919`, parent 69,084 named in the
marker. `setcheck.py sweep` reads the new marker.

## Next

`[C]`'s recommendation, `[A]`'s to assert: **a drafting session for the arc account**, then a
drafting session for the rest of `FINDINGS-job72-20260915.md`. The handoff's §5 sets out both.
