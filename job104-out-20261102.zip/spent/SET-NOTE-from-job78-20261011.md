# SET NOTE — from `Job78 drafting 20261007`

This note goes to the session that receives `job78-out-20261011.zip`. `[A]` gives the kind of session.
The manifest label carries only the counter and the date.

## Arrival

The incoming zip was `job77-out-20261006.zip`. It verified against `MANIFEST-job78-20261006.md`:
**55 ok, 0 mismatched, 0 bad count, 0 missing, 86 not in the manifest** (the `spent/` and `superseded/`
folders). The record arrived at 77,107 w, sixty-second append, matching `Job77`'s set note. During the
session `[A]` added `ADDENDUM-job77-20261007.md`, `NOTE-introduction-recognition-20261007.md`, and from
`Job70 doctrine 09152026` the files `CLOSURES-SITED-job70-20261009c.md` and
`RECUT-range-of-detachment-from-job70-20261009b.md`, with a record carrying doctrine's append.

## What was done

A drafting session. Everything is in **`CHANGES-job78-20261011.md`**. In brief: all of
`FINDINGS-job77-20261006.md`; the addendum (pain of any kind, the tooth, desperation, `brake` out of the
book); doctrine's fifteen re-cut items and every closures site; and the passages `Job77` named as
rebuilds, each shown to `[A]` and approved.

**The master is `BOOK2-20261011.md`**, md5 `22eca00d`, 40,396 w by `LC_ALL=C wc -w`. A working copy,
`BOOK2-20261009.md` (md5 `5b04888a`), went to doctrine on 10-09 and is in `superseded/`.

**Register letter `f`, `WORD-RULINGS-book2-20261009.md`**: `aversion` no longer reserved to the cautious
phase; attraction, pleasure, `desire`, `draws`, capacity, `brake`, the grab, and `allowed to notice`. Five
patterns added or rewritten. `wordcheck.py` against letter `f` shows no retired form in the master.

## The record

Three appends were made blind, each with the parent's bytes checked unchanged:

- **sixty-third**, `Job77`'s late addition from the addendum, on its behalf (parent 77,107, head 78,399);
- **sixty-fourth**, this session mid-way (head 80,333);
- doctrine then made the **sixty-fifth** (head 83,603, md5 `606b4570`);
- **sixty-sixth**, this session's close (parent 83,603, **head 84,610 w**, md5 `19f449d8`), marker
  `Job78 drafting 20261007`, closing.

## Moved

- To `spent/`: `FINDINGS-job77-20261006.md`, `ADDENDUM-job77-20261007.md`,
  `CLOSURES-SITED-job70-20261009c.md`, `RECUT-range-of-detachment-from-job70-20261009b.md`,
  `SET-NOTE-from-job77-20261006.md`. All applied.
- To `superseded/`: `BOOK2-20261005.md`, `BOOK2-20261009.md`,
  `SUPERSEDED__live__WORD-RULINGS-book2-20261006.md`, `MANIFEST-job78-20261006.md`.
- **Stays live:** `FINDINGS-job75-20261005.md`, for its Part Four.
- **New and live, not to be acted on:** `NOTE-introduction-recognition-20261007.md`. `[A]`: *record it to
  be done later.* No session acts on it until he says so.

## What is owed

- **A coherence run on `BOOK2-20261011.md`.** `[C]`'s recommendation for next, `[A]`'s to decide.
- **The handoff needs a cut.** `HANDOFF-20261005b.md` still names the 09-23 master and register letter
  `c`. When it is cut, its open list gains, under the doctrine heading: **what the Introduction should
  say about recognition** — a small piece of writing with a clear home, waiting only for `[A]`'s word.
- **Open for doctrine:**
  - conscience for a person detached in the psychic realm (from `Job77`);
  - from `FINDINGS-job75` Part Four: whether a want is laid down when a thought ends; whether disliking
    disturbance is why a disturbance gets noticed; a rule followed by rote;
  - **the held sentence**, *What the person can bear is set by what previous thoughts have laid down,
    and most of all by what has already been buried near the same matter* — under the one-capacity
    ruling it splits, and `[A]` has not said where it goes (closures file, *Not in this file*);
  - **the Rising pass**: trained abiding acting on the feeling of fear, and raised tolerance, which
    doctrine holds for *Rising* and not for *What is actually being undone*;
  - for the burial or unease-loop material, not drafted: `Job70`'s points that later incidents set off
    the turning away sooner and widen what sets it off, and the predicted symptom that later
    threatening incidents are remembered patchily (`[A]`: *later threatening incidents would be less
    than usually easy to remember*);
  - **the unease material**, `NEW-MATERIAL-the-unease-loop-20260923b.md`, held by `[A]` for a sitting
    of its own. Not in the set.
- **For the next style guide letter**, `Job70`'s suggested caught instance: a phrase that parses
  correctly but costs a moment because ordinary English has another use for it (`[A]` could not parse
  *That is why enormous effort low down is no evidence against any of this*).
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261011.md`**, with the tracking check run on
motivation, since attraction and aversion were redefined this session.
