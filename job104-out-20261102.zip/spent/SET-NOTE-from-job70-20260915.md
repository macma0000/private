---
from: Job70 doctrine 09152026
to: the session receiving MANIFEST-job71-20260915.md
---

# SET NOTE — from `Job70 doctrine 09152026`

## Arrival

Incoming zip `job69-out-20260914.zip`, directory `job69set`. Verified **86 ok / 0 mismatched /
0 bad count / 0 missing / 0 not in the manifest** against `MANIFEST-job70-20260914.md`. Screen
fired twice, both benign — the record as CARRY DO NOT READ, and the handoff for quoting the
restriction string.

Record arrived **65,890 w, md5 `af243099`, fiftieth append, marker `Job69 drafting 20260914`,
parent 64,653** — agreeing with `SET-NOTE-from-job69-20260914.md`. Chain clean. A doctrine
session, so the record was read.

Master read: `BOOK2-20260914.md`, 36,336 w, md5 `1519cef6`. **No master was written.** A
doctrine session does not touch the manuscript, so both manuscripts travel byte-identical to
the copies that arrived.

`STYLE-GUIDE-20260908b.md` was read at §1.0, with the handoff and the set note, as `Job69` asked.

## What was done

**All three of `Job69`'s open items are discharged**, in the order `Job69` listed them.

`attention` — sorted into 2 ordinary-English sites, 22 that are older vocabulary for noticing or
for dwelling at the seeing end, and 19 that make a claim. `[A]` did not rule the word, so
`[C]`'s reading that none of the 19 survives translation is recorded as a reading and not as
doctrine.

**The economic register — ruled.** `cost` and `pay` are avoidable everywhere and go. **`ration`
is the only member of the family that stays**, at the three Five sites, because rationing a
psychic thing as though it were physical is the Five's own mistake. `arithmetic` goes.
Everything else was already out under `STYLE-GUIDE-20260908b.md` §3.

**The correlation item — ruled, and its framing dissolved.** `[A]` corrected `[C]` twice: the
item is about leans and not about moving to a new type, and how far a lean runs is not the same
quantity as strength of fixation. **A lean is an offset of the center of the fixation on the
cycle; health widens the range around the center; a person with a widened range lives toward its
forward part.** Ch 11's sentence about lean strengths being independent between realms is about
lean distance only and **stands unchanged**.

Beyond the three items, five more closures came out of `[A]`'s own questions: what governs the
use of lent motivation, the automatic check a cautious realm runs when paired with an
enthusiastic one, a fear directing the looking, health softening fixations into access to the
other orientations, and the return of the author's voice to about twenty sites in place of
hedging.

One hypothesis is held and marked as such: **stress stops a person doing the work of their own
phase, and what shows is the previous phase's material left unworked.**

`CLOSURES-SITED-job70-20260915.md` carries all of it — nine closures, nineteen rows, and the
twenty voice sites specified by chapter.

## Files

- **New `CLOSURES-SITED-job70-20260915.md`.** Fifth instance of the file kind `[A]` ruled
  2026-08-30, following `CLOSURES-SITED-job67-20260912.md`'s layout.
- **Record appended — FIFTY-FIRST APPEND, sighted.** Head is **67,438 w, md5 `2e273204`**,
  marker `2026-09-15 · Job70 doctrine 09152026`, parent 65,890 named in the block. First
  **388,343 bytes verified byte-identical** to the parent. **63 markers** where there were 62.
  Written in the canonical bold form so the sweep can read it.
- **No new master.** `BOOK2-20260914.md` and `rev2-0814t.md` are unchanged.
- **`VOCABULARY-INSTRUCTION-from-job67-20260912.md` still travels, still discharged.** It must
  NOT be run again. `Job69`'s note is the declaration.

## A file named in `Job69`'s close that was NOT in this set

`NOTE-sections-predating-the-attention-account-20260914.md` is named in the memory of `Job69`'s
close as cut and appended, and it is **not in `job69set`**. `[A]` raised its content in session
on 09-15 and the work was done from what he said, so nothing was lost — but this is the
selection-rule class the record warns about, and a later session should check the note against
closures 1 to 4 rather than assume agreement.

## OPEN — carried

**Whether the widened range is symmetric about the center.** `[C]` asked whether widening opens
the backward part as well as the forward part, or the forward part only. Never answered.
**Rows 9 and 10 of the closures file cannot be finished without it**, so a drafting session
should expect to stop there and ask.

**What the settling is when two fixations pull opposite ways at one crossing** — carried from
`CLOSURES-SITED-job67-20260912.md`, untouched.

## One thing about how this session went, for the next one

`[C]` was corrected four times for running two things together — reading all 43 `attention`
sites as current, extending the automatic check beyond the enthusiasm-and-caution pair, writing
*go looking* of a Six who looks constantly, and conflating lean distance with fixation strength.
**Each one came from reaching for a general account before checking which cases it covered.**
The repair each time was `[A]` naming the case it did not fit. **State the scope of a proposed
account before proposing it**, and name the types it is meant to cover.

## Next session

`[C]`'s recommendation: **drafting**, applying `CLOSURES-SITED-job70-20260915.md`. Nineteen
rows, and rows 9 and 10 will stop on the open range question. The voice work at twenty sites is
the largest single piece and needs `[A]` available, since a drafting session that cannot tell
whether a claim was watched or derived must leave the sentence alone and list it.

## Outgoing

`MANIFEST-job71-20260915.md`, label `Job71 20260915`, no job kind — the kind is `[A]`'s to
assert.
