For Job101, from Job99 doctrine, 2026-11-01, second relay of the day. It answers Job101's question "Is the pain of life not working a part of the pain of staying?". [A]'s words are verbatim, with the time of each message (Pacific, UTC-8). Everything else is Job99's report. Quoted book text is from BOOK2-20261029b.md, so the current master may already differ. Job99's earlier relays went to Job100 and are in its set: RELAY-from-job99-20261031.md, -20261031b.md, -20261031c.md, -20261031d.md and -20261101.md.

WHAT [A] SAID

[A], 11:55, after pasting Job101's finding: "i think they are one thing, but maybe broader than "the practical details of life not working". can you characterize the nature of what is painful? the practical threat is just in the physical realm - it's what i, a HB five, imagine. what would apply to everyone?"

Job99 described it as follows. What applies to everyone: things keep going wrong in the person's life, and the person cannot account for them, because the cause is in what the person does not see. The consequences stay, so the pain builds. The person can see that other people manage what the person cannot. What goes wrong depends on the realm the person is blind in. In the physical realm the world pushes back: work, money, health and the things a person depends on fail. In the psychic realm nothing outside pushes back: feelings will not settle, the same troubles with other people keep coming back, and people withdraw or leave. Because whatever a person keeps turning over grows, the trouble feeds on itself. The book's own list already spans both realms: "the job lost, the money gone, the person who left." Asked "Does that fit what you mean?", [A], 11:58: "yes. does the pushback affect people with no cautious fixation the same way?"

Job99 answered, and this answer is background, not an instruction. The pushback reaches everyone the same way. What differs is how it is met. A cautious person meets it ahead of time, as a threat. An enthusiastic person meets it when it arrives, as a setback and a disappointment. A detached person meets it as a disturbance of their peace, which is looked at near the caution end, or turned away from near the enthusiasm end.

[A], 11:59: "what instructions go to job101?" Job99 recommended "the pain of staying" as the one name. [A], 12:02: "i prefer the pain of life not working. it says what a person can easily recognize. does that work?" Job99 said yes, with the two adjustments in b and c below. Asked "Shall I write this up for the coherence session?", [A], 12:03: "yes".

RULED

1. The pain of staying and the pain of life not working are one thing, and its one name is "the pain of life not working". This supersedes his 10-30 answer (17:08) that the pain of life not working is more specific. It also supersedes the closures' and the register's entries built on that answer.

2. The pain of life not working is broader than "the practical details of life". It is a person's life, in either realm, not working the way other people's lives do, as described above.

WHAT FOLLOWS FOR THE BOOK

a. Every "the pain of staying", including "the pain of staying as the person is", becomes "the pain of life not working". The exception is in b. The word "staying" stays wherever it names the choice and not the pain, as in "staying as they are, or facing what they avoid" and "until staying is unbearable".

b. The unease loop: there the pain on the staying side is the unease itself, about one matter, not a life not working. Shown to [A] and covered by his 12:03 yes:
"What motivates a person to take a way out is a comparison of two pains: [the unease], and the pain of doing what the way out requires. When [the unease] becomes the worse pain, the person takes the way out."
Going out: "the pain of staying as the person is" and "staying".

c. The name is explained where it first appears. After b, that is the first comparison, in Why this does not take everyone to the bottom. Job99's proposed paragraph follows. It has not been shown to [A], so show it to him. It would go straight after the paragraph beginning "Consequences do.", so that the name is explained before the comparison uses it:
"[The pain that consequences bring is called the pain of life not working. A person's life does not work the way other people's lives do. Things keep going wrong, in ways the person cannot account for, because the cause is in what the person does not see. The consequences stay, so the pain builds. In the physical realm, the world pushes back: work, money, health and the things a person depends on fail. In the psychic realm, nothing outside pushes back: feelings will not settle, the same troubles with other people come back, and people withdraw or leave.]"

d. Rising: the sentences [A] approved on 10-31 (15:58) now restate the name instead of introducing it. Job99's proposal, also not yet shown to him:
"[Blocked aversions can leave a person less able to handle life than others are. The person's life does not work the way other people's lives do, and the pain of life not working rises. The person can see that others manage. The person might understand that something is causing the difference, and that the cause is the person's own fears.]"
Going out, from the 10-31 version: "For the person, the practical details of life do not work the way they work for others.", "Being less able to handle life is painful." and "That pain is called the pain of life not working."

e. With one name, Rising's "the same comparison" is true as it stands. Both comparisons weigh the pain of life not working against the imagined pain associated with facing buried material.

f. His cause-and-effect point at the first comparison (closures C1) is worded with the pain of life not working again, as his own 17:26 words on 10-30 have it: "failure causes the pain that eventually forces facing the fear". Job99's correction of 10-31 (RELAY-from-job99-20261031b.md, item 3), which said to use the pain of staying there, is withdrawn. So is that relay's instruction to change the register's section 5a entry.

g. For the next session that cuts the register: the pain of life not working is the one name, with the description above, and the pain of staying goes. A wordcheck pattern for "pain of staying" would catch any that are left.
