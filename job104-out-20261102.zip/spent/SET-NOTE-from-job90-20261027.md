# SET NOTE — from `Job90 drafting 20261026`

This note goes to the session that receives `job90-out-20261027.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job91-20261027`.

## Arrival

`job89-out-20261026.zip` verified against `MANIFEST-job90-20261026.md`: **60 ok, 0 mismatched, 0 bad count, 0 missing,
171 not in the manifest**, all 171 in `spent/` (104) and `superseded/` (67). `Job89`'s note said it moved seven relays to
`spent/`; there are eight files (the 10-19, 10-23 and 10-26 relays and `b` to `f`), and nothing is missing. The record's
last marker matched `Job89`'s note: ninety-first append, 100,521 w. `[A]` named the session `job90 drafting 20261026`; the
label's counter agreed. The session ran from 10-26 into 10-27.

## What was done

A drafting session on **`FINDINGS-job89-20261026.md`**, items 1 and 3 to 7, with relays `g` to `j`. **Master out:
`BOOK2-20261027.md`**, 44,029 w. Every change was shown to `[A]` in place before it was applied. The rows, each with his
words, are in **`CHANGES-job90-20261027.md`**.

- **The two kinds of blocking** carried to every site `Job89` listed, and two more (*burying a pain*). *Blocking is not a
  decision* is now *Burial is not a decision*. A buried fear is *turned away from in panic and barely noticed* (`[A]`'s
  sentence).
- **Burial all at once**, and *what is blindly blocked can keep growing*.
- ***What a level is made of*** rewritten: Levels 1 to 6 mostly discomfort blocking; blindness only from burial, earlier
  blindness at every level.
- **What a person can bear** no longer the only thing that decides; each site names both kinds.
- **Lasting unease has three sources**, said of **aversions** (`Job81`'s relay `n`): ignored aversions, blocked aversions,
  and **being less able to handle life than others are**, `[A]`'s one name for what the book had called *unable to handle
  life*.
- ***What is buried then stays buried until it is faced, like any buried fear.***
- **Four `Job81` relays arrived in session**, each saved byte for byte: `RELAY-from-job81-20261026k.md` to `-20261026n.md`.
- **`WORD-RULINGS-book2-20261027.md`, letter `o`**, and **`STYLE-GUIDE-20261027.md`, letter `j`.** `[A]`, shown the summary:
  *yes*.
- **Checks:** referring-word count on every new sentence (four repaired with `[A]`); `wordcheck.py` against letter `o`, every
  new hit read, all allowed. The two new patterns fire on the parent and not on the new master.

**For any session that shows `[A]` a change: bold does not show on his screen.** Mark new words with square brackets and
list the words going out underneath.

## The record

One append, blind: the **ninety-second**, `[A]`'s words verbatim with what each answered; the relays are named, not
repeated. **Parent 100,521 w, head 101,171 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `FINDINGS-job89-20261026.md`, `SET-NOTE-from-job89-20261026.md`.
- To `superseded/`: `BOOK2-20261026.md`, `MANIFEST-job90-20261026.md`, and as `SUPERSEDED__live__`
  `WORD-RULINGS-book2-20261026.md` (letter `n`) and `STYLE-GUIDE-20261026.md` (letter `i`).
- **Kept live:** all eight relays `g` to `n`, for the coherence run to check the changes file against;
  `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be acted on until
  `[A]` says so.

## What is owed

- **A coherence run on `BOOK2-20261027.md`**, reading `CHANGES-job90-20261027.md`. Look first at the two items under *For
  the coherence run* there: Ch 4's *What was never noticed cannot be got at afterwards*, and whether *aversion* in the
  *Blocked* entry and the unease loop sits well beside *fear* everywhere else. The claim inventory needs a 10-27 block.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold, reserved
  for a session of its own. It is now a source of lasting unease as well as of stress.
- **The writer 2 pass**, still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261027.md`.**
