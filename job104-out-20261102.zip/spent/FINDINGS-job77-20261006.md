# FINDINGS — `Job77 coherence 20261006`

Cut 2026-10-06. The session opened on `job76-out-20261006.zip` and ran against
**`BOOK2-20261005.md`** (39,839 w, md5 `d50bf9bb`), cut by `Job76 drafting 20261005`. During the
session `[A]` carried questions to `Job70 doctrine 09152026` and brought back its answers.

**This is the one file a drafting session works from for this session's rulings.** It does not
replace `FINDINGS-job75-20261005.md`, which stays live only for its Part Four. Where an item of
that Part Four is closed here, this file says so.

**Every site was located by content in `BOOK2-20261005.md`, which this session did not edit.** Each
blockquote below is a sentence of that master, checked with `quotecheck.py quotes`. `[A]`'s words
are given in italics and are never put in blockquotes. Neither are `Job70`'s words or `[C]`'s
proposed sentences.

**How the rows are marked.**

- **RULED** — `[A]` said it, and his words are given. Where `[A]` ruled by agreeing to a `Job70`
  answer, his words of agreement are given and the substance is `Job70`'s answer as he accepted it.
- **`[C]` DECISION** — a fault this session recorded without asking, because a ruling already
  covers it. The ruling is named.
- **`[C]` REPAIR SENSE** — how the repair might go. A drafting session may use it or write its own,
  and must show `[A]` the sentences around the change, before and after.
- **`Job70`'S** — `Job70`'s own addition, travelling with a ruling. `[A]` did not rule on it
  separately. Put it to him in one line before acting on it.
- **NOT RULED** — a `[C]` reading. Do not act on it without asking `[A]`.

**A note on `Job70`.** On this day `Job70` twice stated something broader than the manuscript
supports. Its *`looked at` is the wrong word throughout* was a generalization from two sites, and
it withdrew it. Its first statement of the burial ruling said *nothing is blocked the first time*,
and `[A]` called that wrong. **Treat any sweeping statement from `Job70` as a reading until the
manuscript has been checked.**

---

## PART ONE — THE RULINGS, EACH IN ITS OWN ROW

### 1. Trained detachment counters engagement, not a detached fixation — RULED

`[C]` asked whether the summit section's closing expectation holds for a person detached in the
realm they train. `[A]`: *you're right. detachment counters engagement, not a detached fixation.*

**Site — *The summit, and what counterfeits it*, last paragraph:**

> It would be reasonable to expect that training to abide in the detached phase weakens a fixation. A fixation is attention concentrated at one phase, and attention given to abiding in the detached phase is not concentrated there.

Two faults.

- **Scope.** The expectation covers a person whose fixation in the trained realm is enthusiastic
  or cautious. Those two fixations are engagement. It does not cover a detached fixation.
- **The reason is wrong.** The second sentence makes attention the cause of the weakening. `[A]`
  ruled the same day that attention in a phase is a result of the fixation and not a cause (row 2).
  The mechanism is his: *detachment counters engagement*.

`[C]` REPAIR SENSE: keep *It would be reasonable to expect*, which is his form for a guess
(`CHANGES-job76`, ruling 10). Name the two fixations it covers. Give his reason in plain words,
for example: abiding in the detached phase works against the engagement that an enthusiastic or a
cautious fixation is.

**Second site, in the same section, `[C]` DECISION:**

> No orientation is trained, and the person's fixation is unchanged.

If training is expected to weaken an enthusiastic or cautious fixation over time, *the person's
fixation is unchanged* contradicts the closing paragraph. What the section's examples show is that
the type is unchanged. Each example already ends *Nothing about the person's type has changed*.
`[C]` REPAIR SENSE: *No orientation is trained, and the person's type does not change.* Show `[A]`.

### 2. Attention in a phase is a result of the fixation; a fixation is the hardened orientation — RULED

`[A]`, on the reason `[C]` gave in row 1: *be careful not to confuse detached fixation with detached
phase. attention in a phase is a result of fixation, not a cause.* Then: *it was a fault in your
reasoning. you seemed to be using "A detached person gives the detached phase the most attention."
to conclude the attention strengthened the fixation.* So **the book's sentence *A detached person
gives the detached phase the most attention* stands**. The fault was `[C]`'s inference, not the book.

On the definition at *Where a fixation acts*: `[A]` *it's not identity.* Asked which the book
should carry, the hardened orientation or the concentration of attention, `[A]` accepted `Job70`'s
answer: *job70 agrees with you. i accept it.* **A fixation is the hardened orientation, a habit,
held in a realm. The concentrated attention is what the fixation produces.** `Job70`'s five
reasons: the types are pairs of orientations; the result-not-cause ruling would say nothing
otherwise; `[A]`'s 08-25 ruling that the hardening is the accumulation of a lifetime of the same
move; a fixation is held in a realm while attention is concentrated at a phase; and the Part 3
opening already defines it.

**Site — *Where a fixation acts*:**

> The orientation a person holds in a realm, once hardened into habit, is called a fixation. A fixation is attention concentrated at one phase. Every thought passes through all three phases, so a fixation acts in every thought.

**The replacement for the middle sentence was worked out with `[A]` in session.** `Job70` endorsed
it, and `[A]` accepted that answer. It is two sentences, keeping his order of attention first:
*In each realm, a person's attention is usually concentrated at one phase. The phase shows which
orientation is the person's fixation in that realm.* Neither has a referring word. **Do not write
*fixation in that phase* or *fixation in a phase*.** `[A]` 09-23: *fixations and phases are
separate things.*

**The same identity is used once more in the book**, as the reason in row 1's summit paragraph,
which row 1 replaces. **It is also in `ARC-ACCOUNT-from-job75-20261005.md` §7**, which reads *A
fixation is attention concentrated at one phase (`[A]` 09-12)*. That file was not edited. A session
reading it takes this row over §7's first line.

The two sketches' *attention is concentrated at the enthusiastic phase* / *the cautious phase* read
as results and stand.

### 3. The turning away is automatic, not a reflex — RULED

`[A]` accepted `Job70`'s answer: *go with doctrine's answer.* The test is what produced the act.
A reflex is produced by no thought: *a hand coming off a hot pan almost always happens while some
thought is in progress. What makes it a reflex is not that nothing was going on. It is that no
thought produced it.* The turning away answers a fear that a thought raised, so it is
**automatic**. That is already the book's word for it in the orientations chapter and in *The four
fates*.

**`Job70`'s two sentences go where the reflex is defined** (`[A]` accepted them with the answer),
in *Action without a full thought* or in the paragraph of *The range of detachment* that begins
*A reflex is different from both*: *A reflex and an automatic turning away are both unchosen, and
they differ in what brings them on. A reflex answers nothing — no thought raised anything, and the
body moves. A turning away answers a fear that a thought raised.* Say it once, at one of the two.

**Sites that call the turning away a reflex, to become *automatic*:**

> Turning away from a fear that cannot be borne is itself a reflex.

> The skill at the enthusiasm end is the harder of the two to use, because turning away is a reflex and the relief it brings is real every time. But a habit can reach a reflex.

> The failure to notice is reflexive rather than chosen, and it was learned rather than designed.

> Detachment can be taken with something in view, or taken as a reflex with nothing in view.

> A feeling arises, and a reflex follows that uses the feeling the way the infant's cry was once used on a parent.

**One site takes a different repair**, which `Job70` asked `[C]` to check and `[C]` confirms. In
*Rising*:

> An adult taking up a skill for handling fear has to displace a reflex that is already running. Displacing a running reflex is slower, and practice is what does it, not conviction.

What is displaced is **the habit of turning away**, not one act. Write that, not *automatic*.

`[C]` REPAIR SENSE for *But a habit can reach a reflex*: the claim is that a skill laid down as a
habit can act as fast as the automatic turning away does. Say that.

**Stays:** the three sentences that define the reflex and set panic and the grab apart from it.

### 4. Burying develops over a history; what the deposit is — RULED

**The ruling, in stages.**

- `[A]` said *yes* to `Job70`'s statement: burying develops over repeated incidents; what an
  incident lays down later produces the turning away before anything has been noticed; so the
  turning away becomes automatic over a history.
- `[A]`, through `Job70`, on what is laid down: *what is learned, the deposits, is that certain
  thoughts, triggered by certain incidents, are painful, along with an automatic decision to avert
  noticing those thoughts.*
- `Job70`'s first statement had said nothing is blocked the first time. `[A]`: *"nothing is
  blocked the first time" is wrong. the new point is the automatic decision not to notice certain
  painful thoughts.* `Job70`'s correction stands: **an incident is not a fear.** An incident raises
  several fears across several thoughts. Some are noticed and turned away from, which is ignoring.
  Some are never noticed, which is blocking. Each still meets one fate.
- *Decision* in `[A]`'s sentence is replaced in the book by *automatic turning away from noticing*
  (row 5).

**In the book's words:** what is learned is that certain thoughts are painful, together with an
automatic turning away from noticing them. Later incidents of the same kind set it off.

**`Job70`'S, travelling with it:**

- Later incidents of the same kind set off the turning away earlier.
- The range of thoughts that set it off widens, because each incident adds to what has been learned
  as painful.
- **The blindness loop gets a beginning**: a fear bad enough to leave a deposit that later produces
  the turning away.
- **Why the buried material cannot be found by recalling the incident**: what was learned is about
  thoughts, not about the event. A person could remember the incident perfectly and never raise the
  thoughts it is attached to.
- **Siting**: the account belongs beside the mental deposits, in *What previous thoughts have laid
  down*, as a worked instance of what a thought lays down. It does not go inside the *Blocked*
  entry of *The four fates*.

**Sites to rebuild, not reword** (`Job70` named the first two, `[C]` confirms them, and `[C]` found
the third):

- *The range of detachment*, the job example. It has a person notice part of a fear and bury the
  rest inside one thought:

> When the fear of the fear wins, the person is unable to bear knowing about the job.

> A deeply caught person turns away from the fear quickly. A less caught person can look at more of the fear before turning away.

  Under the ruling, what varies is how far the turning away has developed over the person's history.
  It is not how much of one fear is noticed inside one thought.

- *The range of detachment*, the lean paragraph:

> A person leaning toward caution gives the caution end more attention, so more of the fear is looked at and less of the fear is left over.

  `[C]` REPAIR SENSE: the lean changes how likely a fear is to be noticed and met at the caution end.
  Do not divide one fear into a part noticed and a part buried. The paragraph before it, *The lean
  changes how much of a fear is not yet disposed of when the fear reaches the enthusiasm end*, has
  the same fault.

- *Blocking is not a decision*, the paragraph on learning:

> The move had to be learned at a time when the anxiety still *was* felt, at least half-consciously, at a stage before there were words for any of it. By the time there were words it was already running by itself. Each new fear gets its own blocking laid down, and the later blockings are the ordinary case of a choice repeated until it sinks beneath understanding — the choice here being the choice not to look.

  The first two sentences fit the ruling. The third calls the later blockings *a choice repeated*,
  and *the choice not to look*, while the same section's last paragraph says no decision is made.
  Under rows 4 and 5 what repeats is the automatic turning away from noticing certain thoughts,
  learned at each incident.

**Holding, checked at `Job70`'s request:** the climb and the brake. *A buried fear comes back into
view, the person faces the fear, and the fear has been released*, the climb being rare, and the
brake's *pain of facing what has been buried* all read correctly when what was buried is painful
thoughts together with an automatic turning away from noticing them.

**The *Blocked* entry's sentence stands**: *Ignoring and blocking begin as the same turning away.
At first the only difference between them is whether the person can bear the feeling of the fear.*
The noticed fears of an incident are ignored, and the unnoticed ones are blocked.

### 5. `decision` is the conscious kind only — RULED

`[A]` accepted `Job70`'s answer: *take job70's answer.* **`decision` keeps its conscious sense.** The
automatic case is named **an automatic turning away from noticing**. `Job70`'s reason: the
sentences denying a decision are the book's proof that blocking cannot be deciding, and the proof
runs on deciding requiring a prior noticing. Redefining the word would dissolve the argument.

**So these all stand:** the orientations chapter's *To decide not to look at something, a person
would first have to notice it*; the heading *Blocking is not a decision*; *This is why a decision
not to look is not what happens*; *The person does not decide this*; *Nothing about it is decided*;
*None of that is decided*. **Do not write *automatic decision* anywhere in the book.** A word ruling,
so it is in register letter `e`.

### 6. Recognition works one kind at a time; general understanding retires nothing — RULED

`[A]`: *i agree with what job70 said*, and he added: *i agree. but it is possible to understand that
happens in one's self.* `Job70`'s answer, as accepted: a climb requires facing a particular painful
thought, so recognition is of one kind at a time. **Three things are kept apart:**

- **the capacity to turn away** — not learned, so it is not what is recognized;
- **the general understanding that one does this** — real, and it retires nothing. It lets a person
  take seriously that something is there when nothing seems to be, such as a reaction that does not
  fit or a subject they never arrive at;
- **the recognition of one kind** — this is what a climb runs on.

`Job70`'S: say all three, briefly. Say plainly that the general understanding does not do the
particular recognition's work, or a reader will take it for the way out.

**Site — *What is actually being undone*:**

> **Better is to recognize the burying itself.** Not the individual fear but the arrangement that disposes of fears without consulting anyone, which is a single thing running under all of them. That one generalizes where the other does not, and it is the only object in this account whose recognition would reach material not yet laid down.

That paragraph offers a single thing whose recognition generalizes. Under the ruling there is none.
The paragraph before it, *What undoes it is conscious recognition of the buried fears … That works,
and it is local*, stands.

### 7. The act is *turning away from noticing* — RULED

`[A]`: *i agree with job70*: *i think noticing is what is avoided.* **One form, wherever the act is
named: *turning away from noticing*.** The register's 10-05 form *turning away from looking*, ruled
in `Job76`, is superseded. `look at` stays as ordinary English for attending to something already
noticed (*A person can notice something and then decline to look at it any further* is correct).
**Sort by what the sentence is about, not by the word:** where a sentence is about the second stage,
the word is `notice`.

**Sites naming the act:**

> The person turns away from looking at the fear, and the turning away is what blocks the fear.

> Leaning forward toward enthusiasm, a person turns away from looking, and what goes unattended was taken in and never noticed at all.

> What blocks the fear is turning away from looking at it, so nothing about the fear ever has to be faced — a person turns away from something before knowing what it was.

**Not the same act, and left as it is:** *A person turns away even from recognizing what happened*
is about the conscious way back.

**Sites where `look at` stands for noticing:** the lean paragraph in row 4, *A process reaches the
detached phase at the caution end, where fears are still looked at*, and the orientations chapter's
*the fear comes to the caution end first, where fears are still looked at* and *the more of the
fear is looked at*. A drafting session greps `look` across Part 1 and Part 3 and sorts each use.

### 8. `disturbance`: a fear is not itself the disturbance — RULED

The sort `[A]` deferred to this run on 10-05. `[C]` asked whether, where the book makes a fear itself
the disturbance, the disturbance should be *the discomfort a fear leaves behind*. `[A]`: *yes.
everywhere.*

**Sites:**

> The two faces differ in what happens when a disturbance arrives, such as a fear.

> But the fear arriving meets the desire for comfort, and a fear is exactly the disturbance a detached person stepped back to be free of.

**Stays:** the verb (*while nothing disturbs a Nine*), and a disturbance as a trouble in the world
(*a practical difficulty reduced in the physical realm*). `[C]` read all 33 uses. The other uses that
mention a fear are the job example, which row 4 rebuilds, and the Nine's sketch, which has *want
the fear to go away* with no `disturbance`. *Desire for comfort* in the second site falls under
row 9.

### 9. What a detached person wants is peace; the enthusiasm end's want was inverted — RULED

`[C]` asked whether the Nine's sketch should say *peace* for *comfort*. `[A]`: *i agree with job70's
response.* `Job70`'s answer, as accepted: **`peace`.** What belongs to detachment at any lean is
wanting not to be disturbed, and comfort is the enthusiasm end's want. Then, on `[A]`'s addition:
**the enthusiasm end does not want pleasure for its own sake.** It is getting away from the discomfort
a fear leaves, and a pleasure serves, which is distraction going toward something (`[A]` 09-23: *Z+
changing the subject/distraction/ignoring is a want*). **Both ends serve the dislike of
disturbance, the caution end by fixing and the enthusiasm end by getting away.**

**Site — the Nine's sketch:**

> What a Nine wants is comfort — to be left undisturbed. Wanting comfort makes a Nine forget two things a cautious person knows.

**Sites — *The range of detachment*:**

> Near the enthusiasm end what a person wants is pleasure itself. The want is for ease and comfort, rather than for one particular pleasure the person has in view.

> What the person wants as a standing matter is still ease and comfort.

`Job70`'s sense of the repair: near the enthusiasm end what a person reaches for is a pleasure that
takes them away from what is uncomfortable, and any pleasure will serve, which is why nothing
particular is in view.

**Also governed:** the cycle chapter's *the fear arriving meets the desire for comfort*, and the
range passage's *A detached person leaning toward enthusiasm wants comfort*. Those two are about a
person at the enthusiasm end and the enthusiasm-end passage. `[C]` reading: they may stand where the
person is at the enthusiasm end. The cycle chapter's sentence is about a detached person in general,
so it takes *peace*. **NOT RULED as to the cycle chapter's sentence.** Show `[A]`.

---

## PART TWO — FAULTS RECORDED WITHOUT ASKING (`[C]` DECISIONS)

**A. The caution end's want, under rows 8 and 9.** `Job70` asked `[C]` to check whether the
caution-end sentence was written as a parallel to the pleasure sentence and needed the same
correction. It is parallel in form, and it is not inverted: it already names getting rid of
something. Under row 8 it names the discomfort a fear leaves behind instead of *fear itself* or
*fear as such*.

> Near the caution end what a person wants is to be rid of fear itself. The want is for fear as such to be gone, rather than for one particular fear to be settled.

> What the person wants as a standing matter is still to be rid of fear as such.

**This closes the item *each end of detachment's own want* in `FINDINGS-job75-20261005.md` Part
Four.**

**B. *Acts* used for handling a fear in the detached phase.** Under the 09-16 and 09-23 rulings on
where action comes, an action comes at the enthusiastic phase or the cautious phase, placed by motive.
In *Which fixation handles a fear*, *acts* means *handles the fear*, and with a person as subject it
reads as outward action in the detached phase:

> An enthusiastic or cautious person acts before the detached phase.

> Everybody acts in the detached phase too, and what differs is how much attention a person gives the detached phase.

`[C]` REPAIR SENSE: the section's own verb, *handles a fear*. *A fixation acts in every thought* in
*Where a fixation acts* has a fixation as subject and stands.

**C. *The feeling of the fear lasts*, under the register's entry on what ignoring leaves** (*Write
ignoring leaves tension behind, never an ignored fear keeps its feeling*):

> The feeling of the fear lasts a while after the fear has been ignored.

`[C]` REPAIR SENSE: ignoring leaves a bodily tension, which lasts a while. *Once the feeling has
subsided, the fear is forgotten* becomes *once the tension has subsided*.

**D. *Two of the four leave something behind*, carried from `Job76`.** *The four fates* says
*What remains is a regret*, and *Where a fear meets its fate* says *a regret is left behind*, so
given up on leaves something too.

> Two of the four leave something behind.

`[C]` REPAIR SENSE: name the two fates and what they lay down, instead of counting: *Ignoring and
blocking each lay something down.* This avoids a count the regret breaks.

**E. A fear kept over time, under *a fear lasts one thought* (09-16, 09-23) and *a buried fear is
mental deposits* (10-05).** Each reads as one fear persisting between thoughts.

> Either way the fear is still to be met, and a fear still to be met is what the chain runs on.

> A fear with no consequences attached can be left indefinitely. As consequences gather it presses harder, and at some point it can no longer be left — it has to be weighed or turned away from, and which of those happens depends on how much sight is left by then.

> I suspect that a detached person under stress stops disposing of what arrives. The person is left holding fears that arrived, and a person holding fears that cannot be disposed of worries.

> A fear that goes past the caution end without being noticed at all is turned away from instead, and it accumulates: buried anxiety continues to cause stress even though the fear behind it was never noticed.

`[C]` REPAIR SENSE: the problem still stands, so the fear is raised again each time the problem is
met. As consequences gather, each raising is stronger. What accumulates is what the burials laid
down. The first site was carried from `Job76`. At the urgency site, keep the slope of urgency, and
attach it to the problem, not to one fear.

**F. The second way down keeps the fear *in view and keeps its pull*:**

> Nothing is turned away from and nothing is hidden — the fear is in view and keeps its pull, and what stops is the weighing.

`[C]` REPAIR SENSE: the fear is noticed each time it is raised, and its pull is felt each time.
Minor, under the same ruling as E.

---

## PART THREE — CHECKED AND HOLDING

- **The climb and the brake against the burial history** (row 4). Hold.
- ***Only blocking leaves a person seeing less than before*** (*Where a fear meets its fate*), against
  ignoring laying down the habit and the knowledge. Holds. Ignoring by habit still notices, and the
  fear is let alone after being noticed.
- **`wordcheck.py` against register letter `d`: 74 hits**, the same count `Job76` read, and each was
  re-read here. All 31 `settled` hits are ordinary uses or the two fates that end a fear. The five
  `aversion` hits are Ch 14's two class definitions and the Part 3 opening's arhat sentence.
- **The Part 3 opening's new arhat paragraph** reads correctly under the register.
- **Ch 14's coffee example** carries `[A]`'s 10-05 ruling on heavy examining correctly.

**The tracking check this session ran was on one object: the turning away**, from the fear an
incident raises, through what is laid down, to the climb that retires it. It found rows 3 to 7. It was
not run on the fear's fate or on motivation again.

---

## PART FOUR — OPEN, FOR DOCTRINE

- **Conscience for a person detached in the psychic realm.** The summit section gives conscience for a
  person cautious in the psychic realm and a person enthusiastic in it, and says nothing of the third:

> A person enthusiastic in the psychic realm examines little of what their wants would do to others, so whatever conscience the person has was learned as a rule.

  `[C]` noticed the gap and did not put it to `[A]`. NOT RULED.
- **Carried from `FINDINGS-job75-20261005.md` Part Four, still open:** whether a want is laid down
  when a thought ends; whether disliking disturbance is why a disturbance gets noticed (row 9 bears
  on it, since both ends now serve that dislike); a rule followed by rote.
- **Closed here:** each end of detachment's own want (Part Two A, under rows 8 and 9).
- **The unease material**, a job of its own. Not in the set.

---

## WHAT THE REGISTER GAINS

Register letter `e`, `WORD-RULINGS-book2-20261006.md`, carries rows 2, 3, 5, 7, 8 and 9 as entries,
with `[A]`'s words. Row 3 and row 7 each add a `wordcheck.py` pattern.
