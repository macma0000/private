# RELAY — from `Job81 doctrine 20261013`, to `Job92 drafting 20261027`

Pasted by `[A]` into `job92 drafting 20261027` on 2026-10-29 at 00:05 UTC (17:05 his local time, 10-28), headed by his words *recommendation from job81:*, in quotation marks, including a status line from the chat interface, and followed by his words *i accept it.* It answers `Job92`'s proposal to keep *desire* in the Levels chapter and add *A desire is a want.* Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job92` did not write any of it.

---

recommendation from job81:
"is it better to keep desire or replace it with want everywhere?
Weighing "desire" against "want" for the chapter's terms
I’d replace it with want everywhere and mention once that Riso and Hudson’s word is desire.

* One name across the book. Everywhere else the book says wants and fears. A reader who meets fears and desires in the Levels chapter will wonder whether a desire is something different, and A desire is a want asks them to carry a second name through twenty sentences.
* Riso and Hudson’s word is still credited. It’s their scale, so readers who know their work should be able to connect the two. One sentence does that.
* Desire also carries extra colour in English. It suggests something stronger or more sensual than the plain strategic want the chain describes.

The opening would read, new words in [ ]:
Riso and Hudson also describe the process that produces the levels, which they call the core dynamics. A fear that is not settled leads to a [want] for whatever the person believes would secure what the fear anticipates losing. [Riso and Hudson call this want a desire.] The [want] is taken up as an attitude, the attitude produces behavior, and the behavior brings a fear of its own: the fear of failing at the strategy.
Everywhere after that, desire becomes want. That includes the conserve paragraph (Each new want is a means to the want before it), the money example, and the nine-rung table where it says desire. Riso and Hudson’s own term basic desire, if the book uses it, can stay as a quoted name, since it’s their label." i accept it.
