# NOTE for `job74-drafting-20260919`, from `Job70 doctrine 09152026`

Cut 2026-09-23, mid-session, because `Job74` is drafting the arc account into Ch 14 right now and
two things in that account changed today. **This note carries only what is cheaper to tell you now
than to repair later. It is not the full closures file**, which is
`CLOSURES-SITED-job70-20260923b.md` and is held for the coherence run after you close.

**`Job70` has not seen the manuscript in any sitting since 09-15.** These items are sited against
`ARC-ACCOUNT-from-job72-20260916.md`, not against what you have written. Where your drafting has
moved on, yours is what exists and the coherence run reconciles.

---

## 1. The angry remark moves from the ending to the cautious phase

`ARC-ACCOUNT-from-job72-20260916.md` §6 says of the truncated cycle: *the examining is cut short,
and the action happens at the ending.* **That placement is superseded.**

RULED 2026-09-16 by `[A]`: **an action is placed by the motive behind it.** An action released by
going toward something comes at the enthusiastic phase. An action released by fending something off
comes at the cautious phase. The same outward act can be either — `[A]`: *there is happy aggression
and angry aggression.*

So the angry remark comes at the **cautious phase**, where the examining is cut short by the remark
being released instead. `[A]` proposed the placement himself: *would that be the end of a B cycle
since it's motivated by aversion?*

**If you have drafted the truncated cycle with the action at the ending, that sentence needs
changing. If you have not reached it, write it this way.**

## 2. The stress hypothesis is restated, and loses one of its hedges

The old wording said stress stops a person doing the work of their own phase and **the previous
phase's material** shows unworked. That does not fit the cautious case, because the cautious phase
raises its own fear by examining.

RULED 2026-09-23 by `[A]`:

> Stress cuts short the work of a person's own phase, and the person acts on what is in hand
> unworked.

A cautious person acts on a fear that was raised but not weighed. An enthusiastic person stops
short of acting, so nothing arises. A detached person stops taking in and disposing, and is left
holding what arrived.

**The *I suspect* marking comes OFF the cautious case**, which is now a plain consequence of the
truncated cycle `[A]` ruled on 09-16. **It stays on the enthusiastic case and the detached case.**

RULED the same day, and it is what forced the restatement — **panic acts on a fear, not on a
want.** `[A]`: *on fear.*

## 3. `aversion` is now reserved to the cautious phase

RULED 2026-09-23 by `[A]`: *i question my use of the word aversion - i think it should be reserved
to cautious phase.* Fear and disappointment are the two aversions, and both are raised in the
cautious phase by examining and meet a fate at the ending.

**What a detached person has is a standing dislike of disturbance, and it is never called an
aversion.** `[A]`: *detached always wants to avoid disturbance whether or not the disturbance is
the same or different.* It is a feature of the orientation, not something raised in a cycle.

**This is in the note rather than held back because you may be writing about a detached realm
now.** Every existing use of `aversion` has to be sorted later, and the coherence run will run that
census. **What this note asks is only that you add no new ones** — where you are about to write
`aversion` of a detached realm, write the standing dislike of disturbance instead.

`[A]` accepted that name and called it *a little clumsy*. **Do not substitute a better one
silently.** A proposal may go to him.

---

## What is NOT in this note, deliberately

The buddha ruling, where a detached person's action comes, the tie between the lean and the
standing dislike, and the siting rows for Ch 4 and Part 3. **None of those touches what you are
drafting**, and all of them are in `CLOSURES-SITED-job70-20260923b.md` for the coherence run.
