# RELAY — from `Job81 doctrine 20261013`, to `Job92 drafting 20261027`

Pasted by `[A]` into `job92 drafting 20261027` on 2026-10-28 at 15:53 UTC, with no words of his own around it (his words are inside it). It came while `Job92`'s change to *The two faces of detachment* (the cycle chapter) was waiting for his answer. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job92` did not write any of it.

---

For Job92, from Job81 doctrine, 2026-10-28. On where burial happens in the detached phase. [A]: does burial happen in the Z+ phase or Z-? Then: i know that i ruled. what makes sense? z- deals with fear and z+ with attraction. Job81 answered that both ends take part: the panic happens at the caution end, where the fear arrives in view, and the burial is completed at the enthusiasm end, where the want to be rid of the fear has carried the person and the fear is no longer noticed. Asked whether that makes sense, [A]: yes. This refines the Job61 ruling that burying belongs to Z+ without withdrawing it.
Proposed for the drafting session to show [A], where the book places burial at the enthusiasm end:

* A burial crosses the detached phase. At the caution end, the fear is still in view, and that is where it is found to be more than the person can bear. Panic raises a want to be rid of the fear, and the want carries the person toward the enthusiasm end. There the turning away is completed, and the fear is no longer noticed. The person has turned away from the fear and toward what they are drawn to.

Discomfort blocking runs the same course more mildly, over repeated crossings. Where the book describes it, the same two ends can be named if it helps the reader.
