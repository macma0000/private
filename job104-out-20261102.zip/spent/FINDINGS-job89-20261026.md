# FINDINGS — `Job89 coherence 20261026`

Coherence run on `BOOK2-20261026.md` (43,514 w), reading `CHANGES-job88-20261026.md` and the seven
`RELAY-from-job81-*` files `Job88` applied. `[A]`'s words are verbatim. Four updates from `Job81 doctrine
20261013` arrived in session, each saved byte for byte: `RELAY-from-job81-20261026g.md` to `-20261026j.md`.
They travel live, because each carries wording for the drafting session to show `[A]`.

**For the drafting session.** Every item below is ruled, with `[A]`'s words. Where a relay proposes
wording, show it to `[A]` in place before applying it. Grep each idea by its words, not only at the
sites listed. One thread runs through items 1 and 3 to 7: the book was written when blocking meant
burial, and the two kinds of blocking now have to be carried everywhere the book speaks of blocking.

**Tracking check.** Run on **a blocked fear**: whether it is noticed, whether it can be borne, what
decides the blocking, what it lays down, whether it makes a person blind, what unease it leaves, and
how it ends. Tests (a) to (d) were not re-run across the book.

**Relays checked.** Every sentence of text the seven applied relays proposed was found in the master.
The sentences not found are instructions, `[A]`'s words, or wording `[A]` changed in `Job88`.

## 1. *Blocking is not a decision* and discomfort blocking

**Fault.** The section's heading says blocking; its body describes burial only, and ends: *No choice
is repeated here, because nothing was noticed to choose about.* / *This is why a decision not to look
is not what happens. Deciding not to look at a thing requires having noticed it first.* The *Blocked*
entry says of discomfort blocking: *A habit of turning away builds until the fear is no longer
noticed* — so the fear was noticed while the habit built.

**Asked:** while the habit of discomfort blocking is building, is each turning away automatic, or
does the person choose not to look?

**`[A]`, 2026-10-26:** *it's a continuum of noticing. the decision starts out feeling like a choice
and becomes more automatic each time.*

**Sites his answer reaches** (found by grep on blocking with noticing, view, choice):

- Fixations chapter, *Blocking is not a decision* — the heading and the last two paragraphs hold for
  burial only.
- Fixations chapter, *The four fates*, *Blocked* — *the fear is turned away from before it is noticed.*
- Same section, the two-questions paragraph — *blocking is what happens when the fear never comes into
  view.*
- Underneath the cycle, *Where a fear meets its fate* — *the fear is turned away from before it is
  noticed* (same claim, Ch 14).
- Fixations chapter, *The range of detachment*, the job example — *Some of the fears are never noticed,
  and those fears are blocked.*

**More sites, found by grepping the idea by its words** (*before it is noticed*, *never noticed*,
*never comes into view*), not by the word *block*. Each says or assumes that a fear that is turned away
from was never noticed, which holds for burial and not for discomfort blocking at its start:

- The cycle chapter, *The two faces of detachment* — *When the fear is very unpleasant, the turning
  away happens before the fear is noticed at all.*
- Fixations chapter, *Disregarding, and not seeing at all* — *Leaning forward toward enthusiasm, a
  person turns away from noticing, and what goes unattended was taken in and never noticed at all.*
- Fixations chapter, the Z+ sketch — *A fear that goes past the caution end without being noticed at
  all is turned away from instead. What the burials lay down accumulates…* (every unnoticed turning away
  read as a burial).
- Levels chapter, *Where a level change can happen* — *A person falls when fears are blocked. Each fear
  turned away from before the fear is noticed takes a little of the person's noticing with it.*
- Falling and rising chapter, *What actually descends* — *Each fear turned away from before it is
  noticed takes a little of the seeing with it.* The relay says discomfort blocking takes a person down
  too, and it starts with the fear noticed.

Checked and left: sites that speak of buried material only (the unease loop's *Her buried fears were
never noticed*, *With buried material, the fear is never noticed*, *What the burial laid down stays
unchanged*, the range-of-detachment paragraph *what is being avoided was never noticed*).

**Follow-up asked:** when a person notices a fear and turns away from it, what makes the turning away
the start of discomfort blocking rather than ignoring?

**Answered by relay from `Job81 doctrine 20261013`**, saved byte for byte as
`RELAY-from-job81-20261026g.md`. `[A]`, pasting it: *from job81 doctrine. i agree.* In short: ignoring
lets the problem alone, and the fear is noticed as fully each time it comes back; discomfort blocking
turns away from the feeling of the fear, driven by aversion to that feeling, and the fear is noticed
less each time. The relay carries a proposed four-sentence addition to the discomfort-blocking part of
the *Blocked* entry, after its first sentence, **for the drafting session to show `[A]`**, and says the
same distinction should guide the five sites Job89 first passed on; it applies equally to the five
found after.

**For drafting:** all ten sites above, worded by that distinction, plus the relay's addition to the
*Blocked* entry.

## 2. *What the axis is toward*, *Follow the object of the wants down*

Job88 had no separate yes for this paragraph in its own session. Shown the paragraph as it stands in
the master. **`[A]`, 2026-10-26:** *yes.* Closed; no change.

## 3. Burial: all at once, or gradual?

**Fault.** The *Blocked* entry: *Blind blocking happens in panic, to a fear the person cannot bear. The
turning away is automatic and happens all at once.* The paragraph opening *What previous thoughts have
laid down* (end of the fixations chapter): *A burial is not one event. … at first most of the fears are
noticed before being turned away from. … Each time, more of the fears are turned away from before they
are noticed. So burying develops gradually…*

**Asked:** does burial happen all at once, or build up gradually from fears that were at first noticed?

**Answered through `Job81 doctrine 20261013`**, saved byte for byte as `RELAY-from-job81-20261026h.md`
(pasted by `[A]` without words of his own; his words are inside it). `Job81` separated one fear from the
history of a matter: each fear blindly blocked is buried all at once, in panic; what develops gradually
is how soon the turning away comes. **`[A]`:** *yes. and that implies and explains that the area of
blind blocking can continuously expand.* The *Blocked* entry stays as it is.

**For drafting, to show `[A]` in place before applying:** in that paragraph, *at first most of the
fears are noticed before being turned away from* → *at first a fear may be glimpsed before panic turns
the person away from it*; and at its end, *As the turning away comes sooner, it also reaches further:
fears that only lead toward the matter are turned away from as well. So what is blindly blocked can keep
growing.*

**Note carried with it (from `Job81`), so the book does not say it three times:** the result is already
stated twice — *So the number of things a person turns away from grows over time.* (fixations chapter,
*The range of detachment*, the paragraph *A conversation, a place*) and *So the part of a person's world
that can still be approached shrinks with every burial.* (levels chapter, *What a level is made of*).
The new sentence gives the reason. Check whether either earlier sentence should point to it, or be cut.
`Job89` checked both sentences: each occurs once, at those places. The first ends the paragraph *A conversation, a place*,
which follows the paragraph on the blindness, as `Job81` said.

## 4. What a level is made of, above the unhealthy band

**Fault.** *What a level is made of* (levels chapter) builds a level from blindness and burial alone:
*Blindness accrues one crossing of the detached phase at a time. A level is not the work of one
crossing. A level takes many crossings, and what stands at a level is all of them together.* / *Each
burial puts one thing out of reach … So the part of a person's world that can still be approached
shrinks with every burial. A person falls as it shrinks.* The book gives blindness to burial (*The
blindness comes about when the person cannot bear the discomfort a fear causes*, fixations chapter),
and says *In the healthy and average bands, Levels 1 to 6, the blocking is mostly discomfort blocking.*

**Asked:** do discomfort-blocked fears make a person blind too, in the health axis's sense, or is
blindness only what burial produces?

**`[A]`, 2026-10-26:** *blindness is only what burial produces, but preexisting blindness can operate at
all levels.*

**Sites his answer reaches:**

- Levels chapter, *What a level is made of*, its first two paragraphs — a level, and the fall, are said
  to be made of blindness and burials only. In Levels 1 to 6 a level is made mostly of fears blocked by
  discomfort, which are not blindness; blindness carried from earlier burials (childhood burial among
  them) operates there too.
- Falling and rising chapter, *What actually descends*, last paragraph — *What was learned from outside
  changes how often a fear gets handled instead of buried, and so how fast a person sinks.* Sinking is
  tied to burial only.
- Falling and rising chapter, *Rising* — *A skill for handling fear does not put a person further up the
  axis. It changes how often a fear gets handled instead of buried, which is a rate.* Same tie.
- Already listed under finding 1: *What actually descends*, *Each fear turned away from before it is
  noticed takes a little of the seeing with it*; levels chapter, *A person falls when fears are blocked.
  Each fear turned away from before the fear is noticed…*

Checked and left: *Spoiled arrivals* (*Blindness … accrues … and it locks* is a claim about blindness,
true under the answer); *The correspondence* (*to blindness* names the bottom of the range).

## 5. What a person can bear, and discomfort blocking

**Fault.** Two sentences make blocking depend on a fear being unbearable, against the *Blocked* entry's
*Discomfort blocking happens to a fear the person can bear but finds uncomfortable*:

- Fixations chapter, *The unease loop* — *Only a skill for handling fear can change whether a fear is
  blocked, because a fear is blocked only when the person cannot bear the fear.*
- Falling and rising chapter, *Why this does not take everyone to the bottom* — *A level is made of many
  blocked fears, and a fear is blocked only when it is more than the person can bear.*

More widely, the book's account of the fall runs on what a person can bear deciding between facing and
turning away: *What falling takes from capacity* (*how much a person can bear is what decides whether
the next fear is faced or turned away from*), and the intervener passages (*A fear gets turned away from
when it is more painful than the person can bear at that moment*; *Whether a person faces a fear or turns
away from it is settled by how much they can bear at that moment*). As written these cover burial only.

**Asked:** for a fear the person can bear, what decides whether it is faced or blocked by discomfort,
and does stress make discomfort blocking more likely?

**Answered through `Job81 doctrine 20261013`**, saved byte for byte as `RELAY-from-job81-20261026i.md`.
`[A]`, to `Job81`: *stress decides. anything else?*; asked whether the list is stress, the lean, the
strength of the fixation, learned skill, the habit already built, and understanding one's own blindness:
*yes.* `[A]`, pasting the relay here: *i agree.* Stress makes discomfort blocking more likely, as it
makes blind blocking more likely, by making a fear's discomfort bigger relative to what the person can
bear.

**For drafting, by the relay:** each site must cover both kinds — a fear is blindly blocked when it is
more than the person can bear, and blocked by discomfort when looking at it is uncomfortable; the six
factors bear on both; where the intervener helps by changing how much a person can bear, the same help
also makes discomfort blocking less likely. **Sites:**

- Fixations chapter, *The unease loop* — *a fear is blocked only when the person cannot bear the fear.*
- Falling and rising chapter, *Why this does not take everyone to the bottom* — *a fear is blocked only
  when it is more than the person can bear.*
- Falling and rising chapter, *What falling takes from capacity* — *And how much a person can bear is
  what decides whether the next fear is faced or turned away from.*
- Falling and rising chapter, *What reaches someone who cannot see their own condition* — *A fear gets
  turned away from when it is more painful than the person can bear at that moment. Two things decide
  whether it is.*; *Blocking happens when something is detected as a threat. In small enough amounts, no
  part of the truth is a threat by itself. So no part of the truth is blocked*; and the last paragraph,
  *Whether a person faces a fear or turns away from it is settled by how much they can bear at that
  moment.* `Job81` named three sentences; `Job89` found these further sites by grepping *can bear*.

## 6. The sources of lasting unease

**Fault.** The unease loop names two sources only: *Ignored aversions and buried fears are the two
sources of lasting unease, and they differ in what ends them.* / *Where a person has neither buried
fears nor ignored aversions, there is no chronic unease.* A fear blocked by discomfort is neither.

**Asked:** does a fear blocked by discomfort leave lasting unease, so that it is a third source?

**Answered through `Job81 doctrine 20261013`**, saved byte for byte as `RELAY-from-job81-20261026j.md`
(pasted without words of his own; his words are inside it). **`[A]`, to `Job81`:** *i'm thinking that the
knowledge that the person is less capable than others is a cause.*; asked whether the sources are ignored
aversions, blocked fears of either kind, and a persisting perceived threat such as knowing one is less
capable than others: *yes. maybe we should say "knowing one is less capable than others because the
person because of failure to face fears"? do you think native lack of ability counts or is that just a
fear that can be handled by any of the four fates?*; asked whether native lack of ability is an ordinary
matter and only the lack that comes from blocked fears is a source: *yes.*

**For drafting, to show `[A]` in place:** the relay's replacement for the two-sources paragraph (three
sources) and for the no-chronic-unease sentence; the same change at every pairing. `Job89` grepped the
pairing; there are exactly five sites, all named by the relay:

- Fixations chapter, *The unease loop*, opening — *The unease comes from buried fears and from ignored
  aversions.*
- Same section — *Ignored aversions and buried fears are the two sources of lasting unease…*
- Same section — *Where a person has neither buried fears nor ignored aversions, there is no chronic
  unease.*
- Same section, the habitual-fear paragraph — *A habitual fear is kept going by buried fears or ignored
  aversions, and by the unease loop.*
- Fixations chapter, the Z+ sketch — *the unease comes from buried fears and ignored aversions.*

**`Job89` note for drafting, not a ruling:** the book already has a perceived inability, in two places —
*The unease loop*: *Buried material can leave a person unable to handle life. The person perceives the
inability as a threat. The perception is not blocked.*; and *What falling takes from capacity*, the
third source of stress: *a person who cannot handle life perceives the inability as a threat.* Both name
buried material as the cause; under this ruling the cause is blocked fears of either kind. The new third
source should be checked against these two so that one thing has one name (*unable to handle life*
against *less capable than others*). If the names differ in meaning, that is a question for `[A]`.

**Asked:** is *knowing that one is less capable than others* the same thing as the book's perceived
inability to handle life (*Buried material can leave a person unable to handle life. The person perceives
the inability as a threat.*)? `Job89` quoted both book sentences in full and then, in the question, used
the compressed form *perceives the inability to handle life as a threat*, which is not the book's text.

**`[A]`, 2026-10-26:** *same. merging them would be good.*

**For drafting:** one name for the one thing, at the new third source and at both existing sites (*The
unease loop*, *Buried material can leave a person unable to handle life…*; *What falling takes from
capacity*, the third source of stress). The drafting session proposes the name and shows `[A]`. Under
finding 6 the cause at both existing sites becomes blocked fears of either kind, not buried material
only.

## 7. *What is buried then stays buried*

**Fault.** *The process that produces the levels*: *A small child can be brought to panic by very little,
and what is buried then stays buried.* *Rising*: *A buried fear can come back into view by itself. What
arrives first is not the buried fear but the fear of looking at it.* *Stays buried* reads as permanent.

**Asked:** does it stay buried until the fear of looking is borne and the buried fear faced, like any
buried fear, or is early-childhood material different?

**`[A]`, 2026-10-26:** *same in that regard, but preverbal fears are immune to logic and therefore more
difficult to access.*

**For drafting:** the sentence should say the material stays buried until it is faced, as any buried
fear does. The difficulty `[A]` names is already in *Rising* (*The oldest material was never ideas at
all. … There is nothing there to bring to mind and examine. The only handle is the felt quality
itself.*); the drafting session decides whether the panic paragraph needs more than the correction, and
shows `[A]`.

## Owed

- **A drafting session** on items 1 and 3 to 7 above, with the four relays.
- **The handoff is stale** (`HANDOFF-20261005b.md` names the 09-23 master). Carried from `Job88`.
- **For a doctrine session:** whether the perceived inability to handle life bears on depth and
  threshold, reserved for a session of its own. Carried from `Job88`. Item 6 makes it a source of
  lasting unease, which may bear on the question.
- **The writer 2 pass**, still waiting on Toby Marshall. Carried.
