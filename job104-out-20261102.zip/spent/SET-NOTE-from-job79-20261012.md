# SET NOTE — from `Job79 coherence 20261010`

This note goes to the session that receives `job79-out-20261012.zip`. `[A]` gives the kind of session.
The manifest label carries only the counter and the date.

## Arrival

The incoming zip was `job78-out-20261011.zip`. It verified against `MANIFEST-job79-20261011.md`:
**56 ok, 0 mismatched, 0 bad count, 0 missing, 95 not in the manifest** (the `spent/` and `superseded/`
folders). `[A]` added by hand `BRIEF-for-coherence-from-job70-20261011.md`,
`FILES-from-job70-20261011.md` and the record at 85,913 w (md5 `4a13bf4b`), all matching the receipt
list. On 10-12 he added `ANSWERS-for-coherence-from-job70-20261012.md` and the record at **88,403 w**
(md5 `2f729e0e`), with the 85,913 w file as its exact byte prefix.

## What was done

A coherence run. The master, `BOOK2-20261011.md` (md5 `22eca00d`, 40,396 w), was read through in
full and **not edited**. Everything is in **`FINDINGS-job79-20261012.md`**, which is the file a drafting
session works from, together with `ANSWERS-for-coherence-from-job70-20261012.md`. In brief:

- the capacity sweep the brief asked for: **one site**, in the orientations chapter;
- **turning away is not learned**: two sentences in *Blocking is not a decision* are at fault;
- **`range`** may carry two senses where context is clear; one sentence in the health axis chapter
  fails that test;
- **`pulls` replaces `draws` everywhere** (`[A]` 10-12), plus three `point` sites in the type sketches;
- **disappointment** is not an aversion; the shoelace is two thoughts; the four fates' entries are
  written for a fear; giving up does not always leave a regret;
- one `looked at` at the wrong stage, in the chapter on leans.

**Register letter `g`**, `WORD-RULINGS-book2-20261012.md`: `pulls`, `range`, disappointment and regret.
Letter `f` is in `superseded/`. Three patterns added and one extended; `wordcheck.py` against letter `g`
fires on every site the findings name.

**The claim inventory** has a 10-12 section naming the units at fault. Its entries were not re-cut.

## The record

One append, blind: the **sixty-ninth**, parent 88,403 w, **head 88,950 w**, md5 `55dd6d0f`, marker
`Job79 coherence 20261010`, closing. The parent's bytes were checked unchanged at the join.

**One departure from the rule that a coherence session does not open the record.** To copy the
marker's shape, `Job79` displayed the record's last 25 lines, which are the end of `Job70`'s
sixty-eighth append. It read nothing else in the file. The block says so.

## Moved

- To `spent/`: `CHANGES-job78-20261011.md` (read by this run), `SET-NOTE-from-job78-20261011.md`,
  and `FILES-from-job70-20261011.md` (the receipt list for this run).
- **Kept live at set level:** `BRIEF-for-coherence-from-job70-20261011.md`. Its §6 is the only statement
  a drafting session may read of the two 10-10 rulings. Its record figure, 85,913 w, is stale.
- To `superseded/`: `MANIFEST-job79-20261011.md`, and letter `f` of the register as
  `SUPERSEDED__live__WORD-RULINGS-book2-20261009.md`.
- **New and live:** `FINDINGS-job79-20261012.md`, `WORD-RULINGS-book2-20261012.md`,
  `ANSWERS-for-coherence-from-job70-20261012.md`.
- **Stays live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`,
  not to be acted on until `[A]` says so.

## What is owed

- **A drafting session** on `FINDINGS-job79-20261012.md` and the answers file. Two items in the answers
  file carry no words of `[A]`'s on their wording or placement: **what a thought leaves** (item 3) and
  **where the held sentence goes** (item 6). Put each to him in one line first.
- **The two 10-10 rulings** go to the unease-loop job, not the next drafting session (`[A]` 10-12, *ok*).
- **The handoff is stale on two files a drafting session reads first:** it names register letter `c`
  (`WORD-RULINGS-book2-20261005.md`); the live register is letter `g`, `WORD-RULINGS-book2-20261012.md`.
  The style guide (`STYLE-GUIDE-20261005b.md`) and `RULE-referring-words-20260908b.md` it names are current.
- **The handoff needs a cut.** `HANDOFF-20261005b.md` still names the 09-23 master and register letter `c`.
- **The unease material** is in the set, restricted by its name to the doctrine sitting (below).
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## The order of work, agreed by `[A]` on 10-12 (*ok*)

1. **A drafting session** on `FINDINGS-job79-20261012.md` and the answers file. It does not touch the
   unease material, the two 10-10 rulings, or *Rising* beyond the sites the findings name.
2. **A doctrine sitting on the unease loop.** It reads, besides the record in full:
   - `DOCTRINE-ONLY__NEW-MATERIAL-the-unease-loop-20260923b.md` — `Job70`'s 09-23 material, written
     before a fear was ruled to last one thought, before one capacity, gradual burial, and disappointment
     not being an aversion. **Check it against those rulings first.**
   - `ANSWERS-for-coherence-from-job70-20261012.md` item 7 (no ranking; exits by competence; the loop
     about the unease at the enthusiasm end; capacity as its only exit) and item 2 (the turning over is a
     fate of its own and belongs here).
   - `BRIEF-for-coherence-from-job70-20261011.md` §5 and §6: the 10-07 case of a person who learned to
     recognize a secondary aversion; the 10-09 separation of buried material from material that
     habitually raises fear; and the two 10-10 rulings. All are in the record with `[A]`'s words.
   - It hands over sited closures, against whatever master step 1 produces.
3. **A drafting session** from those closures, including *Rising*.
4. **A coherence run.**

**`Job79` read the file through, to check it before carrying it, and checked nothing in the manuscript
against it.** Two things for the doctrine sitting to know, neither a ruling: its §8 ranks the loop's
strength by orientation, which `Job70`'s answers file item 7 now recommends the book not do; and it
uses `brake` and `registers`, which the register keeps out of the book. Its own header says it was cut
without a manuscript or the record.

**The unease file is restricted by its name.** `DOCTRINE-ONLY__` means a drafting session does not open
it, for the same reason it does not open the record: it holds unruled material.

## Next

`[C]`'s recommendation: **a drafting session on `FINDINGS-job79-20261012.md`**. It should run
`wordcheck.py` against letter `g` before closing.
