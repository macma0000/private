# SET NOTE — from `Job56 drafting 09072026`, for the session that opens this set

**Cut 2026-09-07. Kind 11, drafting, on the eleven items of prose owed by
`SET-NOTE-from-job55-20260907.md` §9.**

**All eleven were done, including the vocabulary pass the outgoing session recommended holding
back.** Book 2 and the style guide have new letters. Book 1, the claim inventory and every note are
byte-identical to what arrived.

---

## 1. What arrived, and what the checks said

Incoming zip `job55-out-20260907.zip`, one directory, verified against `MANIFEST-job56-20260907.md`:
**51 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.** Screen fired two, both
benign — the record as CARRY DO NOT READ, and the handoff for quoting the restriction string.

Record arrived **47,048 w, marker `Job55 doctrine 09072026`, thirty-sixth append, parent 44,672** —
matching `SET-NOTE-from-job55-20260907.md`, so the chain was clean.

---

## 2. WHAT WAS WRITTEN

`BOOK2-20260907.md` → **`BOOK2-20260907b.md`, 32,049 → 32,533 w.**

**Part 1 — the width of focus, and the two stages named.** Five paragraphs in the three orientations,
after the detachment paragraph. Everything a realm holds is taken in whole and at once; picking one
part out of it and attending to that part is noticing, and it is work. What has been taken in stays
out of view until something makes a person want one part of it. Motivation brings the noticing on and
also sets how much is taken in. The three widths follow, in the order the cycle runs. A person does
one or the other and not both at once, and nothing is used up by the move.

**Detachment's competence is the taking in, at three sites** — Part 1's competence line, the range of
detachment, and the Four's sketch, where `seeing` stood four times.

**The range of detachment's contradiction is now derived rather than asserted.** Taking in is widest
where nothing pulls; noticing needs something pulling; a detached person wants nothing, so takes in
the most and notices the least. *Its closing sentence had said handling a conflict destroys the
competence `because that competence is attending`, which the ruling reverses. What quieting a
conflict costs is the noticing, which was already the scarce half.*

**The blocking passage.** Both place-sentences replaced. The third compartment sentence repaired —
`some part of them registers the threat and stops it before it reaches them` is gone, and what stays
is that the fear survives whole and a person cannot get at what they never noticed. **The
second-recognition sentence is cut**: it was put to `[A]` before any prose was written and he ruled
*yes*. What replaces it is the deposits ruling. **A fourth compartment site was found in the same
paragraph and was on nobody's list** — `rational consciousness grew on top of it and hid it`.

**The three-things-run-together passage** rewritten so that nothing stops the taking in and nothing
fails to be presented. **It is stated a second time at the end of Part 2, and both copies carried the
fault.** Both are repaired. **The duplication itself is NOT resolved** — the same passage said twice
is already on the open list as an architecture matter, and cutting one of them is not a drafting
session's call.

**The leverage guess replaced** by the accumulating recognition, and the passage no longer calls
itself a guess. Blocking stops the noticing and never the taking in, so a disposed-of moment is not
lost; painful consequences raise the accumulation into view. *Its new closing paragraph — the
recognition still waits on the world to deliver the pain — leads into the section on what reaches a
person the consequences no longer reach, which previously had no lead-in.*

**The Nine's block:** `nothing bends what they take in`; `seeing twice over` retired; the blind-face
sentence; and a paragraph opener that restated the sentence above it and stated it backwards, since
having no stake is why a Nine takes in whole and not the result of it.

**Two of the twelve instances** — the Two's and the Four's physical — plus a residue of the same
claim at the foot of the Four's own sketch. *The Five's and Seven's detached lines were checked
against their sketches and needed nothing.*

**The 0-position paragraph** shortened to two, with book 1's trait-plus-state reason in place of the
assertion. Out: the recital of what each lean carries, `unselective receptivity`, and `it is not
perfection`.

**`intuition` sited in Part 1**, immediately after the two stages, on `[A]`'s definition. *Sited
there because the two stages raise the question and answering it elsewhere leaves a question the book
asked and walked away from. Its last sentence supplies the reason the type profiles never had for
telling a reader not to score themselves against a checklist.*

---

## 3. THE VOCABULARY PASS — done, and far smaller than estimated

The outgoing session put it at roughly a hundred sites and recommended a session of its own.
**Measured before starting, it was about twenty.**

- **`register` is gone from book 2** — twelve occurrences on nine lines. Three to `take in` (*what a
  person does about what they take in*, *a person is allowed to notice less of what they take in*,
  and the arc sequence). The rest to `notice`, including a section heading.
- **Both doctrinal `surface` sites are gone.** Six ordinary uses stand.
- **The verb `see` needed four first-stage sites**, all repaired: Part 1's competence, the Nine's
  *seeing twice over*, the range of detachment, and the Four's sketch. Most of the 216 occurrences of
  the see family are ordinary, and the noun `sight` is the health axis's own word and keeps its job.

**A finding to carry into the coherence check.** *Both of the sites found beyond the two the outgoing
session had named were reached by a `register` search landing on a neighbouring line, not by any
search aimed at them.* **A sentence that assumes the single-stage account while using neither word is
invisible to search.** The second copy of the three-way distinction is the demonstration: it was
found because a `register` hit fell on the heading above it.

---

## 4. `[A]`'S CORRECTIONS THIS SESSION — three of the four are one fault

- **`"It is fed each time it runs." - inanimate subject with animate verb`**, on `[C]`'s own new
  prose. Re-reading the session's other new prose against the same rule found two more of `[C]`'s.
- **`is it taken in or noticed?`** — and it caught a substantive error, not a wording one. `[C]` had
  retired `register` at the Seven's site and reached for `take in` without asking which stage the
  sentence was about. **It is noticing.** A Seven has a motivation; motivation brings noticing on and
  narrows it; the claim is that a narrow noticing turns them without telling them what the thing is.
  `take in` destroys it, since everything is taken in whether they stay or not.
- **`did you mistake taking in for noticing anywhere else?`** — **three more, all `[C]`'s from this
  session**: `known through having looked at it` (nothing taken in is known until noticed), a
  disposed-of moment said to stay `where everything else a person has taken in stays` (the compartment
  reappearing in the paragraph removing it), and `taking in that the blindness is costing them` (which
  makes the taking in propositional).
- **`"The position is real and it has no width." is a good metaphor but a general reader won't
  understand it.`** `width` had been earned in Part 1 by building it out of narrow and wide, then used
  here where nothing earned it.

**Both are in `STYLE-GUIDE-20260907c.md`** — a section 8 bullet on deciding which stage a sentence is
about before changing its word, and a caught instance under the diagnostic on a technical figure a
general reader cannot parse.

---

## 5. WHAT IS OPEN

- **The two crossings between a person's two realms are ruled doctrine with no prose anywhere in book
  2.** An orientation crossing helps; a realm's principles crossing is the critical confusion. It was
  settled by `Job55` §7 and was never on that session's owed-prose list, so it would otherwise fall
  between sessions. **It touches the One's and the Eight's sketches, which this session also touched.**
- **The three-way distinction is stated twice**, at the end of Part 2 and in Part 3. Both are correct
  now; which one goes is an architecture question and is already on that list.
- **Two sentences left standing in the Nine's block**, both predating this session and neither ruled:
  the join sentence `Job54` added, and the closing line about judging soundly because they can see
  what the wanting is doing to their view. Either may now restate the repaired opening paragraph.
- **Whether blindness is a separate input to capacity or the realm-specific part of being caught** —
  carried from 09-06, untouched again. Today's rulings bear on it.
- **The claim inventory is now two masters stale** and carries none of the two-stage doctrine.
- **No site in either book shows a crossing into a cautious realm.** Untested, not a gap.

---

## 6. THE RECORD

**Thirty-seventh append, blind**, this being a drafting session. Reach verified from the marker before
writing: 47,048 w, `Job55 doctrine 09072026`, thirty-sixth append, parent 44,672. Head is now
**48,322 w, md5 `d10cfd25`**; the 278,523-byte prefix verified byte-identical after the append, and
the marker is in the canonical bold form the sweep can read.

---

## 7. RECOMMENDATION FOR THE NEXT SESSION

**Kind 12, the coherence check.** `[A]` asked what kind should come next and assented.

The reason is what this session did. The book now uses `take in` and `notice` as two different things
in about thirty places, and the distinction did not exist when the surrounding prose was written.
What a search cannot find is a sentence that assumes the old single-stage account while using neither
word, and **§3 above shows those exist**. A coherence session also reads cold, which the session that
made the changes cannot.

**Kind 11 is queued behind it, and its job is the two crossings.** Written into a coherence-checked
book rather than this one, because it lands in sketches this session's pass touched.
