# FINDINGS — `Job93 coherence 20261028`

Coherence run on `BOOK2-20261028.md` (44,633 w, unchanged), reading `CHANGES-job92-20261028.md` and the nine relays
`Job92` applied (`RELAY-from-job81-20261027.md` to `-20261027d.md`, `-20261028.md` to `-20261028e.md`). `[A]`'s words are
verbatim. The session ran on 10-28 his time (10-29 UTC). Three updates from `Job81 doctrine 20261013` arrived in session,
each saved byte for byte: **`RELAY-from-job81-20261029.md`, `-20261029b.md`, `-20261029c.md`.** Each carries `[A]`'s
words inside it.

**Changes file checked.** All 34 rows of `CHANGES-job92-20261028.md` are in the master (35 paragraph hunks against
`superseded/BOOK2-20261027.md`). Every sentence the nine relays proposed is in the master, relay `20261028d` with *that is
where it is found* repaired as row 11 says, and relay `20261028e` with *desire* left only in *Riso and Hudson call this want
a desire.* and the Naval Ravikant sentence.

**For the drafting session.** Items 1 to 3 are ruled, through the three relays. Items 4 to 6 are `[C]` decisions taken from
rulings already given. Show `[A]` each change in place before applying it, new words in square brackets, with the words
going out listed underneath (bold does not show on his screen). Grep each idea by its words, not only at the sites listed.

**Tracking check.** Run on **a buried fear**, as Job92 asked: its growth before the panic, the panic at the caution end,
the turning away completed at the enthusiasm end, denial, the layers of fear of the fear, and what can still reach it. The
growth stage was missing from the book (item 1). Every later stage reads consistently with relays `20261028b` and
`20261028d`, apart from items 4 and 5. Tests (a) to (d) were not re-run across the book.

## 1. What happens to the fear before the panic

**Fault.** The book says *A fear is usually buried only after it has come up repeatedly and grown*, but not what fate the
fear meets on the earlier occasions. A fear worked through or given up on is settled, so it cannot be the fear that grows.

**Asked:** on the occasions before the panic, is the growing fear ignored, blocked by discomfort, either one, or something
else?

**Answered by `RELAY-from-job81-20261029.md`.** `[A]`: *i agree with this:* — and, inside it: *Worked through doesn't cause
discomfort, i think. not until a person responds differently later. how does that sound?*; *not sure. it fits with our
picture so i would use it.*

**For drafting**, at the burial passage (the *Blocked* entry of *The four fates*, and *A burial is not one event*): *Before
the panic, the fear has usually been ignored, or blocked by discomfort, as the problem went on. Each time the fear came back
stronger.* The relay's last line (worked-through tension fades and does not build) is **withdrawn** by relay `20261029b`.

**`[C]` DECISION, the week.** *A burial is not one event* says *The main burial of a matter happens quickly, perhaps within
a week.* `[A]` gave the week on 10-27, before the growth was ruled in. A fear that grows over repeated incidents can take
longer than a week, so the week counts from the panic. Drafting to word the sentence so the week plainly starts at the
panic, not at the first incident.

## 2. Does the tension build in the unease loop?

**Fault.** Relay `20261029`'s last line said a worked-through fear leaves tension that fades and does not build from turn to
turn. *The unease loop*: *each turn is worked through*; *The bodily tension builds, because every turn leaves a little
more.*; *But every turn of the unease loop adds more bodily tension. So the unease lasts as long as the matter stays
unresolved.*

**Answered by `RELAY-from-job81-20261029b.md`**, which withdraws relay `20261029`'s last line. `[A]`, inside it: *i'm not
sure tension builds. why should it?*; then *yes* to: the tension is kept up while the matter is unresolved, and builds only
when the turns come quickly.

**For drafting**, in the house-sale example: both sentences that say the tension builds every turn (third paragraph,
*The bodily tension builds, because every turn leaves a little more.*; eighth paragraph, *Any one bodily tension lasts
hours rather than days. But every turn of the unease loop adds more bodily tension. So the unease lasts as long as the
matter stays unresolved.*) give way to the relay's four sentences, beginning *Every turn of the unease loop leaves a little
bodily tension.* Check the rest of the section for *builds*.

## 3. *Two things that cannot happen*

**Fault.** *Nobody watches themselves go down. A drop is made blacked out; if it were witnessed it would not be a drop.* and
*Insight requires a crossing made in full sight. A fall is a crossing made blacked out.* Against: discomfort blocking begins
with a fear that is noticed, and *at first the turning away feels like a choice*; at a burial the fear is still in view at
the caution end, and *what the person feels then is panic or a sharp upset*. The *blacked out* wording is left from the
crossing account retired in September. No earlier session raised it.

**Asked:** does a person ever see themselves going down, and should the section be cut or narrowed?

**Answered by `RELAY-from-job81-20261029c.md`.** `[A]`, inside it: *my thought is that a fall by discomfort blocking isn't
noticed because it's gradual. so it would be noticeable. and "blacked out" sounds like the fall happens in a single
incident.*; then *yes* to the relay's two paragraphs.

**For drafting:** the relay's two paragraphs replace the section's sentences using *blacked out*. By the relay's last line,
*Rising*'s opening, *in full sight instead of blacked out*, follows the same wording. That is the book's only other
*blacked out*. (*It falls from full sight, through wariness…* in *The correspondence* is about the levels' names and stays.)

## 4. Chapter 4 places the panic at the enthusiasm end

**Fault.** Chapter 4's denial paragraph: *At the enthusiasm end, a person is more likely to turn away from anything
negative. Sometimes a fear grows until the fear is more than the person can bear, and panic turns the person away from the
fear.* Relay `20261028d` (`[A]`: *yes*): the panic happens at the caution end, where the fear is in view, and the turning
away is completed at the enthusiasm end. The cycle chapter and *The range of detachment* now say so.

**`[C]` DECISION, by relay `20261028d`:** Chapter 4's paragraph to place the panic at the caution end and the completed
turning away at the enthusiasm end. The paragraph before already names both ends.

## 5. *With buried material, the fear is never noticed*

**Fault.** *The unease loop*, habitual-fear paragraph. Job92 left the sentence for coherence to judge, reading it as about
later fears. By relay `20261028b` the fear came up repeatedly, in view, before the panic, so *never* is wrong of the fear
itself.

**`[C]` DECISION, by relays `20261028b` and `20261028c`:** *never noticed* → *no longer noticed*, as at the four sites Job92
changed (rows 2, 20, 21, 32).

## 6. Checked and left

- *The unease loop*, migraine case: *A person whose turning away comes before the noticing has nothing to notice and stop.*
  Reads by the layers of fear of the fear: when the fear of looking is buried too, the anxiety is turned away from before it
  is noticed. *Not too deeply buried* is that contrast. Left.
- *Burial is not a decision*, fourth paragraph: *The anxiety that caused the turning away is taken in, and so is the turning
  away itself, and neither of them is ever noticed.* Follows the paragraphs on later threats, and reads as about them. Left.
- *One thought, step by step*: *A want is what motivates a person to bring something about…* repeats Chapter 4's sentence
  word for word. Approved in place (Job92 row 27). Left.
- Job92's left-unchanged list: the two small-child sentences, *move* at the summit, and the section title *Disregarding, and
  not seeing at all*, all stand. *With buried material, the fear is never noticed* is item 5.

## Owed

- **A drafting session** on items 1 to 5 above, with relays `20261029` (its first proposal only), `20261029b` and
  `20261029c`.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master. Carried.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold. Carried.
- **The writer 2 pass**, still waiting on Toby Marshall. Carried.
