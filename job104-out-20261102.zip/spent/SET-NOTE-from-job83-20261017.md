# SET NOTE — from `Job83 coherence 20261016`

This note goes to the session that receives `job83-out-20261017.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job84-20261017`.

## Arrival

The incoming zip was `job82-out-20261016.zip`. It verified against `MANIFEST-job83-20261016.md`: **56 ok,
0 mismatched, 0 bad count, 0 missing, 126 not in the manifest** (`spent/` and `superseded/`). The screen fired on the
names in `superseded/` and on the record (*carry, do not read*). The record's last marker matched `Job82`'s set note:
eighty-third append, 95,915 w. `Job83` did not read the record.

## What was done

The coherence run on `BOOK2-20261016.md`, step 4 of the order `[A]` agreed on 10-12. Part 3 was read through; Parts 1
and 2 were read except the type sketches. Eight faults were put to `[A]` one at a time and all eight ruled; a ninth is
a `[C]` finding not put to him. `[A]` carried two exchanges with `Job81 doctrine 20261013` in, both marked as relays.

- **Product: `FINDINGS-job83-20261017.md`.** The drafting session works from it alone. In brief: the pain of facing is
  imagined unbearable at every depth, so only the pain of staying sets where a person settles; the whole felt pain of
  staying counts, and at unbearable a person is open to trying something new, not bound to face; minor intervention
  is common; an ignored aversion is available, not kept in view; chronic unease needs buried fears or ignored
  aversions; no *unease loop about the unease*; gratification's relief comes from expecting less; *Book 1 calls* is
  dropped; the migraine passage reworded in `[A]`'s approved form; *health axis* used before it is introduced (not
  ruled).
- **`WORD-RULINGS-book2-20261017.md`, letter `j`.** Section 5a amended; two patterns added, each firing on the master.
- **The claim inventory** carries a 2026-10-17 update block: entries for *Gratification* and *The unease loop*, a
  replacement entry for *Disappointment*.
- **No book text was written.** The master is unchanged: `BOOK2-20261016.md`, md5 `7612914c`.

## The record

One append, blind: the **eighty-fourth**, `[A]`'s answers verbatim with the questions, the two relays marked
second-hand, and one passage marked **PERSONAL — NOT FOR THE BOOK**. **Parent 95,915 w, head 96,764 w.** The parent's
bytes were checked unchanged at the join.

## Moved

- To `spent/`: `CHANGES-job82-20261016.md` (read by this coherence run), `SET-NOTE-from-job82-20261016.md`.
- To `superseded/`: `SUPERSEDED__live__WORD-RULINGS-book2-20261016.md`, `MANIFEST-job83-20261016.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be
  acted on until `[A]` says so.

## What is owed

- **A drafting session on `FINDINGS-job83-20261017.md`.** Read its header first. Item 9 is not ruled.
- **The style guide's section 8 names register letter `i`.** Letter `j` is live; the pointer needs a letter of the
  style guide at the next cut. Nothing else in the style guide changed.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master, register letter `c` and style guide letter
  `d`. It needs a cut.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a drafting session on `FINDINGS-job83-20261017.md`**, then a coherence run on what it cuts.
