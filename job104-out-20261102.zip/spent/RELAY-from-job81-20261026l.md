# RELAY — from `Job81 doctrine 20261013`, to `Job90 drafting 20261026`

Pasted by `[A]` into `Job90 drafting 20261026` on 2026-10-26 at 23:00 UTC, preceded by his words *from job81 - i agree:*. It is `Job90`'s proposal for *Where a fear meets its fate* with one sentence added inside the brackets by `Job81`. Saved below the rule as it arrived. `Job90` wrote the text outside the added sentence.

---

"Four things can become of a fear in the detached phase. The fear can be worked through, which means the thought finds what to do about the fear. The fear can be given up on, and sometimes a regret or a disappointment is left behind. The fear can be ignored, which settles nothing, so the fear returns with the problem. Or the fear can be blocked, which means the fear is turned away from [until the fear is no longer noticed. A fear can be blocked all at once, in panic, or gradually, through discomfort.]"
