# SET NOTE — from `Job91 coherence 20261026`

This note goes to the session that receives `job91-out-20261028.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job92-20261028`.

## Arrival

`job90-out-20261027.zip` verified against `MANIFEST-job91-20261027.md`: **64 ok, 0 mismatched, 0 bad count, 0 missing,
177 not in the manifest**, all 177 in `spent/` (106) and `superseded/` (71), matching `Job90`'s moves. The record's last
marker matched `Job90`'s note: ninety-second append, 101,171 w. `[A]` named the session `Job91 coherence 20261026`; the
label's counter agreed. The session ran from 10-27 into 10-28.

## What was done

A coherence run on **`BOOK2-20261027.md`** (unchanged; 44,029 w), reading `CHANGES-job90-20261027.md` and relays `g` to
`n`. All 29 rows and every relay sentence are in the master. **Product: `FINDINGS-job91-20261028.md`** and a 10-28 block in
`CLAIM-INVENTORY-book2-20260902.md`. Five `Job81` updates arrived in session, saved byte for byte:
**`RELAY-from-job81-20261027.md`, `-20261027b.md`, `-20261027c.md`, `-20261027d.md`, `-20261028.md`.**

The findings, all ruled with `[A]`'s words or taken from them as marked `[C]` decisions: a buried fear is glimpsed before
panic turns the person away, and later fears are turned away from before they are noticed; the first burial is not a
decision because panic does the turning away; denial is blind blocking only; what was never noticed is closed to
intentional access only; new Ch 4 definitions of attraction, aversion, want and fear (relay `20261027d`, final); the main
burial is quick, and the layers of fear of the fear that follow are buried too; *blocked* → *buried* in the job history;
both causes of being less able to handle life come from blocked aversions; discomfort blocking lowers noticing but does
not blind, so *seeing* → *noticing* at four sites.

**`relief from` was proposed and withdrawn in session** (relays `b` then `c`). Every *want to be rid of* and *want …
gone* sentence stands as written.

## The record

One append, blind: the **ninety-third**, `[A]`'s words verbatim with what each answered; the relays are named, not
repeated. **Parent 101,171 w, head 101,849 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `CHANGES-job90-20261027.md`, `SET-NOTE-from-job90-20261027.md`, relays `RELAY-from-job81-20261026g.md` to
  `-20261026n.md`, and `FOR-job81-from-job91-20261027.md` (answered).
- To `superseded/`: `MANIFEST-job91-20261027.md`.
- **Kept live:** the five new relays, for the drafting session; `FINDINGS-job75-20261005.md` for its Part Four;
  `NOTE-introduction-recognition-20261007.md`, not to be acted on until `[A]` says so.

## What is owed

- **A drafting session on `FINDINGS-job91-20261028.md`**, items 1 to 8, with relays `20261027d` and `20261028`.
- **The word register** needs the 10-28 definitions; its 10-09 entries on attraction, aversion and desire are superseded.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold.
- **The writer 2 pass**, still waiting on Toby Marshall.

**For any session that shows `[A]` a change: bold does not show on his screen.** Mark new words with square brackets.

## Next

`[C]`'s recommendation: **a drafting session on `FINDINGS-job91-20261028.md`.**
