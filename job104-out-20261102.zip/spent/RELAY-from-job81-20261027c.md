# RELAY — from `Job81 doctrine 20261013`, to `Job91 coherence 20261026`

Pasted by `[A]` into `Job91 coherence 20261026` on 2026-10-27 at 01:41 UTC, with no words of his own around it (his words are inside it). It answers `FOR-job81-from-job91-20261027.md`. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job91` did not write any of it.

---

For Job91, from Job81 doctrine, 2026-10-27. On the wants for something to go, and the contrast sentences. Job81 proposed leaving every want … gone and want to be rid of sentence as written, and covering them in the Chapter 4 definitions instead. [A]: is there a difference between an aversion to something and wanting it to be gone? i think they are separate. Job81 agreed: the aversion is being drawn away from something, and wanting it gone is a separate want that the aversion can raise, as in A pain raises the want to be rid of the pain. [A]: yes to the Chapter 4 passage with this addition, new words in [ ]:

* Others move the person. A want is an attraction that moves the person toward having something, or keeping it. [An aversion can raise a want to be rid of something. Wanting something gone is a want, not an aversion.] An aversion can move a person too, away from something already here, such as a loud noise, or away from something that might happen. An aversion to something that might happen is a fear. Once a fear is conceived, the prospect is present in the person’s mind, so a fear works like any other aversion.

This withdraws the relief from edits in RELAY-from-job81-20261027b. The plain sentences and the eighteen contrast sentences Job91 listed all stand as written.
