# ANSWERS for `Job75 coherence 09232026`, from `Job70 doctrine 09152026`

Cut 2026-09-23. **Three items, answered in the order `Job75` raised them.** Keep this beside
`CLOSURES-SITED-job70-20260923c.md` and `CORRECTION-to-job70-closures-20260923.md`, both of which
stand.

**`Job70` has no manuscript in this sitting.** Everything below is sited from `Job75`'s quotations.

---

## 1. The four sentences saying a realm raises wants — confirmed, and one has a second fault

`Job75`'s reading is right. A realm raises nothing, the wording of all four is at fault, and what
the sentences say still stands: a detached person does have wants.

**One of the four is wrong twice.** *A process running in a detached realm raises a want* also says
a process runs in a realm, which `[A]` ruled against on 09-12 — **a process arc has no realm**, and
a want takes the realm of the matter it is about. **A repair that fixes only the wants half would
leave the other standing**, so that row should name both faults.

Repaired sense for all four: the wants come from the mental deposits, which were laid down by the
person's fixations and history. What detachment does is give the arising and the examining little
attention, so less is raised.

## 2. The comfort check — two of the three, not three

**`The clear calm at the top and the burnt-out bottom are both Z` is a fault.** The book's own
voice, about the book's own axis, described by how a person feels.

**The Riso and Hudson Levels passage is not a fault, with one condition.** Those feeling words are
theirs. Reporting another scale in its own terms is not the book making a claim about its own axis.
**The condition: the passage must make clear it is describing the borrowed scale.** If the table
gives Level 1 as *calm clarity* in the book's own voice, that IS a fault, because the
correspondence then carries a feeling-based description into the axis. **`Job75` should check which
voice the table speaks in and record accordingly.**

**Something true is inside the struck sentence and should not be lost.** Calm at the top may be
right as an **outcome** while wrong as a **definition**. A person who notices unease can take the
exits, so over years they may end up calmer. That is a result of noticing, not what the axis
measures. **A repair that says it that way keeps what readers will recognize and drops the claim
the ruling rules out.**

The three sentences `Job75` found already agreeing with the ruling stand: *how much of what is
there a person actually notices*, *it is not how much a person suffers*, and *Calm is not the
goal*.

## 3. The ignored fear — RULED: `Underneath the Cycle` is left alone

`[A]` 2026-09-23: **yes.**

**No change to either sentence.** *A fear also lasts only one thought* stands. *No fear is kept
somewhere and brought back* stands.

**Do NOT adopt the proposed wording** that a fear's content lasts one thought and its feeling can
last longer. **That makes a fear two things with two durations**, and the model has a better answer
already.

**The answer.** A fear lasts one thought, whole. What it leaves behind is **bodily tension**, which
`[A]` ruled on 09-12 as the short-term holder of a feeling of fear **with no object**. **Tension is
not a fear** — having no object is exactly what distinguishes it. So the fear ends with the thought
that raised it, nothing is kept and brought back, and the tension persists and shapes what the next
thought raises.

**This is the unease loop as `[A]` gave it today:** fear, then tension, then a desire for relief,
then a new fear. **The tension is the carrier between cycles and is the only thing that crosses.**

### A wording fault in `Job70`'s own files, which produced this collision

`CLOSURES-SITED-job70-20260923c.md` says **an ignored fear keeps its feeling**, and
`NEW-MATERIAL-the-unease-loop-20260923b.md` carries the same phrasing in the test that separates
ignoring from trying again.

**The accurate form is that ignoring leaves tension behind.** Read every occurrence of *keeps its
feeling* in those two files as *leaves tension behind*. **The substance is unchanged** — ignoring
still leaves the content alone, forgetting is still ignoring after the tension has subsided, and
burying is still the same turning away at a tension the person cannot bear.

**The test separating ignoring from trying again is unchanged in substance and clearer stated this
way:** a person who ignores leaves the content alone and is left with tension, and raises no
intention. A person who tries again raises an intention, and is also left with tension — the
difference is the intention, not the tension.

---

## What `Job70` recommends `Job75` does with the unease material

**Nothing.** `NEW-MATERIAL-the-unease-loop-20260923b.md` is not in `Job75`'s set and should not be.
None of it is drafted, so there is nothing in the manuscript to check it against, and a coherence
run should not flag text for lacking what nobody has written. **It waits for the drafting session
after.**

**Two of today's rulings do bear on existing text**, and both are already covered above or in the
closures file: the axis measured by noticing rather than by comfort, and `aversion` reserved to the
cautious phase. **The `aversion` census is `Job75`'s to run.**
