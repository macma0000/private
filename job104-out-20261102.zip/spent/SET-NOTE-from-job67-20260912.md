# SET NOTE — from `Job67 doctrine 09122026`, 2026-09-12

## What arrived

One zip, `job66-out-20260912.zip`, directory `job67set`, verified against
`MANIFEST-job67-20260912.md`: **79 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the
manifest.** The screen fired twice and both are expected — `AUTHOR-RECORD.md` as CARRY DO NOT
READ, and `HANDOFF-20260906.md` quoting the restriction string. Both tools exempted themselves.

**This is a doctrine session and the record was not opened.** Its reach was checked with
`setcheck.py sweep`: 61,860 w, forty-seventh append, marker `Job66 coherence 09122026`, parent
60,946 — matching the manifest row and `Job66`'s set note. Chain clean.

**`[A]` named this session `Job67 doctrine 09122026` and the label says `Job67 20260912`.** The
counter and the date agree, and the kind is the one `Job66` recommended. **No manuscript was
touched**, so `BOOK2-20260912.md` is still 35,695 w, md5 `1065e37e`.

## What this session did

**All four items of `NOTE-doctrine-from-job66-20260912.md` are discharged, and fault 48 in
`REPAIRS-job66-20260912.md` is unblocked and closed.** Nine closures, twelve sites, in
`CLOSURES-SITED-job67-20260912.md`.

The whole session turned on one question: what a realm attaches to.

- **A realm is a kind of subject matter.** A process arc has no realm. A want or a fear has no
  realm of its own and takes the realm of the matter it is about. Where the matter lies on both
  sides there is no single realm. This supersedes the 08-19 closure and keeps its criterion.
- **`[A]` went further than the item asked**, questioning whether wants and fears carry realms at
  all, which is what produced the ruling above.
- **One fear, one arrival, both fixations acting at the same crossing** where the matter lies on
  both sides.
- **A person with one cautious realm is partly protected from burying a both-sides fear.** `[A]`
  accepted it and stated for the record that he does not claim cautious people fall faster.
- **The comparison between enthusiasm and caution is withdrawn** at three clauses. `[A]` had
  doubted it that morning; he supplied the reasoning that killed it and then stopped `[C]` from
  reversing it, which would have been the same fault in the other direction.
- **Most of a person's examined fears arise in their cautious realm**, and for a Type One that is
  the psychic realm.
- **No fear is ever lent between realms** — the routing question dissolves.
- **Ignoring arises independently of blindness.**
- **The basic fear is defined by position in the chain and by nothing else**, in `[A]`'s own
  phrase the least compounded fear in a type's chain.

## Two things a later session needs to see

**One ordering constraint, and it is not obvious.** `REPAIRS-job66-20260912.md` repair 2 replaces
*time* with *attention* at five sites. Its third site is Ch 15 *Which fixation handles a fear*,
and that sentence contains reasoning withdrawn by this session's fourth closure. **Applied first,
repair 2 would fix the words, leave the false reasoning, and leave a sentence that looks freshly
checked.** The withdrawals go first, or the two are applied together. Repairs 3, 4 and 5 and
repair 2's other four sites are independent of everything here.

**The handoff's record-reach line is six sessions stale, and nothing else can catch it.**
`HANDOFF-20260906.md` states the record at 41,888 words as measured 09-06. The record is now
63,458. That line exists as the only cross-check that can tell a live copy of the record from a
short one, because the file carries no date on its name and a stale copy is not wrong but short.
**Every session since `Job61` has appended without updating it.** Keeping it current would cost a
handoff letter per session, which is why nobody has. **This is a handoff session's job** and it is
recorded here so the next handoff does not have to rediscover it.

## Carried unruled

Three items, all `[A]`'s, none of them asked for, all in `CLOSURES-SITED-job67-20260912.md`:

- his phase mapping — the A fixation realm busy at the A phase, the B fixation realm at the B and
  Z phases — which would supply a mechanism for `Job66`'s shallow-crossing ruling and predicts a
  Three has the shallowest crossings of anyone
- his definition of noisy applied at the crossing, which is only as settled as the mapping
- **what settles a both-sides fear when the two fixations pull opposite ways** — the one thing the
  second closure opens without closing

`NOTE-doctrine-from-job61-20260909.md` and `NOTE-doctrine-from-job62-20260910.md` were not touched
and everything owed in them stays owed. The `Job62` item on a section making explicit the relation
between fixations, arc stages and single thoughts has now been open across four sessions.

## Files

Cut: `CLOSURES-SITED-job67-20260912.md`, this note. **No manuscript touched, and
`CLAIM-INVENTORY-book2-20260902.md` was not updated** — twelve sites change and several inventory
entries for the two Ch 15 sections will be wrong once the rows are applied, so a coherence run
after the drafting will want it regrown.

**Record: forty-eighth append, blind, head 63,458 w, parent 61,860.** Prefix verified
byte-identical at 364,642 bytes, md5 `b514534e` before and after, 60 markers, canonical bold
marker form so the sweep can read it.

## Recommendation for the next session, `[A]`'s to assert

**Drafting.** The backlog is now nineteen sites across three files — twelve closures here, seven
repairs in the two `Job65` and `Job66` files — and nothing in it is blocked on a ruling any more.
The two Ch 15 sections carrying nine of the twelve rows are the place to start, since they are
being rewritten rather than patched and the ordering constraint above applies to them.

A handoff session is also overdue: the handoff is from 09-06, seven sessions back, and the
record-reach line in it is wrong.
