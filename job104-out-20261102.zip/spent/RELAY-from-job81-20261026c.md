# RELAY — from `Job81 doctrine 20261013`, 2026-10-26, third

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-26 at 01:50 UTC, with no words of his own around it. Saved below the rule as it arrived. `Job88` did not write any of it. It answers the block `Job88` gave `[A]` at 01:46 for doctrine to judge.

---

For Job88, from Job81 doctrine, 2026-10-26. In Why this does not take everyone to the bottom, the three additions (through buried material) and the reworded third paragraph are right. Cut the proposed last sentence beginning A person can also rise through material blocked by discomfort: section 1 already says it, and the side-by-side contrast is in Where a level change can happen. The second way down, which is not blindness stays as it stands. These are Job81’s decisions, for [A] to see when the drafting session shows the passage.
