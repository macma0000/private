# RELAY — from `Job81 doctrine 20261013`, to `Job91 coherence 20261026`

Pasted by `[A]` into `Job91 coherence 20261026` on 2026-10-27 at 01:24 UTC, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job91` did not write any of it.

---

For Job91, from Job81 doctrine, 2026-10-27. On how to define want, fear, attraction and aversion, and where. [A]: i think “attraction” and “aversion” should be introduced when “wants” and “fears are. i’m unclear about how to define all these words. Then: fear, dislike and hatred are all aversion. liking and wanting are attraction. like and dislike are not volitional and not necessarily motivating. want and fear are clearly motivating. hatred involves volition. on the attraction side craving and coveting might be volitional. On a fear being about the future while other aversions are about the present: maybe a fear becomes an aversion once it is conceived. [A]: yes to Job81’s reading of that, and to the whole passage.
For Chapter 4, where wants and fears first appear:

* Attraction and aversion are the two directions in which a person can be drawn: toward something, or away from it.
* Some attractions and aversions are only felt. Liking and disliking are of this kind. They are not chosen, and they need not move the person to do anything.
* Others move the person. A want is an attraction that moves the person toward having something, or keeping it. An aversion can move a person too, away from something already here, such as a loud noise, or away from something that might happen. An aversion to something that might happen is a fear. Once a fear is conceived, the prospect is present in the person’s mind, so a fear works like any other aversion.
* Some attractions and aversions also involve the will: craving and coveting on the side of attraction, hatred on the side of aversion.
* Every fear has a want behind it. Behind the fear of losing a job is the want to keep the job.

Consequences, Job81’s decisions for [A] to see:

* In One thought, step by step, the definitions beginning A want is an attraction when the want is for something to arrive are replaced by a sentence recalling Chapter 4. A fear is one kind of aversion can stay.
* The Blocked entry’s opening keeps the aversion is turned away from, since aversion is now defined before it. Its later sentence the person’s aversion turns their attention elsewhere becomes the discomfort of the fear turns the person’s attention elsewhere, so that aversion has one role in the entry. Dislike is not used there, because dislike is now defined as not moving the person.
* The same four fates meet every aversion, not only a fear moves to directly after the opening sentence of The four fates, so the reader is told before the entries.
