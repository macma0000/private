# SET NOTE — from `Job57 coherence 09072026`, for the session that opens this set

**Cut 2026-09-07. Kind 12, the coherence check, third run of the kind.**

**Nine faults found and all nine ruled by `[A]` in the session.** Nothing was drafted. The claim
inventory is the session's one product; book 2, book 1 and every note are byte-identical to what
arrived.

---

## 1. What arrived, and what the checks said

Incoming zip `job56-out-20260907.zip`, one directory, verified against `MANIFEST-job57-20260907.md`:
**52 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.** Screen fired two, both
benign — the record as CARRY DO NOT READ, and the handoff for quoting the restriction string.

Record arrived **48,322 w, marker `Job56 drafting 09072026`, thirty-seventh append, parent
47,048** — matching `SET-NOTE-from-job56-20260907.md`, so the chain was clean.

**The set was again far larger than the kind 12 row.** The row names about ten files and 52
arrived. Four are the shape the row warns against — `CLOSURES-SITED-job32`,
`CLOSURES-SITED-job49-20260906c`, `DRAFTING-aligned-types-20260906b`,
`SKETCHES-rewrite-by-author-20260901b`. All four were left unopened, as in the second run.
**The row still does not name the claim inventory**, which is the file the kind cannot run
without. That is now two runs in a row.

---

## 2. WHAT THE SESSION LOOKED FOR

`Job56` handed over one class of fault and it is what the session was aimed at. The two stages
were ruled on 09-07 and the vocabulary pass ran the next day, so the surrounding prose was
written when seeing was one act. **A sentence that assumes the single stage while using neither
`take in` nor `notice` cannot be searched for.** The only way to it is a cold read, which is
what this kind is for.

**A count `[C]` reported and `[A]` corrected, and the correction is the lesson.** The first
finding was put at fifteen sites, and most of them were the ordinary verb `see` doing ordinary
work. `[A]`: *i thought we used "taken in" for detached realms and "see" only for its
conventional meaning.* **The test is not whether a sentence contains the word see. It is whether
a sentence makes the absence of pull the reason for the capacity to notice.**

---

## 3. THE NINE FAULTS

All nine are set out in the claim inventory with their rulings and their sites. In brief, and in
the order they were taken:

1. **The Five's obsession passage is the Four's, unrepaired.** The book calls them one structure
   seen twice; one was brought into line on 09-07 and the other was not.
2. **The lean changes noticing, not sight.** `[A]` corrected `[C]` here, and the correction is
   doctrine: what caution lends is motivation, so the lean moves how much noticing happens, and
   only blocking moves sight.
3. **Ch 4's width paragraph carries the cycle's ordering** three chapters before Ch 7 states it
   and two before Ch 6 says nothing has turned on it. Fault 19's class, reopened by new prose.
4. **Detachment's competence is named `see` at six sites**, four of them the italicised
   competence line that opens a sketch's detached realm.
5. **`What is seen is the same at either end of the range`** is false under the ruling, and it
   is the sentence that section rests on.
6. **Ch 4's clear face** gives the absence of pull as the reason for seeing, five paragraphs
   after the same chapter says it is the reason for the taking in.
7. **`clear` and `blind` are retired as names for detachment's two ends.** `[A]` raised this
   himself and settled it: the ends are the **caution end** and the **enthusiasm end**, `blind`
   is kept for the health axis alone, and *two faces* survives as the name for the thing before
   leans exist — **to be described rather than labelled**.
8. **Ch 7 says a person enters detachment on its blind side from enthusiasm**, which is the
   backward cycle the model retired. `[A]` caught this one and asked for a census; it is two
   sentences and nowhere else. Ch 15 and Ch 16 already carry the correct account.
9. **The Nine's block gives depth as the reason its two faces differ**, where the lean is what
   decides. Depth sets how much a Nine can bear once something has been taken up.

---

## 4. ONE PARAGRAPH IS OWED, AND ONLY ONE

`[A]` asked whether any of the new ideas needs a paragraph to itself. **One does: detachment has
no motivation of its own, and gets it from a neighbour.**

Ch 15 asserts a place for it and leaves it empty — *because the two orientations either side of
detachment are what produce them* — and never says by what means. The means is motivation. The
same claim answers fault 24 from the other side: a mixed type's detached realm draws its
noticing from the realm alongside it, and a Nine, having no such realm, draws it from the lean
alone. **Written once, it does the work at both.**

Three others were considered and fit inside sentences that already exist: the separation of
noticing from sight (Ch 17's two rate-setters already carry it), the forward route to the
enthusiasm end (inside Ch 7's two repaired sentences, with Ch 16 keeping the spoiled arrival),
and the Nine's two faces (inside the block's closing lines).

---

## 5. THE CLAIM INVENTORY

**19,495 → 23,010 w, same name kept deliberately**, following the second run's practice. The
name-per-revision rule is still unminted for this file; `[C]` recommends minting the exception
rather than renaming a survivor file at every check, and that recommendation is now two runs
old.

What changed in it: a new `UPDATED 2026-09-07` header stating the master and the scope; **ten
entries carrying `RE-READ 09-07`**; one section heading renamed with the retirement of
`register`; **faults 25 to 33 with their rulings and sites**; the paragraph owed; and a note on
fault 24 saying where it lands.

**What the pass did not do, stated on the file's face.** The per-entry sweep stopped at the
entries the two-stage doctrine touches. **An entry recording the old vocabulary is not stale,
because the text still carries it** — every repair is owed prose and none of it is written. A
later run re-reads those entries once the drafting session has run.

---

## 6. THE RECORD

**Thirty-eighth append, blind**, this kind not reading the record. Reach verified from the
marker before anything was written: 48,322 w, `Job56 drafting 09072026`, thirty-seventh append,
parent 47,048. Head is now **49,081 w, md5 `18e39395`**; the 286,237-byte prefix verified
byte-identical after the append, 50 markers where there were 49, and the marker is in the
canonical bold form the sweep can read.

---

## 7. RECOMMENDATION FOR THE NEXT SESSION

**Kind 11, drafting.** `[A]` raised it and `[C]` agrees. Everything settled this session is
prose owed and none of it is in the book.

**Order matters in one place.** Ch 4's two-faces paragraph is written first, because the Nine's
sketch and Ch 7 both now point back to a description rather than to the words `clear` and
`blind`. After that the naming change is mechanical and spans Ch 4, Ch 5, Ch 7, Ch 13, Ch 15 and
Ch 17; the other eight faults are local.

**The two crossings stay queued behind it**, as `SET-NOTE-from-job56-20260907.md` had them, and
the inventory now says where they land.
