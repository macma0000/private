# RELAY — from `Job81 doctrine 20261013`, to `Job91 coherence 20261026`

Pasted by `[A]` into `Job91 coherence 20261026` on 2026-10-28 at 01:08 UTC, preceded by his words *job81 says and i accept:*, including a status line from the chat interface. It answers `Job91`'s question whether a fear blocked by discomfort leaves a person seeing less. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job91` did not write any of it.

---

Working out how discomfort blocking affects perceived condition level.
It leaves the person noticing less, but not blind. That follows from what you’ve already ruled:

* It does take something away. You ruled that discomfort blocking takes a person down a level, a little at a time, as blind blocking does. And What actually descends says what moves on the axis is how much of their own condition they notice. So a fear blocked by discomfort lowers what the person notices.
* But it isn’t blindness. No blindness loop forms, and a matching fear can still be noticed and chosen about. What’s lost can come back.

So the fault is the word seeing, which the reader hears as a degree of blindness. Noticing is the axis’s own word, and it is true of both kinds. The two sentences would read:
Each fear turned away from until it is no longer noticed takes a little of the [noticing] with it.
Only blocking leaves a person [noticing] less than before.
What a level is made of then stands as written: a fear blocked by discomfort is no longer noticed but leaves no blindness, and blindness comes only from burial. The three passages agree. Blocking of either kind lowers noticing, and only burial adds blindness.
