# SET NOTE — from `job86 drafting 20261017`

This note goes to the session that receives `job86-out-20261019.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job87-20261019`.

## Arrival

`job85-out-20261018.zip` verified against `MANIFEST-job86-20261018.md`: **56 ok, 0 mismatched, 0 bad count, 0 missing,
145 not in the manifest**, all 145 in `spent/` and `superseded/`. The screen marked the record *carry, do not read*;
the 33 files it said to drop were all already in `superseded/`. The record's last marker matched `Job85`'s set note:
eighty-seventh append, 98,143 w. `[A]` named the session `job86 drafting 20261017`; the label's date is a day later.
Nothing turned on it.

## What was done

A drafting session on **`FINDINGS-job85-20261018.md`**. **Master out: `BOOK2-20261018.md`**, 43,060 w. Every change
was shown to `[A]` before and after, and every one carries his words. The rows are in **`CHANGES-job86-20261018.md`**.

- **All six findings applied.** Consequences reach a person at every depth, and *intervener* is now defined at its
  first use. Two things gather people in the middle. The habitual-fear paragraphs are rewritten in `Job81`'s wording
  and placed at the end of the unease-loop section. The blocking claim is replaced, with `[A]`'s verb change to
  *perceives the inability as a threat*. A third source of stress is in the fall, with a sentence `Job81` relayed
  during the session, which `[A]` approved. *Given up on* is now used for an aversion at four sites.
- **Not in the findings, ruled in session:** the last section of the falling-and-rising chapter. *what consequences no
  longer can* is gone. The author's voice is removed at `[A]`'s request. The lever figure is out, and the heading is
  now *Why trying harder does not change a person*. The chapter is now *Falling and Rising*. The two-ways-out paragraph
  is cut to its two sentences on help from outside, and *One thing is left unsolved.* is cut.
- **`WORD-RULINGS-book2-20261019.md`, letter `m`:** a `Job86` block in section 5a, three entries in section 7, the
  `consequences-unreach` pattern widened, and two patterns added (`lever`, `book-comment`). Each new pattern fires on
  the parent at this session's sites. On the new master, `lever` fires only on the Eight's literal *leverage*.
- **`STYLE-GUIDE-20261019.md`, letter `h`:** section 8's pointer names register letter `m`. There are two caught
  instances, one in section 1 and one in section 3.
- **Checks:** `wordcheck.py` against letter `l` shows the four `Job85` patterns at 0. The referring-word count was run
  on every changed sentence. Every row was read back in the file.

## The record

One append, blind: the **eighty-eighth**, `[A]`'s words verbatim with what each answered. The `Job81` relay is marked.
**Parent 98,143 w, head 98,902 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `FINDINGS-job85-20261018.md` (applied), `SET-NOTE-from-job85-20261018.md`.
- To `superseded/`: `BOOK2-20261017b.md`, `SUPERSEDED__live__WORD-RULINGS-book2-20261018.md`,
  `SUPERSEDED__live__STYLE-GUIDE-20261018.md`, `MANIFEST-job86-20261018.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be
  acted on until `[A]` says so.

## What is owed

- **A coherence run on `BOOK2-20261018.md`.** It should read the last section of the falling-and-rising chapter in
  full, since this session cut it down without a finding behind it. It should also bring the claim inventory up to
  date for the units this session changed. This session did not touch the inventory.
- **For a doctrine session:** whether the perceived inability to handle life bears on depth and threshold. That
  question is reserved for a session of its own. Also, the idea of *removing the need for a footing* is gone from the
  book; if `[A]` wants it, it needs doctrine first.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master, register letter `c` and style guide
  letter `d`. It needs a cut.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261018.md`**.
