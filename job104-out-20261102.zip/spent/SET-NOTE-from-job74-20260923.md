# SET NOTE — from `job74-drafting-20260919`

To the session receiving `job74-out-20260923.zip`. `[A]` gives the kind; the manifest label carries
the counter and date only.

## Arrival

Incoming zip `job73-out-20260919.zip`, verified against `MANIFEST-job74-20260919.md`: **53 ok, 0
mismatched, 0 bad count, 0 missing, 48 not in the manifest.** The 48 were the `spent/` and
`superseded/` folders, which Job73's note declared. The screen fired twice, both expected: the
record as `CARRY, DO NOT READ`, and the old handoff for quoting the restriction string. The record
arrived at 69,240 w, marker `Job73 handoff 20260919`, matching Job73's note.

**Four files arrived from `[A]` during the session, outside the zip**, and all four travel in this
set: a replacement `DRAFTING-INSTRUCTION-from-job72-20260916.md` (adding the ruling on where an
action comes), `CLOSURES-SITED-job70-20260916.md`, and two mid-session notes,
`NOTE-for-job74-from-job70-20260923.md` and `NOTE-for-job74-from-job70-20260923b.md`.

## What was done

The arc account is drafted into Ch 14 in one run, Ch 7 is cut back to the short version, and the
findings repairs and small word repairs are applied. `CHANGES-job74-20260923.md` is the full list.
Everything shown to `[A]` was shown with the sentences around it, and every edit was read back from
the file after writing.

**Three rulings of the session are in the register**, which took letter `b`: `crossing` retired in
favor of the detached phase, *how far* as the wording for the size of a lean, and a climb as the
retiring of buried fears. The phase split and the definition of an orientation are there too.

## What is owed

- **Ch 4's account of what moves a detached person.** The ruled-out reasoning is cut from Ch 4,
  Ch 5 and Ch 15, and nothing replaces it. `[A]` said `[C]`'s reading was wrong and that doctrine
  has an update, to be handled by a coherence run.
- **The answer to why a fixation does not turn over.** The question now opens Ch 15's
  mental-deposits section. The 08-25 ruling — the move made again is what lays it down — is the
  answer doctrine recommends, and no session has written it.
- **A collision to resolve.** The doctrine note says a detached person under stress stops taking in
  and disposing. Taking in is ruled unlimited, so this session wrote only *stops disposing of what
  arrives*.
- **`aversion`'s census.** The 09-23 ruling reserves the word to the cautious phase. This session
  added no new uses; the existing ones, including Ch 15's *an aversion meets an aversion to that
  aversion*, are for the coherence run.
- **`CLOSURES-SITED-job70-20260923b.md`** was held back from this session and goes to the coherence
  run, with the buddha ruling, where a detached person's action comes, and the tie between the lean
  and the standing dislike of disturbance.
- **The claim inventory is stale** in Ch 7, Ch 14, Ch 15, Ch 16 and Ch 17.
- **The style guide still has no letter** carrying the 09-09 withdrawal, and now also lacks the
  09-23 correction that prose is written too terse when it transcribes thought one for one.

## The set

- **New:** `BOOK2-20260923.md`, `WORD-RULINGS-book2-20260923.md`, `CHANGES-job74-20260923.md`,
  this note, `MANIFEST-job75-20260923.md`, and the four files `[A]` sent in session.
- **Moved to `superseded/`:** `BOOK2-20260915.md`, `WORD-RULINGS-book2-20260916.md` (as
  `SUPERSEDED__live__`), `MANIFEST-job74-20260919.md`.
- **Moved to `spent/`:** `SET-NOTE-from-job73-20260919.md`.
- **Unchanged:** the handoff, book 1, every note, the claim inventory, the style guide, the
  figures, the scripts.
- **`superseded/` and `spent/` travel outside the manifest**, and `setcheck.py verify` reports them
  as not in the manifest. That is expected, and this note declares them.
- **The screen fires three times, and every hit is expected:** the record as `CARRY, DO NOT READ`;
  the old handoff in `superseded/`, which quotes the restriction string; and the superseded register
  in `superseded/`, which fires on its `SUPERSEDED__live__` prefix alone.

## The record

**Two appends, both blind.** The first 408,295 bytes were verified byte-identical to the parent,
md5 `24171966`. `Job70`'s second-sitting block was appended first, verbatim, on `Job72`'s behalf:
fifty-fifth append, parent 69,240 w. This session's own block followed: **fifty-sixth append,
parent 69,658 w, head 70,645 w**, marker `job74-drafting-20260919`. `setcheck.py sweep` reads the
new marker.

## Next

`[C]`'s recommendation, `[A]`'s to assert: **a coherence run on `BOOK2-20260923.md`**. Ch 14 is new
whole, Ch 15 and Ch 16 changed at their doctrinal joins, and three items above wait on doctrine that
only a coherence run can site.
