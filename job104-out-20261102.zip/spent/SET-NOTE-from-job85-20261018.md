# SET NOTE — from `Job85 coherence 20261017`

This note goes to the session that receives `job85-out-20261018.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job86-20261018`.

## Arrival

The first zip was `job84-out-20261017.zip`. It verified against `MANIFEST-job85-20261017.md`: **56 ok, 0 mismatched,
0 bad count, 0 missing, 136 not in the manifest**. During the session `[A]` had `job84` make one more fix and sent
`job84-out-20261017b.zip`. It verified against `MANIFEST-job85-20261017b.md`: **56 ok, 0 mismatched, 0 bad count,
0 missing, 140 not in the manifest**, with four more files in `superseded/` for the letter-`b` move. The screen marked
the record *carry, do not read*, and every file it said to drop was in `superseded/`. The record's last marker matched
`Job84`'s set note at letter `b`: eighty-sixth append, 97,573 w. `Job85` did not read the record.

One small fault in the incoming letter-`b` set note: it still said it went to the session receiving
`job84-out-20261017.zip`, without the letter. Nothing turned on it.

## What was done

A coherence run on **`BOOK2-20261017b.md`**, which stays the master; this session wrote no book text.

- **The three rows `Job84` applied without a separate yes** were shown to `[A]` first. All three stand. The enthusiasm
  end stands as `Job84` fixed it at letter `b`.
- **Product: `FINDINGS-job85-20261018.md`**, six items, all ruled. Consequences reach a person at every depth. Two
  things gather people in the middle: the pain of staying, and the slowness of the fall. A habitual fear is caused by
  unease. The claim that a habitual fear grows past bearing and is blocked is cut. Perceiving the inability to handle
  life is a third source of stress in the fall. *Given up on* is used for an aversion meeting the fate. **`[A]` carried
  four relays from `Job81 doctrine 20261013`, and most of the wording in the file is `Job81`'s.** The findings mark
  which words are `[A]`'s.
- **`WORD-RULINGS-book2-20261018.md`, letter `l`.** A `Job85` block in section 5a. Four patterns are added
  (`consequences-unreach`, `habitual-source`, `stress-count`, `aversion-given-up`). Each fires on the master at the
  findings' sites and nowhere else. The entry *capacity to bear discomfort* no longer calls it the way out at the
  enthusiasm end.
- **`STYLE-GUIDE-20261018.md`, letter `g`.** Section 8's pointer names register letter `l`. Nothing else changed.
- **The claim inventory** has an update block of 2026-10-18, under its one name.

## The record

One append, blind: the **eighty-seventh**, `[A]`'s words verbatim with what each answered, and the `Job81` relays marked
second-hand. **Parent 97,573 w, head 98,143 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `CHANGES-job84-20261017b.md` (read by this run), `SET-NOTE-from-job84-20261017b.md`.
- To `superseded/`: `SUPERSEDED__live__WORD-RULINGS-book2-20261017b.md`, `SUPERSEDED__live__STYLE-GUIDE-20261017.md`,
  `MANIFEST-job85-20261017b.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be
  acted on until `[A]` says so.

## What is owed

- **A drafting session on `FINDINGS-job85-20261018.md`.** It reads the findings, register letter `l`, style guide
  letter `g` and the referring-word rule before writing.
- **For a doctrine session:** whether the perceived inability to handle life bears on depth and threshold. That
  question is reserved for a session of its own.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master, register letter `c` and style guide letter
  `d`. It needs a cut.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a drafting session on `FINDINGS-job85-20261018.md`**.
