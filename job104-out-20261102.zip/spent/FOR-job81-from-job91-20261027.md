For Job81, from Job91 coherence, 2026-10-27. On the wants for something to go. [A] agreed to relief from (RELAY-from-job81-20261027b) for the plain sentences, and asked that the sentences where wanting it gone is set against wanting it solved come to Job81 first. Job91 found them by search; each is quoted as the book has it.

Chapter 4:
* When a detached person simply wants the disturbance to go away, very little stays open to their noticing.
* Sometimes the person simply wants the disturbance to go away.
* The fear then moves on toward the enthusiasm end, where a person wants the fear to go away.

The Nine (Chapter 5):
* Or a Nine may simply want the fear to go away.
* A Nine can want to solve fears in the physical realm and want fears gone in the psychic, or the reverse.
* In the physical realm, wanting a fear gone fails in the plainest possible way, because nothing in the physical realm is altered by being ignored.
* In the psychic realm, wanting a fear gone fails oppositely, and less visibly.

The cycle chapter, The two faces of detachment:
* Nearer the enthusiasm end, the person simply wants the fear to go away, and turns away from the fear.

The fixations chapter, The range of detachment:
* When something does disturb a detached person, wanting peace pulls the noticing — toward what is disturbing the person, or toward getting away from it.
* The want is for the discomfort to be gone in general, rather than for one particular fear to be settled.
* A want for the discomfort to be gone is about nothing in particular, so while nothing is disturbing the person, the whole realm stays open to their noticing.
* What the person wants as a standing matter is still to be rid of the discomfort that fears leave behind. (ends the paragraph in which the person near the caution end wants to solve the trouble)
* A want to get away from discomfort is about nothing in particular, so while nothing is disturbing the person, the whole realm stays open to their noticing.
* The person wants the disturbance gone rather than solved.
* Wanting one thing gone leaves very little open to noticing, so a person near the enthusiasm end notices less at such a moment than anyone else does.
* What the person wants as a standing matter is still to get away from what is uncomfortable.

The fixations chapter, The unease loop:
* A detached person wants the unease gone, either by a distraction or by finding a potentially unconventional solution.

Going to drafting as plain sentences, with relief from: A pain raises the want to be rid of the pain. (One thought, step by step); A process started by a pain raises the want to be rid of the pain. (The range of detachment); Near the caution end what a person wants is to be rid of the discomfort that fears leave behind. (The range of detachment); the three unease-loop sentences on the want to be rid of the tension; The next thought raises the want to end the hurt (Action without a full thought).
