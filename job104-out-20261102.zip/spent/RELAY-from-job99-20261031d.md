For Job100, from Job99 doctrine, 2026-10-31, fourth relay. It follows RELAY-from-job99-20261031c.md. [A]'s words are verbatim, with the time of each message. Everything else is Job99's report.

1. PART 3'S OPENING (closures C3)

[A], 19:53, pasting Job100's change to the opening's last paragraph:
""the word" is fixations, but that was last mentioned two paragraphs earlier.
the next two sentences are each different major topics and don't make much sense in so short a form."

Job99 agreed with both points and proposed naming the word and giving each subject its own short paragraph. [A], 20:09: "does the idea that beginning, middle and end correspond to the three orientations need to go here? probably not for here, checking that we still have the correspondence as beginning=Z->A, middle=A->B, end=B->Z." Job99 answered that the correspondence does not need to go in the opening. It corrected its first new paragraph to say "phases" (see part 2 below). Asked "Is that what you want?", [A], 20:14: "yes".

The opening's last paragraph, and the two new paragraphs after it, as they now stand (new words in brackets, relative to BOOK2-20261029b.md):

Parts 1 and 2 described the orientations, the nine types they make, and how people of different types meet one another. None of that needed the word [fixation].

[Every thought a person has runs through three phases. In each realm, a person's attention is usually concentrated at one of the three phases. Where the attention is concentrated shows the person's fixation in that realm. So the characteristics of each fixation, and so of each type, show in how the fixation runs a thought.]

[People also differ in how deeply they are caught in their fixations. Riso and Hudson's Levels of Development serve as a measure of that depth. What moves a person down or up the Levels happens where a thought finishes. A person falls when a fear is turned away from there, and rises when a fear that was blocked is faced there.]

Going out: "What the chapters here take up is the limitation a person holds themselves inside: where the habit comes from, how deep it goes, and what holding it does to a person." Job100's two bracketed sentences are replaced.

One change Job99 made after his yes, and reported to him: the depth paragraph first said "happens at the end of a thought". After part 2, "the end" names the ending passage, and a burial is completed at the enthusiasm end of the detached phase. So the paragraph now says "happens where a thought finishes", which matches Chapter 14's "A thought finishes in the detached phase."

Every claim in the two paragraphs is already in the book: Where a fixation acts ("In each realm, a person's attention is usually concentrated at one phase."), the Health Axis chapter (the Levels "borrowed here and used as a measure of depth"), and Where a fear meets its fate (how deep a person has fallen changes only in the detached phase).

2. BEGINNING, MIDDLE AND END NAME THE PASSAGES (Underneath the Cycle, The phases and their names)

The book gives the plain words to the phases: "The beginning is the enthusiastic phase, the middle is the cautious phase, and the end is the detached phase." The sentence first appears in BOOK2-20260923.md, from the drafting of 09-19 to 09-23, and Job99 found no ruling of his on it. His rulings give the plain words to the transitions. On 08-21 he said: "saying the arc has a beginning middle and end is speaking of transitions, not states, that is beginning is Z->A, middle is A->B, end is B->Z". On 09-15 he ruled: "these are transition names, not phases" (FINDINGS-job72-20260915.md, section 4). He repeated the correspondence at 20:09 today and said "yes" at 20:14 to:

Every process runs a beginning, a middle and an end. [The beginning, the middle and the end are the three passages: the arising, the development and the ending.] The three phases are named after the three orientations.

Going out: "The beginning is the enthusiastic phase, the middle is the cautious phase, and the end is the detached phase."

This is the only sentence in BOOK2-20261029b.md that ties beginning, middle or end to a phase or a passage.
