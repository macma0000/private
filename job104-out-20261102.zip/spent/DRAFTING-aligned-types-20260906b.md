# DRAFTING INSTRUCTION — the aligned types, why one set of rules gets carried

**APPLIED 2026-09-06 by `Job50 drafting 09062026`, letter `b`; quarantine
`DRAFTING-aligned-types-20260906.md` as `SUPERSEDED__live__`.** All four sites are written into
`BOOK2-20260906.md`. The reason stands in the grid chapter only; the Three, the Six and the Nine
keep the missing contrast and lose the reason. **Nothing was written about the aligned types being
harder to help, or about resistance to change varying by type.**

*What this file said when it was cut, retained:* **Cut 2026-09-06 in `Job49 doctrine 09052026`,
after `Job50` raised a doubt.** This replaces
row 8 of `CLOSURES-SITED-job49-20260905.md`, which named the wrong reason.

**This is not a doctrine change to what the aligned types do.** Everything the four sites
claim about the consequence stands: one set of rules gets carried across both realms, and each
of the three sketches then shows that set failing in one realm. **Only the reason changes.**

---

## What is wrong with the drafted reason

All four sites say the aligned type has no internal contrast **to reveal that the realms
differ**. `[A]` doubted it and it does not hold.

**A mixed type cannot learn the realm distinction from their own experience either.** A Five is
cautious in the physical realm and detached in the psychic one, always. The orientation and the
realm vary together and never come apart. When things go differently in the two, the Five has
two candidate causes — the realms differ, or they behaved differently — and nothing in their own
experience separates them. The distinction is confounded for them.

**And the aligned type is the one running the experiment that would isolate it.** Holding the
move constant while the situation varies is what shows the situation up. The Nine steps back
from a leak and steps back from a quarrel, and the two come out differently. Same move, two
outcomes. If anyone were placed to notice that the realms differ, it is the aligned type. The
drafted reason has it backwards.

## The reason that holds

**A mixed type has watched themselves attend in two different ways. An aligned type never has.**

So the mixed type has interior evidence that their orientation is something they do, rather than
how things are. The aligned type has none. Their orientation has no contrast anywhere in their
experience, so it does not show up as a stance at all — it reads as reality.

That is what the mixed type intuitively knows and cannot say. Not that there are two realms.
That there is more than one way to meet a thing, because they have felt themselves do it.

**Why one set of rules follows.** A move that is invisible as a move has nothing to be applied
selectively. It is not chosen for a situation, so it does not vary with the situation, and it
goes everywhere. The consequence the three sketches already draw is unchanged.

**It uses only what is ruled.** A fixation is a standing preference about where attention is
directed, and attending is something a person does, not a place they stand — Chapter 4's closing
paragraph. What an aligned type lacks is the one thing that would make their own attending
visible as attending.

**RULED by `[A]` 2026-09-06,** put to him as a consequence and confirmed: an aligned type's
orientation is harder for them to see as an orientation.

---

## The four sites

The reason belongs in **one place only** — the grid chapter, where the aligned types are gathered
as a class. The three sketches keep the consequence and lose the reason.

| Site | What is there now | What to do |
|---|---|---|
| Grid chapter, `BOOK2-20260905.md` line 643 | *With the same orientation on both sides there is no internal contrast, nothing to reveal that the realms differ, and so one set of rules gets carried across both.* | **The reason goes here, and only here.** The clause *nothing to reveal that the realms differ* is what is false and is replaced. What replaces it: with no contrast between how they attend in one realm and how they attend in the other, an aligned person's own orientation never shows up as something they are doing. The consequence clause — *one set of rules gets carried across both* — stays. |
| The Three, line 445 | *There is no internal contrast to reveal that the realms differ at all. A person who is cautious in one realm and enthusiastic in the other has the difference presented to them daily, from inside. A person who is the same in both has nothing to compare, and the two collapse into one undifferentiated reality with one set of rules.* | **The middle sentence is the one to watch.** *Has the difference presented to them daily* is exactly the claim that fails — what a mixed type has presented daily is two ways of attending, not two realms. Rewrite so that what the mixed type meets daily is their own two ways of attending. The last sentence stands. |
| The Six, line 523 | *one fixation in both realms means no internal contrast, and so no occasion to discover that the realms run differently* | Cut *and so no occasion to discover that the realms run differently*. What follows — *What the Six therefore runs across both is a single threat logic* — follows from the missing contrast directly. |
| The Nine, line 601 | *no internal contrast — nothing to reveal that the realms differ. So one move answers everything: step back.* | Cut *nothing to reveal that the realms differ*. *So one move answers everything* already carries it. |

**Read all four together before writing any of them.** The same false clause appears in each,
and the point of the repair is that only one site carries a reason.

## Style constraints on the sentence

- **Positively.** *Being less caught does not supply the contrast* and *nothing reveals the
  realms differ* are both the shape `[A]` ruled against on 09-04 — the absence of the other
  thing instead of the thing.
- **Once.** The reason is stated in the grid chapter and nowhere else.
- **Do not give the orientation a person's properties.** *The orientation does not show itself*
  is the animate-verb rule. Say that the person never sees it.
- **One idea per sentence**, and do not make a later sentence depend on holding an earlier
  phrase in mind.

---

## Opened by this, and NOT to be written

`[A]` declined to extend the finding to how hard the aligned types are to help, on the ground
that **each type has its own style of resistance to change, so difficulty of help is not one
quantity.** That is a new claim and a large one. Nothing anywhere in either book describes
resistance to change as varying by type — the health axis carries what descends and what climbs,
and it carries it the same way for everyone. **Nine styles of resistance, none drafted.**

**Do not write anything about the aligned types being harder to help**, and do not write anything
about type-varying resistance. Both are recorded here so they are not lost, not so they are used.
