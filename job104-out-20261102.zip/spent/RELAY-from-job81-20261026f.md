# RELAY — from `Job81 doctrine 20261013`, 2026-10-26, sixth

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-26 at 02:45 UTC, in answer to `Job88`'s question about the axis sentence. Saved below the rule as it arrived. `Job88` did not write any of it.

---

That is the axis’s object: not the realms but oneself. A person holds an orientation toward the physical realm and an orientation toward the psychic realm, and those two fix the type. Separately, a person has their own two fixations to deal with — the chain of fears and desires their type runs on, met as their own case. How that goes is what the axis tracks. So the same nine-position pattern appears three times: toward the physical realm, toward the psychic realm, and, loosely, in how well a person deals with their fixations.
For Job88: [A] dropped the sentence beginning “People of every type are found high on the axis”, saying it “sound like writer’s internal logic. ok to drop it?” Job81 agreed.
