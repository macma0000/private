# SITED CLOSURES — `Job70 doctrine 09152026`, second sitting (2026-09-16)

Cut at `[A]`'s request for `Job72 coherence 09152026` to carry. Sixth instance of the file kind
`[A]` ruled 2026-08-30 — **site and claim, never the sentence.** A drafting session writes the
sentences.

**Not applied. Nothing in this file has been carried into any master.**

**This sitting worked from three files only:** `BRIEF-for-job70-from-job72-20260916.md`,
`ARC-ACCOUNT-from-job72-20260916.md` and `WORD-RULINGS-book2-20260916.md`. No manuscript and no
record were in hand, so **this sitting did not append the record** — the block at the end of this
file is for `Job72` to append, under the pattern `job34` set for a session appending on behalf of
one that could not.

**No word ruling was made**, so `WORD-RULINGS-book2-20260916.md` takes no new letter from this
sitting.

---

## Two corrections to this session's first sitting, owned

- **Closure 5 of `CLOSURES-SITED-job70-20260915.md`** marked the `attention` reading as not a
  ruling, then said a drafting session *may work from* it. That clause is what let `Job71` apply
  it. A reading a drafting session may work from is a ruling in practice. **No `[C]` reading in
  this file carries that licence.**
- **Closure 3's** *a Five looking with lent motivation has nothing directing the looking* was
  `[C]`'s sentence and is false (`[A]` 09-16). *Can notice what no fear pointed at* stands.

---

## What was ruled

**An action is placed by the motive behind it.** An action released by going toward something
comes at the enthusiastic phase. An action released by fending something off comes at the
cautious phase. **The same outward act can be either.**

This settles the question the brief carried — where in a thought cycle action happens — and
supersedes the three placements in use, as far as they place an action.

`[A]`'s words, in order:

> "the snapping would be another thought cycle where the desire to end the pain was decided, with
> the snapping occurring at the end of a truncated cycle." would that be the end of a B cycle since
> it's motivated by aversion?

> "desire to be rid of something an aversion" - i don't know. in my case it's definitely an
> aversion, but i have a B fixation. i could imagine an A fixation person thinking "wouldn't it be
> nice if i were rid of something". my guess is that both can happen. i think there is happy
> aggression and angry aggression. i've had experiences of people happily manipulating me.
> snapping, however, is clearly angry.

> record it and i'll give it the job72 coherence session.

**What follows from the ruling, in plain words.**

- **Aggression is not one kind of action.** Happy aggression — someone cheerfully manipulating
  another person — is going toward, so its action comes at the enthusiastic phase. Angry
  aggression is fending off, so its action comes at the cautious phase.
- **The angry remark in `[A]`'s truncated-cycle example comes at the cautious phase.** The examining
  happens there, and in a truncated cycle it is cut short by the remark being released instead.
  The ending follows at once with little to dispose of. *At the end of a truncated cycle* is this
  position — late in the cycle, where the examining would have been. `[A]` proposed the placement
  himself (*would that be the end of a B cycle*).
- **The wording of a desire does not decide where its action goes.** *To be rid of something* can
  be felt as fending off or as going toward, depending on the person. `[A]`: a person fixated in
  caution feels it as aversion; a person fixated in enthusiasm might feel it as *wouldn't it be
  nice*; *both can happen*.

---

## `[C]` readings — NOT ruled. Do not apply without asking `[A]`.

- **No action belongs to the detached phase.** Derived from the 09-16 ruling that a detached realm
  generates nothing. A person walking away for peace would be acting on a want for peace.
- **A cautious action is examining done in the world.** Examining a want asks what could go wrong;
  checking, securing and preparing do the same work outside thought. If so, the cautious phase does
  one job two ways, which answers `Job72`'s worry that it would do two jobs.
- **Ch 15's *if they act, the action begins a new arc inside the decision* is consistent** with the
  ruling as it stands: a decision can come at the ending, and the decided step's action is released
  in a later cycle.
- **The 08-25 gun example agrees.** That ruling placed the first urge at the enthusiastic phase;
  this one places the release. Buying a gun to be safe is fending off, so the buying comes at the
  cautious phase.

---

## The rows

| # | Site | What changes |
|---|---|---|
| 1 | `ARC-ACCOUNT-from-job72-20260916.md` §6, the truncated-cycle case — *the examining is cut short, and the action happens at the ending* | The angry remark's action comes at the cautious phase, where the examining is cut short. The account is not yet drafted anywhere, so the account itself is the site |
| 2 | The brief's §3 placement *at the ending* | Superseded by the ruling |
| 3 | Ch 4, enthusiasm's competence named as *doing* | **NO CHANGE** on this ruling. Doing toward something is the enthusiastic phase's. Whether Ch 4 should also name fending off as caution's kind of action is not ruled |
| 4 | The arc account §6 and the stress hypothesis's *I suspect* sentence, wherever drafted | **OPEN, see below.** Nothing to change until `[A]` rules |

---

## OPEN — carried

**Panic, and the stress hypothesis.** Panic is a truncated cycle (`[A]` 09-16) and is motivated by
aversion, so on this ruling panic's action comes at the cautious phase. The 09-15 stress hypothesis
described a panicking cautious person as *acting on an unexamined want*, which places the action at
the enthusiastic phase. **The two sit badly together.** One of them needs revising, and it is
`[A]`'s to say which. `[C]` raised it in session and deferred it deliberately.

---

## For `Job72` to append to the record

Append after the record's current last marker, blind or sighted as `Job72`'s kind allows. Name the
parent count from the marker `Job72` finds. Write the marker in the canonical bold form.

```
## 2026-09-16 · `Job70 doctrine 09152026` (second sitting), appended by `Job72 coherence 09152026`

**Provenance.** `[A]` returned to `Job70` on 2026-09-16 with a brief cut by `Job72`, for one
doctrine question: where in a thought cycle action happens. `Job70` held no manuscript and no
record in that sitting and could not append, so `Job72` appends it. Blockquotes are `[A]`'s typing
of the day, unedited. Everything else is `[C]`'s report.

`[C]` recommended `[A]`'s own suggestion of 09-16 — enthusiastic actions in the enthusiastic phase,
cautious actions in the cautious phase — and read the angry remark in his truncated-cycle example as
released at the enthusiastic phase. `[A]` asked what "the snap" was; `[C]` had shortened his
"snapping" without saying so, and had read it as snapping at someone in anger without marking that
reading as its own. `[A]` then asked:

> "the snapping would be another thought cycle where the desire to end the pain was decided, with
> the snapping occurring at the end of a truncated cycle." would that be the end of a B cycle since
> it's motivated by aversion?

`[C]` agreed and withdrew its placement, proposing that an action is placed by its motive: going
toward at the enthusiastic phase, fending off at the cautious phase. Asked whether a desire to be
rid of something counts as an aversion:

> "desire to be rid of something an aversion" - i don't know. in my case it's definitely an
> aversion, but i have a B fixation. i could imagine an A fixation person thinking "wouldn't it be
> nice if i were rid of something". my guess is that both can happen. i think there is happy
> aggression and angry aggression. i've had experiences of people happily manipulating me.
> snapping, however, is clearly angry.

Asked whether to record it as ruled:

> record it and i'll give it the job72 coherence session.

**Ruled: an action is placed by the motive behind it — going toward at the enthusiastic phase,
fending off at the cautious phase — and the same outward act can be either.** The angry remark
comes at the cautious phase, where the truncated cycle cuts the examining short. Carried open:
panic's action now comes at the cautious phase, which sits badly with the 09-15 stress hypothesis.
Sited in `CLOSURES-SITED-job70-20260916.md`.
```
