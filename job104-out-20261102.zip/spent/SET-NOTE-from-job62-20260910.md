# SET NOTE — from `Job62 drafting 09102026`, 2026-09-10

## What arrived, and the zip that had to be asked for

**Two zips.** The session opened on `job60-out-20260909.zip` — the set Job60 cut FOR Job61. It
verified clean (64 ok / 0 / 0 / 0 / 2 not in the manifest, the same two quarantined parents
Job61 reported) but carried **nothing from Job61 at all**: no repairs file, no doctrine note, no
record append, no set note. `[C]` reported that Job61's closing work appeared never to have run,
said the ten rulings were recoverable from the conversation, and asked whether a Job61 zip
existed. It did, and `[A]` uploaded it.

`job61-out-20260909.zip`, verified against `MANIFEST-job62-20260909.md`:
**67 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the manifest.** Screen fired once,
on the handoff quoting the restriction string. `AUTHOR-RECORD.md` fired CARRY DO NOT READ as it
should. Record arrived **55,730 w, forty-second append, marker `Job61 coherence 09092026`,
parent 53,036**, first 313,460 bytes byte-identical to Job61's arriving copy. Chain clean.

**Worth carrying forward as a practice point:** an arriving set that verifies clean can still be
the wrong set, and only its CONTENTS show it. Verification checks a set against its own manifest
and cannot tell you the manifest is the previous session's.

## What this session did

Kind 11, drafting, from `REPAIRS-job61-20260909.md`. **Every repair in that file is applied.**
Its two non-repair items — the three wants behind the basic fears, and the nine per-type
derivations — stay in the doctrine note, as that file directs.

**Thirteen further rulings came from `[A]` in session**, and five faults were found while
drafting that were on nobody's list. All are in `CHANGES-job62-20260910.md`. The largest are:

- **`part of the realm` is out** as the way to say what a want is about, and with it the
  inherited claim that wants are narrower than fears, which nobody had checked and which his own
  09-08 ruling contradicts.
- **A NEW ORDERING, four positions, his:** wanting a disturbance gone (narrowest), enthusiasm,
  caution, wanting to solve a disturbance (widest). **This supersedes Job61's repair for Ch 15's
  enthusiasm end.**
- **The conflation he named** — a detached realm was being written as though it had no wanting or
  fearing of its own. Four sites.
- **Burying is not automatic**; it happens only to a fear the person cannot bear. `[C]` had made
  it automatic in three sentences and he caught all three.
- **`caught` and `a detached realm` were never defined.** Both now are, `caught` at three places
  because the gaps between uses run over 4,000 words.

## Files cut

- **`BOOK2-20260910.md`** — 35,048 w, md5 `d5b02d58`, from 34,517 w and `87864a84`. 52 blocks
  changed: Ch 4 (11), Ch 5 (10), Ch 7 (1), Ch 10 (2), Ch 11 (1), Ch 15 (22), Ch 16 (3), Ch 17 (2).
- **`CHANGES-job62-20260910.md`** — what changed and why, in three sections: Job61's rulings
  applied, his rulings made in session, and what was found while drafting. Also lists three
  things owed to the later style job.
- **`NOTE-doctrine-from-job62-20260910.md`** — six new items from `[A]`, all his own material,
  none of it written into the book except where noted below. **A drafting session must not write
  from it.** It carries forward the whole of Job61's note, which is unaffected and is still the
  note to read first.
- **`AUTHOR-RECORD.md`** — forty-third append, below.

`CLAIM-INVENTORY-book2-20260902.md` is **unchanged and now stale**: it describes faults 34–43 as
open, and this session closed them. A coherence session will want to regrow it. The
different-bytes-different-name question on that file is still unruled, fourth run running.

## One item of new doctrine DID reach the prose

`[A]` ruled that fixations may be **partially** determined by biological tendency. Ch 15's
fixation paragraph now carries it in the one hedged sentence he gave. Before the repair the
paragraph said a fixation simply IS a choice that has sunk below deciding, which is a larger
claim than he holds. The book says nothing else anywhere about biology. It is in the doctrine
note for ruling, together with his free-choice item, a biological share being one form of
determined-in-advance.

## Held for doctrine, deliberately not drafted

`[A]` raised his Z+ material mid-session and said himself to hold it until the drafting was done
(*"it might be better to hold off processing it until you finish your current work"*). `[C]`
reordered the remaining work so the enthusiasm-end paragraphs came last, and took the material
after the rest was finished. **None of it is in the prose.** It is items 1 to 3 of the doctrine
note: passage into Z+ as forgetting; the dropping loop as distinct from the blindness loop, with
his childhood case; and three stores rather than two, with bodily tension separated out.

**Item 1 carries a repair owed if it is ruled:** Ch 11's Z+ paragraph says the weighing *does
happen* and is brief. If passage into Z+ is usually forgetting, the weighing is absent rather
than short.

## Record

**FORTY-THIRD APPEND, blind** — this kind does not read the record. Head is now **58,114 w,
md5 `10d9ddd0`**, marker `2026-09-10 · Job62 drafting 09102026`, parent 55,730 named in the
block. **55 markers** where there were 54; canonical bold marker form, so the sweep can read it.
The append quotes `[A]`'s typed words throughout and marks everything else as `[C]`'s report.

## Recurring defect, fifth run running

**The handoff's kind 11 row still does not match the set.** Same shape as the kind 12 row Job61,
Job59 and Job57 reported. A handoff session should fix the rows from the last five set notes
rather than each session recording it again.

## What `[C]` recommends next — `[A]`'s to assert

**Kind 13, doctrine.** Six new items are waiting, three of them his Z+ material, and one of them
(the biological share) is already in the prose in hedged form and wants ruling. The doctrine note
also still carries Job61's nine per-type derivations untested. A coherence run would find the
claim inventory stale; a drafting run has nothing ruled left to write.
