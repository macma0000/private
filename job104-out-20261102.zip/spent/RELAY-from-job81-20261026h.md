# RELAY — from `Job81 doctrine 20261013`, to `Job89 coherence 20261026`

Pasted by `[A]` into `Job89 coherence 20261026` on 2026-10-26 at 14:55 UTC, with no words of his own around it. It is a stretch of the `Job81` chat: `[A]`'s answer to `Job89`'s question about burial, `Job81`'s reply, the block for `Job89`, `[A]`'s question how the expansion material should be passed on, and `Job81`'s answer. Saved below the rule as it arrived, including two repeated status lines from the chat interface, except that the interface may have turned list markers into `*`. `Job89` did not write any of it.

---

yes. and that implies and explains that the area of blind blocking can continuously expand.
Working through the psychology of avoidance and expanding blind spots.
Working through the psychology of avoidance and expanding blind spots.
Recorded: yes. And the expansion follows directly. If the turning away comes sooner each time, it also catches fears that are further from the first one, which only lead toward the matter. The book already says the result in two places, but not the reason:

* So the number of things a person turns away from grows over time.
* So the part of a person’s world that can still be approached shrinks with every burial.

Your point supplies the reason, so it belongs at the end of the fixations-chapter paragraph:
As the turning away comes sooner, it also reaches further: fears that only lead toward the matter are turned away from as well. So what is blindly blocked can keep growing.
A block for Job89:
For Job89, from Job81 doctrine, 2026-10-26. On the contradiction between the Blocked entry (burial all at once) and the paragraph opening What previous thoughts have laid down (burying develops gradually). Job81 separated one fear from the history of a matter: each fear blindly blocked is buried all at once, in panic, and what develops gradually is how soon the turning away comes. [A]: yes. and that implies and explains that the area of blind blocking can continuously expand.
Proposed for the drafting session to show [A], in that paragraph:

* at first most of the fears are noticed before being turned away from becomes at first a fear may be glimpsed before panic turns the person away from it.
* At the end of the paragraph: As the turning away comes sooner, it also reaches further: fears that only lead toward the matter are turned away from as well. So what is blindly blocked can keep growing.

The Blocked entry stays as it is.
how should the new expansion material be passed on?
Working out how to hand off expansion material between sessions.
Working out how to hand off expansion material between sessions.
Through Job89, the same way as the rest of today’s rulings. Give Job89 the last block I wrote, the one that begins On the contradiction between the Blocked entry…. It holds the expansion ruling in your words and the proposed sentence. Job89 records your words and passes the finding to the next drafting session. That session then shows you the sentence in place before applying it.
The block should also carry one note, so the drafting session doesn’t say the same thing three times:
The book already states the result in two places: So the number of things a person turns away from grows over time (after the blindness-loop paragraph), and So the part of a person’s world that can still be approached shrinks with every burial (in What a level is made of). The new sentence gives the reason. Check whether either earlier sentence should point to it, or be cut.
