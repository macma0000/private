# DRAFTING INSTRUCTION — from `Job72 coherence 09152026`

Cut 2026-09-16 for the drafting session that follows the handoff session. Everything here was
settled with `[A]` on 2026-09-16. This file says what to build, in what order, and what not to do.

## Read these first, before writing any prose

1. `WORD-RULINGS-book2-20260916.md` — the register of standing word rulings.
2. `STYLE-GUIDE-20260908b.md` and `RULE-referring-words-20260908b.md`.
3. `ARC-ACCOUNT-from-job72-20260916.md` — `[A]`'s new account, settled in full.
4. `FINDINGS-job72-20260915.md` — sixteen items, each sited by content.
5. `CLOSURES-SITED-job70-20260916.md` — the ruling on where action happens.

**Apply only what is marked as `[A]`'s ruling.** Anything marked `[C]` is a Claude reading and is
not authority to change the book; ask him. Job71 applied an unruled reading and reversed a ruling
of his, which is why the register exists.

## The placement ruling, 2026-09-16

`[A]` asked whether the new material would end up contiguous. It would have been spread over Ch 7,
Ch 14 and Ch 15. He approved this placement:

- **Ch 14 takes the whole account of cycles, arcs and where a fixation acts**, in one run. Ch 14 is
  already the chapter underneath the cycle, and it sits in Part 3, so it may say `fixation`.
- **Ch 7 keeps a short version only** — a process makes three passages, processes come in sizes, a
  thought is the smallest. No arcs built out of cycles there, no deposits, no `fixation`.
- **Ch 15 keeps the four fates and the mental deposits** where they are. Ch 14 refers to them as
  what an ending does and does not restate them.

## Order of work

### A. Ch 14, built in one run

Write the account in this order. The content is in `ARC-ACCOUNT-from-job72-20260916.md`; this is
the running order `[A]` approved.

1. **What a passage is.** The move from one phase to the next. The arising: detached phase to
   enthusiastic phase. The development: enthusiastic phase to cautious phase. The ending: cautious
   phase to detached phase. No letters. No second names — `impulse`, `examination` and
   `resolution` are not names for anything.
2. **One thought cycle, step by step.** A desire appears at the arising, or a pain or pleasure
   starts the cycle. The person examines the desire at the development, and examining raises an
   aversion where the examination finds trouble. The aversion meets its fate at the ending.
3. **What a cycle leaves.** Ch 14 already says a resolution finishes a process and that nothing
   crosses. Keep both sentences. Add what does happen: what a thought was carrying is laid down,
   and the next thought arises out of what previous thoughts laid down.
4. **A long desire.** Not one desire lasting. Nearly the same desire is raised again and again out
   of what the last cycle left. A person pursuing something for a month raises that desire many
   times a minute. The run ends when the desire stops being raised.
5. **A fear.** Lasts one cycle. A fear that returns is raised again out of the deposits and out of
   the problem, which still stands. Ignored: the problem is unsolved, so the fear is raised again
   from the problem. Blocked: the deposits are shaped by the burial, so later cycles raise fears
   shaped by it even after the problem is gone.
6. **Disappointment.** Two cases, and the cautious phase takes both: the examination judges the
   desire cannot be met; or the person meets an outcome that did not meet it, which is a pain and
   starts a new cycle. What becomes of a failure depends on where attention is concentrated —
   a new plan at the enthusiastic phase, disappointment at the cautious phase, denial at the
   enthusiasm end of the detached phase. Ch 4's paragraph on what people do when something goes
   wrong already says this; Ch 14 sites it in the cycle rather than repeating it.
7. **Reflex, truncated cycle, cycle fully lived.** A reflex has no thought cycle. A truncated cycle
   has the examining cut short. Panic is a truncated cycle, because a judgement is made. Never write
   that a phase is skipped. Where the action comes is placed by its motive — see the section on
   action below.
8. **Where a fixation acts.** A fixation is attention concentrated at one phase, so a fixation acts
   in every cycle and at every size. Enthusiastic: much at the arising, cursory examining, little
   raised and little settled. Cautious: heavy examining, many aversions raised, most settled before
   the ending. Detached: little at either, generating nothing, wanting peace, and the lean decides
   whether what arrives is processed or ignored.

### B. Ch 7, cut back to the short version

Keep the three sizes and the definition of scale. Rewrite `The smallest scale` to say, one idea per
sentence: a thought is best described by the passages it makes; a passage is the move from one
phase to the next; the three phases are the same three places on the cycle as the three
orientations. Cut *In a lived process the arising is enthusiastic, the development cautious, the
ending detached*. Do not write `fixation` anywhere in Ch 7. Add the two sentences `[A]` approved
about an arc having no exact beginning or end, because what marks an arc is that nearly the same
desire keeps being raised.

### C. The sited repairs from the findings

Work through `FINDINGS-job72-20260915.md` in its own order. The larger ones:

- `attention` restored at every `dwell` site in Ch 15 and Ch 17, and the `how long` wording with
  them. Ch 2's quoted line keeps `dwell`.
- Ch 4's paragraph on what moves a detached person, with the lean named and defined there.
- Ch 5's opening and Ch 15's `The range of detachment`, where *whatever orientation a person holds*
  goes.
- Ch 5's Type 5, Type 2, Type 4, Type 6 and Type 9 sentences.
- Ch 13's `The imaginary self`, reordered exactly as `[A]` approved it.
- Ch 15's `The hinge`, `Two channels`, `What previous thoughts have laid down` and `Why it does not
  turn over`.

### D. The small word repairs

`lent` → `supplied` at five sites. `keeping off` → `trying to avoid`. The verb `loops` replaced
with the person as subject. `judgement` → `judgment` at four places. `orientation` → `attitude` at
two places in Ch 2. `or quietly see it` → `or watch it without doing either`.

### E. Before closing

1. `python3 wordcheck.py BOOK2-<new date>.md` and read every hit.
2. `python3 refcount.py` over what was written.
3. Any new word ruling `[A]` gives goes into the register **in this session**, and the register
   takes a letter.
4. Cut a changes file and a set note, append to the record, regenerate the manifest.

## Where in a cycle action happens — RULED 2026-09-16 in `Job70 doctrine 09152026`

The question was taken to a doctrine sitting after this file was first cut. Its output is
`CLOSURES-SITED-job70-20260916.md`; add that file to this session's set and read it. **The ruling:**

**An action is placed by the motive behind it.** An action released by going toward something comes
at the enthusiastic phase. An action released by fending something off comes at the cautious phase.
The same outward act can be either. `[A]`: *i think there is happy aggression and angry aggression
… snapping, however, is clearly angry.*

**What the drafting session writes on it:**
- In Ch 14's truncated-cycle case, the angry remark comes at the cautious phase, where the
  examining is cut short. **This overrides `ARC-ACCOUNT-from-job72-20260916.md` §6**, which says the
  action happens at the ending. Do not write *at the ending*.
- Ch 4's naming of *doing* as enthusiasm's competence is **left unchanged**.
- Ch 15's *if they act, the action begins a new arc inside the decision* is **left unchanged**.

**What the drafting session does NOT write:**
- The four `[C]` readings in the closures file — no action at the detached phase; a cautious action
  as examining done in the world; Ch 15's sentence as consistent; the gun example. None is ruled.
- **Panic's placement.** Panic is a truncated cycle driven by aversion, so on this ruling its action
  comes at the cautious phase. The 09-15 stress hypothesis says a panicking cautious person acts *on
  an unexamined want*. The two disagree and `[A]` has not said which gives way. **Write panic only
  as a truncated cycle, and leave the stress hypothesis's sentence as it stands.**

## The record: one block to append on behalf of `Job70`

`CLOSURES-SITED-job70-20260916.md` ends with a record block under *For `Job72` to append to the
record*. `Job72` could not append it: its set had already gone out, and the record now travels with
this session's set. **This session appends that block, verbatim, after the record's current last
marker and before its own session block**, with the marker in the canonical bold form and the parent
count taken from the marker it finds. Say in its own block that it appended `Job70`'s on `Job72`'s
behalf.

## What not to do

- Do not write the phase mapping (which realm is busy in which phase) as doctrine. It is `[A]`'s,
  carried unruled since 09-12.
- Do not use `aversion` beyond the sites the register names: where disappointment is introduced and
  where the four fates are stated. `fear` and `want` stay the working words.
- Do not write that a phase is skipped.
- Do not place panic's action, and do not apply the `[C]` readings in `CLOSURES-SITED-job70-20260916.md`.
- Do not introduce `attraction` as a second name for `want`.
- Do not use `fixation` before Part 3.
- Do not restore the idea of one attention divided between the two realms.
