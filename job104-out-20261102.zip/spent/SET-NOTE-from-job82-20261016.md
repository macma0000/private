# SET NOTE — from `Job82 drafting 20261015`

This note goes to the session that receives `job82-out-20261016.zip`. `[A]` gives the kind of session. The
manifest label carries only the counter and the date: `job83-20261016`.

## Arrival

The incoming zip was `job81-out-20261015d.zip`. It verified against `MANIFEST-job82-20261015d.md`: **57 ok,
0 mismatched, 0 bad count, 0 missing, 119 not in the manifest** (`spent/` and `superseded/`). The screen fired on
the names in `superseded/` and on the record (*carry, do not read*). The record's last marker matched `Job81`'s
set note: seventy-fourth append, 92,429 w. **One fault:** the command `Job82` used to print that marker also
printed the record's last 1,500 characters (end of the seventy-third append and the seventy-fourth). Both were
already in the closures file. `Job82` read nothing else of the record.

## What was done

The drafting session from `CLOSURES-SITED-job81-20261014d.md`, step 3 of the order `[A]` agreed on 10-12.
`Job81` sat with `[A]` in parallel and `[A]` relayed its rulings into this session. **Every change was shown to
`[A]` and carries his answer.** The list is `CHANGES-job82-20261016.md`.

- **Product: `BOOK2-20261016.md`**, md5 `7612914c`, 42,986 w, 1,835 lines. Parent `BOOK2-20261013.md` (`572d83bb`).
- Working through re-cut; bodily tension after every fate; a disappointment's four fates.
- **New section *The unease loop*** in Ch 15 after *Blocking is not a decision*, built part by part.
- **New section *Gratification*** in Ch 14 after *Disappointment* — placed by `Job81` on `[A]`'s *stand on its own*,
  superseding the closures' placement of Part G.
- *Rising*: a buried fear's return qualified; trained abiding; fear closes the intuition route; the ways out.
- **New doctrine from `[A]` in this session**: the pain of facing buried material is *imagined to be unbearable*,
  for all buried pain; on their own people face it only when staying is unbearable; help or trained abiding brings
  facing sooner. Written into *Rising* and the two-pains paragraph (the latter in `[A]`'s own words).
- **`STYLE-GUIDE-20261016.md`, letter `e`** — the metaphor section. **`WORD-RULINGS-book2-20261016.md`, letter `i`.**

## The record

Nine appends, all blind: the seventy-fifth to eighty-second carry `[A]`'s relays from `Job81` and his rulings to
`Job82` as they came; the **eighty-third** is the session's closing block. **Parent 92,429 w, head 95,915 w.** Each
parent was checked unchanged at its join.

## Moved

- To `spent/`: `CLOSURES-SITED-job81-20261014d.md` (discharged), `SET-NOTE-from-job81-20261015d.md`,
  `CHANGES-job80-20261013.md` (superseded in substance by `Job82`'s file; no coherence run read it).
- To `superseded/`: `BOOK2-20261013.md`, `SUPERSEDED__live__STYLE-GUIDE-20261005b.md`,
  `SUPERSEDED__live__WORD-RULINGS-book2-20261013.md`, `MANIFEST-job82-20261015d.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to
  be acted on until `[A]` says so.

## What is owed

- **Step 4 of the agreed order: a coherence run** on `BOOK2-20261016.md`. `CHANGES-job82-20261016.md` names what to
  read first: every site weighing the pain of facing against the pain of staying, now that the facing side is a
  fear of a pain imagined to be unbearable.
- **The claim inventory** has no entries for *The unease loop*, *Gratification*, or Ch 14's eight older sections.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master, register letter `c` and style guide letter
  `d`. Live now: master `BOOK2-20261016.md`, register letter `i`, style guide letter `e`. It needs a cut.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation, following the order `[A]` agreed: **a coherence run on `BOOK2-20261016.md`.**
