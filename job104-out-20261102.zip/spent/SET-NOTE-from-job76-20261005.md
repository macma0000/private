# SET NOTE — from `Job76 drafting 20261005`

This note goes to the session that receives `job76-out-20261006.zip`. `[A]` gives the kind of
session. The manifest label carries only the counter and the date.

## Arrival

The incoming zip was `job75-out-20261005c.zip`. It verified against `MANIFEST-job76-20261005c.md`:
**54 ok, 0 mismatched, 0 bad count, 0 missing, 78 not in the manifest.** The 78 were the `spent/`
and `superseded/` folders, which the note declared. The screen fired on the record as `CARRY, DO NOT
READ`, and on eight `SUPERSEDED__live__` files. Every hit was expected. Outgoing, the screen fires on
nine, the new one being the register's letter `c`. The record arrived at 73,080
words with the sixtieth-append marker, which matches the handoff.

## What was done

**Every change Job75's findings called for was drafted, shown to `[A]` and approved.** That covers
all sixteen rows and the six faults. Also done: four sites the findings did not list, a sweep of
`settled`, and the work that came out of eleven new rulings from `[A]`. `Job70 doctrine 09152026`
took part through `[A]`, who carried drafts and comments between the two sessions. Where `Job70` was
wrong, `[A]` was shown why before anything was written. `CHANGES-job76-20261005.md` is the full list.
After writing, all 52 edits were read back from the master.

## What is in the set that is new

- **`BOOK2-20261005.md`**, 39,839 w, 1,721 lines. This is the master now.
- **`WORD-RULINGS-book2-20261005b.md`**, letter `d`. It adds `settled` / *meets its fate*, `arhat`
  replacing `buddha`, `disturbance` and *the discomfort that fear leaves behind*, *prolong* at one
  site, and the withdrawal of `fear of looking`. There is a new `wordcheck.py` pattern for `settle`,
  and `arhat` is added to the `buddha` pattern.
- **`CHANGES-job76-20261005.md`**.
- **This note** and **`MANIFEST-job77-20261006.md`**.

## Moved

- To `superseded/`: `BOOK2-20260923.md`, `SUPERSEDED__live__WORD-RULINGS-book2-20261005.md`, and
  `MANIFEST-job76-20261005c.md`.
- To `spent/`: `SET-NOTE-from-job75-20261005.md`.
- **`FINDINGS-job75-20261005.md` stays live** for its Part Four, which is still open for doctrine.
  Its Parts One to Three are discharged. Its 30 blockquotes are of the superseded master, so `quotecheck.py sweep`
  reports them as orphans. Against `superseded/BOOK2-20260923.md` they verify: 30 verified, 0 failed.
- **The handoff, the style guide and the arc account are unchanged.** The handoff still names
  register letter `c`. Read letter `d`.

## The record

One append was made, blind. The parent's 431,885 bytes were checked and are byte-identical after
writing. **Sixty-first append, parent 73,080 w, head 73,632 w**, marker `Job76 drafting 20261005`.

## What is owed

- **A coherence run on `BOOK2-20261005.md`.** Ch 14, Ch 15 and Ch 17 changed a lot. The changes file
  lists what this session left alone and why. On top of that list:
  - sorting `disturbance` into its two senses, which `[A]` deferred to coherence;
  - claim-inventory entries for Ch 14;
  - a re-read of Ch 15 and Ch 17.
- **Open for doctrine:** the findings' Part Four, and the unease material.
- **The writer 2 pass** is still needed, and is still waiting on Toby Marshall.

## Next

`[C]`'s recommendation, for `[A]` to decide: **a coherence run on `BOOK2-20261005.md`.**
