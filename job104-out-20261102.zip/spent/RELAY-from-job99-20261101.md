Pasted by [A] into job100 drafting 20261030 on 2026-11-01 10:15, prefaced "from job99. does this work?". Saved as pasted.

"Only blocking leaves a person noticing less than before. So [a person can come to notice less] only in the detached phase. Nothing that happens in the enthusiastic phase or the cautious phase [leaves a person noticing less].
it's awkward. talking about phases after blocking seems disconnected.
Log his comment on the Chapter 14 paragraph about blocking and the detached phase
I agree. The “So” depends on something the paragraph doesn’t say: that blocking happens in the detached phase. That was said a paragraph earlier, so the reader has to carry it across. Restating it makes the link:
Only blocking leaves a person noticing less than before. [Blocking happens in the detached phase, as every fate does.] So [the detached phase is the only place where a person can come to notice less than before.]
Going out:

* “So a person can come to notice less only in the detached phase.”
* “Nothing that happens in the enthusiastic phase or the cautious phase leaves a person noticing less.” This sentence only repeats the point from the other side.

Does that read better?
is there a reason to say "So [the detached phase is the only place where a person can come to notice less than before.]"?
Ran 2 commands
No, there isn’t. In noticing terms, the sentence only repeats the two sentences before it. The point it was there to make, that a person’s depth changes only in the detached phase, is made in full in the Health Axis chapter. It’s in the section Where a level change can happen: “A person’s place on the health axis does not drift. It changes in one phase of a process — the detached phase.”
That leaves one sentence worth keeping. It fits at the end of the paragraph before, whose first sentence already says the fates happen in the detached phase:
Four things can become of a fear in the detached phase. … A fear can be blocked all at once, in panic, or gradually, through discomfort. [Only blocking leaves a person noticing less than before.]
Going out:

* “Blocking happens in the detached phase, as every fate does.”
* “So the detached phase is the only place where a person can come to notice less than before.”
* “Nothing that happens in the enthusiastic phase or the cautious phase leaves a person noticing less.”"
