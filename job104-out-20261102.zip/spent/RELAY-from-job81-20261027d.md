# RELAY — from `Job81 doctrine 20261013`, to `Job91 coherence 20261026`

Pasted by `[A]` into `Job91 coherence 20261026` on 2026-10-27 at 01:51 UTC, with no words of his own around it (his words are inside it). It answers `Job91`'s check that *A want is an attraction* conflicts with wanting something gone, and replaces the Chapter 4 passage in `RELAY-from-job81-20261027.md` and `-20261027c.md`. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job91` did not write any of it.

---

For Job91, from Job81 doctrine, 2026-10-27. This replaces the Chapter 4 passage in the earlier blocks today. On Job91’s check that a want is an attraction conflicts with wanting something gone, [A] asked: is a desire an attraction or an attraction a desire? the former would solve the wanting something gone as attraction, but the latter sounds more like normal usage. Job81 proposed that an attraction or an aversion is the pull, and a want is what moves the person, raised from either side. [A]: good. so a want can arise from an aversion or an attraction. and a fear can arise from attraction as well as an aversion. a fear arising from attraction is a real thing. [A]: yes to:

* Attraction and aversion are the two directions in which a person can be drawn: toward something, or away from it.
* Some attractions and aversions are only felt. Liking and disliking are of this kind. They are not chosen, and they need not move the person to do anything.
* A want is what moves a person to bring something about: to have something, to keep it, or to be rid of it. An attraction can raise a want to have something or to keep it. An aversion can raise a want to be rid of something.
* A fear is an aversion to something that might happen, such as losing a job or spilling a cup of coffee. A fear can arise from an attraction, as the fear of losing someone arises from being drawn to them. A fear can also arise from an aversion, as the fear that a pain will return arises from disliking the pain. A fear moves the person to keep the feared thing from happening. Once a fear is conceived, the prospect is present in the person’s mind, so a fear works like any other aversion.
* Some attractions and aversions also involve the will: craving and coveting on the side of attraction, hatred on the side of aversion.
* Every fear has a want behind it. Behind the fear of losing a job is the want to keep the job.

All want … gone and want to be rid of sentences stand as written. One thing for the drafting session to check: the Levels chapter uses desire for what the chain produces. [A] used desire and want as the same thing here, so under the one-name rule the book should either use want there or say once that a desire is a want.
