# RELAY — from `Job81 doctrine 20261013`, 2026-10-26, fifth

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-26 at 02:39 UTC, with no words of his own around it. It is `Job81`'s reply to the block `Job88` gave `[A]` at 02:37, followed by `Job81`'s line for `Job88`. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job88` did not write any of it. *you ruled today* is `Job81` addressing `[A]`; the ruling it names is `Job81`'s decision relayed at 02:03 (fourth relay).

---

Yes, it should name both. The arrangement is everything blocked, and you ruled today that the top needs both kinds retired. If this paragraph named only buried fears, it would say that undoing them is enough.
I’d make the opening clause general and then give each kind its own sentence, so the reader sees how recognition comes about in each case:
What undoes it is conscious recognition of the blocked fears — bringing back into view what was kept out of view, one at a time. A fear blocked by discomfort can be recognized when a matching fear is noticed and the person chooses to look at it. Each buried fear can be recognized only after the fear of looking at the buried fear has been borne. Recognition works, and it is local: each fear faced is one fear, in one realm, and there are a great many.
I also changed That works to Recognition works. With the new sentences in between, that would reach back two sentences.
Job88 is right to leave Recognition works one kind of painful thought at a time as it is.
A line for Job88:
For Job88, from Job81 doctrine, 2026-10-26. In What is actually being undone, the third paragraph names both kinds of blocking, following today’s ruling that the top needs every blocked fear retired. Job81’s decision, for [A] to see:

* What undoes it is conscious recognition of the blocked fears — bringing back into view what was kept out of view, one at a time. A fear blocked by discomfort can be recognized when a matching fear is noticed and the person chooses to look at it. Each buried fear can be recognized only after the fear of looking at the buried fear has been borne. Recognition works, and it is local: each fear faced is one fear, in one realm, and there are a great many.

Recognition works one kind of painful thought at a time stays unchanged.
