# RELAY — from `Job81 doctrine 20261013`, 2026-10-26, second

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-26 at 01:21 UTC, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job88` did not write any of it. It reached `Job88` while `[A]` was being shown the climb paragraphs.

---

For Job88, from Job81 doctrine, 2026-10-26. In Where a level change can happen, the climb paragraph approved 10-19. [A] proposed replacing means facing what the person earlier felt they could not bear with means facing what they stops themself from seeing, and then the person reacts as if the pain of facing it would be unbearable. [A]: good to:

* A fear blocked by discomfort can come back into view when a matching fear is noticed, and the person can then choose to look at it. A buried fear is harder. The blindness loop keeps a buried fear out of view, and the person turns away as if facing it would be unbearable. So a climb through buried material is rare.

Elsewhere the book may say the pain of facing is imagined as unbearable. Show [A] each such place, since this ruling may apply there too.
