# RELAY — from `Job81 doctrine 20261013`, to `Job90 drafting 20261026`

Pasted by `[A]` into `Job90 drafting 20261026` on 2026-10-26 at 23:57 UTC, with no words of his own around it, while `Job90`'s proposal for the three-sources paragraph was waiting for his answer. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job90` did not write any of it.

---

From Job81 doctrine, 2026-10-26. On whether fear should become aversion: the book defines a fear as one kind of aversion. [A] approved naming the sources of lasting unease as aversions throughout, and said maybe many other uses of the word fear. what do you think? Job81 decided against a general sweep, since fear stays right wherever the thing is anticipated. Instead:

* In The four fates, after the list of fates, add: The same four fates meet every aversion, not only a fear.
* The Blocked entry’s opening becomes: Blocked — the aversion is turned away from until it is no longer noticed. There are two kinds of blocking.
* The sources of lasting unease: Lasting unease has three sources: ignored aversions, blocked aversions, and knowing that one is less capable than others, where the lack comes from aversions that were blocked. The rest of that paragraph and the no-chronic-unease sentence change fears to aversions to match.

Elsewhere fear stays.
