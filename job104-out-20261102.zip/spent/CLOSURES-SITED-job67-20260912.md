# SITED CLOSURES — `Job67 doctrine 09122026` (2026-09-12)

Cut under the standing convention `[A]` ruled on 2026-08-30: a doctrine session cuts a file of
this kind — **site and claim, never the sentence.** Fourth instance. The layout follows
`CLOSURES-SITED-job63-20260912.md`.

**This is not a repairs file and not a note.** Every row is something `[A]` ruled in session,
paired with where it lands. A drafting session writes the sentences. Two rows carry proposed
wording, marked as such, because `[A]` approved the wording itself in session.

**Not applied. Nothing in this file has been carried into any master.**

**Master this session read:** `BOOK2-20260912.md` (35,695 w, md5 `1065e37e`). Book 1 was not
opened. All line numbers are against `BOOK2-20260912.md`.

**Discharged from `NOTE-doctrine-from-job66-20260912.md`: all four items.** The arc's realm, the
routing of a lent fear, the rate-setter `[A]` doubted, and whether ignoring arises only from
blindness. **Fault 48 in `REPAIRS-job66-20260912.md`, blocked pending doctrine, is also
discharged.** `NOTE-doctrine-from-job61-20260909.md` and `NOTE-doctrine-from-job62-20260910.md`
are untouched by this session and everything owed in them stays owed.

---

## What was ruled, in plain words

Nine closures. They are stated here once so the rows can be short.

1. **A realm is a kind of subject matter.** `[A]` 2026-09-12, opening the item: *it seems to me
   that the process arc does not run in a particular realm. only the fixations depend of realms.
   a process arc can be about something in one realm or the other but also both.* Then, pressed
   on whether wants and fears carry realms: *i now question whether wants and fears have realms.*
   **Ruled: a process arc has no realm. A want or a fear has no realm of its own and takes the
   realm of the matter it is about. Where the matter lies on both sides, the want or the fear has
   no single realm.** The test for a matter is unchanged — which realm's rules the matter answers
   to. Ch 3's own opening sentence already says it: everything a person deals with falls on one
   of two sides.

   **This supersedes the 08-19 closure and keeps its criterion.** What the 08-19 closure got
   wrong was what the criterion applies to. **Motivation is no longer the way to identify a
   realm**, and the 09-07 lending ruling had already broken that half — what is lent carries no
   object in the receiving realm, so motivation and matter can come from different sides.
   `[A]`'s two 08-19 worked examples survive word for word, read as fears rather than as arcs:
   the neighbour thinking you careless is a psychic matter, losing the livelihood a physical one.

2. **One fear, one arrival, both fixations acting at the same crossing.** `[A]` 2026-09-12, given
   the choice between one fear handled twice and two fears: *i think one fear, arriving once,
   with both fixations acting at the same crossing.* Most of what that needs is already ruled —
   Ch 4's one attention across two realms makes the crossing one act of attending, and each
   fixation acts where its own orientation acts. **What the book has no account of is the
   settling: one fear gets one fate, and nothing says what decides it when the two contributions
   pull opposite ways.** `[A]`'s own alternation over repeated cycles is the evidence that the
   settling is not fixed.

3. **A person with one cautious realm is partly protected from burying a both-sides fear.** `[A]`
   2026-09-12: *i think so.* The protection needs no new machinery — Ch 15 already has a cautious
   person settling most of the contingencies before the ending is reached, and what is new is
   only the reach, a cautious fixation working on a fear the other realm would otherwise have
   handled alone. **It is narrow: a fear about a matter on one side only goes to one fixation and
   is not covered.** It bears on the rate at which fears get buried and not on where a person is
   found, so Ch 16's argument that health is not another name for type is untouched. Book 1's
   *direction and depth are independent as positions* says nothing about rate, and this sits in
   that gap beside the reserved depth-and-threshold question. **`[A]` stated for the record: he
   does not claim cautious people fall faster.**

4. **The comparison between enthusiasm and caution is withdrawn.** `[A]` doubted it on 09-12
   (*seems wrong. defer it to the doctrine session*) and withdrew it on 09-12 after the argument
   was worked. **The reasoning he supplied:** *with a A fixation, examination is cursory, so no
   fears are generated. the Z phase receives an attraction that didn't succeed, and it gets
   dropped.* And then, against the reversal `[C]` proposed: *the cautious phase resolves fears as
   well as producing them.*

   So the cautious phase both makes fears and disposes of them, and nothing says which grows
   faster with attention. **The net arriving at the crossing is undetermined for both
   orientations, so the book must rank neither.** The rate-setter itself survives — how much the
   earlier part of the process left standing still sets a rate. What goes is the ranking.

   **Also closed on the way, and it is why the sentence read as true:** the sentence compares a
   handling with a person. Cutting an examination short leaves more standing than finishing it,
   which cannot be false and cannot separate two people. The sentence borrows that and spends it
   on the comparison between persons, which is the one the falling chapter needs.

   **And the phase/position confusion behind it, settled from the book:** examination is the
   cautious **phase**, which every arc of every person has, and not the cautious position. Ch 14
   already rules that the letters name a person only.

5. **Most of a person's examined fears arise in their cautious realm.** Derived from closure 1
   and Ch 15's existing claim that examining a want raises a fear about it. How many fears a
   realm raises depends on how much attention the examination gets there, and a cautious realm
   gives it the most. **Scope, stated to `[A]` before he ruled and accepted: direct pain raises
   fears in any realm regardless, so a person's fears are never all in one realm.**

6. **A One's examined fears are psychic.** `[A]` 2026-09-12: *a type one thinks he is thinking
   about the physical = noisy. meanwhile he misuses the tools of the psychic there which is the
   quiet foundation he operates from. and i think his fears would be psychic, e.g. is this proper
   rather than is this actually correct.* **Three of those four are already written into the Ch 5
   Type 1 sketch and are not re-ruled here** — attention sitting in the realm the person is doing
   in, the psychic standard crossing into the physical realm and failing there, and the One
   experiencing the standards as plain fact. **What is new is the fears.** It is also a worked
   case of closure 1: the One believes the matter is physical, the matter of the fear is psychic,
   and what the person believes does not set the realm.

7. **No fear is ever lent between realms.** Discharges the routing question left open by Job66.
   The 09-07 lending ruling already distinguishes the two sources by whether an object travels: a
   fear delivered by an arc arrives with its own object, while motivation lent from the other
   realm has no object in the receiving realm. **A fear is about something, so a fear is not what
   crosses.** What crosses is the pull, with nothing it is about. So no fear ever arrives outside
   its own realm and closure 1's routing needs no supplement. `[A]`'s own case comes out right:
   the pressure to defer is physical, the fear it belongs to is about a physical matter, and the
   same pressure is what gets him attending to psychic material.

8. **Ignoring arises independently of blindness.** `[A]` 2026-09-12: *yes*, on his own Job65
   guess. The four fates stay four independent things. **The book already carries an account of
   ignoring that never mentions blindness** — Ch 17's second way down, where urgency decides
   whether a fear can go on being left. And a fate defined by the fear being in view cannot
   require a fate defined by the fear never coming into view. **Where blindness does enter is
   later:** when urgency forces the fear to be weighed or turned away from, how much sight is
   left decides which happens. So blindness decides how an ignored fear ends and not whether it
   was ignored. **`[A]`'s Job65 statement that other forms of neglecting fears might arise from
   blindness is recorded as co-occurrence, not as a route**, so no later session builds a
   mechanism on it.

9. **The basic fear is defined by position in the chain and by nothing else.** Discharges fault
   48. Every fear down the chain is a fear of failing at the strategy taken up to cope with the
   fear one level above; the basic fear is the one with no fear above it and no strategy to fail
   at. **`[A]` rejected `[C]`'s first wording** — *i don't like "One fear on the scale stands
   apart". it sounds more significant that just being the least compounded fear in a type's chain
   of fears* — and the approved wording takes the weight out explicitly.

   **The realm objection Job66 raised is closed by closure 1.** Ch 16 already says the axis's
   object is not a realm but oneself, and a fear about oneself is about a matter on neither side,
   so having no realm is now expected rather than defective.

   **The join to the rest of the book:** the basic fear behaves like any other fear, reaches a
   crossing, and meets one of the same four fates. Level 1 is that fear attended to. `[C]`
   derived the join; `[A]` approved it.

---

## The rows

| # | Site | L | What lands there |
|---|---|---|---|
| 1 | Ch 15, *Where a fear comes from* | 1125 | **Withdraw** *The fear arrives where the process ends, in the realm the process ran in.* Falsified by closure 1. Nothing replaces it. |
| 2 | Ch 15, *Which fixation handles a fear* | 1229 | **Rewrite** *A fear lives in one realm or the other, so the fixation that handles it is the one held in that realm and not the person's type.* The fixation that handles a fear is the one held in the realm of the matter the fear is about. Closure 1. |
| 3 | Ch 15, *Which fixation handles a fear* | 1229 | **Add** the both-sides case. Where the matter lies on both sides, both fixations act on the one fear at the one crossing. Closure 2. **The book has no account of what settles the fate when the two pull opposite ways, and the addition must not imply one.** |
| 4 | Ch 15, *Which fixation handles a fear* | 1231 | **Withdraw** *so contingencies arrive at the ending unprocessed.* A cursory examination makes few fears rather than leaving made ones unhandled. The rest of the sentence describes enthusiasm and is right. Closure 4. |
| 5 | Ch 15, *Which fixation handles a fear* | 1233 | **Withdraw** from *which costs caution nothing* to the end of the sentence. What is left — that enthusiasm and caution both pass the two ends of detachment with little attention — is true and is what the paragraph needs. Closure 4. |
| 6 | Ch 17, *What actually descends*, second rate-setter | 1425 | **Withdraw** *Enthusiasm that cut the examination short sends more to the crossing than caution does.* Keep the sentence naming the rate-setter and keep *what arrives unprocessed is what there is to turn away from.* Closure 4. |
| 7 | Ch 15, *Where a fear comes from* | 1125 | **Add**, after *Every realm raises fears by examining wants, whatever orientation a person holds in the realm*: how many a realm raises depends on how much attention the examination gets there; a cautious realm gives it the most; so a person with a cautious realm raises most of their examined fears there. Closure 5. |
| 8 | Ch 5, Type 1 sketch | 435 | **Add**, after *They are experienced as plain fact about how things are*: a One examines in the psychic realm, so a One's examined fears arise there — that a thing is not proper rather than that a thing is not correct — while physical pain still raises fears in the physical realm as in anyone. Closure 6. **No separate qualification is needed under the 09-04 ruling: the addition describes where the fears come from rather than how caught the One is, and the sketch's closing qualification covers it.** |
| 9 | Ch 4, *Motivation can cross* | 419 | **Rewrite** *An enthusiastic or cautious realm can also lend wanting and fearing to the person's other realm, when the other realm is detached.* Wants and fears do not cross. Closure 7. **Approved wording is below.** |
| 10 | Ch 15, *Where a fear comes from* | 1127 | **Rewrite**, same sentence, second site. Closure 7. Same wording. |
| 11 | Ch 16, opening section | 1305 | **Add** the definition of the basic fear, after *each of the nine types has its own description at every level*. Closure 9. **Approved wording is below.** |
| 12 | Ch 16, *The rule beneath them* | 1327 | **Add** the join, after *Like every fear, the basic fear has a want behind it*. Closure 9. **Approved wording is below.** |

---

## The three approved wordings

`[A]` approved these as written, so a drafting session takes them rather than composing.

**Rows 9 and 10 — the lending sentence, both sites:**

> An enthusiastic or cautious realm also supplies motivation the person can turn on their other
> realm, when the other realm is detached. What crosses is the motivation and not anything it is
> about, so the person can turn it on whatever the detached realm has taken in.

**Row 11 — the definition:**

> Riso and Hudson call the fear at the head of the chain the basic fear. Every fear further down
> is a fear of failing at the strategy taken up to cope with the fear one level above. The fear
> at the head is the one with no fear above it and no strategy to fail at. What makes it basic is
> that position and nothing more. Each of the nine types has a basic fear of its own, and which
> fear belongs to which type is part of the description not reproduced here.

**Row 12 — the join:**

> The basic fear behaves like any other fear. What a basic fear is about is the person themselves,
> rather than a matter in the physical realm or the psychic one. An ordinary fear takes the realm
> of the matter the fear is about, and a fear about oneself takes no realm. A basic fear reaches a
> crossing like any fear, and meets one of the same four fates. Seeing through the basic fear,
> which is what holds at Level 1, is that fear attended to.

**Register note for row 11.** The name is Riso and Hudson's. What makes the fear basic, as
written, is this book's. The chapter already separates the two on the page and the addition sits
on the book's side.

---

## What this collides with in the repairs backlog

**`REPAIRS-job66-20260912.md` repair 2, site 3, must not be applied before rows 4 and 5.** That
repair is a wording repair — it takes out *time* and puts in *attention* at five sites. Site 3 is
Ch 15 *Which fixation handles a fear*, and the sentence at L1233 contains the reasoning withdrawn
by closure 4. **A session applying repair 2 first would rewrite the words, leave false reasoning
standing, and the sentence would then look freshly checked.** Rows 4 and 5 go first, or the two
are applied together.

**`REPAIRS-job66-20260912.md` repair 1 and rows 2, 3, 4 and 5 are in the same section.** That is
why Job66 recommended doctrine before drafting. The section is now fully ruled and can be written
once.

**Repairs 3, 4 and 5, and repair 2's other four sites, are independent of everything here.**

---

## Carried unruled

- **`[A]`'s phase mapping, 2026-09-12:** *i think the A fixation realm is busy in the A phase and
  the B fixation realm is busy in the B and Z phases.* `[C]` asked whether to take it as a ruling
  and got no answer, so it is carried. **What it would buy if ruled:** a mechanism for Job66's
  ruling that the crossing is attended shallowly rather than not at all, since the attention there
  would come from a cautious realm; machinery for `[A]`'s 09-12 guess that both fixations
  contribute at every position; and a prediction that a Three, enthusiastic in both realms, has
  the shallowest crossings of anyone. **The unanswered half:** does a detached realm take the
  ending, the way a cautious realm takes the examination and the ending.

- **`[A]`'s definition of noisy, 2026-09-12:** *where the conscious attention goes* — the physical
  realm for a One, taken across a whole arc, with the psychic realm still the one at work at the
  crossing. `[A]`: *i think so.* Ch 5's Type 1 sketch already carries the overall claim. The
  crossing half is new and is only as settled as the mapping above.

- **What settles a both-sides fear when the two fixations pull opposite ways.** Named in closure 2
  and not answered. **This is the one thing closure 2 opens and does not close.**

---

## What a drafting session should know

**Twelve rows, and nine of them are in two sections.** Ch 15 *Where a fear comes from* and Ch 15
*Which fixation handles a fear* carry rows 1, 2, 3, 4, 5, 7 and 10. Those two sections are being
substantially rewritten rather than patched, and the rewrite should be read whole afterwards.

**The withdrawals outnumber the additions and that is the shape of the session.** Four clauses
come out. Nothing that comes out is replaced by an argument for the opposite — closure 4 leaves
the net undetermined, and writing the reverse would be the same fault in the other direction.

**`CLAIM-INVENTORY-book2-20260902.md` is not updated by this session.** Twelve sites change and
several inventory entries for those two Ch 15 sections will be wrong once the rows are applied. A
coherence run after the drafting will want it regrown.
