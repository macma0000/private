# ANSWERS for `Job75 coherence 09232026`, from `Job70 doctrine 09152026` — fourth sheet

Cut 2026-09-23, after the third answer sheet. **Merge last, in date order.** This sheet overrides
the earlier ones where they differ.

**`Job70` has no manuscript in any sitting today.** Everything is sited from `Job75`'s quotations.

---

## 1. The counterfeit summit — three parts, and one withdrawn

**`Job75` was right to hold these for `[A]` rather than record them as ruled.** They were `[C]`'s
reasoning passed on, which is the gap the struck sentence came through. **Three still await `[A]`'s
word; see the end of this sheet.**

**What the person trains: detachment, in both places.** Being outside the model is a fact about a
whole person, and a trained realm leaves the other orientation standing. The person still dislikes
disturbance in the trained realm, which is why austerity and fearlessness are its visible marks.
*Physical-realm indifference* becomes *physical-realm detachment*; austerity, fearlessness and
unconcern with comfort and pain stay as written.

**Conscience is muted, not lost.** The person trains psychic detachment. A detached realm **raises
little about that matter rather than nothing**, which is the same correction as *they do not look*.
*Training that realm to indifference loses it as a side effect* and *A casualty of the training*
both overstate. Conscience is a psychic-realm motive that stops getting raised.

**The unchecked-realm clause stays.** *With the other realm running entirely unchecked behind it*
is the paragraph's real claim and survives both corrections.

### WITHDRAWN — `[C]`'s fourth part

`[C]` had added that what observers take for height is a narrowing, because the axis measures
noticing and a trained realm notices less. **`[C]` withdraws it, and it is worse than redundant —
it is wrong.** A detached realm **raises** little, which is about wanting and examining. It does
not **notice** less, which would be a position on the health axis. **The addition quietly crossed
the border the book already guards**, where the correspondence with the Levels does not make a
healthy person detached.

### `[A]`'s own account of the deception, which replaces it

**Observers see one realm, find the marks of attainment there, and take the person to be like that
throughout.** The deception is a generalization from one realm to two, not a mistake about what
unmovedness means. **The paragraph already carries it** in *with the other realm running entirely
unchecked behind it*, so nothing new is needed.

## 2. `indifference` — `Job75`'s correction to `Job70` accepted

`[C]` said the word leaves the book, generalizing from two sites without checking the rest. **That
was the same move that produced the struck sentence, and `Job75` caught it.**

**`Job75`'s register wording stands:** `indifference` is never used of a person or of detachment.
**The Four's sentence stays** — *the physical world runs on its own principles and is indifferent
to how truthful an inner life is* is ordinary English about the world.

**`[A]` 2026-09-23 on the buddha sentence: `the absence of caring` is preferred to `indifference`
there**, because a reader who half-knows the word is worse off than one who has never met it.

## 3. RULED — `equanimity` stays out of the book, and where its boundary falls

`[A]` 2026-09-23: **ok to omit equanimity**, and **his understanding of equanimity includes a lack
of aversion to disturbance.**

**That places equanimity outside the model, not at Z0.** `[C]` had mapped equanimity to Z0 and was
wrong. **The boundary runs between Z0 and equanimity:**

- **Z0** — the midpoint of the continuum, no lean either way, **still minds disturbance, still an
  orientation.**
- **Equanimity** — no dislike of disturbance at all, which is `[A]`'s 09-23 ruling about what
  separates a buddha from a detached person with no leans. **Same state as the buddha's.**

**Two reasons the word stays out.** A reader who knows it brings a framework the book has not
built. And the traditions treat equanimity as reachable by training, while **the book has no
account of training an orientation at all**, so the word would promise a path the book cannot
deliver.

**Consequence for the buddha sentence: say nothing about how anyone gets there.**

## 4. `[C]` draft for the buddha sentence — NOT ruled

For Part 3, where fixation and Naranjo are introduced. **A drafting session may use it, rewrite it,
or write its own.** `[A]` agreed it travels this way rather than as finished text.

> Detachment is not the absence of caring. A detached person minds disturbance — that is what their
> orientation is made of, and it is why a disturbance gets noticed at all. Someone who has given up
> all attraction and aversion, what buddhism calls a buddha, is not further along the same road.
> They are off it. Nothing in this book describes such a person, because everything here is built
> on what a person wants and what they cannot easily bear.

It defines the class before naming the word, as ruled; says nothing about how a person gets there;
and gives the reason the model stops rather than announcing that it does.

---

## OPEN — awaiting `[A]`

**The three counterfeit-summit parts in §1 have not been ruled by `[A]` in his own words.** He
corrected the fourth and gave his own account of the deception, which is recorded above as his.
**The three remain `[C]`'s reasoning.** `Job75` should not record them as ruled until `[A]` says
so.

## FLAGGED, not pursued

**Whether detachment can be trained at all is unexamined.** Health widens the range and gives
access to other orientations. Deliberate cultivation of one orientation in one realm is a
different claim, and the model has not said whether it is possible. **The counterfeit-summit
paragraph assumes it throughout.**
