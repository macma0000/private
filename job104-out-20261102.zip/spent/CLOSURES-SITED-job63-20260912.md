# SITED CLOSURES — `Job63 doctrine 09102026` (2026-09-12)

Cut under the standing convention `[A]` ruled on 2026-08-30: a doctrine session cuts a file
of this kind — **site and claim, never the sentence.** Third instance. The layout follows
`CLOSURES-SITED-job49-20260906c.md`.

**This is not a repairs file and not a note.** No replacement wording. Every row is something
`[A]` ruled in session, paired with where it lands. A drafting session writes the sentences.

**Not applied. Nothing in this file has been carried into any master.**

**Masters this session read:** `BOOK2-20260910.md` (35,048 w). Book 1 was not opened.
All line numbers below are against `BOOK2-20260910.md`.

**Discharged from `NOTE-doctrine-from-job62-20260910.md`:** the Z+ forgetting item, the
dropping-loop item, the three-stores item, the biology item and the free-choice item. **Its
item on a section about fixations, arc stages and single thoughts was not taken and stays
open.** `NOTE-doctrine-from-job61-20260909.md` is untouched by this session and all of it
stays owed.

---

## What was ruled, in plain words

Eleven closures. They are stated here once so the rows can be short.

1. **Forgetting is the same fate as ignoring.** `[A]`: *i think forgotten is the same as
   ignored.* No fifth fate is minted. A fate is sorted by whether the fear is in view and
   whether the fear is disposed of, and forgetting and ignoring answer both alike. Whether the
   act was chosen is a position on the book's own run from the involuntary to the chosen, which
   the book already says does not make two kinds of thing. **Ignoring is the act at the chosen
   end. Forgetting is the same act after sinking toward the involuntary end**, and the relief
   `[A]` described on 09-10 is what does the sinking.

2. **An ignored fear leaves nothing mental.** `[A]`, asked whether the want keeps its object
   when a fear comes back with its focus lost: *no - it's not mental at all - purely physical
   feeling of fear.* So the book's *the fear and the want both stay intact* is false on both
   halves. **What survives is the feeling in the body and nothing else.**

3. **The name is `bodily tension`, and the thing is never called a fear.** `[A]` ruled the
   name after being shown that *physical* is the book's word for one of the two realms, so a
   reader meeting *a purely physical feeling of fear* would read the physical realm. **The
   tension belongs to no realm and a fear from either realm can leave one behind.**

4. **A fear comes back because the problem still stands.** Nothing carried forward brings an
   ignored fear back, because nothing mental was carried. The problem is still standing in the
   world, the occasion arises again, and the fear is raised fresh with its object.

5. **The panic or upset that accompanies a burial is the bodily tension**, at full strength and
   at the moment of the burial rather than in the hours after. `[A]` raised it: *panic or upset
   would accompany burial. is that bodily tension?* The block does not prevent the feeling,
   because what is blocked is the noticing of the fear. **So a burial leaves bodily tension as
   well as what previous thoughts have laid down**, and a person feels upset and cannot say why.

6. **At a burial the fear comes before the content.** `[A]`: *i think the fear isn't about the
   content - not caused by the content, rather it accompanies the content and causes the content
   to be feared.* So no fear exists before the feeling, and **what sets the size of the panic is
   a fact about the person rather than about the thing.** Same shape as his 09-05 ruling that
   the thing feared is not a thing.

7. **The general rule for where a fear comes from.** `[A]`: *any direct pain or a reminder of it
   causes fear - examining a want would be one case of that.* **So the book's arc account is one
   case of a general rule rather than the whole account.** `[C]`'s two-ways claim, made in
   session, is withdrawn: there are not two routes, there is one rule with the arc case inside
   it.

8. **The blindness loop spreads the dread.** `[A]`: *the fear that causes blindness might be
   from any source and probably a combination of causes and i think it would be at the level of
   panic. probably these were established during childhood - but once established, the blindness
   loop can spread the dread to things that bring up the already forbidden material.* The book
   has exactly one instance of dread spreading — recognising a burial threatens to undo the
   burial. **This widens the same mechanism to anything which brings up the forbidden material.**

9. **A person falls as the shutdown spreads.** `[A]` reversed `[C]`'s reading, which had the
   world shutting down as a consequence of falling: *the cause probably goes the other way -
   they fall as the shutdown spreads.* **The health axis measures how much of the world stays
   approachable.** What limits the spread is the brake already ruled — `[A]`: *i think the
   desire to avoid pain limits the spread. people struggle against suffering.* **No new brake is
   minted by that.**

10. **The descent has two phases, and burial starts around Level 7.** `[A]`: *looking at riso's
    levels, it looks like panic and therefore burial starts around level 7. but in young children
    it seems logical that panic could happen at any level and that would leave buried material
    that could later spread at any level.* Above Level 7 the compensatory chain runs on fears
    that are ignored rather than buried, and little blindness accrues. From Level 7 down, fears
    reach panic and are buried, and the loop becomes the main driver. **The spread still reaches
    the whole axis**, because childhood material sits under a person at any level. `[C]` measured
    support, and nobody had connected it: the book's own rungs table has the survival of the
    self-image under threat at Level 7 and *anxiety forces the denial of reality* at Level 8,
    and `[A]` ruled on 09-10 that denial is the same act as burying. **So the unhealthy band
    gets the cause the book has never given it.**

11. **The origin of a fixation, and the freedom question.** `[A]`: *as you recommend.* The
    hedged biology sentence he gave on 09-10 stays exactly as written. **The book's claim that
    the answer lies in a person's earliest history goes further than he has ruled**, and
    contradicts the biology sentence four paragraphs later; his 08-29 closure was that the origin
    is unexplained, with a carve-out for tolerance to fear, and that closure reached neither book.
    **The freedom-against-determination problem stays unnamed in the book.** The run from the
    involuntary to the chosen already answers the contradiction a reader would feel, and naming
    the philosophical question opens a debate the book cannot settle.

---

## The sites

| # | File | Site | What lands there | From |
|---|---|---|---|---|
| 1 | `BOOK2-20260910.md` | line 1185, Ch 15, *Disregarding, and not seeing at all* | The ignoring account reads *The fear is intact and in plain view, and it will be back.* **Both halves are now wrong.** A forgotten fear is not in plain view, and nothing mental stays intact. What lands: ignoring covers the chosen end and forgetting the sunk end, and what survives is bodily tension. | closures 1, 2 |
| 2 | `BOOK2-20260910.md` | line 1199, Ch 15, the *Ignored* entry | Reads *nothing is dropped. The fear and the want both stay intact and only the occasion is let pass, which is why it comes back.* **The reason is wrong as well as the wording.** What lands: the feeling survives in the body without its object, and the fear comes back because the problem still stands. | closures 2, 4 |
| 3 | `BOOK2-20260910.md` | line 1177, Ch 15 | *What a person does about what they take in runs from the involuntary to the chosen, and a choice repeated often enough stops being made and sinks back toward the involuntary end.* **No change.** This sentence is what makes closure 1 hold, and it is already correct. Recorded so a drafting session does not touch it while repairing the sentences around it. | closure 1 |
| 4 | `BOOK2-20260910.md` | line 1235, Ch 15, the Z+ sketch | Reads *the weighing does happen — but it is brief and it is unpleasant.* **Forgetting leads as the usual case and the brief weighing stays as the less common one**, the weighed drop being ignoring at the chosen end. `[A]` was offered the alternative of cutting the weighing altogether and did not take it. | closure 1 |
| 5 | `BOOK2-20260910.md` | wherever the term is introduced, and at every site that now needs it | **`bodily tension` is a new term for book 2.** The book has none. It is short-lived, around hours; it carries no object and no want; it is released by breathing or exercise; **and it is never called a fear.** A drafting session decides the introduction site; `[C]` recommendation, not `[A]`'s: Ch 15, at the four fates, where both fates that leave something are described. | closure 3 |
| 6 | `BOOK2-20260910.md` | line 1201, Ch 15, the *Blocked* entry, and line 1207, *Blocking is not a decision* | **A burial leaves bodily tension too**, felt at the moment as panic or upset. The block stops the noticing of the fear and not the feeling. **This is the first account in book 2 of what burying is like from the inside** — the book describes burying only from the outside, as a turning away the person never sees. | closure 5 |
| 7 | `BOOK2-20260910.md` | line 1201 and line 1207 | **At a burial the fear precedes the content.** The size of the panic is a fact about the person and not about the thing buried. Sits with the entry condition the book already has — blocking happens only to a fear the person cannot bear. | closure 6 |
| 8 | `BOOK2-20260910.md` | line 1125, Ch 15, *Every realm raises fears by examining wants* | **The general rule is missing and the arc case stands alone.** What lands: any direct pain, or a reminder of pain, raises fear, and examining a want is one case. **Do not write this as a third source of motivation** — the two ruled sources are untouched, and this is about how a fear gets its object rather than about where motivation comes from. | closure 7 |
| 9 | `BOOK2-20260910.md` | Ch 15, at the maintenance loop | **The spread of dread has no prose anywhere.** What lands: once material is buried, anything which brings up that material takes on the dread and is turned away from in its turn. The book's single instance — recognising a burial threatens to undo it — becomes the narrow case of a wider one. | closure 8 |
| 10 | `BOOK2-20260910.md` | Ch 16, the health axis | **A person falls as the shutdown spreads**, rather than the world shutting down because they fell. More and more things reach the forbidden material and are turned away from before being noticed. **The brake is unchanged** and must not be rewritten here. | closure 9 |
| 11 | `BOOK2-20260910.md` | line 1319, Ch 16 | *A fear left unattended at a crossing stays in the deposits, and it is from what has collected there that the fears at each level are drawn.* **True of a blocked fear and false of an ignored one**, under closure 2. The compensatory chain at line 1315 needs no store: the fear was left unattended, the problem stands, and the person comes to want whatever would secure against it. | closures 2, 10 |
| 12 | `BOOK2-20260910.md` | Ch 16, the rungs table and the band description | **The unhealthy band is the band where fears reach panic and are buried.** Above it the chain runs on ignored fears with little blindness. **The childhood exception goes in with it**, or the reader will take the account to mean that a person above Level 7 has nothing buried. | closure 10 |
| 13 | `BOOK2-20260910.md` | line 1239, Ch 15 | *where it came from is a separate question, and the answer lies in a person's earliest history.* **Goes further than `[A]` has ruled, and contradicts line 1267.** What lands: the origin is not accounted for, with early history and constitution named as the two places an answer could lie. This is `[A]`'s 08-29 closure reaching a manuscript for the first time. | closure 11 |
| 14 | `BOOK2-20260910.md` | line 1267, Ch 15 | *Some of what makes a fixation may come from biological tendency. The rest was a choice, repeated until the choice sank below deciding.* **No change. `[A]` ruled the hedge stays exactly as he gave it.** Recorded so a later session does not read the biology claim as unruled and strip it. | closure 11 |
| 15 | *(no change — recorded so nobody re-opens it)* | — | **The freedom-against-determination problem is not named in the book.** `[A]` raised it on 09-10 and said he did not know whether acknowledging it was good; he took the recommendation to leave it unnamed. The run from the involuntary to the chosen carries what a reader needs. | closure 11 |

---

## Opened by this session, not closed

- **The engine has been strengthened a fifth time and the brake has not been touched since
  09-01.** The spread of dread is a new self-feeding route, and closure 9 makes the falling
  identical with it. `[A]` pointed at the existing brake rather than adding one, and his
  two-phase account of the descent is the first thing in weeks that limits the engine's reach
  rather than extending it — above Level 7 there is little blindness to feed. **Whether those
  two balance has not been looked at, and this session did not look.** Job31, Job32, Job33 and
  Job49 all declined to assemble a brake, and so did this one.

- **The three stores need restating and this session only half did it.** After closures 2, 3
  and 5: bodily tension is left by ignoring and by burying; what previous thoughts have laid
  down is left by burying alone; the problem itself unsolved is not a store of fear. **What is
  not settled is whether bodily tension left by a burial drains in hours like any other**, with
  the burial underneath refilling it, or lasts differently. `[C]` put the refilling reading to
  `[A]` and he did not answer it in as many words.

- **`NOTE-doctrine-from-job62-20260910.md`'s last item was not taken.** `[A]`'s proposal of a
  short section making explicit the relation between fixations, stages of the process arc and
  single thoughts. His own reason stands: so much depends on the distinction between positions
  on the process arc and fixation positions. The note also records that the distinction is
  needed as early as Ch 4 and Ch 7.

- **`CLAIM-INVENTORY-book2-20260902.md` is stale and this session made it worse.** It already
  described faults Job62 closed as open, and thirteen more sites now change. A coherence run
  will want it regrown.
