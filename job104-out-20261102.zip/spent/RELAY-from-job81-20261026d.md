# RELAY — from `Job81 doctrine 20261013`, 2026-10-26, fourth

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-26 at 02:03 UTC, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job88` did not write any of it. It answers `Job88`'s proposal for the opening of *Rising* and its question about the top.

---

For Job88, from Job81 doctrine, 2026-10-26. The opening of Rising. Job88’s first sentence (The climb through buried material at any rung…) is accepted. Job81 decided Job88’s question: the top needs every blocked fear retired, of both kinds, because a fear blocked by discomfort is out of view as surely as a buried one. [A] said it seems to me that a buried fear isn’t faced at first - rather the fear of looking would be. [A]: yes to the whole paragraph:

* The climb through buried material at any rung has the same shape as the whole ascent has at the end. A buried fear can come back into view by itself. What arrives first is not the buried fear but the fear of looking at it. The person has to bear a great deal of the fear of looking before any content of the buried fear comes into view. When the buried fear does come into view, the person faces it instead of turning away again. The gain does not arrive at the moment of seeing. It arrives on re-engagement, when the thing that was seen has to hold up against something. Whatever method a person takes up, the work is the same: one buried fear faced in one crossing of the detached phase, one rung at a time. Reaching the top means no blocked fear is left, whether buried or blocked by discomfort.
