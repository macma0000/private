# RELAY — from `Job81 doctrine 20261013`, to `Job93 coherence 20261028`

Pasted by `[A]` into `Job93 coherence 20261028` on 2026-10-29 at 00:54 UTC (17:54 his local time, 10-28), with no words of his own around it (his words are inside it). It answers `Job93`'s question whether the tension from a worked-through fear builds across the turns of the unease loop, and withdraws the last line of `RELAY-from-job81-20261029.md`. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job93` did not write any of it.

---

For Job93, from Job81 doctrine, 2026-10-29. On the collision between Job81’s note and the unease loop. Job81 withdraws the note’s last line (the tension fades and does not build from one turn to the next), which contradicted the unease loop. Asked whether tension builds across the turns, [A]: i’m not sure tension builds. why should it? Job81 answered that the only reason in the model is timing: each turn leaves a little tension, and it builds only if the next turn comes before the last has faded, while the unease loop needs only the tension to be kept up. Asked Is that closer: the tension is kept up while the matter is unresolved, and builds only when the turns come quickly?, [A]: yes.
Proposed for the drafting session to show [A], in the house-sale example of the unease loop, replacing the sentences that say the tension builds every turn:

* Every turn of the unease loop leaves a little bodily tension. While the matter stays unresolved, the turns keep coming, and the tension is kept up. When the turns come close together, the tension can build. So the unease lasts as long as the matter stays unresolved.

The burial sentence stands: Before the panic, the fear has usually been ignored, or blocked by discomfort, as the problem went on. Each time the fear came back stronger. What grows toward a burial is an unsettled fear, not the tension of the unease loop. Tension kept up in the unease loop adds to stress, which lowers what the person can bear.
