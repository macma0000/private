# FINDINGS — `Job85 coherence 20261017`

Cut 2026-10-18. The session opened 2026-10-17 on `job84-out-20261017.zip` (manifest label `job85-20261017`). During
the session `[A]` had `job84 drafting 20261017` make one more fix and sent `job84-out-20261017b.zip` (label
`job85-20261017b`). The run is against **`BOOK2-20261017b.md`** (43,053 w, md5 `90eba2ec`). `[A]` carried four
exchanges with `Job81 doctrine 20261013` into this session. Each one is a relay and is marked so.

**A drafting session works from this file alone.** It holds every fault this session found and every ruling `[A]`
gave here. **This session wrote no book text.** Where a row gives wording, the drafting session uses it and still shows
`[A]` the sentences around it, before and after.

**Every site was located by content in `BOOK2-20261017b.md`, which this session did not edit.** Each blockquote below
is a sentence of that master, checked with `quotecheck.py quotes`. `[A]`'s words are given in italics and are never
put in blockquotes. Neither are `Job81`'s.

**How the rows are marked.**

- **NOT RULED**: a `[C]` finding not put to him. Do not act on it without asking `[A]`.
- **RULED**: `[A]` said it, and his words are given. Where he ruled by agreeing to a question, the question is given
  with his answer.
- **RELAY**: `Job81`'s words, pasted in by `[A]`. Where `[A]` gave words inside the relay, they are marked *(in relay)*.
- **`[C]` DECISION**: a call this session made inside a ruling, without asking. The drafting session shows him the
  result.

---

## PART ZERO — THE THREE ROWS `Job84` APPLIED WITHOUT A SEPARATE YES

All three were shown to `[A]` before and after, at the start of this session. **All three now stand.**

- **The ignored disappointment** (`CHANGES-job84-20261017b.md` row 21). `[A]`: *yes*.
- **The enthusiasm end through the migraine case** (rows 13 to 17). `[A]` answered the first cut with *no. i had job84
  do a fix.* The fix is row 15a: the migraine case now opens *A buried fear does not fade in this way.* This session
  takes the fix as his, since he had it made. Shown the two smaller cuts (row 17) on their own, `[A]`: *yes*.
- **The health axis sentence keeping *not how comfortable the person is*** (row 19). `[A]`: *the after is right.*

---

## PART ONE — FAULTS IN THE MANUSCRIPT

### 1. Consequences reach a person at every depth

**RULED 2026-10-18.** **RELAY** first. Asked whether anyone stands where consequences no longer reach them, `Job81`
answered that consequences reach everyone: they work as force and do not depend on sight. What a person far down
loses is the connection between the pain and their own condition. Then `[A]` was asked here *Do you agree with it:
consequences reach a person at every depth, and what a person far down lacks is the connection between the pain and
their own condition?*: *i agree*.

The book already says this:

> Blindness destroys the ability to see one's own condition. It does not reach the job. So this keeps working all the way down, and a person can be driven to struggle without any idea what they are struggling about.

> So the pain of staying goes on rising however far down a person is.

At fault, in the falling-and-rising chapter. The heading *What reaches someone the consequences no longer reach* is
at fault, and so are these:

> This still waits on the world. The recognition comes into view under painful consequences, so where consequences no longer reach a person, nothing raises it.

> What reaches them is another person, working by opposite means. Consequences work as force and bypass sight entirely.

**RELAY, the wording to start from** (`Job81`, 2026-10-18). `Job81` also found *nothing raises it* too strong, because
`[A]`'s 10-17 ruling has a person far down able, possibly, to come to facing without help.

- Heading: *What reaches someone who cannot see their own condition*
- Before the heading: *This still waits on the world. The recognition comes into view under painful consequences.
  Far down, a person feels the consequences but cannot connect them to their own condition, so the recognition rarely
  comes without help.*
- Third paragraph opening: *What reaches such a person is another person, working by opposite means. Consequences work
  as force and bypass sight entirely. The other person works through sight.*

**Run the referring-word count on these before showing them.** *such* is one referring word, and so is *them*. Each
sentence carries no more than one.

### 2. Two reasons people gather in the middle

**RULED 2026-10-18.** Asked *What gathers people in the middle: the pain of staying, once staying becomes unbearable,
the slowness of the fall, or both?*: *both*.

The section *Why this does not take everyone to the bottom* gives the pain of staying as the only reason:

> So something must push back, and it must push harder the further down a person goes.

> The force grows with the distance fallen, which is exactly what produces a population gathered in the middle rather than piled at the bottom.

Since `Job84`'s rewrite, the same section also gives the slowness of the fall:

> Few people reach the bottom, because getting there takes many years of blocked fears.

**The repair, as a claim.** The section states both reasons. *exactly what produces* stops claiming to be the only
reason. **`[C]` note:** the pain of staying pushes back only once staying is unbearable (`Job84`'s ruling). So
*it must push harder the further down a person goes* should be read with that ruling when it is reworded.

### 3. A habitual fear is caused by unease

**RULED 2026-10-18.** Asked *Is a habitual fear the same thing as an ignored aversion?*: *no. Ignored aversions and
buried fears are two sources of unease and habitual fear is caused by unease itself.* **RELAY:** `Job81` then asked
whether a habitual fear ends only when its source ends. `[A]` *(in relay)*: *they are correlated but there are other
factors.* In the second relay file, asked about the paragraph on what keeps a habitual fear going, `[A]` *(in relay)*:
*ok*.

At fault, in the unease-loop section. Each treats a habitual fear as a source of unease, or as ended by its matter:

> Unease from buried material and unease from a habitual fear are two separate cases. A habitual fear is a fear that a matter raises every time the matter comes up. With buried material, the fear is never noticed. With a habitual fear, the fear is noticed every time.

> The two cases are kept going in different ways. The blindness loop keeps buried material in place. A habitual fear is kept going by the matter, which still stands, and by the unease loop.

> The two cases also end in different ways. Buried material ends when the buried fear is faced. A habitual fear ends when the matter resolves, or when the want behind the fear is given up.

**RELAY, the wording to start from.** The habitual-fear paragraphs move below the two-sources paragraph, because a
reader needs the sources first. The other factors stay unnamed. In order:

1. *Ignored aversions and buried fears are the two sources of lasting unease, and they differ in what ends them. An
   ignored aversion can later be given up on. A buried fear can only be faced.* (Unchanged.)
2. *Lasting unease also produces fears. The unease loop keeps raising fears, and the fears attach to whatever matter
   keeps coming up. A fear that a matter raises every time the matter comes up is a habitual fear. With buried
   material, the fear is never noticed. A habitual fear is noticed every time, and worked through every time, as each
   turn of the unease loop is.*
3. *The blindness loop keeps buried material in place. A habitual fear is kept going by buried fears or ignored
   aversions, and by the unease loop. The matter is only what the fear attaches to each time the matter comes up.*
   `[A]` proposed *A habitual fear is kept going by the buried fear and ignored aversion, and by the unease loop?*, and
   `Job81` changed it to plurals with *or*. `[A]`: *ok*.
4. *A habitual fear usually eases when the source of the lasting unease ends. Other things affect a habitual fear as
   well.*

The old paragraphs beginning *Unease from buried material and unease from a habitual fear*, *The two cases are kept
going* and *The two cases also end* are replaced. **`[C]` note:** the paragraphs between the old habitual-fear block
and the two-sources paragraph (the two kinds of help with unease, idle discomfort, distraction, the ignored
disappointment) are not changed by this row. The drafting session reads both joins before moving the block.

### 4. What a person cannot bear: the blocking claim is cut

**RULED 2026-10-18, by RELAY.** `[A]` did not write the claim that a habitual fear grows past bearing and is blocked.
At fault, in the unease-loop section:

> The two cases meet at what a person can bear. A habitual fear can grow past what the person can bear. The fear is then blocked, and the matter becomes buried material.

`[A]` *(in relay)*: *what does a person feel that they can't bear? i would say that they feel like they can't handle
life which is a threat. that's more like perceived material. and that situation persists.* Asked whether that sense is
blocked, `[A]` *(in relay)*: *it stays perceived. the previously blocked material causes them to be unable to handle
life.* Then, to the replacement wording, `[A]` *(in relay)*: *ok*. The replacement, in the same place:

*Buried material can leave a person unable to handle life. The person perceives this, and the perception is a threat.
The perception is not blocked. The person goes on perceiving the threat, because the situation persists.*

`[A]` here, of that passage: *i think that's important and it bears on falling down the levels.* (See item 5.)

**Read with it:** the paragraph after it still holds, and needs no change for this row:

> Only a skill for handling fear can change whether a fear is blocked, because a fear is blocked only when the person cannot bear the fear.

### 5. A third source of stress in the fall

**RULED 2026-10-18, by RELAY.** `Job81` reasoned that the inability to handle life is a third thing that adds stress,
not part of the second. The anxiety from buried material is felt as unease, and the fear behind the anxiety is never
noticed. The inability to handle life is noticed, and perceiving the inability is a threat in its own right. Asked
*Is it a third thing that adds stress as a person falls?*, `[A]` *(in relay)*: *yes*. Then here: *i agree with job81's
opinion*.

The site is *What falling takes from capacity*, in the falling-and-rising chapter. It names two:

> Falling lowers how much a person can bear, and it does that by adding stress. Two things produce it.

> The first is that what is not seen is not taken into account.

> The second is that what is buried goes on producing anxiety.

> Both lower how much a person can bear.

**RELAY, the wording to start from**, after the second: *The third is that a person who cannot handle life perceives
the inability as a threat. The person goes on perceiving the threat as long as the situation persists.* Use
*perceives*, not *sees* (`Job81`). The passage in the unease-loop section (item 4) stays there. The falling section
names the third source.

**At fault with it:** *Two things produce it.* and *Both lower how much a person can bear.* both count two. The section
heading *What falling takes from capacity* stands.

### 6. *Given up* and *given up on*

**RULED 2026-10-18.** `Job81` decided the rule under the one-name rule, and `[A]` gave no words on it in the relay.
He was asked here whether the four sentences should change. `[A]`: *i agree with job81's opinion and also your given up
on changes.*

**The rule:** a fear or an aversion that meets the fate is **given up on**. A want is **given up**.

At fault, in *Rising*:

> Giving up ignored aversions is the way out most within a person's reach.

> Each ignored aversion given up takes away some of the unease that sends a person looking for distraction.

At fault, in the thought-cycle chapter's *Disappointment*:

> Where an aversion about the outcome had been raised, the disappointment is what is left when the aversion is given up.

> When the aversion is given up, what is left is a disappointment.

The four sentences become, in order: *Giving up on ignored aversions is the way out most within a person's reach.*;
*Each ignored aversion given up on takes away some of the unease that sends a person looking for distraction.*;
*Where an aversion about the outcome had been raised, the disappointment is what is left when the aversion is given up
on.*; *When the aversion is given up on, what is left is a disappointment.*

**Stands:** *So the person can give up the want behind the aversion.* (a want); *The want to tie the shoe is given up,
and the thought ends.* (a want). **`[C]` DECISION:** a grep of `given up` and `giving up` found two other sites. One is
the habitual-fear sentence *A habitual fear ends when … the want behind the fear is given up*, which item 3 replaces.
The other is in the Part 3 opening, where it means a standing motivation, not an aversion meeting a fate:

> A person who has given up all attraction and all aversion would mind nothing at all.

That sentence stands, and so do the uses for a want, for giving up one's footing, and for Ch 7's *giving up*.

---

## PART TWO — WHAT THIS SESSION CHECKED AND FOUND SOUND

- **Read in full:** the thought-cycle chapter (Ch 14); the fixations chapter (Ch 15) from *Disregarding, and not
  seeing at all* through the unease-loop section; the health axis chapter's *Where a level change can happen*; the
  whole falling-and-rising chapter (Ch 17). The rest of the book was not re-read. `Job83` read Part 3 and most of Parts
  1 and 2 against the previous master, and only `Job84`'s 26 hunks have changed since.
- **`Job84`'s changes file**, every row, read against the new text. Its two open questions are items 1 and 6 above.
- **The new sentence *A buried fear does not fade in this way.*** has one referring word, *this*, pointing to the
  previous sentence. Holds.
- **The comparison of pains** after `Job84`: the pushback paragraph, *Consequences do not arrive and then pass*, the
  falls-only-sometimes paragraph and the climb-ends paragraph agree with the 10-16 and 10-17 rulings. The one fault
  left is item 2.
- **Facing at unbearable:** the two-pains paragraph, the far-down paragraph and *Rising*'s *On their own, people face
  buried material only once staying has become unbearable* agree. Help is never written as a condition.
- **The health axis chapter's *Every turn of the unease loop is worked through and nothing is buried*** stands, as
  `Job83` found. It agrees with item 3, since a habitual fear is worked through every time.
- **The register entry *capacity to bear discomfort*** still describes it as *the way out at the enthusiasm end*. The
  paragraph that made it so is cut (`Job84` row 14). Repaired in register letter `l`.
- **`wordcheck.py`** against letter `k` on `BOOK2-20261017b.md`: the same hits as on the first cut, because the one
  added sentence fires nothing. The hits were not re-read; `Job84` read every hit falling in a changed sentence.
- **Tracking check:** run on **consequences** (from the job lost, through the pain of staying, to the far-down person
  and the intervener), on **a habitual fear** (from lasting unease to what keeps it going and what eases it), and on
  **an aversion given up** (from the disappointment section through the unease loop to *Rising*). Items 1, 3 and 6 are
  what they found.

## PART THREE — OWED

- **A drafting session on this file.** Every item is ruled.
- **Register letter `l`** is cut with this file (`WORD-RULINGS-book2-20261018.md`). Its section 5a gets a `Job85`
  block for items 1, 3, 5 and 6.
- **Style guide letter `g`** (`STYLE-GUIDE-20261018.md`): section 8's pointer names register letter `l`. Nothing
  else changed.
- **The claim inventory** has an update block of 2026-10-18 for the units these items touch.
- **The handoff is stale.** It is still `HANDOFF-20261005b.md`, naming the 09-23 master, register letter `c` and
  style guide letter `d`. It needs a cut.
- **For a doctrine session:** item 5 places the inability to handle life in the fall. Whether that perceived threat
  connects to the depth-and-threshold question (whether depth sets how soon a process is overwhelmed) is not asked.
  That question is reserved for a session of its own.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.
