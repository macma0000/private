# SITED CLOSURES — Job49 doctrine 09052026 (2026-09-05)

Cut under the standing convention `[A]` ruled on 2026-08-30: a doctrine session cuts a file
of this kind — **site and claim, never the sentence.** Second instance. The layout follows
`CLOSURES-SITED-job32-20260830.md`, whose head said the form was not settled; it worked, and
nothing here departs from it.

**This is not a repairs file and not a note.** No defects found in text, no reasoning, no
replacement wording. Every row is something `[A]` ruled in session, paired with where it
lands. A drafting session writes the sentences.

**THE LAST ROW IS APPLIED 2026-09-06 by `Job51 drafting 09062026`, letter `c`; quarantine
`CLOSURES-SITED-job49-20260905b.md` as `SUPERSEDED__live__`. Closure 6 is written into
`BOOK2-20260906b.md` at the health axis chapter's section on what reaches someone the consequences
no longer reach. NOTHING IN THIS FILE IS NOW OWED.** *Rows 10 and 12 are discharged with it: the
two marks in the brake note now name drafted text rather than a closure, and the `pieces`
restriction was observed — the word does not occur in the new section.*

*What the `b` file said of itself, retained:* **APPLIED 2026-09-06 by `Job50 drafting 09062026`, letter `b`; quarantine
`CLOSURES-SITED-job49-20260905.md` as `SUPERSEDED__live__`.** Every site that called for text is
written into `BOOK2-20260906.md`, except as listed here. **Three rows did not go in as written:**
the aligned-types row named a reason `[A]` doubted and was replaced mid-session by
`DRAFTING-aligned-types-20260906.md`; the intervener row was deferred by `[A]` and is untouched;
and the appetite row turned out to need no sentence — the paragraph it points at already says *it
does not say that a person fixed at appetite is thereby unhealthy*, and four drafts of an addition
were all restatements of it. `[A]` ruled the addition out and one stale sentence beside it was
dropped. **The vocabulary row about `pieces` binds the session that writes the intervener account
and is still live.**

*What this file said before it was applied, retained:* **Not applied. Nothing in this file has been
carried into any master.**

> **A DEFECT IN THE PRECEDENT, found 2026-09-06 and not repaired.**
> `CLOSURES-SITED-job32-20260830.md` still says *Not applied* at its head, and its thirteen rows
> were applied by `Job33` on 08-31. **A closures file that is never marked goes stale silently and
> reads as work owed.** Marking on application is what this head is doing; the 08-30 file needs the
> same and this session did not touch it.

**Masters this session read:** `BOOK2-20260905.md` (30,527 w), `rev2-0814t.md` (56,489 w).
All line numbers below are against those two files.

---

## What was ruled, in plain words

Eight closures. They are stated here once so the rows can be short.

1. **The generalization is ruled: being less caught in the fixations shows as characteristics
   of the types ahead.** It does not violate book 1's rule that direction and depth are
   independent as positions. A lean is a temporary displacement caused by circumstance; being
   less caught is the forward step being less resisted. A deeply caught person can still lean
   forward and a healthy person can still lean backward, so both of book 1's cases survive.
   The claim is not new to book 2 — Chapter 10 line 854 has carried it since before Job48.

2. **Less fixation means greater tolerance for the discomfort that orientation is averse to.**
   Disappointment for enthusiasm, loss of control for caution, naked suffering for detachment
   — `[A]`'s three aversion objects of 08-20. Stated of the three orientations, not of the
   nine types; a sketch applies it twice, once per realm.

3. **The two extra mechanisms Job48 invented are withdrawn.** *An unused sight* and *a covered
   realm* were one mechanism seen in a detached realm and in a covered one. Closure 2 carries
   all nine sketches on its own, which is what `[A]` wanted from the generalization.

4. **The descent runs on one loop with one variable.** Blindness leaves trouble unhandled;
   the trouble is real and produces stress; stress lowers tolerance; lower tolerance means the
   next fear is less likely to be held where it can still be seen. **Stress and loss of
   tolerance are independent of realms**, so a blind crossing in one realm affects the
   fixations in both. **Trouble is partly dependent on the outside**, which is what gives the
   population its spread rather than a single trajectory.

5. **Opportunity to see is unlimited; willingness is what falls.** *The truth is everywhere and
   in everything.* The moments of clarity get rarer as a person descends, and the cause is
   falling willingness rather than scarce occasion. Willingness to see something painful is
   tolerance for the discomfort of knowing, so this is closure 2's variable and not a new one.

6. **What an intervener supplies: capacity, and a truth given a little at a time.** Comfort and
   calming raise what the person can bear. A truth divided small enough that no part of it is a
   threat by itself gets past the block, which fires on recognition of a threat and not on
   decision. **The intervener needs sight of their own** — to divide the truth they must be able
   to look at it. This replaces the 09-01 wording *the second brake works by imported sight*:
   nothing is handed to the person, and the intervener's sight is a qualification rather than a
   transfer. **Urging fails** because urging is pressure, pressure is stress, and stress lowers
   the one variable that decides the outcome. It also explains, for the first time, why people
   low down are harder to help — the same comfort buys less capacity where stress is higher —
   and gives `[A]`'s 09-04 ruling that levels heal one at a time a mechanism: the size of a step
   is set by what the person can bear without the block firing.

7. **Blind fear.** The object of a blind fear is the trouble as never examined. Real trouble
   may stand where it was; the thing as feared does not. The fear attaches to things that are
   not necessarily threats, and those things appear to be threats because they trigger the fear
   — so what a person would find by looking at what sets the fear off is misleading. **A blind
   fear cannot be given up on**, since giving up drops the want behind the fear and finding the
   want requires looking. Unburying is the only route out of it, which is why the climb costs
   what it does.

8. **The competences do come with the pair at any depth, and `[C]`'s objection is withdrawn.**
   `[A]`'s reading: the beneficial aspects of the fixation stay available at strong fixation and
   under stress. Book 2 line 1069 already grounds it — *What is seen is the same at either end
   of the range. What differs is how much of it the person is allowed to know.* What blindness
   withholds is the part that threatens the person, not the realm. All nine closing lines stand
   as written on this count.

---

## The sites

| # | File | Site | What lands there | From |
|---|---|---|---|---|
| 1 | `BOOK2-20260905.md` | line 719, Chapter 8 | Guard sentence reads *Ahead here is a position on a circle, not a rank.* **Book 1 line 884 carries a further clause that book 2 drops** — *there is no ladder and no top.* That clause is what `[A]` ruled on 09-05 about seeing not being a higher grade. Book 2 is the book carrying the sketches and has the weaker guard. Add the clause. | closure 1 |
| 2 | `BOOK2-20260905.md` | line 1063, Chapter 15 | The entry condition — *The fear has grown more painful than the person can hold, and what gives way is not their preference but their capacity.* **Closure 2 says what sets that capacity in a realm:** how hard the fixation there is holding to what it will not do without. Goes beside this sentence. `[A]`'s siting instruction, given in as many words: it belongs in the Z−/Z+ blindness discussion. | closure 2 |
| 3 | `BOOK2-20260905.md` | Chapter 5, the nine sketches, lines 375–620 | **No text change from closures 2 and 3.** The additions never use the withdrawn vocabulary — checked, and `ahead`, `behind` and `integration` appear in none of the nine additions. What changes is the account behind them: one mechanism, not three. Recorded so a drafting session does not go looking for two mechanisms to repair. | closures 2, 3 |
| 4 | `SET-NOTE-from-job48-20260905.md` | the three-mechanism list | Mark superseded. *An unused sight* and *a covered realm* are withdrawn as separate mechanisms. | closure 3 |
| 5 | `BOOK2-20260905.md` | line 617, the Nine | Internal contradiction, and it is the one `[A]` marked for checking. The paragraph says a less caught Nine has stakes; the sketch two paragraphs above grounds the Nine's soundness in having no stake. **Both must be true at once.** The claim that lands: a deeply caught Nine's judgment is sound because nothing is pulling at them, and a less caught Nine's is sound because they can see what is pulling. `[A]` ruled against the negated forms — *can no longer be*, *is not* — under the say-the-thing rule. Not a doctrine change; the doctrine was already sound. | Nine's paragraph, `[A]` 09-05 |
| 6 | `BOOK2-20260905.md` | line 619, the Nine's closing line | Reads *a view of a dispute bent by nothing they want or fear*, which is the deeply caught grounding stated as the competence. It contradicts line 617. The competence itself is a view of a dispute that comes out straight, which holds under both groundings. **Only this closing line is affected — the other eight are sound**, per closure 8. | line 617 |
| 7 | `BOOK2-20260905.md` | line 1245, Chapter 16 | The correspondence's landmark table has Level 7 as *appetite, unqualified*. **New as of 09-05:** the sketches now describe a person improving by moving toward appetite, and eleven chapters later the reader meets appetite near the bottom of the health axis. Nothing says a forward step inside a realm is not a move down this axis. One sentence, and it goes here rather than in the sketches — at the sketches the reader has no health axis yet and feels no strain. The resolution is already in the table's own word: what Level 7 names is appetite with nothing left watching it. | closure 1 + `[A]` 09-05 |
| 8 | `BOOK2-20260905.md` | line 643, the grid chapter | The aligned types are gathered here as a class, with the missing internal contrast stated. **What is missing is `[A]`'s 09-04 ruling:** the difference between the realms has to be learned rather than noticed. A person with two different orientations has it presented from inside, daily; a person with the same one in both has to be told. **Write it positively, not as a denial** — *being less caught does not supply the contrast* is the shape `[A]` ruled against. **Once, here** — not three times across the Three, the Six and the Nine. | `[A]` 09-04, restated 09-05 |
| 9 | **WRITTEN 2026-09-06 by `Job51`** — `BOOK2-20260906b.md`, Chapter 17, *What reaches someone the consequences no longer reach* | — | **The intervener account, closure 6, has no drafted home anywhere in either book.** It belongs to the rising half of the health axis chapter, which is the thinnest part of book 2. `[A]` chose on 09-05 to leave it for a session after the closures are applied, on `[C]`'s recommendation: it is a day old, it is the least settled thing ruled this session, and writing a section that does not exist is not the same job as applying closures. **Do not attempt it in a closures-applying session.** | closure 6 |
| 10 | `NOTE-the-dwell-and-the-brake-20260901.md` | §5.6, and the support half of §5.2 | Two marks. **§5.6:** *the second brake works by imported sight* is replaced by closure 6 — capacity and sized pieces, with the intervener's sight a qualification. The conclusion it supported is untouched: the route still cannot be urged, and the intervener still adds no force. **§5.2:** the support half — *others support them in resisting* — has had no content since it was ruled. Closure 6 is its content. | closure 6 |
| 11 | `NOTE-the-dwell-and-the-brake-20260901.md` | §5.7, the rate question | Closure 4 supplies the missing rate from a direction the note did not expect. The note's open question was that people further down are more stressed but also have more consequences pressing on them, and nothing said which wins. **Both terms now come from one source — trouble** — which raises stress on one side and the pain of staying on the other. The thin low tail is unaffected: it was always a pain quantity and never a sight quantity. | closure 4 |
| 12 | *(vocabulary, no site yet)* | — | **`pieces` is taken.** Book 2 line 1069 gives it a technical job in the passage nearest to where the intervener account will sit: a cautious realm *assembles it piece by piece and never holds it whole*, against a detached person taking a realm *not assembled out of pieces, but seen as it is*. If the intervener's method is also called breaking a truth into pieces, a reader lands on the reading that helping someone moves them from seeing to assembling — the opposite of what closure 6 says. **Say the size, not the noun.** | closure 6 |
| 13 | *(no change — recorded so nobody re-opens it)* | `BOOK2-20260905.md` line 854 | Chapter 10 already carries closure 1 in full, and has since before Job48: *as that grip loosens they come to resemble those types more closely.* It also already draws the consequence that the ahead relation and the classical arrows do not coincide — *A Six has the Four and the Five ahead as well as the Nine.* **Nothing to write.** | closure 1 |
| 14 | *(no change — recorded so nobody re-opens it)* | `BOOK2-20260905.md` line 719 / `rev2-0814t.md` lines 884, 2023 | **`ahead` was examined and cleared.** It does one job in both books — one step forward on the cycle inside one realm — predicated of two people in Chapter 8 and of two types in Chapter 10, which line 854 says outright. Not the one-word-two-jobs class. The rank overtone is guarded at first technical use in both books, and the cycle closing defeats it. **The only change is row 1.** | closure 1 |
| 15 | *(no change — `[A]` withdrew it in session)* | — | **`hope` is not the name for anything.** `[A]` proposed *hope is in a way a denial of caution* and withdrew it the same turn: *hope is no more a denial of caution than enthusiasm is.* Book 1 already places hope as the affect Z+ tends to carry and already refuses to make it diagnostic — *A hopeful surface does not make a person Z+ unless the attention beneath it is turned away from what would disturb.* Book 2 uses *the active phase of hope* for enthusiasm working normally. Nothing to change; recorded so the proposal is not re-made. | `[A]` 09-05 |

---

## Opened by this session, not closed

- **The engine has now been strengthened a fourth time and the brake has not been touched
  since 09-01.** The four: bearability falling as stress rises, the maintenance loop widening
  as burials accumulate, the external route reaching blindness rather than stalling, and now
  closure 4, which closes the loop so that blindness manufactures its own stress. `[A]`
  supplied the one thing pulling the other way when he said trouble is partly dependent on the
  outside — that is what keeps the population spread rather than piled at the bottom. **It has
  not been written down anywhere but here.**

- **`[C]` FAILURE MODE, recorded because it happened twice in one session and both times the
  same way.** `[C]` took a sentence from the Nine's sketch and generalized it, and took a
  sentence from the four fates and generalized it, without first reading the qualifying
  sentence that governs it. Both qualifiers were in Chapter 15. `[A]` caught both. **The
  pattern named on 08-29 is still running:** the recent thinking lands in the crossing and
  health-axis chapters and nothing carries back to the earlier ones, so a session reading Part
  1 or Chapter 5 alone reads a superseded account and does not know it. This is the argument
  for the next session being drafting.

- **Job48 flagged `[A]`'s parallel as worth a session of its own and then left it out of the
  record entirely.** It survived only in the set note, in Job48's paraphrase, using a word
  (*edge*) that may not have been `[A]`'s. `[C]` recommended dropping it rather than
  reconstructing it; `[A]` reconstructed it himself and it turned out to be closure 4. **The
  practice question this raises is not settled: what a set note may carry that the record does
  not.** Everything in the set note that matters should be in the record, and this was the item
  the note itself called the most important.
