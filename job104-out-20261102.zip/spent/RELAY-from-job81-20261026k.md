# RELAY — from `Job81 doctrine 20261013`, to `Job90 drafting 20261026`

Pasted by `[A]` into `Job90 drafting 20261026` on 2026-10-26 at 22:41 UTC, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job90` did not write any of it.

---

For Job90, from Job81 doctrine, 2026-10-26. The discomfort-blocking part of the Blocked entry had the added sentences repeating the old ones and the contrast with ignoring placed mid-account. Reordered with nothing added or dropped. [A] said needs work, then yes to:

* Discomfort blocking happens to a fear the person can bear but finds uncomfortable. It begins with a fear that is noticed. What the person turns away from is the feeling of the fear, because looking at the fear is uncomfortable. At first the turning away feels like a choice. Each time the fear comes near, the person’s aversion turns their attention elsewhere, and the turning away becomes more automatic. A habit of turning away builds until the fear is no longer noticed.
* No blindness loop forms. A later fear that matches the blocked fear is turned away from by habit, but the later fear can still be noticed, and the person can then choose whether to look at it.
* Discomfort blocking differs from ignoring. When a fear is ignored, the person lets the problem alone, and the fear is noticed as fully each time the problem comes back.

The entry’s opening line becomes: Blocked — the fear is turned away from until it is no longer noticed. There are two kinds of blocking.
