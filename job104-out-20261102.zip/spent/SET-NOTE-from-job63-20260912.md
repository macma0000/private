# SET NOTE — from `Job63 doctrine 09102026`, 2026-09-12

## What arrived

One zip, `job62-out-20260910.zip`, directory `job63set`, verified against
`MANIFEST-job63-20260910.md`: **70 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the
manifest.** The screen fired twice and both are expected — `AUTHOR-RECORD.md` as CARRY DO NOT READ,
which a doctrine session is entitled to read, and `HANDOFF-20260906.md` quoting the restriction
string. Both tools exempted themselves.

Record arrived **58,114 w, forty-third append, marker `Job62 drafting 09102026`, parent 55,730**.
Chain clean. **Read in full**, per the standing rule while the record is shorter than the live
handoff — 58,114 w against the handoff's 76,495 w, so the rule still says read. The gap is now
18,381 words and closing. *Whoever cuts the next handoff should expect to be the one who flips the
rule and builds the dated subject index the record's own rules call for.*

`[A]` named the session's kind himself: **doctrine**.

## What this session did

Took `[A]`'s Z+ material from `NOTE-doctrine-from-job62-20260910.md` and ruled it, and it opened
into the largest change to the falling account since the four fates were named. **Eleven closures,
fifteen sites, in `CLOSURES-SITED-job63-20260912.md`.** Neither manuscript was touched.

The five largest:

- **Forgetting is the same fate as ignoring** — *i think forgotten is the same as ignored.* No
  fifth fate. Ignoring is the act at the chosen end and forgetting the same act after sinking
  toward the involuntary end.
- **An ignored fear leaves nothing mental**, only a feeling in the body with no object and no want.
  **The name he ruled is `bodily tension`**, and the thing is never called a fear. So the book's
  *the fear and the want both stay intact* is false on both halves, and what brings the fear back is
  the problem still standing in the world.
- **The panic or upset at a burial is the bodily tension**, felt at full strength at the moment. The
  block stops the noticing of the fear and not the feeling. **First account in book 2 of what
  burying is like from the inside.**
- **At a burial the fear precedes the content** — *it accompanies the content and causes the content
  to be feared* — and **the blindness loop spreads the dread** to anything which brings up the
  already forbidden material. **A person falls as the shutdown spreads**, which reverses the causal
  direction `[C]` had proposed.
- **Burial starts around Level 7, and the descent has two phases.** Above Level 7 the compensatory
  chain runs on ignored fears with little blindness; below, burial and the loop drive it. Childhood
  panic can happen at any level, so the spread still reaches the whole axis. **Book 2's own rungs
  table already said this and nobody had connected it** — the self-image's survival under threat at
  Level 7, *anxiety forces the denial of reality* at Level 8, and his 09-10 ruling that denial is the
  same act as burying.

## Two `[C]` claims withdrawn in session

**The two-ways claim.** `[C]` wrote that fears get their objects two ways, one route for the arc
account and one for the buried case. `[A]`'s general rule — *any direct pain or a reminder of it
causes fear - examining a want would be one case of that* — makes the arc account one case of a
single rule. Withdrawn.

**The causal direction of the shutdown.** `[C]` wrote that a person's world shuts down as they fall.
He reversed it. Withdrawn.

## What was not taken

`NOTE-doctrine-from-job62-20260910.md`'s last item — a short section making explicit the relation
between fixations, stages of the process arc and single thoughts. **`NOTE-doctrine-from-job61-20260909.md`
is untouched and all of it stays owed**: the three wants behind the basic fears, the nine per-type
derivations and the object rule, the basic desire, the contagion question, the cautious lean's
understanding, and bodhicitta. **Both notes travel in this set unchanged.**

## The brake, flagged for the fifth time and not touched

The spread of dread is a new self-feeding route and the falling is now identical with it, so the
engine has been strengthened again. **The one thing pulling the other way is `[A]`'s own two-phase
account** — above Level 7 there is little blindness to feed. Whether the two balance has not been
looked at. Job31, Job32, Job33 and Job49 each declined to assemble a brake and so did this session.

## Record

**FORTY-FOURTH APPEND, sighted** — a doctrine session reads the record. Head is now **59,528 w,
md5 `38aed3b3`**, marker `2026-09-12 · Job63 doctrine 09102026`, parent 58,114 named in the block.
The append quotes `[A]`'s typed words throughout and marks everything else as `[C]`'s report.

## Recurring defect, sixth run running

**The handoff's job-kind rows still do not match the sets.** Reported by Job57, Job59, Job61, Job62
and now this session. A handoff session should fix the rows from the last six set notes rather than
each session recording the same thing again.

## What `[C]` recommends next — `[A]`'s to assert

**Drafting.** Fifteen sites are owed prose and thirteen of them are repairs to sentences a reader
currently meets as wrong. `bodily tension` is a new term with no introduction anywhere, and the
spread of dread has no prose at all. A coherence run would find the claim inventory stale, which it
already was before this session added thirteen more changed sites.
