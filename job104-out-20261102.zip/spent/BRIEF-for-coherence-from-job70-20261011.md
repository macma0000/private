# BRIEF — for the coherence run — from `Job70 doctrine 09152026`, 2026-10-11

For the coherence session that follows `Job78 drafting 20261007`. Read with
**`CLOSURES-SITED-job70-20261009c.md`** and **`RECUT-range-of-detachment-from-job70-20261009b.md`**,
which carry the rulings and the sites. This brief says what to check, what not to try to settle, and
where this session has been unreliable.

`Job70` last held a manuscript as `BOOK2-20261009.md`, md5 `5b04888a46edd85b818750732e427e99`. Every
line number in the closures and re-cut files is from that copy, and `Job78` drafted after it into
`BOOK2-20261011.md`, so treat the numbers as locations rather than addresses.

**This brief was cut after `Job78` closed, so it is not in `MANIFEST-job79-20261011.md` and arrives by
hand.** The record's head, with `Job70`'s sixty-seventh append, is 85,913 w, md5 `4a13bf4b`.

---

## 1. The one sweep worth running, and the one `Job70` could not do

**Capacity to bear pain is now one capacity for the whole person**, and what differs between the two
realms is how much pain a given event produces there. `[A]` ruled this on 2026-10-09.

The book was written while the per-realm claim was available, so **every sentence about how much a
person can bear needs reading against the new account.** `Job70` found the fault by reading one
paragraph of the orientations chapter and had no way to sweep for more.

**What `Job70` expects, so that nothing is manufactured.** The sentences in Part 3 — in the chapter
on falling and rising, around what falling takes from capacity and what reaches someone the
consequences no longer reach — read as whole-person already, and that chapter is where the one-capacity
account is strongest, since it keeps capacity and load apart explicitly. **The sweep should come back
mostly clean.** The orientations chapter is the one place `Job70` knows to be at fault, and the
closures file carries its repair.

**A related sweep has already been run once and should not be repeated.** `Job77` swept all 41
sentences using `pain` under `[A]`'s *pain is pain* ruling and found none treating the two realms as
different in kind. **The capacity version of that sweep is the new one.**

---

## 2. What changed, and where to check it landed evenly

**`draws … toward` is the relation between motivation and noticing; `pulls` is for how hard.** The
defining sentence is in the orientations chapter. `Job70` found two places that had drifted, by
grepping rather than by reading, so **a proper census is warranted** — other forms may exist that a
grep for two words would miss.

**`aversion` is no longer reserved to the cautious phase.** Attraction and aversion are the two most
general kinds of motivation. `Job78` was asked to re-cut the register entry, and the book's uses of
the word need reading against the general sense rather than the narrow one.

**`range` has left the chapter on how the grip loosens.** Check no stray use survives there, and that
*the range of detachment* is the only range the book still names.

**Panic stays and the grab is gone.** `grab` should not appear anywhere. Panic's four load-bearing
uses — the disintegration mechanism for caution, the backward passage from caution to enthusiasm, the
childhood-burial claim in the health chapter, and what a person feels at the moment of a burial — all
depend on the definition in *Action without a full thought*, so check that definition survived.

**Nothing is *allowed* to be noticed or known.** `Job70` found three places and the files site them
all, but the phrasing may have spread further.

**The orientation definitions in Part 1 are ruled and stay as they are.** They still pair *what
attracts* with *what threatens*, which is looser than the new sense of attraction and aversion.
`Job78` asked `[A]` at its close whether to leave them, and he answered yes. **Do not report the
looseness as a fault.**

---

## 3. Where `Job70` has been unreliable, and what follows

**This session twice made sweeping statements about the manuscript and was wrong both times.** It
reported that `aversion` was used at the detached phase in three places, from a copy four drafting
runs out of date — the live file had already fixed it. And it reported that the content about calming
fear was absent from the book, having searched for the word `meditation` rather than reading the
Rising section, which carries the whole territory.

**So any sweeping claim attributed to `Job70` needs its own census before being acted on.** That
includes the claims in this brief.

**Three `[C]` claims were withdrawn on 2026-10-09** and are written into the closures file as
withdrawn. A coherence run may meet them in an older file or a transcript, and they are dead: that
capacity is per realm, with a recommendation to delete the one-capacity sentence; a four-way
classification of wants; and moving the grab beside the snap.

**Two more were withdrawn on 2026-10-10**, both about the burial paragraph: that what a burial teaches
is about thoughts rather than about the incident, and that a person can remember the incident. The
second contradicted the book's own memory rule — a person can remember something happening only if
they noticed it at the time.

---

## 4. Open, and not for a coherence run to settle

Whether the unease loop is stronger in any one orientation.

Where the held sentence goes — *What the person can bear is set by what previous thoughts have laid
down, and most of all by what has already been buried near the same matter.* Under the new rulings it
splits: the deposits set the one capacity, and what has been buried near a particular matter sets how
much that matter hurts.

**`arhat` against lower-case `buddha`.** The Part 3 opener says `arhat`. `[A]` ruled earlier for
lower-case `buddha` as the name of a class rather than the particular man. Whether the ruling was
superseded or not applied is unknown to this session.

**`[A]`'s four additions to the burial ruling**, which `Job78` recorded as never written and owed a
one-line question to him.

---

## 5. Gaps that are deliberate

**The unease-loop material is held out of every set**, at `[A]`'s instruction, for a drafting sitting
of its own. Three things now wait for it: the material itself in
`NEW-MATERIAL-the-unease-loop-20260923b.md`; the case `[A]` brought on 2026-10-07 of a person who
learned to recognize a secondary aversion; and the 2026-10-09 separation of buried material from
material that habitually raises fear, with the distinction between discharging a tension already
there and raising what can be borne while a feeling arrives.

**A coherence run will find places where that material would go. The gaps are deliberate** and are not
to be reported as faults.

**`NOTE-introduction-recognition-20261007.md`** is recorded to be done later, with three cautions, and
no session is to act on it until `[A]` says so.

---

## 6. Two things ruled on 2026-10-10 that have not been drafted anywhere

**Trained abiding acts on the feeling of fear**, so it works on the fresh anxiety that guards a
burial, and the effect has to be strong before any of the content comes into view. The Rising section
already says the only handle on the oldest material is the felt quality itself, and that a skill for
handling fear can be taught. **Nothing yet says the skill is what grips that handle**, and `[A]`'s
ruling is what joins them. The join and the strength qualification belong in that section.

**The blindness loop runs the same way on material laid down before a person had words**, and the
difference is significant in two ways. Fear closes the one route such material otherwise has, since
the route the intuition passage describes needs the noticing that blocking stops. And the pain
comparison loses its measurable side, because facing has no known size when what would surface is a
feeling with no story attached — so desperation is what is left to move the person.

**Neither is in the book.** Both are `[A]`'s rulings, recorded in the sixty-sixth append.
