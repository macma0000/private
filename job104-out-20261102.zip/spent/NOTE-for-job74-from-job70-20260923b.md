# SECOND NOTE for `job74-drafting-20260919`, from `Job70 doctrine 09152026`

Cut 2026-09-23, after `NOTE-for-job74-from-job70-20260923.md`, which you already have. **That note
stands unchanged.** This one adds a single item, raised by `[A]` when he saw the paragraph you are
redrafting.

**You do not have `CLOSURES-SITED-job70-20260923b.md`**, which is held for the coherence run after
you close. Nothing in this note depends on it.

**`Job70` has no manuscript in this sitting.** The paragraph below is quoted from what `[A]` sent,
and everything about its provenance is from session history, not from the files.

---

## The desire/fear asymmetry paragraph does not answer its own question

The paragraph:

> Everything else in a person turns over by the hour. Wanting and fearing arrive, run, and are
> gone. Why should one particular way of noticing stay put for fifty years?
>
> Because wanting and hurting are not symmetrical. A desire has a completion condition: it is
> satisfied or it is blocked, and either way it ends and something else takes its place. A fear has
> none. The feared thing failing to happen does not retire the fear — it confirms the watching that
> seemed to prevent it. So desire cycles because it can be satisfied, and fear freezes because it
> cannot. What accumulates in a person is the unanswerable kind.

### Where it came from

**Not from `[A]`.** Book 2's Ch 14 was drafted whole on 2026-09-02, and the desire/fear asymmetry
was one of the movements the Part 3/4 architecture file specified for it, named there as why a
fixation does not turn over. The drafting session wrote to that specification. The specification
most likely took the material from book 1's origins chapter. **`[A]` on 2026-09-23:** *what i
remember is that fixations are what is laid down. i don't think i ever said anything about fears
repeatedly being raised.*

### Why it is wrong, in two ways

**It answers with content where the ruling answers with the move.** RULED 2026-08-25 by `[A]`: a
fixation is the accumulation of a lifetime of the same move, and **there is no separate thing
sitting under the accumulation — the hardening is the accumulation.** So the answer to the
paragraph's own question is that the move is made again and again, and making it is what lays it
down. The paragraph answers instead that fears pile up because they cannot be settled, which puts
the weight on what the fears are about. **RULED the same day: content is the most overdetermined
thing in the model**, which is why `[A]` took *what varies is what those thoughts are about* over
*what distinguishes people*. Content is the one thing that cannot fix a type.

**It reads as fears being kept.** The arc account settled 2026-09-16 says **a fear lasts one
cycle**, and a fear that returns is raised again out of the mental deposits and out of the problem,
**never stored and brought back**. *Fear freezes* and *what accumulates in a person is the
unanswerable kind* say the opposite.

### What in it is true and can be kept

**A fear about something unsettled keeps being raised, because the problem is still there.** That
is the ignored fate as the book already has it — `ignored, which settles nothing, so the fear
returns with the problem`. It is a true statement about fears. **It is not an answer to why a
fixation persists**, so it cannot carry this paragraph.

### What to do with it

**`[C]`'s recommendation, not ruled, and `[A]` has not been asked about the replacement.** The
question the paragraph opens is a good one and the book should keep asking it. The answer it needs
is the 08-25 ruling: a way of noticing stays put because the person makes the same move at every
cycle, and every making of it lays more down. The mental deposits are what is laid down, and the
next cycle's wants and fears are raised out of what previous thoughts laid down, so the move
reproduces the conditions for making the move again.

**If that is too much to settle mid-pass, cut the second half of the paragraph and keep the
question**, rather than redrafting an answer that two rulings are against. A gap is repairable by
the coherence run; a redrafted wrong answer reads as settled doctrine.
