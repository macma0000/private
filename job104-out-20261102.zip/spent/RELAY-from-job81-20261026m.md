# RELAY — from `Job81 doctrine 20261013`, to `Job90 drafting 20261026`

Pasted by `[A]` into `Job90 drafting 20261026` on 2026-10-26 at 23:19 UTC, preceded by his words *from job 81:*. It is a stretch of the `Job81` chat: `[A]`'s question on `Job90`'s proposal for the leans paragraph in *Disregarding, and not seeing at all*, and `Job81`'s answer. Saved below the rule as it arrived. `Job90` did not write any of it.

---

"declines to look at it further." - or they might make a decision?


Yes. A person leaning toward caution often does make a decision, which works the fear through. That is the competence of caution. So declines to look at it further is too broad. It describes only the fears such a person leaves unattended.
The original sentence had that limit: what goes unattended is what they noticed and passed over. The new text lost it. Declines to look at it further also now sounds like the first step of discomfort blocking, which is the wrong kind.
A version that restores the limit, new words in [ ]:
The leans are what make the difference [in how a fear goes unattended. A person leaning back toward caution stays watchful, and often works a fear through. A fear such a person leaves unattended was noticed and let alone. A person leaning forward toward enthusiasm turns away from noticing. A fear such a person leaves unattended is noticed less each time it comes near, or barely noticed at all.]

Noticed and let alone is ignoring. Noticed less each time is discomfort blocking, and barely noticed at all is blind blocking.
