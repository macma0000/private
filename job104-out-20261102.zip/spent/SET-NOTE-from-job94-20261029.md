# SET NOTE — from `job94 drafting 20261028`

This note goes to the session that receives `job94-out-20261029.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job95-20261029`.

## Arrival

`job93-out-20261029.zip` verified against `MANIFEST-job94-20261029.md`: **59 ok, 0 mismatched, 0 bad count, 0 missing,
207 not in the manifest**, all 207 in `spent/` (130) and `superseded/` (77), matching `Job93`'s moves. The record's last
marker matched `Job93`'s note: ninety-fifth append, 102,979 w. `[A]` named the session `job94 drafting 20261028`; the
label's counter agreed. The session ran on 10-28 his time (10-29 UTC).

## What was done

A drafting session on **`FINDINGS-job93-20261029.md`**, items 1 to 5, with relays `20261029` (first proposal only),
`20261029b` and `20261029c`. **Master out: `BOOK2-20261029.md`**, 44,653 w. Every change was shown to `[A]` in place before
it was applied. The 12 rows, each with his words, are in **`CHANGES-job94-20261029.md`**.

- **Before the panic, the fear has usually been ignored, or blocked by discomfort**, at *A burial is not one event*; the
  week of the main burial counts from the panic.
- **The unease loop's tension is kept up while the matter is unresolved, and builds only when the turns come close
  together.**
- ***Two things that cannot happen*** rewritten from relay `20261029c`; ***Rising*** opens with a climb and a fall in the
  same place, the difference being what happens to a fear. No *blacked out* describes a fall anywhere now.
- **Chapter 4's panic is at the caution end**; *never noticed* → *no longer noticed* in the habitual-fear paragraph.
- **New ruling: the author does not refer to himself in the body of the book.** `[A]`: *"What I call" - remove reference
  to author.* Fourteen places changed. Hedges are kept with *seems* (`[A]`: *seems  is good*); the model's two central
  proposals are stated plainly. The Foreword keeps *I*. Written into **`STYLE-GUIDE-20261029.md`, letter `l`**, section 1.
  The word register is unchanged (letter `p`).
- **Checks:** referring-word count on every new sentence of `[C]`'s; `wordcheck.py` against letter `p`, every changed hit
  read.

**For any session that shows `[A]` a change: bold does not show on his screen.** Mark new words with square brackets and
list the words going out underneath.

## The record

One append, blind: the **ninety-sixth**, `[A]`'s words verbatim with what each answered, including the text he pasted for
*Rising*. **Parent 102,979 w, head 103,462 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `FINDINGS-job93-20261029.md`, `SET-NOTE-from-job93-20261029.md`.
- To `superseded/`: `BOOK2-20261028.md`, `MANIFEST-job94-20261029.md`, and as `SUPERSEDED__live__`
  `STYLE-GUIDE-20261028.md` (letter `k`).
- **Kept live:** the three relays applied here, `RELAY-from-job81-20261029.md`, `-20261029b.md`, `-20261029c.md`, for
  the coherence run to check the changes file against; `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be
  acted on until `[A]` says so.

## What is owed

- **A coherence run on `BOOK2-20261029.md`**, reading `CHANGES-job94-20261029.md`. The claim inventory needs a 10-29 block.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold.
- **The writer 2 pass**, still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261029.md`.**
