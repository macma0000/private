# SPENT FILES — moved here by `Job72 coherence 09152026`, 2026-09-16

Nothing is deleted. These files were consumed by a later session and are kept only as history. A
session does not read them; `AUTHOR-RECORD.md` and the handoff carry what they settled.

- `CLOSURES-SITED-job32/49/63/67/70` — every closure applied by the drafting session that followed
  (Job33, Job50, Job64, Job68, Job71). Job70's closure 3 carried an unruled `[C]` reading that
  Job71 applied; that is now item 6 of `FINDINGS-job72-20260915.md`.
- `REPAIRS-job61/65/66` — applied by Job62 and Job68. Job66's repair 2 (time and dwelling →
  attention) is live again and is item 1 of the findings; the ruling is in the word register.
- `RULINGS-job18`, `RULINGS-20260816b`, `RULINGS-job59` — applied.
- `CHANGES-job62/64/68/69` — session change logs. `CHANGES-job71` stays, being the incoming one.
- `SET-NOTE-from-job48` through `SET-NOTE-from-job70` — spent handovers.
  `SET-NOTE-from-job71` stays, being the incoming one.
- `CORRECTION-job57-instructions`, `COUNT-referring-words-job59`, `QUERY-when-blocking-happens`,
  `REPORT-to-doctrine-since-blocking-ruling`, `DRAFTING-aligned-types`,
  `DOCTRINE-BRIEF-two-stages-of-seeing` — each answered by the session that received it.

Kept in the set: every `NOTE-*` doctrine note, both architecture files, the style guide, the
referring-word rule, the word register, the vocabulary instruction, the claim inventory, the
census, the book 1 files and defect lists, the figures, the scripts, and the two masters.

## Added by `Job73 handoff 20260919`, 2026-09-19

- `SET-NOTE-from-job71-20260915.md`, `CHANGES-job71-20260915.md` — Job72's coherence run read
  them and its findings carry what they left open.
- `SET-NOTE-from-job72-20260916.md` — folded into `HANDOFF-20260919.md`, which names the two
  files Job72 left as work: `FINDINGS-job72-20260915.md` and `ARC-ACCOUNT-from-job72-20260916.md`.

`HANDOFF-20260906.md` is not here. It went to `superseded/` as
`SUPERSEDED__live__HANDOFF-20260906.md`, since `HANDOFF-20260919.md` replaces it.
