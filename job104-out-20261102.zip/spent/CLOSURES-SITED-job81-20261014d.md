# CLOSURES — SITED — `Job81 doctrine 20261013`, 2026-10-14 to 2026-10-15 — letter `d`

**Letter `d` settles Part G2: the game image stays out, by `[A]`'s ruling, and `[C]`'s plain sentence, which he ruled in, replaces it.**
Letter `c` added Part H (the metaphor rule, for the style guide); letter `b` added Part G. Parts A to F are
unchanged from the first cut. Letters `a`, `b` and `c` are in `superseded/`.

The doctrine sitting on the unease loop. Step 2 of the order `[A]` agreed on 10-12. **Site and claim, never
the finished sentence.** Any wording marked **`[C]` wording** is offered, not ruled, and a drafting session
may rewrite it freely.

Sited against **`BOOK2-20261013.md`**, md5 `572d83bb9cfe713d05d0340968876523`, 40,485 w by `LC_ALL=C wc -w`,
1,729 lines. Line numbers are from that copy and are locations, not addresses: grep the sentence.

**Provenance is marked on every closure.** `[A]`'s words are quoted exactly as he typed them. The whole
exchange is in the record's seventy-first, seventy-second, seventy-third and seventy-fourth appends.

**This file replaces the unease file as the thing to draft from.**
`DOCTRINE-ONLY__NEW-MATERIAL-the-unease-loop-20260923b.md` was written before six later rulings and is wrong
in several places (Part F lists them). It goes to `spent/`. A drafting session works from this file only.

**Order of application.** Part A first: the unease loop in Part B rests on the new sense of worked through.
Then B, C, D, E, G, and H for the style guide. Part F is information, not work. Part G rests on Part B and goes after it.

---

# Part A — Working through, and what every fate leaves

## A1. Deciding on a next step works a fear through — RULED

**Asked:** *When a person decides on a next step, has the fear been worked through?* `[A]` pasted `Job70`'s
answer (yes; the coffee passage is right; the 10-13 wording is wrong) and asked *what do you think?* `[C]`
agreed and raised the 09-03 ruling. `[A]`: **"i withdraw the 09-03 ruling."**

**The claim.** A fear is worked through when the thought finds what to do about the fear. The decision may
be as thin as *I will try again*. The fear is settled, and nothing is turned away from. The want behind the
fear need not be met: if the want is still unmet, the want is laid down and raised again by a later thought,
like any want. The matter the fear was about may still be waiting.

**Withdrawn by `[A]`:** the 09-03 ruling that a fear ends only when the want behind it ends. A fear can now
end while the want behind it lives on. **Giving up on is unchanged** — the want is dropped, and the fear
goes with it.

**Also withdrawn:** `Job81`'s claim that putting the cup down differs from trying again because it removes
the danger. At the ending of the thought only a decision exists in both cases. **And dead:** `Job70`'s
10-13 reading that the availability of working through be stated once, by whether the want can be met.

**Sites.**
- **L1297**, the *Worked through* entry in *The four fates*. Replace `[A]`'s 10-13 wording, which he has
  withdrawn. `Job70`'s candidate, corrected by `[C]`: *Worked through — the fear is settled, because the
  thought has found what to do about it. Nothing has been turned away from. If the want behind the fear is
  still unmet, the want is laid down and the next thought raises it again.* **Do not write that the want
  *carries into* the next thought**: only the bodily tension and the content cross (RULED 09-23), and a want
  is laid down and raised again (Ch 14's own account).
- **L1311**, the last paragraph of *The four fates*: *Within that one pairing the difference is how the want
  ended — met in the one case, let go unmet in the other.* False now. What separates the two is whether the
  thought found what to do about the fear or dropped the want.
- **L1125**, *Where a fear meets its fate*: *The fear can be worked through, and nothing about the matter is
  left waiting to be dealt with.* The clause is false for the unease loop and for the coffee case. Bring it
  in line with A1.
- **L1283**, *Disregarding, and not seeing at all*: *It can be thought through and met. In that case the
  fear is dissolved. … Either way the person is finished with it.* `met` and `finished with it` both say the
  matter is done. Bring in line with A1: the person is finished with **the fear**.
- **L1143**, the shoelace: *Deciding on a next step is one way of working a fear through.* **Correct as it
  stands. Do not change it.** It is now the book's worked example of A1.
- **Grep** across the master for *want behind*, *ends with the want*, *want is met*, *met in the one case*,
  *nothing is left over*, *finished with*. `[C]` found the four sites above and L1431 and L1433, which are
  about the basic fear and are unaffected.
- **Register.** The *the four fates* entry (worked through in `[A]`'s 10-13 wording) and the `left-over`
  pattern (*RULED 10-13: worked through leaves nothing waiting to be dealt with*) both need re-cutting. The
  `settled` entry stands: of a fear, `settled` is still only for worked through and given up on.

## A2. Every fate leaves bodily tension, and every thought leaves deposits — RULED

**Asked:** *Does a fear that is worked through also leave bodily tension?* `[A]`: **"yes. probably less than
the other fates. and everything leaves deposits."**

**The claim.** Bodily tension is left by every fate, not only by ignoring and burial. Working through
probably leaves less than the other fates. Every thought lays down mental deposits, whatever its fate.
`probably` is `[A]`'s, and the book keeps it.

**Sites.**
- **L1307**, the paragraph beginning *Ignoring and blocking each lay something down*. It gives bodily tension
  to ignoring and to burial only. Add that a fear worked through or given up on leaves bodily tension too,
  probably less. Keep the bodily tension separate from the mental deposits: the tension lasts hours and can
  be let go by breathing or exercise (RULED 09-10, 09-12).
- **L1287**, *Ignoring leaves a tension in the body* — correct; the general statement belongs at L1307 and
  is not repeated here.
- **The second half** (*everything leaves deposits*) is already in *What previous thoughts have laid down*
  (*Every thought that finishes leaves something behind*). **Nothing to add.**

## A3. A disappointment meets all four fates — RULED, reversing 10-13

**Asked:** *Does a disappointment still meet only three fates?* `[A]`: **"not if you see the fourth."**
`[C]` read it back — working through is now finding what to do, and a thought can find what to do about a
disappointment, as when the person decides to tie the broken pieces together — and asked whether that was
his meaning. `[A]`: **"yes"**.

**The claim.** A disappointment can be worked through, given up on, ignored or blocked. Working a
disappointment through is finding what to do now that the outcome is settled. Giving up on a disappointment
is dropping the want, for instance going without and wearing other shoes.

**This reverses `[A]`'s 10-13 *three fates – yes*.** `Fear and disappointment meet the same four fates`, which
`Job70` withdrew in `Job80`, is true again.

**Sites.**
- **L1169**, *Disappointment*: *A disappointment can be given up on, ignored, or blocked.* Four fates.
  **Give no reason.** `[A]` ruled on 10-13 that the reason is *just an explanation of your logic*, and
  `Job70`'s offered sentence (*cannot be worked through, because …*) is now false as well. Neither goes in.
- **L1173**, the second shoelace thought: *If the disappointment is given up on, the next thought might be to
  tie the broken pieces together.* Deciding to tie the pieces is now working the disappointment through, not
  a new matter after a giving up. If the paragraph keeps a giving-up case, the example is going without
  (wearing other shoes). **`[C]` error recorded:** in conversation `[C]` first gave *buys a new lace* as
  giving up; buying a new lace is finding what to do, so it is working through.
- **Register.** The `disappointment` entry (*meets three fates*) and the pattern `four-fates-disappointment`
  (*RULED 10-13: a disappointment meets three fates*) both reverse. The pattern is now wrong and must be
  removed or inverted, or `wordcheck.py` will flag the repair as a fault.
- **The four fate entries** at L1297–L1303 stay written for a fear (Job80's decision). Nothing else in them
  needs changing for a disappointment.

---

# Part B — The unease loop (new prose; nothing of it is in the book)

**Where it goes. `[C]`'s decision:** one new section in Ch 15, **immediately after *Blocking is not a
decision***, so that bodily tension (introduced at *The four fates*) and the enthusiasm end of detachment
(in *The range of detachment*) are already in hand. Ch 14 cannot take it, because Ch 14 comes before bodily
tension is defined. Title: the drafting session's choice; *The unease loop* will do.

**One case per paragraph.** The section is new and dense; the style guide's density repair applies.

## B1. The loop — RULED 10-04 (record, sixty-fifth append) and today

`[A]`, 10-04: *what about fear->tension->desire for relief->fear?* and *unease loop is ok.*

**The claim.** A fear is raised and worked through, and leaves some bodily tension. The tension is
uncomfortable, so a later thought raises a want to be rid of it. The examining finds the want cannot be met,
and a new fear is raised. Each turn is a whole thought with all three passages. **Each turn is worked
through** (A1): the person decides to try again. The loop goes on because the matter does not resolve and
the decision cannot make it resolve, and the tension builds because every turn leaves a little.

**What the loop does not do.** Nothing is turned away from, so the loop buries nothing and takes nothing
from what a person notices. (`Job70`, relayed by `[A]` today, agreed by `[C]`.)

**The original trouble stops mattering** after a few turns: the want is to be rid of the tension, and the
fear is of failing to be rid of it. `[A]`, 10-04: *the discomfort is more basic since solving a problem
usually leads to finding another problem.*

## B2. `unease` — RULED 10-04

`[A]`: *ok. bare unease for now.* and, of unease and bodily tension: *they are two faces of one thing. i don't
know a name for that thing.*

**The claim.** `unease` is the felt discomfort of the loop; bodily tension is the same thing in the body. The
book names both and names nothing that covers both. **`[C]` decision:** the 09-23 file's *unease is the
whole round, and the bodily tension is the part that carries* is `[C]`'s and is dropped for `[A]`'s *two
faces of one thing*. No synonym (*disquiet*, *restlessness*, *malaise* …). `unease` can last hours or years,
and the sentence says which.

**Register.** `the unease loop` becomes the **third permitted use of `loop`**, beside the feedback loop and
the blindness loop. The `loop` entry and the `loop` pattern both need it.

## B3. The three orientations — RULED 10-04 and 10-12; NO RANKING

`[A]`, 10-04: *in all orientations, it seems that the person gives up with the intention that the fear still
needs to be dealt with. for A the desire is to try something else. for B it is to solve the existing
problem. for Z the desire is to make the anxiety go away either by distraction … or finding a creative
solution …*

**The claim.** All three run the loop. An enthusiastic person tries something else, circling the same matter
by a new route each time. A cautious person goes on trying to solve the existing problem. A detached person
wants the anxiety gone, by distraction or by a creative solution. Each has an exit through its own
competence: a cautious person can come to understand the matter, an enthusiastic person can act on it, and
detachment at the caution end disposes of the fear.

**RULED 10-12: the book does not rank the loop's strength by orientation.** `[C]` decision: the 09-23 file's
whole strength section (climb rate, saturation ranking, *strongest at the enthusiasm end*) is dead. The word
*gives up* in `[A]`'s 10-04 sentence is now working through (A1); see F1.

## B4. The enthusiasm end of detachment — RULED today

**Asked:** *When a detached person at the enthusiasm end distracts themselves, is the fear ignored rather than
blocked?* `[A]`: **"ignored."**

**The claim.** At the enthusiasm end the person changes the subject, and the fear about the matter is
ignored and drops out of mind. The unease stays. The want becomes the want to make the unease go away, and
distraction does not remove unease, it occupies the person. So the want fails and is raised again with no
object to act on. **The loop about the matter ends there; the loop about the unease goes on.** The only exit
at that position is capacity rather than competence — bearing the unease instead of wanting it gone.

**Withdrawn:** `Job70`'s 10-12 *the fear is blocked and leaves view* (answers file item 7, and the record).
`blocked` was `[C]`'s word, not `[A]`'s; a blocked fear is buried, and the loop buries nothing.

**Hook:** L1263 already says a person near the enthusiasm end, when disturbed, *wants the disturbance gone
rather than solved*. The new section hooks to it rather than saying it again.

## B5. Saturation — RULED 10-04 as a hypothesis

`[A]`, 10-04: *what if the unease loop saturates at a lower level of disability than the blindness loop?*

**The claim, in the author's *I suspect* voice (the 09-15 voice ruling).** The unease loop carries a person
only so far, where the blindness loop has no such limit. **`[C]` decision on the ground:** nothing in the
unease loop is buried, so the unease is felt and some exit is always open, even where the only exit is
bearing the unease. What moves a person to take it is the comparison of pains — which is worse, staying as
one is or doing what the exit requires (RULED 10-07, *pain is pain*). **Do not use `brake`** (retired 10-07)
**or `disability`** (`[A]`'s conversational word, not the book's).

## B6. The turning over — RULED today

**Asked:** *Is turning over a past outcome a separate thing from the unease loop, or one form of it?* `[A]`:
**"does turning the same want over actually occur. yes in the sense of a general desire. maybe not for a
specific plan to achiece it. what do you think?"** Then, on `[C]`'s *never reaching a plan*: **""and never
reaching a plan" - should be "but not repeating the same plan?"** Then: **"ignored would repeat the same plan.
it happens especially with children, trying the same thing over and over because the don't understand that
such behavior is unacceptable as an adult. there is also trying slightly different approaches which is
similar. - i don't know how much of this detain is appropriate for the book."**

**The claim.** While an outcome may still be changed, a person can turn the matter over. What is raised
again each time is the general want — that the outcome go the other way. **If a different plan is reached
each time, each turn is worked through, and the turning over is the unease loop. If the same plan is
repeated, the fear that it will fail again is noticed and let alone each time, which is ignoring.** The
turning over ends when the want is given up, leaving a regret where the person could have acted otherwise,
or when a want about the future replaces it (*next time I'll prepare*).

**`[C]` decision on detail:** the book carries the distinction and one plain example (a person going over a
bad interview). **The children and the slightly different approaches stay out:** acting by rote is *not in
the model* (`[A]`, 09-23), and `[A]` warned on 09-21 that unnecessary details tempt a literal reading.

**Correction to the answers file:** *Ignored leaves the person turning the matter over* is too narrow. Only
the same plan repeated is ignoring.

## B7. Ordinary, not a disorder — RULED 09-23 / 10-04

`[A]`: *i agree with your population recommendation.* and *keep them out for now.*

**The claim.** The shape is ordinary. It can run for years without a person thinking of themselves as
troubled, and from inside it feels like effort rather than being stuck. **No frequency claim. No clinical
names** (workaholism, PTSD, obsessions stay out). No research is cited.

## B8. Unease present, noticed, acted on — RULED 10-04

`[A]`: *i'm confused about the relationship between awareness of unease and the degree of ability to deal
well with reality.* and, to `[C]`'s answer: *i think so. add it.*

**The claim.** Three things: the unease being there, the unease being noticed, and the unease being acted
on. Noticing is needed for acting on it and does not deliver it. A person higher on the axis may feel more
unease than a person lower down and be better able to do something about it. **Safe form** (the 09-23
file's own caution): say what the axis measures — how much is in view — not that healthier people feel
worse. The book must not read as recommending discomfort.

## B9. Two cases: buried material and material that habitually raises fear — RULED 10-09

`[A]`, 10-09: *these are separate cases, i think.* `[C]`'s three differences, accepted.

**The claim.** With buried material the fear is never noticed; with material that habitually raises fear
the fear is noticed every time. Burial is kept going by the blindness loop; habitual fear by the matter
still standing and by the unease loop. Buried material ends when the buried fear is faced; habitual fear
ends when the matter resolves or the want is given up. **They meet at bearing:** a fear raised again and
again that grows past what the person can bear is blocked, and after that it is buried.

## B10. Letting go of tension, and bearing more — RULED 10-09

`[C]`'s distinction, accepted by `[A]`.

**The claim.** Breathing and exercise let go of a tension already there, with nothing it is about (already
in L1307). A taught skill for handling fear raises what a person can bear while a feeling is arriving. Only
the second reaches what guards a burial. **Whether exercise also raises what can be borne over time is not
ruled and is not written.**

## B11. The migraine case — `[A]`'s, 10-07, placed by `[C]`

`[A]`, 10-07: *i talked to someone who has overcome aversion to aversion. she learned to recognize the
secondary aversion and resist it. the ability to recognize it can from learning to control migraine pain by
avoiding resisting it.* and *apparently the secondary aversion is not so deeply buried … that may be
different for other people. and notice the original motivation was extreme pain which enabled learning
equanimity.*

**`[C]` decision on placement:** with the unease loop, as the exit by capacity in B4. She learned not to
resist a sensation, and the capacity then applied to a feeling she had not been working on. **Conditions,
`[A]`'s and `Job70`'s, all binding:** no name and no migraine detail that invites a reader to try it; told
as one person's report, not as a prediction; the secondary aversion was recognizable because it was not
deeply buried, and a person whose turning away comes before the noticing has nothing to catch; the word
`equanimity` stays out — say she stopped resisting the pain and found she could stay with it.

---

# Part C — *Rising* (Ch 17)

## C1. Trained abiding acts on the feeling of fear — RULED 10-10

`[A]`: *i think trained abiding acts directly on the feeling of fear, so it should make buried fears easier
to approach although the effect would need to be strong before the person would be able to notice the
content.*

**The claim, and the join it makes.** *Rising* says the only handle on the oldest material is the felt
quality itself (L1663), and that a skill for handling fear can be taught (L1671). Nothing says the skill is
what grips that handle. It is: the skill acts on the feeling, and the feeling guarding a burial is felt even
though its content is not.

**The strength qualification.** L1661 says *A buried fear comes back into view by itself.* Qualify: whether
it does depends on how strongly the arriving feeling can be borne, and the effect must be strong before any
content comes into view.

**Hooks.** Do not restate *Rising*'s taught-skill paragraphs; add the join beside them. The summit section
(L1705–L1719) already uses *abide in the detached phase*; use the same verb.

## C2. Material laid down before words — RULED 10-10

`[A]`: *separately, the book discussed material laid down preverbally which is difficult to notice for a
different reason. but i think when there was fear, the blindness loop happens in the same way. do you think
the difference is significant?* `[C]` answered yes, with two consequences; accepted.

**The claim.** The blindness loop runs the same way on material laid down before a person had words. Two
consequences. **Fear closes the route such material otherwise has:** intuition (L375) needs a later noticing
of what was taken in, and blocking stops the noticing. **And facing loses its known size:** what would come
up is a feeling with no story attached, so neither side of the comparison has a measure, and desperation is
what is left to move the person.

**Sites.**
- **L1663**, *Rising*'s oldest-material paragraph: the first consequence.
- **L1675**, *What sets a person preparing is the same comparison …*: the second consequence. That paragraph
  already qualifies the staying side; the facing side is the new part.
- **L1401**, the burial paragraph in *What previous thoughts have laid down*: one sentence that burying can
  begin before a person has words and runs the same way. **This replaces the statement `Job80` cut from
  *Blocking is not a decision*** (the book's only statement that turning away began before words). Do not
  restore *learned rather than designed* or *the move had to be learned*: `[A]` ruled 10-11 that the
  capacity to turn away is not learned.

---

# Part D — Ch 16, *Where a level change can happen* (L1499–L1507)

**The claim.** L1503 already says three of the four fates take nothing from what a person notices and that
*Most of a person's life is lived this way.* Add one sentence: the unease loop is lived this way too, since
every turn is worked through and nothing is buried; it can hold a person in unease for years without moving
them down the axis. The saturation hypothesis (B5) is said once, in Ch 15, and not repeated here.

---

# Part E — Decided by `[C]`, nothing to draft

- **The question at L1389** (*Why should one particular way of noticing stay put for fifty years?*) keeps
  its present answer, the mental deposits. The 09-23 file recommended the unease loop as the answer; that
  would join a fixation to a loop the book says any fixation runs. Not done.
- **`NOTE-introduction-recognition-20261007.md`** stays untouched until `[A]` says so.
- **Placement inside the new section** is the drafting session's, in the order B1, B2, B3, B4, B11, B5,
  B6, B7, B8, B9, B10, or better.

---

# Part F — What in the 09-23 unease file is dead, and why

For a session that meets the file in `spent/` or in the record.

1. **§2, *giving up stays one fate … dropping the attempt is not giving up* and the record's 10-04 *giving
   up on a fear has two kinds*.** Both are superseded by A1: the case `[A]` called a second kind of giving
   up is working through.
2. **§2, the test between ignoring and trying again** (*keeps the feeling … no fear left to feel*). Both
   leave tension (A2). The difference is whether the thought found what to do (A1).
3. **§3, *what survives into the next cycle is a desire*.** Only the bodily tension and the content cross
   (RULED 09-23); the want is raised again.
4. **§5, *unease is the whole round*.** Replaced by `[A]`'s *two faces of one thing* (B2).
5. **§7, the saturation argument resting on `brake`.** Re-grounded (B5).
6. **§8, the whole strength ranking.** Dead (RULED 10-12, B3).
7. **§11, the loop as the answer to why a fixation stays put.** Not taken (Part E).
8. **§13, the draft paragraph** says *looked at*; the word is *noticed*. Draft afresh.
9. **The header's date.** The file is named 09-23; the record dates the sitting 10-04. Not resolved, and
   nothing depends on it.

---

# Part G — The drawbacks of immediate gratification (new material, 2026-10-15)

**`[A]` opened it:** *the drawbacks of immediate gratification.* None of it is in the book. The book never
uses the phrase. All of `[A]`'s words are in the record's seventy-second append.

**Where it goes. `[C]`'s decision:** in the new Ch 15 unease-loop section (Part B), as its last part, after
B4. The loop about the unease at the enthusiasm end of detachment *is* distraction, and this material says
why distraction never closes that loop. The routes out (G6) go to *Rising*, not here.

## G1. Idle discomfort, and the turn to distraction — `[A]`, hedged

`[A]`: *a person's natural tendency is to seek gratification. when completely idle most people are
uncomfortable - probably due to buried fears. so the person seeks a distraction, something they think would
make them feel better. for A orientation that would be something pleasant. for B that would be solving a
problem. for Z, some activity or contact with someone else.*

**The claim.** With nothing else going on, most people feel uncomfortable. The discomfort probably comes from
buried fears (keep `probably`). The person seeks a distraction: something pleasant for an enthusiastic
person, a problem to solve for a cautious one, activity or contact with someone else for a detached one.

**Hooks.** The book already says a burial is felt though nothing about it was noticed (*Blocking is not a
decision*), and that a pain starts a process and raises the want to be rid of it (L1227). Use both rather
than restating them.

**Site to repair: L1349**, the enthusiastic-side sketch in *The four sketches*: *starts from the vacuum the
phase itself creates: boredom*. The discomfort comes from buried fears and ignored aversions (G4), not from
the phase. Repair the cause; keep *boredom* as the name of how it feels.

## G2. Gratification always wears off — `[A]`

`[A]`: *gratification is comparative. the same thing day after day becomes expected and no longer is a
distraction. therefore constant gratification and distraction is impossible.* Asked whether this holds for
all three forms: *gratification always wares off.*

**The claim.** Whatever gratifies, repeated, becomes expected and stops gratifying. True of all three forms
of distraction. So no distraction lasts, and constant distraction is impossible.

**`[A]`'s filter analogy stays out of the book, at his instruction** (*a mathematical analogy for you but
not the book*). **The game image stays out — RULED.** `[A]` asked *is the game metaphor useful -i don't know. what do you
think?* `[C]` recommended leaving it out: the book already uses a game for the self as a piece in the
competition game, so a second game would give one image two jobs; and a game suggests deliberate play where
the reach for distraction runs below choosing. `[A]`: **"leave it out. use your plainly said point."**

**`[C]`'s plain sentence, which `[A]` ruled in:** *What gratifies changes as it is repeated, so no way of
seeking gratification keeps working.* A drafting session may adjust it for the paragraph around it; the
claim stays as stated. `[C]` consequence, not disputed: each rise in gratification is followed by
an equal fall when the thing becomes expected, and the fall is felt as suffering with an outside cause. The
book may say the fall; it gives no arithmetic.

**No research is cited.** The phenomenon is well established (*hedonic adaptation*); the book does not need
the term.

## G3. Misattribution, and the drawback — `[A]`

`[A]`: *a person who doesn't understand this blames external circumstances for this suffering and believes
some different behavior will bring relief. and since the baseline gratification has lowered, many behaviors
can again increase gratification and bring relief. the person mistakes the new behavior as the cause when in
fact the cause is simply saturation of gratification unrelated to behavior. so the drawback of seeking
gratification is constant useless behavior.*

**The claim.** When a gratification wears off, the person blames circumstances and tries a different
behaviour. Any new behaviour relieves for a while, because the person has gone without the old
gratification long enough for anything to gratify again. The person credits the new behaviour, when the
relief came from the wearing off and recovery, not from the behaviour. **The drawback of seeking
gratification is constant useless behaviour.**

**Hook.** This is a case of misattribution (`NOTE-the-two-pressures-and-misattribution-20260902.md`, unruled
for the book) — say it in this case's own terms; do not import the note.

## G4. Two sources of the standing discomfort — RULED

`[C]` asked whether suffering wears off as gratification does. `[A]`: *not when there is buried fear.
distraction is constantly needed to avoid feeling the fear.* Then: *Where nothing is buried, there is no
suffering and no need for the distraction of gratification. but what happens in that case when pleasure is
experienced? does that create acclimation and then suffering when the pleasure stops. probably yes. depends
on whether the disappointment is cleanly accepted. if not, there is left over aversion.* Then: *what about
ignored aversion. it seems like that would also encourage seeking distraction although giving up on the
aversion later would not be blocked.* `[C]` put the combined form; `[A]`: **"yes."**

**The claim, as ruled.** The standing discomfort that sends a person to distraction has two sources: buried
fears and ignored aversions. An ignored aversion is still in view and can later be given up on. A buried
fear can only be faced. Where there is neither, ordinary pain still comes and goes, but no distraction is
needed to cover it.

**Why buried fear does not wear off** (`[C]`, from the book): each time the buried material comes near, a
fresh anxiety arises (the maintenance loop, *The range of detachment*). What is felt is raised again and
again, not one steady feeling.

**When a pleasure stops**, a disappointment arises and meets one of the four fates (A3). Worked through or
given up on, it is accepted cleanly. Ignored, it leaves the aversion `[A]` describes, which is a source of
standing discomfort. Blocked, where the loss is more than the person can bear, it is buried.

**`[C]` addition, not disputed:** an aversion ignored long enough can grow past bearing and slide into
burial (gradual burial, ruled 10-12). Say it once.

**No frequency claim** (RULED 09-23). The book may say seeking distraction is the ordinary case. `[C]`
reported the research to `[A]` (Wilson 2014; Killingsworth and Gilbert 2010); none of it goes in.

## G5. What it is not

The unease loop as ruled in Part B is unchanged. Distraction is one form of a turn of the loop at the
enthusiasm end (B4); this part adds why that form never succeeds. **Do not write it as a fifth fate or a
third loop.**

## G6. The ways out — `[A]`: *looks good*

`[C]` set out five routes, each already ruled, and asked whether `[A]` would add or change one. `[A]`:
**"looks good."**

1. Understanding that gratification wears off, so the hunt for the right behaviour stops. A general
   understanding retires nothing (RULED 10-06); it lets the person take seriously that the discomfort has
   another source.
2. Giving up ignored aversions, which are in view. The most available route.
3. Bearing the unease instead of covering it — the exit by capacity (B4), what trained abiding acts on (C1).
4. Facing buried fears one at a time — the climb.
5. Help from an intervener (RULED 09-05).

**Sites.** *Rising* already carries routes 3 to 5 and *What is actually being undone* carries the general
understanding. **Add only what is new: route 2, and the point that a better distraction is never a way
out**, in *Rising*, after the taught-skill paragraphs (L1671–L1673). Join route 1 to the existing
general-understanding paragraph in *What is actually being undone* in one sentence.

**Limits, both standing rulings:** growth material stays at the mechanism and practices are not given
(09-08); ways of lowering the pain directly are not listed (09-06). **Say what each route acts on, not how
to do it.**

---

# Part H — The metaphor rule, clarified (style guide, not book text)

`[A]`, 2026-10-15: **"my objection to metaphor is against single sentences where a mild metaphor is used
unexplained to save a few words where it could be said using more literal words. an explained metaphor is
okay."** Asked whether that lifts the bans on economic and mechanical metaphor: **"economic metaphors are
still too remote. the frequency filter is an example of mechanical metaphor i deliberately avoided, but
there might be a use for that - i don't think we have any now."**

**For the drafting session to apply to `STYLE-GUIDE-20261005b.md`, cutting it at letter `e`** (style guide
§3, *Name the mechanism; do not reach for a figure to save a few words*):

- **The fault** is a single sentence using a mild metaphor, unexplained, to save a few words, where literal
  words would say it. **An explained metaphor is acceptable.**
- **The section's sentence** *Where the mechanism is stated right after the figure, the figure compresses
  nothing and only delays the explanation* goes further than `[A]` and is to be reworded to his statement.
- **Economic and financial language stays out**, explained or not (*economic metaphors are still too
  remote*; ruled 08-29, confirmed 10-15).
- **Mechanical metaphors for psychic-realm phenomena:** no longer a flat ban. Avoid them; one, explained, may
  have a use; the book currently has none. `[A]`'s words to be carried with the bullet.
- **No sweep — `[C]` decision.** Nothing already removed under the old wording is to be restored on this clarification
  alone.
