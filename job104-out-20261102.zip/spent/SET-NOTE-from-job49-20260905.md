# SET NOTE — from `Job49 doctrine 09052026` (2026-09-05)

**The next session is kind 11 — composing prose for ruled doctrine.** `[A]` chose it on 09-05
over the alternative of writing the intervener account, on the recommendation below.

**Read `STYLE-GUIDE-20260905.md` before writing any prose.** `[A]` ruled on 09-04 that it
applies as prose is written, not as a later cleanup pass.

**`AUTHOR-RECORD.md` travels in this set and is NOT opened.** Kind 11 writes new prose, which
is the strongest form of the bar.

---

## What this session produced

**`CLOSURES-SITED-job49-20260905.md`, 2,522 w.** Fifteen rows. **This is the session's work
and the next session's job.** Read its eight numbered closures first — the rows are written
short because the closures are stated in full above them.

Four of the fifteen rows record that **nothing changes**. They are there so a later session
does not re-open something already examined: `ahead` was measured and cleared, Chapter 10
already carries the generalization, `hope` was proposed by `[A]` and withdrawn by him the same
turn, and the nine closing lines are sound.

**`AUTHOR-RECORD.md` appended** — twenty-ninth append, 36,482 → 39,305 w, parent verified.

*Marker note: `Job48`'s marker was written as a `##` heading rather than in the form every
marker before it used, which is why `setcheck.py sweep` reported the record at 35,695 words
against a real head of 36,482. This append returns to the canonical form and the sweep now
reads the head correctly. Nothing was wrong with either file; only the sweep was misreading.*

## The seven claims Job48 marked

Six settled, one dropped and then recovered by `[A]` himself.

- **The generalization is RULED.** It also turned out to be already drafted, in Chapter 10, since
  before `Job48`. Nothing to write for it.
- **The two extra mechanisms are WITHDRAWN.** `[A]` supplied a tolerance account that covers all
  nine sketches from three statements about the orientations, so his rule carries them on its own
  after all.
- **The Nine's fourth paragraph is sound; its closing line contradicts it.** One line to repair,
  and it is not doctrine.
- **The competences at any depth are sound.** `[C]` argued they were not and `[A]` corrected it.
- **Seeing is not a higher grade** — consequences checked, one sentence owed in the health axis
  chapter.
- **The aligned types** — one sentence owed in the grid chapter, written positively and said once.
- **The parallel** was unrecoverable from the record and `[C]` recommended dropping it. `[A]`
  reconstructed it from memory and it is the descent loop, closure 4.

## Two things this session opened

- **The intervener account has no drafted home.** It is closure 6 and the largest thing ruled
  here. It belongs to the rising half of the health axis chapter, which is the thinnest part of
  book 2. **`[A]` deferred it deliberately. Do not attempt it while applying closures** — writing
  a section that does not exist is a different job.

- **`[C]` failed the same way twice in one session** and `[A]` caught both. It generalized a
  sentence from the Nine's sketch, and a sentence from the four fates, without reading the
  qualifying sentence that governs each. Both qualifiers were in Chapter 15. **This is the 08-29
  pattern still running** — the thinking lands in the crossing and health-axis chapters and
  nothing carries back to where the reader meets it. It is the reason the next session is
  drafting.

## A practice question, not settled

`Job48` flagged one item as *worth a session's attention on its own* and left it out of the
record entirely. It survived only in the set note, in `Job48`'s paraphrase, using a word that
may not have been `[A]`'s. **What a set note may carry that the record does not is undecided,**
and this is the second kind of gap in the record found in three sessions.

## The set

Everything that arrived, plus this note and the closures file. The kind 11 row's set is job 3's
plus the files carrying the doctrine being composed, and every one of those is already here.
**Not carried, per the 09-04 entry in that row: the eight figures and the seven Part 3 drafting
files.** No queued change references a figure.

**AMENDED 2026-09-06, same session.** `[A]` returned from `Job50` with a doubt about the
aligned-types row and it was right. **`DRAFTING-aligned-types-20260906.md` (1,125 w) replaces
row 8 of the closures file** and says so at its head, so the drafting session does not work from
both. The repair reaches **four sites, not one** — the grid chapter plus the same false clause in
the Three's, the Six's and the Nine's sketches. **The record took a thirtieth append** carrying
what he ruled on 09-06; the twenty-ninth was cut before he came back. **Carry the instruction
file forward marked applied**, on the precedent of `CLOSURES-SITED-job32-20260830.md`.

The label on `MANIFEST-job50-20260906.md` carries the 09-06 date. `[A]` names the session; if he
runs it on a later day, his name governs and the label's date is not a correction to make.
