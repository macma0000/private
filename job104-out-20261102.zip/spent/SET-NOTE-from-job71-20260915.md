---
from: job71-drafting-20260915
to: the session receiving MANIFEST-job72-20260915.md
---

# SET NOTE — from `job71-drafting-20260915`

## Arrival

Incoming zip `job70-out-20260915.zip`, directory `job70set`. Verified **88 ok / 0 mismatched /
0 bad count / 0 missing / 0 not in the manifest** against `MANIFEST-job71-20260915.md`. Screen
fired twice, both benign (the record as CARRY DO NOT READ; the handoff quoting the restriction
string). Record arrived **67,438 w, fifty-first append, marker `Job70 doctrine 09152026`**,
agreeing with `SET-NOTE-from-job70-20260915.md`. A drafting session, so the record was not read.

## What was done

All of `CLOSURES-SITED-job70-20260915.md` is applied, with `[A]` answering the one question it
left open (the widened range is symmetric). He then asked to see each voice change one by one and
reworded most of them himself, and added new material. Everything is itemized in
`CHANGES-job71-20260915.md`, which is the file to read first.

**Output master: `BOOK2-20260915.md`, 37,380 w, md5 `60a65b20`.** Parent in `superseded/`.

**Record: FIFTY-SECOND APPEND, blind.** Head is now **68,463 w, md5 `404cc220`**, marker
`2026-09-15 · job71-drafting-20260915`, parent 67,438 named in the block, in the canonical bold
form. First 397,268 bytes verified byte-identical. `setcheck.py sweep` reads the new marker. The
block quotes `[A]`'s typed lines verbatim and marks the rest as `[C]`'s report.

## Set layout

Directory `job71set`: the job70 set with `BOOK2-20260914.md` replaced by `BOOK2-20260915.md`, the
record appended, `MANIFEST-job71-20260915.md` replaced by `MANIFEST-job72-20260915.md`, and two new
files (this note and the changes file). `superseded/` holds the parent master and the old
manifest; both are outside the manifest and declared here.

## Recommendation for the next session: a coherence run

`[C]` recommends a coherence run on `BOOK2-20260915.md`, as after earlier drafting sessions. This
session wrote new doctrine into the text (the range account, the stress hypothesis, the self as a
piece in a game, the person replacing the parents, passages defined as moves between orientations)
and changed a word used across four chapters. Things for it to check:

- **Ch 7's passage sentence** says *the arising is enthusiastic, the development cautious, the
  ending detached.* Ch 14 now defines each passage as a move between two orientations (arising Z to
  A, development A to B, ending B to Z). The two may be reconcilable (each passage named by where it
  arrives) or may not.
- **`ending` names two things in Ch 14** — a passage (B to Z) and a phase (*the impulse, the
  examination, the ending*). One name per thing.
- **The Five's detached-realm paragraph.** Closure 1 and closure 3 of Job70's file read against
  each other; `[C]` wrote closure 1 only. See the changes file.
- **Ch 15's two *I assume* sentences** sit near sentences that argue from them as settled.
- **The new Ch 13 passage** says a person sees their own self as a fixed object; the paragraph above
  it says the self is not an object. `[C]` reads these as consistent (the second explains the
  mistake the first names) — worth a second look.
- **Ch 2's profiles** were outside this session's scope and still carry the older vocabulary
  wherever they had it.

## Carried for later sessions, not for the coherence run

- **Part 4 — Parallels** is still a sketch in `BOOK2-ARCHITECTURE-20260815b.md` (the poisons and
  the Trimurti first). `[A]` asked about bringing that material into book 2 and agreed it is Part
  4's. Two rulings to carry into it: **the three poisons correspond to the fixations**, and **the
  Trimurti corresponds to the three passages, not the orientations** — Brahma the arising, Vishnu
  the development, Shiva the ending. It needs chapters worked out before drafting.
- **Book 1 defect:** in `rev2-0814t.md`'s Buddhist section, the sentence beginning *The model makes
  the same claim about the orientation cycle* ties the Trimurti to the orientations, against book
  1's own Trimurti section and its list of what is borrowed. For a book 1 session.
- **The widened range in both realms.** Whether health widens the range in both realms together is
  `[C]`'s derivation, not ruled. Ch 10 speaks realm by realm and does not claim it.
- Still open from Job67 and Job70's files: what the settling is when two fixations pull opposite
  ways at one crossing.

## Working with `[A]` — what worked this session

- One thing per message. He asked to see each change one by one and reworded most himself; showing
  the before and the after, with the sentence around it, was what he could work with.
- He chooses the strength of each claim himself: *my proposal*, *I propose*, *I suspect*, *I
  assume*, *what I have seen is*, *what I call*, *corresponds to*. Do not collapse these back into
  one form.
- `[C]` twice showed him its own paraphrase as though it were the book's text (*a standing
  preference*; *the orientations are named after the phases*). Quote the book's sentence when asking
  about a claim.
