# SET NOTE — from `job100 drafting 20261030`

This note goes to the session that receives `job100-out-20261101.zip`. `[A]` gives the kind of session. The manifest label
carries only the counter and the date: `job101-20261101`.

## Arrival

`[A]` named the session `job100 drafting 20261030`. `job99-out-20261030.zip` verified against `MANIFEST-job100-20261030.md`:
57 ok, 0 mismatched, 0 bad count, 0 missing, 234 not in the manifest, all in `spent/` and `superseded/`. The screen marked
the record carry, do not read; every drop hit was a name in `superseded/` or `spent/`. The record's last marker matched
`Job99`'s note: hundred-and-first append, 106,615 w. The record was not opened.

## The job

`CLOSURES-SITED-job99-20261030.md`, Parts A to D, as `[C]` recommended: the order, the word rulings, the doctrine additions
and the repairs. While it ran, `[A]` sat with `Job99` in parallel and pasted five relays from it; each is saved byte for
byte and changed what was applied. Every change was shown to `[A]` in place, new words in square brackets and the words
going out listed, and applied on his answer. **Every site and his words for each are in `CHANGES-job100-20261030.md`.**

## What was done

`BOOK2-20261029b.md` (44,666 w) became **`BOOK2-20261030.md`**. In short:

- **Order.** The new chapter *What Becomes of a Fear* (chapter 15; the book now runs to 18 chapters). *The Three
  Orientations* has seven sections. *Equal positions, and the mirror pairs* and *Where the two systems disagree* moved up.
  *Underneath the Cycle* has *The caution end and the enthusiasm end*. *Spoiled arrivals*, *Two things that cannot happen*
  and *The last stretch* moved within *Falling and Rising*; *Rising* is split into *Rising*, *The oldest material* and *A
  skill for handling fear*; *The second way down, which is not blindness* is now *Discomfort blocking and the fall*.
- **Words.** *settled* (and a fear is settled only at the caution end), *mixed*, the contest paragraph cut, the facing side
  named *the imagined pain associated with facing buried material*, *depends on* for *turns on* and *direct … at* for *turn
  … on*.
- **Doctrine additions, as the relays changed them.** What happens to a fear at each end of the detached phase for every
  fixation (*Which fixation handles a fear*); where discomfort blocking happens; the pain of life not working first named in
  *Rising*; the cause and effect said with the pain of staying; fear and pain in *Rising*; Part 3's opening with his two
  subjects; the cycle chapter's order standing on the orientations, with the classical directions corresponding and
  predicted.
- **Repairs.** The aligned types; Riso and Hudson's two books named; the Eight's last paragraph; *What self-reference does*
  (with his point about the body as a different kind of self); the forward reference in the leans chapter; *Habit carries
  it*; *This describes a small number of people* (with his sentence on energized and burdened); five sites of nothing used
  before its explanation; the say-it-once items.
- **Decided not to change:** two restatements kept because they stand far from the first statement (discomfort blocking,
  about 12,000 words on, which `[A]` asked about; motivation crossing, about 24,000); the pain-or-pleasure paragraph kept as
  the full statement after the short one; *Ignoring leaves a tension in the body* kept as the plain short statement before
  the defined term.

**Ruled in this session**, with his words in the register and style guide: density and terseness fixes wait for his paper
read (*put them off.*); *depends on*, *direct … at*; a fear is settled only at the caution end. **Register letter `r`**
(`WORD-RULINGS-book2-20261101.md`), two patterns added, each firing 22 times on the parent master and on none of the new.
**Style guide letter `n`** (`STYLE-GUIDE-20261101.md`). `wordcheck.py` run on the new master; every hit for this session's
patterns read. `quotecheck.py sweep` run over the set; this session's files carry no quotations.

## The record

One append, the **hundred-and-second**, blind: `[A]`'s words in the session, verbatim, each with what it answered, and
`[C]`'s report with its errors. **Parent 106,615 w, head 107,759 w.** The parent's 635,618 bytes were checked unchanged at
the join.

## Moved

- To `superseded/`: `SUPERSEDED__live__BOOK2-20261029b.md`; `SUPERSEDED__live__WORD-RULINGS-book2-20261030.md` (letter
  `q`); `SUPERSEDED__live__STYLE-GUIDE-20261030.md` (letter `m`); `MANIFEST-job100-20261030.md`.
- To `spent/`: `SET-NOTE-from-job99-20261030.md`; `PROPOSED-ORDER-job99-20261030.md` (its order is now the master's).
- **Kept live:** `CLOSURES-SITED-job99-20261030.md` (Parts E, F, G owed); `FINDINGS-job99-20261029.md`; the six relay files,
  until a coherence run checks the master against them; `HANDOFF-20261029.md`, now further behind (letters, sessions, open
  list) — this note and the changes file cover the difference.

## What is owed

- **Show `[A]` first:** the enthusiastic person's sketch, *The detached phase gets very little attention, so little is
  settled there before the next want is raised.* — *there* was taken out under his 10-31 ruling, found by the new pattern,
  and not yet shown to him.
- **A coherence run on `BOOK2-20261030.md`**, as the closures recommend after each drafting session. It should check the
  master against the six relays, then move them to `spent/`; run the tracking check on a fear through the new chapter;
  and update the claim inventory, which this session did not touch — including the cycle chapter's new claim that the order
  predicts the classical directions for each type, shown at *The Figure's Own Lines*.
- **To drafting, later:** the closures' Part G (letters in Part 3, pilot first), then Parts E and F (glossary working file,
  openings, *New words in this chapter*). Ask `[A]` before drafting any section summary. The arhat paragraph in Part 3's
  opening is decided in the openings pass.
- **Waiting for `[A]`'s paper read:** density and terseness, including the paragraphs that open by pointing back (ten in
  the inner-world chapter, fourteen in *Falling and Rising* at the last count); the *Disregarding* leans paragraph's
  *turns away from noticing* followed by *usually ignored* (relay of 10-31b, item 1); *Each of the three also comes with*
  at the head of *Being caught, and what a person can bear*, whose referent is now a section back.
- **For a doctrine session:** the record's index of subjects; the handoff's §6.1 backlog.
- **For a tools session, optional:** `wordcheck.py` has no Part-3 scope.
- **For a handoff session:** the 10-29 handoff is behind by two sessions and three relay-carrying sittings.
- **Still waiting:** the writer 2 pass, on Toby Marshall; the Introduction on recognition, on `[A]`.

For any session that shows `[A]` a change: bold does not show on his screen. Mark new words with square brackets and list the
words going out underneath.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261030.md`**. The kind is `[A]`'s to say.
