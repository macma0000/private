# FINDINGS — `Job83 coherence 20261016`

Cut 2026-10-17. The session opened 2026-10-16 on `job82-out-20261016.zip` (manifest label `job83-20261016`) and
ran against **`BOOK2-20261016.md`** (42,986 w, md5 `7612914c`), cut by `Job82 drafting 20261015`. During the
session `[A]` carried two exchanges with `Job81 doctrine 20261013` into this one; both are relays and are marked so.

**A drafting session works from this file alone.** It holds every fault this session found and every ruling `[A]`
gave here. **This session wrote no book text.** Where a row carries a wording `[A]` approved, the drafting session
uses that wording and still shows him the sentences around it, before and after.

**Every site was located by content in `BOOK2-20261016.md`, which this session did not edit.** Each blockquote below
is a sentence of that master, checked with `quotecheck.py quotes`. `[A]`'s words are given in italics and are never
put in blockquotes. Neither are `Job81`'s.

**How the rows are marked.**

- **NOT RULED** — a `[C]` finding not put to him. Do not act on it without asking `[A]`.
- **RULED** — `[A]` said it, and his words are given. Where he ruled by agreeing to a question, the question is
  given with his answer.
- **`[C]` DECISION** — a call this session made inside a ruling, without asking. The drafting session shows him the
  result.

---

## PART ONE — FAULTS IN THE MANUSCRIPT

### 1. The comparison of pains: the facing side is not an amount that grows with depth

**RULED 2026-10-16.** Asked *Does the pain of facing that a person weighs stay "imagined to be unbearable" at every
depth, so that only the pain of staying sets where a person settles?* — after `[C]`'s reading that the older
paragraphs must be brought into line, and that the actual pain of facing may still be greater further down while the
pain weighed is the imagined one: *yes*.

The new doctrine, in *Why this does not take everyone to the bottom*, stands:

> The person imagines that facing the buried fear would be unbearable, without any idea of how much facing would actually hurt.

At fault, in the same section — each treats the facing side as an amount that grows with depth, or sets a person
where two amounts cross:

> That also gives the pushback its shape. As consequences accumulate, the pain of staying rises, and at some point it passes the pain of facing — and the person faces the fear.

> But the other term rises too, and for the same reason: further down there is more to unbury, so facing hurts more. Both terms climb together as the fall goes on, and where a person sits is where the two cross.

> The pain of facing does not fall along with the pain of staying: what is left near the top is the oldest material, which was never an idea and can only be reached by how it feels. The climb ends where the falling term drops below the one that does not, and that is the middle.

**The repair, as a claim.** The pain weighed on the facing side is imagined to be unbearable, at every depth. So the
pain of staying alone sets where a fall stops and where a climb ends: a fall goes on until staying becomes
unbearable, and a climb ends when staying stops being unbearable. The oldest material is no longer the reason the
facing side stays high; the 10-16 doctrine covers all buried pain. *The pain of facing does not fall along with the
pain of staying* may stay as true, with the reason replaced. Whether the actual pain of facing is greater further
down may be said or left; it is not what is weighed.

**Read with these paragraphs and check against the ruling:** *Consequences do not arrive and then pass* (the pain of
staying working the whole time — holds); *That raises a question. Against a force like that, nobody should go on
falling at all* (its answer is the cut sentence — the question needs a new answer from the ruling: staying is not yet
unbearable); *That slowness is what makes a climb possible* (holds, read as staying staying unbearable for a while).

### 2. The pain of staying: the whole felt pain counts, and desperation opens a person to something new

**RULED 2026-10-17**, in three answers.

Asked *When staying becomes unbearable, is that the whole felt pain of staying, or only the part the person connects
to their own condition?*: *the felt pain rises until staying is unbearable. at that point the person is open to
trying something new.*

Asked *Should the sentence say that only then is the person open to trying something new, with facing the buried fear
as one of the things they might try?*: *yes. desperation is no guarantee that facing their fears is the first thing
they try.*

Asked *Is that the reason to give? Far down, the pain of staying still makes a person open to trying something new.
But the person cannot see their own condition, so they are unlikely to try facing the buried fear without someone who
can see it.*: *yes. but minor intervention is common. people have friends and friends will constantly try to help.*

At fault:

- *Why this does not take everyone to the bottom*, the two-pains paragraph, last sentence — facing is one thing a
  person open to something new may try, not what desperation brings:

> Only then does the person face the buried fear.

- *What reaches someone the consequences no longer reach* — counts only the connected part, and gives that as why a
  person far down needs someone else:

> What it adds to the comparison is only the part a person can connect to their own condition, and making that connection is what blindness takes. So the pain of staying goes on rising while the part of it that can be weighed does not.

> Far enough down, that stops being enough. Not because the effort fails, but because a person at depth cannot generate the one thing the comparison needs — a belief that anything could be different — since that belief is about their own condition, and their own condition is precisely what they cannot see.

  The ruled reason: far down, the pain of staying still makes a person open to trying something new; the person
  cannot see their own condition, so is unlikely to try facing the buried fear without someone who can see it.
  *Consequences count only as far as they are understood* and *A person feels a consequence whether or not they
  understand where it came from. The job is gone, and that hurts.* are read against this: the second stands; the
  first falls with the counted-part claim.

- *Rising* — the same counted-part claim:

> The pain of life not working weighs only so far as the person connects the failures to fears left unfaced.

  and the sentence after it, which depends on it. Under the ruling, without the connection a person in pain is still
  open to something new, and what they try may be anything that promises relief.

- *Rising*, the oldest-material paragraph, last sentence: *Desperation is then what is left to move the person.*
  Desperation now moves everyone on their own. Read it against the ruling; the paragraph's own point (the person
  cannot tell how much of the pain comes from the oldest material) stands.

**Minor intervention is common** (`[A]`'s words above). The intervener passage reads as if help comes mainly from
someone who has been where the person is:

> Sizing the amounts takes sight of the truth being given, so an intervener has to be able to look at it themselves — which is usually why it is someone who has been where the person is.

The drafting session adds that friends constantly try to help, at a site of its choosing in *What reaches someone the
consequences no longer reach*, and shows him.

### 3. An ignored aversion is not kept in view

**RULED 2026-10-17.** Asked *Should "stays in view" become something like "the matter behind an ignored aversion can
still be noticed, so the person can give up the want behind the aversion"?*: *the matter behind an ignored aversion
can still be noticed. it's available, not necessarily in view.*

At fault — the ignored aversion kept in view, against the ruled account that ignoring never leaves the fear or the
want, and against the same section's ignored fear that drops out of mind:

> An ignored aversion is noticed and let alone, so the ignored aversion stays in view.

> An ignored aversion is still in view, so the person can give the ignored aversion up.

The repair says what `[A]` said: the matter behind an ignored aversion can still be noticed — available, not
necessarily in view — so the person can give up the want behind the aversion. *An ignored aversion can later be
given up. A buried fear can only be faced.* stands, read the same way.

**And the ignored disappointment. RULED 2026-10-17.** Asked *Should the sentence say that an ignored disappointment
leaves the matter unresolved and some bodily tension, and that the matter raises the aversion again when it comes up,
rather than that the aversion itself is left behind?*: *yes.*

> And a disappointment at a gratification ending that is ignored leaves an aversion behind, and the aversion adds to the unease.

### 4. Chronic unease needs buried fears or ignored aversions

**RULED 2026-10-17**, in two answers. Asked *Can unease become chronic through the unease loop alone, with nothing
buried or ignored behind it?*: *Where a person has neither buried fears nor ignored aversions there is no unease.
ordinary pain still comes and goes. But no distraction is needed to cover the pain.* Then shown that this collides
with the house sale, where every turn is worked through and the person is uneasy, and asked which way the two fit:
*Where a person has neither buried fears nor ignored aversions there is no chronic unease.*

So a worked-through unease loop leaves unease while the matter is live; unease becomes chronic only where buried
fears or ignored aversions lie behind it.

At fault, in *The unease loop*:

> Bodily tension is uncomfortable in itself, so the unease loop can go on after the matter that started the unease loop has stopped mattering. So unease can become chronic.

The sentence came from `[A]`'s own relayed wording (`Job82`'s changes, Part B). Show him the change.

The last paragraph of the section takes his sentence:

> Where a person has neither buried fears nor ignored aversions, ordinary pain still comes and goes. But no distraction is needed to cover the pain.

**Show him, with the change above** — each says a span of years:

> The unease loop is ordinary. A person can run the unease loop for years without thinking of themselves as troubled.

> Every turn of the unease loop is worked through and nothing is buried, so the unease loop can keep a person uneasy for years without moving the person down the health axis.

### 5. The enthusiasm end: no unease loop about the unease

**RULED 2026-10-17.** `[A]` asked *why do you say "and an unease loop about the unease goes on."?* `[C]` answered that
the sentence is book text and that by the book's own definition what it names is not the unease loop: no new fear,
nothing worked through. **Relay from `Job81`** (`[A]` pasted the exchange): `[A]` to `Job81`, *i didn't write that
part. with an enthusiastic person, i don't think the fear comes back. is that correct for ignoring?*; `Job81` traced
the sentence to `Job70`'s account of 10-12, carried into the closures in error, and proposed the cut. `[C]` noted that
the passage is about a detached person leaning toward enthusiasm, not an enthusiastic person, and that for that person
the book already says an ignored fear comes back with the next occasion. Asked *Cut "an unease loop about the unease
goes on", and use that wording in its place?* — the fear is ignored and drops out of mind; it leaves some bodily
tension, which fades; and the fear is raised again when the person next meets the problem: *yes*.

At fault:

> At the enthusiasm end, then, the unease loop about the sale ends, and an unease loop about the unease goes on.

**`[C]` DECISION.** The paragraph before it describes the same thing and goes with the cut, folded into *leaves some
bodily tension, which fades*:

> The unease stays. Now the want is to make the unease go away. A distraction does not remove unease. A distraction only keeps the person occupied. So the want to be rid of the unease is not met, and the want is raised again with nothing in particular to act on.

*Near the enthusiasm end the only way out is through the person's capacity to bear discomfort* stays, read as bearing
the tension instead of reaching for a distraction. The ongoing want for relief is covered where the book treats
distraction and gratification.

**Stands, on this ruling:** *Every turn of the unease loop is worked through and nothing is buried* in the health axis
chapter. `[C]`'s first recommendation, to change it, is withdrawn. The name *unease loop* belongs only to the
worked-through round the book defines.

### 6. Gratification: what brought the relief

**RULED 2026-10-17.** Asked to change the sentence to *But the relief came from expecting less, and not from the
behavior.*: *yes*.

> But the relief came from the wearing off, and not from the behavior.

The paragraph before it says the wearing off made the person feel worse; the relief came from the lower expectation
the wearing off leaves behind (`[A]` 10-15: *the baseline gratification has lowered*).

### 7. Book 1 named in book 2

**RULED 2026-10-17.** Asked whether to keep the name or drop the sentence: *drop it.*

In *Where the Types Come From*, the crossing paragraph:

> Book 1 calls that the critical confusion, arrived at here from the orientations.

### 8. The migraine passage: what was buried, and what carried over

**RULED 2026-10-17.** **Relay:** `[A]` to `Job81`, pasted here: *I'm saying that there was buried material. the person
learned how to control her reflex to resist and that carried over to the reflex of the blindness loop.* `Job81`
proposed *automatic*, not *reflex* (the 10-06 ruling), and a closing paragraph saying her turning away came after some
noticing. `[C]` objected that a turning away after noticing makes the fears ignored, not buried, and that what she
could catch was the anxiety the blindness loop runs on, which is felt. `[A]` asked to *show the whole thing*; shown the
passage before and after, he answered: *yes but "What I have seen" - keep me out of it.*

**PERSONAL — NOT FOR THE BOOK.** `[A]`'s background on the woman (her long struggle with a compulsion, and friends
with the same problem who supported her) is for understanding only. *probably not to go into the book.* Nothing of it
goes into the book.

At fault:

> She could notice her resistance because the resistance was not too deeply buried.

> What I have seen since is that she went further.

**The wording `[A]` approved:**

- *What I have seen since is that she went further.* → *Later she went further.*
- After *She already understood that buried material has to be faced.*, add: *What she had learned with the pain was
  to stop an automatic resistance. The same capacity let her stop the automatic turning away that kept her fears
  buried.*
- *She could notice her resistance because the resistance was not too deeply buried.* → *She could stop turning away
  because her fears were not too deeply buried. Her buried fears were never noticed. But she felt the anxiety that
  came when the buried fears came near, and she could stay with the anxiety instead of turning away.* The two
  sentences after it stay.

**`[C]` DECISION on scope.** *keep me out of it* is applied to this passage only. The book's two other *What I have
seen* sentences, in *The range of detachment* and *The problem of leverage*, are author's-voice forms he ruled for
those claims, and are left.

### 9. The health axis named before it is introduced — NOT RULED

**`[C]` finding, not put to `[A]`.** The unease-loop section is the first place the book says *health axis*; the
chapter that introduces the axis comes after it:

> A person higher on the health axis notices more, and so may notice more unease than a person lower down.

The drafting session puts it to him: keep the paragraph and say there what the axis is in a phrase, or move the
paragraph's point to the health axis chapter. Do not act on it without asking.

---

## PART TWO — WHAT THIS SESSION CHECKED AND FOUND SOUND

- **Read in full:** Part 3 (the Part 3 opening through *The problem of leverage*); the Introduction, Ch 1, Ch 3, Ch 4,
  Ch 5's opening, Ch 6, Ch 7, Ch 10's *As the grip loosens* and *Reading it from either end*, Ch 11. The type sketches
  of Ch 2 and Ch 5 were not read.
- **The comparison of pains**, `Job82`'s first request: every site read. Holding: the toothache paragraph (the
  contrast case); the unease loop's *What moves a person to take a way out is a comparison of two pains* (nothing is
  buried there, so both pains are felt); *A climb is rare, because facing a buried fear means facing what the person
  earlier felt they could not bear*; *Whether the buried fear does come back depends on how much of the arriving
  feeling the person can bear*; *How the comparison ever gets made is a harder question*.
- **The unease loop and the blindness loop** are both defined in Ch 15 and kept apart; with item 5 the name *unease
  loop* has one use.
- ***Gratification* sits in Ch 14** before unease and bodily tension are defined, and says nothing of either. Not a
  fault: the section stands on its own, as `[A]` placed it, and Ch 15 applies it to distraction.
- **The four fates and disappointment**: the re-cut *worked through*, the four fates of a disappointment and *every
  fate leaves bodily tension* read consistently at every site in Ch 14 and Ch 15.
- **`wordcheck.py`** against register letter `i` was run by `Job82` on this master (162 hits, all read). This session
  re-ran it (160 lines by a count of tagged lines) and did **not** re-read the hits; nothing in the master changed
  since `Job82` read them.
- **Tracking check:** run on the **pain of staying** (from consequences, through the comparison, to facing or trying
  something new) and on **unease** (from a fate's bodily tension, through the unease loop, idle discomfort and
  distraction, to the ways out). Items 1 to 5 are what they found.

## PART THREE — OWED

- **Register letter `j`** is cut with this file (`WORD-RULINGS-book2-20261017.md`); its section 5a carries items 1,
  2, 4 and 5 for the vocabulary they govern.
- **The claim inventory** now has entries for *The unease loop*, *Gratification* and Ch 14's re-cut *Disappointment*
  (update block of 2026-10-17).
- **The handoff is stale** — still `HANDOFF-20261005b.md`. Live now: master `BOOK2-20261016.md` until the next
  drafting session, register letter `j`, style guide letter `e`.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.
