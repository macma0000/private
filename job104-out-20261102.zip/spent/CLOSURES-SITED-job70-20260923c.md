# SITED CLOSURES — `Job70 doctrine 09152026`, sittings two through five

Cut 2026-09-23, later the same day. **Supersedes `CLOSURES-SITED-job70-20260923b.md`**, and with it
`…-20260923.md` and `…-20260916.md`.

**One sentence in the superseded file was struck rather than repaired. See the strike below before
anything else.** A coherence run found it by collision.

Site and claim, never the sentence. A drafting session writes the sentences.

**Not applied. Nothing in this file has been carried into any master.**

**No sitting had a manuscript or the record in hand.** The append block is at the end, for a later
session to carry.

**The word rulings are carried here as an addendum to be merged**, not cut as a new lettered file,
because the copy in hand is the 09-16 one and `Job74` has changed things in it since.

---

## STRIKE — a sentence recorded as ruled that `[A]` never ruled

The superseded file records this as ruled:

> A detached realm releases no action of its own … Where a detached person acts, the action comes
> at the cautious phase, because fixing and forgetting are both avoiding, and avoiding is fending
> off.

**`[A]` never answered that claim.** `[C]` wrote it late in the fourth sitting; his next message was
about the standing dislike and about reserving `aversion`, and `[C]` recorded the action claim as
ruled anyway. **It is struck, not repaired.** What replaces it is below, and it is narrower.

**This is the third time this session has recorded its own reading as something a drafting session
may act on.** The `attention` closure was the first, the *nothing directing the looking* sentence
the second. A `[C]` line in this file is not actionable.

---

## The corrections that follow from the strike

**The tie between the lean and the standing dislike loses half.** The superseded file says the lean
sets which kind of avoiding serves the dislike, fixing or forgetting. **Forgetting is not
avoiding**, so the lean sorts nothing of the kind. The lean keeps only the job `[A]` gave it on
09-16: it sets whether an arriving fear is processed or ignored.

**The standing dislike of disturbance itself is untouched.** A detached person dislikes disturbance,
and that is why a disturbance gets noticed. What the person then does about a disturbance is placed
by motive, like anyone's.

---

# Where a detached person's action comes (2026-09-23, fifth sitting)

## Ruled

**A detached person's actions are placed by motive, like anyone's.** `[A]`, asked whether the struck
ruling covered only fixing a disturbance: *yes.*

**Fixing is fending off, so fixing comes at the cautious phase.** That is the motive ruling applied
to one case, **not a separate fact about a detached realm.** A Nine smoothing over a conflict is the
example.

**Changing the subject is a want, so distraction comes at the enthusiastic phase.** `[A]`: *Z- fixing
is fending off and Z+ changing the subject/distraction/ignoring is a want.*

**The Z+ sketch in the fixations chapter stands as written** — *an impulse toward something
enjoyable arises and goes straight to action* — which is going toward, with the examining cursory
because little attention reaches the cautious phase.

## Context from `Job75`, ruled there and not here

`[A]` ruled in the coherence run the same day: **a fixation is a fixed place on the orientation
cycle, and wants and fears are processed in the enthusiastic and cautious phases even for a detached
fixation, just less intensively.** Recorded here because the struck sentence was built on the 09-16
ruling that a detached realm generates nothing, and **that ruling may now be too strong in the same
way the struck sentence was.** `[C]` flagged it and did not pursue it. **A detached realm's wants
now have three sources: the lean, the person's other realm, and the person's own cycles in the
detached realm.**

---

# The feeling and the content of a fear (2026-09-23, fifth sitting)

## Ruled

**A fear has a feeling and has content — what the fear is about — and the two come apart.** `[A]`:
*i would separate feeling from seeing. fear is a feeling as well as having content. i think an
ignored fear continues to be a feeling but the content continues to be ignored.*

**An ignored fear keeps its feeling. The content goes on being ignored.**

**Ignoring means taking no action about what the fear is about, and the fear remains.** `[A]`: *i
think a fear remains after being ignored - ignoring means taking no action. there is a desire to
stop awareness of the fear.*

**So the want that follows is a want about the feeling, not about the thing feared.** A person who
distracts is getting away from the feeling while the content stays untouched.

**Forgetting is a later stage of ignoring, when the feeling has subsided.** `[A]`. **This keeps his
09-12 ruling that forgetting is the same fate as ignoring, and gives it a mechanism** — one fate
seen at two times. The fear stopped being raised because the feeling stopped, not because anything
was settled, so the problem may still stand and later raise the fear again.

**Burying and ignoring are one move made at two strengths of feeling.** Burying is the same turning
away, at a feeling the person cannot bear. `[A]`: *that is the only difference at first, but the
fear of fear feedback loop leads to more differences.* **Everything that separates them afterwards
is produced by the loop, not present at the start.**

## `[C]` readings — NOT ruled, and not actionable

- **The bodily tension is what an ignored fear is.** The bodily tension was ruled 09-12 as the
  short-term holder of a feeling of fear with no object, which is the feeling with the content left
  ignored. If so it is not a separate mechanism.
- **A buried fear cannot be found by looking for the original.** The loop is named *fear of fear*,
  so the feeling becomes what the next fear is about, and the content a buried fear carries is no
  longer the thing first feared.
- **A climb is harder than the original turning away was**, since the loop has made the feeling
  worse than it was when the person turned away. That fits `[A]`'s 09-21 ruling that climbs are rare
  because they require facing what the person earlier felt they could not bear.
- **The four fates need weakening where they are stated as a fear meeting its fate.** Worked through
  and given up on end a fear. **Ignored and blocked leave a fear standing**, which is what `[A]`'s
  own 08-31 `unattended` ruling already says.

---

## The rows

| # | Site | What changes |
|---|---|---|
| 1 | `ARC-ACCOUNT-from-job72-20260916.md` §6, the truncated-cycle case — *the action happens at the ending* | The angry remark's action comes at the cautious phase |
| 2 | Ch 4, where detachment is introduced | New: detachment is not indifference, and a detached person minds disturbance. No figure named |
| 3 | Part 3, where fixation and Naranjo are introduced | New: the class defined in the sentence, `buddha` named second, lower case, outside the model |
| 4 | Wherever the detached realm's wants are described | The standing dislike of disturbance belongs to detachment itself, present at zero lean. **The lean sets only whether an arriving fear is processed or ignored** |
| 5 | Wherever `aversion` appears outside the cautious phase | `aversion` is the class word for fear and disappointment only |
| 6 | `ARC-ACCOUNT-from-job72-20260916.md` §6, the stress hypothesis line | Restated: stress cuts short the work of a person's own phase, and the person acts on what is in hand unworked. The *I suspect* marking comes off the cautious case and stays on the enthusiastic and detached cases |
| 7 | Wherever a detached person is described as acting | **Placed by motive, like anyone's.** Fixing comes at the cautious phase; distraction comes at the enthusiastic phase |
| 8 | The Z+ sketch — *an impulse toward something enjoyable arises and goes straight to action* | **NO CHANGE.** Recorded so a later session does not reopen it |
| 9 | Wherever a fear is described as meeting a fate and being finished with | A fear has a feeling and a content. Ignored keeps the feeling and leaves the content |
| 10 | Wherever forgetting is distinguished from ignoring | One fate at two times: forgetting is ignoring after the feeling has subsided |
| 11 | Wherever burying is distinguished from ignoring | One move at two strengths of feeling. The loop produces every later difference |
| 12 | The bodily tension, where the mental deposits are explained | **`[C]` reading only. Ask `[A]` before writing anything** |

---

## To be merged into the word rulings file — NOT cut as a new letter here

Under **§2**, amend the `lean` entry:

> **Detachment's standing dislike of disturbance does not come from the lean** (RULED 09-23). The
> lean sets whether an arriving fear is processed or ignored (RULED 09-16) **and nothing else**.

Under **§4a**, amend:

> **`aversion` is reserved to the cautious phase** (RULED 09-23). Fear and disappointment are the
> two aversions. **Detachment's is a standing dislike of disturbance, never called an aversion.**
> `[A]` accepted the name and called it *a little clumsy*; a drafting session may propose a better
> one to him and must not substitute one silently.

Under **§5**, amend:

> **A fear has a feeling and a content** (RULED 09-23). **Ignored** keeps the feeling and leaves the
> content. **Forgotten** is ignored after the feeling has subsided. **Buried** is the same turning
> away at a feeling the person cannot bear, after which the fear-of-fear loop produces the
> differences.

Under **§7**, add:

> **buddha** — RULED 09-23. Lower case, no article, **the class defined in the sentence before the
> word appears**. Names a state, never Gautama. Used once, in Part 3.

Add to the patterns block:

```
buddha | \bbuddh\w* | all | lower case, class defined first, Part 3 only (RULED 09-23)
aversion-scope | \baversion\w* | all | cautious phase only (RULED 09-23)
```

---

## For a later session to append to the record

Append after the record's current last marker, naming the parent count from the marker that session
finds. Canonical bold marker form.

```
## `Job70 doctrine 09152026` — sittings two through five, appended on its behalf

**Provenance.** `[A]` returned to `Job70` on 2026-09-16 and three times on 2026-09-23, each time
with no manuscript and no record in hand, so `Job70` could not append. Blockquotes are `[A]`'s
typing. Everything else is `[C]`'s report.

**Where action happens, 09-16.** `[A]` asked whether the angry remark in his truncated-cycle example
comes at the cautious phase, *since it's motivated by aversion*. `[C]` withdrew its own placement.
Asked whether a desire to be rid of something counts as an aversion, `[A]` answered that both can
happen, that a person fixated in caution feels it as aversion and one fixated in enthusiasm might
not, and that *there is happy aggression and angry aggression*. **Ruled: an action is placed by the
motive behind it — going toward at the enthusiastic phase, fending off at the cautious phase — and
the same outward act can be either.**

**The boundary of the model, 09-23.** Asked whether a detached person's want for peace is
motivation, and where it comes from:

> is a detached person with no leans the same as a buddha with no attractions or aversions. i think
> not and that is new to the book. a detached person is still averse to disturbances while a buddha
> is indifferent to them.

**Ruled: the dislike of disturbance is present at zero lean and belongs to detachment itself. A
person with no attraction and no aversion at all is outside the model.** On naming it, `[A]` wanted
the class rather than Gautama; `[C]` recommended defining the class in the sentence and naming the
word second, and `[A]` took the recommendation.

**Panic, 09-23.** `[A]`: *on fear.* **Ruled**, which puts panic's action at the cautious phase.
`[C]` then showed the stress hypothesis's old wording does not fit the cautious case, since the
cautious phase raises its own fear. **Ruled, `[A]`: *yes*. Stress cuts short the work of a person's
own phase, and the person acts on what is in hand unworked.**

**`aversion` scoped, 09-23.** `[A]`: *i question my use of the word aversion - i think it should be
reserved to cautious phase*, and *detached always wants to avoid disturbance whether or not the
disturbance is the same or different.* **Ruled: `aversion` is the cautious phase's; detachment's is
a standing dislike of disturbance.** On the name: *it works. it's a little clumsy but i can't think
of an alternative.*

**A `[C]` sentence struck, 09-23.** A coherence run found that `Job70` had recorded as ruled a
sentence `[A]` never answered — that a detached realm releases no action of its own and that every
action of a detached person comes at the cautious phase. `[A]` narrowed it:

> Z- fixing is fending off and Z+ changing the subject/distraction/ignoring is a want.

**Ruled: a detached person's actions are placed by motive like anyone's. Fixing comes at the
cautious phase because fixing is fending off. Distraction is a want and comes at the enthusiastic
phase.**

**The feeling and the content, 09-23.**

> i would separate feeling from seeing. fear is a feeling as well as having content. i think an
> ignored fear continues to be a feeling but the content continues to be ignored. the difference
> with burying is that the fear is amplified by the feedback loop.

> i think a fear remains after being ignored - ignoring means taking no action. there is a desire to
> stop awareness of the fear.

> i think forgetting is a later stage of ignoring when the feeling has subsided.

> that is the only difference at first, but the fear of fear feedback loop leads to more
> differences.

**Ruled: a fear has a feeling and a content. Ignoring leaves the content and keeps the feeling, and
the want that follows is about the feeling. Forgetting is ignoring after the feeling has subsided,
so his 09-12 ruling stands with a mechanism. Burying is the same turning away at a feeling the
person cannot bear, and the fear-of-fear loop produces every later difference.**

Sited in `CLOSURES-SITED-job70-20260923c.md`.
```
