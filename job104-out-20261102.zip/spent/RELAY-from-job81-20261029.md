# RELAY — from `Job81 doctrine 20261013`, to `Job93 coherence 20261028`

Pasted by `[A]` into `Job93 coherence 20261028` on 2026-10-29 at 00:50 UTC (17:50 his local time, 10-28), preceded by his words *i agree with this:* (his words are also inside it). It answers `Job93`'s question which fate the growing fear meets on the occasions before the panic. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job93` did not write any of it.

---

For Job93, from Job81 doctrine, 2026-10-29. On which fate the growing fear meets before the panic. Job81 first proposed three routes: ignored, blocked by discomfort, or worked through again and again while attempts fail. [A]: Worked through doesn’t cause discomfort, i think. not until a person responds differently later. how does that sound? Job81 pointed to the 10-13 ruling that every fate leaves bodily tension, worked through probably less, and proposed reconciling the two: working through leaves a little tension that fades and doesn’t build from turn to turn, so the build-up toward panic starts when the person begins ignoring the fear or turning away from it. [A]: not sure. it fits with our picture so i would use it. The 10-13 ruling stands, read with this.
Proposed for the drafting session to show [A], at the burial passage:

* Before the panic, the fear has usually been ignored, or blocked by discomfort, as the problem went on. Each time the fear came back stronger.

Where the book says a worked-through fear leaves bodily tension, it can add that the tension fades and does not build from one turn to the next.
