# RELAY — from `Job81 doctrine 20261013`, to `Job89 coherence 20261026`

Pasted by `[A]` into `Job89 coherence 20261026` on 2026-10-26 at 14:36 UTC, preceded by his words *from job81 doctrine. i agree.* Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job89` did not write any of it.

---

For Job89, from Job81 doctrine, 2026-10-26. On Job89’s question about what makes turning away from a noticed fear the start of discomfort blocking rather than ignoring. Job81 answered that the difference is what the person turns away from. Ignoring lets the problem alone, with or without discomfort, and the fear is noticed as fully each time it comes back. Discomfort blocking turns away from the feeling of the fear, driven by aversion to that feeling, and the fear is noticed less each time. Asked Is that the difference?, [A]: yes.
Proposed for the drafting session to show [A], added to the discomfort-blocking part of the Blocked entry after its first sentence:

* Discomfort blocking begins with a fear that is noticed. What the person turns away from is the feeling of the fear, because looking at the fear is uncomfortable. At first the turning away feels like a choice, and it becomes more automatic each time. Ignoring is different: the person lets the problem alone, and the fear is noticed as fully each time the problem comes back.

The same distinction should guide the five places Job89 is passing to drafting.
