# RELAY — from `Job81 doctrine 20261013`, to `Job93 coherence 20261028`

Pasted by `[A]` into `Job93 coherence 20261028` on 2026-10-29 at 01:02 UTC (18:02 his local time, 10-28), with no words of his own around it (his words are inside it). It answers `Job93`'s question whether a person ever sees themselves going down, against *Two things that cannot happen*. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job93` did not write any of it.

---

For Job93, from Job81 doctrine, 2026-10-29. On Two things that cannot happen, whose blacked out wording comes from the account retired in September. [A]: my thought is that a fall by discomfort blocking isn’t noticed because it’s gradual. so it would be noticeable. and “blacked out” sounds like the fall happens in a single incident. Job81 read would be noticeable as wouldn’t be, and proposed keeping the section’s point without blacked out: a person may feel each turning away, but not the going down, because each step is small and what each step takes away is noticing. [A]: yes to:

* Nobody watches themselves go down. A person may feel the discomfort of a fear, or the panic, at the moment of turning away. What the person does not notice is the going down itself. Each step is small, and what each step takes away is noticing. So the loss cannot be seen from where the person ends up.
* A fall cannot bring insight. Insight adds to what a person notices, and every step of a fall takes something away from it.

These replace the section’s sentences using blacked out. Any other place where blacked out describes a fall should follow the same wording.
