# SET NOTE — from `Job59 coherence 09082026`, 2026-09-08

**For the session receiving `job59-out-20260908.zip`. `[A]` names that session; this note does not.**

---

## 1. WHAT THIS SESSION DID

**Nothing was written into book 2.** `BOOK2-20260908.md` and `rev2-0814t.md` are byte-identical to
the copies that arrived. A coherence session does not draft, does not move anything, and does not
rule.

The session ran the two things `SET-NOTE-from-job58-20260908.md` asked for by name.

**The tracking check, on objects other than the fear.** Object followed: motivation. The check found
one disagreement, and `[A]` then rebuilt the account across nine exchanges. **Eight rulings, all
his, all owed prose.** They are in `RULINGS-job59-20260908.md`.

**The referring-word count, run over all of book 2.** It found a fault in the rule and 113 sites in
the prose. `COUNT-referring-words-job59-20260908.md` carries both, with the site table.

---

## 2. ARRIVAL

`job58-out-20260908.zip`, one directory, against `MANIFEST-job59-20260908.md`:
**59 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the manifest.** Screen fired two, both
benign — the record as carry-do-not-read, and `HANDOFF-20260906.md` quoting the restriction string.

Record arrived **50,116 w, thirty-ninth append, marker `Job58 drafting 09082026`, parent 49,081**,
agreeing with `SET-NOTE-from-job58-20260908.md`. Chain clean.

**Recorded for the third run in a row: the kind 12 row still does not name the claim inventory**,
which is the file the kind cannot run without, and the set again carried far more than the row names
— fifty-nine files against a row naming about ten. The standing `[C]` recommendation, now three runs
old and still unruled, is to mint the different-bytes-different-name exception for the inventory
rather than rename a survivor file at every check.

---

## 3. THE DISAGREEMENT THE TRACKING CHECK FOUND

Stated here because the METHOD is what earns its place in the handoff, and this is the second run in
which the method found something four passage-by-passage runs had not.

Ch 4 gives a rule: motivation sets how much of a realm a person takes in. Ch 15 says a detached
realm receives motivation two ways, and that where the fixation sits decides how long a person stays
with an arriving fear. **Follow motivation across those and the caution end should take in a
narrower realm than the enthusiasm end. Ch 15 rules the opposite in its own words** — *What is taken
in is the same at either end of the range.*

Both halves were ruled on 2026-09-07 by different sessions, each correct in its own chapter.

---

## 4. WHAT IS OWED, AND THE ORDERING CONSTRAINT

**`RULINGS-job59-20260908.md` holds eight rulings and their sites.** Every one is owed prose and none
is written.

**Ch 4's width paragraph is written FIRST.** The Two's sketch and the Nine's block both give a reason
using *nothing pulling at them*, and each should refer back to a corrected account rather than be
repaired on its own. Same shape as the constraint `Job57` set for the two-faces paragraph.

**`[C]` recommendation for the next session: kind 11, drafting, taking the eight rulings ONLY.**
Rewriting the 113 referring-word sites is a mechanical pass across nine chapters, and mixing it with
new doctrine prose is close to what produced the trouble `Job58`'s own note describes — prose written
against doctrine that moved underneath it. **The count sites overlap the rulings at Ch 4, Ch 15 and
Ch 17**, so a later pass should drop whatever the rulings rewrote and work the remainder.

The drafting session still writes under the amended count, since a repair made to satisfy the count
is new prose and gets counted like any other.

---

## 5. FOR A DOCTRINE SESSION, NOT FOR DRAFTING

**`[A]`'s observation of his own cautious realm**, given verbatim in §9 of
`RULINGS-job59-20260908.md` and in the record. A fear passing through detachment ignored, through
enthusiasm as something he wants to think about, and back to caution, with the fear's focus often
lost while the wanting to think continues. Three things in it that book 2 does not have, all put as
questions.

**One check owed and not settled:** book 1's three remedies are one paragraph each, and whether one
paragraph each is thick enough for book 2's growth material to point at is for the session that
writes that material.

---

## 6. FILES CUT THIS SESSION

| file | what it is |
|---|---|
| `RULINGS-job59-20260908.md` | 2,090 w. The eight rulings with sites, the unruled vulnerability ordering marked as `[A]`'s, and his observation. **The next drafting session's input.** |
| `COUNT-referring-words-job59-20260908.md` | 4,438 w. The count over 1,901 sentences, the fault it found in the rule, and the 113-site table |
| `RULE-referring-words-20260908b.md` | **supersedes `RULE-referring-words-20260908.md`** — step 1 amended to distinct words. Quarantine the parent |
| `STYLE-GUIDE-20260908b.md` | **supersedes `STYLE-GUIDE-20260908.md`** — section 9 carries the same amendment and points at letter `b` of the rule. Quarantine the parent |
| `refcount.py` | the step-1 checker. Steps 2 and 3 need a reader and are not machine-checkable |

**Both `b` files state their supersession on their own face.** Two letter-cuts in one session, each
forced by the rule that a file with different bytes never keeps a name it has had.

---

## 7. THE RECORD

**FORTIETH APPEND, blind** — this kind does not read the record. Head is now **51,378 w, md5
`1260501c`**, marker `2026-09-08 · Job59 coherence 09082026`, parent 50,116 named in the block.
First **296,631 bytes verified byte-identical** after the append. **52 markers** where there were 51.
Canonical bold form, and `setcheck.py sweep` reads the new marker correctly.

The block states its provenance first and quotes seventeen of `[A]`'s typed passages verbatim,
marking everything else as `[C]`'s report.

---

## 8. NOT DONE

**Steps 2 and 3 of the referring-word count were not run** — finding what a word points at, and
counting how many names one thing carries across a passage, both need a reader. The 113 sites are
step 1 only.

**The per-entry sweep of the claim inventory was not run**, and the inventory is unchanged from what
arrived. This session's product is the rulings file and the count, not an updated inventory.
