# SITED CLOSURES — `Job70 doctrine 09152026` (2026-09-15)

Cut under the standing convention `[A]` ruled on 2026-08-30: a doctrine session cuts a file of
this kind — **site and claim, never the sentence.** Fifth instance. The layout follows
`CLOSURES-SITED-job67-20260912.md`.

**This is not a repairs file and not a note.** Every row is something `[A]` ruled in session,
paired with where it lands. A drafting session writes the sentences.

**Not applied. Nothing in this file has been carried into any master.**

**Master this session read:** `BOOK2-20260914.md` (36,336 w, md5 `1519cef6`). Book 1 was not
opened. Sites are given by content, never by line number, per the handoff's standing rule.

**All three items `SET-NOTE-from-job69-20260914.md` left open are discharged** — `attention`,
the economic register, and whether the two realms' fixation strengths are correlated. The third
turned out not to be about fixation strength at all; see closure 7.

**`NOTE-sections-predating-the-attention-account-20260914.md` was NOT in this set.** `[A]`
raised its content in session and the work was done from what he said. A later session should
check the note against closures 1 to 4 rather than assume agreement.

---

## What was ruled, in plain words

Nine closures and one hypothesis. They are stated here once so the rows can be short.

1. **The fixation governs what lent motivation is turned on.** `[A]` 2026-09-15: *it's right.*
   The 09-07 lending ruling says an enthusiastic or cautious realm lends motivation to a detached
   one, and that what is lent carries no object in the receiving realm. What it does not say is
   what the lent motivation gets used on. **Ruled: what a person turns lent motivation on is set
   by what their non-detached fixation is concerned with.** So a Five does look at psychic
   material, but only psychic material bearing on the physical fear. What goes unnoticed is
   everything else the psychic realm took in. **Being less caught widens what the lent motivation
   is turned on.**

2. **A cautious realm paired with an enthusiastic one runs as an automatic check.** `[A]`
   2026-09-15: *i think the B realm for the one and eight runs as a kind of automatic check on
   everything that is happening while the real focus in on the A realm and gets focus whenever it
   raises an alarm.* **Ruled, and scoped by him to the enthusiasm-and-caution pair only** — he
   corrected `[C]`'s attempt to extend it to the Six. Taking in is whole and needs no motivation,
   which is why a check can run over everything at once. A fear raised by that realm's own arcs
   arrives carrying its own object, and an arriving fear is the alarm.

   **What a One never notices is the guarding, not the psychic realm.** A One notices the
   particular thing that alarmed them, holds off from it, and has no occasion to notice the
   holding off. Caution is what a One looks with.

3. **A fear directs the looking.** Following from closure 2 and `[A]`'s correction of `[C]`'s
   phrase *go looking*: *sixes are looking all the time. what they cannot do is notice what they
   are not looking for.* **Ruled: a person whose motivation all arrives with fears attached
   notices what the fears point at and nothing else.** The looking finds what it went out for.
   A Five looking with lent motivation has nothing directing the looking, so a Five can notice
   what no fear pointed at. A Six has no detached realm and therefore never has undirected
   looking at any level.

4. **Health softens fixations, and softening gives access to the other orientations.** `[A]`
   2026-09-15. This is what answered `[C]`'s worry that undirected noticing might belong to
   detachment permanently, so that a Six and a One could never have it. **They can: a loosening
   person has some detachment available.** This is the same fact the *ahead* account names from
   the other side, so naming and mechanism agree.

5. **`attention` — `[C]`'s reading, NOT a ruling.** `[A]`: *if you want to insist that attention
   is not zero sum, that's ok.* Recorded as a reading a drafting session may work from and a
   later session may overturn without reopening a ruling. Of the 43 occurrences in the master:
   2 are ordinary English and stay; 22 are older vocabulary for noticing or for dwelling at the
   seeing end and translate with nothing lost; 19 make one of four claims — that attention is
   what makes noticing happen, that attention sits in one realm so the other goes unlooked-at,
   that attention is not limited, and that the realms compete for attention. **`[C]`'s reading is
   that the word survives at none of the 19**, because each says either motivation, or noticing,
   or what a fear points the looking at. **The Five's rationing paragraph is the one place the
   idea of a limited supply is correct, because rationing a psychic thing as though it were
   physical is the Five's own mistake** — see closure 6.

6. **The economic family, and `ration` as its only survivor.** `[A]` 2026-09-14 had already ruled
   `cost` a bad metaphor. 2026-09-15, on the thirteen physical-realm sites where depletion is
   real rather than figurative: *it would be good if you can avoid "cost" and "pay" does that
   work?* — and then, on the carve-out: *can you use the verb "ration" instead?* **Ruled: `cost`
   and `pay` are avoidable everywhere and go. `ration` is the only member of the family that
   stays, at the three Five sites.** Everything else in the family was already out under
   `STYLE-GUIDE-20260908b.md` §3. `[C]` verified before answering that each of the thirteen has a
   plain replacement naming what is actually used up — effort, time, damage, discomfort.
   `arithmetic` goes with them.

7. **A lean is an offset of the center; health widens the range around the center.** `[A]`
   2026-09-15: *i think lean is an offset of the center of the fixation on the orientation cycle.
   health would widen the available range and in general, i think a person with a widened range
   would want to live towards the forward part.* **Ruled.** A fixation has a center on the cycle
   and a range around the center. The lean is how far the center is offset from pure, and its
   direction. Health sets the width of the range. A person low on the axis has almost no range
   and is found at the center. A person higher up has range and lives mostly toward its forward
   part.

   **This closes the correlation item and dissolves its original framing.** `[A]` corrected `[C]`
   twice on the way: first that the item is about leans and not about moving to a new type, and
   then that `[C]` was conflating how far a lean runs with strength of fixation. **The two are
   different quantities and Ch 11's sentence about lean strengths being independent between
   realms is about lean distance only. It does not collide with the correlation claim and stands
   as written.**

   **`[C]`'s derivation from the ruling, marked as such.** Width is set by health, health is one
   position for the person, so both realms' ranges widen together — which is the correlation
   `[A]` reported. Centers stay independent, which is why lean direction is free in each realm,
   and why `[A]`'s own psychic center can be offset backward while his physical one is offset
   forward.

8. **HYPOTHESIS, NOT RULED — what stress does.** `[A]` 2026-09-15: *stressed B does seem to move
   closer to A through panic... is there a mechanism for that? jumping to the end of the arc
   early under stress?* `[C]` generalized it: **stress stops a person doing the work of their own
   phase, and what shows is the previous phase's material left unworked.** A cautious person
   stops weighing and acts on an unexamined want, which is panic. A detached person stops taking
   in and disposing, and is left holding fears they cannot dispose of. An enthusiastic person
   stops acting, and nothing arises at all. `[A]`: *yes. let's keep it as a hypothesis.*

   **It is to be written into the descent material in the `I think` voice of closure 9, NOT
   labelled as a hypothesis in the text.** See closure 9 for why the label was dropped.

9. **The author's voice returns, and it replaces hedging.** `[A]` raised the underlying worry:
   *to a varying degree, everything in the book is speculation. i tried to state that early in
   the book. now things are detailed an complex and don't look like speculation.* He rejected
   repeated warnings himself, then asked about `seems`. **Ruled after `[C]` showed that the first
   person appears in the Foreword, the Introduction and the nine type self-descriptions and
   nowhere else — `[A]`: *do it.***

   **The instruction.** Restore the author's voice at the largest claim in each chapter, about
   twenty places. **Two forms only.** *What I have seen is*, where `[A]` has watched something in
   people. *I think*, where the claim is a derivation nobody has checked against cases. **A
   drafting session that cannot tell which a claim is leaves the sentence alone and lists it for
   `[A]`.**

   **Three bars.** No sentence about the book — *I have tried to show*, *this chapter argues* —
   which §1 of the style guide already bars. No third voice form. Each new sentence takes the
   referring-word count like any other new prose.

   **Why `seems` was rejected.** A hedge on every claim alike tells a reader nothing about which
   claims are firmer, and it makes a reader read the claim and then apply a discount, against §9
   of the style guide.

---

## The rows

| # | Site | What changes |
|---|---|---|
| 1 | Ch 5, the Two's psychic sketch — *their attention is in the caring, which is in the other realm, so they do not look* | *They do not look* is too strong. The Two looks at physical material bearing on the psychic concern and at nothing else there. Closure 1 |
| 2 | Ch 5, the Four's physical sketch — *their attention is in the searching, which is in the other realm, so they do not look* | Same repair as row 1. Closure 1 |
| 3 | Ch 5, the Five's psychic sketch — *their attention is in the studying, which is in the other realm, so they do not look* | Same repair, and this is `[A]`'s own case. Closure 1 |
| 4 | Ch 5, the Seven's psychic sketch — *their attention is in the doing, which is in the other realm, so they do not stay* | Same repair. Closure 1 |
| 5 | Ch 5, the One — *a guard that has to be consciously maintained is a guard that lapses the moment something else needs doing* | The clause goes. It claims the guard would fail if attended to, which the model does not claim and does not need. Replace with the automatic check of closure 2 |
| 6 | Ch 5, the One — *their attention is in the doing. The state of their psychic realm is precisely what is running out of view* | What runs out of view is the guarding, not the psychic realm. Closure 2 |
| 7 | Ch 5, the Eight — *attention sits in the realm a person is doing in* and the two sentences after it | Same repair as row 6, with the realms exchanged. Closure 2 |
| 8 | Ch 5, the Six — *it is also the whole of their attention, in both realms at once* | Restate: every fear a Six has raised is attended to, in both realms, and nothing unalarmed is examined. A Six looks constantly. Closure 3 |
| 9 | Ch 10, the types ahead — *two lie a single step ahead, one realm advancing and the other held* | Nothing advances and nothing is held. A range widens and the person lives toward its forward part. Closures 4 and 7 |
| 10 | Ch 10, *as the grip loosens* — *in the realm where the person is less caught, some of the orientation ahead becomes available* | Correct as far as it goes; recast on the widened range so it does not read as the center moving. Closure 7 |
| 11 | Ch 11, the paragraph on lean strength | **NO CHANGE.** Recorded so a later session does not reopen it. Lean distance and fixation strength are different quantities and the sentence is about lean distance. Closure 7 |
| 12 | Ch 5, the Five — the rationing paragraph and *so is its price* | `ration` stays. `resources`, `finite`, `spending`, `spent` twice and `price` go. The summary sentence is the book's own voice, so `price` goes there too. Closure 6 |
| 13 | Ch 5 and Ch 10, the two loosening lines — *rationed as though they were finite* | `ration` stays, `finite` goes: rationed as though they would run out. Closure 6 |
| 14 | The thirteen physical-realm sites in Ch 5 and Ch 15 — the Two's helping, the Four's pushing away, the Nine who can afford to look, the Seven's staying | Say what is used up: effort, time, damage, discomfort. `arithmetic` goes with them. Closure 6 |
| 15 | The seventeen psychic-realm sites — reassurance spent, turning away costing the noticing, the distance costing what every level costs, and the seven in the not-everyone-to-the-bottom section | All go. Each has a mechanism behind it that can be named. Closure 6 |
| 16 | The 22 older-vocabulary `attention` sites, chiefly the range-of-detachment and descent runs | Translate to noticing or to dwelling at the seeing end. `[C]`'s reading, closure 5 |
| 17 | The 19 surviving `attention` sites | `[C]`'s reading is that none survives translation. Closure 5 |
| 18 | Ch 17, the descent material | The stress hypothesis goes in here, in the *I think* voice, unlabelled. Closure 8 |
| 19 | Twenty sites, one per chapter and two each in Ch 5, Ch 10 and Ch 15 | The author's voice returns. Closure 9 |

---

## Open, and carried

**Whether the widened range is symmetric about the center.** `[C]` asked whether widening opens
the backward part as well as the forward part, or the forward part only. `[A]` moved to the
stress question and it was never answered. **It decides how the range is described in Ch 10 and
Ch 16, so row 9 and row 10 cannot be finished without it.**

**What the settling is, when two fixations pull opposite ways at one crossing** — carried from
`CLOSURES-SITED-job67-20260912.md`, untouched this session.

**Where a fixation comes from** — the book sets it aside as a separate question. Named here only
because closure 9's returning voice reaches the same ground.

---

## The twenty voice sites, specified

Part 1: the two-realm claim in Ch 1; the psychic realm having no outside in Ch 3; the three
orientations being all of them in Ch 4; and two in Ch 5 — the nine types coming out of two realms
and three orientations, and the claim that the derivation is what the types are rather than a
description fitted to them.

Part 2: the grid in Ch 6; the order around the cycle in Ch 7; position as something felt rather
than ranked in Ch 8; what passes between two people in Ch 9; two in Ch 10 — the hexad and the
triangle each recovered from the model; and eight wings rather than two in Ch 11.

Part 3: where the inner world came from in Ch 13; arcs underneath the cycle in Ch 14; two in
Ch 15 — what a fixation is, and detachment having two faces; the correspondence with the Levels
in Ch 16; and leverage in Ch 17.

**The type profiles in Ch 2 get none**, since a type is already speaking there.
