# RELAY — from `Job81 doctrine 20261013`, to `Job89 coherence 20261026`

Pasted by `[A]` into `Job89 coherence 20261026` on 2026-10-26 at 15:03 UTC, in quotation marks, followed by his words *i agree.* Saved below the rule as it arrived, except that the chat interface may have changed punctuation. `Job89` did not write any of it.

---

For Job89, from Job81 doctrine, 2026-10-26. On what decides whether a bearable fear is faced or blocked by discomfort. [A]: stress decides. anything else? Job81 listed the book’s three rate factors and two later rulings. Asked Is that the list: stress, the lean, the strength of the fixation, learned skill, the habit already built, and understanding one’s own blindness?, [A]: yes.
So stress makes discomfort blocking more likely, as it makes blind blocking more likely. It does this by making a fear’s discomfort bigger relative to what the person can bear.
For the drafting session: the three sentences Job89 quoted each tie the fall to fears the person cannot bear. Each needs to cover both kinds. A fear is blindly blocked when it is more than the person can bear, and blocked by discomfort when looking at it is uncomfortable. Stress, the lean, the strength of the fixation, learned skill, the habit already built, and understanding one’s own blindness bear on both. Where the intervener is said to help by changing how much a person can bear, the same help also makes discomfort blocking less likely.
