# CORRECTION SHEET — `Job57 coherence 09072026` corrects its own instructions

**Written 2026-09-08 by `Job57`, after reading
`NOTE-two-sources-of-motivation-20260908.md`. Pass this WITH that note. Read this one first.**

---

## The point

**The defect the note reports was in `Job57`'s instructions before it was in anyone's prose.**
`Job57` wrote that the lean supplies the motivation noticing needs, and that a Nine, having no
other realm, gets it from the lean alone. The drafting session took that and wrote the sentence
the note quotes. **Repairing the sentence without repairing the instruction leaves the
instruction to produce it again.**

**Book 2 itself is clean.** `motivation` occurs at three places outside the front matter and
none of them says a detached realm has none. Ch 4's *a detached person wants nothing, so nothing
narrows it* is about the width of the taking in and is correct. Ch 15's *they take in the most
of any of the three and notice the least* is a comparative and is correct. **Nothing in book 2
needs repairing for this. Four things `Job57` wrote do.**

---

## 1. The paragraph owed — its heading is the error

`CLAIM-INVENTORY-book2-20260902.md`, section **THE PARAGRAPH OWED**, and
`SET-NOTE-from-job57-20260907.md` §4. It reads *detachment has no motivation of its own, and
gets it from a neighbour*, and its body says *The means is motivation. A trace of caution in the
lean is something pulling, and something pulling is what brings noticing on.*

**Two faults in one sentence.** It runs together originating no motivation with receiving none —
the distinction the note draws. And it gives the lean the job of supplying motivation, which the
note records as NOT RULED.

**The paragraph is still owed, and its content changes.** What it should say is that a detached
realm originates no motivation of its own and receives it two ways: from its own process arcs,
which deliver a fear to the crossing in any realm whatever orientation is held there, and from
the person's other realm when that realm is not detached. **Not that the lean supplies it.**

---

## 2. Fault 33, the Nine — the ruling stands, the reason given is wrong

`CLAIM-INVENTORY` fault 33, `SET-NOTE` §3 item 9, and the record's `Job57` block.

**What stands:** which face of detachment shows in a Nine's realm is set by the lean, not by how
deeply caught they are. That is `[A]`'s ruling of 09-07 and it is untouched.

**What is wrong:** *the lean is what supplies the motivation noticing needs* and *a Nine has no
other realm to draw on, which is why the lean is the whole of it there.* A Nine is short of one
source, not of motivation. Their own arcs deliver fears in both realms.

**Use the note's repair**, at section 2 of the note, in the Nine's block at Ch 5. It says what
the lean actually does — decides what becomes of a fear that has arrived — and leaves the arc
its own job.

---

## 3. Fault 26 — the ruling stands, the mechanism must be replaced

`CLAIM-INVENTORY` fault 26, `SET-NOTE` §3 item 2.

**What stands, and it is `[A]`'s own words:** *not sight, noticing.* The lean moves how much
noticing happens; only blocking moves sight. **Do not weaken this.**

**What is wrong is the reason `Job57` gave for it:** *what caution lends is motivation, and
motivation brings noticing on.* That is the lean-as-source claim again.

**The book already has the right mechanism and the note names it.** The trace of a neighbouring
orientation decides how long a person dwells at the caution end of the crossing, and so how much
of an arriving fear is processed. Leaning toward caution they move through slowly and more is
processed; leaning the other way they are already moving as they pass. **Same conclusion, and it
rests on what the book has rather than on an unruled claim.**

---

## 4. Fault 24 — the crossings — one clause overreaches

`CLAIM-INVENTORY` fault 24 note, `SET-NOTE` §4 closing.

`Job57` wrote that Ch 5's growth halves *depend on a crossing between realms going right*. The
cross-realm source is one of two. **The clause should say the growth halves depend on motivation
reaching the detached realm, and name both sources**, since the arcs are available at all six
detached-realm sites and the cross-realm source is available at five of them.

---

## 5. What the drafting session should do about the record

The record's `Job57` block carries the fault at two places and **the record appends only**. Do
not edit it. The correction belongs in the next append, stated plainly as a correction, so the
chain shows what was wrong and when it was caught.

---

## 6. The caution worth carrying

The note's own closing is the general lesson and `Job57` is the evidence for it: **a new ruling
makes the material it does not cover easier to forget, not harder.** The cross-realm rule was a
day old and vivid; the arc source had been in the book for weeks. The session that had just
ruled the new thing reasoned from its absence rather than from what was already there.
