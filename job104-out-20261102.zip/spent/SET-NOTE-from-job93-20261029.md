# SET NOTE — from `Job93 coherence 20261028`

This note goes to the session that receives `job93-out-20261029.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job94-20261029`.

## Arrival

`job92-out-20261029.zip` verified against `MANIFEST-job93-20261029.md`: **65 ok, 0 mismatched, 0 bad count, 0 missing,
195 not in the manifest**, all 195 in `spent/` (119) and `superseded/` (76), matching `Job92`'s moves. The record's last
marker matched `Job92`'s note: ninety-fourth append, 102,754 w. `[A]` named the session `Job93 coherence 20261028`; the
label's counter agreed. The session ran on 10-28 his time (10-29 UTC).

## What was done

A coherence run on **`BOOK2-20261028.md`** (unchanged; 44,633 w), reading `CHANGES-job92-20261028.md` and the nine relays.
All 34 rows and every relay sentence are in the master. **Product: `FINDINGS-job93-20261029.md`** and a 10-29 block in
`CLAIM-INVENTORY-book2-20260902.md`. Three `Job81` updates arrived in session, saved byte for byte:
**`RELAY-from-job81-20261029.md`, `-20261029b.md`, `-20261029c.md`.**

The findings: before the panic, the fear has usually been ignored or blocked by discomfort, coming back stronger each time
(relay `20261029`; its last line is withdrawn by relay `b`); the unease loop's tension is kept up while the matter is
unresolved and builds only when the turns come close together (relay `b`); *Two things that cannot happen* loses *blacked
out*: a person may feel the turning away but does not notice the going down (relay `c`, which also reaches *Rising*'s
opening). `[C]` decisions: the week of the main burial counts from the panic; Chapter 4's panic moves to the caution end
(relay `20261028d`); *With buried material, the fear is never noticed* → *no longer noticed*.

## The record

One append, blind: the **ninety-fifth**, `[A]`'s words verbatim with what each answered; the relays are named, not
repeated. **Parent 102,754 w, head 102,979 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `CHANGES-job92-20261028.md`, `SET-NOTE-from-job92-20261028.md`, and the nine relays checked in this run,
  `RELAY-from-job81-20261027.md` to `-20261027d.md` and `-20261028.md` to `-20261028e.md`.
- To `superseded/`: `MANIFEST-job93-20261029.md`.
- **Kept live:** the three new relays, for the drafting session; `FINDINGS-job75-20261005.md` for its Part Four;
  `NOTE-introduction-recognition-20261007.md`, not to be acted on until `[A]` says so.

## What is owed

- **A drafting session on `FINDINGS-job93-20261029.md`**, items 1 to 5, with relays `20261029` (first proposal only),
  `20261029b` and `20261029c`.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold.
- **The writer 2 pass**, still waiting on Toby Marshall.

**For any session that shows `[A]` a change: bold does not show on his screen.** Mark new words with square brackets and
list the words going out underneath.

## Next

`[C]`'s recommendation: **a drafting session on `FINDINGS-job93-20261029.md`.**
