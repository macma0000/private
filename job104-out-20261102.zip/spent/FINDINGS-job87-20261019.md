# FINDINGS — `Job87 coherence 20261018`

Cut 2026-10-19. The session opened 2026-10-19 on `job86-out-20261019.zip` (manifest label `job87-20261019`). The run
is against **`BOOK2-20261018.md`** (43,060 w, md5 `4c5c1ed5`), which this session did not edit. During the session
`[A]` pasted in an update from `Job81 doctrine 20261013`. It travels as **`RELAY-from-job81-20261019.md`**, byte for
byte, and Part Two below says how to use it.

**A drafting session works from this file and the relay file.** This session wrote no book text. Where a row gives
wording, `[A]` approved that wording here, and the drafting session still shows him the sentences around it, before
and after.

**Every site was located by content.** Each blockquote below is a sentence of `BOOK2-20261018.md`, checked with
`quotecheck.py quotes`. `[A]`'s words are in italics and are never put in blockquotes. Neither are `Job81`'s or
`Job86`'s, nor the approved new wording.

**How the rows are marked.**

- **RULED**: `[A]` said it, and his words are given. Where he ruled by agreeing to a question, the question is given
  with his answer.
- **RELAY**: words from another session, brought in by `[A]`.
- **`[C]` DECISION**: a call this session made without asking. The drafting session shows him the result.

---

## PART ONE — THE LAST SECTION OF THE FALLING-AND-RISING CHAPTER

The set note asked for *Why trying harder does not change a person* to be read in full, because `Job86` cut it without
a finding behind it. It was read in full and shown to `[A]` whole, with the faults marked, at his request (*show the
whole section and highlight where the problems are.*). It had three faults. **All three are ruled, and the whole
section's new wording is approved.** The drafting session replaces the section's three paragraphs with the three in
row 4.

### 1. Own effort and help from outside

**RULED 2026-10-19.** The section said effort does not help a climb at all:

> Going up means giving up one's footing before there is anything else to stand on, which is not effort and does not respond to more of it.

> In each of those, the person is moved by someone else, not by their own effort.

Against these, the intervener section and *Rising*:

> That sight stays the intervener's own. Nothing is handed over. What the person is given is an amount small enough to look at, and the looking is theirs.

> Displacing a habit that is already running is slower, and practice is what does it, not conviction.

Asked *Does a person's own effort help a climb when it goes into practice and into looking, and fail only when it goes
into resolving to be different?*, `[A]`: *your reading is right.*

### 2. What help from outside works well at

**RULED 2026-10-19.** `Job86`'s cut removed the paragraph's opening, which named two ways out, so *works well* was left
with no object:

> Help from outside works well, in children who grow up in healthy families and in the people twelve-step programs help.

Asked *Is that what the sentence should say: that help from outside works well at changing a person, in both of those
cases?*, `[A]`: *yes.*

### 3. The lever figure's words left behind

**RULED 2026-10-19.** `Job86` took the lever figure out (register letter `m`) and left words that belonged to it,
which nothing in the book explains. Style guide section 3: where the explanation was dropped and the figure kept, the
claim has gone.

> Everything a person does about their own condition is done from somewhere. The wanting, the effort, the choosing what to work on — all of it proceeds from the position the self occupies, and the position is what needs moving.

> It is a fact about what there is to push against.

The *footing* sentence is quoted under row 1. *Occupies* also disagreed with *Where the Inner World Came From*:

> The self is that position.

**RELAY.** `[A]` gave `Job86`'s reading of the person's position: *Whatever a person does about their own condition,
the person does it as they are now. The person can work only on what they notice, and what needs to change is what they
do not notice. So the effort goes into the parts of their condition the person can already notice. That is why
resolving to be different so often produces a more determined version of the same person.* `[C]` put it to him with `[A]`'s own 10-19 last sentence kept in place of *a more determined
version*. `[A]` asked: *"as they are now" do you think "as they are at the time" is better?* `[C]` recommended *as they
already are*. `[A]`: *"as they already are." is good.*

For the second paragraph, `[C]` first proposed a sentence saying the person imagines facing would be unbearable, then
withdrew it after the `Job81` relay arrived, since under the relay that holds only for a buried fear. The revised
proposal: `[A]`: *ok*. For the last paragraph: `[A]`: *yes*.

### 4. The approved wording for the whole section

The heading stays: *Why trying harder does not change a person*. The three paragraphs become:

    Whatever a person does about their own condition, the person does it as they already are. The person can work
    only on what they notice, and what needs to change is what they do not notice. So the effort goes into the parts
    of their condition the person can already notice. That is why a person who resolves to be different so often ends
    up doing what they already did, just trying harder, and still failing to change.

    It is also why the climb is hard. Going up means bringing into view something the person does not notice. Trying
    harder at what the person already notices does not bring it into view.

    Help from outside works well at changing a person, in children who grow up in healthy families and in the people
    twelve-step programs help. In each of those, someone else helps the person see what trying harder could not bring
    into view.

**Referring-word count, run on all ten sentences** (`refcount.py`, then sorted by hand): each carries at most one
distinct referring word, pointing no further back than the previous sentence. *they* repeats its own sentence's subject
in the first, second and fourth sentences and is not counted. *It* in *does not bring it into view* points to the
previous sentence's *something the person does not notice*.

**Gone with this wording:** *done from somewhere*, *the position the self occupies*, *the position is what needs
moving*, *what there is to push against*, *footing*, *stand on*, *does not respond to more of it*, *moved by someone
else, not by their own effort*. **The register's lever entry quotes *the person is moved by someone else, not by their
own effort* as the way to say what happens.** That wording is now replaced, so the drafting session amends the entry
with `[A]`'s words above.

**`[C]` DECISION:** the word *position* is not used in the new section, so the mismatch with *The self is that
position* is gone without a separate change.

---

## PART TWO — THE `Job81` RELAY

**RELAY, 2026-10-19.** `RELAY-from-job81-20261019.md` holds `Job81`'s update for this session and the next drafting
session. It carries `[A]`'s words with what each answered, and wording he approved: two kinds of blocking (**blind
blocking** and **discomfort blocking**), the glossary entry *Blocked*, the levels chapter's chain section rewritten
under a new heading, *what the chain conserves*, the job example, the climb in *Where a level change can happen*, a new
section in the falling-and-rising chapter with the present *The second way down, which is not blindness* retitled
*Leaving fears unweighed*, and a sweep limiting every statement of how hard it is to rise to buried material.

**The drafting session applies the relay from that file, not from this summary.** Every passage it names was found in
`BOOK2-20261018.md` by content:

- the glossary entry, which the master writes *\*Blocked\** in italics, so a search for the bare word with a dash finds
  nothing;
- *The rule beneath them*, and the paragraph beginning *The chain runs on unattended fears*, which holds *Fresh burial
  belongs to the unhealthy band*;
- *It conserves what is wanted*;
- the job example, at *Some of the fears are noticed and turned away from*;
- *Where a level change can happen*;
- *A climb of any real distance is measured in years*;
- *Panic can happen at any level*;
- *Recognition works one kind of painful thought at a time*.

**Three notes for the drafting session.**

1. **The third source of stress is already in the book.** The relay lists it under *Not yet approved*. `[A]` approved
   it in `Job86` (*yes.*, `CHANGES-job86-20261018.md` row 10). It reads in the master as the relay gives it. Do not
   apply it again. `[C]` told `[A]` this in session.
2. **The sweep names the section that replaced the leverage material.** Part One's approved wording already holds for
   both kinds of blocking. Its one statement of difficulty is *It is also why the climb is hard*. That sentence says
   nothing about buried material, and `[A]` approved it after the relay arrived.
3. **The relay's new climb paragraphs and the new section both say a buried fear is faced alone only late, and help
   from outside brings it sooner.** That agrees with Part One row 2 and with the intervener section. No collision was
   found. **The sweep itself was not run by this session.** It is drafting work, and the relay gives it to the next
   drafting session.

---

## PART THREE — WHAT THIS SESSION CHECKED, AND WHAT IT DID NOT

- **Read in full:** the falling-and-rising chapter, and the unease-loop section of the fixations chapter, where
  `Job86` made its changes. Apart from Part One, every `Job86` change reads as its changes file says. `Job86`'s rows
  1 to 11 were found at their sites.
- **`wordcheck.py`** against register letter `m`: no pattern fires in the last section. `lever` fires once in the book,
  on the Eight's literal *leverage*.
- **Tracking check:** run on **own effort in a climb** (practice, looking, resolving, help from outside), across the
  intervener section, *Rising*, the migraine case in the unease-loop section, and the last section. Part One rows 1 and
  2 are what it found.
- **The claim inventory** is updated for every unit `Job86` changed, under the 10-19 block.
- **Not done:** tests (a) to (d) across the book. The handoff is still stale; it needs a cut.
