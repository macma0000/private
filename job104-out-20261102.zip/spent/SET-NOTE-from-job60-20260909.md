# SET NOTE — from `Job60 drafting 09092026`, for the session that receives this set

**Written by `[C]` at the close of a kind 11 drafting session. `[A]`'s typed words appear as
blockquotes; everything else is `[C]`'s report.**

---

## 1. WHAT THIS SESSION DID

It applied **all eight rulings** of `RULINGS-job59-20260908.md`. Every one now has prose. The master
moved from `BOOK2-20260908.md` (33,402 w) to **`BOOK2-20260909.md`**.

Nothing from `COUNT-referring-words-job59-20260908.md` was touched, as the arriving note instructed.
**The 113 sites are still owed and still want a session of their own.**

---

## 2. THE RECOMMENDED NEXT SESSION — `[A]` ACCEPTED IT

**`Job61 coherence`, running the tracking check on *fear*.**

Roughly thirty new paragraphs went into Ch 15 and Ch 17 this session, and the rule about what narrows
the taking in changed shape. Nothing has read that against the rest of the book. A fear is the right
object to track because this session's new prose follows one from where it is raised, through the
crossing, to burial — and the last four coherence runs each found a contradiction whose parts were
each correct alone.

Queued behind it, **not interchangeable, one per session**:

- **`[A]`'s cautious-realm observation** (09-08, in `RULINGS-job59-20260908.md`): a fear of his goes
  through detachment ignored, through enthusiasm as something he wants to think about, and back to
  caution, losing its object on the way. Book 2 has no account of a fear coming back round, and this
  session made that gap sharper by writing the crossing as where a fear's fate is settled. **Doctrine.**
- **The vulnerability ordering**, which `[A]` declined to rule on 09-08. See §4 below — this session
  had to write around it. **Doctrine.**
- **The 113 referring-word sites.** Mechanical, no doctrine, own session.

---

## 3. THE RULE THAT CHANGED, AND WHY IT MATTERS TO EVERY LATER SESSION

Job59 settled an **object test**: what narrows the taking in is a want with an object in the realm.
`[A]` broke it this session:

> i would keep narrow, wider, widest because a cautious person who focuses on one outcome would be
> cautious with a strong enthusiastic lean.

**A single object cannot order the three orientations**, because an enthusiastic person's want and a
cautious person's fear are both single objects, and a person focused on one outcome is not caution but
caution leaning hard toward enthusiasm. `[A]` then added strength. **The settled form, now in Ch 4:**

> What settles the amount is how hard the want pulls a person toward one part of the realm.

**Both terms are load-bearing.** Strength orders the extremes — panic and a reflexive grab pull hardest
and narrow hardest. Aiming protects Ch 15's *What is taken in is the same at either end of the range* —
a want for peace can pull very hard and has no part of the realm to pull toward, so it never narrows.
**A session that drops either term will break one of those two.**

---

## 4. WHAT THIS SESSION WROTE AROUND, AND HANDS ON

**The vulnerability ordering.** Ruling 4 quotes `[A]` saying *A and B fixations would not dwell at Z+
and not be vulnerable*. He declined to rule the ordering. This session wrote **the burial happens less
often** rather than *not at all*, because every arc passes through the detached phase, Ch 15's cautious
sketch has a fear going into that phase and out unhandled, and Part 3 applies to all nine types.
**Stronger than that is a ruling still to be made, and it bears on the health axis:** *not vulnerable*
says only detached fixations fall.

**A pointer to book 1's practices.** The 09-08 ruling keeps book 2's growth material at the mechanism
and points at book 1 for the techniques. **Ch 17 has no pointer to book 1 anywhere in it**, so this
session invented no convention for one. Whoever writes the joins decides.

---

## 5. THE SITES TOUCHED

| where | what |
|---|---|
| **Ch 4**, rule paragraph | *nothing pulling at them* out; the pull rule in |
| **Ch 4**, width paragraph | *a detached person wants nothing* out; narrow / wider / widest; peace named |
| **Ch 15**, range section | second false-phrase site repaired; **7 new paragraphs** — the unfocused want at each end, the focused extreme at each end, burial as a reflex, taking in as preconscious |
| **Ch 15**, loop and dwelling | **3 new paragraphs** — fixation as dwelling, the burial as a countable event, the loop separated from the lean |
| **Ch 5**, the Two | physical-realm reason repaired |
| **Ch 5**, the Nine | **two sites**, not the one the ruling named |
| **Ch 17**, the rate | two things become three; **5 new paragraphs** on the skill learned from outside |
| **Ch 17**, Rising | **4 new paragraphs** — the skill as something copied, taught, or practiced into place |

---

## 6. FOUR CORRECTIONS `[A]` MADE TO THIS SESSION'S PROSE — ALL ONE FAULT

He caught *both halves* standing in for the competence and the failure; *a fact about where the person
usually is* standing in for the fixation; *the conditions come round less often* pointing back across a
paragraph break; and *No want pulls a Nine*, which puts a negated noun in the subject of an active verb
so a reader meets the noun and the verb before anything signals a denial.

**Three of the four passed `[C]`'s own check before he read them.** The common fault is writing a
description of something the book already has a word for.

---

## 7. `[A]`'s STANDING CHANGE TO HOW STYLE IS HANDLED — READ THIS BEFORE DRAFTING

He gave a note for later:

> at some point we either need to get the style much more carefully controlled or almost everything
> will need to be manually rewritten. currently we are getting all the information down and in a well
> organized order. after that is done, the next job is to try to specify how claude can reword
> everything to make it easier for the reader. but that's too much for now.

**and then withdrew his own 09-04 objection to fixing style later:**

> i withdraw "the part about fixing things later seems like a problem" - but the writing still has to
> be clear enough for me to understand it when i read it later.

**So a later reworking job is allowed again.** `[C]`'s reading of the condition, given to him and not
corrected: **the mechanical checks stay in force while drafting** — the referring-word count above all,
and naming a thing rather than describing it — because those are what make a passage readable on his
first pass. What moves to the later job is the finer choosing between two forms he would understand
either way. **The floor is his reading of it in session; the ceiling moves to a later pass.** His last
word:

> ok. i will continue to say when i have problems understanding. go on.

---

## 8. THE COUNT, RUN ON THIS SESSION'S OWN PROSE

`refcount.py` over the changed and new paragraphs: **79 sentences new or changed, 6 flagged, 3 real.**
All three repaired before the master was cut.

**The three false positives are the rule's known blind spot and will recur in every run:** relative
*that* (*a fear that arrives too fast*), complementizer *that* (*convinced that burying a pain*), and
expletive *there* (*before there is any occasion*). `refcount.py` cannot tell those from the demonstrative
uses, which is what `RULE-referring-words-20260908b.md` already says. **A reader has to sort them.**

`refcount.py` also writes its row dump to a hard-coded path, `/home/claude/job59/refrows.json`, and
fails if that directory is absent. **Create it before running, or the script dies after printing its
summary.**

---

## 9. FILES CUT THIS SESSION

| file | what it is |
|---|---|
| `BOOK2-20260909.md` | the master, 34,517 w. **`BOOK2-20260908.md` is dropped from the set** |
| `SET-NOTE-from-job60-20260909.md` | this file |
| `MANIFEST-job61-20260909.md` | the outgoing manifest |

**`RULINGS-job59-20260908.md` is spent** — every ruling in it has prose. It travels as a record of what
was applied, not as an instruction.

---

## 10. THE RECORD

**FORTY-FIRST APPEND, blind** — this kind does not read the record. Head is now **53,036 w**, marker
`2026-09-09 · Job60 drafting 09092026`, parent 51,378 named in the block. The first **303,817 bytes
verified byte-identical** after the append. Canonical bold form; `setcheck.py sweep` reads the new
marker.

The block states its provenance first and quotes **eleven** of `[A]`'s typed passages verbatim, marking
everything else as `[C]`'s report.
