# SET NOTE — from `Job68 drafting 20260913`, 2026-09-13

## What arrived

`job67-out-20260912.zip`, 81 files, verified against `MANIFEST-job68-20260912.md` under the label
`Job68 20260912`: **81 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.** The
screen fired twice, both expected — `AUTHOR-RECORD.md` as CARRY DO NOT READ, `HANDOFF-20260906.md`
for quoting the restriction string, and both tools exempted themselves.

**`VOCABULARY-INSTRUCTION-from-job67-20260912.md` arrived separately**, beside the set, cut by
`Job67` after its zip was built. It was added to the directory and the manifest regenerated, as
its header instructs.

## What this session did

The nineteen-site backlog, applied whole: twelve rows of `CLOSURES-SITED-job67-20260912.md`, five
repairs from `REPAIRS-job66-20260912.md`, two from `REPAIRS-job65-20260912.md`. Master
`BOOK2-20260912.md` (35,695 w, md5 `1065e37e`) → **`BOOK2-20260913.md` (36,139 w, md5
`ed135b63`)**. Every site is itemized in `CHANGES-job68-20260913.md`, and every change was shown
to `[A]` before it was applied.

Six changes beyond the backlog, each on `[A]`'s word in the chair: three sentences in the day's
own draft that broke the naming convention, three sites found by the sweep, the scale definition
in Ch 7, the cut of *Why there are scales*, the Ch 17 sentence he did not understand, and two
small fixes inside passages being rewritten anyway. The changes file marks each one.

## Three things a later session needs to see

**1. The naming convention, and that a session walked into it.** `[A]` restated it in full and
the record carries his statement verbatim. Letters `A`, `B`, `Z` for a person, always with a realm
prefix; adjectives shared between orientations and phases on purpose; plain words where the
resemblance is beside the point. **The trap is the adjectives.** A drafter writing *enthusiasm*
against *detachment* can put a person on one side and a phase on the other without noticing, and
that is exactly how the false claim `Job66` caught got written. §8 of the vocabulary instruction
records the same finding from the other direction and `[A]` has said no rule yet.

**2. The ends of the detached phase — open, and `[A]`'s.** Ch 4 introduces *the caution end* as an
end of detachment where detachment is a person's position. Part 3 uses the same two ends as ends
of the detached phase, which every endeavor runs through whoever runs it. The bare form hides
which is meant. This session attached the phase at the first mention in each section it touched,
as a local measure. **Whether the ends need one clean introduction is not settled and is a
doctrine question.**

**3. The claim inventory is stale in Part 3.** Sixteen sites changed in Ch 15, Ch 16 and Ch 17,
including two sections of Ch 15 rewritten whole and one section of Ch 13 cut. Entries for those
will be wrong. `CLAIM-INVENTORY-book2-20260902.md` was not regrown, and a coherence run will want
it regrown first.

## Carried unruled

- **The Ch 11 lean sentence**, *Leaning back toward caution, detachment keeps the realm in view*,
  found by the sweep and deliberately not fixed. It belongs to the vocabulary job: it is in Part 2
  and in the same passage as §4.5 of the instruction, which has to put a person at a lean for the
  same reason.
- **`Enthusiasm plays down risk; that is what enthusiasm is`**, Ch 5, found by the sweep and
  recommended for leaving. It defines an orientation, and the style guide forbids putting a person
  into such a sentence. Recorded so the next sweep does not re-find it as new.
- **`Each new fear gets its own blocking laid down`**, Ch 15, left when repair 5 was applied
  beside it.

## Files

Cut: `BOOK2-20260913.md`, `CHANGES-job68-20260913.md`, this note, and the regenerated manifest.
Dropped: `BOOK2-20260912.md`, superseded. `VOCABULARY-INSTRUCTION-from-job67-20260912.md` added.
The three spent backlog files are carried, as spent closures files have been all along.

**Record: forty-ninth append, blind, head 64,653 w, parent 63,458.** Prefix verified
byte-identical at 374,081 bytes, md5 `ef64564a` before and after; 61 markers; canonical bold
marker form.

## Recommendation for the next session, `[A]`'s to assert

**Drafting, and only the vocabulary pass.** Its own §6 says not to interleave it with other work,
and the reason holds in both directions: sixty-one sites in Parts 1 and 2, forty-five of them in
Ch 5 and Ch 10, with one formula repeated about sixteen times, so a wording chosen in a hurry is
repeated sixteen times before anyone sees it. The pass also owes new prose — the Part 3 opening
at §5 of the instruction, which includes the Naranjo claim the book states nowhere at present.

**The line range in §7 of the instruction is now wrong.** It says lines 63 to 994. In
`BOOK2-20260913.md` Part 1 opens at line 63, Part 2 at 671 and Part 3 at 997, so the range is 63
to 996, and 48 lines in it carry the word. Recalculate before running the final check.

**Not a coherence run next.** It would inventory Parts 1 and 2 immediately before sixty-one sites
in them change.

**A handoff session is overdue** — the live handoff is `HANDOFF-20260906.md`, now eight sessions
back, and its record-reach line has been wrong since `Job61`.
