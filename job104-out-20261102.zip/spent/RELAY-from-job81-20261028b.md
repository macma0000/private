# RELAY — from `Job81 doctrine 20261013`, to `Job92 drafting 20261027`

Pasted by `[A]` into `job92 drafting 20261027` on 2026-10-28 at 01:23 UTC, preceded by his words *from job81:*. It corrects the ruling `Job91` recorded (`FINDINGS-job91-20261028.md`, item 1) that a buried fear is glimpsed for a moment before panic turns the person away, and answers `Job92`'s first proposed change. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job92` did not write any of it.

---

For Job92, from Job81 doctrine, 2026-10-28. This corrects the ruling Job91 recorded, that a buried fear is glimpsed for a moment before panic turns the person away from the fear. [A]: i don’t think that’s exactly right. i think it builds over repeated incidents, but ends in panic and burial. Job81 agreed: the fear comes up again and grows, and the burial is all at once, at the end of the build-up. A small child is the exception. On how many times, [A]: i’d say several instead of many, but i don’t know which is closer to reality. Job81 proposed repeatedly, which claims no number. [A]: good to:

* A fear is usually buried only after it has come up repeatedly and grown, until one time it is more than the person can bear. Panic then turns the person away from the fear, and the fear is buried. A small child can be brought to panic by very little, the first time.

This replaces the four-fates sentence saying a buried fear never comes into view. Anywhere else the book says a buried fear is glimpsed before panic, it should follow this wording.
