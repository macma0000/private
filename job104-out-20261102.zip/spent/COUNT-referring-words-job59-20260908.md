# The referring-word count run over book 2 — `Job59 coherence 09082026`

**Asked for by name in `SET-NOTE-from-job58-20260908.md`: run the count of
`RULE-referring-words-20260908.md` over the prose written before the rule existed, which is all of
book 2 apart from what `Job58` wrote.**

Source: `BOOK2-20260908.md`, 33,402 w. Tool: `refcount.py`, cut by this session and carried in the
set. **1,901 sentences scanned.** Headings, table rows, list items and the contents block are
excluded; body prose and bolded lead-ins are included.

---

## What the count as written finds

The rule's step 1 reads: count the referring words in the sentence, and rewrite on more than one.
Run literally on every listed word, **674 sentences fail, which is 35% of the book.** Dropping
*that* and *there*, which are ambiguous for a different reason given below, **445 fail, 23%.**

**A quarter of a book is not a repair list, and most of the 445 are harmless.** The reason is worth
putting to `[A]`, because it is a finding about the rule rather than about the prose.

## The rule counts tokens, and a reader's load is referents

The largest class of failure is one referent named twice inside one sentence, where the referent is
also the sentence's own subject:

> They value efficiency, excellence, and forward motion — and they apply these values to themselves
> relentlessly.

> They don't ask more of others than they ask of themselves.

Nothing is resolved twice there. The reader holds one subject and the second pronoun costs nothing.
The type sketches are built out of sentences of that shape, which is why Chapter 5 and Chapter 2
carry 160 of the 445 between them.

**Three variants were computed.**

| variant | fails | share |
|---|---|---|
| every listed token, *that* and *there* dropped | 445 | 23% |
| distinct referring WORDS, two or more | 306 | 16% |
| distinct words, third-person plural dropped | 113 | 6% |

**The third is a usable repair list and the table below is that list.** Dropping *they*, *them* and
*its* removes the one-subject-named-twice class almost entirely, and a sample of the survivors shows
each carrying a real reference the reader must resolve.

## Why *that* and *there* were dropped from the automatic flag

*That* runs as a complementizer (*the person begins to understand that grasping the risks…*) and as
a relative pronoun far more often than it runs as a demonstrative, and neither of those asks a
reader to resolve anything. *There* runs as an expletive (*there is no event of collapsing*) as well
as a place word. **A machine cannot separate the uses, and counting them raises the failure rate by
half without adding a single real site.** They are still worth a drafter's eye when the demonstrative
use is intended, and the tool records every occurrence so a later pass can look.

## What this leaves for `[A]`

**The count as ruled cannot be run as ruled.** Step 1 counts tokens; a reader's load is referents.
**Recommendation, not a ruling: step 1 should count distinct referring words rather than
occurrences, and should not count a third-person plural pronoun that repeats the subject of its own
sentence.** Steps 2 and 3 are untouched — reaching back past the previous sentence, and one thing
one name, are both about referents already, and neither can be machine-checked.

**Steps 2 and 3 were NOT run.** Finding what a word points at, and counting how many names one thing
carries across a passage, both need a reader. The 113 sites below are step 1 only.

---

## The 113 sites

| chapter | line | referring words | sentence |
|---|---|---|---|
| front matter | 11 | it, this | My deepest wish is that this material might help others as it has helped me. |
| front matter | 51 | it, the first | Gurdjieff brought the diagram to his students in Moscow in the years around the First World War, presenting it as a map of how processes unfold rather |
| Chapter 1 | 77 | the first, the second | An apple on the first table and an orange on the second. |
| Chapter 1 | 77 | the first, the same, the second, those | Or an orange on the first and an apple on the second — and those are two arrangements, not one, because the two tables are not the same table. |
| Chapter 2 | 213 | it, the former, the latter, they | That knowing about life and actually living it are very different things — and that they can mistake the former for the latter. |
| Chapter 2 | 305 | it, them, this | This feels like contentment to them, even when others might see it as inertia. |
| Chapter 3 | 333 | it, the same | A carefully repeated experiment gives the same result no matter who runs it. |
| Chapter 3 | 333 | it, this | This is the physical realm, and this book abbreviates it **H**. |
| Chapter 4 | 361 | it, this | In some people this shows up as explicit plans and contingencies; in others it is held silently, a map kept current with no schedule attached. |
| Chapter 4 | 365 | it, this | This book calls that act noticing, and it is work. |
| Chapter 4 | 371 | it, the same | A person can take a realm in whole, or pick one thing out of it, but not both in the same moment. |
| Chapter 4 | 383 | it, such | Such a person still pursues pleasure, but only where pursuing it demands nothing. |
| Chapter 4 | 387 | the other, these, they | None of these is a consolation prize; each is a genuine capacity that the other two do not have, and each is part of why a person keeps the one they h |
| Chapter 4 | 389 | it, the first | A detached person steps back and lets the difficulty go, or does not look at it in the first place. |
| Chapter 4 | 393 | it, the same | A person under stress can bear less, so the same thing is harder to face than it was the day before. |
| Chapter 4 | 399 | the other, the same, them | The difference is not one of subject matter: two people can face the same trouble with the same facts in front of them, one attending to what could st |
| Chapter 5 | 405 | the same, these, they | A person has one of these three in the physical realm and one in the psychic, and they need not be the same. |
| Chapter 5 | 433 | it, its, this | This is perfectionism, and it comes with its own signature resentment — a world permanently falling short of a standard that was never valid there. |
| Chapter 5 | 483 | it, the other | Or it runs the other way and the internal conviction fails to show up as anything outside. |
| Chapter 5 | 491 | it, the same, this | The psychic realm works the same way, because a Three is enthusiastic there too, and this is where it matters. |
| Chapter 5 | 501 | it, the other, they | The Four does not, so the world arrives undistorted — and they have, in the other realm, what it takes to say what it means. |
| Chapter 5 | 517 | it, the other, they | But their attention is in the searching, which is in the other realm, so they do not look, and the cost is realized only once it has been paid. |
| Chapter 5 | 553 | it, the same, they | Their loyalty is not sentimentality; it is the same competence applied to people, and they stay when others leave. |
| Chapter 5 | 555 | the same, this | The Six sees this as clearly as the Four and the Five see theirs, and for the same reason: two cautious realms and no enthusiasm anywhere means nothin |
| Chapter 5 | 557 | it, the same | Holding the same competence in both realms makes the Six the only type that models how a thing can fail and how the people around it can fail, at the  |
| Chapter 5 | 557 | it, those | The Six anticipates the technical breakdown and also who will panic, who will quietly stop cooperating, and how the announcement will be misread — and |
| Chapter 5 | 563 | it, the same | In the psychic realm the same scanning is not neutral, because that realm loops: watching for a danger is one of the things that produces it. |
| Chapter 5 | 573 | it, the same, this | The psychic realm works the same way, because a Six is cautious there too, and this is where it matters more. |
| Chapter 5 | 611 | it, those | Understanding force and position is one thing, and caring wholeheartedly about people is another, and the two rarely occur together — those who grasp  |
| Chapter 5 | 611 | the first, the second | The Eight has the first in the physical realm and the second in the psychic, so the understanding gets put to use on somebody else's behalf. |
| Chapter 5 | 613 | the other, these, they | These two are the only types carrying enthusiasm in one realm and caution in the other, and they are the only two in which a person cannot see their o |
| Chapter 5 | 613 | the same, this | The One cannot see their own anger for this reason; the Eight cannot see their own guardedness for the same one. |
| Chapter 5 | 617 | it, the other | And it is the unwatched realm that supplies the principles which invade the other one. |
| Chapter 5 | 617 | these, they, this | These are physical-realm moves, correct in their own realm, and they cannot do this job — because connection requires openness, and the walls that kee |
| Chapter 5 | 651 | it, the same, this | The psychic realm works the same way, because a Nine is detached there too, and this is where it costs more. |
| Chapter 6 | 681 | the same, these | These are the types holding the same orientation in both realms — enthusiastic in both, cautious in both, detached in both. |
| Chapter 6 | 689 | such, the other | There are three such pairs and no more: three cells lie on the fold, and the other six exchange in pairs. |
| Chapter 7 | 749 | it, this | It is a fact, completing many times an hour, in everyone — the one claim in this book you can check in the next sixty seconds. |
| Chapter 8 | 757 | it, those | It is practical advice rather than a further part of the account, and it holds only so far as those two do. |
| Chapter 8 | 759 | the other, the same | In the physical realm their two fixations either sit at the same place on the loop or one is a step ahead of the other. |
| Chapter 9 | 790 | it, the other | What it is like from inside is a different matter — who looks up to whom, where the irritation comes from, and what each person has that the other nee |
| Chapter 9 | 794 | it, this | This describes a small number of people, and in any real relationship it is one factor among many. |
| Chapter 9 | 802 | it, the other | Holding it apart from the other two is what keeps an accurate reading of position from curdling into awe on one side and condescension on the other. |
| Chapter 9 | 808 | it, this | This is checkable, and it is where the account differs sharply from most descriptions of human development, which assume that someone further along th |
| Chapter 9 | 814 | the other, these | These relationships tend to be the easiest of all — no gradient to manage, no competition, each strong where the other is weak. |
| Chapter 9 | 816 | the other, the same | The trouble is the echo: little the other does not already have, the same blind spots doubled, and the standing risk that neither ever challenges the  |
| Chapter 9 | 828 | it, the other | Marcus is ahead in the physical, where his caution tempers Elena's build-it-now enthusiasm with *what's our downside?* Elena is ahead in the psychic,  |
| Chapter 9 | 828 | the other, the same, they | They are also mirrors, the same two orientations distributed oppositely, so each recognizes the other from the inside while being fluent exactly where |
| Chapter 9 | 830 | it, the same | When Priya brings Tom a worry he does not weigh it, he adds to it, and two vigilances pointed at the same object confirm each other. |
| Chapter 9 | 830 | the other, this | The best gift each could give the other is the one thing neither naturally supplies: the voice that says *this one is not worth watching.* |
| Chapter 9 | 842 | it, the other, them, they | They may or may not take both realms to be real, and may or may not be comfortable with the reality the other sees, but they have direct evidence that |
| Chapter 9 | 844 | the same, this | This can be enriching and difficult in the same measure. |
| Chapter 9 | 848 | it, the other | A person detached in a realm tends to be unaware of that realm and to undervalue it, and so to undervalue another person's competence in it, dismissin |
| Chapter 9 | 848 | it, this | This friction is independent of relational position, and it can sharpen or soften any of the dynamics above. |
| Chapter 9 | 850 | it, the other, them, this | On good days this is a running joke between them; under strain it hardens, each briefly certain the other is giving their life to what does not matter |
| Chapter 10 | 874 | it, the other | A single step in one realm leaves the other where it was, so it breaks the alignment; only the double step preserves it. |
| Chapter 10 | 876 | it, the other | Advance one realm and one of two things happens: either the advancing realm arrives where the other already stands, and the type becomes aligned, or i |
| Chapter 10 | 892 | it, the other | The other twelve cross between the mixed types and the diagonal — each mixed type has one aligned type a step ahead of it, and each aligned type has t |
| Chapter 10 | 894 | the other, the same | A crossing relation is the same move as a hexad step: one realm advancing a single place, the other held. |
| Chapter 10 | 896 | it, the other | A relation running forward is also the direction along which one of the two stands to the other as the next orientation stands to the one before it. |
| Chapter 10 | 902 | it, the other, the same | A fixation loosening shows up the same way in either realm: some of the orientation ahead becomes available there, and the other realm stays as it was |
| Chapter 11 | 928 | the other, the same, this | For enthusiasm this gives A−, A0 and A+, and the same for the other two. |
| Chapter 11 | 955 | the other, the same | Read the same person both ways and each reading checks the other. |
| Chapter 11 | 983 | it, the same | The eight combinations are read the same way whichever orientation a fixation sits at, and for enthusiasm and caution that is right: a lean shades the |
| Chapter 13 | 1031 | it, them, this | This is also the property that divides the two realms most sharply, and it is what the earlier account of them was describing. |
| Chapter 13 | 1045 | it, its, the first, the same | It is the picturing capacity turned back on its owner: the same turn that produced the inner world in the first place, made for its own sake. |
| Chapter 13 | 1047 | it, them, those | What differs is whether the person looks at what disturbs them or turns away from it, and those are the two directions the range of detachment runs be |
| Chapter 13 | 1047 | such, the other | The other two orientations have nothing to make such a difference with. |
| Chapter 13 | 1065 | it, the other, them | It was built for situations in which the other party is predicting you while you predict them, and in a situation of that kind what one needs is a pos |
| Chapter 13 | 1065 | it, the other | It seems solid because it was made for a contest in which the other side is holding a position too, and because for most of a life the contest never s |
| Chapter 14 | 1085 | it, the same | Detachment is already the odd one among the three, and the same asymmetry that shows at the resting place shows again in the passage that leaves it. |
| Chapter 15 | 1115 | it, these | These are opposite functions, and both belong to detachment, which is the only one of the three with a contradiction inside it. |
| Chapter 15 | 1117 | it, the same | There is a reason the contradiction lands there, and it is the same reason in both halves. |
| Chapter 15 | 1131 | it, this | What the blindness produces is what maintains it, which makes this a feedback loop and not a habit, and that is the difference between it and ordinary |
| Chapter 15 | 1133 | it, the other, the same, them | It is one quantity, not two conditions with a boundary between them — a doubly detached Nine leaning one way attends to a realm with concerned clarity |
| Chapter 15 | 1175 | it, the other | Within that one pairing the difference is how the want ended — met in the one case, let go unmet in the other — and the regret is the mark of it. |
| Chapter 15 | 1189 | it, the other | A fear lives in one realm or the other, so the fixation that handles it is the one held in that realm and not the person's type. |
| Chapter 15 | 1215 | it, this | All of this is automatic, and none of it is a fault. |
| Chapter 15 | 1219 | the first, those | Some things lead to pleasure and some to pain, and those contingencies are the first wantings and the first fearings. |
| Chapter 15 | 1223 | it, the same | Nothing dramatic marks the moment; the same behavior continues, with intention now behind it. |
| Chapter 15 | 1227 | it, the second, this | This is also the second reason a person cannot find their own fixation by looking for it. |
| Chapter 15 | 1227 | the first, this | The first was that a fixation is a slant on what gets pictured rather than one of the things pictured; this one is that a strategy laid down before un |
| Chapter 15 | 1233 | it, the same | The same faculty does both, and what it carries makes no difference to it. |
| Chapter 15 | 1235 | it, the other | Something about a person's orientation is a choice and something about it is not, and habit is what moves it from the one to the other. |
| Chapter 15 | 1249 | it, this | One question has been left open since the beginning, and it is the one that decides whether any of this holds together. |
| Chapter 15 | 1257 | it, the other | There is no core habit sitting on top of the mental deposits with the residue of a lifetime underneath it, the one running and the other merely record |
| Chapter 15 | 1259 | it, the same | Mental deposits that have laid down the same move for decades go on laying it down, and a person who has been doing one thing for decades is, for all  |
| Chapter 15 | 1259 | it, this | It is what this mechanism produces. |
| Chapter 16 | 1267 | it, its, this | What follows about what moves a person along it is this book's, and stands or falls on its own. |
| Chapter 16 | 1295 | it, the same | Each new desire is the previous desire with one more layer of unawareness over it — nothing new is ever wanted, only the same want at a further remove |
| Chapter 16 | 1341 | it, the other | The third is not a third orientation standing beside the other two, and it is a different sort of quantity. |
| Chapter 16 | 1357 | it, the first, them | The first three happen while it is still in view and none of them takes anything from a person's seeing. |
| Chapter 17 | 1375 | it, they, this | One thing moves on this axis, and it is not how much a person suffers or how hard they are trying. |
| Chapter 17 | 1379 | it, the other | One is where the fixation held in that realm sits when the crossing comes — detachment leaning toward caution dwells at the caution end and more is de |
| Chapter 17 | 1387 | it, those | As consequences gather it presses harder, and at some point it can no longer be left — it has to be weighed or turned away from, and which of those ha |
| Chapter 17 | 1415 | the other, the same | But the other term rises too, and for the same reason: further down there is more to unbury, so facing costs more. |
| Chapter 17 | 1415 | it, the same | It continues at all because the thing that would end it is getting more expensive at the same time. |
| Chapter 17 | 1419 | it, the same | New consequences stop arriving, and the stock of old ones fades — slowly, because the same persistence that built it holds it in place. |
| Chapter 17 | 1427 | it, the same | A person who turns away from their own condition has taken that condition in all the same, and the turning away is taken in with it. |
| Chapter 17 | 1445 | the first, the same | An intervener who steadies someone has changed the first: a person who is calm bears more than the same person alarmed. |
| Chapter 17 | 1451 | it, the same, them, they | Stress has already taken more of what they can bear, so the same steadying leaves them able to bear less than it would leave someone higher up. |
| Chapter 17 | 1473 | it, the other, the same | The other one uses the same crossing, made in full sight instead of blacked out, and it is the more surprising half, because it turns out not to be a  |
| Chapter 17 | 1477 | it, the same | What hardens in an infant is an expectation that begins provisional, gets confirmed, and stops being tested, and it has the same structure without eve |
| Chapter 17 | 1485 | it, this | There is a trap in training that is particular to this model, and it follows from a person having two realms rather than one. |
| Chapter 17 | 1485 | it, the other | Training the realm you already live in does not merely leave the other one alone — it unchecks it, because attention withdrawn from a realm is exactly |
| Chapter 17 | 1485 | it, the other | The cut has to be graded, and it is thinnest at the top: near the summit the two are close enough together that working on one carries the other. |
| Chapter 17 | 1487 | it, such | The time such work takes is almost none of it in the change. |
| Chapter 17 | 1493 | it, the first | What it is for can now be said, and it has been at stake since the first fear was turned away from. |
| Chapter 17 | 1499 | it, the other, this | That one generalizes where the other does not, and it is the only object in this account whose recognition would reach material not yet laid down. |
| Chapter 17 | 1505 | it, the same | It could not be held in any case, and the reason is the same one that runs the whole book. |
| Chapter 17 | 1507 | it, the other | It is a genuine, hard-won half-attainment wearing the visible marks of the whole one, with the other realm running entirely unchecked behind it. |
| Chapter 17 | 1513 | it, the same | It is a fact about what there is to push against, and it is why resolving to be different so reliably produces a more determined version of the same p |
| Chapter 17 | 1517 | the second, this | This account produces the second. |