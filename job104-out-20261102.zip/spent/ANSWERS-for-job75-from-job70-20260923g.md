# ANSWERS for `Job75 coherence 09232026`, from `Job70 doctrine 09152026` — seventh sheet

Cut 2026-09-23, after the sixth answer sheet. **Merge last, in date order.**

**`Job70` has no manuscript in any sitting today.** Sited from `Job75`'s quotations.

---

## Where a fear is settled — RULED: at the ending, always

**No. A fear cannot be settled in the cautious phase.** Both sentences `Job75` found are faults,
**and the thing they were reaching for is true and must not be lost.**

### Why the ending, and nowhere else

**The cautious phase examines**, which is where a fear is raised and weighed. **Disposing of a
fear is the detached phase's work** — the detached phase takes in what arrived and disposes of it,
with the lean setting whether an arriving fear is processed or ignored (RULED 09-16). **A fear
settled during the examining would mean the examining did the disposing**, and the detached phase
would then have nothing to do in a cycle that raised a fear.

**It also breaks the four fates.** Worked through, given up on, ignored and blocked are what
happens to a fear **at the ending**. If some fears never arrive there, **the four stop being
exhaustive** and nothing names the fifth outcome.

### What the two sentences were reaching for, which is real

**`Job75`'s first branch states it correctly.** Heavy examining means a fear arrives at the ending
**already worked out** — weighed, its trouble understood, the next step clear. **The disposing is
then easy and quick**, and from inside it can feel as though nothing happened at the ending at all.

A person who examines cursorily sends the same fear to the ending **unweighed**, and the ending
has to do something with a fear nobody has understood.

**So the contrast between fixations survives. What moves is where the work happens.**

### Repair sense for both sites

**Not *settled before the ending*. *Worked out before the ending*.**

- `Underneath the Cycle`, under *Where a fixation acts* — *Many fears are raised, and most are
  settled before the ending* becomes: many fears are raised, and most are worked out before the
  ending.
- The fixations chapter, under *Which fixation handles a fear* — *settles most of what might go
  wrong before the detached phase is reached* becomes: works out most of what might go wrong
  before the detached phase is reached.

**The register line needs no qualification.** Every aversion is raised in the cautious phase and
meets its fate at the ending, as written.

### One thing to check while those rows are written

**The enthusiastic and detached descriptions in the same two passages.** All three are usually
written in parallel, so the same slip may be in either. **If either says a fear is settled anywhere
but the ending, it is the same fault.**
