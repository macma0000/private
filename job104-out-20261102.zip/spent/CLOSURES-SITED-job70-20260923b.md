# SITED CLOSURES — `Job70 doctrine 09152026`, second, third and fourth sittings

Cut 2026-09-23. **Supersedes `CLOSURES-SITED-job70-20260923.md` and
`CLOSURES-SITED-job70-20260916.md`.** Everything in both is here, with the fourth sitting added
and two items that were carried open now closed.

Site and claim, never the sentence. A drafting session writes the sentences.

**Not applied. Nothing in this file has been carried into any master.**

**What these sittings had in hand:** `BRIEF-for-job70-from-job72-20260916.md`,
`ARC-ACCOUNT-from-job72-20260916.md` and `WORD-RULINGS-book2-20260916.md`. **No manuscript and no
record**, so no sitting appended the record. The block at the end is for a later session to append,
under the pattern `job34` set for a session appending on behalf of one that could not.

**A warning about the word rulings.** The copy in hand is the 09-16 cut. Sessions have run since,
and `Job74`'s drafting is known to have retired `crossing` and split the phases. **A new lettered
word-rulings file cut from the 09-16 copy would silently drop that work**, so the word rulings from
these sittings are carried here as an addendum to be merged. That is a deliberate departure from
the brief's instruction to cut the new letter in session.

---

## Two corrections to this session's first sitting, owned

- **Closure 5 of `CLOSURES-SITED-job70-20260915.md`** marked the `attention` reading as not a
  ruling, then said a drafting session *may work from* it. That clause is what let `Job71` apply
  it. A reading a drafting session may work from is a ruling in practice. **No `[C]` reading in
  this file carries that licence.**
- **Closure 3's** *a Five looking with lent motivation has nothing directing the looking* was
  `[C]`'s sentence and is false (`[A]` 09-16). *Can notice what no fear pointed at* stands.

---

# Where action happens (2026-09-16)

## Ruled

**An action is placed by the motive behind it.** An action released by going toward something
comes at the enthusiastic phase. An action released by fending something off comes at the
cautious phase. **The same outward act can be either.**

`[A]`'s words:

> "the snapping would be another thought cycle where the desire to end the pain was decided, with
> the snapping occurring at the end of a truncated cycle." would that be the end of a B cycle since
> it's motivated by aversion?

> "desire to be rid of something an aversion" - i don't know. in my case it's definitely an
> aversion, but i have a B fixation. i could imagine an A fixation person thinking "wouldn't it be
> nice if i were rid of something". my guess is that both can happen. i think there is happy
> aggression and angry aggression. i've had experiences of people happily manipulating me.
> snapping, however, is clearly angry.

**What follows.**

- **Aggression is not one kind of action.** Happy aggression — someone cheerfully manipulating
  another person — is going toward, so its action comes at the enthusiastic phase. Angry
  aggression is fending off, so its action comes at the cautious phase.
- **The angry remark in `[A]`'s truncated-cycle example comes at the cautious phase**, where the
  examining is cut short by the remark being released instead. `[A]` proposed the placement himself.
- **The wording of a desire does not decide where its action goes.** *To be rid of something* can
  be felt as fending off or as going toward, depending on the person.

## `[C]` readings — NOT ruled

- **A cautious action is examining done in the world** — checking, securing, preparing. If so, the
  cautious phase does one job two ways, which answers `Job72`'s worry that it would do two.
- **Ch 15's *if they act, the action begins a new arc inside the decision*** stands: a decision can
  come at the ending, and the decided step's action is released in a later cycle.
- **The 08-25 gun example agrees.** That ruling placed the first urge at the enthusiastic phase;
  this one places the release, which for buying a gun to be safe is the cautious phase.

---

# The boundary of the model (2026-09-23)

## Ruled

**A person with no attraction and no aversion at all is outside the model.** `[A]`:

> is a detached person with no leans the same as a buddha with no attractions or aversions. i think
> not and that is new to the book. a detached person is still averse to disturbances while a buddha
> is indifferent to them.

`[A]` called this new to the book. **A dislike of disturbance is what makes detachment an
orientation.** Take it away and nothing is left that could be called a place a person stays at.

**Where it goes.** `[A]` 09-23: *ok. keep buddha.* Ch 4 says plainly that detachment is not
indifference and that a detached person minds disturbance, with no figure named — the misreading
happens at first contact with the word. The buddha is named once in Part 3, where fixation and
Naranjo are introduced.

**How the word is used.** `[A]` 09-23: *if we leave out the article "the" and use lower case
buddha, i think that names a class of people, not guatama buddha. using the class rather than the
particular man is better.* **Ruled on `[C]`'s recommendation, which `[A]` took: the class is
defined in the sentence, and the word is named second** — *a person who has given up all attraction
and aversion, what buddhism calls a buddha, is outside this model.* Lower case. `[C]`'s reason,
given and accepted: lower case and a dropped article do not by themselves make English read a name
as a class, and a reader who knows the word will otherwise supply a definition the book never gave.

## `[C]` reading — NOT ruled

**A buddha is not the top of the health axis**, which was ruled to have no top. Outside the model
rather than high in it.

---

# The standing dislike of disturbance (2026-09-23)

## Ruled

**`aversion` stays the class word for fear and disappointment, in the cautious phase only.** `[A]`:

> i question my use of the word aversion - i think it should be reserved to cautious phase.

**What a detached person has is a standing dislike of disturbance.** `[A]`, on whether it is raised
fresh each cycle:

> detached always wants to avoid disturbance whether or not the disturbance is the same or
> different.

**So the standing dislike is a feature of the orientation, not something that happens in a cycle.**
It is not raised by anything and meets no fate, which is what separates it from an aversion: an
aversion is raised in the cautious phase by examining, and meets a fate at that cycle's ending.

**It is present at zero lean**, which is what `[A]`'s buddha answer settled. So the want for peace
belongs to detachment itself and not to the lean.

**The lean and the standing dislike are tied together, which is new.** `[A]` 09-23, naming the two
ways of avoiding:

> it is about avoiding, either by fixing or forgetting.

**Fixing is the caution end, where an arriving fear is processed. Forgetting is the enthusiasm end,
where it is ignored. The lean sets which kind of avoiding a person does, and both serve the same
standing dislike.** Until now the lean's job and the want for peace were two separate facts about a
detached realm.

**The name is ruled and `[A]` is not satisfied with it.** `[A]`: *it works. it's a little clumsy but
i can't think of an alternative.* **A drafting session uses `standing dislike of disturbance` and
may propose a better name to `[A]`. It must not substitute one silently.** `[C]`'s candidates,
offered and not taken: *dislike of disturbance*, with the standingness carried by the sentence;
*wanting not to be disturbed*; *dislike of being disturbed*.

## Ruled — where a detached person's action comes

**A detached realm releases no action of its own**, which is the same fact as generating nothing
rather than a second one. Disposal is not action in the world.

**Where a detached person acts, the action comes at the cautious phase**, because fixing and
forgetting are both avoiding, and avoiding is fending off. A Nine smoothing over a conflict is
fixing a disturbance.

## `[C]` readings — NOT ruled

- **The standing dislike is why a detached person notices disturbances**, which the book asserts
  and does not account for. The dislike points the noticing at whatever breaks the peace; the fear
  that a disturbance raises then runs the ordinary course, and the fixing is released against that
  fear.
- **The enthusiasm end of a detached realm produces almost no action at all**, since forgetting is
  not an action in the world. That fits what the book says about a Nine's inertia and about the
  Seven's psychic realm.

---

# Panic, and the stress hypothesis (2026-09-23)

## Ruled

**Panic acts on a fear, not on a want.** `[A]`: *on fear.* A person who panics is fleeing, freezing
or lashing out, and each is fending off. What panic acts on is a fear that has arrived and not been
weighed.

**So panic's action comes at the cautious phase**, and the collision with the action ruling is
gone. It also agrees with `[A]`'s 09-16 scoping of panic as a truncated cycle rather than a reflex,
because judging a fear is the cautious phase's own work.

**The stress hypothesis is restated.** `[A]`: *yes.*

> Stress cuts short the work of a person's own phase, and the person acts on what is in hand
> unworked.

A cautious person acts on a fear that was raised but not weighed. An enthusiastic person stops
short of acting, so nothing arises. A detached person stops taking in and disposing, and is left
holding what arrived.

**Why the old wording had to go:** it said the previous phase's material shows unworked, and the
cautious case does not fit — the cautious phase raises the fear itself, by examining. The new
wording is also closer to the truncated cycle `[A]` ruled on 09-16, which is defined as the
examining cut short rather than as a phase skipped.

**The *I suspect* marking.** **Dropped from the cautious case**, which is now a plain consequence
of the truncated cycle. **Kept on the enthusiastic case and the detached case**, which nothing has
confirmed.

---

## The rows

| # | Site | What changes |
|---|---|---|
| 1 | `ARC-ACCOUNT-from-job72-20260916.md` §6, the truncated-cycle case — *the action happens at the ending* | The angry remark's action comes at the cautious phase. The account is not drafted anywhere, so the account is the site |
| 2 | The brief's §3 placement *at the ending* | Superseded by the action ruling |
| 3 | Ch 4, enthusiasm's competence named as *doing* | **NO CHANGE.** Whether Ch 4 should also name fending off as caution's kind of action is not ruled |
| 4 | Ch 4, where detachment is introduced | New: detachment is not indifference, and a detached person minds disturbance. No figure named here |
| 5 | Part 3, where fixation and Naranjo are introduced | New: the class defined in the sentence, `buddha` named second, lower case, outside the model |
| 6 | Wherever the detached realm's wants are described | The standing dislike of disturbance belongs to detachment itself, present at zero lean. The lean sets which kind of avoiding — fixing or forgetting — serves it |
| 7 | Wherever `aversion` appears outside the cautious phase | `aversion` is the class word for fear and disappointment only. Detachment's is the standing dislike of disturbance |
| 8 | `ARC-ACCOUNT-from-job72-20260916.md` §6, the stress hypothesis line | Restated as above. The *I suspect* marking comes off the cautious case and stays on the other two |
| 9 | Wherever a detached person is described as acting | The action comes at the cautious phase. A detached realm releases no action of its own |

---

## To be merged into the word rulings file — NOT cut as a new letter here

Merge into whatever the live word-rulings file is, since the 09-16 copy in hand is behind
`Job74`'s work.

Under **§2 Orientation, fixation, position**, amend the `lean` entry:

> **Detachment's standing dislike of disturbance does not come from the lean** (RULED 09-23). The
> lean sets which kind of avoiding serves the dislike — **fixing** at the caution end, **forgetting**
> at the enthusiasm end (RULED 09-23: *it is about avoiding, either by fixing or forgetting*).

Under **§4a Aversion, fear, want**, amend:

> **`aversion` is reserved to the cautious phase** (RULED 09-23: *i think it should be reserved to
> cautious phase*). Fear and disappointment are the two aversions. **Detachment's is a standing
> dislike of disturbance, never called an aversion.** `[A]` accepted the name and called it *a
> little clumsy*; a drafting session may propose a better one to him and must not substitute one
> silently.

Under **§7 Register and voice**, or wherever proper names are handled, add:

> **buddha** — RULED 09-23. Lower case, no article, and **the class is defined in the sentence
> before the word appears**. Names a state a person could reach, never Gautama. Used once, in
> Part 3. `[A]`: *using the class rather than the particular man is better.*

Add to the patterns block:

```
buddha | \bbuddh\w* | all | lower case, class defined first, Part 3 only (RULED 09-23)
aversion-scope | \baversion\w* | all | cautious phase only; detachment's is the standing dislike of disturbance (RULED 09-23)
```

---

## For a later session to append to the record

Append after the record's current last marker. Name the parent count from the marker that session
finds. Write the marker in the canonical bold form.

```
## `Job70 doctrine 09152026` — second, third and fourth sittings, appended on its behalf

**Provenance.** `[A]` returned to `Job70` on 2026-09-16 and twice on 2026-09-23, each time with
files cut by `Job72` and no manuscript or record in hand, so `Job70` could not append. Blockquotes
are `[A]`'s typing. Everything else is `[C]`'s report.

**2026-09-16, where action happens.** `[C]` recommended `[A]`'s own suggestion — enthusiastic
actions in the enthusiastic phase, cautious actions in the cautious phase — and read the angry
remark in his truncated-cycle example as released at the enthusiastic phase. `[A]` asked what "the
snap" was; `[C]` had shortened his "snapping" without saying so. `[A]` then asked:

> "the snapping would be another thought cycle where the desire to end the pain was decided, with
> the snapping occurring at the end of a truncated cycle." would that be the end of a B cycle since
> it's motivated by aversion?

`[C]` withdrew its placement and proposed that an action is placed by its motive. Asked whether a
desire to be rid of something counts as an aversion:

> "desire to be rid of something an aversion" - i don't know. in my case it's definitely an
> aversion, but i have a B fixation. i could imagine an A fixation person thinking "wouldn't it be
> nice if i were rid of something". my guess is that both can happen. i think there is happy
> aggression and angry aggression. i've had experiences of people happily manipulating me.
> snapping, however, is clearly angry.

**Ruled: an action is placed by the motive behind it — going toward at the enthusiastic phase,
fending off at the cautious phase — and the same outward act can be either.**

**2026-09-23, the boundary of the model.** `[A]` asked whether a detached person's want for peace
should be classed as motivation. `[C]` recommended that it should, and could not settle whether the
want comes from the lean or from detachment itself. `[A]`:

> is a detached person with no leans the same as a buddha with no attractions or aversions. i think
> not and that is new to the book. a detached person is still averse to disturbances while a buddha
> is indifferent to them.

**Ruled: the dislike of disturbance is present at zero lean and belongs to detachment itself. A
person with no attraction and no aversion at all is outside the model.** On naming it:

> if we leave out the article "the" and use lower case buddha, i think that names a class of
> people, not guatama buddha. using the class rather than the particular man is better.

`[C]` agreed about the class but said lower case and a dropped article do not by themselves make
English read a name as a class, and recommended defining the class in the sentence and naming the
word second. `[A]` took the recommendation.

**2026-09-23, panic and the standing dislike.** On whether panic acts on a want or a fear, `[A]`:
*on fear.* **Ruled**, which places panic's action at the cautious phase and removes the collision
with the action ruling. `[C]` then showed that the stress hypothesis's old wording — the previous
phase's material showing unworked — does not fit the cautious case, since the cautious phase raises
the fear itself. **Ruled, `[A]`: *yes*. Stress cuts short the work of a person's own phase, and the
person acts on what is in hand unworked.** The *I suspect* marking comes off the cautious case and
stays on the enthusiastic and detached cases.

On the detached realm's own motive, `[C]` asked whether the dislike of disturbance is standing or
raised fresh each cycle. `[A]`:

> i'm not sure about the difference. detached always wants to avoid disturbance whether or not the
> disturbance is the same or different. also i question my use of the word aversion - i think it
> should be reserved to cautious phase.

**Ruled: `aversion` is reserved to the cautious phase, and detachment's is a standing dislike of
disturbance** — a feature of the orientation, not raised and meeting no fate. Earlier in the same
sitting `[A]` had named the two ways it works:

> could it be called aversion without fear? it is about avoiding, either by fixing or forgetting.

**So the lean sets which kind of avoiding a detached person does — fixing at the caution end,
forgetting at the enthusiasm end — and both serve the standing dislike.** `[C]`: this ties the
lean's 09-16 job to the want for peace, which were two separate facts until now. **A detached realm
releases no action of its own, and where a detached person acts the action comes at the cautious
phase**, since both fixing and forgetting are avoiding.

On the name, `[A]`: *it works. it's a little clumsy but i can't think of an alternative.* Recorded
so a later session may propose a better one rather than assume the name was chosen for its sound.

Sited in `CLOSURES-SITED-job70-20260923b.md`.
```
