# SET NOTE — from `Job66 coherence 09122026`, 2026-09-12

## What arrived

One zip, `job65-out-20260912.zip`, directory `job66set`, verified against
`MANIFEST-job66-20260912.md`: **76 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the
manifest.** The screen fired twice and both are expected — `AUTHOR-RECORD.md` as CARRY DO NOT
READ, and `HANDOFF-20260906.md` quoting the restriction string. Both tools exempted themselves.

**This is a coherence session and the record was not opened.** Its reach was checked without
opening it: 60,946 w, forty-sixth append, marker `Job65 coherence 09122026`, parent 60,384 —
matching the manifest row and Job65's set note. Chain clean.

**`[A]` named this session `Job66 coherence 09122026` and the label says `Job66 20260912`.** The
counter and the date agree. He asserted coherence where Job65 recommended drafting, so **Job65's
two repairs are still unapplied** and `BOOK2-20260912.md` is untouched at 35,695 w, md5
`1065e37e` — the same master Job65 read.

## What this session did

The claim inventory was rebuilt by Job65 yesterday against this exact master, so nothing was to
be gained by rebuilding it. **Job65 amended entries from its re-read and did not re-run the four
tests**, and test (d) had not been run over Part 3 since 09-02. This session ran the four tests
over Part 3's entries.

**Six faults, numbered 48 to 53.** Three came out of the tests and three out of the exchange with
`[A]`. Four were ruled or settled by him in session, one is a wording repair needing no ruling,
and one is blocked until a doctrine session rules.

- **Fault 48, OPEN and blocked.** Ch 16 uses *the basic fear* four times and book 2 defines it
  nowhere. It seeds the descent, it has a want behind it, its realization is the bottom, and it
  is the Level 1 row. The term is Riso and Hudson's and the chapter has just said their
  descriptions are not reproduced.
- **Fault 49, ruled.** Ch 15's split between the orientations is too clean and reads as saying
  nothing acts at the crossing for a person detached in neither realm.
- **Fault 50, ruled.** Five sites say time or dwelling where the quantity is attention.
- **Fault 51, settled.** Ch 17's climb is written as a journey along the cycle, which nothing in
  the book provides for.
- **Fault 52, ruled.** Nothing says what sets a person preparing; `[A]` supplied the claim.
- **Fault 53.** Ch 15 spends the mental deposits two sections before they are earned.

**Tests (b) and (c) came back clean over Part 3**, and the entries checked are named in the
inventory so a later session does not re-open them.

**One inventory line was stale and is corrected.** The *Rising* entry still sent a reader to Ch
5's Type 1 and Type 6 sketches for the realms competing for attention. Fault 6 was discharged
09-06 when Ch 4 gained the sentence about one attention and two realms.

## What `[A]` ruled, and the one thing he reopened

Four rulings are in `REPAIRS-job66-20260912.md` with their sites and proposed wordings: the
crossing is attended shallowly rather than not at all; attention replaces time at five sites;
the climb is not a journey; and the pain of life not working has to be understood as coming from
fears not faced before a person prepares.

**He also reopened how an arc gets its realm** — *the process arc does not run in a particular
realm… the fears are of the process arcs* — which collides with his own 08-19 closure and
falsifies two sentences in Ch 15. That and three other items are in
`NOTE-doctrine-from-job66-20260912.md`.

## Files

Cut: `NOTE-doctrine-from-job66-20260912.md`, `REPAIRS-job66-20260912.md`, this note.
`CLAIM-INVENTORY-book2-20260902.md` updated in place, 27,339 → 28,642 w, name unchanged as at
the 09-06, 09-07, 09-09 and 09-12 passes. **No manuscript touched.**

**Record: forty-seventh append, blind, head 61,860 w, md5 `b514534e`, parent 60,946.** Prefix
verified byte-identical, 59 markers, canonical bold marker form so the sweep can read it.

## Recommendation for the next session, `[A]`'s to assert

**Doctrine.** The drafting backlog is now seven items across two repairs files and it would
ordinarily be the call. What decides against it is that **Repair 1 and the first doctrine item
are in the same section.** Fault 49's repair rewrites Ch 15 *Which fixation handles a fear*,
and the unruled question about an arc's realm falsifies that section's opening sentence. A
drafting session run first would write the section twice.

Repairs 2 to 5 are independent of the doctrine items and could be taken by a drafting session in
either order.
