# ADDENDUM to `FINDINGS-job77-20261006.md` — `Job77 coherence 20261006`, 2026-10-07

**Why this is a separate file.** `job77-out-20261006.zip` had already gone out, and a drafting session
holds it. `[A]` then brought one more ruling from `Job70 doctrine 09152026`. Re-cutting the set would
leave two sets under one session. So this file travels on its own. **Give it to whichever session
holds the set now. It is to be added to that session's live set, and to its outgoing manifest.**

**The record is not touched here.** The copy of the record this session holds may already be behind
the drafting session's copy, and a second append from here would fork the record. **The block at the
end of this file is to be appended to the record by the session that holds the set**, on `Job77`'s
behalf, with its provenance, as the handoff's record section allows.

Blockquotes are sentences of `BOOK2-20261005.md`, checked with `quotecheck.py quotes`. `[A]`'s words
are in italics.

---

## 10. Pain is pain: avoiding the greater pain runs on pain of any kind — RULED

`Job70` put it to `[A]` as a widening for him to make or decline. The brake's comparison had been
written about the pain of staying as one is, and it reads as psychic. The question was whether
extreme physical pain can drive the turning point too. `[A]`: *pain is pain. pulling your own painful
tooth in the past when a dentist wasn't available is an example.*

**So avoiding the greater pain works with pain of any kind.** What decides is which is worse:
staying as one is, or facing what is avoided. The pain on either side can be physical or psychic.

**What happened to `Job70`'s two further points.** `[A]` settled both on 2026-10-07 in `Job77`'s chat:

- **The physical example is written.** `[A]`: *i wrote the physical pain example.* `[A]` wrote it himself, and
  the drafting session takes it from him. It does not compose one.
- **`Job70`'s *the brake is the general mechanism, and the climb is what it looks like when the thing
  faced is a buried fear* is corrected.** `[A]`: *the word "brake" refers to stopping the fall but
  avoiding the greater pain is also a mechanism the motivates facing fears and rising.* So **`brake`
  keeps its one meaning, the thing that stops the fall.** The general mechanism is **avoiding the
  greater pain**. It works in both directions: it stops a fall, and it moves a person to face a fear
  and rise. The brake is one of its uses, and the climb is another. `[C]` DECISION, under the style
  guide's rule against coined handles: **the general mechanism gets no name of its own.** The book
  says what it is, *avoiding the greater pain*, wherever it is meant.

**Sites — *Why this does not take everyone to the bottom*:**

> The routing is not a choice. What the struggling person is settling is which is more painful — staying as they are, or facing the pain of unburying what has been buried.

> As consequences accumulate, the pain of staying rises, and at some point it passes the pain of facing — and the person faces the fear.

**Site — *Rising*:**

> What sets a person preparing is the same comparison that decides a fear's fate in the detached phase: the pain of life not working against the pain of facing what has been buried.

`[C]` REPAIR SENSE: state the comparison once in general, with pain of either kind on either side.
Then give the tooth as the plain physical case, and keep the buried-material case as the one the
chapter is about.

**WITHDRAWN — `[C]`'s earlier caution was wrong.** This file first said that pulling one's own tooth
is a comparison made consciously, so *That comparison is made below consciousness* had to stay with
the buried case. `[A]`, 2026-10-07: *the decision to endure the pain of pulling ones tooth seems to be
a pre-conscious comparison of pain, the same as facing a fear.* `Job70` agreed. The reasoning about
the tooth is conscious, but the turn itself arrives when enduring the pulling has become less bad than
going on. **So the comparison is pre-conscious in every case.** What differs is whether the person can
see what is being weighed. With the tooth both pains are in view, and the person can tell it
afterwards. With a buried fear one side is not in view, so the moment seems to come from nowhere. The
book's *That comparison is made below consciousness* can therefore go with the general statement.
What is particular to the buried case is that one of the two pains cannot be seen.

### `brake` leaves the book — RULED

`[A]` asked: *is there now a better word than "brake"?* `Job70` recommends retiring it from the book:
a brake gives an object a job the model has no object for, and it names only the downward direction.
Asked *Shall the book drop `brake`, as Job70 recommends?*, `[A]`: *yes.* **RULED: `brake` is not used in
the book.** The sessions keep it for their own use, as they do slot numbers. A word ruling, so the next
register letter carries it.

`[C]` checked the master. **The book uses `brake` as a name exactly once, and never defines it:**

> The brake grows for the same reason the fall does.

The Three's *without brakes* is ordinary English and stays. So retiring the word from the book means
repairing that one sentence, for example by saying what grows: the pain of staying. Suggested
`wordcheck.py` pattern for the next register letter: `brake | \bbrakes?\b | all | RULED 10-07: not used in
the book; say what happens. The Three's "without brakes" is ordinary English and stays`.

### The sweep `Job70` asked for

`Job70` asked whether the book anywhere treats physical and psychic pain as different in kind,
rather than as pain about different subject matter. **`[C]` read every one of the 41 sentences in the
master that use `pain`. None treats the two as different in kind.** The orientations chapter already
says the opposite:

> A person has one capacity to bear pain, not one for each realm, so a hard week in the physical world leaves less to face an inner fear with.

The other uses either name a pain that starts a thought, with no realm, or are the brake's pain of
staying and pain of facing. Those are the sites above.

---

## The case `[A]` reported — routed to the unease material, not drafted

`[A]` told `Job70` of a person *who has overcome aversion to aversion. she learned to recognize the
secondary aversion and resist it. the ability to recognize it can from learning to control migraine
pain by avoiding resisting it.* He added: *apparently the secondary aversion is not so deeply buried
which means the aversion to the secondary aversion isn't as strong. that may be different for other
people. and notice the original motivation was extreme pain which enabled learning equanimity. the
ability to be equanimous to aversion would be a side effect. that fits the worse pain turning point
for buried fear - applied to physical pain instead.*

**`Job70`'S recommendation**, not ruled by `[A]`: the case belongs with the unease material, because
what she recognizes is in view, so it is not what the book calls blocked. `Job70` calls it an instance
of the brake, since the physical pain passed the turning point. Under `[A]`'s correction it is an
instance of avoiding the greater pain, working toward facing, not of the brake. What transferred is a side effect, not a
method. **Its conditions, if it ever goes in:**

- no named person, and no migraine detail that invites a reader to try it;
- told as one person's report, not as what the model predicts;
- `[A]`'s caution travels with it: a secondary aversion that can be recognized was not deeply buried,
  and someone whose turning away fires before noticing has nothing to catch.

**`[C]` notes for whoever drafts it.**

- **Vocabulary.** `aversion` is reserved to the cautious phase (09-23). *Aversion to aversion* and
  *secondary aversion* are `[A]`'s working words, and are not to be carried onto the page; the book's
  form is the fear of the fear.
- **`equanimity` is out** (09-23). `Job70`'s plain form is *she stopped resisting the pain and found
  she could sit with it*.

**No drafting session writes this case.** The unease material is a job of its own and is not in the
set.

---

## BLOCK TO APPEND TO THE RECORD — on `Job77`'s behalf

The session that appends this writes its own RECORD MARKER after it, giving its own session name, and
says in the marker that the block is `Job77`'s. Everything below the rule is to be copied verbatim.

---

### `Job77 coherence 20261006` — late addition, 2026-10-07, appended by another session on its behalf

**Provenance.** `[A]` pasted this into `Job77`'s chat on 2026-10-07, after `Job77`'s set had gone out.
It is `Job70 doctrine 09152026`'s exchange with `[A]`. `[A]`'s lines are in it, and the rest is
`Job70`'s. It is quoted verbatim, relayed from `Job70`:

"i talked to someone who has overcome aversion to aversion. she learned to recognize the secondary
aversion and resist it. the ability to recognize it can from learning to control migraine pain by
avoiding resisting it. can we use that?
There is something real in it, and I would use it carefully rather than wholesale, because it collides
with one ruling and supports another.
What it supports. You ruled this morning that recognition goes one kind at a time, and that a person
can understand in general that they do this. Her case is exactly that shape: a general understanding
reached in one place, then applied kind by kind. What she learned with pain was not a technique for
fear — it was that resisting a sensation makes it worse, and that she can tell when she is resisting.
That is the general understanding doing its proper job, which is making the gap noticeable.
What it collides with. It is a report of one person overcoming something, and the book's account of
the climb says the pressure to face a thing comes from which pain is greater, not from a method. If her
case goes in as a method, the book acquires a practice it has nowhere else and cannot support. You also
ruled out telling anyone to fix rather than hide, on the ground that it asks for an output they cannot
select.
And one thing in it is not what the book calls burying. She recognizes the secondary aversion, which
means it is in view. What the book calls blocked is the case where the turning away fires before
anything is noticed. So her material is about the fear of fear running where the person can catch it —
closer to the unease loop than to burial.
That gives the recommendation. The case belongs with the unease loop, which is undrafted and needs its
own sitting, rather than in the burial material or the climb. There it does real work: it is an
instance of a person stepping out of the loop by noticing the second fear instead of acting on it,
which the loop account says is possible because unease is felt.
Two conditions if it goes in. No named person and no migraine detail that invites a reader to try it.
And it is one person's report, so it is told as an observation, not as what the model predicts.
apparently the secondary aversion is not so deeply buried which means the aversion to the secondary
aversion isn't as strong. that may be different for other people. and notice the original motivation
was extreme pain which enabled learning equanimity. the ability to be equanimous to aversion would be a
side effect. that fits the worse pain turning point for buried fear - applied to physical pain instead.
That last point is the substantial one, and it extends your brake account rather than sitting beside
it.
The brake says what decides is which pain is greater — staying as one is, or facing what was avoided.
Your reading of her case puts physical pain on one side of that comparison. The migraine was worse than
what resisting it was protecting her from, so she stopped resisting. Same mechanism, different kind of
pain driving it.
And the transfer is a side effect, not a method. What she learned was not how to handle fear. She
learned not to resist a sensation, and the capacity turned out to apply to a sensation she had not been
working on. Nobody chose that, which keeps it clear of the re-sighting ruling — the ability arrived, it
was not selected.
Your point about depth is the right caution and it should travel with the case. A secondary aversion
that can be recognized is one that was not deeply buried, and the aversion to it is correspondingly
weak. Someone whose secondary aversion fires before noticing has nothing to catch, so the same route is
not open to them. That keeps the case from reading as a way out that anybody can take.
On `equanimity`: I would keep the word out, as you ruled earlier today, and say what happened instead —
she stopped resisting the pain and found she could sit with it.
One thing worth putting to you, and it is doctrine rather than wording. If extreme physical pain can
drive the turning point, then the brake runs on pain of any kind rather than on psychic pain. The
account as written is about the pain of staying as one is, which reads psychic. That is a widening, and
it is yours to make or decline.
pain is pain. pulling your own painful tooth in the past when a dentist wasn't available is an example.
Ruled, and your example makes the point better than an argument would. A person pulls their own tooth
when the toothache is worse than what pulling it will cost. Nothing psychic is involved, and the shape
is identical.
So the brake runs on pain of any kind. What decides is which is worse — staying as one is, or facing
what is avoided — and the pain on either side can be physical or psychic. The account as written reads
psychic because its examples are, not because the mechanism is.
Three things follow and should go to Job77 with it.
The brake material needs its claim widened and probably one plain example of the physical case, since
a reader meeting only psychic examples will take the mechanism to be about psychic pain.
The migraine case becomes an instance of the brake rather than a separate story. Physical pain passed
the turning point, she stopped resisting, and the capacity turned out to apply elsewhere.
And it tidies something that was awkward. The brake and the climb both describe a person facing what
they avoided, and the climb is about buried fears. Now the brake is the general mechanism and the climb
is what it looks like when what is faced is a buried fear.
One thing I would not have you settle now. If pain is pain, the two realms are not two kinds of pain,
and somewhere the book may be treating physical and psychic pain as different in kind rather than in
subject matter. That is a sweep for Job77 rather than a question for you."

`[C]`'s result for the sweep: none of the master's 41 sentences using `pain` treats the two as
different in kind. The orientations chapter's *A person has one capacity to bear pain, not one for each
realm* already says the opposite. `Job77` wrote `ADDENDUM-job77-20261007.md` with the sites.

`[A]`, later the same day, in `Job77`'s chat: *i wrote the physical pain example. the word "brake"
refers to stopping the fall but avoiding the greater pain is also a mechanism the motivates facing
fears and rising.*

`[A]`, later again: *two things. 1) is there now a better word than "brake"? 2) the decision to endure
the pain of pulling ones tooth seems to be a pre-conscious comparison of pain, the same as facing a
fear.* `Job70` agreed on the second, and recommended retiring `brake` from the book. `Job77` withdrew
its caution that the tooth comparison was conscious.

`[C]` asked: *Shall the book drop `brake`, as Job70 recommends?* `[A]`: *yes.*
