# PROPOSED ORDER — chapters and sections of book 2

Cut 2026-10-30 by `Job99 doctrine 20261029`, at `[A]`'s request (14:43 and 14:44): *show the proposed order of chapters
and section titles.* and *also mark those where the order is changed from the current book.*

**Status: `[C]`'s proposal, with one change RULED.** The new chapter *What Becomes of a Fear* was put to `[A]` on 10-30 and
he answered at 15:03: *yes*. Everything else here is `[C]`'s and is not ruled. It is drawn from `BOOK2-20261029b.md` (md5 `f49c8c53`), from the
findings in `FINDINGS-job99-20261029.md`, and from `[A]`'s account of Part 3 given on 10-30 (two subjects: the fixations
against the phases and the way each fixation runs a thought; and what is behind the Levels). Each change is checked below
against the placements `[A]` has ruled or approved before. **One change goes against a placement of his, and it is put to
him on its own: the new chapter.**

**How to read the marks.** A mark in square brackets says what changes. A section with no mark keeps its place. Not shown:
single paragraphs that move inside a section, passages that get shorter because they repeat, and the openings that every
Part and chapter will get.

---

## The order

PART 1 — THE MODEL

- A New Theory of the Enneagram
- The Nine Enneagram Types — Profiles and Self-Perception
  - Overview; Type 1 to Type 9; The Common Thread Between the Types
- The Two Realms
- The Three Orientations [has no sections now]
  - Attraction, aversion, want and fear [new section]
  - Enthusiastic, cautious and detached [new section; takes in "Each competence is real" from later in the chapter]
  - Taking in and noticing [new section]
  - Intuition [new section]
  - When something goes wrong [new section]
  - Being caught, and what a person can bear [new section]
  - What a detached person does with a fear [new section; moved from the middle of the chapter to the end]
- Where the Types Come From
  - Type 1 to Type 9; In Short

PART 2 — THE FINER STRUCTURE

- The Grid
- The Cycle
  - Forward; Backward; The two faces of detachment; What kind of thing this is; The smallest scale
- Relational Positions
- Relational Dynamics
  - What passes between them
  - Position by position
  - Equal positions, and the mirror pairs [moved up, to before In everyday life]
  - In everyday life
  - Aligned and non-aligned
  - Friction from the detached realm
  - Diversity
- The Figure's Own Lines
  - The types ahead; Why the two shapes close; The relations the figure does not draw; As the grip loosens; Reading it
    from either end
- Leans, and the Classical Wings
  - The eight wings
  - Reading a person either way
  - Where the two systems disagree [moved up, to after Reading a person either way]
  - Fractional leans
  - Opposite
  - The lean in detachment is not like the others
  - What the leans do with what a person notices
- Learning to See (reserved, not drafted)

PART 3 — THE DEPTH OF FIXATION

- Where the Inner World Came From
  - A part of the world that contains the rest; The turn inward; The imaginary self; What self-reference does; A slant on
    everything rendered; Why detachment is the odd one; The same capacity, turned the other way
- Underneath the Cycle
  - The phases and their names
  - The caution end and the enthusiasm end [new section, from the chapter's opening]
  - Where a fear meets its fate
  - One thought, step by step
  - What a thought leaves
  - A want that lasts, and a fear that comes back
  - Disappointment
  - Gratification
  - Action without a full thought
  - Where a fixation acts
- What Becomes of a Fear [new chapter; its sections come from The Fixations Themselves]
  - Disregarding, and not seeing at all [moved from The Fixations Themselves]
  - The four fates [moved from The Fixations Themselves]
  - How a fear comes to be buried [new section, gathered from The range of detachment and What previous thoughts have
    laid down]
  - Burial is not a decision [moved from The Fixations Themselves]
  - The blindness loop [new section, gathered from The range of detachment]
  - The unease loop [moved from The Fixations Themselves; the migraine story moves to Rising]
  - Lasting unease [new section, split from The unease loop]
- The Fixations Themselves
  - The range of detachment [its paragraphs on burial and the blindness loop move to What Becomes of a Fear]
  - Which fixation handles a fear
  - The four sketches
  - Two channels
  - The hinge
  - Habit carries it
  - What previous thoughts have laid down [its last paragraph, on how a burial builds, moves to What Becomes of a Fear]
- The Health Axis
  - The nine rungs
  - The process that produces the levels
  - The correspondence
  - The same nine names, two different shapes
  - What the axis is toward
  - The two ends, and what lies between them
  - Where a level change can happen
  - What a level is made of
  - [Spoiled arrivals moves to Falling and Rising]
- Falling and Rising
  - What actually descends
  - Leaving fears unweighed
  - Discomfort blocking and the fall [new title for The second way down, which is not blindness]
  - What falling takes from capacity
  - Spoiled arrivals [moved from The Health Axis]
  - Two things that cannot happen [moved up, from after What reaches someone who cannot see their own condition]
  - The last stretch [moved up, with Two things that cannot happen]
  - Why this does not take everyone to the bottom
  - What reaches someone who cannot see their own condition
  - Rising [takes in the migraine story from The unease loop]
  - The oldest material [new section, split from Rising]
  - A skill for handling fear [new section, split from Rising]
  - What is actually being undone
  - The summit, and what counterfeits it
  - Why trying harder does not change a person

PART 4 — PARALLELS (not drafted)

**Count.** Part 3 goes from five chapters to six, so Part 4's chapter numbers move up by one. The book uses no chapter
numbers in its prose, so only the table of contents changes.

---

## Why each change, and what it was checked against

### The orientations chapter gets sections

It is 2,020 words with about fourteen subjects and no headings (findings C1). The titles use the chapter's own words.

- **"Each competence is real" moves up** to sit with the three competences it is about. It now sits after the denial
  paragraphs, with nothing joining it to them.
- **The paragraphs on what a detached person does with a fear move to the end** (from *A detached person's own want is
  peace* to *intuition can act on it*). Two reasons. They use *more than the person can bear* before the chapter says what
  sets what a person can bear, and the sections on what goes wrong and on being caught say that. And the chapter then runs
  from what holds for all three orientations to what is special about one. The sentence placed there with `[A]`'s agreement in
  `Job70`'s sitting of 10-11 and 10-12, *What a person can bear is set by what previous thoughts have laid down*, stays
  immediately before the stress paragraph, where that placement put it. `[A]`'s own sentences in the denial paragraphs move whole and unchanged.
- **Checked:** no ruling on the order of this chapter's paragraphs was found in the record.

### Relational Dynamics: the mirror pairs before the sketches

The sketch of Elena and Marcus says *They share the mirror pair's blind spot too*; the section that says what a mirror pair
is comes after the sketches (findings C13). **Checked:** nothing in the record on this order.

### Leans: the two systems' disagreement after the reading either way

*Reading a person either way* ends on the one case the classical vocabulary cannot report, and *Where the two systems
disagree* opens *Two wings per type against eight*. They are one subject split by *Fractional leans* and *Opposite*.
**Checked:** the 09-02 architecture lists what the chapter keeps and does not order it. **The chapter's last section stays,
and stays last:** it is `[A]`'s own siting (08-15) and the short statement left behind on 09-02 when the full one moved.

### Underneath the Cycle: the two ends get their own section

The chapter's opening splits each phase into two halves and names the caution end and the enthusiasm end before *The phases
and their names*. The ends are used in every later chapter, so a section headed with their names is where a reader will look
for them. *Where a fear meets its fate* still comes before *One thought, step by step*: it says what the four fates are
before the example names them, as the style guide's rule to define a word before using it requires. **Checked:** `[A]`
approved during `job74-drafting-20260919` (09-19 to 09-23) that this chapter takes the whole account of a
thought; nothing leaves it.

### The new chapter, What Becomes of a Fear — the one change that goes against a placement of `[A]`'s

**What it holds:** everything about what becomes of a fear in the detached phase — the four fates, blocking of both kinds,
how a fear comes to be buried, why a burial is not a decision, the blindness loop, the unease loop, and lasting unease.
Today these sit in the middle of The Fixations Themselves, and the account of burial is told in seven places in that
chapter (findings C2).

**Why a chapter of its own, and why before The Fixations Themselves:**

- The fates, the burials and the unease are now about half of The Fixations Themselves, and they split that chapter's
  description of the fixations in two: the range of detachment on one side, the sketches on the other.
- **The sketches cannot come before the fates.** Three of them use *unattended*, which the four fates define. The 09-02
  architecture records this dependency and placed the fates first for it. Putting the new chapter before The Fixations
  Themselves keeps that.
- With the fates first, *unattended*, *lasting unease* and *the blindness loop* are no longer used in The Fixations
  Themselves before they are defined.
- **Disregarding, and not seeing at all goes with the fates and stays immediately before them.** That is the shape `[A]`
  asked for on 09-02: the miniature first, and the full account immediately after.
- The Fixations Themselves then does what `[A]` ruled on 09-02: the descriptions of the fixations first, and where a
  fixation comes from second.

**The placement it goes against.** On 09-02 `[A]` ruled that the descriptions of the fixations, *and what follows*, go at
the beginning of that chapter, and the four fates travelled with them. During `job74-drafting-20260919` (09-19 to 09-23) he
approved that the chapter keeps the four fates and the mental deposits. This proposal keeps the mental deposits there and takes the fates out. **Put to `[A]`.**

**The joins.** *Where a fixation acts* ends Underneath the Cycle on a detached person processing or ignoring an arriving fear;
*Disregarding* opens the new chapter on the three things that are easy to run together. *The range of detachment* then opens
The Fixations Themselves on *For enthusiasm and caution a lean shades the orientation without altering what it does.*

**What moves into it from elsewhere in the chapter:**

- From *The range of detachment*: the job example and the account of burial (*Giving way to easy wanting sounds slack* to
  *What happens to a fear after the burial does not depend on the lean*). Its first sentence leans on the paragraph before
  it in the range of detachment, so it has to restate what giving way to easy wanting is.
- From *What previous thoughts have laid down*: its last paragraph, *A burial is not one event*.
- From *The unease loop*: the account of building the capacity to bear discomfort, with the migraine story, goes to Rising.
  `[A]` said on 10-16 that *the migraine section seems like an abrupt change after the unease material*. One sentence stays
  in the unease loop to say that a buried fear does not fade the way an ignored one does.
- *Lasting unease* is the unease loop's second half, from *Three things about unease are separate* to the end of the
  section: unease when idle, distraction, the three sources of lasting unease, and the habitual fear.

### The Health Axis: Spoiled arrivals goes to Falling and Rising

The same thing is described three times with no link between the places: a person under stress looking like the orientation
behind their own (findings C9). The cycle chapter's *Backward* is one; *Spoiled arrivals* is another; the third is the
end of *What falling takes from capacity*: *Under stress, a person looks more like the orientation behind their own.* Placed
right after that sentence, *Spoiled arrivals* joins two of the three. **Checked:** the 09-02 architecture kept it in the
health-axis chapter for its contrast with blindness, which needs the four fates nameable. The fates are still named well
before it.

### Falling and Rising

- **The new title** replaces a heading that names a case by its position. It is already on the later style job's list.
- **Two things that cannot happen and The last stretch move up** into the falling sequence, before *Why this does not take
  everyone to the bottom*. That section opens *Set out so far, the mechanism has a hole in it* and says *Everyone should end
  at the bottom*, which reads straight on from the bottom rungs. Today the bottom rungs come after the intervener and just
  before Rising. **Checked:** the 09-02 architecture placed the two things that cannot happen after both brakes because the
  derivation that the levels do not wrap was to close the falling half. That derivation is now in the health-axis chapter, in
  *The same nine names, two different shapes*, so the reason no longer holds.
- **Rising splits into three.** It carries five subjects in 1,305 words: the climb itself, the oldest material, what can be
  learned from other people, trained abiding, and how long the work takes. *The oldest material* and *A skill for handling
  fear* are the book's own phrases. The paragraph that depends on another across the split (*With the oldest material the
  connection is especially hard to make*, which leans on the paragraph before it) is sorted by the drafting session.
- **The summit and the last section keep their order.** The 09-02 architecture has the counterfeit summit close the climb,
  and the last section is the book's present ending.

### Kept where they are, and why

- **Where the Inner World Came From stays first in Part 3**, as `[C]` recommended on 10-30. `[A]` has not answered that
  recommendation.
- **The cycle chapter's last two sections stay.** `[A]` approved in the same placement that the cycle chapter keeps a short version of
  the account of a thought. It is now nearly as long as the full one; that is a matter of length, not order.
- **The Figure's Own Lines keeps its order.** *The relations the figure does not draw* ends *as that grip loosens*, which
  leads straight into *As the grip loosens*.
