---
from: Job69 drafting 20260914
to: the session receiving MANIFEST-job70-20260914.md
---

# SET NOTE — from `Job69 drafting 20260914`

## Arrival

Incoming zip `job68-out-20260913.zip`, directory `job68set`. Verified **84 ok / 0 mismatched /
0 bad count / 0 missing / 0 not in the manifest** against `MANIFEST-job69-20260913.md`. Screen
fired twice, both benign — the record as CARRY DO NOT READ, and the handoff for quoting the
restriction string.

Record arrived **64,653 w, md5 `b6e20a67`, forty-ninth append, marker `Job68 drafting
20260913`, parent 63,458** — agreeing with `SET-NOTE-from-job68-20260913.md`. Chain clean. A
drafting session, so the record was never opened.

Master arrived `BOOK2-20260913.md`, **36,139 w, md5 `ed135b63`**. The vocabulary instruction's
count was re-run against it before any work: 61 occurrences on 48 lines in lines 63 to 996.
Exact agreement, so nothing had drifted.

## What was done

`VOCABULARY-INSTRUCTION-from-job67-20260912.md` in full, and it is **DISCHARGED**. All 61 sites,
the five §4 named as not dissolving, and the Part 3 opening §5 specifies. §7's check passes:
**zero occurrences in lines 63 to 996** of the new master.

Beyond the instruction: a run of 20 `attend` sites that were a second name for `noticing`; the
Part 3 opening's attribution corrected from Naranjo to Ichazo on `[A]`'s instruction to check it;
and six repairs `[A]`'s readings turned up, including two sentences cut from Ch 4 and one
comparative dropped from Ch 5.

`CHANGES-job69-20260914.md` has every one of them with the before and after.

## Files

- **New master `BOOK2-20260914.md`, 36,336 w.** Supersedes `BOOK2-20260913.md`, which is NOT in this set.
- **New `CHANGES-job69-20260914.md`.**
- **Record appended — FIFTIETH APPEND, blind.** Head is **65,890 w, md5 `af243099`**, marker `2026-09-14 · Job69 drafting 20260914`, parent 64,653 named in the block. First **381,122 bytes verified byte-identical** to the parent. **62 markers** where there were 61. Written in the canonical bold form so the sweep can read it.
- **`VOCABULARY-INSTRUCTION-from-job67-20260912.md` travels unchanged and unmarked, but it is discharged.** It is kept because it is the authority for what was done to 61 sites and a later session may need to check work against it. It must NOT be run again. No existing status prefix fits a discharged instruction — `SUPERSEDED__live__` is for parents and `STALE__origin__` is for a file gone stale with nothing replacing it — so nothing was invented; this note is the declaration.

## OPEN — carried to whoever takes them

Three, none settleable by drafting. All three are `[A]`'s, raised in this session.

**1. `attention`.** 43 uses, no ruling behind any of them, sitting in the same ground as
`notice` and `attend`. This session cleared `attend` out and cut the one sentence where the
unruled idea did real work — *there is one attention and two realms, so what goes to one is not
going to the other*, which `[A]` said he never claimed and which reads as exclusive without
saying so. Whether attention is one divided supply or another name for noticing is undecided.

**2. The economic register.** 43 occurrences across 29 sentences. Ch 5 has 24, Ch 17 seven,
Ch 15 and Ch 16 three each, Ch 10 three, one each in Ch 2, Ch 9 and Ch 13. `STYLE-GUIDE-20260908b.md`
§3 rules the family out and says so twice, *including where the exchange carries the argument* —
and in Ch 17 it is carrying the argument. **Not all of it goes**: the Five's paragraph describes
a psychic supply being rationed as though it were physical, which is the Five's own mistake and
needs the vocabulary. A pass over this needs judgement at every site, not a substitution.

**3. Whether the two realms' fixation strengths are correlated.** `[A]`: *we think that
strength of fixation is somewhat correlated between the two realms.* The book says nothing
either way. It bears on the types-ahead account, which describes a person loosening in one realm
while the other holds — if the strengths move together, that account describes a case rather
than the case.

## Two things about how this session went, for the next one

`[C]` **miscounted three times**, each time by trusting a grep pattern instead of checking what
it caught. A pattern requiring a lower-case letter and a full stop cannot see a sentence that
opens with the word or one that ends in a question mark. Count case-insensitively and on word
boundaries, and re-count before quoting a figure.

`[C]` **did not read `STYLE-GUIDE-20260908b.md`** until `[A]` asked, most of the way through.
Three corrections he gave that day were already in it. Read it at §1.0, with the handoff and the
set note.

## Next session

`[C]`'s recommendation, put to `[A]` at the close: **doctrine**, taking the three open items
above in the order they are listed. All three are questions about what is true, not about
wording, and the economic pass in particular cannot start until it is settled which sites are
describing a mistake and which are making one.

## Outgoing

`MANIFEST-job70-20260914.md`, label `Job70 20260914`, no job kind — the kind is `[A]`'s to
assert.
