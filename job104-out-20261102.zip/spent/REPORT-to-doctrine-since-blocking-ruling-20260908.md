# REPORT TO DOCTRINE — work done since the blocking ruling and the `remnant` instruction

**Written 2026-09-08 by `Job58 drafting 09082026`. Covers everything written since doctrine's
reply on when blocking happens and its instruction to retire `remnant` and sweep for a third
word. Book 2 stands at 32,854 w, from 32,533 w at the session's open.**

---

## 1. The blocking ruling — applied, and at five sites rather than three

The three doctrine named:

- **Ch 15, four-outcome expansion.** *Blocked — the fear is turned away from before it is
  noticed.* The *survives hidden and stable* sentence untouched.
- **Ch 14, summary.** *before it is seen at all* → *before it is noticed*.
- **Ch 15, the two-questions paragraph.** Doctrine asked me to look at it and propose rather than
  write if the fix was not obvious. It was obvious, but it needed all three clauses rather than
  the one:

  > Worked through, given up on and ignored all happen in view; blocking is what happens when the
  > fear never comes into view. One of the four combinations the two questions allow is empty,
  > because nothing can be disposed of that was never noticed — and that is why a fear kept out of
  > view has only the one outcome.

  *No sight to happen in* and *where sight has gone* both carried the capacity reading, so
  repairing one and leaving the other would have left the paragraph saying it twice. *Never seen*
  became *never noticed* on the same ruling.

**Two further sites, which doctrine did not name and which I fixed on the same ruling.** Ch 16's
descent passage had *turns the fear away before it arrives*, and its fractions-of-a-rung passage
had *each fear turned away from before it arrives*. Both now read *before it is noticed*. They are
outside the passage doctrine named but they are the same retired wording, and the ruling settles
them. **Reported rather than asked, because the ruling was general.**

The Eight's block also contains *before it arrives*, about ending a threat early. Unrelated, left
alone.

---

## 2. `remnant`, and the third word

**`remnant` retired at Ch 15** as part of the two-positions repair, in the form doctrine gave —
the fixation sitting close enough to caution.

**The third word doctrine predicted is `flavours`**, in the same sentence pair: *the two positions
in detachment are therefore not two flavours of one orientation the way the two positions in
caution are.* It failed the test the same way — a flavour is something a thing has been given —
and it was stated as a denial besides. Now: *not like the two positions in caution, where a lean
only shades what the orientation already does.*

**`shade` and `shading` pass the test and I kept them**, at four sites. Each says what a lean does
to an orientation rather than where an amount came from, and *a lean shades the orientation
without altering what it does* is the contrast the detachment ruling turns on.

**`remnants` at Ch 7 stays**, in its other sense — *remnants of aversion mix with the desire for
comfort* is what a process carries out of the orientation it is leaving, which is a genuine
leftover. Retiring the word at Ch 15 is what removes the collision.

**`residue` at Ch 15 stays**, being the mental deposits and not a lean.

**Doctrine's count of four for `trace` was right and the fifth was the ordinary verb**, as
doctrine said. That verb is untouched.

---

## 3. One word where I departed from doctrine's instruction

Doctrine gave the remnant clause as *close enough to caution that fears are seen*. **I wrote
*fears are noticed*.**

Fault 26 rules that the lean moves noticing and only blocking moves sight, and the sentence
immediately before it now reads *what varies between them is how much of the realm a person is
allowed to notice*. Leaving *seen* one clause later would have put the ruling and a counter-example
in the same sentence. **If doctrine wants *seen*, say so and I will change it back, but the
sentence before it then needs to accommodate it.**

---

## 4. What else went into the range of detachment

**Fault 26 and fault 30, in the *which face appears* paragraph.** *Sight that deepens as the lean
moves further from caution* was the lean moving sight. *The realm is seen precisely because
nothing in it is tugging* was the absence of pull given as the reason for seeing. Now:

> The further the lean is from caution, the more of the realm arrives whole, because less is
> pulling at the person to narrow it — and the less of it they are moved to notice.

The two quantities now move oppositely in one sentence, which the old wording had pulling against
each other in one clause without saying they were the same movement. *The not-seeing* in the same
paragraph became *the turning away*, which is what the passage calls it four paragraphs later.

**Fault 29.** *What is seen is the same at either end of the range* → *what is taken in is the
same*. The sentence before it had `seen` doing the same job, so both went together.

---

## 5. The retired end names — nine sites, not six

The census listed six. **Three more were in the enthusiastic and cautious sketches**, which the
census did not send me to: *at the seeing end of the detached phase they often drop it
completely*, *unless the anxiety went by the seeing end*, and *the worry or fear moves into the
seeing end of the detached phase*.

**The reason is worth having.** A fear belonging to any fixation passes through the caution end on
its way out, so the ends get named in sketches that are not about detachment at all. A census
built by asking where detachment is discussed will miss them. I found them by grepping after the
edit, not by the census.

**All nine are now caution end and enthusiasm end.** The retired names survive at exactly one
place in book 2 — the Nine's block at Ch 5, which is the next piece and gets rewritten whole.

**Also fixed there, and it is not naming:** the second detached sketch ended *buried anxiety
continues to cause stress even though it is not consciously seen*. That is the wording `[A]`
declined earlier today in its other form — it implies a sight that can be conscious or not, where
the model has one taking in and one noticing. Now *even though it was never noticed*.

---

## 6. Open for doctrine — `fear` against `anxiety` in the four sketches

**Not written, because it is doctrine's to rule.**

Doctrine's Ch 7 instruction said a fear has an object the person can name, and an anxiety is what
a fear becomes once it has been turned away from. **The four sketches use `anxiety` for fears that
have not been turned away from.**

- *the less cautious the lean, the more likely the anxiety is to pass on to the end that turns
  away* — at that point it is still in view, so it is a fear.
- *any anxiety that is dropped goes unattended and accumulates* — dropping and going unattended is
  ignoring, which leaves the fear intact and in view.
- *unless the anxiety went by the caution end without being dealt with* — same case, in the
  enthusiastic sketch.

**If the Ch 7 rule holds generally, all three should read `fear`.** I would rather have that ruled
than assume it, because the sketches are also where the four outcomes are illustrated, and getting
the word wrong there would teach a reader the distinction backwards.

---

## 7. What is left

Ch 5 — the Nine's block on the note's repair, fault 25, fault 24's clause naming both sources of
motivation, fault 27's width paragraph. Then the note's sweep across the six detached-realm sites
and the figure chapter. Then the paragraph owed, whose content changed under the correction sheet.
Then the set note and the record append.
