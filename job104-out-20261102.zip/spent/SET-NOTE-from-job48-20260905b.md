# SET NOTE — from `Job48 drafting 09042026`, cut 2026-09-05

**LETTER `b`, cut 2026-09-06 by `Job50 drafting 09062026`: the three-mechanism list is marked
superseded and nothing else is changed. Quarantine `SET-NOTE-from-job48-20260905.md` as
`SUPERSEDED__live__`.**

**For the next session, which should be a DOCTRINE session.** This note exists because `Job48` wrote
about 2,200 words of new prose into book 2 that rests on claims nobody has ruled. Everything built on
them until they are checked is at risk of being rewritten.

---

## What the session did

Two things, in this order.

**1. The reading pass for an abstract subject given an agency verb — about a third done.** This was the
job the sets-by-job table left for a second session of kind 11. Thirty-eight repairs applied. Part 1,
Chapter 7 and the heaviest parts of Chapter 15 are clear. Chapters 6, 8–14, 16 and 17 are READ and
their hits identified, NOT repaired — roughly forty sites remain, none as bad as the ones taken.

**2. Nine closing qualifications, one per type sketch in Chapter 5.** `[A]` raised this mid-session:
the sketches read as universal when many people of a type are not completely caught. This became the
larger part of the session. Book 2: 28,315 → 30,527 w.

## The nine additions, and what they rest on

Each sketch now ends with roughly 250 words in a fixed shape: a paragraph for the physical realm, a
paragraph for the psychic, and a closing line naming what the pair gives at any depth.

**`[A]`'s generalization, given 2026-09-05 and NOT RULED:** *less fixated allows characteristics of
type in the direction of integration* — refined by him the same day to the **ahead** relation, so each
type has two forward directions, one per realm. Being less caught shows as movement in those
directions. All nine additions are written to it.

Ahead, computed from the pairs: 1 → 6, 7. 2 → 3, 4. 3 → 8, 1. 4 → 1, 9. 5 → 9, 8. 6 → 4, 5.
7 → 5, 3. 8 → 2, 6. 9 → 7, 2.

**SUPERSEDED 2026-09-06 by `Job50 drafting 09062026`.** `[A]` ruled on 09-05 that less fixation
means greater tolerance for the discomfort that orientation is averse to — one mechanism, applied
once per realm — and **the two mechanisms below that are marked *Not ruled* are withdrawn**. *An
unused sight* and *a covered realm* were that one mechanism seen in a detached realm and in a
covered one. The nine additions themselves need no change: none of them uses the withdrawn
vocabulary. The list is left standing below as the record of how they were written.

**Three mechanisms were needed to write them, and only the first is `[A]`'s.**

- *The forward step.* Where a realm's forward step is ordinary, the addition names it directly.
- *An unused sight.* Where a realm is DETACHED, the person can already see that realm; their attention
  is in the other one, so the sight goes unused. Being less caught puts it to work. Used for the Two
  and Four (physical), the Five and Seven (psychic). **Not ruled.**
- *A covered realm.* Where a pair has NO detachment (the One, HA;SB, and the Eight, HB;SA), the quiet
  realm runs under the loud one and stays covered AT ANY DEPTH. Being less caught changes only what
  the person can accept from an outside report. **Not ruled.** `[A]` corrected a siting error here
  mid-session: the covered realm is the One's psychic and the Eight's physical.

## Claims marked for ruling

1. **The generalization itself** (above). Everything else depends on it.
2. **The two extra mechanisms** (above). The Four and the Five now explain one realm by the forward
   step and the other by the loud realm covering the quiet one. `[A]` accepted this; it means his rule
   does not carry all nine on its own.
3. **The Nine's fourth paragraph** — that the seeing survives the return of appetite well enough to
   watch what the wanting is doing to the person's view. `[A]`: *go with it but mark it for a doctrine
   session to check.* It sits oddly against the Nine's closing line, which still says the view is bent
   by nothing they want or fear; **read the two paragraphs together, not either alone.**
4. **The competences come with the pair at any depth.** Asserted in all nine closing lines. Implied by
   the independence of depth and direction; stated by no ruling.
5. **Seeing is not a higher grade than doing or understanding.** `[A]`, 09-05: once a person is fully
   detached, enthusiasm is an improvement. This corrected a claim `Job48` had made that the step out
   of detachment risks the orientation's own competence. The three are positions on a loop with no
   top. **Consequences elsewhere in the book not yet checked.**
6. **The aligned types and the realms.** The aligned types (3, 6, 9) have no internal contrast to
   reveal that the realms differ, at any depth, and being less caught does not supply one. `Job48`
   first wrote that the forward step delivers the differentiation; `[A]` rejected it — noticing a
   failure does not tell a person which realm the question was asked in, and the concept most likely
   comes from outside. **The weaker claim above is what stands.** A stronger draft sentence was cut
   from the Three's addition.
7. **`[A]`'s parallel, worth a session's attention on its own.** Failing to see at the seeing edge is
   what makes a person caught; being less caught is what lets them keep seeing there. He notes this
   may be the same thing as a healthy person dissolving fears at the other edge — *one mechanism or
   two?*

## Two distinctions `[A]` drew that the drafting must not blur

- **Differentiating the realms** (finding out there are two) is NOT **self-discovery** (seeing one's
  own fixation). The aligned/mixed distinction bears on the first only. **None of the nine additions
  claims that being less caught shows a person their own fixation.**
- **Being less caught relieves the trouble the pair produces, for every type including the aligned
  ones.** That is functioning better and is not in doubt. It does not hand anyone the theory.

## Style guide

**Re-cut as `STYLE-GUIDE-20260905.md`.** Two changes, nothing else touched.

- **New section 9, *Write for what a reader can actually hold*,** at `[A]`'s instruction, carrying five
  rules from today with the example that produced each: say the thing not the absence of the other
  thing; one idea per sentence; no second name for something that already has one; no sentence whose
  sense depends on holding an earlier phrase while parsing a later one; restate a fact rather than
  pointing back at it. His reason is quoted rather than paraphrased.
- **Two bullets added to section 2**, recording the repair method this pass produced (put the person
  back in the subject) and `[A]`'s limit on it: *orientations are never people*. Where a sentence
  DEFINES an orientation, `such a person` is an accepted imprecision. Where a sentence is about the
  ORDER of the orientations, the person must NOT be put in — that would say a person changes
  orientation. Repair those by taking the person's verb off the orientation.

**Section numbers were not changed**, so anything pointing at a numbered section still points where it
did.

## Left for the session after the doctrine one

- **The rest of the agency pass**: Chapters 6, 8–14, 16, 17. Untouched by whatever doctrine rules,
  since none of its remaining sites is in a type sketch.
- **Chapter 14 names a case by its position**: *only the last leaves a person seeing less than before*
  should say *only a blocked fear*. Style guide section 4.
- **Chapters 6 and 14 talk about the book's own arrangement**: the cycle *has been used as an
  ordering*; the scales *have been in use since the cycle was introduced*. Style guide section 1. These
  want a session that can rule on what replaces them, since deleting them may leave a gap.
