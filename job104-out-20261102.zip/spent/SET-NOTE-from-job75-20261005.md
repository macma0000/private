# SET NOTE — from `Job75 coherence 09232026`

To the session receiving `job75-out-20261005c.zip`, which supersedes the earlier cuts
`job75-out-20261005.zip` and `job75-out-20261005b.zip`. `[A]` gives the kind; the manifest label
carries the counter and date only.

## Arrival

Incoming zip `job74-out-20260923.zip`, verified at its top level against
`MANIFEST-job75-20260923.md`: **58 ok, 0 mismatched, 0 bad count, 0 missing, 52 not in the
manifest** — the declared `spent/` and `superseded/`. The screen fired on the record as `CARRY, DO
NOT READ` and on two expected files in `superseded/`. The record arrived at 70,645 w, marker
`job74-drafting-20260919`, matching `Job74`'s note.

**The zip also held a folder `job74/`** — a second copy of the whole set with an earlier cut of
`Job74`'s set note and manifest. It was left alone and does not travel. **An assembler should not
nest the previous set inside the zip.**

**Eleven files arrived from `[A]` during the session, outside the zip**, all cut by `Job70 doctrine
09152026` without a manuscript: four closures and correction files, and seven answer sheets written
for this session. All now travel in `spent/` (see below).

## What was done

**The tracking check was run on what moves a detached person**, from where a want is raised through
what the lean does to where a detached person's action comes. It turned up a contradiction inside
the book, and `[A]` ruled on it. That ruling collided with a sentence `Job70` had recorded as ruled
and `[A]` had never said. From there the session became an exchange: `[A]` carried each question
to `Job70` and brought its answer back, and `[A]` ruled directly in this session five times.
`FINDINGS-job75-20261005.md` is the full account.

**Three of `Job70`'s answers carried no words of `[A]`'s and were put to him before being
recorded:** the counterfeit summit, which he reworked; the grab, *i agree*; and where a fear is
settled, where he rejected `Job70`'s wording.

**No manuscript was touched.** `BOOK2-20260923.md` stays the master.

## What is in the set that is new

- **`FINDINGS-job75-20261005.md` — the one file a drafting session works from.** Sixteen ruling rows,
  each in `[A]`'s words with every site quoted from the master (30 blockquotes, `quotecheck` passes),
  six faults recorded under rulings already in force, what was checked and holds, and four items
  open for doctrine. **Where it disagrees with any `Job70` file, the findings file wins** — `Job70`
  asked for that.
- **`WORD-RULINGS-book2-20261005.md`, letter `c`.** Nine `Job70` files merged in date order into
  letter `b`, plus this session's rulings, with seven new patterns for `wordcheck.py`. `Job70`'s
  files speak of *the 09-16 register*; that was the copy `Job70` held, and letter `b` was live.
- **`ARC-ACCOUNT-from-job75-20261005.md`**, re-cut at `Job70`'s request, each change marked
  `CHANGED` with its ruling.
- **`CLAIM-INVENTORY-book2-20260902.md`** gained a 10-05 section; name kept, as is the practice.
- **`HANDOFF-20261005b.md`** and **`STYLE-GUIDE-20261005b.md`**, letter `d`, cut after the close at
  `[A]`'s request (*can you update the handoff and style guide?*). Their first cuts went out in the
  `b` zip; `Job70` found three faults in them, which these letters repair. The handoff is the 09-19 file
  brought up to date, not a fresh read; its §10 says what that means. The style guide adds `[A]`'s
  09-09 withdrawal, his 09-21 correction about transcribing a thought one for one, and his 09-06
  ruling on comments about the material.

## Moved

- **To `superseded/`:** `ARC-ACCOUNT-from-job72-20260916.md`, `WORD-RULINGS-book2-20260923.md`,
  `HANDOFF-20260919.md`, `STYLE-GUIDE-20260908b.md`, `HANDOFF-20261005.md` and
  `STYLE-GUIDE-20261005.md`, all as `SUPERSEDED__live__`; `MANIFEST-job75-20260923.md` and the two
  earlier outgoing manifests, `MANIFEST-job76-20261005.md` and `…b.md`.
- **To `spent/`:** every `Job70` file — `CLOSURES-SITED-job70-20260916.md`, `…20260923.md`,
  `…20260923b.md`, `…20260923c.md`, `CORRECTION-to-job70-closures-20260923.md`, and the seven
  `ANSWERS-for-job75-from-job70-20260923*.md` sheets; also `DRAFTING-INSTRUCTION-from-job72-20260916.md`
  and `Job74`'s two `NOTE-for-job74-from-job70` files (discharged by `Job74`), `CHANGES-job74-20260923.md`,
  and `SET-NOTE-from-job74-20260923.md`.
- **`spent/` and `superseded/` travel outside the manifest**, and `setcheck.py verify` reports them as
  not in it. That is expected.
- **The screen fires on the record as `CARRY, DO NOT READ` and on eight files in `superseded/`**, every
  one a `SUPERSEDED__live__` file; the 09-06 handoff also quotes the restriction string. Every hit is
  expected. `setcheck.py sweep` also lists the two old handoffs; both carry status on the name.

## The record

**Four appends, all blind.** The parent's 416,680 bytes were verified byte-identical after writing.
`Job70`'s sittings from 09-16 on were appended first, on its behalf, written from its files rather
than from the block at the end of its closures file, which `Job70` said was incomplete: **fifty-seventh
append, parent 70,645 w, head 71,943 w.** This session's own block followed: **fifty-eighth append,
parent 71,943 w, head 72,704 w**, marker `Job75 coherence 09232026`. After the close, at `[A]`'s request for the handoff and style
guide, a short block recorded that work: **fifty-ninth append, parent 72,704 w, head 72,891 w.**
After `Job70`'s check of them, a second short block recorded the repairs: **sixtieth append, parent
72,891 w, head 73,080 w.** `setcheck.py sweep` reads it.

## What is owed

- **A drafting session on `FINDINGS-job75-20261005.md`.** It reads `STYLE-GUIDE-20261005b.md`, the
  referring-word rule and `WORD-RULINGS-book2-20261005.md` before writing, as the new handoff's §1.1
  says.
- **The unease material is a job of its own** — `NEW-MATERIAL-the-unease-loop-20260923b.md`, cut by
  `Job70`. It is **not in this set** and was not read by this session. It is undrafted and needs its
  own sitting. `[A]` holds it.
- **Four items open for doctrine,** listed at the end of the findings: whether a want is laid down;
  each end of detachment's own want; whether the dislike of disturbance is why a disturbance gets
  noticed; and a rule followed by rote.
- **The claim inventory** has no entries for Ch 14's eight sections. Build them after the drafting.
- **The writer 2 pass is still needed and still waiting on Toby Marshall.**

## Next

`[C]`'s recommendation, `[A]`'s to assert: **a drafting session on `FINDINGS-job75-20261005.md`.**
Today's rulings change Ch 4, Ch 5, Ch 7, Ch 14, Ch 15, Ch 16 and Ch 17. Every one of them is a site
found and quoted, and nothing in the findings waits on doctrine.
