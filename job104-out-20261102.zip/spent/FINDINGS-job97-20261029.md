# FINDINGS — `Job97 coherence 20261029`

Coherence run on `BOOK2-20261029b.md` (44,666 w, unchanged), reading `CHANGES-job96-20261029.md`. The session ran on 10-29
his time. `[A]` named it `Job97 coherence 20261029`; the manifest label `job97-20261029` agrees.

**Arrival.** `job96-out-20261029.zip` verified against `MANIFEST-job97-20261029.md`: 56 ok, 0 mismatched, 0 bad count, 0
missing, 222 not in the manifest, all in `spent/` and `superseded/`. The screen's 42 hits are all `SUPERSEDED__live__` names
in `superseded/`; the record is the one file marked carry, do not read. The record's last marker matched `job96`'s note:
ninety-eighth append, 103,915 w. The handoff carries no status on its name and is the current one.

**Changes file checked.** All five rows of `CHANGES-job96-20261029.md` are in the master as the rows say: four paragraph
hunks against `superseded/BOOK2-20261029.md`, and the type chapter's general *we* left as `[A]` scoped it. Nothing else in the
master changed.

- **Row 1**, Chapter 1's second paragraph: *The three are orientations … and the two are realms*. It answers the question
  the paragraph before asks (*What are the three things, and what are the two places they can sit?*), so the plain statement
  reads as the answer. No fault. The 10-29 `Job95` block filed this site under the Introduction; `job96` corrected that, and
  the claim inventory now files it under Chapter 1.
- **Row 3**, *The unease loop*, habitual-fear paragraph: *With buried material, the buried fear is no longer noticed.* The
  sentence now names the buried fear, and the next sentence's *A habitual fear is noticed every time* no longer contradicts
  it. The same words stand six paragraphs earlier, in *A burial is felt even though the buried fear is no longer noticed.* In
  the habitual-fear paragraph the sentence does a different job, setting buried material against a habitual fear, so the
  repeat is a restatement the style guide allows, not a disguised one. No fault.
- **Row 4**, *The range of detachment*, job example. The buried fear now comes from fears that were ignored or blocked by
  discomfort several times first, as *A burial is not one event* and the blind-blocking paragraph of Chapter 15 say. *Each
  fear meets one fate* is gone; Chapter 14's *Where a fear meets its fate* still says it. No fault.
- **Row 5**, *Rising*: *the way out of lasting unease most within a person's reach*. No fault. See the tracking check on
  *a way out*.

**One claim in the changes file is wrong, and harmlessly.** Its Checks list says *`refcount.py` output unchanged between
masters*. The output did change. Sentences with two or more referring words went from 568 to 566, and Chapter 15's count from
45 to 44, because the old row 1 and row 4 sentences carried two each and their replacements carry one or none. Every new
sentence passes: row 4's *these* and *That* each point to the sentence before, and no new sentence has more than one
referring word.

**`wordcheck.py`** against `WORD-RULINGS-book2-20261028.md`: the only changed hit is row 5's sentence (*aversion-scope*,
ordinary use), as the changes file says.

**Tracking check.** Run on **how a fear comes to be buried**, from the first time it is raised to the panic, at every site:
Chapter 4's two faces of detachment, Chapter 14's four fates, the job example, the burial crossing the detached phase, the
blind-blocking paragraph, *A burial is not one event*, and Chapter 17's discomfort blocking. All agree: a fear is usually
ignored or blocked by discomfort several times, comes back stronger, and is buried when one time it is more than the person
can bear; *all at once* is said only of the turning away at the moment of panic. Also run on **a way out**, at every use:
the way out of a fixation running through detachment (Chapter 13), the ways out of the unease loop by each orientation's
competence, the two-pains comparison that moves a person to take one, the way out of lasting unease in *Rising*, and general
understanding not being a way out by itself in *What is actually being undone*. Each says what it is a way out of, or the
section says it. They agree. Tests (a) to (d) were not re-run across the book.

**Author voice.** Every *I*, *my* and *me* after the Foreword is inside a type speaking in the first person, quoted speech,
or a name (*G. I. Gurdjieff*).

## Findings

None. No question was put to `[A]` in this session, and nothing is owed to a drafting session from this run.
