# ANSWERS for `Job75 coherence 09232026`, from `Job70 doctrine 09152026` — third sheet

Cut 2026-09-23, after the first and second answer sheets, both of which stand. **This sheet
answers the last `aversion` census site and retires a term the earlier files coined.**

**Merge in date order after the second answers sheet.** This sheet is later than all three and
overrides them where they differ.

**`Job70` has no manuscript in this sitting.**

---

## 1. The three sentences in the orientations chapter — the reservation reaches all three

**Yes.** `aversion` comes out of all three.

The reservation exists to stop one word naming two different things. **An aversion is raised in the
cautious phase by examining and meets a fate at that cycle's ending.** What these three sentences
name is not raised by anything and meets no fate.

**The chapter supplies its own repair.** The lead-in already reads *something a person cannot
easily bear*, which names the standing thing in plain English. So:

- what an enthusiastic person cannot easily bear is disappointment
- what a cautious person cannot easily bear is losing control
- what a detached person cannot easily bear is suffering with nothing softening it

**No new term is needed and none is coined.**

**A wrinkle this also removes.** Disappointment was ruled 09-16 to belong to the cautious phase, so
*averse to disappointment* read as an aversion to an aversion. *Cannot easily bear* removes the
stutter.

## 2. RULED — every orientation has a standing dislike

`[A]` 2026-09-23: **all have a standing dislike.**

Enthusiasm's is disappointment. Caution's is losing control. Detachment's is disturbance. **None is
raised in a cycle, none meets a fate, and each is there whenever the matter comes up.**

Two consequences worth carrying:

- **Detachment is no longer special in this respect.** The standing dislike of disturbance was
  treated as a fact about detachment alone, which made detachment look as though it had a kind of
  motive the other two lacked. It does not.
- **The buddha ruling is stronger.** A person outside the model has **none of the three standing
  dislikes**, not merely detachment's. That matches the 09-23 wording — no attraction and no
  aversion at all.

## 3. RETIRED — `standing dislike of disturbance` as a term

**`[A]` 2026-09-23, asked whether the book should have a general class word now that all three
orientations have one: *no need for the general term.*** No class word, and **no term for
detachment's either** — each orientation's is described, in the chapter's own phrase.

**This overrides the earlier files.** `CLOSURES-SITED-job70-20260923c.md` and
`NEW-MATERIAL-the-unease-loop-20260923b.md` both carry `standing dislike of disturbance` as a
coined term, record `[A]` calling it *a little clumsy*, and list `[C]`'s candidate replacements.
**None of that is merged into the register.** `[A]` has since decided against having a term at
all, which is why it was clumsy.

**What survives unchanged:** the substance. A detached person dislikes disturbance, and that is why
a disturbance gets noticed. **Only the coinage goes.**

**The register merge should therefore carry no `standing dislike` entry**, and should carry instead
that **`aversion` is reserved to the cautious phase, and what each orientation cannot easily bear
is said in plain words at Ch 4.**
