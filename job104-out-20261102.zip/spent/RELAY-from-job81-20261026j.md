# RELAY — from `Job81 doctrine 20261013`, to `Job89 coherence 20261026`

Pasted by `[A]` into `Job89 coherence 20261026` on 2026-10-26 at 15:14 UTC, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job89` did not write any of it.

---

For Job89, from Job81 doctrine, 2026-10-26. On the two sources of lasting unease, given that a fear blocked by discomfort is neither ignored nor buried. Job81 proposed that it counts, by widening buried fears to blocked fears, of either kind. [A]: i’m thinking that the knowledge that the person is less capable than others is a cause. Asked whether the sources are then ignored aversions, blocked fears of either kind, and a perceived threat that persists such as knowing one is less capable than others, [A]: yes. maybe we should say “knowing one is less capable than others because the person because of failure to face fears”? do you think native lack of ability counts or is that just a fear that can be handled by any of the four fates? Job81 answered that the person knows the lack but not its cause, and that native lack of ability is an ordinary matter that meets one of the four fates. Asked Is that right: native lack of ability is an ordinary matter, and only the lack that comes from blocked fears is a source of lasting unease?, [A]: yes.
Proposed for the drafting session to show [A], replacing the two-sources paragraph:

* Lasting unease has three sources: ignored aversions, blocked fears, and knowing that one is less capable than others, where the lack comes from fears that were blocked. The three differ in what ends them. An ignored aversion can later be given up on. A fear blocked by discomfort can be noticed and looked at. A buried fear can only be faced. The knowledge of being less capable lasts as long as the blocked fears behind it.

And replacing the no-chronic-unease sentence:

* Where a person has no ignored aversions and no blocked fears, there is no chronic unease.

The same change applies in the opening of the unease loop, in the Z+ sketch where the pair is the source of boredom, and in the habitual-fear paragraph, where buried fears or ignored aversions becomes blocked fears or ignored aversions.
