# SITED CLOSURES — Job32 doctrine 08292026 (2026-08-30)

**FIRST INSTANCE. THE FORM IS NOT SETTLED.** `[A]` ruled on 2026-08-30 that a doctrine
session cuts a file of this kind: **site and claim, never the sentence.** He agreed to the
rule, not to this layout — `[C]` proposed the layout and he has not seen one before. Reshape
it freely. The contents are meant to survive being moved into a different form.

**This is not a repairs file and not a note.** It carries no defects found in text, no
reasoning, and no replacement wording. Every row is something `[A]` ruled in session, paired
with where it lands. A drafting session writes the sentences; nothing here is drafted.

**Not applied. Nothing in this file has been carried into any master.**

> **ONE NAME CHANGED SINCE, 2026-08-31, by `[A]`: the first fate is `worked through`, not
> `settled`.** Book 1 already has a fear *settling into a fact* at lines 618 and 624, which is the
> mechanism of the descent, so the ruled name meant the opposite of the fate in the book that carries
> it. `answered` and `resolved` were checked and are also taken — `answered` is the fear-capitalized-
> into-desire rule at line 1484 and book 1 says at 1734 that a fear cannot be answered; `resolution`
> is the third arc stage at 1460. `worked through` is both books' own phrase for a fear met properly
> — book 2 line 360, book 1 line 1370. **Rows 2, 3 and 10 below read `settled`; they mean `worked
> through`. The rest of this file stands as cut.**

---

## What was ruled, in plain words

Six closures. They are stated here once so the rows below can be short.

1. **A fixation is a standing preference about where attention is directed.** Not what it is
   directed at. Directing attention is something a person does, not a place they occupy. The
   forward step to the next orientation is *resisted*, in book 1's existing sense at line 640.
   *Where one habitually stops*, said of the person, stays true and stops being the definition:
   it becomes the consequence, since taking the step requires attending the way the next
   orientation attends and the preference is against that. This also collapses the definition
   and its cause into one thing — the blindness that holds a fixation in place and the fixation
   are no longer two facts.

2. **A fear at the crossing has four fates, in an order:** *settled*, *given up on*, *ignored*,
   *blocked*. Sorted on two questions — whether the fear is in view, and whether it is disposed
   of. Nothing never seen can be disposed of, so *blocked* is the only fate on the unsighted
   side. Within one crossing the fear meets the sighted end first; what survives reaches the end
   that turns away. **Giving up on drops the want behind the fear**, so the fear is gone and a
   regret remains. **Ignoring drops nothing** — fear and want both intact, only the occasion let
   pass — which is why it returns.

3. **The words: *settled* and *given up on*,** replacing *reconciled* and *accepted*. Both
   replaced words are already in the books doing the other one's job.

4. **Painful replaces urgent** as the variable deciding whether a fear can be left alone.

5. **Retraction, two parts.** Arriving at Z+ does not automatically fire the blindness loop.
   And *does not turn into* is withdrawn: intentional non-attending, automatic non-attending and
   defended blindness are three points on a spectrum, the feedback at the third being a
   qualitative change rather than a further degree.

6. **Entry and maintenance are different mechanisms.** Entry: a fear becoming unbearable —
   how much it hurts against how much the person can bear, and bearability falls with descent
   because stress and ordinary suffering rise. Maintenance: recognising a burial threatens to
   undo it, so the recognition is itself a threat and burying it avoids a real present anxiety.
   The preverbal account is **not** superseded by either; it answers how the reflex was learned,
   which is a third question.

---

## The sites

| # | File | Site | What lands there | From |
|---|---|---|---|---|
| 1 | `rev2-0814l.md` (book 1) | line 1460, whole paragraph | Goes in full. It is the stopping definition at its most complete — *a type is not a place a person stands but the place they habitually stop*, the three fixations built out of endeavors stopping in impulse / examination / resolution, closing *One habitual stopping point per realm*. Cannot be repaired by substitution. **The three outside-view descriptions should survive the rewrite as symptoms** — it is the only place either book says concretely what the three fixations look like. | closure 1 |
| 2 | `rev2-0814l.md` (book 1) | line 1462, whole paragraph | Rewrite, not a criterion swap. Was already owed a pass for `[A]`'s 08-27 ruling that the clear side of detachment is defined by sight rather than by the examination having completed. Now also loses its ground entirely: its claim that arrest-point and lean are one fact rather than two findings needs an arrest point to exist. **One pass, not two.** | closure 1 + 08-27 |
| 3 | `RULINGS-20260816.md` | R4, lines 82–86 | Needs the supersession mark. R4 still reads *Fixation is one thing. Definition: the next transition failing to start* at full strength with nothing on it. It was struck by name on 08-21 in the two-scales note's do-not-restore list; the striking was never carried back into the rulings file. Now superseded a second time. **Two live citations need re-grounding:** R4 as what makes 3 and 6 the pure cases (line 219), and R4 as the account reserved for a later chapter (line 448). | closure 1 |
| 4 | `BOOK2-PART34-ARCHITECTURE-20260830.md` | the crossing statement | States the crossing as *buried, reconciled or accepted* — exhaustively three. Wrong on both counts now: four fates, and two of the three words replaced. | closures 2, 3 |
| 5 | `NOTE-the-two-tests-and-the-ignoring-habit-20260827b.md` | §2 | Mark superseded. It places ignoring outside the crossing — not a fate there, but what happens to a fear already let in. `[A]` sited the decision to ignore at Z+ on 08-30, which puts it back at the crossing as a disposal alongside the others. **The clear-side ruling it rests on is untouched** and still holds: a fear seen can be ignored but not buried. | closure 2 |
| 6 | `NOTE-the-two-tests-and-the-ignoring-habit-20260827b.md` | the *does not turn into* ruling | Mark retracted. `[A]` withdrew it 08-30. **Consequence recorded at the time also falls:** the external route is no longer the only route down. An internal route now exists — the habit acquires the feedback and converts at the tipping point. | closure 5 |
| 7 | `NOTE-the-three-outcomes-and-the-burial-reflex-20260826b.md` | §6 table | Replace: three rows to four, with the two-question sort. **Only part of §6 dies.** The rule that which outcomes are available is set by whether there is sight *survives*. What died is the assumption riding on it — that at Z+ there is no sight, so burying is all that is left. Z+ has sight for some fears and not others, and the disposal differs accordingly. | closure 2 |
| 8 | `NOTE-the-three-outcomes-and-the-burial-reflex-20260826b.md` | §4, and §2.3's first argument | Two marks. **§4:** the preverbal account is not replaced by the new maintenance trigger — different question, both stand, per `[A]`'s 08-29 ruling that laying-down and reinforcing run continuously. **§2.3:** its first argument for a third outcome was that a two-outcome model overpredicts blindness. That argument now belongs to *ignoring*, not to *giving up on*. Giving up on stays, on its own grounds. | closures 2, 6 |
| 9 | `BOOK2-20260830c.md` (book 2) | line 844 | `[A]`'s sentence **being unable to bear knowing is the blindness loop** goes into the sentence, not after it. The paragraph already says an aversion meets an aversion to that aversion and *the second wins*; his phrase names what the second winning consists of. **Same line, second item:** its *aversion even to recognising the conflict, since merely seeing it is itself a threat* was drafted as description and is now the maintenance mechanism. **Book 1 has no site** — it carries no crossing account at all. | closures 5, 6 |
| 10 | `rev2-0814l.md` (book 1) | line 1124 | Z− definition reads *the path from caution through acceptance to neutrality*. *Acceptance* here is the sighted route through understanding — i.e. what is now **settled**. Repairable by substitution. | closure 3 |
| 11 | `rev2-0814l.md` (book 1) | line 576 | *numbness instead of acceptance* — same crossed sense. Note this paragraph is already marked DEPRECATED and superseded by book 2 Ch 11's crossing account, so the swap may be moot depending on what happens to the paragraph. | closure 3 |
| 12 | `rev2-0814l.md` line 383 / `BOOK2-20260830c.md` line 310 | Nine blind-spot paragraph | **DO NOT TOUCH — recorded so nobody does.** *Their comfort with merging into others' worlds is not acceptance but self-erasure* adjudicates real acceptance against a counterfeit. This is why *accepted* was rejected as an outcome name: had it been taken, this sentence would have stopped being about the Nine's self-image and started reading as a claim about which outcome the Nine takes. Both books, same sentence. | closure 3 |
| 13 | *(no site yet)* | — | *Painful* over *urgent* costs nothing in either master: *urgent* and *urgency* appear nowhere in either book, and book 1's three *painful* uses are ordinary prose. The ruling lives in the notes only. **One consequence:** `[A]`'s 08-27 scope note *fears from A, i think, feel less urgent than a fear arising at B* becomes *less painful*, which reads truer — an A-side fear is a disappointment, a B-side fear is a threat. | closure 4 |

---

## Opened by this session, not closed — for whoever takes it next

- **The structural asymmetry has lost its derivation.** That enthusiasm and caution fixations
  fail within an arc while a detachment fixation fails at the join between arcs was derived from
  where the stopping happened. Stopping is gone. The asymmetry may still be true — the remedies
  split two-and-one independently — but it now rests on the remedies alone, where it used to have
  two arrivals. Whether the preference account reaches it as well **has not been looked at.**

- **`[C]` FLAG, and it is `[C]`'s objection, not a finding of `[A]`'s: the model may now
  overpredict the fall.** Entry gets easier with depth by two independent routes — bearability
  drops as stress and ordinary suffering rise, and the maintenance loop widens as burials
  accumulate. Both are `[A]`'s. Both strengthen with depth. Neither was posited to explain the
  descent. But the engine has been strengthened twice without the brake being touched, as a side
  effect of a correction rather than by anyone deciding it, and a bottom-heavy distribution is
  what the brake existed to prevent.

- **The brake was deliberately not assembled, twice.** Job31 held it back from `[A]` because it
  had built the argument and his assent would have been to the assembly. Three things in this
  session pointed at it — the steepening, the two entry routes, the widening loop — and `[C]`
  stayed off it on the same ground. `[A]` asked directly whether he should agree to an assembly
  and was told no. **The pieces go forward separately and checkable; the join does not.** The
  08-27 problem it would resolve is still open: stress interferes with weighing, consequences
  drive mobilisation, both rise with depth, and nothing yet says which wins by how much.

- **Ignoring's siting rests on `[A]`'s motive argument**, given 08-30: Z+ is the position that
  chooses pleasure over fear, and dropping a fear without processing it is that sort of act.
  `[C]` had objected that Z+ has no sight to ignore with, and withdrew it — book 1 gives Z+ both
  a quantity of sight and a motivational trace, and says both faces are *selective*, one toward
  what needs correcting and the other **away from what would disturb**. Selecting away is an act
  on material that is there.
