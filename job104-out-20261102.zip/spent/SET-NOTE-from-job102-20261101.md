# SET NOTE — from `Job102 drafting 20261101`

This note goes to the session that receives `job102-out-20261101.zip`. `[A]` gives the kind of session. The manifest label
carries only the counter and the date: `job103-20261101`.

## Arrival

`[A]` named the session `Job102 drafting 20261101`; the label `job102-20261101` agreed. `setcheck.py verify`: 58 ok, 0
mismatched, 0 bad count, 0 missing, 249 not in the manifest, all in `spent/` and `superseded/`. Screen: the record is the one
carry-do-not-read hit; all 48 drop hits are names in `superseded/`. Sweep: the record's last marker matched `Job101`'s note,
hundred-and-third append, 108,458 w. The record was not opened.

## The job

`FINDINGS-job101-20261101.md` Part Four, items 1 to 3, and `RELAY-from-job99-20261101c.md` whole. Every wording already had
`[A]`'s *yes*, so nothing was shown to him. **Every site is in `CHANGES-job102-20261101.md`.**

## What was done

`BOOK2-20261030.md` (45,230 w) became **`BOOK2-20261101.md`** (45,342 w):

- **A fate is met in the detached phase.** Five sentences said *at the ending*; they now say *in the detached phase*. *The
  ending* stays where the passage is meant.
- **One name, *the pain of life not working*.** *The pain of staying* no longer occurs: 19 sites renamed, and the unease loop's
  comparison now weighs *the unease*. `Job99`'s explaining paragraph is the name's first use, straight after the toothache
  paragraph in *Why this does not take everyone to the bottom*. *Rising*'s sentences restate the name. *Staying* is kept where
  it names the choice.
- ***, one rung at a time*** cut from *Rising*.

**Register letter `s`** (`WORD-RULINGS-book2-20261101b.md`): the one name, *the unease* in the loop, and where a fate is met,
each with `[A]`'s words; two patterns added (`staying-name`, `fate-ending`), each firing on the parent at its sites and on
none of the new master. **Style guide letter `o`** (`STYLE-GUIDE-20261101b.md`): pointer only.

## The record

One append, the **hundred-and-fourth**, blind: `[A]`'s one message, verbatim, and `[C]`'s report. **Parent 108,458 w, head
108,707 w.** The parent's 646,856 bytes were checked unchanged at the join.

## Moved

- To `superseded/`: `SUPERSEDED__live__BOOK2-20261030.md`; `SUPERSEDED__live__WORD-RULINGS-book2-20261101.md` (letter `r`);
  `SUPERSEDED__live__STYLE-GUIDE-20261101.md` (letter `n`); `MANIFEST-job102-20261101.md`.
- To `spent/`: `SET-NOTE-from-job101-20261101.md`.
- **New and live:** `BOOK2-20261101.md`; `WORD-RULINGS-book2-20261101b.md`; `STYLE-GUIDE-20261101b.md`;
  `CHANGES-job102-20261101.md`.
- **Kept live:** `RELAY-from-job99-20261101c.md`, until a coherence run checks the master against it;
  `FINDINGS-job101-20261101.md` (items 4 and 5 owed); `CLOSURES-SITED-job99-20261030.md` (Parts E, F, G owed);
  `FINDINGS-job99-20261029.md`.

## What is owed

- **A coherence run on `BOOK2-20261101.md`**: check the master against `RELAY-from-job99-20261101c.md`, then move the relay
  and `CHANGES-job102-20261101.md` to `spent/`. Worth a tracking check on the pain of life not working from its first use
  through *Rising*.
- **The letters pass** (closures Part G, pilot first) must change *The letters are never used for a phase. So a letter always
  means a person.* in *The phases and their names* (findings item 4).
- **Held for `[A]`'s scope and his paper read:** a person placed *at* or *near* an end of the detached phase (findings item 5,
  finding 4); the density items carried from `job100`'s note.
- **Still from earlier notes:** closures Parts E and F; the record's index of subjects (doctrine); `wordcheck.py` has no Part-3
  scope, and `refcount.py` writes to a fixed `Job59` path and fails without it (tools); the handoff is now four sessions
  behind.
- **Still waiting:** the writer 2 pass, on Toby Marshall; the Introduction on recognition, on `[A]`.

For any session that shows `[A]` a change: bold does not show on his screen. Mark new words with square brackets and list the
words going out underneath.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261101.md`.** The kind is `[A]`'s to say.
