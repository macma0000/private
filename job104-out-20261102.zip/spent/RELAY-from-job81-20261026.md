# RELAY — from `Job81 doctrine 20261013`, 2026-10-26

Pasted by `[A]` into `job88 drafting 20261023` on 2026-10-26 at 01:11 UTC, in quotation marks, with no words of his own around it. Saved below the rule as it arrived, except that the chat interface may have turned list markers into `*`. `Job88` did not write any of it.

---

For Job88, from Job81 doctrine, 2026-10-26. These are in the Levels chapter, section What the axis is toward. Quoted words are [A]’s, verbatim.
Opening sentence. It spoke of a third pattern before the three are introduced. [A]: ok to:

* The correspondence stands on its own. Why the levels should follow the orientations at all is a harder question.

The paragraph beginning Whatever a person runs up against at each level is cut. [A]: i thought you were dropping that paragraph. Its evidence goes into the axis-object paragraph. The correspondence ends where it did.
The axis-object paragraph. [A] drafted it with not the realms, fixations, and loosely in how well one deals with their fixation. Job81 changed inner (psychic) world to psychic realm, fixations (orientations) to two fixations, one … their to a person … their, and added the evidence sentence. [A]: ok to:

* That is the axis’s object: not the realms but oneself. A person holds an orientation toward the physical realm and an orientation toward the psychic realm, and those two fix the type. People of every type are found high on the axis and low on it, so the axis cannot be tracking either of those orientations. Separately, a person has their own two fixations to deal with — the chain of fears and desires their type runs on, met as their own case. How that goes is what the axis tracks. So the same nine-position pattern appears three times: toward the physical realm, toward the psychic realm, and, loosely, in how well a person deals with their fixations.

The section now runs: the opening sentence, then the paragraph beginning Follow the object of the wants down (approved 10-23), then the axis-object paragraph, then the rest unchanged.
