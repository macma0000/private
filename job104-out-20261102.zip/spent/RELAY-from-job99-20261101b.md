For Job100, from Job99 doctrine, 2026-11-01, fifth relay. It follows RELAY-from-job99-20261031d.md. [A]'s words are verbatim, with the time of each message (Pacific, now UTC-8). Everything else is Job99's report. Quoted book text is from BOOK2-20261029b.md, so Job100's text may already differ.

1. CHAPTER 14, WHERE A FEAR MEETS ITS FATE

[A], 10:11, pasting Job100's change:
"Only blocking leaves a person noticing less than before. So [a person can come to notice less] only in the detached phase. Nothing that happens in the enthusiastic phase or the cautious phase [leaves a person noticing less]."
"it's awkward. talking about phases after blocking seems disconnected."

Job99 first proposed restating that blocking happens in the detached phase, then concluding from it. [A], 10:13: "is there a reason to say "So [the detached phase is the only place where a person can come to notice less than before.]"?" Job99 said no. In noticing terms, the conclusion only repeats what comes before it. The point the paragraph was there for, that a person's depth changes only in the detached phase, is made in full in the Health Axis chapter's Where a level change can happen: "A person's place on the health axis does not drift. It changes in one phase of a process — the detached phase." Asked whether this goes to drafting, [A], 10:41: "yes".

So the paragraph that begins "Four things can become of a fear in the detached phase." ends:
"... A fear can be blocked all at once, in panic, or gradually, through discomfort. [Only blocking leaves a person noticing less than before.]"
The next paragraph goes. Its first sentence has moved up. Going out: "So how deep a person has fallen can change only in the detached phase." and "Nothing that happens in the enthusiastic phase or the cautious phase changes how deep a person has fallen.", and Job100's versions of both.

2. CHAPTERS 7 AND 8: THE ORDER, AND THE CLASSICAL DIRECTIONS

[A], 10:20, pasting Job100's proposal for Chapter 7's opening sentence, his question to Job100 ("is there any claim that the order of the orientations makes sense independently?") and Job100's answer, began: "i think you should do this job:"

Job99 found that the opening comes from his ruling of 09-15 in job71-drafting-20260915, in the pass on the author's voice: "Chapter 7: it's necessary for directions of(dis)integrations to match the classical system so it depends on the classical system being true." He said the same of Chapter 8. That ruling was about the directions of integration and disintegration, but the opening puts the condition on the order itself. The order has its own ground, which he ruled the same day (FINDINGS-job72-20260915.md, section 2): "phases describe the same three places on the cycle as the fixations". The chapter's last section calls the order of a thought's phases "a fact, completing many times an hour, in everyone". Job99 recommended a split: the order follows from the orientations themselves, and the classical directions are a separate matter. [A], 10:26: "show it." Then, 10:28: "go on". Then, 10:32: "now we don't need to say "If the classical Enneagram is right" - just explain that the two systems correspond. maybe that's done in detail later but it should be said here. right?" Job99: right, and Chapter 10, The Figure's Own Lines, shows the correspondence type by type. Asked whether this replaces his 09-15 ruling, [A], 10:38: "yes. but can more be said that two orientation system with its directions integration and disintegration predict the directions integration and disintegration of the enneagram system? i think it's important even if it isn't demonstrated until chapter 10." Shown the paragraph below, [A], 10:40: "yes".

His 10:32 and 10:38 words supersede his 09-15 ruling for Chapters 7 and 8. They also supersede Job100's proposal for Chapter 7's opening sentence.

a. Chapter 7, the opening sentence:
"There is an order among the three orientations."
Going out: "If the classical Enneagram is right about the directions of integration and disintegration,"

b. Chapter 7, the paragraph that defines integration and disintegration:
"[The classical Enneagram describes which way a person is pulled in growth and under stress, and calls the two directions integration and disintegration. The two directions correspond to the order: integration goes with the order, and disintegration goes against the order.] [Integration is] the direction natural experience leads as a person meets the drawbacks of the orientation they hold. [Disintegration is] the direction competence comes apart in when stress disturbs a person's ability to focus."
Going out: "The pull that goes with the order is integration," and "The pull that goes against it is disintegration,". The book's bold on the first use of integration and disintegration moves to their new first uses.

c. Chapter 7, a new paragraph straight after b:
"[Because a type is a pair of orientations, one for each realm, the order predicts the classical directions for each of the nine types. The classical Enneagram joins the nine types with lines and gives each line a direction of growth and a direction of stress. On every line, the type a person is pulled toward in growth is one step forward along the order, in one realm or in both. The type a person is pulled toward under stress is one step back, in one realm or in both. The classical Enneagram gives no reason for its lines, and the order supplies one.]"
Job99 checked each sentence against Chapter 10. The six-pointed figure is a chain of single steps. The triangle is a chain of double steps. Disintegration is "the same lines read backward". Chapter 10 also says "No reason has ever been offered for that particular order." The paragraph claims only that every classical line is a step along the order, not the reverse, because the order also gives the twelve crossing relations that the figure does not draw.

d. Chapter 8, Relational Positions:
"Ahead here is a position on a circle, not a rank. The circle comes from the order of the orientations."
Going out: ", so the positions hold only if the classical Enneagram is right about the directions of integration and disintegration"
The next paragraph, "Ahead means one step in the direction of integration, behind one step the other way. …", stays as it is. Job99's earlier changes to it (10:28) are withdrawn.

For the next session that maintains the claim inventory: the Chapter 7 head entry gains the claim that the order predicts the classical directions for each type, asserted at Chapter 7 and shown at Chapter 10.
