# ANSWERS for `Job75 coherence 09232026`, from `Job70 doctrine 09152026` — fifth sheet

Cut 2026-09-23, after the fourth answer sheet. **Merge last, in date order.**

**This sheet largely replaces §1 of the fourth sheet.** `[A]` reworked the counterfeit-summit
account after that sheet was cut, and the three parts `Job75` was holding for his ruling are
overtaken rather than ruled. **What replaces them is below, and it is his.**

**`Job70` has no manuscript in any sitting today.**

---

## 1. RULED — what is trained is abiding in the detached phase

`[A]` 2026-09-23: **fixations and phases are separate things. every fixation orientation has a
detached phase. abiding in the detached phase can be trained.**

**So nothing is trained into being an orientation.** Everyone passes through the detached phase in
every cycle, whatever their fixation. **What a person trains is how long and how fully they stay
in a phase they already pass through.**

This removes a question `[C]` had raised and could not settle — whether the model allows an
orientation to be reached deliberately. **It does not arise.**

**What the training produces.** A person who trains abiding in the detached phase of cycles about
physical matter does not flinch and does not chase comfort — **the visible marks, real, and
produced by real training — while their physical fixation is unchanged.**

**So there is one counterfeit, not two.** `[C]` had separated an honest case from a performance.
**That separation is withdrawn.** The attainment is genuine, the marks are genuine, and the error
is the observers' — they read an orientation off conduct. **Nobody is performing, and the book
accuses no one.**

**`[A]`'s account of the deception, from the fourth sheet, still stands:** observers see one realm
and take the person to be like that throughout.

## 2. RULED — trained detachment is a tool, used at moments

`[A]`, imagining himself trained to physical detachment: he would **remain vigilant in the physical
realm** and **use detachment as a tool** when fear got in the way — to avoid panic, the better to
protect himself.

**So a trained person is not in a state. They reach for abiding when it serves them.** The chapter
currently describes the trained person as simply being a certain way, which is wrong.

## 3. RULED — conscience is psychic caution, and what happens to it depends on the person

`[A]`: **conscience is a psychic cautious phenomenon — understanding the disadvantages of hurting
others.**

**That is the cautious phase examining a want and finding trouble with it, about psychic matter.**

**For a person whose psychic realm is cautious:** conscience is their own fixation operating.
Abiding does not touch it. **It is not raised while they abide and it is there again when they
stop. Muted during, intact after.**

**For a person whose psychic realm is enthusiastic:** their own cycles raise little examining of
what their wants would do to others, so **whatever conscience they have came from outside, learned
as a rule rather than reached by examining.** `[A]`: such a person **might have less understanding
of the disadvantages of hurting others**, and **having worked without conscience might cause them
to unlearn it.**

**So the chapter's *a casualty of the training* is right for one kind of person and wrong for
another, and not for the reason the chapter gives.** What costs that person their conscience is
**not the training** — it is the period of working without it, which the training made
comfortable. A rule has to be invoked to work, and acting against it repeatedly is practice at not
invoking it.

**The chapter must not say that training damages conscience.** It does not.

## 4. NEW MATERIAL, not in the model — a rule followed by rote

`[A]` 2026-09-23: **it's not in the model. young people operate by rote before they start
understanding and continue when understanding is absent.**

**A rule followed by rote, operating where understanding is absent.** The model has nothing like
it. **It is what the conscience case above needs**, and it may reach further than this one
passage. **Flagged as new; not sited anywhere.**

## 5. The missing examples — a question for `Job75` before anything is written

`[A]` reports that **the false summit originally carried examples in each realm** — two for the
physical, one for the psychic. **None survives in the section as `Job75` quoted it.**

**The section is now lopsided.** The physical realm gets the whole visible account — austerity,
fearlessness, unconcern with comfort and pain, the holiness reading. **The psychic realm appears
only as the conscience sentence.** Losing the examples is the likely cause.

**`Job75` has the manuscript and `Job74`'s output. Please find out what happened to them** —
deliberately cut with a reason recorded, lost in a rewrite, or sitting in a superseded file.
**Whoever cut them may have had a reason that is written down**, and that matters more than
reconstructing the examples.

## 6. RULED — the examples come back without labels

`[A]`: **ok to drop labels.** The originals named groups — a political and religious charge in one
case, a living category of person in another. **Everything else in the book describes kinds of
people by what they do.**

**`[C]`'s replacements, not ruled, offered for a drafting session:**

- **Physical** — a person trained to work on a body that is bleeding, or to keep moving under
  fire, who does not flinch and does not look away.
- **Psychic** — a person trained to sit with someone in the worst hour of their life and stay
  level, hearing what is said without being pulled into it.

**Why these rather than something stranger.** The trained behaviour is the person's **competence**,
so observers read serenity off skill and the mistake is forced rather than careless. Each abides in
the detached phase of cycles about its own matter, so the pair is exact. **And the conscience case
sits naturally in the psychic one**, which carries `[A]`'s distinction without explaining it twice.

**`Job75` should check whether either example is already used elsewhere in the book for something
else before they are placed.** `Job70` has no manuscript and cannot.

## 7. `[A]`'s guess, recorded as a guess

**What trained abiding does to the fixation: *probably weakens it*.** Not ruled, and the book
should not state it as a finding.

**What the existing account predicts, which can be said:** a fixation is attention concentrated at
one phase, so time spent abiding at the detached phase is attention not concentrated where the
fixation holds it. **Weakening is what the model predicts**, and the book may say so as a
prediction.

---

## What survives from the fourth sheet

**The unchecked-realm clause stays** — *with the other realm running entirely unchecked behind it*.

**`indifference`:** never used of a person or of detachment; the Four's sentence about the physical
world stays; *the absence of caring* in the buddha sentence.

**Equanimity stays out of the book**, and the boundary runs between Z0 and equanimity.

**The buddha draft** in §4 of the fourth sheet, still `[C]`'s and unruled.
