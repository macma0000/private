# FINDINGS — `Job91 coherence 20261026`

Coherence run on `BOOK2-20261027.md` (44,029 w), reading `CHANGES-job90-20261027.md` and the eight relays `Job90` applied
(`RELAY-from-job81-20261026g.md` to `-20261026n.md`). `[A]`'s words are verbatim. The session ran from 10-27 into 10-28.
Five updates from `Job81 doctrine 20261013` arrived in session, each saved byte for byte: `RELAY-from-job81-20261027.md`,
`-20261027b.md`, `-20261027c.md`, `-20261027d.md` and `-20261028.md`. `FOR-job81-from-job91-20261027.md` is the block
`Job91` wrote for `Job81`; it is answered (relay `c`).

**Changes file checked.** All 29 rows of `CHANGES-job90-20261027.md` are in the master (36 diff hunks against
`BOOK2-20261026.md`). Every sentence of text the eight relays proposed is in the master, relay `m` with *unsettled* for
*unattended* as row 6 says.

**For the drafting session.** Every item below is ruled, with `[A]`'s words, except where marked as a `[C]` decision
taken from rulings already given. Show `[A]` each change in place before applying it, new words in square brackets
(bold does not show on his screen). Grep each idea by its words, not only at the sites listed. Items 1 to 3 and 5 to 6
continue Job89's thread: the two kinds of blocking. Item 4 brings new definitions into Ch 4.

**Tracking check.** Run on **a buried fear**: from the first burial (glimpsed, then turned away from by panic), through
the later fears about the same matter (turned away from before they are noticed), the layers of fear of the fear (buried
too, possibly without end), to whether it can be got at (intentional access blocked; intuition can act on it; it can come
back into view when conditions do not trigger fear) and what it leaves (blindness; noticing lowered). Tests (a) to (d)
were not re-run across the book.

## 1. Is a buried fear noticed at all?

**Fault.** Never noticed: *A buried fear never comes into view at all.* (*The four fates*); *What does not happen is the
noticing, so the threat never comes into view.* (*Burial is not a decision*); *With buried material, the fear is never
noticed.* and *Her buried fears were never noticed.* (*The unease loop*). Barely noticed or glimpsed: *Some of the fears
are turned away from in panic and barely noticed, and those fears are buried.* (*The range of detachment*); *When the fear
is very unpleasant, the person turns away in panic, and the fear is barely noticed.* (*The two faces of detachment*); *at
first a fear may be glimpsed before panic turns the person away from it.* (*A burial is not one event*).

**Asked:** is a buried fear glimpsed for a moment before panic turns the person away from the fear, or never noticed at all?

**`[A]`, 2026-10-27:** *a buried fear glimpsed for a moment before panic turns the person away from the fear.*

**Asked next:** when a later fear about the same matter comes up, after the turning away has become automatic, is it
glimpsed too, or turned away from before it is noticed at all? (book: *What a burial laid down is not noticed again,
because the turning away comes before the noticing.*; *Each time, more of the fears are turned away from before they are
noticed.*)

**`[A]`, 2026-10-27:** *it is turned away from before it is noticed at all.*

**Sites, sorted by the two answers.**
- Say the first burial is never noticed, so are wrong by the first answer: *A buried fear never comes into view at all.*
  (*The four fates*, two-questions paragraph); *What does not happen is the noticing, so the threat never comes into view.*
  and *the fear it belongs to never came into view* (*Burial is not a decision*); *The threat is taken in like everything
  else, and the noticing simply does not happen.* (*Disregarding, and not seeing at all*).
- About later fears, right by the second answer: *What a burial laid down is not noticed again…*; *Each time, more of the
  fears are turned away from before they are noticed.*; *With buried material, the fear is never noticed.*; Ch 4 *It
  happens before the thing is noticed.* (denial, automatic).
- Read both ways, for drafting to word: *what is being avoided was never noticed* (*The range of detachment*); *Her
  buried fears were never noticed.* (migraine case); *a person cannot get at what they never noticed* (*Disregarding*).

**Asked next:** *Burial is not a decision* argues *Deciding not to look at a thing requires having noticed it first.* If
the first burial is glimpsed, is it not a decision because a glimpse is too brief, because panic does the turning away and
not the person, or for another reason?

**`[A]`, 2026-10-27:** *because panic does the turning away, not the person.*

**For drafting:** the section's reason, at the first burial, becomes panic doing the turning away; the no-noticing reason
stays for the later fears, which are turned away from before they are noticed.

## 2. Denial, and turning away that has become automatic (Ch 4)

**Fault.** Ch 4: *When the negative thing is very unpleasant, the turning away can become automatic. Turning away that has
become automatic is denial. It happens before the thing is noticed.* *The four fates*: *Blind blocking is the same act as
denial*; discomfort blocking: *the turning away becomes more automatic*, and *the later fear can still be noticed*.

**Asked:** is denial only blind blocking, or is discomfort blocking also denial once its turning away has become automatic?

**`[A]`, 2026-10-27:** *i would limit it to blind blocking because apparently nothing can make that person remember.*

**For drafting:** Ch 4's *Turning away that has become automatic is denial* is too wide; denial is the automatic turning
away of blind blocking only.

## 3. *What was never noticed cannot be got at afterwards*

**Fault.** Ch 4: *Turning away brings relief, and the relief is real each time. That relief is what holds the turning away
in place. What was never noticed cannot be got at afterwards, so nothing in the realm corrects it.* *Disregarding*: *a
person cannot get at what they never noticed.* Against: Ch 4 intuition, *A person notices something now that was taken in
earlier and never noticed at the time.*; *Rising*, *A buried fear can come back into view by itself.*; *Where a level
change can happen*, *A fear blocked by discomfort can come back into view when a matching fear is noticed*.

**Asked:** does *cannot be got at* mean cannot be found by deliberately looking, while the thing can still come back into
view by itself?

**`[A]`, 2026-10-27:** *it seems possible the thing could come back into view itself when the conditions didn't trigger
fear. any trying to find it would probably trigger fear. the fear itself is more approachable, but the fear is often also
be buried. at some level of burial there would be only discomfort and examination could work at that level.* / *intuition
can act on buried information. only conscious awareness of it is blocked. so intentional access is blocked.* / *any more
needed?* — answered: no more needed for this item.

**For drafting:** both sentences say intentional access is blocked, not all access; intuition can act on buried
information; the thing can come back into view by itself when conditions do not trigger fear.

## 4. *aversion* in the *Blocked* entry

**Fault.** *Blocked — the aversion is turned away from until it is no longer noticed.* (aversion = what is turned away
from) against, four sentences on, *Each time the fear comes near, the person's aversion turns their attention elsewhere*
(aversion = what does the turning). *The same four fates meet every aversion, not only a fear.* comes after the four
entries; the other three entries say *fear*. The definitions are in Ch 14, *One thought, step by step*: *A want is an
attraction when the want is for something to arrive. A want is an aversion when the want is for something to go, or to
stay away. Attraction and aversion are the two most general kinds of motivation.* and *A fear is one kind of aversion.*
Wants and fears are first used in Ch 4.

**Asked:** should the opening line say *the fear*, keeping *aversion* for what does the turning, or keep *the aversion*?

**`[A]`, 2026-10-27:** *good question. i think "attraction" and "aversion" should be introduced when "wants" and "fears
are. i'm unclear about how to define all these words.*

Not for coherence to settle; taken to `Job81 doctrine 20261013` by `[A]` in session, and settled there (below).

**Relay in session:** `RELAY-from-job81-20261027.md` — the Ch 4 definitions of attraction, aversion, want and fear, and
`Job81`'s three consequences (the *One thought* definitions replaced by a sentence recalling Ch 4; the *Blocked* opening
keeps *the aversion*, and *the person's aversion turns their attention elsewhere* becomes *the discomfort of the fear turns
the person's attention elsewhere*; *The same four fates meet every aversion* moves to directly after the opening sentence
of *The four fates*). His words inside it: *yes to Job81's reading of that, and to the whole passage.*

**Asked:** under the new definition (*A want is an attraction that moves the person toward having something, or keeping
it.*), is the want to be rid of a pain still a want? Answered by `RELAY-from-job81-20261027b.md`: keep *want*, write
*relief from*. `Job91` found about twenty wants for something to go, several setting wanting it gone against wanting it
solved. **`[A]`, 2026-10-27:** *yes*; asked which question the yes answered: *job81 say: "Apply relief from to the plain
sentences. Send the ones where wanting it gone is set against wanting it solved to Job81 first." do that.*

**Withdrawn by `RELAY-from-job81-20261027c.md`** (pasted 01:41, his words inside it): *is there a difference between an
aversion to something and wanting it to be gone? i think they are separate.*; then yes to the Ch 4 passage with the
addition *An aversion can raise a want to be rid of something. Wanting something gone is a want, not an aversion.* The
*relief from* edits are withdrawn; every *want to be rid of* and *want … gone* sentence stands as written.
`FOR-job81-from-job91-20261027.md` was sent and is answered.

**Final, `RELAY-from-job81-20261027d.md`** (pasted 01:51; his words inside it, among them *good. so a want can arise from
an aversion or an attraction. and a fear can arise from attraction as well as an aversion. a fear arising from attraction
is a real thing.*, then *yes* to the passage). It replaces the Ch 4 passage of relays `20261027` and `c`. An attraction or
an aversion is the pull; a want is what moves the person, raised from either side. All *want … gone* and *want to be rid
of* sentences stand. `Job81`'s three consequences from relay `20261027` stand (*One thought* definitions replaced by a
sentence recalling Ch 4; *Blocked* keeps *the aversion* and *the person's aversion turns their attention elsewhere* becomes
*the discomfort of the fear turns the person's attention elsewhere*; *The same four fates meet every aversion* moves after
the opening sentence of *The four fates*). **For drafting also:** *desire* in the Levels chapter — use *want*, or say once
that a desire is a want. Note: the register's 10-09 entries on *aversion and attraction* and *desire* are superseded.

## 5. *So burying develops gradually*

**Fault.** *A burial is not one event*: *So burying develops gradually, and the turning away becomes automatic over that
history.* Against the *Blocked* entry, *The turning away is automatic and happens all at once.*, and *Where a fear meets
its fate*, *A fear can be blocked all at once, in panic, or gradually, through discomfort.* (`Job91` first wrote that the
two disagree with each other; `[A]`: *they don't disagree. the first is burial = blind blocking. the second refers to the
two kinds of blocking separately.* The fault is the *gradually* sentence against both.)

**`[A]`, 2026-10-27:** *the main issue in the burial happens quickly, maybe in no more than a week. layers of fear of the
fear accumulate later possible without an end. those layers would correspond to turning away sooner. (discomfort blocking
also becomes automatic over time.)*

**Shown:** the main burial of a matter happens quickly, perhaps within a week, each fear buried all at once in panic;
afterwards layers of fear of the fear build up, possibly without end, each layer meaning the turning away comes sooner; the
gradual part is the later layers, not the burial. **`[A]`, 2026-10-27:** *"layers of fear of the fear build up" these and
the original are all blind buried. yes.*

**For drafting:** *So burying develops gradually* becomes that account; the later layers are buried too, blindly.

## 6. *blocked* used for burial in *The range of detachment*

*Suppose the person had news of a threat to their work years before, and a fear about losing work was blocked then. The
new incident sets off an automatic turning away from noticing, before anything about the job has been noticed.* Turning
away before anything is noticed is what follows a burial (item 1, second answer); after discomfort blocking *the later
fear can still be noticed*. **`[C]` DECISION, by the rulings already given, not put to `[A]`:** *blocked* → *buried* here.
Also in the section: *Such a person turns away from whatever would interrupt the return to peace, and so never notices
what would interrupt the peace.* — drafting to word by item 1 (discomfort-blocked fears are noticed at first).

## 7. *less able to handle life than others are* — two causes

**Fault.** *The unease loop*: *Blocked aversions can leave a person less able to handle life than others are.* *What
falling takes from capacity*: *Things going wrong unexpectedly, and reactions that have not been thought out, can together
leave a person less able to handle life than others are.*

**Asked:** is the second sentence how blocked aversions do it, or a separate cause?

**`[A]`, 2026-10-28:** *both are the result of blocked aversions.*

**For drafting:** *What falling takes from capacity* says the two come from blocked aversions, so one cause stands at both
sites.

## 8. Discomfort blocking and seeing

**Fault.** *What a level is made of*: *A fear blocked by discomfort is no longer noticed, but it leaves no blindness.* and
*Blindness comes only from burial.* Against *What actually descends*, *Each fear turned away from until it is no longer
noticed takes a little of the seeing with it.*, and *Where a fear meets its fate*, *Only blocking leaves a person seeing
less than before.*

**Asked:** does a fear blocked by discomfort leave a person seeing less, or only stop the noticing of that one fear?

**Answered by `RELAY-from-job81-20261028.md`. `[A]`, 2026-10-28:** *job81 says and i accept:* — discomfort blocking leaves
the person noticing less, but not blind; the fault is the word *seeing*.

**For drafting:** *seeing* → *noticing* at both sentences. **`[C]` DECISION, by the same ruling:** two more sites found by
grep take the same change — *The four fates*, opening: *only one of them leaves a person seeing less than before*; and
*Disregarding, and not seeing at all*: *Only a blocked fear is a failure of seeing.* (→ *of noticing*). The section title
*Disregarding, and not seeing at all* is left: drafting to judge, since the section is about burial as well.

## 9. Checked and left

- *Falling and rising*, *What actually descends*: *The skill at the enthusiasm end is the harder of the two to use, because
  turning away is automatic and the relief it brings is real every time.* Holds for both kinds: `[A]` 2026-10-27,
  *discomfort blocking also becomes automatic over time.*
- Job90's left-unchanged list re-read against today's rulings; the buried-material sites are now sorted under item 1.

## Owed

- **A drafting session** on items 1 to 8 above, with relays `20261027d` (the Ch 4 definitions; it replaces the passages in
  `20261027` and `c`, whose three consequences still stand) and `20261028`.
- **The word register** needs the 10-28 definitions of attraction, aversion, want, fear and desire; its 10-09 entries are
  superseded. For the drafting session to enter with `[A]`'s words.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master. Carried.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold. Carried.
- **The writer 2 pass**, still waiting on Toby Marshall. Carried.
