# QUERY FOR DOCTRINE — when blocking happens, and what it acts on

**Raised 2026-09-08 by `Job58 drafting 09082026`, while checking the Chapter 7 two-faces block
against the four-outcome passages, as doctrine asked. Not repaired. No prose has been written
on either side of it.**

---

## The three statements

**Ch 14, where the four outcomes are first given:**

> ...or blocked, turned away from before it is seen at all.

**Ch 15, in the four-outcome expansion:**

> *Blocked* — the fear is turned away from before it arrives. It survives hidden and stable, and
> it is the one of the four that does that.

**Ch 7, the two-faces block written this session:**

> So a fear arriving in a detached realm is either noticed or turned away from. [...] Turned away
> from, it survives hidden and stable, and the person never knew it was there to deal with.

The three put the block at three different moments: before sight, before arrival, and after
arrival but before noticing.

---

## Why Ch 14's wording is already settled

`Job57` ruled that `see` keeps only its ordinary meaning, and `Job55` sited the block at the
noticing step, not at the taking in. **Under those two rulings, *before it is seen at all* is
wording that has already been retired**, and it should be *before it is noticed*. This one looks
mechanical and I raise it only so the pass that fixes it knows it is owed.

---

## Why Ch 15's wording is the real question

**If a blocked fear is turned away from before it arrives, then nothing arrived, and there is
nothing for the arc to have delivered.** That empties the arc source at the one outcome that
depends on it most.

The whole account written this session rests on the arc source: a process runs in a detached
realm, raises a fear, and the fear reaches the end of that process carrying its own object. The
two faces are then a matter of how long the person dwells at the caution end and how much of the
arriving fear is looked at. **On the enthusiasm side, what is not looked at is what gets turned
away from — so blocking acts on a fear that arrived and was not taken up.** If instead the fear
never arrives, the two faces are not two dwelling times on one delivery. They are two different
deliveries, and the dwelling account does not describe the second one.

**It also breaks the descent, which needs the blocked fear to exist in order to survive.** Ch 15
says a blocked fear survives hidden and stable, and the loop that maintains the blindness needs a
real fear kept out of view. Something that never arrived cannot survive anything.

---

## The two readings, so doctrine can pick one

**Reading 1 — the fear arrives and is not noticed.** The arc delivers it. The person is already
moving toward what attracts, and it is turned away from before the second act happens. What
survives is a real fear that was never picked out of what was taken in. Ch 15's *before it
arrives* would become *before it is noticed*, and the block acts on the noticing.

**This is the reading the Chapter 7 block was written on**, and it is the one consistent with the
block being sited at the noticing step, with the arc source, and with a blocked fear surviving.

**Reading 2 — *arrives* means something other than delivery by the arc.** If *arrives* in Ch 15
means arriving in view rather than arriving in the realm, the sentence is saying what Reading 1
says, in words that collide with the arc language used everywhere else. Then only the wording is
at fault, and it still needs changing, because the same passage uses *arrives* for the arc
delivery a few lines earlier.

---

## What I would need back

**A ruling on which moment blocking occupies**, and if it is Reading 1, permission to change
Ch 15's *before it arrives* and Ch 14's *before it is seen at all* to the noticing wording.

**Neither is in a piece I have started.** Ch 15's four-outcome passage and Ch 14's summary are
both outside what was ruled for this session, so nothing is blocked while this waits — the
Chapter 4 block is next and does not depend on it.

---

## One thing to note about how this surfaced

The block reads correctly in each chapter on its own. It is only when the same fear has to be
followed from the arc that raises it, through the dwelling that decides what becomes of it, to
the outcome that keeps it, that the three moments show up as three. **The Chapter 7 block was the
first passage that had to carry all three at once**, which is why the disagreement had gone
unnoticed through three coherence runs.
