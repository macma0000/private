For Job100, from Job99 doctrine, 2026-10-31. On what happens to a fear at the caution end of the detached phase (phase Z−) and at the enthusiasm end (phase Z+), for fixations A, B, Z− and Z+.

[A], 12:40, in Job99: "drafting needs to know what happens to fears at the Z- and Z+ phases for fixations at A and B as well as Z- and Z+."

Job99 put the account below together from his rulings and from his own four sketches (09-01, SKETCHES-rewrite-by-author-20260901b.md), and showed it to him whole. One point in it was Job99's reading and not yet a ruling: that discomfort blocking starts at the caution end and is completed at the enthusiasm end, the way a burial is. Asked "Is that right?", [A], 13:23: "yes". Nothing else in the account is new doctrine.

In what follows, a person's fixation means the fixation the person holds in the realm the fear is about.

THE SAME FOR EVERY FIXATION

- Every process passes through the caution end and then the enthusiasm end, whatever fixation a person holds. (His words 08-27: "all fixations move through z- and z+".)
- At the caution end the fear is still in view. The caution end is where a fear is settled, by being worked through or given up on. (His ruling in Job100, 10-31.)
- A fear not settled at the caution end goes on to the enthusiasm end. There the fear is ignored or blocked by discomfort. An ignored fear is let alone, and comes back when the person next meets the problem. (Ignoring sited at the enthusiasm end, ruled 08-30.)
- Discomfort blocking starts at the caution end, where the fear is in view and looking at the fear is found uncomfortable. The person turns away from the fear at the enthusiasm end. (13:23 today.)
- A fear found at the caution end to be more than the person can bear is turned away from in panic. The turning away is completed at the enthusiasm end, and the fear is buried. A burial can happen with any fixation. (09-10; the panic at the caution end approved 10-28.)
- A fear about a matter already buried is turned away from before the fear is noticed, so the fear never comes into view at the caution end. (10-27.)
- A fixation changes how much attention each end gets, and so how many fears are settled before the enthusiasm end. A fixation does not change whether a process reaches the enthusiasm end. (09-10, agreed.)

BY FIXATION

- Fixation A. Few fears reach the detached phase, because the examining was cut short. The person understands little about the fears that do reach the detached phase. Little attention goes to either end. At the caution end the person often gives up on a fear by dropping the endeavor. A fear that gets past the caution end unsettled meets one of the fates at the enthusiasm end, and a new want arises at once. (His A sketch; Where a fixation acts.)
- Fixation B. Many fears reach the detached phase, already understood. The fears reach the detached phase late, when need or exhaustion forces the ending. Little attention goes to either end. At the caution end the person may work a fear through, give the fear up, or let the fear pass. A fear that passes meets one of the fates at the enthusiasm end, and the person starts another endeavor. (His B sketch; Where a fixation acts.)
- Fixation Z−. Most attention goes to the caution end, so a fear is more likely to be settled, often by a real decision either to act or that acting is not worth the trouble. The less cautious the lean, the more fears go on to the enthusiasm end, where the fears are ignored. (His Z− sketch; Disregarding, and not seeing at all.)
- Fixation Z+. Little attention goes to the caution end, so a fear is less likely to be settled. A fear that is settled is more often given up on than worked through. Most attention goes to the enthusiasm end. There the person usually drops everything for something more pleasant, and the fear is forgotten. A fear that is uncomfortable to look at is blocked by discomfort, and a fear the person cannot bear is buried. (His Z+ sketch; 08-30; 09-10; 10-08.)

WHERE THE ACCOUNT BEARS ON THE BOOK

Quoted from BOOK2-20261029b.md. Job100's text may already differ.

1. Which fixation handles a fear, the paragraph Job100 is repairing. The paragraph gives the two detached leans, and one sentence to the enthusiastic and cautious fixations. To cover all four fixations at both ends, the paragraph needs what the account above says. The four sketches come next and tell the same in story form, so the paragraph needs the account and not the stories.

2. The same section, the paragraph before: "An enthusiastic or cautious person handles a fear mostly before the detached phase." contradicts the 10-31 ruling, because no fear is settled before the detached phase. What happens before the detached phase is the examining. An enthusiastic person cuts the examining short, so few fears are raised. A cautious person examines heavily, so many fears are raised and understood. In the paragraph after it, "Everybody handles fears in the detached phase too" loses "too" for the same reason. And "A person with no detached realm gives the detached phase little attention" should be about a person whose fixation in the realm of the fear is enthusiastic or cautious, since the section's first paragraph says the fixation in the fear's realm handles the fear.

3. Disregarding, and not seeing at all: "A fear such a person leaves unsettled is noticed less each time the fear comes near, or grows until panic turns the person away from the fear." gives the detached person leaning toward enthusiasm only discomfort blocking and burial. Ignoring comes first for that person. His words 09-10: "passage into Z+ usually involves simply forgetting". And in Job81 (10-13 to 10-15), asked whether a fear is ignored or blocked when a detached person at the enthusiasm end distracts themselves, his answer: "ignored."

4. The four fates, the Blocked entry: where discomfort blocking happens (13:23 today) goes where discomfort blocking is defined. The burial's crossing of the detached phase is stated later, in How a fear comes to be buried.

5. Two sentences say a fear is "noticed and met" at the caution end. Chapter 4: "The more attention a person gives the caution end, the more likely a fear is to be noticed and met there." The range of detachment: "The lean changes how likely a fear is to be noticed and met at the caution end, before the fear reaches the enthusiasm end." A fear still in view is noticed at the caution end whatever the attention, as the same Chapter 4 paragraph says. What attention changes is whether the fear is settled. The repair is the one [A] made in Which fixation handles a fear on 10-31.

6. Chapter 14 states the place of the fates twice in short form: "A fear meets its fate somewhere between the caution end of the detached phase and the enthusiasm end." and "Processing happens near the caution end of the detached phase. Ignoring happens near the enthusiasm end of the detached phase." Under the 10-31 ruling, a fear that is settled is settled at the caution end, and a fear that is not settled meets its fate at the enthusiasm end. "somewhere between" and "near" both leave room for a fear to be settled somewhere else.
