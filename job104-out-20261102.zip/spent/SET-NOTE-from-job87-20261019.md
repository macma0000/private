# SET NOTE — from `Job87 coherence 20261018`

This note goes to the session that receives `job87-out-20261019.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job88-20261019`.

## Arrival

`job86-out-20261019.zip` verified against `MANIFEST-job87-20261019.md`: **56 ok, 0 mismatched, 0 bad count, 0 missing,
151 not in the manifest**, all 151 in `spent/` and `superseded/`. The screen marked the record *carry, do not read*,
and this session did not open it. The 35 files the screen said to drop were all already in `superseded/`. The record's
last marker matched `Job86`'s set note: eighty-eighth append, 98,902 w. `[A]` named the session `Job87 coherence
20261018`; the label's date is a day later. Nothing turned on it.

## What was done

A coherence run on **`BOOK2-20261018.md`**, which is unchanged and is still the master.

- **The last section of the falling-and-rising chapter, *Why trying harder does not change a person*, read in full and
  shown to `[A]` whole.** Three faults, all ruled: effort was said never to help a climb; *works well* had no object
  after `Job86`'s cut; the lever figure's words were left with nothing to explain them. **`[A]` approved new wording for
  the whole section.** It is in **`FINDINGS-job87-20261019.md`** Part One row 4.
- **`Job81 doctrine 20261013` sent an update during the session**, pasted by `[A]`. It travels byte for byte as
  **`RELAY-from-job81-20261019.md`**: two kinds of blocking, *blind blocking* and *discomfort blocking*, with approved
  wording at seven sites and a sweep. Every passage it names was found in the master. The findings' Part Two has three
  notes on it. One of them: the third source of stress it lists as not yet approved is already in the book with
  `[A]`'s yes from `Job86`.
- **The claim inventory** has a 10-19 block for every unit `Job86` changed, and the leverage entry is replaced.
- **Checks:** `quotecheck.py quotes` on the findings against the master: 7 verified, 0 failed, 1 skipped as short
  (*The self is that position.*, found once by `grep -F`). `wordcheck.py` against letter `m`. The referring-word count
  was run on the approved wording. Tracking check run on own effort in a climb.
- **Register and style guide not changed.** A coherence session does not rule vocabulary. The register's lever entry
  quotes wording that is now replaced, and the findings tell the drafting session to amend it.

## The record

One append, blind: the **eighty-ninth**, `[A]`'s words verbatim with what each answered. The `Job86` and `Job81` relays
are marked. **Parent 98,902 w, head 99,377 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `CHANGES-job86-20261018.md` (read by this coherence run), `SET-NOTE-from-job86-20261019.md`.
- To `superseded/`: `MANIFEST-job87-20261019.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be
  acted on until `[A]` says so.

## What is owed

- **A drafting session on `FINDINGS-job87-20261019.md` and `RELAY-from-job81-20261019.md` together.** The relay is the
  larger part, and it includes the sweep limiting statements of how hard it is to rise to buried material. It also adds
  a new word, *discomfort blocking*. The register needs it with `[A]`'s words. A coherence run should follow.
- **For a doctrine session:** whether the perceived inability to handle life bears on depth and threshold, which is
  reserved for a session of its own.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master, register letter `c` and style guide letter
  `d`. It needs a cut.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a drafting session on the findings and the relay.**
