# SET NOTE — from `job92 drafting 20261027`

This note goes to the session that receives `job92-out-20261029.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job93-20261029`.

## Arrival

`job91-out-20261028.zip` verified against `MANIFEST-job92-20261028.md`: **61 ok, 0 mismatched, 0 bad count, 0 missing,
189 not in the manifest**, all 189 in `spent/` (117) and `superseded/` (72), matching `Job91`'s moves. The record's last
marker matched `Job91`'s note: ninety-third append, 101,849 w. `[A]` named the session `job92 drafting 20261027`; the
label's counter agreed. The session ran from 10-28 into 10-29 (UTC).

## What was done

A drafting session on **`FINDINGS-job91-20261028.md`**, items 1 to 8, with relays `20261027d` and `20261028`. **Master out:
`BOOK2-20261028.md`**, 44,633 w. Every change was shown to `[A]` in place before it was applied. The 34 rows, each with his
words, are in **`CHANGES-job92-20261028.md`**.

- **Item 1 was corrected in session.** `[A]`, through `Job81` (relay `20261028b`): a fear is buried only after it has come
  up repeatedly and grown; panic then buries it. Relay `20261028d`: the panic happens at the caution end, and the turning
  away is completed at the enthusiasm end. Every burial site follows those two relays. *Barely noticed* and *glimpsed* are
  gone. After a burial, the fear is *no longer noticed*, and later threats are turned away from before they are noticed.
- ***Burial is not a decision*** rewritten: panic does the turning away, not the person.
- **Denial is the effect of a burial**, in Ch 4 and the *Blocked* entry. **Intentional access** only is blocked; Ch 4's
  relief sentences are `[A]`'s own.
- **The main burial is quick, then layers of fear of the fear build up.**
- **Ch 4 defines attraction, aversion, want and fear** (relay `20261027d`), with **motivate** for what a want or a fear
  does (`[A]`), carried to five other sites.
- **desire → want everywhere** (relay `20261028e`, `[A]`: *i accept it.*), with *Riso and Hudson call this want a desire.*
- **seeing → noticing** at four sites; **the discomfort of the fear turns the person's attention elsewhere** at three.
- **`WORD-RULINGS-book2-20261028.md`, letter `p`**, and **`STYLE-GUIDE-20261028.md`, letter `k`.** `[A]`, shown the
  summary: *yes*.
- **Checks:** referring-word count on every new sentence of `Job92`'s (the sentences `[A]` wrote are his); `wordcheck.py`
  against letter `p`, every new hit read and allowed. The four new patterns and the rewritten `desire` pattern fire on the
  parent and on none of the new master, apart from the two allowed uses of *desire*.

**For any session that shows `[A]` a change: bold does not show on his screen.** Mark new words with square brackets and
list the words going out underneath.

## The record

One append, blind: the **ninety-fourth**, `[A]`'s words verbatim with what each answered; the relays are named, not
repeated. **Parent 101,849 w, head 102,754 w.** The parent's bytes were checked unchanged at the join.

## Moved

- To `spent/`: `FINDINGS-job91-20261028.md`, `SET-NOTE-from-job91-20261028.md`.
- To `superseded/`: `BOOK2-20261027.md`, `MANIFEST-job92-20261028.md`, and as `SUPERSEDED__live__`
  `WORD-RULINGS-book2-20261027.md` (letter `o`) and `STYLE-GUIDE-20261027.md` (letter `j`).
- **Kept live:** all nine relays, `RELAY-from-job81-20261027.md` to `-20261027d.md` and `-20261028.md` to `-20261028e.md`,
  for the coherence run to check the changes file against; `FINDINGS-job75-20261005.md` for its Part Four;
  `NOTE-introduction-recognition-20261007.md`, not to be acted on until `[A]` says so.

## What is owed

- **A coherence run on `BOOK2-20261028.md`**, reading `CHANGES-job92-20261028.md`. The burial account changed in session,
  so its tracking check should follow one buried fear from its growth through panic, burial, denial, the layers of fear
  of the fear, and what can still reach it. The claim inventory needs a 10-28 block.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold.
- **The writer 2 pass**, still waiting on Toby Marshall.

## Next

`[C]`'s recommendation: **a coherence run on `BOOK2-20261028.md`.**
