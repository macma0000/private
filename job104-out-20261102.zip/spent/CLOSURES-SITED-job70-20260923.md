# SITED CLOSURES — `Job70 doctrine 09152026`, second and third sittings

Cut 2026-09-23. **Supersedes `CLOSURES-SITED-job70-20260916.md`**, which carried the second
sitting alone. Everything in the superseded file is here unchanged, with the third sitting added.

Site and claim, never the sentence. A drafting session writes the sentences.

**Not applied. Nothing in this file has been carried into any master.**

**What these sittings had in hand:** `BRIEF-for-job70-from-job72-20260916.md`,
`ARC-ACCOUNT-from-job72-20260916.md` and `WORD-RULINGS-book2-20260916.md`. **No manuscript and no
record**, so neither sitting appended the record. The block at the end is for a later session to
append, under the pattern `job34` set for a session appending on behalf of one that could not.

**A warning about the word rulings.** The copy in hand is the 09-16 cut. Sessions have run since,
and `Job74`'s drafting is known to have retired `crossing` and split the phases. **A new lettered
word-rulings file cut from the 09-16 copy would silently drop those changes**, so this file carries
the word ruling as an addendum to be merged instead. That is a deliberate departure from the
brief's instruction to cut the new letter in session.

---

## Two corrections to this session's first sitting, owned

- **Closure 5 of `CLOSURES-SITED-job70-20260915.md`** marked the `attention` reading as not a
  ruling, then said a drafting session *may work from* it. That clause is what let `Job71` apply
  it. A reading a drafting session may work from is a ruling in practice. **No `[C]` reading in
  this file carries that licence.**
- **Closure 3's** *a Five looking with lent motivation has nothing directing the looking* was
  `[C]`'s sentence and is false (`[A]` 09-16). *Can notice what no fear pointed at* stands.

---

# SECOND SITTING (2026-09-16) — where action happens

## Ruled

**An action is placed by the motive behind it.** An action released by going toward something
comes at the enthusiastic phase. An action released by fending something off comes at the
cautious phase. **The same outward act can be either.**

`[A]`'s words:

> "the snapping would be another thought cycle where the desire to end the pain was decided, with
> the snapping occurring at the end of a truncated cycle." would that be the end of a B cycle since
> it's motivated by aversion?

> "desire to be rid of something an aversion" - i don't know. in my case it's definitely an
> aversion, but i have a B fixation. i could imagine an A fixation person thinking "wouldn't it be
> nice if i were rid of something". my guess is that both can happen. i think there is happy
> aggression and angry aggression. i've had experiences of people happily manipulating me.
> snapping, however, is clearly angry.

**What follows.**

- **Aggression is not one kind of action.** Happy aggression — someone cheerfully manipulating
  another person — is going toward, so its action comes at the enthusiastic phase. Angry
  aggression is fending off, so its action comes at the cautious phase.
- **The angry remark in `[A]`'s truncated-cycle example comes at the cautious phase**, where the
  examining is cut short by the remark being released instead. `[A]` proposed the placement himself.
- **The wording of a desire does not decide where its action goes.** *To be rid of something* can
  be felt as fending off or as going toward, depending on the person.

## `[C]` readings — NOT ruled

- **No action belongs to the detached phase**, from the 09-16 ruling that a detached realm
  generates nothing.
- **A cautious action is examining done in the world** — checking, securing, preparing. If so, the
  cautious phase does one job two ways, which answers `Job72`'s worry that it would do two.
- **Ch 15's *if they act, the action begins a new arc inside the decision*** stands: a decision can
  come at the ending, and the decided step's action is released in a later cycle.
- **The 08-25 gun example agrees.** That ruling placed the first urge at the enthusiastic phase;
  this one places the release, which for buying a gun to be safe is the cautious phase.

---

# THIRD SITTING (2026-09-23) — the want for peace, and the boundary of the model

## Ruled

**Detachment carries a standing aversion to disturbance, and the aversion does not come from the
lean.** `[A]`, asked whether a detached person with no lean is the same as a person with no
attraction or aversion at all:

> is a detached person with no leans the same as a buddha with no attractions or aversions. i think
> not and that is new to the book. a detached person is still averse to disturbances while a buddha
> is indifferent to them.

**So the want for peace belongs to detachment itself and is there at zero lean.** `[A]` had been
asked whether that want should be classed as motivation, and `[C]` recommended that it should;
the buddha answer settled where it comes from.

**New to the book, `[A]`'s own words for it, and RULED: a person with no attraction and no aversion
at all is outside the model.** Aversion to disturbance is what makes detachment an orientation.
Take it away and nothing is left that could be called a place a person stays at.

**Where it goes.** `[A]` 09-23: *ok. keep buddha.* Ch 4 says plainly that detachment is not
indifference and that a detached person minds disturbance, with no figure named — the misreading
happens at first contact with the word. The buddha is named once in Part 3, where fixation and
Naranjo are introduced.

**How the word is used.** `[A]` 09-23: *if we leave out the article "the" and use lower case
buddha, i think that names a class of people, not guatama buddha. using the class rather than the
particular man is better.* **Ruled on `[C]`'s recommendation, which `[A]` took: the class is
defined in the sentence, and the word is named second** — *a person who has given up all attraction
and aversion, what buddhism calls a buddha, is outside this model.* Lower case. `[C]`'s reason,
given and accepted: lower case and a dropped article do not by themselves make English read a name
as a class, and a reader who knows the word will otherwise supply a definition the book never gave.

## `[C]` readings — NOT ruled

- **The lean keeps exactly the job the 09-16 ruling gave it** — setting whether an arriving fear is
  processed at the caution end or ignored at the enthusiasm end. The want for peace is a separate
  fact about a detached realm.
- **A detached realm still generates nothing.** Generating means raising new wants about things in
  the realm. A standing aversion to disturbance raises nothing; it meets whatever arrives.
- **The want for peace is why a detached person notices disturbances**, which the book asserts and
  does not account for. The want points the noticing at whatever breaks the peace and at nothing
  else, which is the narrow noticing a detached realm shows.
- **A buddha is not the top of the health axis**, which was ruled to have no top. Outside the model
  rather than high in it.

## OPEN — carried

**Where a detached person's action comes.** Peace is an absence, so a want for peace has no object
to go toward and can only point at what spoils it. On the second sitting's ruling, an action
motivated that way comes at the cautious phase — a Nine smoothing over a conflict would be fending
off. **That needs `[A]`, and `[C]` raised it without pressing it.**

**Panic, and the stress hypothesis.** Panic is a truncated cycle (`[A]` 09-16) and is motivated by
aversion, so panic's action comes at the cautious phase. The 09-15 stress hypothesis described a
panicking cautious person as *acting on an unexamined want*, which places the action at the
enthusiastic phase. **One of them needs revising and it is `[A]`'s to say which.**

---

## The rows

| # | Site | What changes |
|---|---|---|
| 1 | `ARC-ACCOUNT-from-job72-20260916.md` §6, the truncated-cycle case — *the action happens at the ending* | The angry remark's action comes at the cautious phase. The account is not drafted anywhere, so the account is the site |
| 2 | The brief's §3 placement *at the ending* | Superseded by the action ruling |
| 3 | Ch 4, enthusiasm's competence named as *doing* | **NO CHANGE.** Whether Ch 4 should also name fending off as caution's kind of action is not ruled |
| 4 | Ch 4, where detachment is introduced | New: detachment is not indifference, and a detached person minds disturbance. No figure named here |
| 5 | Part 3, where fixation and Naranjo are introduced | New: the class defined in the sentence, `buddha` named second, lower case, outside the model |
| 6 | Wherever the detached realm's wants are described | The want for peace belongs to detachment itself, not to the lean. The lean keeps its own job |
| 7 | The stress hypothesis's *I suspect* sentence, wherever drafted | **OPEN.** Nothing changes until `[A]` rules on panic |

---

## To be merged into the word rulings file — NOT cut as a new letter here

Merge into whatever the live word-rulings file is, since the 09-16 copy in hand is behind
`Job74`'s work.

Under **§2 Orientation, fixation, position**, amend the `lean` entry:

> **Detachment's standing aversion to disturbance does not come from the lean** (RULED 09-23: *a
> detached person is still averse to disturbances while a buddha is indifferent to them*). The lean
> sets whether an arriving fear is processed or ignored, as ruled 09-16.

Under **§7 Register and voice**, or wherever proper names are handled, add:

> **buddha** — RULED 09-23. Lower case, no article, and **the class is defined in the sentence
> before the word appears**. Names a state a person could reach, never Gautama. Used once, in
> Part 3. `[A]`: *using the class rather than the particular man is better.*

Add to the patterns block:

```
buddha | \bbuddh\w* | all | lower case, class defined first, Part 3 only (RULED 09-23)
```

---

## For a later session to append to the record

Append after the record's current last marker. Name the parent count from the marker that session
finds. Write the marker in the canonical bold form.

```
## `Job70 doctrine 09152026` — second and third sittings, appended on its behalf

**Provenance.** `[A]` returned to `Job70` on 2026-09-16 and again on 2026-09-23, both times with
files cut by `Job72` and no manuscript or record in hand, so `Job70` could not append. Blockquotes
are `[A]`'s typing. Everything else is `[C]`'s report.

**2026-09-16, where action happens.** `[C]` recommended `[A]`'s own suggestion — enthusiastic
actions in the enthusiastic phase, cautious actions in the cautious phase — and read the angry
remark in his truncated-cycle example as released at the enthusiastic phase. `[A]` asked what "the
snap" was; `[C]` had shortened his "snapping" without saying so. `[A]` then asked:

> "the snapping would be another thought cycle where the desire to end the pain was decided, with
> the snapping occurring at the end of a truncated cycle." would that be the end of a B cycle since
> it's motivated by aversion?

`[C]` withdrew its placement and proposed that an action is placed by its motive. Asked whether a
desire to be rid of something counts as an aversion:

> "desire to be rid of something an aversion" - i don't know. in my case it's definitely an
> aversion, but i have a B fixation. i could imagine an A fixation person thinking "wouldn't it be
> nice if i were rid of something". my guess is that both can happen. i think there is happy
> aggression and angry aggression. i've had experiences of people happily manipulating me.
> snapping, however, is clearly angry.

**Ruled: an action is placed by the motive behind it — going toward at the enthusiastic phase,
fending off at the cautious phase — and the same outward act can be either.**

**2026-09-23, the want for peace and the boundary of the model.** `[A]` asked whether a detached
person's want for peace should be classed as motivation. `[C]` recommended that it should, and
could not settle whether the want comes from the lean or from detachment itself. `[A]`:

> is a detached person with no leans the same as a buddha with no attractions or aversions. i think
> not and that is new to the book. a detached person is still averse to disturbances while a buddha
> is indifferent to them.

**Ruled: detachment carries a standing aversion to disturbance, present at zero lean, so the want
for peace belongs to detachment itself and not to the lean. A person with no attraction and no
aversion at all is outside the model.** `[A]` called this new to the book.

On naming it:

> if we leave out the article "the" and use lower case buddha, i think that names a class of
> people, not guatama buddha. using the class rather than the particular man is better.

`[C]` agreed about the class but said lower case and a dropped article do not by themselves make
English read a name as a class, and recommended defining the class in the sentence and naming the
word second. `[A]` took the recommendation. Ch 4 says plainly that detachment is not indifference,
with no figure named; the buddha is named once in Part 3.

Sited in `CLOSURES-SITED-job70-20260923.md`.
```
