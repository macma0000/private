# CORRECTION to `CLOSURES-SITED-job70-20260923c.md` — from `Job70 doctrine 09152026`

Cut 2026-09-23, after the coherence run found a contradiction inside the fifth-sitting closures
file. **This is a correction sheet, not a new closures file.** The closures file stays in the set
and keeps its name; three of its statements are wrong and are corrected here. A fourth re-cut of
the whole file in one day would be churn, and the coherence run already has the file loaded.

**`Job70` has no manuscript and no record in this sitting.**

---

## What the coherence run found

The closures file tells the word register that **the lean sets whether an arriving fear is
processed or ignored and nothing else**. The same file says **a detached realm's wants have three
sources: the lean, the person's other realm, and the person's own cycles in the detached realm**.
Those two cannot both stand, and the first one would also silently retire a 09-16 ruling of
`[A]`'s that the register carries.

**The *and nothing else* instruction is `[C]`'s and is wrong.** It was written while striking a
different `[C]` sentence about the lean, and it took away a job the lean does have.

---

## Ruled 2026-09-23 — three corrections

### Wants come from the mental deposits

**Wants are not raised by a realm.** `[A]` 09-12: a process arc has no realm, and a want or a fear
takes the realm of the matter it is about. **So the question is never which realm raises a want.
The question is what a cycle's enthusiastic phase raises a want about, and the answer is the mental
deposits, which were laid down by the person's fixations and their history.**

`[A]` 2026-09-23, correcting `[C]`, who had written of *a Five's own psychic cycles*: **the cycles
apply to the whole, not by realm.**

### The three-sources sentence is wrong in its whole shape

Not wrong in one item. **There are no sources of a detached realm's wants to count, because wants
are not raised by realms.** Strike the sentence rather than reducing it to two sources.

### The lean is not a source of anything

**The lean sets how much attention reaches each phase.** A center nearer the arising means more
wants raised. A center nearer the examining means more fears weighed. Sorting arriving fears into
processed or ignored is one consequence of where the center sits, and the amount of wanting is
another. **Neither is a separate power of the lean.**

**This supersedes `[A]`'s own 09-16 ruling, by `[A]`.** That ruling answered what directs a Five's
looking in the psychic realm when no fear does, and the answer then was *2 is true because
detachment has a lean*. **The answer now is the mental deposits.** `[A]` 2026-09-23 on the Five
noticing someone else's emotional situation: **it depends on mental deposits which were determined
by fixations and history.**

**The register entry *Detachment's lean is a source of a detached realm's own wants* is rewritten,
not removed.** Replacement sense: the lean sets how much attention reaches each phase, so a center
nearer the arising raises more wants.

**What detachment itself does is unchanged**, and is `[A]`'s ruling in the coherence run the same
day: little attention at the arising and little at the examining, so less is raised and less is
settled.

---

## What to merge into the word rulings file

Replace the `and nothing else` instruction from the closures file with this:

> **lean** — the offset of the fixation's center on the cycle. **The lean sets how much attention
> reaches each phase and is not itself a source of wants or of fears** (RULED 09-23, superseding
> the 09-16 entry that made the lean a source of a detached realm's wants). A center nearer the
> arising raises more wants; a center nearer the examining weighs more fears; which of those two a
> detached person does with an arriving fear is the 09-16 processed-or-ignored ruling, and follows
> from where the center sits.

> **wants and fears come from the mental deposits** (RULED 09-23), which were laid down by the
> person's fixations and history. **A want is never described as raised by a realm** — a process
> arc has no realm (RULED 09-12), and a want takes the realm of the matter it is about.

---

## Flagged for the coherence run, not pursued here

**The supplied-motivation account is stated in terms of realms.** The register has *supplies
motivation* as what a non-detached realm does for a detached one. Today's ruling says wants are not
raised by realms and come from the mental deposits. **Those may not conflict** — supplying
motivation is about what directs noticing, not about where a want comes from — **but the two
accounts now use the word `realm` differently, and somebody should check every sentence that says a
realm supplies, raises, or generates anything.**

**`[C]` has twice in one day written of a realm having its own cycles**, which `[A]` corrected both
times. A coherence run should expect the same mistake in the manuscript, since the 09-12 ruling that
arcs have no realm is recent and much of Part 3 predates it.
