# SET NOTE — from `Job97 coherence 20261029`

This note goes to the session that receives `job97-out-20261029.zip`. `[A]` gives the kind of session. The manifest label
carries only the counter and the date: `job98-20261029`.

## Arrival

`job96-out-20261029.zip` verified against `MANIFEST-job97-20261029.md`: 56 ok, 0 mismatched, 0 bad count, 0 missing, 222
not in the manifest, all in `spent/` and `superseded/`. The record's last marker matched `job96`'s note: ninety-eighth
append, 103,915 w. `[A]` named the session `Job97 coherence 20261029`.

**A slip to declare.** At §1.0 this session printed the record's last 3,000 bytes to check the marker, instead of leaving
that to `setcheck.py sweep`. Those bytes are the ninety-seventh and ninety-eighth appends, both written by sessions of this
run's kind from their own exchanges. Nothing from them was used.

## What was done

A coherence run on `BOOK2-20261029b.md` (unchanged, 44,666 w), reading `CHANGES-job96-20261029.md`. **Product:
`FINDINGS-job97-20261029.md`**, and a block appended to `CLAIM-INVENTORY-book2-20260902.md` (now 39,131 w). All five rows
are in the master. **No fault was found.** One claim in the changes file is wrong without harm: the referring-word count fell
between masters rather than staying unchanged. Tracking check run on how a fear comes to be buried and on *a way out*.

## The record

One append, blind: the **ninety-ninth**. **Parent 103,915 w, head 104,064 w.** The parent's bytes were checked unchanged at
the join.

## Moved

- To `spent/`: `CHANGES-job96-20261029.md`, `SET-NOTE-from-job96-20261029.md`.
- To `superseded/`: `MANIFEST-job97-20261029.md`.
- Kept live: `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be acted
  on until `[A]` says so; `FINDINGS-job97-20261029.md`, until a session has read it.

## What is owed

- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master, the 10-05 style guide and register, and a record reach of
  73,080 w. Every session since has worked around it from set notes.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold. The
  record's index of subjects, which the handoff says a doctrine session should build first.
- **The writer 2 pass**, still waiting on Toby Marshall.

For any session that shows `[A]` a change: bold does not show on his screen. Mark new words with square brackets and list
the words going out underneath.

## Next

`[C]`'s recommendation: **a handoff session**, to cut a handoff that names the current master, style guide and register. The
coherence run found nothing to draft, so this is the first clean point since 10-05 to bring the handoff up to date.
