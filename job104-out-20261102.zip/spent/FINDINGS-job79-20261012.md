# FINDINGS — `Job79 coherence 20261010`

Cut 2026-10-12. The session opened 2026-10-11 on `job78-out-20261011.zip` (manifest label
`job79-20261011`) and ran against **`BOOK2-20261011.md`** (40,396 w, md5 `22eca00d`), cut by
`Job78 drafting 20261007`. During the session `[A]` carried questions to `Job70 doctrine 09152026` and
brought back `ANSWERS-for-coherence-from-job70-20261012.md`.

**A drafting session works from two files: this one, and `ANSWERS-for-coherence-from-job70-20261012.md`.**
This file holds every fault this session found in the manuscript and every ruling `[A]` gave here.
The answers file holds `Job70`'s rulings and wording that have no fault site of their own here. Part
Three of this file lists those, with the mark each carries. **Where the answers file and a row here
disagree, the row here wins, because this session held the manuscript.** None disagree at cut.

**Every site was located by content in `BOOK2-20261011.md`, which this session did not edit.** Each
blockquote below is a sentence of that master, checked with `quotecheck.py quotes`. `[A]`'s words
are given in italics and are never put in blockquotes. Neither are `Job70`'s words.

**How the rows are marked.**

- **RULED** — `[A]` said it, and his words are given. Where he ruled by agreeing to a question, the
  question is given with his answer.
- **`[C]` DECISION** — a fault this session recorded without asking, because a ruling already covers
  it. The ruling is named.
- **`JOB70`'S** — from the answers file, with the mark that file gives it.
- **NOT RULED** — a `[C]` reading. Do not act on it without asking `[A]`.

**This session wrote no wording for the book.** Every repair below is a site and a claim. The
drafting session writes the sentence and shows `[A]` the sentences around the change, before and after.

---

## PART ONE — FAULTS IN THE MANUSCRIPT

### 1. Capacity: one sentence still makes capacity belong to a realm

**RULED 2026-10-11.** Asked whether the sentence should be repaired to match the paragraph before it:
*yes*.

The brief's one sweep. Every sentence about how much a person can bear was read against the 10-09
ruling that capacity is one capacity for the whole person. One sentence fails, in the orientations
chapter, in the paragraph after the stress paragraph:

> A person deeply caught in one realm can bear less in the other as well, because being deeply caught is itself hard to live under and hard living is stress.

The reason is right. *Can bear less in the other as well* makes the person bear less in the realm
they are caught in, which is the per-realm reading. Under the ruling, being deeply caught makes events
in that realm hurt more; it does not lower capacity there.

**Checked clean in the same sweep:** the stress paragraphs of the orientations chapter; the cycle
chapter's *the more of what the step requires they can bear* (an amount of a load, not a capacity);
*cannot easily bear what the next phase would bring*; the job example in *The range of detachment*,
which states the ruling exactly; the four fates; the climb in the health axis chapter; and in the last
chapter *What falling takes from capacity*, the pain of staying, the intervener passage and *a person
with a little less buried can bear the next part*.

### 2. Whether turning away is learned: two chapters contradict each other

**RULED 2026-10-11.** Asked whether the last chapter is right — the capacity to turn away is not
learned, and only the turning away from particular painful thoughts is laid down, one burial at a
time — so that the two sentences in *Blocking is not a decision* are at fault: *yes*.

At fault, in *Blocking is not a decision*:

> The failure to notice is automatic rather than chosen, and it was learned rather than designed.

> The move had to be learned at a time when the anxiety still *was* felt, at least half-consciously, at a stage before there were words for any of it.

and the sentence after it, which depends on it:

> By the time there were words it was already running by itself.

Right, in *What is actually being undone*:

> Nobody learned the capacity to turn away, and everyone has it.

**Note for the drafting session.** The same paragraph's last sentences already state what a burial
lays down and stay. `Job70`'s ruled account of burial as gradual (answers file, item 5) is drafted at
*What previous thoughts have laid down*, and the repair here should not restate it.

### 3. `range`: one sentence is unclear in context

**RULED 2026-10-11.** Asked whether `range` should be kept for the range of detachment only: *i don't
mind if range is used in two different senses as long as it's clear in context.*

So the health axis keeps its uses of `range`. **`[C]` DECISION**, applying his test: one sentence
fails it. In *The two ends, and what lies between them*:

> The top and the bottom of this axis are its two extremes, and its middle, the point of no lean at all, is nearly unoccupied.

*Its middle* reads as the middle of the health axis. The intended sense is the middle of the range of
detachment, which is pure detachment. Read the first way, the sentence contradicts *Why this does not
take everyone to the bottom*:

> Most people sit somewhere in the middle of the range and stay there for decades.

**Passes his test, and stays:** *what changes down the range*, *a bounded range*, and *the middle of the
range* in *Rising*.

### 4. `pulls` replaces `draws` everywhere

**RULED 2026-10-12.** After `Job70`'s regularization to `draws` (accepted 10-09), and asked what
replacing `draws` with `pulls` everywhere would involve: *ok to replacing draws with pulls
everywhere.* **This reverses the 10-09 regularization.** One verb, `pulls`, names what a want or a fear
does to a person's noticing and how hard; *the harder* carries the strength. The book's nouns are
already *pull*.

**Sites where `draws` does the job — change all seven sentences:**

> A want or a fear draws a person's noticing toward what the want or fear is about.

> Sometimes a want or a fear draws a person's noticing toward one thing.

> While nothing is disturbing the person, wanting peace draws the noticing nowhere.

(the last occurs twice: in the orientations chapter and in *The range of detachment*)

> The whole realm is open to noticing when nothing draws a person's noticing toward what a want or a fear is about.

> But a want or a fear has to draw a person's noticing before any noticing happens.

> When something does disturb a detached person, wanting peace draws the noticing — toward what is disturbing the person, or toward getting away from it.

**Sites where `point` does the same job — RULED 2026-10-11.** Asked whether these three should be
brought into line with `draws`: *yes*. Under the 10-12 ruling the verb is `pulls`:

> A Five also may notice things in the psychic realm that no fear pointed at, such as someone else's emotional situation.

> Every fear a Six has raised gets looked into, and the looking goes where the fears point.

> What a Six does not notice is anything no fear pointed at.

**Leave alone** — `drawn` and `draws` in other senses: the enthusiasm definition's *Drawn toward what
attracts*, the Three's *Drawn toward whatever is in front of them*, the cycle chapter's *something draws
the person back into wanting*, *not being drawn into what troubles other people*, *drawn from that*,
*drawn independently*, and every use about the figure. **The definition of detachment, *nothing pulls
their noticing toward anything in particular*, already agrees and does not change.**

**Owed to the register:** letter `g` carries this (see the set note).

### 5. Disappointment is not a kind of aversion

**RULED.** `[A]`, 2026-10-11, asked whether disappointment is a kind of aversion or a pain:
*disappointment is neither. disappointment is an acceptance that what was desired cannot be had.*
**His second sentence is superseded**, in his own words relayed by `Job70`: *acceptance is one possible
fate of disappointment.* What disappointment is, `[C]`'s wording, which `[A]` accepted (*i accept your
account*): a disappointment arises when a want has been met by an outcome that cannot satisfy it. How
it comes about where an aversion had been raised, `[A]`'s idea, agreed with `Job70`: the disappointment
is what is left when the aversion about the outcome is given up. **`Fear and disappointment meet the
same four fates` stays** (answers file, item 1).

At fault, in *Disappointment*:

> Disappointment is another kind.

The sentence before it, *A fear is one kind of aversion*, stays.

### 6. The shoelace is two thoughts, not one

**RULED 2026-10-11.** Asked whether the broken lace counts as an outcome under the new definition:
*two thought cycles. first is attempting to tie and discovery of broken lace. fate is giving up - the
shoe cannot be tied. second is dealing with broken lace. it needs to be fixed somehow this raises the
aversion, disappointment which meets its fate. if it's acceptance (giving up on feeling of aversion),
the next cycle might be deciding to tie the broken pieces together.*

At fault, in *Disappointment*, the first of the two ways a want disappoints, which has the examining
judge ahead of any attempt:

> A want disappoints when the examining judges that the want cannot be met.

> Looking at the want, the person judges that the lace cannot be tied.

> The examining raises a disappointment.

and the sentence placing both ways in one phase:

> Disappointment belongs to the cautious phase both times.

Under his account the attempt is the outcome. The first thought ends with the want to tie the lace
given up. The disappointment is raised in the second thought, about the broken lace.

**Where this meets item 5.** His *the aversion, disappointment* is the aversion about the outcome, and
the disappointment is what is left when that aversion is given up (answers file, item 1). The two
agree.

### 7. The four fates are written for a fear

**`[C]` DECISION**, a census `Job70` asked for, under the ruling that fear and disappointment meet the
same four fates. Each entry in *The four fates* has to work for a disappointment, where there is a want
and no fear. **All four need generalizing:**

- *Worked through*:
  > The want behind it ends by being met, not relinquished, which is why nothing is left over and nothing has to be put anywhere.

  A disappointment worked through may end with the want revised. A revised want is neither met nor
  relinquished. (`Job70`'s wording for *nothing is left over* is in the answers file, item 4.)
- *Given up on*: *the want behind the fear is dropped, and with the want gone the fear is gone with it.*
  For a disappointment it is the disappointment that goes. (See item 8 for what remains.)
- *Ignored*: *the next time the problem is met the want is raised again, and the fear is raised with the
  want.* For a disappointment, the want comes back with no fear.
- *Blocked*: *Blocking happens only to a fear the person cannot bear.* As written, this rules out
  blocking a disappointment, though the orientations chapter names disappointment as what an
  enthusiastic person cannot easily bear.

**The frame is written for a fear too.** Seventeen sentences name the fates (counted
case-insensitively on word boundaries). Every one speaks of a fear except *Fear and disappointment
meet the same four fates*. (`Job79` told `[A]` *sixteen … all but one* on 10-11; the recount is
seventeen, sixteen of them about a fear.) They include the heading *Where a fear
meets its fate* and all three sentences under it, *At the ending the fear meets one of the four fates*
in *One thought, step by step*, the opening of *The four fates*, the definition of **unattended**, the
health axis chapter's basic-fear paragraph and the opening of *Where a level change can happen*, and
*Rising*'s *the same comparison that decides a fear's fate*. **The drafting session decides how far the
frame needs generalizing.** Many of these sentences are about fears and are right as they stand.

### 8. Regret: giving up does not always leave one

**`[C]` DECISION**, a census `Job70` asked for, under `Job70`'s account of regret (answers file, item 2:
`[C]` wording, `[A]` accepted). Giving up a want sometimes leaves something behind. It is a regret where
the person could have acted otherwise, and a disappointment where they could not.

No use of `regret` does a disappointment's work through its example. **All four say giving up always
leaves a regret**, and need the account above:

> The fear can be given up on, and a regret is left behind.

> Or it can be given up on — surrendered to — and what is left afterwards is a regret rather than a fear.

> What remains is a regret, and a regret is not a fear.

The fourth changes in substance. In the paragraph after the four fates:

> Within that one pairing the difference is how the want ended — met in the one case, let go unmet in the other — and the regret is the mark of it.

If giving up can leave a disappointment or nothing, a regret no longer marks every case. The
difference the sentence names, met or let go unmet, still holds. **The account is stated once, at the
*given up on* entry.** The other three are brought into line with it and do not restate it.

### 9. `looked at`: one use is at the wrong stage

**`[C]` DECISION**, under the 10-06 ruling that `look at` is ordinary English for attending to something
already noticed. The six uses `Job70` named were judged one at a time. One fails, in *The lean in
detachment is not like the others*:

> Leaning back toward caution, detachment keeps the realm in view; leaning forward toward enthusiasm, it has already turned toward what attracts, and what would disturb that is not looked at.

At the enthusiasm lean the turning away comes before the noticing. The failure is at the noticing,
not the attending.

**The other five stay:** the cautious person's *the trouble gets looked at*; the Three's *a result that
did not work is looked at*; the backward passage's *hazards simply no longer looked at* (carelessness,
no claim about stage); *how the same matter looked at the time* (not the phrase); and the intervener's
*what arrives can be looked at*.

---

## PART TWO — CHECKED, AND CLEAN

- **`grab`** — no use. **`brake`** — only the Three's *without brakes*, which stays.
- **Panic** — the definition in *Action without a full thought* survived, and the four load-bearing uses
  stand on it.
- **`allowed to notice / know`** — no use. The Six's *reassurance that arrives is allowed to stay* is
  ordinary English: the Six lets it stay.
- **`range` in the chapter on how the grip loosens** — none.
- **`fire`** — one use, *keep moving under fire*, ordinary English.
- **`aversion`** — five uses, read against the general sense. Only *Disappointment is another kind*
  fails (item 5). The Part 3 opener's *all attraction and all aversion* needs the general sense and has
  it.
- **`arhat`** — the register has carried `arhat` as RULED since 10-05 (`Job76`). The brief's open item is
  closed. `Job70`'s answers file records `[A]` confirming it on 10-11.
- **The orientation definitions in Part 1** — not reported, as the brief instructs.

**The tracking check was run on disappointment**, from where it is raised, through its fates, to what
it leaves (items 5 to 8). It was not run on motivation as a whole.

---

## PART THREE — FROM `ANSWERS-for-coherence-from-job70-20261012.md`, FOR THE DRAFTING SESSION

Each item has no fault site in Part One, or has more than its site there. The marks are `Job70`'s.
The answers file is the authority for wording.

- **Item 3, what a thought leaves.** `[A]` proposed it and `Job70` *recommends taking it*; the file gives
  `[C]` wording and no words of `[A]`'s accepting the wording. **Put it to `[A]` in one line before
  drafting.**
- **Item 4, working through.** `[C]` wording for the entry. It pairs with item 7 above.
- **Item 5, burial is gradual.** **RULED by `[A]`**, with `[C]` wording `[A]` approved. It replaces the
  paragraph at the end of *What previous thoughts have laid down*. **`[A]` withdrew his 10-06 addition**
  that nothing is blocked in the first cycle; no session applies it.
- **Item 6, the held sentence.** It splits: one half goes before the stress paragraph in the
  orientations chapter, the other extends the burial account. The placement is `Job70`'s; the file
  records no words of `[A]`'s on it. **Put it to `[A]` in one line before drafting.** *Near the same
  matter* becomes *about the same matter*.
- **Item 7, the unease loop.** No ranking of the orientations. It belongs to the unease-loop sitting and
  is not drafted here.
- **The two 10-10 rulings** — trained abiding acting on the feeling of fear, and material laid down
  before a person had words. **Not for the next drafting session.** `[A]` agreed on 10-12 (*ok*) to
  move them into the unease-loop job, because they belong in *Rising* beside the exit Job70 names for the
  unease loop. Stated in §6 of `BRIEF-for-coherence-from-job70-20261011.md`.

---

## PART FOUR — OPEN, AND NOT FOR A DRAFTING SESSION

- **The unease-loop material** is in the set as `DOCTRINE-ONLY__NEW-MATERIAL-the-unease-loop-20260923b.md`,
  for the doctrine sitting the set note names. A drafting session does not open it. Gaps where it would
  go are deliberate.
- **`NOTE-introduction-recognition-20261007.md`** — not acted on until `[A]` says so.
- The doctrine items carried in `SET-NOTE-from-job78-20261011.md` and `FINDINGS-job75-20261005.md` Part
  Four.
- **The writer 2 pass** is still needed, and still waiting on Toby Marshall.
