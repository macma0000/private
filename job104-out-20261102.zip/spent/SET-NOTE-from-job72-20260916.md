# SET NOTE — from `Job72 coherence 09152026`, 2026-09-16

To the session receiving `job72-out-20260916.zip`.

## What this session did

A coherence run on `BOOK2-20260915.md`. **The manuscript was not touched** — `BOOK2-20260915.md` is
byte-identical to what arrived, md5 `60a65b20`. Sixteen items are in `FINDINGS-job72-20260915.md`,
each one either `[A]`'s ruling with its sites, or a question left open.

Arrival: `setcheck.py verify` — 90 ok, 0 mismatched, 0 bad count, 0 missing, 2 not in the manifest
(the two `superseded/` files Job71's note declared). Screen fired twice, both expected. **The author
record was carried unread and appended blind.**

## Three new files, and one of them changes how a drafting session works

1. **`WORD-RULINGS-book2-20260916.md`** — the register of every standing word ruling, with dates and
   `[A]`'s own words, cut at his instruction after he said *the latest drafting sessions have done a
   lot of damage. something wrong is happening.* **A drafting session reads it with the style guide
   before writing any prose, applies only entries marked RULED, and asks before acting on anything
   marked `[C]`.** A new word ruling goes into it in the session that gets it.
2. **`wordcheck.py`** — reads the patterns out of the register and lists every sentence in the
   master that uses a governed word. `python3 wordcheck.py BOOK2-<date>.md`. Run it before closing
   any drafting session. It flags; it does not decide.
3. **`ARC-ACCOUNT-from-job72-20260916.md`** — `[A]`'s new account of how a desire and a fear live
   across thought cycles, settled with him in this session against five collisions with the book.
   **This wants a whole drafting sitting of its own.**

## Why the register exists

Job71 applied an unruled `[C]` reading from Job70's closures file and thereby reversed `[A]`'s
09-12 ruling that `attention` replaces `time` and `dwell`. The ruling was recorded only in a
repairs file from two sessions earlier. The register is the fix; the rule that only RULED entries
are applied is the other half of it.

## The set is smaller

Forty spent files moved to `spent/`, listed in `spent/SPENT-NOTE-20260916.md`. Nothing was
deleted. Every doctrine note, both architecture files, the style guide, the referring-word rule,
the vocabulary instruction, the claim inventory, the book 1 files, the figures and the scripts
stay.

## The two folders the manifest does not cover

`setcheck.py verify` against `MANIFEST-job73-20260916.md` reports **55 ok, 0 mismatched, 0 bad
count, 0 missing, 43 not in the manifest**. The 43 are the two folders and nothing else: `spent/`
(41 files, this session's, including its note) and `superseded/` (the parent master and its manifest,
Job71's). Both are declared here, so a receiving session expects them.

## What the next session should be

`[C]` recommendation, `[A]`'s to assert: **a handoff session.** `HANDOFF-20260906.md` is ten
sessions old and 76,495 w, its record-reach line has been wrong since Job61, and it knows nothing
about the register, the arc account or today's rulings. Then a drafting session for the arc
account, and then a drafting session for the rest of the findings.

## What is owed, in the findings file

- Ch 4, Ch 5, Ch 7, Ch 13, Ch 14, Ch 15 and Ch 17 sites for today's rulings, each sited by content.
- Ch 15's `I assume` site, with `[A]`'s own wording approved verbatim.
- Ch 13's *The imaginary self*, reordered, approved verbatim.
- `judgment` for `judgement` at four places.
- The claim inventory carries a 09-16 section saying which of its entries today's rulings make
  stale. **It was not re-read entry by entry.**
