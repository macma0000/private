# DOCTRINE BRIEF — the two stages of seeing, and `intuition`

**Cut 2026-09-06 by `Job49 doctrine 09052026`, after that session's work was already delivered.**
`[A]` returned with an observation while a later session was folding. It is doctrine, so it was
neither ruled nor written here.

**NOTHING IN THIS FILE IS RULED.** `[A]` proposed; `[C]` checked it against the drafted books and
against ruled material. He has not been asked to rule any of it. The questions at the end are what
a doctrine session should put to him.

**FOR A DOCTRINE SESSION. A folding session carries this file forward and does not act on it.**

**STALE SITES.** Line numbers are against `BOOK2-20260905.md` and `rev2-0814t.md`. If `Job50`
applied `CLOSURES-SITED-job49-20260905.md`, both masters have moved. **Locate every site by
content, not by number.** Quotations are exact as of those two files.

---

## 1. What `[A]` reported

He described his own experience of seeing, in the realm where he is detached. His words, close to
verbatim:

- What he sees is not in words and is not something he can think about. It is felt, and put into
  words afterwards.
- It happens instantaneously, like sight. **Putting it into words or concepts takes deliberate
  processing.**
- It also feels like **reaching into darkness, bringing something back, and only then being able
  to see what it is.**
- He offered *knowing without thinking* as another name for it, and said this is probably what is
  called intuition.

**This is first-person testimony from a person detached in one realm.** Almost everything either
book says about detachment was derived rather than observed. That is why it is worth a brief.

## 2. The proposal: seeing has two stages, and only the first is immediate

`[C]` reading, offered to `[A]` and not disputed by him. His two descriptions — instantaneous, and
reaching into darkness — are not in tension. They are two stages, and the seam is already in ruled
material.

**The 08-29 knowing profiles have it:** *Z sees the whole but attends only to parts.* Put that
beside book 2 line 1069 — *A detached person takes a realm in whole, and takes it in directly — not
assembled out of pieces, but seen as it is* — and the structure follows.

- **The taking-in is whole and immediate.** Nothing is assembled; nothing is inferred.
- **The attending is what picks anything out of it**, one part at a time, and it is work.

**So the darkness is not an absence of light.** The whole thing is present the moment it arrives.
Nothing in it has been attended to yet, so nothing in it is anything in particular yet. What is
brought back becomes identifiable when attention goes to it.

### What this explains that is currently unexplained

**`seeing` is one word on two operations, and the strain shows at the sites where the book has had
to work around it.**

- Book 2 line 1069 ends: *What is seen is the same at either end of the range. What differs is how
  much of it the person is allowed to know.* That sentence exists because seeing and knowing had
  to be pulled apart and there was no vocabulary for it.
- **The seeing/knowing naming question has been open since 08-27**, with `know` standing as a
  precedent at one site and no ruling. If the operation genuinely has two stages, that is why one
  word keeps failing and why a substitution at one site never generalizes.

**This bears on `[A]`'s siting of ignoring at Z+, and should be checked against it before anything
is written.** That ruling turns on a Z position choosing comfort over fear — an act on material
that is present. Two stages make that sharper: the material arrives whole, and the choosing happens
in the attending. It should not be assumed to fit; it should be checked.

### What it corrects in the drafted sketches

The Chapter 5 additions lean passive — *the world arrives undistorted*, *stepped back*, *nothing is
pulling at them*. `[A]` is describing something **active**: reaching.

Both are true and the ruled definition already reconciles them — attending is something a person
does, not a place they stand, per book 2's Chapter 4 closing paragraph. **Stepped back means
nothing in the realm is pulling; it does not mean the person is doing nothing.** A reader of the
sketches would not get that, and if the two-stage account is ruled the sketches are where it will
be felt.

## 3. `intuition` — small, separable, and nearly free

**Book 1 already carries the argument in full, at line 1440**, in the typing chapter: *Intuition,
not inference, is the right approach*, because the psychic realm barely shows in conduct while
reading others' inner states directly is what intuition evolved doing; and because much of what
anyone knows about persons was learned before language, *closed to the checklist, which runs on
concepts, and open only to intuition, which does not.*

**The same paragraph already binds the word to Z−:** *Typing-by-checklist is itself a B move…
Direct seeing is a Z− act — clear, dispassionate, uninvested.* So book 1 has already made
`intuition` the name for Z− seeing, in the one place it needed it.

**Book 2 does not use the word once**, while running nine sketches that turn on what a detached
realm sees, with no word for what that is like from inside.

**`[C]` recommendation: this is separable from the two-stage question and much smaller.** It can be
taken without ruling anything about stages. *Closed to what runs on concepts, open to what does
not* is `[A]`'s knowing-without-thinking, already written.

## 4. The unconscious — `[C]` recommends against, and the reason is internal

`[A]` proposed that Z is similar to the unconscious, *maybe only similar but accessible in a way*.

**The word is already spent in both books, and on the opposite face.**

- Book 2 line 1067 / book 1's twin: a doubly detached Nine leaning one way sees with concerned
  clarity, and the same Nine leaning the other is *unconsciously but militantly blind*.
- The maintenance loop is *reinforced each time it runs, by a second recognition — also
  unconscious*.
- Book 1 line 1380: *The orientations are fixations while they are unconscious; direct awareness as
  a fixation — not moving to a better orientation — is what loosens their hold.*

So in this model **unconscious names what a person cannot get at**, and detachment's two faces are
separated by exactly that. Naming the whole orientation the unconscious puts one word on the seeing
face and the blind face at once — the two things detachment's account most needs kept apart.

**Second collision, independent of the first.** What already occupies the unconscious's place is
the **mental deposits** — `[A]`'s own 08-30 words, that behind intention are deposits and from
inside it looks like free will. Everyone has deposits, in both realms, whatever their type. If Z
were the unconscious, a person's unconscious would sit in one realm and depend on their type.

**What survives, and `[C]` believes it is the whole of what he meant:** something arrives already
formed, without having been reasoned to, which is why it feels like material from somewhere out of
sight. The model's answer is that it did not come from out of sight — it was taken in whole and
directly, and what has not happened yet is the attending. **Immediate is not hidden.**

## 5. What should NOT be written

**Not the reaching, and not the darkness.** If the two-stage account is ruled, the book needs the
structure and not one person's inner sense of it. A book that reports how an orientation feels from
inside invites every reader to check their own against it, and a reader who does not recognise the
description will conclude they have the wrong type.

**Also: *reaching into darkness and bringing something back* reads as retrieval — from memory, or
from the unconscious.** Neither is in the model and the second is the borrowed claim rejected
above.

## 6. Raised in the same exchange, and a separate finding

**`[A]`: this is *using the tools of an orientation on one realm in the other realm with a
different orientation*, and *we've seen that in the one and eight already*.** He is right, and the
books have it three times.

| Site | What is there | Verdict the site gives |
|---|---|---|
| `BOOK2` line 581, the Eight | *it is the unwatched realm that supplies the principles which invade the other one* … *a fortress working exactly as designed, in the wrong realm* | a fault |
| `BOOK2` line 397, the One | *Carry that measure into the physical realm … and the result is a standard that cannot be met by anything.* Perfectionism named as the result | a fault |
| `BOOK2` line 467, the Four | *the mode they bring across is understanding* … *translating what they understand inwardly into something that can be shown, made, or explained* | a gift |

**The mechanism is drafted three times. The general claim is stated nowhere**, and neither is what
decides whether the crossing helps or harms.

`[A]`'s own report is a fourth instance and lands on the gift side — psychic sight rendered by
physical caution, which he described as a competence.

**Two candidates, and `[C]` did not choose between them.** It could be **direction**: the Four and
`[A]`'s case both carry a tool *toward* a detached realm's sight, giving it something to be
rendered into, while the One and the Eight carry a tool toward a realm that already has its own
business. Or the crossing is always a fault and **the Four is an unexplained exception**.

**Connection `[A]` partly declined.** `[C]` noted this may be one thing with the 09-06 aligned-types
finding, where a person carries one set of rules across both realms because their move is invisible
to them as a move. **`[A]`: the aligned case is less interesting, since the tools of the
orientation are the same in both realms.** Recorded as his; the unification is not ruled out, only
set aside.

## 7. Questions for the doctrine session to put to `[A]`

1. **Does seeing have two stages** — a whole taken in immediately, and an attending that picks
   parts out of it — as a claim about the orientation rather than about his own experience?
2. If it does, **is that what the seeing/knowing naming question has been failing on since
   08-27**, and does it change the answer there?
3. **Does the two-stage account fit the siting of ignoring at Z+**, or does it disturb it?
4. **Take `intuition` into book 2?** Separable from all of the above.
5. **What decides whether a tool carried into the other realm is a gift or a fault?** Direction, or
   is the Four an exception?
