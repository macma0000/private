# SET NOTE — from `Job99 doctrine 20261029`

This note goes to the session that receives `job99-out-20261030.zip`. `[A]` gives the kind of session. The manifest label
carries only the counter and the date: `job100-20261030`.

## Arrival

`[A]` named the session `Job99 doctrine 20261029` and sent the handoff alone first; the set came with his second message.
`job98-out-20261029.zip` verified against `MANIFEST-job99-20261029.md`: 55 ok, 0 mismatched, 0 bad count, 0 missing, 229 not
in the manifest, all in `spent/` and `superseded/`. The screen marked the record carry, do not read; its other 43 hits were
names in `superseded/`. The record's last marker matched `Job98`'s note: hundredth append, 104,279 w. The label's counter
agreed with his.

## The job `[A]` set

*examine the connections between the topics both at the paragraph to paragraph level, between sections, chapters and overall.
also consider that i want to add introductory paragraphs to the chapters and sections that preview what the reader will see.
and think about whether and how we can have a kind of glossary for the vocabulary we have chosen for each chapter.*

So this session did not build the record's index of subjects that the 10-29 handoff recommended. It is still owed.

## What was done

`BOOK2-20261029b.md` read through, with the style guide and register; the record searched, not read through. The examination
went to `[A]` one piece at a time, and he ruled throughout. **Products:**

- `FINDINGS-job99-20261029.md` — the examination (whole book, between chapters, between sections, paragraph to paragraph,
  openings, glossary), and under *Rulings in this session* every answer of his, verbatim, with what it settles.
- `PROPOSED-ORDER-job99-20261030.md` — chapters and section titles in the proposed order, every change marked. **One change is
  ruled: the new chapter *What Becomes of a Fear*.** The rest is `[C]`'s, shown to him whole.
- `CLOSURES-SITED-job99-20261030.md` — site and claim for everything ruled, in Parts A to G, with a recommended order of work.
- `STYLE-GUIDE-20261030.md` (letter `m`) — the openings; the general *we* (owed since `job96`); the letters in Part 3.
- `WORD-RULINGS-book2-20261030.md` (letter `q`) — *settled*, *mixed*, the letters, the facing side, *the pain of life not
  working*, fear and pain, *game*, the title *New words in this chapter*; the author's-voice entry marked superseded; five
  patterns, each firing on this master at its sites.

**Ruled, in short:** Part 3's two subjects, for its opening; the new chapter; openings that name what is coming as things about
people; a glossary at the back and a *New words in this chapter* section after each chapter's opening, in connected sentences
and the chapter's own order; *settled*, *mixed*, the contest paragraph cut; *the pain of life not working* kept and brought up
earlier; the facing side reworded to say what is feared; fear and pain described together; his cause-and-effect point; and in
Part 3, every phase and fixation with its letter in brackets after the words, piloted on one section first.

**Found under a ruling already given:** *Aligned and non-aligned* still carries the reason he ruled wrong on 09-06.

## The record

One append, the **hundred-and-first**: all of `[A]`'s words in the session, verbatim, each with what it answered, and `[C]`'s
report, including its errors. **Parent 104,279 w, head 106,615 w.** The parent's 621,382 bytes were checked unchanged at the join.

## Moved

- To `spent/`: `FINDINGS-job97-20261029.md` (read by this session; it found no fault), `SET-NOTE-from-job98-20261029.md`.
- To `superseded/`: `MANIFEST-job99-20261029.md`; `SUPERSEDED__live__STYLE-GUIDE-20261029.md` (letter `l`);
  `SUPERSEDED__live__WORD-RULINGS-book2-20261028.md` (letter `p`).
- Kept live: `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be acted on
  until `[A]` says so; `HANDOFF-20261029.md`, which is now behind on the style guide and register letters, the session list
  and the open list — this note and the closures cover the difference.

## What is owed

- **To drafting sessions:** `CLOSURES-SITED-job99-20261030.md`. `[C]` recommends three, each followed by a coherence run:
  structure, words and repairs (its Parts A to D); the letters in Part 3, pilot first (Part G); then the glossary working
  file, the openings and the *New words in this chapter* sections (Parts E and F). A drafting session reads style guide `m`,
  register `q` and the referring-word rule first, and must not open the record.
- **Ask `[A]`** what Relational Dynamics' *This describes a small number of people* means (closures D6), and before drafting
  any section summary, since he may write them himself.
- **For a doctrine session:** the record's index of subjects; the backlog at the handoff's §6.1.
- **For a tools session, optional:** `wordcheck.py` has no Part-3 scope, so it cannot flag a bare letter in Part 3 under the
  new rule; a drafting session greps for it by hand.
- **Still waiting:** the writer 2 pass, on Toby Marshall; the Introduction on recognition, on `[A]`.

For any session that shows `[A]` a change: bold does not show on his screen. Mark new words with square brackets and list the
words going out underneath.

## Next

`[C]`'s recommendation: **a drafting session on Parts A to D of the closures** — the reorder, the ruled word changes, the
doctrine additions and the repairs. The kind is `[A]`'s to say.
