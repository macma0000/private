# SET NOTE — from `Job61 coherence 09092026`, 2026-09-09

## What arrived

Zip `job60-out-20260909.zip`, verified against `MANIFEST-job61-20260909.md`:
**64 ok / 0 mismatched / 0 bad count / 0 missing / 2 not in the manifest.**

The two extras were `SUPERSEDED__live__RULE-referring-words-20260908.md` and
`SUPERSEDED__live__STYLE-GUIDE-20260908.md` in `superseded/` — the quarantined parents of the two
files the set carries at the `b` letter. Benign, and **undeclared in Job60's set note for the
second set running.** Following the 08-31 practice, they are not carried forward; they stay in
Job60's directory.

Screen fired three, all benign: the handoff quoting the restriction string, and the two
quarantined files by their prefix. `AUTHOR-RECORD.md` fired CARRY DO NOT READ as it should.

Record arrived **53,036 w, forty-first append, marker `Job60 drafting 09092026`, parent 51,378** —
agreeing with what Job60 received. Chain clean.

## What this session did

Kind 12, the fifth coherence run. The tracking check on **fear**, following the word from where it
is raised, through the crossing, to burial, and reading Job60's new prose in Ch 15 and Ch 17
against the rest of the book.

**Ten items found, all ruled by `[A]` in the same session, all owed prose.** They are in
`REPAIRS-job61-20260909.md` with sites and proposed wordings, and summarised as faults 34–43 in
the claim inventory.

**`BOOK2-20260909.md` is byte-identical to the copy that arrived**, and so are book 1 and every
note. A kind 12 session writes nothing into the book.

## Files cut

- **`REPAIRS-job61-20260909.md`** — the ten repairs plus two additions of `[A]`'s content, for the
  drafting session that follows. Everything in it is ruled.
- **`NOTE-doctrine-from-job61-20260909.md`** — the session's unruled material, and it is large:
  the three wants behind the basic fears, `[A]`'s decoding of all nine of Riso and Hudson's basic
  fears with the fear wordings quoted by him, the basic desire settled as the want itself, the
  inversion mechanism for a detached realm, the contagion question, the larger-peace claim, the
  bodhicitta correspondence at register 3, and his newest idea — a feeling carried across without
  its content. **A drafting session must not write from it.**
- **`CLAIM-INVENTORY-book2-20260902.md`** — grown 23,010 → 23,821 w, **name kept deliberately**,
  following `Job57`'s precedent. This is the third run to note that the
  different-bytes-different-name rule has no exception for the inventory and that
  `[C]`'s recommendation to mint one is still unruled.

## Record

**FORTY-SECOND APPEND, blind** — this kind does not read the record. Head is now **55,730 w, md5 `60c024f2`**, marker `2026-09-09 · Job61 coherence 09092026`, parent 53,036 named
in the block. First **313,460 bytes verified byte-identical** to the parent; **54 markers** where
there were 53; canonical bold marker form, so the sweep can read it.

The block quotes `[A]`'s typed words throughout and marks everything else as `[C]`'s report.

## Recurring defect, fourth run running

**The handoff's kind 12 row still names `BOOK2-20260902b.md`** — four masters back — **and still
does not name `CLAIM-INVENTORY-book2-20260902.md` in its set at all**, the file the kind cannot
run without. The set again carried far more than the row names. A handoff session should fix the
row; no coherence session has been able to.

## Next

**`[A]` chose the kind: drafting.** The manifest label carries the counter and date and no job
kind, the kind being his to assert.

**Ordering constraint for the drafting session.** Repairs 2, 3 and 10 are one account seen at
three places — the three layers, the competence, and the deleted sentence — and Ch 4's rule
paragraph should be written first, since Ch 5's Nine and Ch 15's range section both then rest on a
form of words that already exists. Repairs 1, 5 and 10 all land on Ch 15's dwelling paragraphs and
are one job.

**Queued behind the repairs and not interchangeable:** `[A]`'s cautious-realm observation from
09-08, still unaccounted for in book 2; and the 113 referring-word sites, which should not share a
session with anything.
