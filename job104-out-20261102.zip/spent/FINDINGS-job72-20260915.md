# FINDINGS — `Job72 coherence 09152026`

Coherence run on `BOOK2-20260915.md` (37,380 w, md5 `60a65b20`). No drafting. Each item is either
`[A]`'s ruling, quoted, with the sites a drafting session applies it at, or a question left open.

Arrival: `setcheck.py verify` — *90 ok, 0 mismatched, 0 bad count, 0 missing, 2 not in the
manifest* (the two `superseded/` files, declared by Job71's set note). Screen fired twice, both
expected (record CARRY DO NOT READ; handoff quoting the restriction string). Record carried unread.

## 1. `dwell` goes; `attention` comes back — `[A]` 2026-09-15, RULED

Job71 applied Job70's unruled closure 5 and replaced `attention` with `dwell` / *how long* at the
detached-phase sites. That reversed `[A]`'s 2026-09-12 ruling (`REPAIRS-job66-20260912.md`,
Repair 2: *i think time means attention. attention is probably more accurate and time a poorer
metaphor* / *dwell is just a synonym for time*). Asked this session, `[A]`:

> dwell isn't good. attention is better.

**Apply at every `dwell` site in book 2 except Ch 2's quoted profile line** (*I choose not to dwell
in what's heavy*, ordinary English inside a type's self-description). Locate by content:

- Ch 15, *The range of detachment*, the paragraph opening *A fear travels with the process that
  raised it* — two sentences (*dwells longer at the caution end*; *dwells mostly at the enthusiasm
  end and only briefly at the caution end*). The 09-14 text had *gives the caution end more
  attention* / *gives most of their attention to the enthusiasm end and little to the caution end*.
- Ch 15, same section, *A person whose fixation is enthusiastic or cautious dwells only briefly at
  the enthusiasm end of the detached phase.*
- Ch 15, *Which fixation handles a fear* — *how long a person dwells at the crossing*, *dwells at
  the crossing longest*, *dwells at the crossing only briefly*, *how long a person dwells at the
  caution end*, *dwells longer at the caution end*, *dwells there more briefly*, *dwells only
  briefly at both ends of the detached phase*. The *how long* wording goes with `dwell`.
- Ch 15, *The four sketches*, Z+ — *dwells only briefly at the caution end of the detached phase*.
- Ch 17, *What actually descends*, paragraph opening *Where the person's fixation sits in the realm
  the fear* — *dwells longest at the caution end*; *dwells only briefly at the caution end*.

Scope note: the ruling is on these sites. It does not by itself restore `attention` at the sites
Job71 translated to `noticing`, and it does not revive the claim Job69 cut (one attention divided
between two realms).

## 2. Passages go between phases — `[A]` 2026-09-15, RULED

Ch 14 (Job71) defined a passage as *the move from one orientation to the next* (arising Z to A,
development A to B, ending B to Z). Ch 7, *The smallest scale*, still called the three resting
points passages and said *the arising is enthusiastic, the development cautious, the ending
detached.* `[A]`:

> ch14 should say phase, not orientation.

> ch7: thoughts are better described by passages and passages are related to phases and phases
> describe the same three places on the cycle as the fixations.

**Ch 14, the paragraph opening *Underneath the ordering are three passages*:** a passage is the
move from one PHASE to the next. The three sentences naming each passage name phases, not
orientations (arising: detached phase to enthusiastic phase; development: enthusiastic phase to
cautious phase; ending: cautious phase to detached phase). No letters — letters never name a phase.

**Ch 7, *The smallest scale*, first paragraph:** carry three claims, one per sentence —
thoughts are best described by the passages they make; a passage is the move from one phase to the
next; the three phases are the same three places on the cycle as the three orientations.
*In a lived process the arising is enthusiastic, the development cautious, the ending detached*
goes. The sentence *Every process makes those three passages*, whose *those* points at the
resting points, is rewritten to match.

**Word choice, `[C]`'s, under the ruled vocabulary instruction:** `[A]` said *fixations*; Ch 7 is
Part 2, and `VOCABULARY-INSTRUCTION-from-job67-20260912.md` bars `fixation` before Part 3, so the
Ch 7 sentence says *orientations*. Reported to `[A]`.

**Consequence, taken to `[A]` next:** with passages running between phases, `ending` names both a
passage (cautious phase to detached phase) and the detached phase's plain name (*the impulse, the
examination, the ending*). One name per thing.

## 3. The detached phase is called the detached phase — `[A]` 2026-09-15, RULED

`[C]` proposed `resolution` as the plain name for the detached phase, to free `ending` for the
passage. `[A]`:

> no. resolution is another name for ending. the detached phase should be called detached phase.

So: `ending` names the passage (cautious phase to detached phase) and `resolution` is not a second
name for anything — where it appears it means the ending passage or goes. The detached phase has
no plain-word name; it is always *the detached phase*.

**Sites, locate by content:**
- Ch 14, *The phases and their names* — *the plain words serve: the impulse, the examination, the
  ending.* `the ending` leaves the list. (What stays in the list is item 4.)
- Ch 7, *The smallest scale* — *comes to rest in turn at an impulse, then an examination, then a
  resolution that both satisfies and disappoints.* The third resting point is the detached phase,
  so `a resolution` is wrong here. Rewritten with item 2's repair.
- Ch 14, *Two transformations and one arising* — *A resolution finishes a process* — the ending
  passage is meant; `resolution` becomes `the ending`.
- Ch 15, *The four sketches*, the enthusiastic person — *Endings are never inhabited at all; each
  resolution is overwritten by the arising that replaces it.* `Endings are never inhabited` treats
  the ending as a place, which is the detached phase. Both words need siting by the drafting session.
- Sites where `the ending` may mean the detached phase rather than the passage, for the drafting
  session to read one by one: Ch 15 *Which fixation handles a fear* (*before the ending is
  reached*); Ch 15 *The four sketches*, the cautious person (*The ending often comes late*) and the
  B-to-Z sketch (*Often the ending is a genuine decision*); Ch 17 *What falling takes from capacity*
  (*A detached person's work is the ending*; *an ending with nothing arising out of the ending*).

## 4. The plain words name passages, not phases — `[A]` 2026-09-15, RULED; one word left open

Of Ch 14's *Where the resemblance is not the point, the plain words serve: the impulse, the
examination, the ending.* `[A]`:

> these are transition names, not phases. and examination isn't right, it should be something like
> processing or activity.

So the three phases have only their phase names — *enthusiastic phase*, *cautious phase*,
*detached phase*. The plain words belong to the passages. `examination` is wrong as a name and is
replaced by a word like *processing* or *activity*; the word itself is not yet chosen.

**Settled the same hour.** The passages carried two sets of names — *arising, development,
ending* (Ch 7, Ch 14) and *impulse, examination, ending* (this sentence). `[A]`:

> "arising, the development and the ending" are good.

So the passage names are **arising, development, ending**, and nothing else. The plain-words
sentence in Ch 14 goes. `examination` and `impulse` stop being names; the sites below are
rewritten to say the development (or the cautious phase, where a place is meant) and the arising
(or the enthusiastic phase). `an impulse arises`, meaning the thing that arises, stays.

**Sites where `examination` or `impulse` names a phase or a passage** (for the drafting session): Ch 14 *What the odd one carries* (*when the impulse is taken up for
examination … the examination has to work with … the end of the examination*); Ch 14 *The phases
and their names* (*while the impulse is still carrying it*); Ch 15 *Which fixation handles a fear*
(*cuts the examination short*); Ch 15 *The four sketches* (*moves quickly to examination*; *the
examination is the cautious person's place of comfort*; *at home in the impulse … in the
examination*); Ch 17 *What falling takes from capacity* (*A cautious person's work is the
examination*; *fears raised in the examination*; *An enthusiastic person's work is the impulse*).
`an impulse arises` as the thing that arises is ordinary English and stays.

## 5. A register of word rulings, and a checker — `[A]` 2026-09-16: *yes*

Cut: `WORD-RULINGS-book2-20260916.md` and `wordcheck.py`. The register gathers every standing
word ruling with its date and `[A]`'s words, marks `[C]` readings as not ruled, and says a
drafting session applies only RULED entries. `wordcheck.py BOOK2-<date>.md` reads the patterns
from the register and lists every sentence that uses a governed word.

Run on `BOOK2-20260915.md` (71 hits). What the hits say, beyond items 1 to 4 above:

- `fixation` before Part 3: 0. Economic words: 0. `ration`: 4, all at the permitted sites.
- `judgement` at four places (Ch 5 twice, the Part 3 opening twice): US spelling is `judgment`.
- `lent motivation` at five sites (Ch 5 four, and *to lend them motivation* at the Nine) —
  unruled: Job68 treated `lent` as a second name for `supplies`, Job71 used it. Question for `[A]`.
- *keeping off what is painful* in Ch 15's *The hinge* — the phrase `[A]` rejected at Ch 4's Z
  entry. Different site; question for `[A]`.
- the verb *loops* for the psychic realm (Ch 3, Ch 5 four times, Ch 13) — `[A]`'s 09-15 `loop`
  ruling names the two proper uses; Job71 kept the verb. Question for `[A]`.

## 6. The Five's psychic realm — `[A]` 2026-09-16, RULED in part

Job70's closures file carried two statements about a Five's looking in the psychic realm: closure 1
(ruled, *it's right*: lent motivation is turned on what the non-detached fixation is concerned
with) and a sentence inside closure 3 that was `[C]`'s extension (*A Five looking with lent
motivation has nothing directing the looking, so a Five can notice what no fear pointed at*).
Job71 wrote closure 1 only. The Ch 5 sketch also says a Five is the type most able to look at an
emotional situation without standing inside it. `[A]`:

> they also notice things no fear pointed at, such as someone else's emotional situation

> "so a Five does look there" does->can?

> "nothing directing the looking" is false. "can notice what no fear pointed at" - true.

**Sites, Ch 5, Type 5, the paragraph opening *The psychic realm is different*:**
- *so a Five does look there* → *so a Five can look there*.
- *What a Five notices in the psychic realm is whatever bears on the fears of the physical realm.
  Everything else a Five has taken in goes unnoticed* — too narrow: a Five also notices what no
  fear pointed at, such as someone else's emotional situation. The looking is still directed by
  something. What directs it when no fear does is taken to `[A]` next.
- Closure 3's sentence in `CLOSURES-SITED-job70-20260915.md` is NOT a ruling in its first half and
  must not be applied. Its second half stands.

**What directs a Five's looking when no fear does — `[A]` 2026-09-16.** `[C]` offered two
candidates: (1) the physical realm's wants as well as its fears; (2) wants arising in the psychic
realm itself, such as wanting to understand what a friend brings. `[A]`:

> 1 is often the case. 2 is true because detachment has a lean.

- The Five sentence names both: the physical realm's wants and fears (often), and wants arising in
  the psychic realm itself.
- **This rules a question held open since 2026-09-08** (`NOTE-two-sources-of-motivation-20260908.md`:
  *NOT RULED … whether the lean is itself a source of motivation*). `[A]` now gives the lean as the
  reason a detached realm has wants of its own. Consequence taken to `[A]` next: Ch 4 currently
  gives a different reason (*wants and fears still arise in a detached person's realm, because wants
  and fears arise in every realm, whatever orientation*).
- Ch 5 cannot name the lean (leans arrive at Ch 11). The Five sentence states the wants; where the
  reason is written is for the drafting session to site once the question below is settled.

**Ch 4's reason — `[A]` 2026-09-16.** Of Ch 4's *But wants and fears still arise in a detached
person's realm, because wants and fears arise in every realm, whatever orientation a person holds.
Something is wanted, and then a fear arises about the thing wanted.* `[A]`:

> i find that paragraph misdirected. saying "wants and fears arise in every realm" is bypassing the
> whole explanation of orientations.

So the reason in that sentence is wrong for Ch 4: what moves a detached person is to be explained
through the orientations (the other realm's orientation; the lean), not by a claim that wants and
fears arise regardless of orientation. Replacement taken to `[A]` next. Other sites carrying the
same *whatever orientation* reasoning to be listed for him after.
- **`[A]`: *ok to mention lean.*** Ch 4's paragraph (opening *A detached person's own want is
  peace*) is rewritten: the person's own want is peace, which makes them look for nothing; what else
  moves a detached person comes from the person's other realm when it is enthusiastic or cautious,
  and from the lean; and one sentence says what a lean is — a detached person is always nearer
  caution or nearer enthusiasm and has some of that orientation's wanting or fearing. *Because wants
  and fears arise in every realm, whatever orientation* goes, with *Something is wanted, and then a
  fear arises about the thing wanted*. Ch 11 then builds on this first mention. The register's
  entry on leans is updated (first named at Ch 4, for detachment).

**Ch 5's opening and Ch 15's *The range of detachment* — `[A]` 2026-09-16.** Both carry the
*whatever orientation* reason. `[C]` proposed joining the 09-12 rulings (pain raises fear in any
realm; how many fears a realm raises depends on how much the person examines there) through the
lean: in a detached realm the lean sets how much wanting and examining happens; a detached realm's
own wants and fears come from its lean, plus pain; *whatever orientation* goes from both sites; the
Nine has only what the leans in their two realms raise, plus pain. `[A]`:

> basically right. two things to discuss: does cautious detachment generate fear or just process
> fear that comes from earlier phases? and how does pain work in the arc?

Both taken in turn below before the two sites are sited.

**Does the caution end generate fear? — `[A]` 2026-09-16, RULED.**

> only process arriving fears. detachment wants peace. processing fears is one way. ignoring them is
> the other. generating is in the opposite direction.

So detachment generates no fears and no wants of its own apart from peace. Its two ways to peace
are processing arriving fears (toward caution) and ignoring them (toward enthusiasm). Generating
belongs to enthusiasm and caution. **Correction to `[C]`'s proposal above:** the lean does not set
how much wanting and examining a detached realm does in the sense of raising new material; it sets
which of the two ways a detached person takes with what arrives. A Five noticing a friend's
emotional situation is processing a disturbance that arrived, in the want for peace. Pain: next.

**How pain works in the arc — `[A]` 2026-09-16, RULED.** `[C]`'s reading: a direct pain, or a
reminder of one, starts a new process; the arising is the want to be free of the pain; the
development looks at the pain and raises fears; examining an ordinary want pictures a pain, which
is how it raises fear. `[A]`:

> "A direct pain, or a reminder of one, starts a new process." i agree. that means pain can
> generate wants as well as fears.

So pain starts processes in any realm and generates wants (to be free of it) as well as fears.
Ch 15's *Pain is what raises a fear* paragraph is incomplete: it says pain raises fears and not
that pain starts a process and raises a want. Site owed there.

**What starts a process — `[A]` 2026-09-16.** Asked whether, in a detached realm, only pain and the
other realm's supplied motivation start a process:

> i think wants and fears start processes. and physically caused attraction and aversion, e.g. pain,
> also do (or do so by creating wants and fears -i'm not clear whether that is different).

Ruled: wants and fears start processes; physically caused attraction and aversion (pain, and by the
same token pleasure) also do. Open, `[A]` unsure: whether attraction and aversion start a process
directly or only by creating a want or fear. `[C]` recommendation put to him next.
- **`[A]`: *pain and pleasure start a process - how is up to wording since we decline to specify
  the method.*** So the book says pain and pleasure start a process and does not say by what means.

**Sited, from the rulings above (Ch 4 is sited earlier in this item):**

- **Ch 5, the paragraph opening *Motivation can cross*.** *Every realm has wanting and fearing of
  its own, whatever orientation a person holds* goes. The paragraph says: a realm where the person
  is enthusiastic or cautious generates wants and fears; a realm where the person is detached
  generates none, wanting only peace; an enthusiastic or cautious realm supplies motivation the
  person can turn on a detached realm (sentence unchanged). *A detached realm can therefore be
  worked on with two kinds of motivation: what arises in the detached realm, and what the other
  realm supplies* is rewritten to match: what a detached person deals with in that realm arrives —
  processes started by wants and fears, or by pain and pleasure — and the other realm's supplied
  motivation.
- **Ch 15, *The range of detachment*, the paragraph opening *In a realm where a person's fixation is
  detached*** and the one after it. Keep *what the person wants is peace* and *Wanting peace does
  not make a person look for anything*. *A process running in a detached realm raises a want, and
  examining the want raises a fear about it* and *Every realm raises fears by examining wants,
  whatever orientation a person holds in the realm* go. Keep the 09-12 sentences (how many fears a
  realm raises depends on how much the person examines there; a person cautious in one realm raises
  most examined fears there). Add: a detached person generates no fears; at the caution end
  arriving fears are processed, at the enthusiasm end they are ignored; the lean sets which. The
  paragraph on the other realm keeps its sentences; *A Nine, detached in both realms, has only what
  their own processes raise* becomes: a Nine has no other realm to supply motivation, so what a
  Nine deals with arrives through processes started by wants, fears, pain and pleasure.
- **Ch 15, the paragraph opening *Pain is what raises a fear*.** Pain and pleasure start a process,
  and the process raises wants as well as fears; the book does not say by what means. *Examining a
  want raises a fear the same way…* stays as the case it already is.
- **Ch 5, Type 5, *The psychic realm is different*.** Per item 6: *can look*; a Five notices what
  bears on the physical realm's wants and fears, and also what no fear pointed at, such as someone
  else's emotional situation, which a Five processes in wanting peace.
- **Ch 15, *The range of detachment*, the lean paragraph** (*The lean changes how much a detached
  person is moved to notice*) — read against the rulings: the lean sets processing against
  ignoring. The drafting session checks it says that and no more.

## 7. Ch 15's two *I assume* sentences — Job71's check

**Site 1, *The hinge*:** *And the reactions fitted to helplessness do not retire when helplessness
ends. I assume that a fixation is a strategy that outlived its problem.* The next paragraph and
*Habit carries it* argue from the assumption without repeating the hedge. `[C]` decision: no fault.
An argument built on a marked assumption does not need the mark again (`[A]`'s 09-15 point that
repeated warnings do not work).

**Site 2, *What previous thoughts have laid down*:** *And the hardening is the accumulation. There
is no core habit sitting on top of the mental deposits … The residue is the habit. I assume that a
fixation is the shape the mental deposits have taken.* The same claim is stated flat three times and
then marked as an assumption. Taken to `[A]`.

Noted for the later style job, not raised: in the same section, *that was the point of separating the
three passages* and *One question has been left open since the beginning* describe the book's own
arrangement; *It also says what undoing one would involve* (end of *Habit carries it*) has an `It`
pointing at nothing named nearby.
- **`[A]` supplied the wording, 2026-09-16:** *I take it that a fixation is a habit, a shape the
  mental deposits have taken. Habits are part of the mental deposits.* **Site:** replaces the four
  sentences from *And the hardening is the accumulation* through *I assume that a fixation is the
  shape the mental deposits have taken*. Checked: one idea per sentence, no referring words, and
  *part of* agrees with the paragraph above (*the mental deposits carry other influences too*).
  *I take it that* is his form for this site; site 1 keeps *I assume that*. The register's voice
  list gains *I take it that*.

## 8. Ch 13, *The imaginary self* — the new passage — Job71's check

Job71 inserted two paragraphs (the capacity began in animals; a person sees their own self as a
fixed object) between *What it is not is an object.* and *Which is why looking for it does not
work.* Two faults found:

- **The join.** *Which is why looking for it does not work* was written to follow *What it is not is
  an object*. It now follows the game paragraph, so *Which* points at the wrong thing, and *it*
  reaches back two paragraphs.
- **Not an object / seen as a fixed object.** The book says the self is not an object, then says a
  person sees their own self as a fixed object, without saying that seeing it so is a mistake.
  `[C]` read these as consistent; a reader meeting them one paragraph apart may not.

`[C]` recommendation taken to `[A]`: move the two new paragraphs after the *Which is why looking for
it does not work* paragraph, and write *sees their own self as though it were a fixed object*.
- `[A]` asked to see the section; shown with the two moved paragraphs after *Which is why looking for
  it does not work*, *as though it were a fixed object*, and one `[C]` addition (*The capacity for
  tracking other minds began in animals*, restating the name after the move). `[A]`: *"A guesser in
  that situation needs a piece to play…" that sentence should move to the paragraph about people,
  not animals.* The sentence moves into the people paragraph, before *A person sees their own self*,
  with *in that situation* dropped since the situation it named stays behind in the animal paragraph.
- **`[A]`: *ok*** to the section as shown last. **Site, Ch 13 *The imaginary self*, final order:**
  (1) *One of the things in that picture is a self.* (2) the *It was not discovered…* paragraph,
  unchanged; (3) the *Which is why looking for it does not work* paragraph, unchanged; (4) *The
  capacity for tracking other minds began in animals, as a way of guessing what another animal will
  do while the other animal is guessing back.* (one sentence); (5) *A person also turns the capacity
  on themselves, and something is added when they do. A guesser needs a piece to play, with a
  position, with some moves open and some closed, and with a chance to win or lose. A person sees
  their own self as though it were a fixed object, in the way a person sees an opponent.* followed
  by the paragraph's remaining three sentences unchanged. Approved verbatim.

## 9. Ch 2's profiles — Job71's check

Surveyed for every governed word. No economic words, no `fixation`, no `dwell` outside the Nine's
own quoted line, no `loop`. `see`, `blind spot` and `clear-eyed` are ordinary English in the types'
self-descriptions and stay. **`[C]` decision, reported to `[A]`:** `orientation` appears twice as
ordinary English, before Ch 4 makes it a technical term — the Seven's *an authentic orientation
toward life* and the Nine's *they see this orientation as a kind of emotional generosity*. One name
per thing: both become `attitude` (*an authentic attitude toward life*; *they see this attitude as a
kind of emotional generosity*).

## 10. `lent` → `supplied` — `[A]` 2026-09-16: *ok*

**Sites:** Ch 5, the Two, Four, Five and Seven, *turns the lent motivation on* → *turns the supplied
motivation on*; Ch 5, the Nine, *A Nine has no other realm to lend them motivation* → *A Nine has
no other realm to supply them motivation*. Run `wordcheck.py` for any other `lent`/`lend`.

## 11. *keeping off* → *trying to avoid* — `[A]` 2026-09-16: *yes*

**Site:** Ch 15, *Two channels*, *going toward what is pleasant, keeping off what is painful, and
watching without doing either* → *going toward what is pleasant, trying to avoid what is painful,
and watching without doing either*.

Noted for the next question: the paragraph above it ends *react to the feeling, weigh it and
respond, or quietly see it* — `see` used for detachment's relation.

## 12. The verb *loops* — `[A]` 2026-09-16

`[A]`: *i dislike both, but i don't have an alternative. let's discuss it. i like the person being the
subject of the sentence instead of what loops.* `[C]` offered, from Ch 3's own sentences, the general
statement *Whatever a person thinks or feels becomes part of what the person is thinking or feeling
about.* `[A]`: **yes** to the pattern.

**Sites:**
- Ch 3, paragraph opening *What I call the psychic realm*: *so whatever a person does in the psychic
  realm loops back through the person* → *so whatever a person thinks or feels becomes part of what
  the person is thinking or feeling about.*
- Ch 3, *So the physical realm corrects through pushback and the psychic realm compounds through
  looping.* → *So in the physical realm a person is corrected by pushback, and in the psychic realm
  a person keeps adding to what they are thinking about.*
- Ch 13, *What self-reference does*: *Self-reference is why whatever a person does in the psychic
  realm loops back through the person.* → *Self-reference is why whatever a person thinks or feels
  becomes part of what the person is thinking or feeling about.*
- Ch 5, the Four: *Because the psychic realm loops, watching for a lack feeds it* → *A Four's
  watching becomes part of what the Four is watching, so watching for a lack feeds the lack*.
- Ch 5, the Two, the Six, the Nine: shown to `[A]` next.
- Shown: the Two, the Six, the Nine. `[A]` on the Nine: *in the case of the nine, that statement is
  true of the A lean but not the B lean.* So the Nine's carrying of a withdrawn conflict belongs to a
  Nine leaning toward enthusiasm only. Scope repair taken to `[A]` next (the Nine's sketch names the
  two ways of handling a fear but not what sets which; Ch 4 now introduces the lean, so Ch 5 may use
  the word).
- **`[A]`: *yes*,** with a wording note: *"Which a Nine does" looks ambiguous. "Which option a Nine
  takes" doesn't but the words might be wrong.* `[C]` decision: **"How a Nine handles a fear is set
  by the lean in that realm."**

**Sites, Ch 5 (approved; the Two and the Six drew no objection):**
- the Two: *Because the psychic realm loops, it appears to have no ceiling:* → *A Two's feeling
  becomes part of what the Two feels about, so the psychic realm appears to have no ceiling:*
- the Six: *because that realm loops:* → *because a Six's watching becomes part of what the Six is
  watching:*
- the Nine, after *Or a Nine may simply want the fear to go away.*: add *How a Nine handles a fear is
  set by the lean in that realm: a Nine leaning toward caution solves, and a Nine leaning toward
  enthusiasm wants the fear gone.*
- the Nine, *In the psychic realm, wanting a fear gone fails oppositely, and less visibly.* → *In the
  psychic realm, a Nine leaning toward enthusiasm wants a fear gone, and that fails oppositely, and
  less visibly.* *Because that realm loops, a Nine still carries the conflict they withdrew from.* →
  *A Nine's feeling about the conflict stays part of what the Nine feels, so a Nine still carries the
  conflict they withdrew from.*
- the Nine, *What a Nine wants is comfort — to be left undisturbed.* → *What a Nine leaning toward
  enthusiasm wants is comfort — to be left undisturbed.*

## 13. Ch 15, *Two channels*: *or quietly see it* — `[C]` decision, reported

*The three are relations to the two: react to the feeling, weigh it and respond, or quietly see it.*
`see` for detachment's relation is the use retired on 09-07, and the next paragraph names the same
relation *watching without doing either*. One name per thing: → *or watch it without doing either.*

## 14. Ch 15, *Why it does not turn over* — a fear has no completion condition

*A desire has a completion condition … A fear has none. The feared thing failing to happen does not
retire the fear … So desire cycles because it can be satisfied, and fear freezes because it cannot.*
Against: the four fates in the same chapter (a fear is *worked through* and nothing is left over; a
fear *given up on* goes with its want), and `[A]`'s 09-03 ruling that a fear ends when the want
behind it ends. Taken to `[A]`.

## 15. NEW MATERIAL from `[A]` 2026-09-16 — desires and fears across thought cycles

Given verbatim, for a doctrine session; nothing here is ruled and none of it may be drafted:

> desires and thoughts seem to span multiple thought cycles. i think the fixations work the same way
> in thought cycles. the process arcs might be less real, rather than a series of thought cycles. but
> process arcs are the scale real fears and desires are processes on. that says that single fears and
> desires duration is a process arc. desires are processed in the A phase. if satisfied, nothing more
> happens until the next cycle. if not disappointment arises, which is a kind of aversion which is
> processed in the B phase. (maybe aversion would be better in most places where "fear" is used.)
> typically the answer to disappointment is another step is needed and the aversion is resolved and
> the next cycle is the desire to do the next step. a worry would be processed in multiple thought
> cycles in the same way, with a desire to solve it leading to facing what needed to be done resolved
> by the decision to do a next step. that's the thoughtful rational way. there can also be a reactive
> way where a desire or fear leads directly to an action - i thing that would mean skipping the B
> (cautious) phase. and there are the ways of ending the cycle without resolving the fear. it's
> getting complicated. can you untangle this, fill in missing steps?

`[C]` untangling given in session; his answer follows in the conversation record.
`[A]` then asked for the proposal to be checked against the whole book, and suggested `aversion` in
Part 3 and possibly `attraction` for `desire`. The check's five agreements and five collisions are
in the conversation record; the collisions are: nothing crosses the arising (Ch 14) against a desire
held across cycles; whether a returning fear is the same fear; where disappointment sits (Ch 7 puts
it at the resolution); skipped against cursory cautious phase (Ch 14, Ch 16's spoiled arrival); and
whether larger arcs stay real (Ch 7, Ch 16).

**First collision settled — `[A]` 2026-09-16: *i agree*.** A long desire is not one desire lasting.
Each thought ends and lays down what it was carrying; the next thought arises out of what was laid
down, so nearly the same desire is raised again. A person pursuing something for a month raises that
desire many times a minute. A process arc at the size of an undertaking is a long run of thought
cycles raising nearly the same desire, and the arc ends when the desire stops being raised — the
thing was got, or the desire was given up. The bodily tension acts the same way, by shaping what the
next cycle raises rather than by crossing into it. Nothing in Ch 14 changes: nothing crosses the
arising.

**Second collision settled — `[A]` 2026-09-16: *yes*.** A fear lasts one thought cycle. A fear that
returns is raised again out of the deposits and out of the problem, which still stands; nothing is
stored and brought back. What lasts an arc is the raising of nearly the same fear while the problem
stands. Ignored: the problem is unsolved, so the next cycle raises the fear from the problem.
Blocked: the deposits are shaped by the burial, so later cycles raise fears shaped by it even after
the problem is gone. **Wording:** *the fear returns with the problem* stays in Ch 14's list; Ch 15
says once, where the mental deposits are explained, that a fear that returns is raised again rather
than stored and brought back.

**Third collision settled — `[A]` 2026-09-16.** Two ways a desire disappoints: the examination
judges the desire cannot be met, or the person meets an outcome that did not meet it. `[A]`:

> yes, the two are different. in the case of the world, a new cycle starts with failure. there could
> be denial in Z+, a new plan in A or disappointment in B. that keeps disappointment in B for both.

So **disappointment belongs to the cautious phase in both cases.** Meeting a failure starts a new
cycle, and what becomes of the failure depends on where the person's attention is concentrated:
denial at the enthusiasm end of the detached phase, a new plan at the enthusiastic phase,
disappointment at the cautious phase. `[C]` note: this is Ch 4's existing paragraph on what people
do when something goes wrong, now sited in the arc — an enthusiastic person turns toward the next
positive, a cautious person engages and the trouble is looked at, a detached person steps back and
lets the difficulty go or does not look at it at all. Ch 7's *a resolution that both satisfies and
disappoints* is a different use and stays.

**Fourth collision settled — `[A]` 2026-09-16.** Reactive action: *action would come without thought.
we could say the no thought cycle was involved. same for panic.* Then, on `[C]`'s half-a-thought
case: *it could be said that the half thought had completed, with a conclusion that restraint was
too painful. then the snapping would be another thought cycle where the desire to end the pain was
decided, with the snapping occurring at the end of a truncated cycle.* Then, on panic: *panic must
involve some sort of judgement and so a thought cycle so it's separate from a reflex.*

**Three cases, ruled:**
1. **No thought cycle.** A reflex — the hand off the hot pan. Nothing thought preceded the action.
2. **A truncated cycle.** One cycle concludes (restraint is too painful); the next raises the desire
   to end the pain, the examining is cut short, and the action happens at the ending. Panic is
   here, not with the reflexes, because panic involves a judgement.
3. **A cycle fully lived.**

Nothing is skipped: Ch 14's *every process runs a beginning, a middle and an end* stands as written,
and `skipping the cautious phase` is not said anywhere. A truncated cycle raises little, so the
ending has little to dispose of; Ch 16's spoiled arrival is the same case. **The 09-15 stress
hypothesis is consistent** (a cautious person acting on an unexamined want) and keeps its `I
suspect` marking.

**Fifth collision settled — `[A]` 2026-09-16: *yes*,** to keeping arcs at every size, with a thought
cycle as the only size at which the three passages are literally made, and a larger arc as a long
run of cycles each raising nearly the same desire out of what the one before laid down. `[A]` on
what he had meant: *i think my "less real" referred to the lack of a clear boundary about which
thought cycles would belong to a particular process arc.* So a larger arc has no sharp edge, which
follows from Ch 15's statement that the mental deposits carry other influences too.

## 16. `aversion` in Part 3 — `[A]` 2026-09-16, RULED: the small version

`[A]` suggested `aversion` in Part 3 and possibly `attraction` for `desire`, then asked whether the
result would be clear for a reader. `[C]` answered no to the wide version — four names for two
things (attraction/want, aversion/fear), and `aversion` is a category word where `fear` is felt —
and recommended a small version. `[A]`: **the small version**.

- `fear` and `want` stay as the working words through Part 3.
- `aversion` is used only where the class is needed: where disappointment is introduced, and where
  the four fates are stated. About half a dozen sites.
- At those sites the book says plainly that fear and disappointment are both aversions and both
  meet the same fates.
- `attraction` is left where it is; `want` keeps its job and gets no second name.
- Parts 1 and 2 are untouched.

Register updated.
