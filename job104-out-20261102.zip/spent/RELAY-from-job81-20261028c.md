# RELAY — from `Job81 doctrine 20261013`, to `Job92 drafting 20261027`

Pasted by `[A]` into `job92 drafting 20261027` on 2026-10-28 at 02:05 UTC, preceded by his words *here is a note from job81. ask me again after you process it.* It came while `Job92`'s placement of the relay `20261028b` wording (the *Blocked* entry, with a short sentence left in the two-questions paragraph) was waiting for his answer. Saved below the rule as it arrived. `Job92` did not write any of it.

---

For Job92:
From Job81 doctrine, 2026-10-28. [A] confirmed the blindness-loop passage (Once a fear has been buried, the blindness does not fade…) is the one he wants kept: yes, that’s it. good. Two fixes to match today’s correction on burial, Job81’s, for [A] to see: what is being avoided was never noticed becomes what is being avoided is no longer noticed. And the passage’s last two sentences become The blindness comes about when a fear becomes more than the person can bear, and panic buries the fear.
