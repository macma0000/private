# SET NOTE — from `Job55 doctrine 09072026`, for the session that opens this set

**Cut 2026-09-07. Kind 7, doctrine, on `DOCTRINE-BRIEF-two-stages-of-seeing-20260906.md`.**

**Nothing was written into book 2 this session.** Everything below is doctrine ruled and prose owed.
The book, the claim inventory and book 1 are byte-identical to what arrived. The style guide took a
`b` letter and the record took an append.

**This is the largest doctrine day in the project's record.** It is written up at length on purpose.
The 08-19 material existed only in a conversation, was not written into that day's addendum, and was
lost until `[A]` noticed it a day later — which is why the standing selection rule is to record what
cannot be reconstructed, and to record his reasoning and not only his conclusions.

---

## 1. What arrived, and what the checks said

Incoming zip `job54-out-20260907.zip`, one directory, verified against `MANIFEST-job55-20260907.md`:
**50 ok, 0 mismatched, 0 bad count, 0 missing, 0 not in the manifest.** Screen fired two, both
benign — the record as CARRY DO NOT READ, and the handoff for quoting the restriction string.

Record arrived **44,672 w, md5 `c6da637a`, marker `Job54 drafting 09072026`, thirty-fifth append,
parent 43,250** — matching `SET-NOTE-from-job54-20260907.md` exactly, so the chain was clean.

*One delivery note, harmless and worth knowing.* The first zip handed to this session was
`job54-closing-20260907.zip`, job54's closing zip for its own directory. It carries the correct
masters but no forward manifest, so §1.0 could not be run against it. Verified against the only
manifest it holds — job54's own arrival manifest — it came out 50 ok / 1 mismatched / 2 missing /
7 not in the manifest, every difference accounted for by job54's own work. **The two zips are easy to
confuse because both are dated 09-07.**

---

## 2. THE CENTRAL RULING — seeing has two stages

**RULED 2026-09-07.** Put to him as a claim about detachment rather than about his own experience,
and answered: **yes**.

- **The first stage is the taking in.** Everything a realm holds arrives whole and at once. Nothing
  is assembled and nothing is inferred.
- **The second stage is the noticing.** It picks one part out of what was taken in, and it is work.

**His own words, which carry more than the summary:** *what is taken in stays unconscious unless or
until it results in a motivation which is when noticing happens. and as in the case of orientations
A and B, acting under motivation narrows vision. motivation determines width of focus.*

**Half of this was already ruled and half was not.** His 09-06 detached-realm ruling — that when a
realm is detached the picking-out has not been done — is the second stage. What was unruled until
today is the first.

**Why it was worth ruling rather than leaving:** the book already stated the first stage without any
ruling behind it, in the range of detachment — *a detached person takes a realm in whole, and takes
it in directly.* And his own deferred question about the word `notice` was this question, since
`notice` presumes the first stage is a noticing.

### What follows immediately

**Motivation determines width of focus, and the three orientations come out in the order they
already stand in.** Enthusiasm is narrowest, acting on the piece in front of it. Caution is wider,
holding several pieces together. Detachment is widest, nothing pulling. **The book reports those
three widths in one sentence in the range of detachment and gives no reason for them. This is the
reason.** It is also his own 08-20 material returning — each fixation's motivation blocks its own
aim, and the price of the crossing is that motivation.

**RULED: taking in whole and noticing can both be done, but not simultaneously.** His words: *it
seems like taking in whole and noticing can be done, but not simultaneously.* **So the whole is not
spent when motivation arrives; a person can come back to it.** Two scales stay apart — the
alternation is moment to moment, while where a person habitually rests is their fixation and does
not alternate.

**RULED: the first stage is general, not detachment's alone.** His words: *an a or b orientation is
usually focused. things can still be taken in, but only in the narrow area of focus.* **So the claim
belongs in Part 1 with the orientations, not at the range of detachment.** Taking in is direct in all
three; motivation sets how wide it is.

**RULED: what caution assembles is the picture, not the taking in.** The range of detachment
contrasts taking in directly against assembling out of pieces, while the ruled pair is wide against
narrow with the taking in direct either way. A cautious person takes in directly but narrowly, and
what gets assembled is their picture of the realm, built from many narrow takings over time. Asked
whether that was right, he answered **yes**.

**RULED: the cycle is a slow widening and a sudden narrowing.** Going forward around the cycle width
increases the whole way, then collapses in one step when motivation arrives and detachment gives way
to enthusiasm. Asked whether that holds, he answered **yes**. *Convergence worth recording: the model
already treats that one step as different in kind — enthusiasm and caution fail inside an arc,
detachment fails at the join, and the ending-and-arising is ruled unlike the within-arc transitions.
The width account arrives at the same join from a new direction and says what is different about it.*

---

## 3. BLINDNESS — the block sits at the noticing

**RULED 2026-09-07, and he found it himself mid-exchange:** *and i just noticed that in the blindness
loop, it is the noticing that is blocked, not the taking in. that's how a reaction can be initiated
without noticing.*

**This takes a compartment out of the model.** Two sentences in the blocking passage explain
blindness by putting the seeing somewhere — *the information is then kept from consciousness*, and
*the seeing occurs where consciousness does not reach it*. Both need a place for the seeing to be
that is not where the person is. **He ruled both replaced.** What replaces them: the taking in
happened in the ordinary way, the attending did not, nothing is stored and nothing is hidden.

**The sentence above them survives** — something deep enough to recognize a threat recognizing it is
the taking in doing its ordinary work.

**It gives a mechanism to a claim the book asserts without one.** The passage on what falling takes
from capacity says buried anxiety forces a reaction that has not been thought out, and never says how
a reaction gets started with nothing in view. Motivation arose from what was taken in, the reaction
ran on that, and the noticing that would have allowed weighing was blocked.

**RULED, and it is his own extension:** *the anxiety that causes the not attending and the failure to
attend are also taken in and all three events are deposits that remain unconscious.*

### The second-recognition sentence — RECOMMENDED, NOT EXPLICITLY RULED

The book says blocking is reinforced each time it runs, by a second recognition, also unconscious,
that an unpleasant anxiety did not have to be felt. **That sentence asks for an unconscious
recognition of something that did not happen, weighed against what would have happened otherwise.**
Under the deposits ruling none of that is needed: the failure to attend is taken in, lays down a
deposit, and the deposit is what makes the same move likelier next time. The book already has the
gradient — a choice repeated often enough sinks beneath understanding — and already says the later
blockings are that ordinary case.

**`[C]` put the removal to him and he answered with the antagonism material instead, so it was never
answered in as many words.** It sat in a list of owed prose he did not dispute. **Treat it as
recommended and unconfirmed; a drafting session should have it confirmed before cutting the
sentence.**

---

## 4. THE DESCENT — two stores, and a third thing pushing back

**`[A]`, then a correction that reverses what his claim does:**

First: *so i think that a kind of antagonism develops between the desire for comfort and the
accumulating unconscious deposits.* `[C]` read this as something opposing the descent and put that
back to him.

**Corrected:** *i meant conscious antagonism towards the unconscious deposits. those deposits feel
like a threat.*

**So it feeds the descent rather than opposing it.** The book says buried anxiety goes on causing
stress though it is never consciously seen, and never says what the person makes of that stress. It
presents as a threat; a threat raises anxiety; anxiety is what the not-attending is for. **Each
deposit becomes a fresh occasion to block, and each block lays down another deposit.** Until now the
buried material only supplied more occasions; it supplies them at an increasing rate.

**RULED — the shape of the fall.** Put to him: two stores both grow as a person falls, the deposits
pressing down and the consequences pressing back, and how fast someone falls is set by which grows
faster. **His words: *that's the shape.*** *This rests on his 09-07 ruling that consequences persist
and accumulate rather than arriving as separate blows.*

### The third thing, and it closes a hole the book declares open

**`[A]`:** *another thing that pushes back is a recognition that blindness is causing trouble and
pain. this recognition may be partly conscious but even as unconscious deposits that will accumulate
and might become conscious under the pressure of painful consequences.*

**This replaces the leverage guess, and he called the replacement *a good explanation*.** The book
currently says how anyone ever makes the comparison is a harder question than the comparison itself
and that what follows is a guess: sight arrives unbidden in a rare moment, is lost, and lost again,
and the moments keep coming because the buried material keeps growing. It offers nothing about how
one of them finally holds.

**Under today's rulings it follows.** Blocking stops the noticing and never stops the taking in, so a
moment of clarity that gets disposed of was still taken in and still deposits. The next deposits on
top of it. **The moments do not have to hold, because they accumulate whether they hold or not.** And
the surfacing has a trigger rather than being luck: painful consequences raise the accumulated
recognition into view.

**What it does not do, and this was stated before he ruled:** it still needs the world to deliver the
pain, so it is not a way out alone and the leverage close stands.

### The tyrant case — RULED OUT of the book, kept as doctrine

**`[A]`:** *lack of consequences applies to the case of tyrants and dictators where depravity results
- even then consequences often finally come.* **The account predicts the case** — where consequences
do not reach a person nothing opposes the fall, and the level correspondence already puts
pathological destructiveness at the blind end of detachment. So it is the account with the brake
removed rather than an exception to it.

`[C]` first gave the 09-06 enumeration ruling as the reason to hold it back — these are conditions a
reader in trouble could arrange for. **He answered: *i don't think many tyrants are going to read the
book. do you see any other reason to hold back?*** The second reason, which is the one he accepted
with **ok**: the book works by a reader recognizing themselves in it, and an example that is
unmistakably not the reader gives them somewhere else to put the mechanism. The insulated position is
not only a tyrant's — it comes with money, authority, a household where nobody contradicts, work that
cannot be lost — and those ordinary versions are what a reader would otherwise have to reach for
themselves. **The book loses nothing by the omission, the bottom of the range being already
occupied.**

---

## 5. VOCABULARY — the two stages get their words

This took most of the session's second half and he drove it. **The whole assignment is now in the
style guide, section 8, and this note records why each part went the way it did.**

**`take in` is the first stage, and it is the only name for it.** `[C]` first recommended that `see`
keep the first stage, on the ground that book 1 binds direct seeing to Z− and that `see` was his own
word for it. **He rejected that:** *i'm not sure. normally seeing includes noticing. can you think of
a better word?* **He is right, and it kills the recommendation** — a word that includes noticing
cannot name the stage where nothing has been noticed. `register` fails the same test, since saying
something did not register means it was not noticed. `take in` is already the book's phrase at the
defining sentence and has no other job anywhere. He answered **yes**.

**`notice` is the second stage, and never the first.** Ruled earlier in the session, with a
style-guide rule at his instruction. *Census that came with it: fourteen uses in book 2, eleven
ordinary and untouched, two made right by the ruling rather than wrong, and one wrong — the Nine's
`nothing bends what they notice`, which credits a Nine with the stage they do least.* **His
expectation had been that the fix would reach many places; it reaches one.**

**`see` keeps no doctrinal job as a verb, and `sight`/`seeing` keep one as a noun.** He asked whether
the second stage should be reduced to one word as well. **The answer is no, and the substantial
reason is that `sight` and `seeing` name a capacity rather than an act** — *how much sight is left by
then*, *a little of the seeing goes with it*, *a failure of seeing* — and that capacity is what the
health axis measures. `notice` is an event and has no noun that carries it. *He then asked how the
verb `see` bore on the question, which sharpened it: `see` is the only one of the candidates that
genuinely spans both stages, so the rule only has to keep it off the first.*

**`register` goes entirely, splitting between the two.** He asked directly whether it could be
replaced by `notice`. Most sites go to `notice`; three are the first stage and go to `take in` —
*less of what is taken in is allowed to surface*, *what a person does about what they take in runs
from the involuntary to the chosen*, and the arc sequence at Ch 14. One site disappears with a repair
already agreed. **Cost stated before he ruled:** `register` is impersonal and suits a passage saying
the blocking is not chosen, while `notice` sounds like something a person does; the surrounding prose
already carries that.

**`surface` goes at its two doctrinal sites.** Both are *allowed to surface* in the range of
detachment. **Surfacing means coming up from below, which is the compartment in a verb** — the same
device removed from three sentences earlier in the session. The permission sense sits in *allowed
to*, which the book already runs on its own a line later (*allowed to know*), so both become *allowed
to notice*. Six ordinary uses of `surface` stay.

**The rule runs one way only, and he approved it that way:** the first stage gets one name and
nothing else may be used for it; the second stage may be said in ordinary English. His 09-05 rule
against a second name was about a thing named and then named again, not about ordinary synonyms.

---

## 6. NOTICING, AND `intuition`

**`[A]` on what comes after noticing:** *putting into words, thinking about and taking action all
come after noticing - but i don't know it it's important to separate noticing from them.*

**It is important, and two of the day's rulings need it.** The blocking account needs it, because a
reaction can be initiated with no noticing behind it — if noticing were only the opening of what
follows, that could not happen. The ignoring account needs it, because there a fear is noticed and
admitted and the weighing stops; without the separation there is no way to tell ignoring from
blocking, and those are two of the four fates. **What is not needed is the three downstream things
separated from each other.**

### `intuition` — DEFINED AND RULED, and book 2 takes the word

**His definition, and it is his:** *intuition is noticing what was taken in when the person isn't
aware where what was noticed came from.* He offered a possible cause — *maybe the person rejects part
of what was taken in* — and `[C]` argued against needing one: the taking in was never noticed, only
what is noticed is available as something that happened, so there was never a moment to look back at.
**Nothing has to reject anything.** *His guess would need something doing the rejecting, and the
model has that only in the blindness loop, where it is a defence and needs a threat to run on.*

**He then put the shape himself:** *so it's something like digging up and noticing deposits of
something taken in earlier but not noticed at the time?* **One adjustment given and accepted: it need
not have been earlier.** What makes the source unavailable is that it was never noticed, and that
holds for something taken in a moment ago as much as decades ago. So the store and the present intake
are reached the same way and the model needs no separate machinery for old material.

**RULED, his words:** *intuition can then happen whenever something is not noticed - blocking is not
required. yes i agree with that definition.*

**Two gains recorded with it.** Book 1 asserts that much of what anyone knows about persons was
learned before language, is closed to the checklist because a checklist runs on concepts, and open
only to intuition because intuition does not. **Under today's rulings that follows** — material taken
in before there were words carries no words and no source, so noticing it now is the only thing that
reaches it. And the same structure already runs on the painful side: buried anxiety is felt without
being understood and cannot be traced, which is why it cannot be addressed. **Intuition is that
mechanism carrying something useful instead of something painful, which also explains why both are
hard to argue with.**

**One constraint keeps the two sides apart:** deposits are reachable by noticing when motivation
arrives, and blocking is what makes some of them unreachable — and blocking only runs where the
material threatens the person. **One store, part of it guarded.**

---

## 7. CROSSINGS BETWEEN A PERSON'S TWO REALMS — the brief's last question, settled

The brief asked what decides whether a tool carried into the other realm is a gift or a fault, and
offered two candidates: direction, or the Four as an unexplained exception. **Neither is the answer,
and `[A]` produced the shape.**

**He reframed his own case first:** *i am using the motivation i get from HB to notice what i take in
from SZ. that's not exactly a tool. a one insisting on precision in the physical is artificially
applying B to HA.* **So what crosses in his case is motivation, not a tool.**

**Then the rule, in his words:** *Z wants nothing. A or B does. for A or B to get what they want they
apply motivation in the Z realm. B can also take detachment from familiarity with the Z realm (a
"tool"). and A can take caution from familiarity with the B realm (a "tool").* And earlier, put as a
generalization: *each orientation receives from the one ahead except that z receives from both others
since z needs motivation.*

**His two tests, and both hold.** The Five is HB;SZ while the Six and the Eight are both HB with no
detached realm, so the Five's insight into the physical can only come from SZ. The Four is HZ;SB
while the One and the Six are both SB with no detached realm, so the Four's insight into the psychic
can only come from HZ. **Both isolate Z lending to B by holding the receiving realm constant.** His
journalist is a Two, HZ;SA, so the excitement is SA lending motivation to HZ.

### `[C]`'s error, and his correction

`[C]` said the fourth case had to go, on the ground that the One and the Eight are A importing caution
and are drafted as faults. **`[A]`: *what's wrong with A importing from B?*** **He is right and `[C]`
was wrong.** The two sites blame the realm, not the orientation. The One's says ideals are
psychic-realm objects and that carrying *that measure* into the physical realm gives a standard
nothing can meet. The Eight's says the imported moves are *physical-realm moves, correct in their own
realm*. **Both name the realm and neither names the orientation, so both are book 1's critical
confusion and neither is an instance of A importing caution.**

**What the book gains, and it is what the brief said was missing:** there are two crossings between a
person's realms, not one. **An orientation crossing helps. A realm's principles crossing is the
critical confusion.** A importing caution from B is the growth direction taken by a shorter route,
since the book already says a less caught enthusiastic realm reaches toward caution.

**Untested:** no site in either book shows a crossing into a cautious realm.

---

## 8. THE SCAN — five items, one withdrawn

He asked for a full re-scan against everything ruled: *a lot has changed. there might be new
conflicts or connections.* Book 2 was scanned whole and the relevant parts of book 1.

**1. The looking that stops — CONFIRMED, repair agreed.** The passage separating three things says
you can decline to attend to something already seen, that *the looking which would have shown you
something can stop*, and that where the looking has stopped there is nothing left to decline; the
next paragraph adds that under a forward lean what goes unseen *was never presented to be passed
over.* **Both say the taking in stops, and it never stops.** The separation survives and gets
simpler: all three take the material in; in the first it is noticed and the person declines to go
further; in the second the noticing is stopped; in the third there is nothing to decline because
nothing was noticed. **This matters more than a wording slip, because the four fates rest on this
separation.**

**2. A third compartment sentence — CONFIRMED, repair agreed.** *Some part of them registers the
threat and stops it before it reaches them. The fear survives whole, and out of reach.* What goes is
*some part of them* and *stops it before it reaches them*. **What stays: the fear does survive whole,
and a person cannot get at what they never noticed.** *Recorded with it, because it was never a slip
repeated three times: the book had no account of how something could be recognized without being
available, so it borrowed a place to put the recognition. All three sites come out at once because
the account now exists.*

**3. `register` doing both stages — CONFIRMED, and it became the vocabulary work in §5 above.**

**4. The pure detachment paragraph — `[C]` RAISED IT AND WITHDREW IT.** `[C]` argued that
*unselective receptivity* describes the taking in, which is unselective in everybody. **`[A]`:
*"whatever falls inside their narrow focus" is selective - it might not be any different than what
you consider to be intentional selection.*** **He is right and the conflict is not one.** Motivation
sets the width of focus, so a narrow focus is already a selection made by the motivation that set it.
The 0 position has no trace of either neighbour, so nothing sets a width and nothing is selected. The
passage is correct as it stands and for the reason it gives.

**What his correction establishes, and it is worth more than the withdrawn item: motivation acts at
both stages.** It narrows what is taken in and it drives what is noticed. `[C]` had it acting only at
the second, which is what produced the false conflict.

**5. The twelve instances were not repaired when the sketches were — CONFIRMED, repair owed.** The
figure chapter says a Two less caught in the physical realm can act on what they see a situation
requires *instead of leaving that sight unused*, and that a Four can take up the demands of physical
life *rather than only observing them*. **Both put the observation already done**, which is the
formed-sight-held-unused shape his 09-06 ruling settled against and which job54 repaired at the six
sketch blocks. **All six detached-realm lines among the twelve need checking against the four
repaired sketches.** *Why the site was missed: the repairs were made where each claim is stated, and
this passage restates the claims of six sketches in one place. Anything settled in a sketch has a
second home there.*

### The 0 position — a separate exchange, and it stays

He asked whether the 0 position could be omitted. **Kept and shortened.** The notation forces it: the
book writes leans as fractions from a zero, so a reader meets a zero position for every orientation
before that paragraph arrives. For enthusiasm and caution zero is the orientation at full strength
and the book gives that in a line; detachment is the one where zero is not obvious, because its leans
are opposite functions rather than intensities.

**He then asked whether the position is unstable or infinitely narrow in the face of fluctuations.
It is narrow, and `[C]`'s earlier phrasing — that it explains why a person does not stay — was wrong,
because it implies a push and nothing in the model pushes.** Book 1 supplies the reason: a measured
lean is a trait plus a fluctuating state, so a trait sitting exactly at zero still has a state added
to it and what is observed is almost never exactly zero. **The position is real and has no width.**
What the shortening keeps: that zero detachment is the absence of any trace of either neighbour, and
that this makes it a position with no width. What comes out: the recital of what each lean
contributes, which the section has already given twice by then, and *it is not perfection*, which
answers a question no reader is asking.

---

## 9. PROSE OWED — this is a full drafting session, possibly two

In no particular order except that the vocabulary pass should be last, since it touches sites the
other repairs will have rewritten.

1. **The width-of-focus claim sited in Part 1**, with the orientations. Motivation sets width;
   enthusiasm narrowest, caution wider, detachment widest. *A sentence in Part 1 already states the
   second stage — `your attention determines what you notice`, in the definition of the psychic
   realm — and is where this can attach.*
2. **Detachment's competence corrected** at the range of detachment: the competence is the taking in,
   not the attending. The contradiction the section is built on is then derived rather than asserted
   — detachment takes in the most and attends least, both from having no motivation.
3. **The two place-sentences in the blocking passage replaced**, and the third one repaired.
4. **The second-recognition sentence** — confirm with him first, then remove.
5. **The three-things-run-together passage** rewritten so that nothing stops looking and nothing
   fails to be presented.
6. **The leverage guess replaced** by the accumulating recognition.
7. **The Nine's block**, one word: *nothing bends what they take in*.
8. **The six detached-realm lines among the twelve instances**, brought into line with the four
   repaired sketches.
9. **The 0 position paragraph shortened**, with the trait-plus-state reason in place of the assertion.
10. **`intuition` sited in book 2**, which does not use the word once.
11. **THE VOCABULARY PASS**, and it is large: `take in` for the first stage everywhere, `register`
    split and retired, `surface` retired at two sites, and the verb `see` taken off the first stage
    at its two doctrinal sites. **Roughly a hundred sites once `see` and `sight` are counted, in the
    prose most recently worked over.**

---

## 10. OPEN, AND NOT TAKEN

- **The second-recognition sentence** — recommended for removal, never answered in as many words.
- **Whether blindness is a separate input to capacity or the realm-specific part of being caught** —
  carried from 09-06, untouched today. *Today's rulings bear on it and were not applied to it.*
- **No site in either book shows a crossing into a cautious realm.** Recorded as untested, not as a
  gap to be filled.
- **The claim inventory is one master stale** and does not carry any of today's doctrine.

---

## 11. THE RECORD

**Thirty-sixth append.** This was a doctrine session, so the record was opened rather than appended
blind. Reach verified before writing: 44,672 w, md5 `c6da637a`, marker `Job54 drafting 09072026`,
thirty-fifth append, parent 43,250.

---

## 12. RECOMMENDATION FOR THE NEXT SESSION

**Kind 11, drafting.** `[A]` asked whether drafting was next and it is. Nothing in §9 is blocked on
doctrine, and everything ruled today is prose the book does not have.

**Take the doctrinal repairs first and the vocabulary pass last, or give the vocabulary pass its own
session.** The two do not mix well: the repairs rewrite sentences the pass would otherwise have to
touch twice, and a hundred-site word change is the kind of work that goes wrong when it is squeezed
in behind other work. **A drafting session that takes both should expect not to finish.**
