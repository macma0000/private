# RELAY — from `Job81 doctrine 20261013`, 2026-10-19

Pasted by `[A]` into `Job87 coherence 20261018` on 2026-10-19 at 06:18, with the words *update from job81:*. Saved here byte for byte below the rule, as it arrived. `Job87` did not write any of it. The sites it names are in the 10-13 manuscript; `Job87` checked that each passage it names is still in `BOOK2-20261018.md`, except the glossary entry, which the master gives as *Blocked* in italics (found by its first words). See `FINDINGS-job87-20261019.md` Part Two.

---

For Job87 and the next drafting session, from Job81 doctrine, 2026-10-19. The sites are from the 10-13 manuscript and from the two Chapter 17 sections [A] supplied. Search the current manuscript for each passage.

How a person goes down a level. [A], on the chain of fears and desires: it seems to me it has something to do with “reifying” the new desire - that is, forgetting the new desire is derivative and taking it as self standing. On what makes the connection go out of view: aversion to the old fear? i like the version to the old fear. it’s our old Z+ transition. a fear that passes to Z+ meets a fate and a new desire arises, isn’t it? Then: at least forgotten. and aversion would facilitate that. it seems that the blocking can happen gradually and without the blindness loop. Asked whether a fear can pass gradually from noticed to unnoticed without a single act of blocking: yes. Then: i think a habit of turning away automatically does develop motivated by aversion. but no blindness loop. just a subconscious knowledge that facing the thing is uncomfortable. And: it seems like there is absolute blocking that involves panic and graduated blocking that builds as a habit. And: blind turning away for absolutely blocked. a possibility of seeing and choosing for graduated blocked?

Names. [A]: should we say blind blocked? and good for blind blocking. For the other kind, [A] offered partial blocking? semiconscious blocking? habitual blocking? discomfort blocking? Job81 chose discomfort blocking. [A]: ok. Buried stays with blind blocking only.

Where fresh burial happens. [A]: The thing that belongs only to the lowest levels is fresh burial - yes. Then, asked whether panic can happen to an adult in the upper bands: i think possible but less likely. but more likely in relation to absolutely blocked material. Panic can happen at any level stays, read with that.

Ignoring. [A] withdrew his question whether ignoring is the mildest form of discomfort blocking: it think my proposal was wrong. Asked about a person who thinks a fear wasn’t important, Job81 answered that a fear weighed and judged unimportant is worked through, and a fear called unimportant without being weighed is ignored. [A]: ok. The habit of leaving fears unweighed does not lower the level by itself, but it makes a later blocking more likely. [A]: yes.

Glossary, Blocked. [A] cut It begins as ignoring, saying ignoring now doesn’t imply discomfort. [A]: ok to:

Blocked — the fear is turned away from before it is noticed. There are two kinds of blocking.
Blind blocking happens in panic, to a fear the person cannot bear. The turning away is automatic and happens all at once. Blind blocking is the same act as denial, and a fear blocked blindly is a buried fear. The blindness loop keeps the buried fear in place. Anything that would lead toward the buried fear is turned away from as well.
Discomfort blocking happens to a fear the person can bear but finds uncomfortable. Each time the fear comes near, the person’s aversion turns their attention elsewhere. A habit of turning away builds until the fear is no longer noticed. No blindness loop forms. A later fear that matches the blocked fear is turned away from by habit, but the later fear can still be noticed, and the person can then choose whether to look at it.
Fears differ in strength. A fear of spilling a cup of coffee is weak. A fear of losing one’s job can be strong enough to be more than a person can bear.

The old entry’s last three sentences, beginning Ignoring and blocking begin as the same turning away, are cut.

Levels chapter: the chain. Replaces the section The rule beneath them from its first paragraph through the paragraph beginning The chain runs on unattended fears. [A]: yes to:

Heading: The process that produces the levels
Riso and Hudson also describe the process that produces the levels, which they call the core dynamics. A fear that is not settled leads to a desire for whatever the person believes would secure what the fear anticipates losing. The desire is taken up as an attitude, the attitude issues in behavior, and the behavior brings a fear of its own: the fear of failing at that strategy.
At first the person knows what the new desire is for. Suppose a person who fears not being safe comes to believe that money will make them safe. The person wants money, and knows the money is for safety. But every thought of what the money is for brings the fear about safety with it. Aversion to that fear turns the person’s attention away from the connection. Over time the connection stops being noticed, and the person wants money for its own sake. The fear about safety has been blocked, and the desire for money now covers the fear.
That is how a person goes down a level. The fear above is blocked, and the desire below is taken as wanted for its own sake. Ignoring does not move a person down, because an ignored fear stays in view.
In the healthy and average bands, Levels 1 to 6, the blocking is mostly discomfort blocking. A fear that matches the blocked fear can still be noticed there, and the person can choose to look at it. Material blindly blocked in childhood is carried at every level, and anything leading toward that material is turned away from blindly. Fresh blind blocking is possible at any level but less likely in Levels 1 to 6, and it is most likely where something touches material blindly blocked in childhood. Fresh blind blocking belongs mostly to the unhealthy band, Levels 7 to 9.

Levels chapter: what the chain conserves. [A]: yes to: It conserves what is wanted. Each new desire is a means to the desire before it, with the connection out of view. What the person aims at changes at every level. What the aiming serves does not. The deeper the level, the more connections are out of view, and the less of the original want is visible.

The job example. Some of the fears are noticed and turned away from, and those fears are ignored becomes Some of the fears are noticed and let alone, and those fears are ignored. [A]: ok.

The climb. In Where a level change can happen. [A]: it’s right to:

A person rises when blocked fears are retired. A blocked fear comes back into view, the person faces the fear, and the fear has been released. One fear retired is a small change, and a full level takes many. That is the climb.
A fear blocked by discomfort can come back into view when a matching fear is noticed, and the person can then choose to look at it. A buried fear is harder. Facing a buried fear means facing what the person earlier felt they could not bear, so a climb through buried material is rare.

Chapter 17, the second way down. The present section The second way down, which is not blindness keeps its text and is retitled Leaving fears unweighed. A new section follows it under the old heading. [A] required the last paragraph to say that a fear blocked blindly is a buried fear, then: ok to:

A fear can also be blocked without panic. The fear can be borne, but facing it is uncomfortable. Each time the fear comes near, the person’s aversion turns their attention elsewhere. A habit of turning away builds until the fear is no longer noticed. This is discomfort blocking. A fear blocked in panic, all at once, is blindly blocked.
Discomfort blocking takes a person down, a little at a time, as blind blocking does. In Levels 1 to 6 it is the usual way down.
Discomfort blocking forms no blindness loop. A later fear that matches the blocked fear is turned away from by habit, but the later fear can still be noticed, and the person can then choose whether to look at it. Looking is uncomfortable, but the discomfort can be borne. So a person can rise through material blocked by discomfort alone, one fear at a time.
A fear blocked blindly is a buried fear. A buried fear is faced alone only when staying has become unbearable. Help from outside can bring the facing sooner.

Sweep: how hard it is to rise. [A]: there is a lot (probably later) about how very difficult it is to rise that was written when we thought all blocking was blind. Asked whether the difficulty applies only to buried material: as it was written, yes. Every statement of how hard it is to rise is limited to buried material. Passages to check include A climb of any real distance is measured in years, the comparison of the pain of staying with the pain of facing and the climb ending at the middle, how the recognition builds under consequences, Recognition works one kind of painful thought at a time, and the section that replaced the leverage material, which [A] says no longer uses that figure.

Not yet approved. For What falling takes from capacity, Job81 proposed that the third source say where the inability comes from: The third is that a person who cannot handle life perceives the inability as a threat. Things going wrong unexpectedly, and reactions that have not been thought out, can together leave a person unable to handle life. The person goes on perceiving the threat as long as the situation persists. The drafting session should show it to [A].