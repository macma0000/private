# FILES from `Job70 doctrine 09152026` — receipt list, 2026-10-11

For the coherence session following `Job78 drafting 20261007`, to check what reached it.

**Why this list exists.** `MANIFEST-job79-20261011.md` covers the 57 files at the set's top level
and **does not cover `spent/`**, where 70 files sit as carriage. Both of this session's applied files
are in `spent/`, so the manifest cannot confirm them. Check them against the rows below instead.

Every row is `md5`, then words by `LC_ALL=C wc -w`, then bytes.

---

## 1. Live, and must be present

### In `spent/` — applied by `Job78`, kept for provenance

| File | md5 | words | bytes |
|---|---|---|---|
| `CLOSURES-SITED-job70-20261009c.md` | `8cfac99b7a037a34f5262659b4709781` | 3374 | 19720 |
| `RECUT-range-of-detachment-from-job70-20261009b.md` | `3b27041bb24df68cc8ae7ad43cf37487` | 2072 | 12185 |

**These two carry every ruling of the 10-09 sittings.** They are in `spent/` because `Job78` applied
them, not because they are dead. A coherence run checking whether a repair landed should read them.

### At set level — in the manifest

| File | md5 | words | bytes |
|---|---|---|---|
| `NOTE-introduction-recognition-20261007.md` | `33cc97900e0d2b8e5efc22f6311dd0fe` | 330 | 1860 |

**Recorded to be done later, with three cautions. No session is to act on it until `[A]` says so.**

### Arriving by hand — cut after `Job78` closed, so in no manifest

| File | md5 | words | bytes |
|---|---|---|---|
| `BRIEF-for-coherence-from-job70-20261011.md` | `92f505847059a899caa2931670b92a24` | 1313 | 8049 |
| `AUTHOR-RECORD.md` | `4a13bf4b4a62773eef517e568f0be681` | 85913 | 507793 |

**The brief is the one file written for this coherence run.** It names the one sweep worth doing,
what to check, where this session has been unreliable, and which gaps are deliberate. **If it did not
arrive, ask `[A]` for it before starting.**

**The record in the zip is superseded.** `MANIFEST-job79-20261011.md` lists `AUTHOR-RECORD.md` at
84,610 w, md5 `19f449d8`, which was the head when `Job78` cut the set. The live head is **85,913 w,
md5 `4a13bf4b`**, carrying `Job70`'s sixty-seventh append. **Use the live head and expect the manifest
row for the record to mismatch.**

**Why it mismatches, so nobody reads it as corruption.** `Job78` appends blind. On 2026-10-10
`Job70` appended its late sitting against parent 83,603 w and numbered it the sixty-sixth; `Job78`
then wrote its closing block against the same parent and took the same number. Both children were
byte-identical to that parent at the head, so nothing was lost. `Job70` kept `Job78`'s block as the
sixty-sixth and re-placed its own after it as the sixty-seventh, changing only the marker. The
re-placement is stated inside the block.

---

## 2. Held out deliberately, and must **not** be present

| File | md5 | words | bytes |
|---|---|---|---|
| `NEW-MATERIAL-the-unease-loop-20260923b.md` | `f4b41533605a3cd5908ed1a5e984a01e` | 2639 | 15787 |

**Held out of every set at `[A]`'s instruction**, for a drafting sitting of its own. Verified absent
from `job78-out-20261011.zip`. Three things now wait for that sitting, and the brief lists them.

**A coherence run will find places where this material would go. The gaps are deliberate and are not
faults.**

---

## 3. Superseded, and correctly absent

Verified absent from the set. **If any of these turns up, it is a stale copy and is not to be used.**

| File | md5 | words | bytes |
|---|---|---|---|
| `CLOSURES-SITED-job70-20261009.md` | `380400c7f3eabf6dd2e0a66b8d711ba9` | 1320 | 7634 |
| `CLOSURES-SITED-job70-20261009b.md` | `f2349368959368ed3725c62810bbe607` | 2537 | 14817 |
| `RECUT-range-of-detachment-from-job70-20261009.md` | `c92879eb73ba90ce50af379dfa59ee15` | 1675 | 9807 |
| `FINDINGS-range-of-detachment-20261007.md` | `31a153afc1c2eb22852e5456e5768e59` | 3410 | 19807 |
| `DRAFT-range-of-detachment-job70-20261007.md` | `c145d82fe72e57b4ace7e72a104bc325` | 2163 | 12208 |
| `DRAFT-range-of-detachment-job70-20261007b.md` | `bf13ee15a8ff46e64739233a557e6cb4` | 2171 | 12250 |
| `NEW-MATERIAL-the-unease-loop-20260923.md` | `f3e46069e8a135cc487f188dd0d7798f` | 1589 | 9371 |

**Two of these matter more than the rest.** The earlier closures file numbered without a letter, and
the earlier re-cut file, **fenced off three doctrine questions as open. All three are settled**, and
the letter `c` and letter `b` versions lift the fence.

**And the two detachment-section drafts are superseded as candidate texts.** `[A]` ruled on 2026-10-09
that `Job78`'s version in the master is the base. **Neither draft is to be drafted from.**

---

## 4. Earlier sittings, already in `spent/` as carriage

Produced by this session between 09-15 and 09-23 and long applied. Listed for completeness; the
rulings in them are superseded by the files in section 1 wherever the two differ.

| File | md5 | words | bytes |
|---|---|---|---|
| `CLOSURES-SITED-job70-20260915.md` | `93532a86fa942c0f22f623cf60a17d70` | 2600 | 15064 |
| `CLOSURES-SITED-job70-20260916.md` | `176d1fc9e9c150403be7e600959b4982` | 1427 | 8508 |
| `CLOSURES-SITED-job70-20260923.md` | `ab25e9b72d1a3e00d7015c3b2c4da87e` | 2241 | 13166 |
| `CLOSURES-SITED-job70-20260923b.md` | `614ec9e3ea7a6a539b830c30bc36d370` | 3095 | 18242 |
| `CLOSURES-SITED-job70-20260923c.md` | `3df066c1025a091049d9f362576b8f4d` | 2396 | 14200 |
| `CORRECTION-to-job70-closures-20260923.md` | `aeae2f26fdb51b6cf150ae06e66b9807` | 855 | 5040 |
| `NOTE-for-job74-from-job70-20260923.md` | `6a6a0e7d6880067ca1a55ee01eae5632` | 681 | 4037 |
| `NOTE-for-job74-from-job70-20260923b.md` | `ae6294eccfb1eee2930e94b853d9b5e5` | 717 | 4189 |
| `ANSWERS-for-job75-from-job70-20260923.md` | `1ceb2dd387cbf486475ab3921519b023` | 872 | 5282 |
| `ANSWERS-for-job75-from-job70-20260923b.md` | `161d965469ae339c048ee20f57ceb835` | 761 | 4588 |
| `ANSWERS-for-job75-from-job70-20260923c.md` | `2bfd4283f27a54ca17d6f5446dc50763` | 525 | 3373 |
| `ANSWERS-for-job75-from-job70-20260923d.md` | `a0b45033e644feb12a8fd12109811d52` | 937 | 5849 |
| `ANSWERS-for-job75-from-job70-20260923e.md` | `3881a24a694bbec4a2200bff41654ee3` | 1152 | 7185 |
| `ANSWERS-for-job75-from-job70-20260923f.md` | `110b7de36671078a1aa14045eb09d65b` | 554 | 3335 |
| `ANSWERS-for-job75-from-job70-20260923g.md` | `b7ed37a23d9b775b8730d8d81b6d14fa` | 461 | 2783 |

**One warning about these.** `CLOSURES-SITED-job70-20260923c.md` opens with a strike of a sentence
this session had wrongly recorded as ruled, and `CORRECTION-to-job70-closures-20260923.md` corrects
three statements in an earlier closures file. **Where an older file and a newer one disagree, the
newer one wins, and no `[C]` reading in any of them carries a licence.**

---

## 5. What is not in any file

Two rulings of 2026-10-10 are in the record's sixty-seventh append and in no draft: that trained
abiding acts on the feeling guarding a burial, with the effect needing strength before any content
comes into view; and the two consequences for material laid down before a person had words. **A
coherence run cannot write these in. They need a drafting slot.**
