# SET NOTE — from `Job64 drafting 20260912`, 2026-09-12

## What arrived

One zip, `job63-out-20260912.zip`, directory `job64set`, verified against
`MANIFEST-job64-20260912.md`: **72 ok / 0 mismatched / 0 bad count / 0 missing / 0 not in the
manifest.** The screen fired twice and both are expected — `AUTHOR-RECORD.md` as CARRY DO NOT READ,
and `HANDOFF-20260906.md` quoting the restriction string. Both tools exempted themselves.

**This is a drafting session and the record was not opened.** `setcheck.py sweep` confirmed its
reach without opening it: 59,528 w, forty-fourth append, parent 58,114 — matching the manifest row
and Job63's set note. Chain clean.

**`[A]` NAMED THIS SESSION `job63-drafting-20260911` AND THE LABEL SAYS `Job64 20260912`.** The
label wins, per the standing rule, and it was said in the first message. The zip he sent is
`job63-out-20260912.zip`, which is the set Job63 CUT; reading a session name off an outgoing zip is
the trap the `-out-` suffix was added to prevent and it has now caught somebody. **He asserted the
kind himself: drafting.**

## What this session did

Applied `CLOSURES-SITED-job63-20260912.md` in full. **Twelve of the fifteen rows wanted prose and
all twelve are written; three were recorded no-change and all three were left alone.** Two further
sites carrying the retracted account were found by sweeping and repaired, and one verb was changed
at `[A]`'s instruction.

`BOOK2-20260910.md` (35,048 w, `d5b02d58`) → **`BOOK2-20260912.md` (35,695 w, `1065e37e`)**.
Everything is in `CHANGES-job64-20260912.md`. **Book 1 was not touched.**

The five largest:

- **`bodily tension` is in the book**, introduced in a paragraph of its own after the four fates,
  where both fates that leave something are described. It is never called a fear at any site.
- **The four fates entries were restructured**, after `[A]` asked *"are those part of a list?"* —
  see the correction below.
- **The spread is written** for the first time, at the maintenance loop.
- **The descent's two phases are written**, with the childhood exception as the guard that stops a
  reader concluding that nobody above Level 7 has anything buried.
- **The falling is identified with the shrinking** of what a person can still approach.

## `[A]`'s corrections in session

**THE DEPOSIT CORRECTION, and it is doctrine.** Of `[C]`'s *An ignored fear leaves nothing there*:

> "An ignored fear leaves nothing there," - ignoring reinforces the habit of ignoring - that's not
> what you meant but it is a deposit.

So the 09-12 ruling that an ignored fear leaves nothing mental holds of the FEAR and not of the
ACT. **This supplies the engine the forgetting ruling was missing** — ignoring is laid down like
any other act, comes more easily each time, and so sinks from the chosen end of the run toward
forgetting at the involuntary end. Written into the health-axis chapter at the one place a reader
would ask for it.

**THE LIST QUESTION.** *"are those part of a list?"* The two paragraphs he was asking about were not,
but the question caught `[C]` having taken two of the four fate entries from two sentences to six
while the other two stayed at two. All four are comparable again.

**THE VERB, rejected twice.** *"earliest years answered" - bad verb*, then, when `[C]` reported the
same verb doing the same job in the book's own inherited sentence one section later, *"change the
second also."*

## Two sentences corrected after he approved them

The referring-word count was run over every changed block after the last approval and found two
failures in prose already agreed: *in the same way* reaching back four sentences in the spread
paragraph, and *All of that* reaching over a whole section at the end of the sketches. Both
repaired, both marked in the changes file, both reported to him.

**The lesson is the rule's own.** Both sentences were written after reading the rule, read back by
`[C]` without anything seeming wrong, and shown to `[A]` in that state. Running the count is not
optional and reading the prose back is not a substitute for it. **Run it before delivering, not
after.**

## The brake — flagged for the sixth time, and it has changed character

The engine now has explicit prose in two chapters: the spread in the fixations chapter and the
shrinking in the health-axis chapter. Against it stands `[A]`'s two-phase account, written this
session, which is the first thing in weeks that limits the engine's reach — above the unhealthy
band there is little blindness to feed. **Nothing was added to the brake and no rate was written
anywhere.**

**What is new is that this is no longer a doctrine question.** The falling-and-rising chapter has a
section arguing why the fall does not take everyone to the bottom, and the health-axis chapter now
says a person falls as their world shrinks. Whether those two are consistent is settled by reading
both, which is the coherence kind's job. Job31, Job32, Job33, Job49 and Job63 each declined to
assemble a brake; this session declined too, and hands it over as a check rather than a
construction.

## A convergence found while repairing one sentence

**The falling-and-rising chapter's second way down and the health-axis chapter's phase above Level 7
appear to be one account written twice.** One describes attention withheld from a fear that stays in
view, hardening into a general habit of not taking questions up; the other describes the
compensatory chain running on ignored fears with little blindness. They were written in different
sessions and neither refers to the other. **Not resolved here — this is exactly what a coherence run
is for.**

## What is still owed

- **`NOTE-doctrine-from-job61-20260909.md` is untouched and all of it stays owed**: the three wants
  behind the basic fears, the nine per-type derivations and the object rule, the basic desire, the
  contagion question, the cautious lean's understanding, and bodhicitta.
- **`NOTE-doctrine-from-job62-20260910.md`'s last item stays owed**: a short section making explicit
  the relation between fixations, stages of the process arc, and single thoughts.
- **`CLAIM-INVENTORY-book2-20260902.md` was already stale and is now fifteen sites staler.**
- For the later style job: `denial`/`blocked`/`buried` as three names for one act, and `loop` doing
  four jobs. **Ch 11's forward reference to Part 3 and Ch 14's case named by its position are the
  same list's items; the second of those was discharged this session** inside a sentence being
  repaired anyway.

Both doctrine notes travel in this set unchanged. `CLOSURES-SITED-job63-20260912.md` is discharged
and travels as history.

## Record

**FORTY-FIFTH APPEND, BLIND** — a drafting session does not read the record. The prefix above the
join was verified byte-identical to the parent and its md5 came out `38aed3b3`, matching the
arriving manifest row. Head is now **60,384 w, md5 `08d122d0`**, marker
`2026-09-12 · Job64 drafting 20260912`, parent 59,528 named in the block. The block quotes `[A]`'s
typed words and marks everything else as `[C]`'s report.

## Recurring defect, seventh run running

**The handoff's job-kind rows still do not match the sets.** Reported by Job57, Job59, Job61, Job62,
Job63 and now this session. A handoff session should fix the rows from the last seven set notes.

**And the handoff itself is now the older file no longer.** The record is 60,384 w against the
handoff's 76,495 — a gap of 16,111 and closing by roughly 850 a session. Whoever cuts the next
handoff should expect to be the one who flips the read-in-full rule and builds the dated subject
index the record's own rules call for.

## What comes next — `[A]` asserted it

**Coherence.** He took `[C]`'s recommendation: *"ok. coherence."* Three things for it to take first,
in this order:

1. **The brake**, as a consistency check between the two chapters named above, not as a
   construction.
2. **The second way down against the two-phase descent** — whether they are one account said twice.
3. **The claim inventory**, stale before this session and staler now.

After that, a handoff session. The live handoff is from 09-06.
