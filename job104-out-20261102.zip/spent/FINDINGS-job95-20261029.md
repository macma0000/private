# FINDINGS — `Job95 coherence 20261029`

Coherence run on `BOOK2-20261029.md` (44,653 w, unchanged), reading `CHANGES-job94-20261029.md` and the three relays
`job94 drafting 20261028` applied (`RELAY-from-job81-20261029.md`, first proposal only; `-20261029b.md`; `-20261029c.md`).
The session ran on 10-29 his time. `[A]` named it `Job95 coherence 20261029`; the manifest label `job95-20261029` agrees.

**Changes file checked.** All 12 rows of `CHANGES-job94-20261029.md` are in the master (22 paragraph hunks against
`superseded/BOOK2-20261028.md`). Every sentence the three relays proposed is in the master as the rows say: relay
`20261029`'s first proposal at *A burial is not one event*; relay `20261029b`'s four sentences in the house-sale example,
with no other sentence in *The unease loop* saying the tension builds; relay `20261029c`'s two paragraphs at *Two things
that cannot happen*, and *blacked out* gone from the book. `wordcheck.py` against letter `p`: the only changed hits are the
ones row 6 and the Checks list name. The referring-word count passes on every new sentence. One claim in the changes file is
wrong: *No I, my or me of the author's remains after the Foreword.* One remains, in the Introduction (item 1).

**For the drafting session.** All four items are `[C]` decisions taken from rulings already given. Show `[A]` each change in
place before applying it, new words in square brackets, with the words going out listed underneath (bold does not show on
his screen). Grep each idea by its words, not only at the sites listed.

**Tracking check.** Run on **bodily tension**: where a fear's fate leaves it, how long it lasts, how the unease loop keeps
it up, and what it does to what a person can bear. The four fates, *The unease loop* and the capacity sections of the
falling chapter agree. Relay `20261029b` ends *Tension kept up in the unease loop adds to stress, which lowers what the
person can bear.* That line was not proposed for drafting and is not in the book; Chapter 4 already says stress *can come
from anywhere*. Left. Also run on **the author's own voice**, the 10-28 ruling, across the whole body of the book (item 1).
Tests (a) to (d) were not re-run across the book.

## 1. The Introduction still speaks as the author

**Fault.** The 10-28 ruling: the author does not refer to himself in the body of the book; the Foreword keeps *I*. `Job94`
applied it at fourteen places, including Chapter 4's *My proposal is that only the same three orientations are possible…*
(now *Only the same three orientations are possible…*, row 11). The Introduction's sentence was missed:

> My proposal is that the three are orientations — three ways of being turned toward whatever a person is dealing with — and that the two are realms, two domains of experience that run on entirely different principles.

The Introduction is not the Foreword. `[A]` answered *yes* to stating the model's central proposals plainly (row 11).

**`[C]` DECISION, by row 11's ruling:** state it plainly, as Chapter 4 now does: *The three are orientations — three ways of
being turned toward whatever a person is dealing with — and the two are realms, two domains of experience that run on
entirely different principles.*

**Same sweep, one further site.** *The Common Thread Between the Types*, end of the type profiles: *The gap between how we
see ourselves and how we actually move through the world is not a flaw to be ashamed of.* The *we* includes the author. It
is the only *we*, *our* or *us* in the narration after the Foreword; the others are inside quoted speech (Chapter 8's
*our downside?*) or the types speaking in the first person. **`[C]` DECISION:** *how we see ourselves and how we actually
move* → *how people see themselves and how they actually move*.

## 2. Two sentences in a row say a habitual fear is not noticed and is noticed

**Fault.** *The unease loop*, habitual-fear paragraph, as `Job94` row 8 left it:

> A fear that a matter raises every time the matter comes up is a habitual fear. With buried material, the fear is no longer noticed. A habitual fear is noticed every time, and worked through every time, as each turn of the unease loop is.

*The fear* points back to the habitual fear named in the sentence before. Read that way, the middle sentence says a habitual
fear is no longer noticed, and the next sentence says a habitual fear is noticed every time. `Job93` read *the fear* as the
buried fear itself, which is what makes the paragraph hold together. The sentence has to name that.

**`[C]` DECISION:** *With buried material, the fear is no longer noticed.* → *With buried material, the buried fear is no
longer noticed.* That is the style guide's repair for a referring word that points at the wrong thing: name the thing.

## 3. The job example sorts the fears into groups that never meet

**Fault.** The 10-28 addition at *A burial is not one event*: *Before the panic, the fear has usually been ignored, or
blocked by discomfort, as the problem went on. Each time the fear came back stronger.* *The range of detachment*, job
example, sorts the fears the news raises into three groups:

> Some of the fears are noticed and let alone, and those fears are ignored. Some of the fears are noticed, and the person turns away from them because looking at them is uncomfortable. Those fears are blocked by discomfort. Some of the fears grow until they are more than the person can bear, and panic turns the person away from them. Those fears are buried. Each fear meets one fate.

Read with *Each fear meets one fate*, the fears that grow to a panic are a group apart from the ignored fears and the fears
blocked by discomfort. By the burial passage they are usually the same fears, earlier. The two agree only through Chapter 14's
*A fear also lasts only one thought*: each time a fear comes back it has been raised again, and each raising meets one fate.
A reader holding the job example will not make that connection.

**`[C]` DECISION, by relay `20261029` and Chapter 14:** in the job example, the buried group says where its fears came from,
and the closing sentence says what *one* counts. Proposed: *Some of the fears are ignored or blocked by discomfort many
times, and come back stronger each time, until one time a fear is more than the person can bear, and panic turns the person
away from the fear. Those fears are buried. Each time a fear is raised, it meets one fate.* Show `[A]` before applying; he
may prefer to word it.

## 4. *Rising* now calls two different things a way out

**Fault.** *Rising* opens, since row 6: *In a fall, a fear is turned away from. In a climb, a fear that was blocked comes
back into view and is faced.* Later in the same section:

> Giving up on ignored aversions is the way out most within a person's reach. The matter behind an ignored aversion can still be noticed. The matter is available, though not necessarily in view. So the person can give up the want behind the aversion. Each ignored aversion given up on takes away some of the unease that sends a person looking for distraction. A better distraction is never a way out, because every distraction wears off.

In a section about climbing, *the way out* reads as a way up. But an ignored aversion was never blocked, and *Where a fear
meets its fate* says *Only blocking leaves a person noticing less than before*. So giving one up does not raise a person on
the health axis. What the paragraph says it removes is unease, one of the three sources *The unease loop* gives for lasting
unease.

**`[C]` DECISION:** name what it is a way out of: *Giving up on ignored aversions is the way out of lasting unease most
within a person's reach.* The paragraph stays where it is.

## 5. Checked and left

- *A fall cannot bring insight.* (relay `20261029c`) against *Why this does not take everyone to the bottom*: the damage
  is taken in and laid down during the fall, and the recognition can come into view under enough consequences. What is laid
  down is taken in, not noticed, and insight adds to what a person notices. Left.
- *Nobody watches themselves go down.* *A person may feel the discomfort of a fear, or the panic, at the moment of turning
  away.* Against Chapter 4's *Neither the anxiety nor the easing is noticed* and *Burial is not a decision*'s *neither of
  them is ever noticed*: the book keeps feeling and noticing apart (*the later threat is felt even though the threat is not
  noticed*). Left.
- *What actually descends*: *There is no event of collapsing… There was no moment.* Against *Once the person has panicked,
  the main burial of a matter happens quickly, perhaps within a week.* A burial is felt, and takes far less than a level.
  Left.
- Chapter 4's new panic sentences against the cycle chapter's *two faces* and *The range of detachment*: all three now put
  the panic at the caution end and the completed turning away at the enthusiasm end. Left.
- *Panic* as a cautious person under stress *acts without weighing* (falling chapter) and as what turns a person away from
  a fear: the cycle chapter has panic raise *a want to be rid of the fear*, which carries the person forward to the
  enthusiasm end, so acting without weighing and turning away are one motion. Left.
- *Rising*: *a fear that was blocked comes back into view*. For a fear blocked by discomfort it is a matching later fear
  that is noticed, as *What is actually being undone* says. Close enough at an opening. Left.
- The book naming its own terms (*This book calls that act noticing*, *what this book calls a fixation*) is the book, not the
  author, and is outside the 10-28 ruling. Left. *Depth of fixation was matched to their levels* (row 9) hides who matched
  it, as the ruling intends. Left.

## Owed

- **A drafting session** on items 1 to 4 above.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master. Carried.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold. Carried.
- **The writer 2 pass**, still waiting on Toby Marshall. Carried.
