# SET NOTE — from `Job95 coherence 20261029`

This note goes to the session that receives `job95-out-20261029.zip`. `[A]` gives the kind of session. The manifest
label carries only the counter and the date: `job96-20261029`.

## Arrival

`job94-out-20261029.zip` verified against `MANIFEST-job95-20261029.md`: **59 ok, 0 mismatched, 0 bad count, 0 missing,
212 not in the manifest**, all 212 in `spent/` (132) and `superseded/` (80), matching `Job94`'s moves. The screen fired on
the record (carry, do not read) and on 42 files, all in `spent/` and `superseded/`. The record's last marker matched
`Job94`'s note: ninety-sixth append, 103,462 w. `[A]` named the session `Job95 coherence 20261029`; the label's counter
agreed.

## What was done

A coherence run on **`BOOK2-20261029.md`** (unchanged; 44,653 w), reading `CHANGES-job94-20261029.md` and the three relays
it applied. All 12 rows and every relay sentence are in the master. **Product: `FINDINGS-job95-20261029.md`** and a second
10-29 block in `CLAIM-INVENTORY-book2-20260902.md`. No question was put to `[A]`.

Four faults, each a `[C]` decision taken from rulings already given:

- **The Introduction still speaks as the author:** *My proposal is that the three are orientations…*, missed by the 10-28
  ruling. `Job94`'s changes file says no *I*, *my* or *me* remains after the Foreword; this one does. The same sweep found
  one narrating *we* (*how we see ourselves*, end of the type profiles).
- **A habitual fear, not noticed and noticed:** *With buried material, the fear is no longer noticed.* reads as the habitual
  fear named before it. Name it: *the buried fear*.
- **The job example's fears:** *Each fear meets one fate* sets the buried fears apart from the ignored ones and the ones
  blocked by discomfort, against the 10-28 burial sentence.
- ***Rising*'s *way out*:** giving up on ignored aversions is a way out of lasting unease, not a way up the axis.

Tracking check run on **bodily tension**, and on **the author's own voice** across the body of the book. Tests (a) to (d)
not re-run.

## The record

One append, blind: the **ninety-seventh**, `[A]`'s one line verbatim. **Parent 103,462 w, head 103,656 w.** The parent's
bytes were checked unchanged at the join.

## Moved

- To `spent/`: `CHANGES-job94-20261029.md`, `SET-NOTE-from-job94-20261029.md`, and the three relays checked in this run,
  `RELAY-from-job81-20261029.md`, `-20261029b.md`, `-20261029c.md`.
- To `superseded/`: `MANIFEST-job95-20261029.md`.
- **Kept live:** `FINDINGS-job75-20261005.md` for its Part Four; `NOTE-introduction-recognition-20261007.md`, not to be
  acted on until `[A]` says so.

## What is owed

- **A drafting session on `FINDINGS-job95-20261029.md`**, items 1 to 4.
- **The handoff is stale.** `HANDOFF-20261005b.md` names the 09-23 master.
- **For a doctrine session:** whether being less able to handle life than others are bears on depth and threshold.
- **The writer 2 pass**, still waiting on Toby Marshall.

**For any session that shows `[A]` a change: bold does not show on his screen.** Mark new words with square brackets and
list the words going out underneath.

## Next

`[C]`'s recommendation: **a drafting session on `FINDINGS-job95-20261029.md`.**
