# THE UNEASE LOOP — `[A]`'s new material, 2026-09-23

**Supersedes `NEW-MATERIAL-the-unease-loop-20260923.md`**, adding the loop's strength by
orientation, the three-way distinction about unease, and the placement.

Cut by `Job70 doctrine 09152026`. Everything here was settled with `[A]` in this sitting and is
his, except where a line says `[C]`. **It is not drafted anywhere.** The file kind follows
`ARC-ACCOUNT-from-job72-20260916.md`.

**`Job70` had no manuscript and no record in this sitting.** Sites are named by content.

**Read with `CLOSURES-SITED-job70-20260923c.md` and
`CORRECTION-to-job70-closures-20260923.md`**, which carry the rest of this session's work.

A drafting session taking this needs a whole sitting. The account touches Ch 14, Ch 15 and Ch 16,
and it answers a question Ch 14 currently answers wrongly.

---

## 1. Where it started

`[A]`: *i have noticed that i spend most of my time in thought cycles of desire and fear, much like
riso's description of falling through levels, desire to reduce fear and fear because the desire
fails.* He asked whether failing to process the fear is one of the four fates, proposed the name
*stuck in engagement*, and said **many people spend most of their time in this state.**

## 2. The four fates stand unchanged

**No fifth fate, and no adjustment.** The case is **worked through**, every cycle. Deciding another
step is needed is one way of working a fear through, and *I will try again* is that decision in its
thinnest form.

**Giving up stays one fate.** `[A]` raised two kinds, and the two turn out to be two things being
given up rather than two fates. **Dropping the desire is giving up, and the fear goes with it.
Dropping the attempt is not giving up on anything**, because an intention to try again is raised in
its place.

**Ignoring stays distinct, with a plain test.** A person who ignores leaves the content alone and
keeps the feeling, with no intention raised. A person who tries again has an intention and no fear
left to feel.

**`[C]` proposed splitting worked through in two — faced and settled against faced and not settled
— and `[A]`'s next answer made the split unnecessary.** Recorded so a later session does not
re-propose it.

## 3. What happens at the ending

`[A]`: *the fear is replaced with the intention to try again, which is a desire. in the next thought
cycle, if the desire fails, a new fear arises.*

So the fear is disposed of, not left standing and not stored. What survives into the next cycle is a
desire, which is what the arising hands on anyway. **Each cycle has its own fear, raised fresh**,
exactly as the arc account says. What is not settled is the problem, and a problem is not a fear.

## 4. The same shape in all three orientations

`[A]`: *in all orientations, it seems that the person gives up with the intention that the fear
still needs to be dealt with.*

- **Enthusiastic** — the desire is to try something else.
- **Cautious** — the desire is to solve the existing problem.
- **Detached** — the desire is to make the anxiety go away, either by distraction, meaning doing
  anything else rather than the more focused alternatives an enthusiastic person reaches for, or by
  finding a creative solution rather than the overly focused attempts a cautious person makes.

**The differences fall out of the orientations rather than being added to them.**

## 5. What persists — RULED, `unease`

`[A]`: *in all cases, the underlying bodily discomfort, its mental discomfort and the desire to
escape it, remain.*

**The name is `unease`, bare.** `[A]` considered and set aside *chronic unease* and *persistent
unease*; `[C]` objected to `chronic` as medical vocabulary, which the book has kept out, and `[A]`
agreed that unease *can last years as well as hours*, so the bare word carries both scales and the
sentence says which is meant. **No synonym is used** — `disquiet`, `restlessness`, `agitation`,
`malaise` and `discomfort` were all considered and none taken.

**Unease is the whole round. The bodily tension is the part that carries between cycles.** So the
09-12 bodily-tension entry is **amended, not replaced**: the bodily tension keeps its job as what
holds the feeling between cycles, inside the account below.

**`[A]`: the discomfort is more basic than the problem**, because *solving a problem usually leads
to finding another problem.*

## 6. The unease loop — RULED

`[A]`'s own formulation: **fear → tension → desire for relief → fear.**

A fear is raised and examined. The fear leaves tension in the body. The tension is uncomfortable, so
a desire for relief is raised in the next cycle. The examination finds the desire cannot be met, and
a new fear is raised.

**Every step runs through the phases.** Each pass is a thought cycle with its arising, its
development and its ending, so nothing new has to be posited to make the round turn.

**The original trouble stops mattering.** The first fear may have been about something real. The
desire for relief is about the tension, and the fear that follows is about failing to get relief.
After a few turns the round runs on itself.

**The name is `the unease loop`**, settled against `the unease cycle`: `cycle` is the closed round
of the three orientations (RULED 09-15) and this runs across many thought cycles. `loop` was ruled
to the feedback loop and the blindness loop only, so **this is a third permitted use and goes in
the word register.** The pairing with the blindness loop earns its keep — both rounds keep
themselves going with nothing arriving from outside.

## 7. Saturation — RULED

`[A]`: *what if the unease loop saturates at a lower level of disability than the blindness loop?*
**Yes**, and `[C]`'s earlier proposal that the loop merely maintains itself is **withdrawn** — it
made the loop flat from the first turn, and unease builds.

**What sets the ceiling.** Unease is felt, and the fear raised at each turn has its content in view,
so an exit is available at every turn: the problem gets solved, or the desire is dropped, or the
person notices what the discomfort is doing. **The exit does not have to be taken for the ceiling to
exist** — the pressure to leave rises with the discomfort, which is `[A]`'s own brake account, where
what decides is which is more painful, staying as one is or facing what was avoided.

**The blindness loop has no ceiling** because it removes the thing the exit depends on. A buried
fear is not in view, so the pressure rises and the person cannot see what to do about it.

**`[C]` note on wording:** `disability` is `[A]`'s word in conversation and is not the book's
vocabulary. The plain version is that the unease loop carries a person only so far down the axis,
where the blindness loop has no floor.

## 8. The loop's strength by orientation — `[A]` agreed with `[C]`'s reading

`[A]`: *your thoughts match mine including the conclusion that the answer is complicated for
detachment.*

**Strength is two quantities, and the orientations rank oppositely on them.** That is the finding,
not a failure to reach one.

**How fast the loop climbs** is set by how much tension each turn leaves. A cautious fixation
examines heavily, so many fears are raised and each leaves tension — fastest. An enthusiastic
fixation examines cursorily — slowest. 

**How high the loop saturates** is set by how available the exit is, and the exit needs the
discomfort noticed. A cautious person notices everything, so pressure to leave rises with the
climb. A detached person at the enthusiasm end ignores what arrives, which removes the exit's own
requirement, so the loop sits at a level nobody acts on.

**Detachment spans the whole range on its own, and the lean is why.** At the caution end arriving
fears are processed, so the exit is open and the loop stays low. At the enthusiasm end they are
ignored, so the exit is shut. Caution and enthusiasm each sit at one place; detachment does not.
**This is why `[A]`'s answer for detachment had two branches where the others had one.**

**`[C]` recommendation for a single measure, not ruled:** the loop's strength is **how much unease
it holds a person at over a lifetime**, which is the saturation level and not the climb rate. On
that measure detachment at the enthusiasm end is strongest, caution is next, enthusiasm is
weakest. **The climb rate stays as a separate thing the book also says.**

## 9. Unease present, unease noticed, unease acted on — RULED

`[A]`: *i'm confused about the relationship between awareness of unease and the degree of ability
to deal well with reality.* `[C]` had run three things together and untangled them; `[A]`: *i think
so. add it.*

**Three different things.**

- **Unease being there.** The body is tense and the loop is turning. True or not regardless of
  whether anyone notices.
- **Unease being noticed.** Whether the person registers what they feel. This is sight, which is
  what the health axis measures.
- **Unease being acted on.** Taking an exit — the problem solved, the desire dropped, or the person
  stopping because of what the discomfort is doing.

**Dealing well with reality is the third. The second is required for it and does not deliver it.**
So noticing unease is neither the same as handling it nor opposed to handling it.

**The consequence for the axis.** The health axis does not run from uncomfortable to comfortable.
It runs from not noticing to noticing. **A person higher up may feel more unease than a person
lower down and be better able to do something about it.**

**The consequence for the loop.** A person at the enthusiasm end of detachment has little unease
noticed and plenty present, because ignoring removes the noticing and leaves the tension. A
cautious person has much noticed and much present, **and is not worse off for feeling more —
feeling more is what makes the exit reachable.**

**`[C]`'s earlier sentence is corrected:** the strongest loop does not *feel least urgent from
inside*. **The loop hardest to leave is the one whose unease is least noticed.** Not because
feeling bad is good, but because the exit needs the feeling in view.

## 10. Placement — `[C]` recommendation

**Four sites, four different claims, not one claim repeated.** Saying it four times would cost the
reader more than it gives.

- **Ch 4 — nothing to add.** The distinction already exists as the two stages: everything is taken
  in, only some is noticed. Unease present but unnoticed is that split applied to one thing. **A
  drafting session hooks to what is there rather than building it again.**
- **Ch 15, with the unease loop.** One sentence that unease is there whether or not a person
  registers it, then the saturation claim, which needs it.
- **Ch 16, where the axis is defined.** The axis runs from not noticing to noticing, not from
  uncomfortable to comfortable.
- **Ch 17, the climb.** A climb is an increase in discomfort, undertaken — `[A]`'s 09-21 ruling
  with a reason under it, since facing restores the feeling that burial removed.

**Risk to flag before Ch 16 is written.** *Healthier people may feel worse* is counterintuitive, and
a careless sentence would read as the book recommending discomfort. **The safe form says what the
axis measures rather than what a person feels:** the axis is about how much is in view, and more in
view means more unease in view along with everything else.

## 11. Where the shape itself belongs

**`[C]` recommendation, not ruled.** The shape answers the question Ch 14 currently answers wrongly
— why one way of noticing stays put for fifty years. A person raises a desire, examines it, finds it
cannot be met yet, settles the fear with an intention to try again, and the next cycle raises nearly
the same desire out of what that one laid down. **Each cycle does its job. The problem outlasts all
of them, and the move is made again every time.** See
`NOTE-for-job74-from-job70-20260923b.md` for why the paragraph there is wrong.

## 12. Kept out deliberately

`[A]`: the shape *probably explains workaholism, ptsd and obsessions.* `[C]` recommended leaving the
clinical names out, because the model cannot support a claim about a disorder and a reader who knows
the literature would judge the whole book on the fit. **`[A]`: *keep them out for now.*** Recorded so
a later session does not read the absence as an oversight.

**No health claim is made anywhere in this account.** The research behind it connects this material
to disease; the book does not.

## 13. `[C]` draft paragraph — NOT ruled, for a drafting session to work from

> Unease keeps itself going. A fear is raised and looked at, and when the looking is done the body
> is left tense. Tension is unpleasant, so the next thought is about getting rid of it, and getting
> rid of it is not something a person can simply do. The attempt fails, which raises a new fear, and
> the new fear leaves the body tense again. A person can go round this for years. What they are
> working on by then is not whatever first troubled them — it is the tension itself, and the failing
> to be rid of it.

**`[C]` note on the research**, used here and not cited, as `[A]`
asked. Three findings stand behind the account. Behaviors that look nothing alike are grouped by
what they are for, which is why trying again, going at it again and distracting are one shape.
Repetitive thought about something unresolved keeps the body activated long after the trouble
itself, and **duration rather than frequency is what matters** — which is why the shape rather than
any one cycle is the thing to describe. And a competing account holds that the unfinished problem
rather than the discomfort is what drives the repetition; **`[A]` ruled for the discomfort**, on the
ground that solving one problem usually turns up another.

---

## 14. How common it is — RULED, and the research behind the ruling

`[C]` researched the prevalence at `[A]`'s request. **The evidence does not support a claim that
most people spend most of their time here, and `[A]` agreed to drop it.**

What the research shows, uncited in the book as with the rest:

- **Mind wandering is about half of waking life.** People spend 46.9 percent of waking hours
  thinking about something other than what they are doing, it occurs in at least 30 percent of
  samples during every activity except one, and it typically makes them unhappy. Sample of 2,250
  people aged 18 to 88, 250,000 moments.
- **Rumination scales say the opposite.** In 64,901 adults over twelve annual waves, mean scores
  sat well below the scale midpoint across the lifespan, with only 5.6 to 7.8 percent above the
  midpoint at any wave.
- **Both can be true**, because the scales count thinking a person recognizes as stuck. **This
  shape does not feel stuck from inside — a person trying again experiences effort.** There is also
  an argument in the literature that much prolonged physiological activation comes from
  perseverative cognition the person does not report, which would make self-report undercount it.

**RULED: the book claims that the shape is ordinary rather than a disorder, that it can run for
years without a person thinking of themselves as troubled, and that a person inside it experiences
effort rather than being stuck. No frequency claim is made.** `[A]`: *i agree with your population
recommendation.*

---

## OPEN — nothing

The question this file previously carried — whether the shape is most people's life or what a
cautious fixation does in particular — **is answered twice over.** The population half is settled
above. The orientation half is settled in the strength section: **all three orientations run the
loop, and they differ in climb rate and saturation rather than in whether they have it.**
