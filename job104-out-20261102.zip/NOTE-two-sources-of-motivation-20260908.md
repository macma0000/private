# NOTE — where a realm's motivation comes from

**Written 2026-09-08 by `Job55 doctrine 09072026`, after the session closed, on `[A]`'s questions
about prose drafted later. For the drafting session. It has six parts: the doctrine, one confirmed
defects with their repairs, a vocabulary retirement, a test for finding other sites, and the two
blocks `[A]` has already had proposed.**

**Sections 4 and 5 were added after the first three, once `[A]` had put a Chapter 4 draft and a
Chapter 7 proposal against this doctrine. Read those two sections before writing anything: they
carry a word retirement that changes how the doctrine has to be said.**

---

## 1. The doctrine

**Motivation reaches a realm two ways, and they are not interchangeable.**

**From the realm's own process arcs. IN THE BOOK, twice.** A process arc runs in a realm, the
examination phase raises a fear, and the fear arrives at the resolution phase. The book states this
at the range of detachment — *a fear arriving from the cautious orientation meets the desire for
comfort* — and again at the crossing — *a process reaches detachment at the caution end, where fears
are still seen, and leaves by the enthusiasm end.* **A fear is a motivation.** This source is
available in every realm a person has, whatever orientation is held there, including a realm held in
detachment and including both realms of a Nine.

**From the person's other realm. RULED 2026-09-07.** An enthusiastic or cautious realm lends
motivation to a detached one. This source requires a non-detached other realm, so a Nine does not
have it.

**What detachment lacks is motivation of its own, not motivation.** Detachment originates none — it
seeks nothing and has no aim of its own. That is what *Z wants nothing* means. It is not a claim that
no motivation reaches a detached realm, and the two must not be run together.

**What the lean does. IN THE BOOK.** The trace of a neighbouring orientation decides how long a
person dwells at the seeing end of the crossing, and so how much of an arriving fear is processed:
leaning toward caution they move slowly through and more is processed, leaning the other way they are
already moving as they pass. **So the lean decides what becomes of a motivation that has arrived.**

**NOT RULED, and it must not be written as though it were:** whether the lean is itself a source of
motivation. `[C]` raised it in the 09-07 session in connection with the 0 position and `[A]` never
answered. Treat it as open. Everything in this note works without it.

**`[C]`'s derivation, marked as such because `[A]` has not ruled it, though it follows from what he
did rule.** The two sources differ in whether the motivation carries an object. **A fear delivered by
an arc arrives with its own object** — it makes the person notice that thing and nothing else.
**Motivation lent by the other realm has no object in the receiving realm**, so it can be turned on
whatever that realm has taken in. This is `[A]`'s own case as he described it on 09-07: *I am using
the motivation I get from HB to notice what I take in from SZ.* The consequence is that a Nine
notices what their arcs have raised a fear about and little else, while a Five can go looking.

---

## 2. The confirmed defect

**Drafted wording, from a session after 09-07:**

> A Nine has no other realm to draw on, so whatever motivation a Nine has in a realm comes from a
> trace of a neighbouring orientation, and that trace decides which face of detachment shows there.

**What is right:** a Nine has no other realm to lend to them. Both realms are detached, so the
cross-realm source is unavailable. And the second clause is right — the trace does decide which face
shows.

**What is wrong:** the step from there to *whatever motivation a Nine has*. A Nine is short of one
source, not of motivation. Every arc a Nine runs delivers a fear to the crossing, in whichever realm
it ran, and the book says so in the two places quoted above. **The sentence also gives the trace a
job the book gives to the arc.**

**Proposed repair, for the drafting session to take or improve:**

> A Nine has no other realm to lend them motivation, so a Nine works with whatever their own arcs
> deliver. A fear arrives at the crossing with its own object, so a Nine notices what a fear has been
> raised about and little else. The trace of a neighbouring orientation decides what becomes of that
> fear, and so which face of detachment shows there.

*Style note: the third sentence names the trace and the fear rather than pointing back at them,
per section 9 of the style guide.*

---

## 3. The test, for finding others

**The general shape of the error: reasoning from a realm being detached, or from a person having no
non-detached realm, to that realm having no motivation.** It is easy to make because *detachment
wants nothing* is true and sounds like it settles the question. It does not, because arcs keep
running and keep delivering fears.

**The reverse form is the same error seen from the other side: giving the lean a job the arc does.**
Anything that has the trace supplying, generating or providing motivation, rather than deciding what
becomes of it, should be looked at.

**Where to look.** The six detached-realm sites are the exposed ones — the Two's physical, the
Four's physical, the Five's psychic, the Seven's psychic, and both of the Nine's. **The Nine is the
most exposed, because it is the only type where the cross-realm source is genuinely absent, so it is
the one place where a drafter reaching for an explanation has nowhere else to reach.** The figure
chapter restates six sketches in one place and should be checked as well as the sketches themselves;
that is where the twelve instances were found unrepaired on 09-07.

**Strings worth grepping:** `no other realm`, `draw on`, `whatever motivation`, `no motivation`,
`nothing to draw`, `trace of`, `neighbouring orientation`, and `motivation` within the Nine's blocks
and the range of detachment.

**What a hit is not.** A sentence saying a detached realm generates no motivation of its own is
correct and should be left alone. A sentence saying a detached realm has little motivation available
in practice may also be correct, since a Nine's arcs are weak — but it should say so, rather than
saying there is none.

---

## 4. VOCABULARY — `trace` is retired, and what arrives gets no name

**RULED 2026-09-08 by `[A]`, after he read the word the other way himself.** Shown a Chapter 4 draft
that turned on a *trace of one of the other two orientations*, he said: *i thought trace meant what
the process carried from the previous orientation.*

**In book 2 `trace` means the composition of the lean** — how much of a neighbouring orientation is
present in where the fixation sits. Each lean adds a trace of its neighbour; the trace of enthusiasm
grows further along the range; the 0 position is the absence of any trace of either.

**His reading names something real: the want and the fear the arc carries into the resolution
phase.** So the word stands for two things that both exist in the model, and they are the exact pair
these passages have to keep apart — what arrives, and what becomes of it once it does. **`[A]`: *i
think having trace for lean is confusing.***

**The retirement, and it is three moves.**

- **`trace` goes.** Say the lean, or where the fixation sits on the range. The sentences read as well
  without it: *the backward lean is corrective concern, seeing tinged with caring* says what *carries
  a trace of caution* was saying. Five sites in book 2, four of them in two paragraphs, plus whatever
  is in new drafts.
- **What the arc carries gets no name.** It is two things, not one — a want raised at the impulse
  phase and a fear about it raised at the examination phase — and the pair being separate is what
  sorts the four outcomes. Say *a want and a fear about it*, or *an arriving fear* where the want is
  not at issue. **A single word for the pair would be a coined handle and would put back exactly what
  retiring `trace` removes.**
- **A phase stops being called an orientation.** The book says *a fear arriving from the cautious
  orientation*, which gives an orientation to a phase. An orientation is where a person stands. Name
  the phase: a fear raised where the want was examined.

**Also settled in that exchange, and it belongs with the doctrine in section 1:** the lean and the
fixation's position are one fact, not two. A fixation sitting on the caution side of detachment is
what having a trace of caution consisted of. Prose that has a trace appearing from nowhere and
deciding things should name the fixation instead.

---

## 5. THE TWO BLOCKS `[A]` HAS ALREADY HAD PROPOSED

**He asked for both to be proposed together and neither written until he had seen both.** That has
now happened for Chapter 4 and Chapter 7, and this section records where each stands. **Both still
need writing; nothing here has gone into the book.**

### Chapter 4 — three faults, one of them the `trace` collision

The draft made the lean a switch with two settings — where the trace is caution one thing happens,
where it is enthusiasm another. **The later material rules the opposite:** the two positions in
detachment are one quantity, not two conditions with a boundary between them, and every process
passes through the whole range. What separates people is dwelling time at the seeing end, not which
end they are at.

It also implied the disturbing part is settled in advance — *a disturbing part of it is looked at* —
where under a dwelling account it is a matter of how far the person got. And it used `trace`, per section 4.

**Proposed repair, which `[A]` has seen:**

> A fear reaching a detached realm arrives at the caution side first, where fears are still seen, and
> moves on toward the side that turns away. What becomes of it is how long the person stays with it,
> and that is set by where their fixation sits. A fixation on the caution side holds them there, and
> more of the fear is looked at. A fixation on the other side has them already moving toward what
> attracts, and less is.

**Its own first sentence — *Detachment originates no motivation of its own. It seeks nothing. What
moves a detached person reaches that realm from somewhere else* — needs checking against section 1.**
*From somewhere else* will be heard as the other realm, and the arc source is inside the same realm.

### Chapter 7 — the vocabulary held; one conflict and one word

**What the proposal got right, and both are easy to lose in rewriting.** *A process running in a
detached realm still raises fears* is the arc source of section 1 stated plainly in the book for the
first time. And *turned away from before it is noticed* uses the two stages correctly.

**The conflict.** The proposal split the fates two ways — dealt with, or turned away from — and put
*left in plain view* under dealt with. **The four outcomes are sorted by two questions, not one:
whether the fear is in view, and whether it is disposed of.** Ignoring is the case that is in view
and disposes of nothing, which is why the fear comes back. Folding it under *dealt with* loses that.

**The word.** The proposal calls what arrives a fear in its first two paragraphs and an anxiety in
the third. **In the descent material the two are not interchangeable.** A fear has an object the
person can name; an anxiety is what a fear becomes once it has been turned away from — felt without
being understood, untraceable, and therefore unaddressable. On the branch where the fear is noticed,
nothing has become an anxiety.

**Proposed repair of the third paragraph, which `[A]` has seen:**

> So a fear arriving in a detached realm is either noticed or turned away from. Noticed, it can be
> settled, or dropped, or left standing with only the occasion let pass — and either way the person
> knows what it was. Turned away from, it survives whole, and the person never knew it was there to
> deal with.

### What the pair established

**The rules of section 4 are usable by someone who was not in the conversation.** The Chapter 7
proposal was written against them and came back with no `trace`, dwelling rather than location, and
`notice` used for the second stage. **That was the point of proposing both before writing either**,
and it is why the same method is worth using on any further block that does this work.

---

## 6. Where this came from

`[A]` raised it after `Job55 doctrine 09072026` had closed, having read the drafted sentence: *doesn't
our idea say that the process arc carries fear motivation from b into z?* It does, and the book
already said so before 09-07. **What 09-07 added was the second source, which is what made the first
one easy to lose sight of** — the cross-realm rule was new and vivid, and the drafter reasoned from
its absence rather than from what the book already had.

**That is worth carrying as a general caution: a new ruling makes the material it does not cover
easier to forget, not harder.**
